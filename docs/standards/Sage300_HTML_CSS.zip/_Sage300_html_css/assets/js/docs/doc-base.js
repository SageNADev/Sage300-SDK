/* apply kendo controls and custom radio/checkbox */

$('.dropdown-group select').kendoDropDownList();
$('#ddl2').kendoDropDownList();
$('#datepicker1').kendoDatePicker();
$('#numeric1').kendoNumericTextBox();

$('input[type=radio]').parent().addClass('radio');
$('input[type=checkbox]').parent().addClass('checkbox');
