/* apply kendo controls and custom radio/checkbox */

$('.dropdown-group select').kendoDropDownList();
$("select.single-select").kendoDropDownList();
$("select.multi-select").kendoMultiSelect(
	{
    autoClose: false
});
$('#ddl2').kendoDropDownList();
$('#ddl3').kendoDropDownList();
$('#datepicker1').kendoDatePicker();
$('#numeric1').kendoNumericTextBox();

$('input[type=radio]').parent().addClass('radio');
$('input[type=checkbox]').parent().addClass('checkbox');
