# Sage installation
Make sure to have the latest version of Node.js

## Install Grunt
`npm install -g grunt-cli`

## Install Sage dependencies
Go to the root of the project and run 
`sudo npm install`

## Automatic compilation
* less compilation `grunt less`
* Automatic compilation `grunt watch`

## Jekyll compilation
* run `jekyll serve --watch` to start the server and watch for changes to the mark-up
* jekyll will take the files from the docs directory and compile them to the design-principle directory
