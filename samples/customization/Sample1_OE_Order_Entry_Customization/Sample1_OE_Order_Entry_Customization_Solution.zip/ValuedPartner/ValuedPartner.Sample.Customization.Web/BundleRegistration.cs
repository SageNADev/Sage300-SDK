﻿/* Copyright (c) 2021 Valued Partner.  All rights reserved. */

using System.Web.Optimization;

namespace ValuedPartner.Sample.Customization.Web
{
    /// <summary>
    /// Class for bundle registration
    /// </summary>
    internal static class BundleRegistration
    {
        /// <summary>
        /// Register bundles
        /// </summary>
        /// <param name="bundles"></param> 
        internal static void RegisterBundles(BundleCollection bundles)
        {

        }
    }
}
