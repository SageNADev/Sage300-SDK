﻿/* Copyright (c) 2021 Valued Partner.  All rights reserved. */

using Microsoft.Practices.Unity;
using Sage.CA.SBS.ERP.Sage300.Common.Web;
using System;
using System.Linq;
using System.Web.Mvc;
using ValuedPartner.Sample.Customization.Web.Areas.Customization.Models;

namespace ValuedPartner.Sample.Customization.Web.Areas.Customization.Controllers
{
    /// <summary>
    /// Controller needs to be registered in CustomizationWebBootstrapper
	/// TODO: add custom controller actions
    /// </summary>
    public class ValuedPartnerSampleCustomizationController : MultitenantControllerBase<ValuedPartnerSampleCustomizationViewModel>
    {
        /// <summary>
        /// Constructor with container parameter
        /// </summary>
        /// <param name="container">The unity container</param>
        public ValuedPartnerSampleCustomizationController(IUnityContainer container)
            : base(container, "UniqueScreenName")
        {
        }

        /// <summary>
        /// Index action method
        /// </summary>
        public virtual ActionResult Index()
        {
            ViewBag.Sage300Url = "http://localhost/Sage300";
            return View();
        }

        [HttpGet]
        public JsonResult GetOrderDetails(string id)
        {
            // Call Sage 300c controller/service/repository or custom service to get data
            var data = new OrderViewModel();
            data.CustomOrderNumber = "CustomOrder_00001";
            data.CustomOrderComments = "This is custom order comments.";
            data.CustomOrderDate = new DateTime(2016, 10, 28);
            data.CustomIsActiveOrder = true;
            data.CustomOrdNumberAmount = 20100.82;
            data.CustomOrderCurrency = "CAD";

            JsonResult jsonResult = new JsonResult { JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            jsonResult.Data = Json(data);
            return jsonResult;
        }
    }
}