﻿/* Copyright (c) 2021 Valued Partner.  All rights reserved. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ValuedPartner.Sample.Customization.Web.Areas.Customization.Models
{
    /// TODO: add custom models and view model

    public class ValuedPartnerSampleCustomizationModel
    {
    }

    public class ValuedPartnerSampleCustomizationViewModel
    {
    }

}