
"use strict";

var ValuedPartnerCopyOrderCustomUI = ValuedPartnerCopyOrderCustomUI || {};
var CopyOrdercustomViewModel;

ValuedPartnerCopyOrderCustomUI = {

    // Init
    init: function () {
        ValuedPartnerCopyOrderCustomUI.initButtons();
    },

    // Init Buttons
    initButtons: function () {
        $("#btnCustomCreate1").bind('click', function () {
            sg.utls.showKendoConfirmationDialog(function () { }, null, "Valued Partner Customization button click, add Javascript code to do real work.", "Demo");
        });
    },
};

var CopyOrderCustomUICallback = {
};

// Initial Entry
$(function () {
    ValuedPartnerCopyOrderCustomUI.init();
});
