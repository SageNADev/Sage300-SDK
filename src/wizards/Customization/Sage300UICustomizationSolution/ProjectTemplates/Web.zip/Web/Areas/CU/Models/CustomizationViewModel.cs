﻿/* Copyright (c) 2017 $companyname$.  All rights reserved. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Areas.$module$.Models
{
	/// TODO: add custom models and view model
	
	public class $project$CustomizationModel
    {
    }

    public class $project$CustomizationViewModel
    {
    }
	
}