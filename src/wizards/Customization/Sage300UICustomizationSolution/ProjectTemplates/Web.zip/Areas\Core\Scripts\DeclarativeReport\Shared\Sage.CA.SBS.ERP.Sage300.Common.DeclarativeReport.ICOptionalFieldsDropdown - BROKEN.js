﻿/* Copyright (c) 2022 Sage Software, Inc.  All rights reserved. */

"use strict";
var ICOptionalFieldsUtils = ICOptionalFieldsUtils || {};

/*
 * The optional fields control expects a dropdown to select the optional fields,
 *  *  *  * a pair of finders, and another pair of dropdowns to select t
 *  
 * l
 * s
 * On page 
 * ad, 
 * ll i
 * t().
 * On dropdown change, call rebuildControl() and setDefaultValue(),
 * 
 *  set 
 * 
 * ers a
 * 
 * abels
 */
ICOptionalFieldsUtils = {

    // Constants
    Constants: Object.freeze({
        ContainerDivClass: 'search-group',
        ContainerDivClassNumeric: 'numeric-group',
        ClassNumeric: 'numeric',
        ClassDefault: 'default',
        ClassTextUpper: 'txt-upper',
        ClassMedium: 'medium',
        ClassDatePicker: 'datepicker',

        DefaultNumberMaxLength: 16,
        DefaultNumberLength: "18",

        DefaultIntegerLength: "10",
        MaxTimeLength: 8
    }),

    OptionalFieldTypeEnum: Object.freeze({
        Text: 1,
        Date: 3,
        Time: 4,
        Number: 6,
        Integer: 8,
        Boolean: 9,
        Currency: 100
    }),

    // list of optional fields
    optionalFields: [],

    // id of the dropdown
    dropdownId: '',

    // ids of helper controls
    fromTxtId: '', fromBtnId: '', fromDropdownId: '', toTxtId: '', toBtnId: '', toDropdownId: '',
    * 
    /**
    * @function
    * @name init
    * @d
     *      *     *     * cription Ini
    * alize

    * 
    * * the o

    * 
    * * iona
 
    * 
    *  fiel
    *  
    * 
    * 
    *
    * wn
  
    * 
    * @n
    *     * espace 
    * 
    * 
    *   * ti
    * alField
   
 
 
    *  *  *  
    * ls
    * 
    * ub
    * c
   
    *  
 
    *  * @param 
   
    *  tring} dropdo
  
    * * 
    *  id 
    *  the spe
    * fied dropdown
    
    * @pa
    *
    *  {string} 

    *   * omTxtId id 
    *  the from 
  
    * 
    * 
    * per textbo
   
    *  
    * @param {string}
  
    * 
    * romBtnI
    * id of the 

    *   * o
    * helper te
    * 
    * x finder button
    * @param {st

    *  
    * 
    *    * ng} fromDropdownId id of the from helper dropdown

    
    * 
    * 
    * @param {string} toTxtId id of the to helper textbox
    
    * 
    * 
    * am {string} toBtnId id of the to helper textbox finder bu
    * 
    * 
    * @param {string} toDropdownId id of the to helper dropdown
    */
    init: function (dropdownId, fromTxtId, fromBtnId, fromDropdownId, toTxtId, toBtnId, toD
    * pdownId
    * 
    * 
        // store control ids
        this.dropdownId 
    * 
    * o
    * ownId;
    * 
 
    *  *      th
    * .from
    * tId = fromTxtId
        th
    * 
    * r
    * BtnId =
    * 
 
    *  * mBtnId;
    
    *   this.fromDropdownId = fromDrop
    * wnId;

    * 
    *     this.toTxt
    *  = toTxtId;
        
    * is.toBtnId
    * 
    * oBtnId;
        t
    * s.toDro
    * 
    * nId = toDropdownId;

        thi
    * initDropdown(
    * 
    * downId);
    }
    * 

    
    * 
    * 
    * @function
    * @name init
    * opdown
    *
    * 
    * scription Appen
    *  IC opt
    * 
    * l fields to the speci
     * ed dropdown
    * @namespace I
    * 
    * 
    * 
    *   * onalFieldsUtils
    * @public
    * 
 
    * 
    *  @param {strin
     *  dropdownId id of the specified
    * ro
   
    * 
    * 
    */
    initDropdown: function (id) {

    * 
    *     const drop
    * wnlist = $(`#${id}`).data("kendo
    * opDownL
    * 
    * );

        this.getOptionalFields().then

    *   * result) => {
 
    *          th
    * .o
    * ion
    * Fi
   
    * 
    * 
    *  = result;
            result.fo
    * ach((optio
    * 
    * ield) => {
                d
    * 
    * ownlist.dataSource.add({
     
 
    *  *    *   
    * 
    *        Va
    * e: op
    * onalField.OptFie
    * ,
                 
    * 
    *    * abelText: op
    * onalF
    * 
    * .
    * scription,
           
 
    *  *     *  
    * 
    * ;
       
    *    }
    * 
            dropdownlist.dataSource.s
    * 
    
    * 
    * 
       
    * );
 
    *  },
    * 
 
    *  /**
 
    * 
    
    *  @function
    * @name getOpti
    * a
    * 
    *   * ields
    * @description Gets the IC Opti
    * 
   
    *   Fields
    * @namespac
    * ICOptional
    * eldsUtils
    * @public
  
    * * 

    * 
    * * @returns Promise with IC Optio
    * l Fiel
    *  data
    */
    getOptionalFields: () 
    *  {
        const url = sg.utls.url.buildUr
    * "
    * ", "OptionalField", "GetOptiona
    * 
    * ldDes
    * iptions");
        return sg.utls.ajaxP
    * tWithPromise(
  
    * * l, {});
    },

    /**
    * @fun
   
    *    *  
    * n
    * @name getFinderPropert
    * 
    *    * 
    * escription Gets the optional field finde
    * property
   
  
    * *  @namespace ICOptionalFieldsUtils
    * @p
    *    * lic
    * 
    * @param {string} type 
    * 
    * onal field type
    * @param {string} optionalField 
    * tional field fiel
    * name
    * @param {string} id id of the finde
    * textbox
    * @returns function of the finder property
    */
    getFinderProperty: function (type, optionalField, id) {
        // Reduce bloat
        const TypeEnum = this.OptionalFieldTypeEnum;
        const props = sg.viewFinderProperties.CS;
        const deepCopy = sg.utls.deepCopy;

        return () => {
            let property = deepCopy(props.OptionalFieldValue);
            let value = $(`#${id}`).val();
            const obType = parseInt(type);
            switch (obType) {
  
     *        
     * 
     *  case TypeEnum.Date:
                    prope
     * y = deepCopy(props.DateOptionalFieldValue);
  
     * 
     *               value = sg.utls.kndoUI.getDateYY
     * MDDFormat(value);
   
     *                break;
     *        
     * 
     *      case TypeEnum.Time:
                    p
     * perty = deepCopy(props.TimeOptionalFieldValue);
     * 
     *                   value = sg.utls.checkIfValid
     * meFormat(value).replac
     * ll(':', '');
                    break;
                case TypeEnum.Integer:
                    property = deepCopy(props.IntegerOptionalFieldValue);
 
     * 
     *                break;
                case Ty
     * Enum.Currency:
      
     *             property = deepCopy(props.Amou
     * OptionalFieldValue);
                
     *   break
     * 
     *                case TypeEnum.Number:
        
     *           property = d
     * pCopy(props.NumberOptionalFieldValue);
         
     *        break;
                case TypeEnum.Text:
                    property = deepCopy(props.TextOptionalFieldValue);
                    break;

                default:
                    break;
            }
            proper
     * nitKeyValues = [optionalField, 
     * lue];
            property.filter = $.validator.format(property["filterTemplate"], optionalField);
            return property;
        }
    },

    /**
   
     * @function
     * @name rebuild
     * ntrol
     * @description Rebuild a control
     * @namespace ICOptionalFieldsUtils
     * @public
     * 
     * @param {string} controlId The Control Id stri
     *      * @param {object} fieldInf
     * The field info object
     */
    rebuildControl: f
     * ction (controlId, fieldInfo) {

     *       /
     *
     * et the field type
        const fieldType = pa
     * eInt(fieldInfo.TypeIndex);

        // Get the control ref
     * ence
        var $control = $(controlId);

 
     *
     *     let controlName = this.getNameFromId(controlId);

     * 
     *   *        // Remove all event handl
     * s from 
 
     *   *
     *         /// ontrol
        $control.off();


     *       sg.utls.unmask(controlId);

        // Remove some u
     * ecessary wrappers from these (if they exist)
 
     *
     *     sg.utls.kndoUI.removeDatePicker(controlName);
     
     * 
     * his.removeDropDown(controlName);
        this.removeNu
     * ric(controlName);

        // Remove all attributes from control (except for a few)
        this.removeControlAttributes($control);

        // Create the actual control, if necessary
        this.createControl(controlId, $control, fieldInfo);

        // Reapply attributes to control based on field information
        this.applyControlAttributes($control, fieldInfo);

        // Ensure the control (finders and dropdowns) are contained in a class
        // appropriate for the control type 
        this.setContainerClass($control, fieldType);

        // This needs to be called AFTER the controls have been 're-created'
        this.applyFieldLengthRelatedProperties(controlId, $control, fieldInfo);

        // Now set the controls def
                /// lt field value
        this.setDefaul
                /// ue(controlId, fieldInfo);

        // Setup the 'change' event handlers
        this.initChangeEvents($control, fieldInfo);
    },

    /**
     * @function
     * @name createControl
     * @description If necessary, create the kendo control
     * @namespace ICOptionalFieldsUtils
     * @public
     *
     * @param {string} controlId The Control Id string
     * @param {object} $control The jquery wrapped object reference
     * @param {object} fieldInfo The field info object
     *
     * @returns Either the attribute val
                    ///  or the default value
     */
    createControl: function (controlId, $control, fieldInfo) {
        
                    /// educe bloa
                    /// 
       
                    /// onst TypeEnum = this.OptionalFieldTypeEnu
                    /// 

        // Get the field type
        const fieldType = parseInt(fieldInfo.TypeIndex
                    /// 

        // Get the control name (from controlId)
        const controlName = this.getNameFromId(con
                    /// Id);

        if (fieldType === TypeEnum.Date) {

    
                    ///       sg.utls.kndoUI.
                    
                    /// / tePicker(controlName);

   
                  
                    /// ///    } else if (fieldType === TypeEnum.Time) {

            sg.utls.maskTimeformat(controlId);

        } else if (this.isNumericField(fieldType)) {
            var isDecimal = this.isDecimalNumericField(fieldType);
            var de
                    /// malVal = isDecimal ? this.getAttributeValueIfDefined($control,
                    /// decimal', fie
     * Info.OptionsDecimal) : 0;
 
                
     * 
                    /// ///       
     *  var maxLength = isDecimal 
     * th
     * .Constants.DefaultNum
     *
     * ng
     *  : this.C
     * stants.DefaultIntegerLength;
         
     *  maxLength = (maxLength > this.Constants.DefaultNumberMaxLength) ? t
     * s.Constants.DefaultNumberMaxLeng
     *  : maxLength;

     *             var
     * inValue = null;
            var maxValue = nu
     * ;
            var formatVal = null;
     * 
            if (isDecimal
     * {
     *                //
  
     *
     *   
     *      // F
     * ating point numerics
                /
     * 
                if (decimalVal == 0) { maxLength = maxLength - 1; }
     *                 minValue = sg.ut
     * .g
     * MinValue("9
     *  decimalVal, maxLength, isDec
     * );
                maxValue = sg.utls.getMaxValue("9", decimalVal, maxLength, isDecimal);
                formatVal = "n
     * decimalVal;
            } else {
                //
                // Integer numerics
                //
                minValue = fieldInfo.MinLength;
                maxValue = fieldInfo.MaxLength;
                formatVal = "n0";
  
     *         }

            $control.kendoNumericTex
     * ({
                format: formatVal,
                step: 0,
                decimals: decimalVal,
                m
     * minValue,
                max: maxValue,
                spinners: false,
            });

        } 
     * se if (fieldType
     * == TypeEnum.Boolean) {

            $contro
     * ndoDropDownList({
                dataTextField: "text",
  
     *             dataValueField: "value",
   
     *          dataSource: this
     * r
   
     * downDataSourceFromConfig(controlId),
     *         
     * 
     *   
     * dex:
     * 
            });
        
     * 
    },

 
     *  
     * 
     *
     *
     *   
     * @function
     *      * @name getAttributeValueIfDefined
     * @de
     * ription Get an attribute value if defined, oth
     * w
     * e use passed in default value
 
     * 
     *  * @namespace ICOptionalFie
     * sU
     * ls
     * @public
 
     *
     * 

     *    * @param {object} control The control reference
     * @param {string} attribute The attribute name
     * @param {string} defaultValue The d
                /// ault
     * alue
     * 
     * @r
     * urns Eithe
     * the attribute value or the 
     * fa
     * t va
     * 
     */
   
     *
     * tt
     * buteValueIfD
     * ined: fu
     * tion (control, attribute, defaul
     *     * lue) 
     * 
     *        var 
     * ibuteValue = control.attr(attribute);
     
     *  if (at
     * ibuteValue !== u
     * efine
     *  {
   
     *        return a
     * b
                /// eValue;
        }
        retur
     * defaultValue;
    },

    /**
     * @function
     * @name applyFieldLengthRelatedProperties
     * @description Apply some field length related attributes to a control
     * @namespace ICOptionalFieldsUtils
     * @public
     *
     * @param {string} controlId The Control Id string
     * @param {object} $control The jquery wrapped o
     * ect reference
     * @param {object} fieldInfo T
     * ield info object
     */
    applyFiel
     * gthRelatedProperties: function (controlId, $control, fieldInfo) {
      
     *  Reduce bloat
        const TypeEnum = this.OptionalFieldTyp
     * num;

        const controlName = this.getNameFromId(controlId);
        const fieldType = parseInt(fieldInfo.TypeIndex);

        if (this.isNumericField(fieldType)) {

            const $kendoNumericTextBox = $control.data('kendoNumericTextBox');

            var isDecimal = this.isDecimalNumericField(fieldType);
            var decimalVal = isDecimal ? this.getAttributeValueIfDefined($control, 'decimal', fieldInfo.OptionsDecimal) : 0;
            var maxLength = isDecimal ? this.Constants.DefaultNumberLength : this.Constants.DefaultIntegerLength;
            maxLength = maxLength > this.Constants.DefaultNumberMaxLength ? this.Constants.DefaultNumberMaxLength : maxLength;

            if (isDecimal) {
                //
     *                 // Floating point numerics
                //
                if (decimalVal == 0)
     * 
                    maxLength = maxLength
     * ;
                
     * 

                sg.utls.kndoUI.restrictDecimals($kendoNumericTextBox, decimalVal, maxLength - decimalVal);

            } else {
                //
                // Integer numerics
                //
                const de
     * ultLength = (controlName === this.f
     * xtId) ? fieldInfo.MinLength.length : fieldInfo.
     * ength.length;
                sg.utls.kndoUI.restrictDecimals($kendoNumericTextBox, 0, defaultLength);
            }

        } else if (fieldType === TypeEnum.Date) {

            $control.attr("disabled", false);
            $control.show();

        } else if (fieldType
     * == TypeEnum.Time) {

 
     *          t
     * s.setMa
    
     *  ength(
  
     *  * nt
     *
     * , 
  
     *  * is
    
     *  onstants.M
     * meLength);

       
     *  else if (fieldTy
     *  === TypeEnum.Boolean) {
     * 
     *             $control.remove
     * tr("ty
     * ;

    
     *
     *  } else {
  
     *       //
            // Text 
     * x
  
     *       //
     
     *      let defaultLength = fieldInfo.OptionsLength;
            this.setMaxLength(controlId, defaultLength);
        }
    },

    /**
     * @function
     * @name setDefaultValue
     * @description Set default values for a control
     * @namespace ICOptionalFieldsUtils
     * @public
     *

     *    * @param {string} controlId The Control Id string
     * @param {ob
     * ct} fieldInfo The field info object
   
     * *     */
     *   setDefaultValue: f
     * ion (controlId,
     * ldInfo) {
        /
     * duce bloat
        
     * t TypeEnum = this.OptionalFieldTypeEnum;

        const control
  
     *  * me = this.getNameFromId(controlId);
        const
     * ieldType = pa
    
     *  eInt(fieldI
     * o.TypeIndex);

        let
     * control = $
     * ontrolId);

        if (this.isNumericField(fieldType)) {

 
     *          const $kendoContro
     * = $control.data('kendoNumericTextBox
     * ;

 
     *        if (this.isDecim
     * Numeric
     * d(fieldType)) {
                //
              
     * // Floating p
     * nt numerics
     *                 //
        
     *       var d
     * aultLength = this.Constants.DefaultNumberLength;

                defaul
     *
     * th
     *  defaultL
     * gth > 16 ? 16 : default
     * ngth;
                if (fieldInfo.OptionsDecimal == 0
     * {
                    defaultLe
     * th = de
     *
     * ltLength - 1;
                }

              
     * if (controlName == this.fromTxtId) {
                    var minValue = sg.utls.g
     * MinValue("9", fieldInfo.OptionsDecimal, de
     * ultLength, true);
                    $kendoControl.value(minValue);
     * 
                } else {
                    var maxValue = sg.utls.getMaxValue("9", fieldInfo.OptionsDecimal, defaultLength, true);
                    $kendoControl
     * );
                }
     *           } else {
               
     * 
                // Integer numerics
                //
                const value = (controlName === this.fromTxtId) ? fieldInfo.MinLength : fieldInfo.MaxLength;
                $kendoControl.value(value);
            }

            $kendoControl.trigger('change');

        } else if (fiel
     * ype === TypeEnum.Date) {

            const $ke
     * atePicker = $control.data('kendoDatePicker');
            const value = (controlName == this.fromTxtId) ? "" : fieldInfo.MaxLength;
            $kendoDatePicker.value(value);

        } else if (fieldType === TypeEnum.Boolean) {

            const $kendoDropDownList = $control.data('kendoDropDownList');
            const value = (controlName === this.fromDropdownId) ? parseInt(fieldInfo.MinLength) : parseInt(fieldInfo.MaxLength);
            $kendoDropDownList.value(value);

        } else if (fieldType === TypeEnum.Time) {

            const value = (controlName === this.fromTxtId) ? fieldInfo.MinLength : fieldInfo.MaxLength;
            $control.val(value);

        } else {
            //
            // Text field
            //
            let defaultLength = fieldInfo.OptionsLength;
            let defaultChar = field
     * fo.MaxL
     * gth;
            let defaultValue = null;
            if (defaultChar) {
                defaultValue = window.sg.utls.strPad(defaultChar, defaultLength, d
     * 
     * ltChar);
            }
            const
     * 
     * ue = (controlName === t
     * 
     * f
     * mTxtId) ? '' : defaultValue;
            $c
     * trol.val(value);
        }
    },

    /**
   
     * * @funct
     *
     *   
     *  * @name 
     * itChangeEvents
     
     * escription Initialize the control change event
     * @namespace ICOptionalFieldsUtils
     * @public
     *
     * @param {object} $control The jquery wrapped object reference
     * @param {object} fieldInfo The field info object
     */
    initChan
     * ents: function ($control, fieldInfo) {
   
     *    const 
     * Date, Time } = thi
     * 
     * ionalFi
     *
     *    * TypeEnum;
        const fieldType = parseInt(fiel
     * nfo.Type
     * dex);

        if (fieldType === Date) 
     * 
     *      * 
            $control.on('change', function (e) 
     * 
               
     * COptionalFieldsUtils.checkDynamicDateValidation(fieldInf
     *  e.target.id);
            });
     * 
      
     *
     *  else if (fieldType === Time) {

            
     * ontrol.on('change', function (e) {
                // If necessary, replace invalid time with
     * 
     *   
     *  easonabl
     * time
                const time
     * 
     *     * lue
     *  $
     * ntrol.val();
                co
     * t fixed
     *
     * e = sg.utls.checkIfValidTimeFormat(timeValue);
     *             
     *
     * on
     * o
     * 
     * l(fi
     * dTime);
            });

     *
     *   
     *  }
    }
     * 

    /**
     * @functi
     *     *      * @name setContaine
     * lass
     * @description Set the c
     * tainer class based
     *      * field type
   
     * * @nam
     * ce ICOp
     * onalFieldsUtils


     *    * 
     *  
     * @p
     * l
     * 
     *
     * @param 
     * ec
    
     *   $control
     * he jqu
     * control object
 
     *   *
     * pa
     * m {number} f
     * ldType The
     * ield Type enum value
     */
    setContainerClass: function ($contr
     * , fieldType) {
        // Reduce bloat
        const TypeEnum = this.OptionalFieldTypeEnum;

        let containerClassName = this.Constants.ContainerDi
     * lass;
        let $parent = {};

 
     *      switch (fieldTyp
     *  {

    
     *       cas
     * TypeEnum.Text:
            
     *   $parent = $control.parent();
                break;

            case TypeEnum.Da
     * :
            case TypeEnum.Tim
     * 
     
     *
     *    
     * ase TypeEnum.Boolean:
                $parent = $control.parent().parent().parent();
                break;


            case TypeEnum.Number:
            case TypeEnum.Integer:
            case TypeEnum.Currency:
                containerClassName = this.Constants.ContainerDivClassNumeric;
                $parent = $control.parent().parent().parent();
                break;
        }

        $parent.attr('class', containerClassName);
    },

    /**
     * @function
     * @name isNumericField
     * @description Determine if field is
     *
     * ri
     * based on 
     * eld type
     * @namespace
     * COptionalFieldsUtils
 
     *   * @pub
     * c
     *
     * @param {number
     * f
  

     *
     *   *   *  * ldTyp
     * The field type 
     * lue
   
     
     * *
    
     *
     * @returns {boolean} true = Fiel
     * 
     *  a num
     * ic t
     
     * e 
     * false = Fi
     * d is not 
     * numeric t
     * e
    
     *
     * 
    isNumericField: function (fieldType) {
 
     *      const { Currency, Integer
     * 
     * mber } = this.OptionalFie
     * TypeEnum;
        return fieldType === Currency ||
     * ieldType === Integer |
     * fieldT
     * e 
     * = Number;
     *    },

    /**
     * @function
     * 
 
     * 
     *  *
     *  i
     * ecimalNum
     * icField
     * @description Deter
     * ne if 
     * eld is decimal numeric
     * ased on field type
     * @namespace IC
     *     * tionalFieldsUtils
     * @publi
     * 
     *
     *
     *     * @param {number} fieldType The field type 
     * lue
     * 
     * @returns 
     * 
     * lean} true = Field is a decimal numeric type | false = Field is not a decimal numeric type
     */
    isDecimalNumericField: function (fieldType) {
        const { Curre
     *  Number } = this.O
     * ionalFieldTypeEnum;
        return fieldType =
 
     * 
     * *  Currency || fieldTyp

     *    * === Number;
    },
     
     * 
    /*
     * 
     * @function
     * @name dropdownDa
     * 
     * rc
     * romConfig
     * @description 
     * 
     * te 
     * datasource object from the json defined datasource
     *
     * namespace ICOptionalFields
     *      * 
     * s
     * @public
 
     *   *
     * @param {string} controlId The
     * ontrol Id stri
     *      * @returns The datasource object
     */
     *    dro
     * ownDataSou
     * eFromConfig: function (controlId) {
        let controlNam
     * = this.getNameFr
     * Id(controlId);
      
     * l
     * ropdownDataSourceFromConfig 
     * Declara
     * ReportViewModel.Data.Par
     * et
     * find(item => item.ID === con
     * olName)
     * ataSource;
        let dataSource = [];
        for (let inde
     * 0; index < dropdownDataSourceFromC
     * 
     * ig.leng
     *
     *  index++) {
         
     *  let value = dropdownDataSour
     * FromConfig[index].Value;
            let text = dropd
     * 
     * ataSourc
     * r
     * n
     * g[index].La
  
     *  * l
     * xt;
           
     * ataSource.
     * sh({
                
  
     *  lue: v
     * ue,
     
     * 
     *    text: text
 
     *
     *         });
   
     *    }
  
     *     *    
     * eturn dataSource;
     *   
     * 

    /**
  
     *  * @function
    
     *
     *   * @name checkDynamicDateValidation
     * @description Date va
     
     * 
 
     * * ation
     * @namespace ICOptio
     
     * lF
     * sU
     * ls
     * @public

     *    *
 
     *
     *     * * @p
     * am {object} fieldInfo The field in
     * 
     * bject
     * @returns {boolean} TODO - Add
     * escription
     */

     * checkDyn
     * 
     * DateValidation: function (fieldInfo, cont
     * 
     * e) {
        let $control = $(`#${controlName}`);
     *      const fieldType = parseInt(fie
     * In
     * .TypeIndex);

        if (fie
     * Ty
     * == this.
     * onalFieldTypeEnum.Date) 
     * 
     *             var validDate = sg.utls.kndoUI.c
     * ckForValidDateNull($control.val(), false) != null;
            if (!validDate) {
                // TODO - Get localized resource
                //let invalidDate = reportCommonResources.InvalidDate;
                let invalidDate = "Invalid Date";
                let errorMessage = `${fieldInfo.Description} ${invalidDate}`;
                sg.utls.showMessageInfo(sg.utls.msgType.ERROR, errorMessage);
              
     * turn true;
     *             }

     *    *      
     *      else {
       
     *        $(
     *
     *      * es
     * ge").e
     * 

     *      *     *    *
     * ();
    
     *  
     * 
     *      

   
     * *    * tu
     *      * alse;
     
     *    
     * 

     *   
     *   }
    
     *
     * 

    /**
     * @function
     * @name applyControl
     * tribu
     * 
     * @description Apply attribu
  
  
     *  *  *
     * o the referenced control based on field 
     *  
     * eldT

     *   
     *  e)
     * @namespace ICOpt
     * na
     *
     * ds
     * ils
     *
     * blic
     *
  
     *  * @param {object} $c
     * trol The jquery control reference
     * @param {object} fieldInfo The field information object
     */
    applyControlAttributes: function ($control, fieldInfo) {
        // Reduce bloat
        const TypeEnum = th
     * .OptionalFi
     * dTypeEnum;

     *        
     * 
     * st fieldType = parseI
     * (fieldInfo.TypeInde
     * ;

        i
     * (!$($control).is("[type]
     * 
     * {
            $c
     * tr
     *
     * tr
     * type', 'text');
        }

       
     * f (fieldInfo.AlphanumericField) {
            $control.att
     * "formattextbox", "alphaNumeric");
  
     *     }

        if (fieldIn
     * .UpperCaseField) {
  
     *
     *   
     *  $control
     * d
     * lass(th
     *
     *      * Constants.ClassTextUppe
     * 
 
     *   * 
            $con
     * 

     *    * .
     *     *
     * as
     * this.Co
    
     *      * 
     * nts.ClassMedium);
     * 

     * 
     *    } else if (fieldType === TypeEnum.Da
     *  ||


     *           fieldTy
     * == TypeEnum

     *    * oolean)
     *
     *  *
     *      * 
            $control.addClass(this.Constants.C
     * ssDefault);

            if (fieldTy
     *  === TypeEnum.Date) {
    
     
     * 
     *         $control.addClass(this.Consta
     * s.
     * assDatePicker);
                $
     * ntrol.attr("disabled", false);
 
     *       
  
     *   
     * 


     *     
 
     *   * } else if (fieldType === TypeEnum.

     *    * me) {

            $control.attr(
     * 
     * abled", false);
        
     *   
  
     *     *     } else {
         
     *  $cont
     * l.addClass(this.C
     *
 
 
     *   *   * nts.ClassDefault);
     *
     *   
     *  }

   
     *    if (this.isNumericFiel
     * fieldType)) {

            // Parent of parent container [span]
            $control.parent().parent().addClass(this.Constants.ClassNumeric);
 
     *          $control.parent().parent().addClass(this.Constants.ClassDefault);

            // Visible textbox
            $control.prev().addClass(this.Constants.ClassNumeric);
            $control.prev().addClass(thi
     * Constants.ClassDefault);

      
     *     // Hidden textbox
            $contr
     * .addClass(this.Constants.ClassNumeric);
            $control.addClass(this.Constants.ClassDefault);
        }
    },

     *     /**
     * @function
     * @name removeControlAttributes
     * @description Remove all attributes from a con
     * ol 
     *              except ones specified
     * @namespace ICOptionalFieldsUtils

     * 
     *  * @public
     *
     * @param {object} $control The jquery control referenc
     * 
     */
    removeControlAttributes: functio
     * ($control) {
        const keepAttributes = ['id', 'name', 'type'];
        var attributes = $control[0].attributes;
        var count = attributes.length;
        var attributesString = "";
        for (var i = 0; i < count; 
     * +) {
            let attribName = attribut
     * 
     * i].name;
           
     * f (!keepAtt
     * 
     * tes.includes(attribName)) {
               
     * 
     * ributesString = at
     * ibutes
     
     * ring + " " + attribName;
    
     *       }
        
     * 
        $con
     * ol.rem
     * 
     *
     * ttr
     * ttributesString);
    },

     * 
     *  /**
     * @function
     * @name
     * etMaxLength
     * @descript
     * n Sets the max leng
     *  attribute of an 
     * put
     * @name
     * ace ICOption
     * FieldsUtils
    
    
     *  public
     *     *
     * @param
     * string} controlId The Con
  
     *  ol ID string
     * @param {numbe
     *  maxLength The 
     * ximum number of char
     * ters to
     * llow
     */
     *     setMaxLength: fu
     * tion (controlId
     * maxLength) {
   
     *    $(co

     *    * ro
     *
     * at
     *
     *
 
     *   * maxleng
     * ', maxLength);
    },

    /**
     * @function
     * @name removeDropDown
     * 
     * escription Remove a kendoDropDow
     * ist fro
     * 
     * e DOM
     *              Note: this does not ac
     * ally remove the html control
     * 
     *       
     * 
     * 
     *      * t only removes t
     *  K
     * do-related
     * dornments
     * 
     * @namespace ICOptionalFi
     * dsUtils
     * @public
     *
     * @pa
     * m {st
     * ng} controlName The cont
     * l name
     */
    removeDropDown: 
     * nction (controlN
     * e) {
        
     * nst kendoCo
 
     *   *
     *   
     * * l = $

     * 
     *  * #${controlName}`).da
    
     *  ("kendo
     *      * DownList");
      
 
     *   * if (kendoControl !=
     * ull) {
         
   
     * *  const input = ken
     * 

     *    *
     *      * trol.el
     * ent.show();
     *            input.remove
     *   
     *
 
     *   * * ass("k-input");
            input
     * nsertBefore(kendoControl.wrapper);
   
     *      
     * kendoControl.wrapp
     * .remove
     * 
     * 
   
     *        input.removeData("kendoDropDo
     * List");
        }
    },

    /**
     * @
     * 
     * tion
     * @name removeNumeric
  
     *  * @description Remove a kend
     * umericTextBox from the DOM
     *              Note: this does not actually r
     
     * ove the html control
     *    
     *        
     *
     *  only removes the Kendo-related 
     * ornments.
     * @namespace ICOptionalF
     * 
     * sUtils
     * @public
     *
     * @p
     * am {string} controlName The c
     * trol name
     */
    removeNumeric: functio
     * (controlName) {
        let controlId = $(`#${controlName}`);

        // Find the primary textbox by id
        let $contro
     * = 
     * controlId);

     *
     *   
     *  let kend
     * ontrol = $control.d
     * a("kendoNumericTextBox");
        if (kendoControl) {
       
     *    const input = kendoControl.element
     * how();
 
  
     *  * 
     *        input.re
     * veClas
     * 'k-input'
     * 
            input.ins
     * tB
     *
     * (k
     * doControl
     * rapper);
            kendoCont
     * l.wrapper.remove();
            input.remo
     * Data('kendoNumericTextBox');
        }
    },

    /**
     * @function
     * @name getNameFromId
     * @description Trims the starting '#' from an id string
     * @namespace ICOptionalFieldsUtil
     * 
 
     *   * @public
     *
     *   
     * 
     * 
     * aram {string} controlId A
     * ontrol id string
     * @returns {string} The control name (not the id)
     */

     *   getNa
     *
     * romId: function (controlId) {

     *       let name = controlId.trim();
        let hashtagIndex = controlId.indexOf('#');
        if (hashtagIndex > -1 && hashtagIndex === 0) {
            name = controlId.substring('#'.length);
        }
        return name;
    },

    /**
     * @function
     * @name getIdFromName
     * @description Prepends '#' to an id string if not already exists
     * @namespace ICOptionalFieldsUtils
     * @public
     * 
     * @param {string} controlName A control name string
     * @returns {string} The control id (not the name)
     */
    getIdFromName: function (controlName) {
        let id = controlName.trim();
        let hashtagIndex = controlName.indexOf('#');
        if (hashtagIndex < 0) {
            // No hashtag found, prepend one
            id = `#${controlName}`;
        }
        return id;
    },

    /**
     * @function
     * @name getTimeHHMMSSFormat
     * @description Formats time string to HHMMSS
     * @namespace ICOptionalFieldsUtils
     * @public
     *
     * @param {string} val Time string
     * @returns {string} Time string in HHMMSS
     */
    getTimeHHMMSSFormat: function (val) {
        const EMPTY_TIME = '000000';
        if (val !== null) {
            if (val !== "") {
                return $.trim(sg.utls.removeColon(val));
            } else {
                return EMPTY_TIME;
            }
        } else {
            return EMPTY_TIME;
        }
    },

    /**
     * @function
     * @name getFormattedDateOrDefault
     * @description Formats date string to YYYMMDD
     * @namespace ICOptionalFieldsUtils
     * @public
     *
     * @param {string} text Date string
     * @returns {string} Date string in YYYMMDD
     */
    getFormattedDateOrDefault: function (text) {
        var defaultVal = "00000000";
        if (sg.utls.kndoUI.checkForValidDate(text)) {
            text = sg.utls.kndoUI.getDateYYYMMDDFormat(text);
            text = text !== "" ? text : defaultVal;
            return text;
        } else {
            return defaultVal;
        }
    },
}
