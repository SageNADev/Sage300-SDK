﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

"use strict";

function extendViewModel(viewModel) {

    viewModel.OptionalFieldsData = ko.observableArray([]);
}