﻿/* Copyright (c) $year$ $copyright$  All rights reserved. */

namespace $companynamespace$.$applicationid$.Web.Areas.$applicationid$.Constants
{
    /// <summary>
    /// Constants used across $applicationid$ module
    /// </summary>
    public static class Constants
    {
        #region Export/Import
      
        #endregion

		/// <summary>
        /// Module Id
        /// </summary>
        public const string AppId = "$applicationid$";

        #region Grid Preferences
        
        #endregion
        
        #region Cache Key

        #endregion
		
		#region Partial Views
		
		#endregion
    }
}