﻿/* Copyright (c) $year$ $copyright$  All rights reserved. */

using System.Web.Optimization;

namespace $companynamespace$.$applicationid$.Web
{
    /// <summary>
    /// Class for bundle registration
    /// </summary>
    internal static class BundleRegistration
    {
        /// <summary>
        /// Register bundles
        /// </summary>
        /// <param name="bundles"></param> 
        internal static void RegisterBundles(BundleCollection bundles)
        {
            
        }
    }
}
