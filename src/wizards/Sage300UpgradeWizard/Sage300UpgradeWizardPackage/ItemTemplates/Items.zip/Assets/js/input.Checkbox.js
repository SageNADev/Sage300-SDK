$(document).ready(function() {
  $('input[type=radio]').parent().addClass('radio');
  $('input[type=checkbox]').parent().addClass('checkbox');
});