// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
	/// <summary>
	/// Represents Sales per Salesperson KPI data item
	/// </summary>
	public partial class SalesPerSalesperson : ApplicationModelBase
	{
		/// <summary>
        /// Gets or sets SalespersonInitials
		/// </summary>
		public string SalespersonInitials { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName
        /// </summary>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
	    public string SalespersonName { get; set; }

        /// <summary>
        /// Total Sales made by the Salesperson
        /// </summary>
        public decimal Sales { get; set; }
	}
}
