/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
	public partial class VendorGroups : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets GroupCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "GroupCodeRequired", ErrorMessageResourceType = typeof(AnnotationsResx))][StringLength(6, ErrorMessageResourceName = "GroupCodeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string GroupCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "DescriptionMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
 		public string Description {get; set;}
		 
  		/// <summary>
        /// Gets or sets Status 
        /// </summary>
        
 		[ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
 		public Status Status {get; set;}
		 
  		/// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "InactiveDateMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
 		public string InactiveDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "DateLastMaintainedMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
 		public string DateLastMaintained {get; set;}
		 
  		/// <summary>
        /// Gets or sets AccountSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "AccountSetMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string AccountSet {get; set;}
		 
  		/// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "CurrencyCodeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
 		public string CurrencyCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "RateTypeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
 		public string RateType {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "BankCodeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
 		public string BankCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets PrintSeparateChecks 
        /// </summary>
        
 		[ViewField(Name = Fields.PrintSeparateChecks, Id = Index.PrintSeparateChecks, FieldType = EntityFieldType.Int, Size = 2)]
 		public PrintSeparateChecks PrintSeparateChecks {get; set;}
		 
  		/// <summary>
        /// Gets or sets DistributionSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "DistributionSetMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.DistributionSet, Id = Index.DistributionSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string DistributionSet {get; set;}
		 
  		/// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "DistributionCodeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string DistributionCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets GeneralLedgerAccountNo 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "GeneralLedgerAccountNoMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.GeneralLedgerAccountNo, Id = Index.GeneralLedgerAccountNo, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
 		public string GeneralLedgerAccountNo {get; set;}
		 
  		/// <summary>
        /// Gets or sets Terms 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "TermsMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string Terms {get; set;}
		 
		
        //TODO: The naming convention of this property has to be relooked
  
  		/// <summary>
        /// Gets or sets DUPLINVC 
        /// </summary>
        
 		[ViewField(Name = Fields.DUPLINVC, Id = Index.DUPLINVC, FieldType = EntityFieldType.Int, Size = 2)]
 		public int DUPLINVC {get; set;}
		 
  		/// <summary>
        /// Gets or sets DuplicateAmountCode 
        /// </summary>
        
 		[ViewField(Name = Fields.DuplicateAmountCode, Id = Index.DuplicateAmountCode, FieldType = EntityFieldType.Int, Size = 2)]
 		public DuplicateAmountCode DuplicateAmountCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets DuplicateDateCode 
        /// </summary>
        
 		[ViewField(Name = Fields.DuplicateDateCode, Id = Index.DuplicateDateCode, FieldType = EntityFieldType.Int, Size = 2)]
 		public DuplicateAmountCode DuplicateDateCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "TaxGroupMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
 		public string TaxGroup {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
 		public int TaxClass1 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
 		public int TaxClass2 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
 		public int TaxClass3 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
 		public int TaxClass4 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
 		public int TaxClass5 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxReportingType 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxReportingType, Id = Index.TaxReportingType, FieldType = EntityFieldType.Int, Size = 2)]
 		public TaxReportingType TaxReportingType {get; set;}
		 
		
        //TODO: The naming convention of this property has to be relooked
  
  		/// <summary>
        /// Gets or sets SUBJWTHHSW 
        /// </summary>
        
 		[ViewField(Name = Fields.SUBJWTHHSW, Id = Index.SUBJWTHHSW, FieldType = EntityFieldType.Int, Size = 2)]
 		public int SUBJWTHHSW {get; set;}
		 
  		/// <summary>
        /// Gets or sets Num1099OrCPRSCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "Num1099OrCPRSCodeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.Num1099OrCPRSCode, Id = Index.Num1099OrCPRSCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string Num1099OrCPRSCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "PaymentCodeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
 		public string PaymentCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets DistributionType 
        /// </summary>
        
 		[ViewField(Name = Fields.DistributionType, Id = Index.DistributionType, FieldType = EntityFieldType.Int, Size = 2)]
 		public DistributionType DistributionType {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxIncluded1 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
 		public PrintSeparateChecks TaxIncluded1 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxIncluded2 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
 		public PrintSeparateChecks TaxIncluded2 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxIncluded3 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
 		public PrintSeparateChecks TaxIncluded3 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxIncluded4 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
 		public PrintSeparateChecks TaxIncluded4 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxIncluded5 
        /// </summary>
        
 		[ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
 		public PrintSeparateChecks TaxIncluded5 {get; set;}
		 
  		/// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        
 		[ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
 		public long OptionalFields {get; set;}
		 
  		/// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        
 		[ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
 		public ProcessCommandCode ProcessCommandCode {get; set;}
		    }
}
