 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for TaxType 
    /// </summary>
	public enum TaxType 
	{
			/// <summary>
		/// Gets or sets Unknown 
		/// </summary>	
        Unknown = 0,
		/// <summary>
		/// Gets or sets SocialSecurityNumber 
		/// </summary>	
        SocialSecurityNumber = 1,
		/// <summary>
		/// Gets or sets EmployerIDNumber 
		/// </summary>	
        EmployerIDNumber = 2,
		/// <summary>
		/// Gets or sets GSTRegistrationNumber 
		/// </summary>	
        GSTRegistrationNumber = 3,
		/// <summary>
		/// Gets or sets BusinessNumber 
		/// </summary>	
        BusinessNumber = 4,
		/// <summary>
		/// Gets or sets SocialInsuranceNumber 
		/// </summary>	
        SocialInsuranceNumber = 5,
	}
}
