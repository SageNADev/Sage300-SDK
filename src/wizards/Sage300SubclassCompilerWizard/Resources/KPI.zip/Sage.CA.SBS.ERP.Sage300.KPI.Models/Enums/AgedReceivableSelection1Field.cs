
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.KPI.Resources;
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for Selection1Field 
    /// </summary>
    public enum AgedReceivableSelection1Field 
	{
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof(EnumerationsResx))]
        None = 0,

		/// <summary>
		/// Gets or sets CustomerNumber 
		/// </summary>	
        [EnumValue("CustomerNumber", typeof(EnumerationsResx))]
        CustomerNumber = 1,

		/// <summary>
		/// Gets or sets CustomerGroup 
		/// </summary>	
        [EnumValue("CustomerGroup", typeof(EnumerationsResx))]
        CustomerGroup = 2,

		/// <summary>
		/// Gets or sets AccountSet 
		/// </summary>	
        [EnumValue("AccountSet", typeof(EnumerationsResx))]
        AccountSet = 3,

		/// <summary>
		/// Gets or sets Salesperson 
		/// </summary>
        [EnumValue("Salesperson", typeof(EnumerationsResx))]	
        Salesperson = 4,

        /// <summary>
        /// Gets or sets Territory 
        /// </summary>
        [EnumValue("Territory", typeof(EnumerationsResx))]
        Territory = 5,

		/// <summary>
		/// Gets or sets TermsCode 
		/// </summary>	
         [EnumValue("TermsCode", typeof(EnumerationsResx))]		
        TermsCode = 6,

		/// <summary>
		/// Gets or sets NationalAccount 
		/// </summary>	
         [EnumValue("NationalAccount", typeof(EnumerationsResx))]		
        NationalAccount = 7,

		
        // [EnumValue("CurrencyCode", typeof(EnumerationsResx))]			
        //CurrencyCode = 8,
	}
}
