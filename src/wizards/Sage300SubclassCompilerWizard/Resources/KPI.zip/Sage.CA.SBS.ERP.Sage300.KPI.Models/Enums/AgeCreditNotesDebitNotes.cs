 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for AgeCreditNotesDebitNotes 
    /// </summary>
	public enum AgeCreditNotesDebitNotes 
	{
			/// <summary>
		/// Gets or sets AsCurrent 
		/// </summary>	
        AsCurrent = 1,
		/// <summary>
		/// Gets or sets ByDate 
		/// </summary>	
        ByDate = 2,
	}
}
