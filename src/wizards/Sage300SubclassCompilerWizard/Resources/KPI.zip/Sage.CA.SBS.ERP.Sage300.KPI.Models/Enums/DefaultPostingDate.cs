
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for DefaultPostingDate 
    /// </summary>
	public enum DefaultPostingDate 
	{
			/// <summary>
		/// Gets or sets DocumentDate 
		/// </summary>	
        DocumentDate = 0,
		/// <summary>
		/// Gets or sets BatchDate 
		/// </summary>	
        BatchDate = 1,
		/// <summary>
		/// Gets or sets SessionDate 
		/// </summary>	
        SessionDate = 2,
	}
}
