
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for CheckforDuplicateChecks 
    /// </summary>
	public enum CheckforDuplicateChecks 
	{
			/// <summary>
		/// Gets or sets None 
		/// </summary>	
        None = 0,
		/// <summary>
		/// Gets or sets Warning 
		/// </summary>	
        Warning = 1,
		/// <summary>
		/// Gets or sets Error 
		/// </summary>	
        Error = 2,
	}
}
