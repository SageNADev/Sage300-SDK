﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
    /// <summary>
    /// Defines display options for Sales per Salesperson Widget
    /// </summary>
    public enum SalesPerSalespersonInterval
    {
        Week = 0,
        Month = 1,
        Year = 2
    }
}
