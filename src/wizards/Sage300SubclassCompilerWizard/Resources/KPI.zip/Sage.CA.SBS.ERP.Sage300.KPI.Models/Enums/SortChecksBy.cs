
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for SortChecksBy 
    /// </summary>
	public enum SortChecksBy 
	{
			/// <summary>
		/// Gets or sets TransactionEntryNumber 
		/// </summary>	
        TransactionEntryNumber = 0,
		/// <summary>
		/// Gets or sets VendorNumber 
		/// </summary>	
        VendorNumber = 1,
		/// <summary>
		/// Gets or sets PayeeName 
		/// </summary>	
        PayeeName = 2,
		/// <summary>
		/// Gets or sets PayeeCountry 
		/// </summary>	
        PayeeCountry = 3,
		/// <summary>
		/// Gets or sets PayeeZipOrPostalCode 
		/// </summary>	
        PayeeZipOrPostalCode = 4,
	}
}
