 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for CalcBaseforDiscountwithTax 
    /// </summary>
	public enum CalcBaseforDiscountwithTax 
	{
			/// <summary>
		/// Gets or sets Included 
		/// </summary>	
        Included = 1,
		/// <summary>
		/// Gets or sets Excluded 
		/// </summary>	
        Excluded = 2,
	}
}
