
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.KPI.Resources;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for Selection1Field 
    /// </summary>
	public enum Selection1Field 
	{
			/// <summary>
		/// Gets or sets None 
		/// </summary>	
        [EnumValue("None", typeof(EnumerationsResx))]
        None = 0,

		/// <summary>
		/// Gets or sets VendorNumber 
		/// </summary>	
        [EnumValue("VendorNumber", typeof(EnumerationsResx))]
        VendorNumber = 1,

		/// <summary>
		/// Gets or sets VendorGroup 
		/// </summary>	
        [EnumValue("VendorGroup", typeof(EnumerationsResx))]
        VendorGroup = 2,

		/// <summary>
		/// Gets or sets AccountSet 
		/// </summary>	
        [EnumValue("AccountSet", typeof(EnumerationsResx))]
        AccountSet = 3,

		/// <summary>
		/// Gets or sets TermsCode 
		/// </summary>	
        [EnumValue("TermsCode", typeof(EnumerationsResx))]
        TermsCode = 4,

        ///// <summary>
        ///// Gets or sets CurrencyCode 
        ///// </summary>	
        //[EnumValue("CurrencyCode", typeof(EnumerationsResx))]
        //CurrencyCode = 5,
	}
}
