/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

//using Sage.CA.SBS.ERP.Sage300.KPI.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Cutoffby 
    /// </summary>
    public enum Cutoffby
    {
        /// <summary>
        /// Gets or sets Doc Date 
        /// </summary>	
        //[EnumValue("CutoffbyDocDate", typeof(AgedPayablesReportsResx))]
        DocDate = 0,

        /// <summary>
        /// Gets or sets Posting Date 
        /// </summary>	
        //[EnumValue("CutoffbyPostingDate", typeof(AgedPayablesReportsResx))]
        PostingDate = 1,

        /// <summary>
        /// Gets or sets Year Or Period 
        /// </summary>	
        //[EnumValue("CutoffbyYearPeriod", typeof(AgedPayablesReportsResx))]
        YearOrPeriod = 2,
    }
}
