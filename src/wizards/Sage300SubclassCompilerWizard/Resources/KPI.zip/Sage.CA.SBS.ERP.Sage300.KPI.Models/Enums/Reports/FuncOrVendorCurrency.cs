
#region Namespace

//using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;

#endregion 

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums.Reports
{
	/// <summary>
    /// Enum for Func Or Vend or Currency 
    /// </summary>
	public enum FuncOrVendorCurrency 
	{
			/// <summary>
		/// Gets or sets VendorCurrency 
		/// </summary>	
        //[EnumValue("VendorCurrency", typeof(AgeRetainageResx))]
        VendorCurrency = 0,
		/// <summary>
		/// Gets or sets FunctionalCurrency 
		/// </summary>	
        //[EnumValue("FunctionalCurrency", typeof(AgeRetainageResx))]
        FunctionalCurrency = 1,
	}
}
