﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

//using Sage.CA.SBS.ERP.Sage300.KPI.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums.Reports
{

    /// <summary>
    /// Aged Payable Reports Types
    /// </summary>
    public enum AgedPayableReportTypes
    {
        /// <summary>
        /// Gets or sets ATB By Due Date
        /// </summary>	
        //[EnumValue("RptAgedPayablesbyDueDate", typeof(AgedPayablesReportsResx))]
        ATBByDueDate = 1,

        /// <summary>
        /// Gets or sets ATB By Document Date 
        /// </summary>	
        //[EnumValue("RptAgedPayablesbyDocumentDate", typeof(AgedPayablesReportsResx))]
        ATBByDocDate = 2,

        /// <summary>
        /// Gets or sets Overdue By Due Date 
        /// </summary>	
        //[EnumValue("RptOverduePayablesbyDocumentDate", typeof(AgedPayablesReportsResx))]
        ORByDueDate = 3,

        /// <summary>
        ///  Gets or sets Overdue By Document Date 
        /// </summary>
        //[EnumValue("RptOverduePayablesbyDueDate", typeof(AgedPayablesReportsResx))]
        ORByDocDate
        


    }
}
