
#region Namespace

//using Sage.CA.SBS.ERP.Sage300.KPI.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums.Reports
{
    /// <summary>
    /// Enum for DetailOrSummaryReport 
    /// </summary>
    public enum DetailOrSummaryReport
    {
        /// <summary>
        /// Gets or sets Summary 
        /// </summary>       
        //  [EnumValue("Summary", typeof(AgeRetainageDocumentsResx))]
        //[EnumValue("Summary", typeof(AgeRetainageResx))]
        Summary = 0,
        /// <summary>
        /// Gets or sets DetailbyDocument 
        /// </summary>       
        //[EnumValue("DetailbyDocument", typeof(AgeRetainageResx))]
        DetailbyDocument = 1,
        /// <summary>
        /// Gets or sets DetailbyDate 
        /// </summary>       
        //[EnumValue("DetailbyDate", typeof(AgeRetainageResx))]
        DetailbyDate = 2,
        /// <summary>
        /// Gets or sets DetailbyRetainageDueDate 
        /// </summary>       
       //[EnumValue("DetailbyRetainageDueDate", typeof(AgeRetainageResx))]
        DetailbyRetainageDueDate = 3,
    }
}
