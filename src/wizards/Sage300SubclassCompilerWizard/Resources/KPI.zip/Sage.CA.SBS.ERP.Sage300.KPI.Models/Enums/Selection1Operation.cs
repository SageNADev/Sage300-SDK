
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.KPI.Resources;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for Selection1Operation 
    /// </summary>
	public enum Selection1Operation 
	{
			/// <summary>
		/// Gets or sets Between 
		/// </summary>
         [EnumValue("Between", typeof(EnumerationsResx))]	
        Between = 0,

		/// <summary>
		/// Gets or sets Is 
		/// </summary>	
        [EnumValue("Is", typeof(EnumerationsResx))]
        Is = 1,

        ///// <summary>
        ///// Gets or sets GreaterThanorEqual 
        ///// </summary>	
        //GreaterThanorEqual = 2,

        ///// <summary>
        ///// Gets or sets LessThanorEqual 
        ///// </summary>	
        //LessThanorEqual = 3,
	}
}
