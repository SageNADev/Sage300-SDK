
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for IncludePrepayment 
    /// </summary>
	public enum IncludePrepayment 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>	
        No = 0,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
        Yes = 1,
	}
}
