 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for NormalBalanceDROrCR 
    /// </summary>
	public enum NormalBalanceDROrCR 
	{
			/// <summary>
		/// Gets or sets Debit 
		/// </summary>	
        Debit = 1,
		/// <summary>
		/// Gets or sets Credit 
		/// </summary>	
        Credit = 2,
	}
}
