 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for FiscalsetDesignator 
    /// </summary>
	public enum FiscalsetDesignator 
	{
			/// <summary>
		/// Gets or sets Actuals 
		/// </summary>	
        Actuals = 65,
		/// <summary>
		/// Gets or sets Quantity 
		/// </summary>	
        Quantity = 81,
		/// <summary>
		/// Gets or sets Reporting 
		/// </summary>	
        Reporting = 82,
		/// <summary>
		/// Gets or sets ProvisionalActuals 
		/// </summary>	
        ProvisionalActuals = 80,
		/// <summary>
		/// Gets or sets ProvisionalQuantity 
		/// </summary>	
        ProvisionalQuantity = 79,
		/// <summary>
		/// Gets or sets ProvisionalReporting 
		/// </summary>	
        ProvisionalReporting = 84,
		/// <summary>
		/// Gets or sets Budget1 
		/// </summary>	
        Budget1 = 1,
		/// <summary>
		/// Gets or sets Budget2 
		/// </summary>	
        Budget2 = 2,
		/// <summary>
		/// Gets or sets Budget3 
		/// </summary>	
        Budget3 = 3,
		/// <summary>
		/// Gets or sets Budget4 
		/// </summary>	
        Budget4 = 4,
		/// <summary>
		/// Gets or sets Budget5 
		/// </summary>	
        Budget5 = 5,
	}
}
