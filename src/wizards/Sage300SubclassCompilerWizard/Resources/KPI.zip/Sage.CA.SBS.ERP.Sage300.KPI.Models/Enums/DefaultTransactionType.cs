 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for DefaultTransactionType 
    /// </summary>
	public enum DefaultTransactionType 
	{
			/// <summary>
		/// Gets or sets Payment 
		/// </summary>	
        Payment = 1,
		/// <summary>
		/// Gets or sets Prepayment 
		/// </summary>	
        Prepayment = 2,
		/// <summary>
		/// Gets or sets ApplyDocument 
		/// </summary>	
        ApplyDocument = 3,
		/// <summary>
		/// Gets or sets MiscPayment 
		/// </summary>	
        MiscPayment = 4,
	}
}
