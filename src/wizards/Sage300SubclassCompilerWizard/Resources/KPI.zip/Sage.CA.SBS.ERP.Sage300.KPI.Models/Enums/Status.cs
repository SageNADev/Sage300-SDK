 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for Status 
    /// </summary>
	public enum Status 
	{
			/// <summary>
		/// Gets or sets Inactive 
		/// </summary>	
        Inactive = 0,
		/// <summary>
		/// Gets or sets Active 
		/// </summary>	
        Active = 1,
	}
}
