
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for DefaultOrderofOpenDocuments 
    /// </summary>
	public enum DefaultOrderofOpenDocuments 
	{
			/// <summary>
		/// Gets or sets DocumentNumber 
		/// </summary>	
        DocumentNumber = 1,
		/// <summary>
		/// Gets or sets PONumber 
		/// </summary>	
        PONumber = 2,
		/// <summary>
		/// Gets or sets DueDate 
		/// </summary>	
        DueDate = 3,
		/// <summary>
		/// Gets or sets OrderNumber 
		/// </summary>	
        OrderNumber = 4,
		/// <summary>
		/// Gets or sets DocumentDate 
		/// </summary>	
        DocumentDate = 5,
		/// <summary>
		/// Gets or sets CurrentBalance 
		/// </summary>	
        CurrentBalance = 6,
		/// <summary>
		/// Gets or sets OriginalDocNo 
		/// </summary>	
        OriginalDocNo = 7,
	}
}
