﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
    /// <summary>
    /// Enum of InventoryItemPerformanceOrder
    /// </summary>
    public enum InventoryItemPerformanceOrder
    {
        /// <summary>
        /// Descending
        /// </summary>
        Desc,

        /// <summary>
        /// Ascending
        /// </summary>
        Asc
    }
}
