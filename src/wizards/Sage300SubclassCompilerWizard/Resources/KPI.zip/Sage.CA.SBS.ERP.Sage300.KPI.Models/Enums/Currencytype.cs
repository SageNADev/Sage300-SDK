 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for Currencytype 
    /// </summary>
	public enum Currencytype 
	{
			/// <summary>
		/// Gets or sets Source 
		/// </summary>	
        Source = 83,
		/// <summary>
		/// Gets or sets Equivalent 
		/// </summary>	
        Equivalent = 69,
		/// <summary>
		/// Gets or sets Functional 
		/// </summary>	
        Functional = 70,
	}
}
