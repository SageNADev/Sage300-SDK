 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for OnHold 
    /// </summary>
	public enum OnHold 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>	
        No = 0,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
        Yes = 1,
	}
}
