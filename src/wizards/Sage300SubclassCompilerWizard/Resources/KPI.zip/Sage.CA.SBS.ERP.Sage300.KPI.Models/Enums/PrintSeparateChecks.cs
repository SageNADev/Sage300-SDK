 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for PrintSeparateChecks 
    /// </summary>
	public enum PrintSeparateChecks 
	{
			/// <summary>
		/// Gets or sets DoNotPrintSeparateChecks 
		/// </summary>	
        DoNotPrintSeparateChecks = 0,
		/// <summary>
		/// Gets or sets PrintSeparateChecks 
		/// </summary>	
        PrintSeparateChecks = 1,
	}
}
