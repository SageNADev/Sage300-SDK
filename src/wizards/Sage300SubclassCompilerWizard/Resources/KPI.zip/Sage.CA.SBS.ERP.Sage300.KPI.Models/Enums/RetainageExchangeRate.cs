
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for RetainageExchangeRate 
    /// </summary>
	public enum RetainageExchangeRate 
	{
			/// <summary>
		/// Gets or sets UseOriginalDocumentExchangeRate 
		/// </summary>	
        UseOriginalDocumentExchangeRate = 0,
		/// <summary>
		/// Gets or sets UseCurrentExchangeRate 
		/// </summary>	
        UseCurrentExchangeRate = 1,
	}
}
