 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for CheckLanguage 
    /// </summary>
	public enum CheckLanguage 
	{
			/// <summary>
		/// Gets or sets ENG 
		/// </summary>	
        ENG = 1,
		/// <summary>
		/// Gets or sets FRA 
		/// </summary>	
        FRA = 2,
		/// <summary>
		/// Gets or sets ESN 
		/// </summary>	
        ESN = 3,
		/// <summary>
		/// Gets or sets AUS 
		/// </summary>	
        AUS = 4,
		/// <summary>
		/// Gets or sets MEX 
		/// </summary>	
        MEX = 5,
		/// <summary>
		/// Gets or sets CHN 
		/// </summary>	
        CHN = 6,
		/// <summary>
		/// Gets or sets CHT 
		/// </summary>	
        CHT = 7,
	}
}
