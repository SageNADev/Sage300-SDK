 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for Processasytdbalancesswitch 
    /// </summary>
	public enum Processasytdbalancesswitch 
	{
			/// <summary>
		/// Gets or sets Balances 
		/// </summary>	
        Balances = 0,
		/// <summary>
		/// Gets or sets NetChanges 
		/// </summary>	
        NetChanges = 1,
	}
}
