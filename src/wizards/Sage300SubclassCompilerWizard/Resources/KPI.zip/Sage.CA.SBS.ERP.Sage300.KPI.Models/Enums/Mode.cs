 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for Mode 
    /// </summary>
	public enum Mode 
	{
			/// <summary>
		/// Gets or sets NormalMode 
		/// </summary>	
        NormalMode = 0,
		/// <summary>
		/// Gets or sets UnconditionalInsertsOrUpdates 
		/// </summary>	
        UnconditionalInsertsOrUpdates = 1,
	}
}
