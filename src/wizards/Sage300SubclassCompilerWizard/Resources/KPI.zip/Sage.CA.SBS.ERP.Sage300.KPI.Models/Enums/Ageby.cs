 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for Ageby 
    /// </summary>
	public enum Ageby 
	{
			/// <summary>
		/// Gets or sets DueDate 
		/// </summary>	
        DueDate = 0,
		/// <summary>
		/// Gets or sets DocumentDate 
		/// </summary>	
        DocumentDate = 1,
	}
}
