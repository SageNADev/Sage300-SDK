 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for ProcessCommandCode 
    /// </summary>
	public enum ProcessCommandCode 
	{
			/// <summary>
		/// Gets or sets InsertOptionalFields 
		/// </summary>	
        InsertOptionalFields = 0,
	}
}
