﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
    /// <summary>
    /// Enum for Group Category
    /// </summary>
    public enum AccountGroupCategory
    {
        /// <summary>
        /// The cashand cash equivalents
        /// </summary>
        [EnumValue("CashandCashEquivalents", typeof(EnumerationsResx), 1)]
        CashandCashEquivalents = 10,

        /// <summary>
        /// The accounts receivable
        /// </summary>
        [EnumValue("AccountsReceivable", typeof(EnumerationsResx), 2)]
        AccountsReceivable = 20,

        /// <summary>
        /// The inventory
        /// </summary>
        [EnumValue("Inventory", typeof(EnumerationsResx), 3)]
        Inventory = 30,

        /// <summary>
        /// The other current assets
        /// </summary>
        [EnumValue("OtherCurrentAssets", typeof(EnumerationsResx), 4)]
        OtherCurrentAssets = 40,

        /// <summary>
        /// The fixed assets
        /// </summary>
        [EnumValue("FixedAssets", typeof(EnumerationsResx), 5)]
        FixedAssets = 50,

        /// <summary>
        /// The accumulated depreciation
        /// </summary>
        [EnumValue("AccumulatedDepreciation", typeof(EnumerationsResx), 6)]
        AccumulatedDepreciation = 60,

        /// <summary>
        /// The other assets
        /// </summary>
        [EnumValue("OtherAssets", typeof(EnumerationsResx), 7)]
        OtherAssets = 70,

        /// <summary>
        /// The accounts payable
        /// </summary>
        [EnumValue("AccountsPayable", typeof(EnumerationsResx), 8)]
        AccountsPayable = 80,

        /// <summary>
        /// The other current liabilities
        /// </summary>
        [EnumValue("OtherCurrentLiabilities", typeof(EnumerationsResx), 9)]
        OtherCurrentLiabilities = 90,

        /// <summary>
        /// The long term liabilities
        /// </summary>
        [EnumValue("LongTermLiabilities", typeof(EnumerationsResx), 10)]
        LongTermLiabilities = 100,

        /// <summary>
        /// The other liabilities
        /// </summary>
        [EnumValue("OtherLiabilities", typeof(EnumerationsResx), 11)]
        OtherLiabilities = 110,

        /// <summary>
        /// The share capital
        /// </summary>
        [EnumValue("ShareCapital", typeof(EnumerationsResx), 12)]
        ShareCapital = 120,

        /// <summary>
        /// The shareholders equity
        /// </summary>
        [EnumValue("ShareholdersEquity", typeof(EnumerationsResx), 13)]
        ShareholdersEquity = 130,

        /// <summary>
        /// The revenue
        /// </summary>
        [EnumValue("Revenue", typeof(EnumerationsResx), 14)]
        Revenue = 140,

        /// <summary>
        /// The costof sales
        /// </summary>
        [EnumValue("CostofSales", typeof(EnumerationsResx), 15)]
        CostofSales = 150,   

        /// <summary>
        /// The other revenue
        /// </summary>
        [EnumValue("OtherRevenue", typeof(EnumerationsResx), 16)]
        OtherRevenue = 160,

        /// <summary>
        /// The other expenses
        /// </summary>
        [EnumValue("OtherExpenses", typeof(EnumerationsResx), 17)]
        OtherExpenses = 170,

        /// <summary>
        /// The depreciation expense
        /// </summary>
        [EnumValue("DepreciationExpense", typeof(EnumerationsResx), 18)]
        DepreciationExpense = 180,

        /// <summary>
        /// The gains or losses
        /// </summary>
        [EnumValue("GainsOrLosses", typeof(EnumerationsResx), 19)]
        GainsOrLosses = 190,

        /// <summary>
        /// The interest expense
        /// </summary>
        [EnumValue("InterestExpense", typeof(EnumerationsResx), 20)]
        InterestExpense = 200,

        /// <summary>
        /// The income taxes
        /// </summary>
        [EnumValue("IncomeTaxes", typeof(EnumerationsResx), 21)]
        IncomeTaxes = 210
    }
}