
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for IncludePendingTransactions 
    /// </summary>
	public enum IncludePendingTransactions 
	{
			/// <summary>
		/// Gets or sets None 
		/// </summary>	
        None = 0,
		/// <summary>
		/// Gets or sets Payments 
		/// </summary>	
        Payments = 1,
		/// <summary>
		/// Gets or sets PaymentsandAdjustments 
		/// </summary>	
        PaymentsandAdjustments = 2,
		/// <summary>
		/// Gets or sets AllTransactions 
		/// </summary>	
        AllTransactions = 3,
	}
}
