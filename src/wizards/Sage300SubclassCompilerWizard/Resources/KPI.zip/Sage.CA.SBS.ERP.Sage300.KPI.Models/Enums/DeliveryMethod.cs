 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for DeliveryMethod 
    /// </summary>
	public enum DeliveryMethod 
	{
			/// <summary>
		/// Gets or sets Mail 
		/// </summary>	
        Mail = 0,
		/// <summary>
		/// Gets or sets Email 
		/// </summary>	
        Email = 2,
		/// <summary>
		/// Gets or sets ContactsEmail 
		/// </summary>	
        ContactsEmail = 4,
	}
}
