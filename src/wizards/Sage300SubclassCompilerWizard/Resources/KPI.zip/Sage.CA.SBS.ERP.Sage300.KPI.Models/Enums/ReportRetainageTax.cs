
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for ReportRetainageTax 
    /// </summary>
	public enum ReportRetainageTax 
	{
			/// <summary>
		/// Gets or sets AtTimeofOriginalDocument 
		/// </summary>	
        AtTimeofOriginalDocument = 0,
		/// <summary>
		/// Gets or sets AsPerTaxAuthority 
		/// </summary>	
        AsPerTaxAuthority = 1,
	}
}
