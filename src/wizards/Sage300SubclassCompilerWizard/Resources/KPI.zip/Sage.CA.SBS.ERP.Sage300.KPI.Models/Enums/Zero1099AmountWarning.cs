 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for Zero1099AmountWarning 
    /// </summary>
	public enum Zero1099AmountWarning 
	{
			/// <summary>
		/// Gets or sets None 
		/// </summary>	
        None = 0,
		/// <summary>
		/// Gets or sets Warning 
		/// </summary>	
        Warning = 1,
	}
}
