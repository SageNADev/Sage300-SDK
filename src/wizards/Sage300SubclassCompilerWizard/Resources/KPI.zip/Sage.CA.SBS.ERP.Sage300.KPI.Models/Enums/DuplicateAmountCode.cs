 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for DuplicateAmountCode 
    /// </summary>
	public enum DuplicateAmountCode 
	{
			/// <summary>
		/// Gets or sets None 
		/// </summary>	
        None = 0,
		/// <summary>
		/// Gets or sets Warning 
		/// </summary>	
        Warning = 1,
		/// <summary>
		/// Gets or sets Error 
		/// </summary>	
        Error = 2,
	}
}
