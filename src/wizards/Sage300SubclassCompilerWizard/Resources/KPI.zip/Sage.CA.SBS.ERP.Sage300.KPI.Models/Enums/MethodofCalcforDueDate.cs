 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for MethodofCalcforDueDate 
    /// </summary>
	public enum MethodofCalcforDueDate 
	{
			/// <summary>
		/// Gets or sets DaysFromInvoiceDate 
		/// </summary>	
        DaysFromInvoiceDate = 1,
		/// <summary>
		/// Gets or sets EndofNextMonth 
		/// </summary>	
        EndofNextMonth = 2,
		/// <summary>
		/// Gets or sets DayofNextMonth 
		/// </summary>	
        DayofNextMonth = 3,
		/// <summary>
		/// Gets or sets DaysfromDayofNextMonth 
		/// </summary>	
        DaysfromDayofNextMonth = 4,
		/// <summary>
		/// Gets or sets DueDateTable 
		/// </summary>	
        DueDateTable = 5,
	}
}
