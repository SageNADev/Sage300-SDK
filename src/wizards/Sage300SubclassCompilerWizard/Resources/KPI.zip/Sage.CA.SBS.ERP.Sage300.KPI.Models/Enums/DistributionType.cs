 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for DistributionType 
    /// </summary>
	public enum DistributionType 
	{
			/// <summary>
		/// Gets or sets DistributionSet 
		/// </summary>	
        DistributionSet = 0,
		/// <summary>
		/// Gets or sets DistributionCode 
		/// </summary>	
        DistributionCode = 1,
		/// <summary>
		/// Gets or sets GOrLAccount 
		/// </summary>	
        GOrLAccount = 2,
		/// <summary>
		/// Gets or sets None 
		/// </summary>	
        None = 3,
	}
}
