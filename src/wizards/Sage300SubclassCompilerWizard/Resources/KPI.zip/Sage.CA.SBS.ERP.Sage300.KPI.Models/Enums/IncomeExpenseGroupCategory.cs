﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
    /// <summary>
    /// Enum for Group Category
    /// </summary>
    public enum IncomeExpenseGroupCategory
    {
        /// <summary>
        /// The Revenue,Group Category code for income 
        /// </summary>
        [EnumValue("Revenue", typeof(EnumerationsResx))]Revenue = 140,

        /// <summary>
        /// The Opening Inventory,Group Category code for expense 
        /// </summary>
        [EnumValue("OpeningInventory", typeof(EnumerationsResx))]
        OpeningInventory = 16,

        /// <summary>
        /// The Purchases,Group Category code for expense 
        /// </summary>
        [EnumValue("Purchases", typeof(EnumerationsResx))]
        Purchases = 17,

        /// <summary>
        /// The Closing Inventory,Group Category code for expense 
        /// </summary>
        [EnumValue("ClosingInventory", typeof(EnumerationsResx))]
        ClosingInventory = 18,

        /// <summary>
        /// The Cost of Sales,Group Category code for expense 
        /// </summary>
        [EnumValue("CostofSales", typeof(EnumerationsResx))]
        CostofSales = 150,
        
        /// <summary>
        /// The Other Revenue,Group Category code for expense 
        /// </summary>
        [EnumValue("OtherRevenue", typeof(EnumerationsResx))]
        OtherRevenue = 160,

        /// <summary>
        /// The Fixed Charges,Group Category code for expense 
        /// </summary>
        [EnumValue("FixedCharges", typeof(EnumerationsResx))]
        FixedCharges = 21,

        /// <summary>
        /// The Other Expenses,Group Category code for expense 
        /// </summary>
        [EnumValue("OtherExpenses", typeof(EnumerationsResx))]
        OtherExpenses = 170,

        /// <summary>
        /// The Depreciation Expense,Group Category code for expense 
        /// </summary>
        [EnumValue("DepreciationExpense", typeof(EnumerationsResx))]
        DepreciationExpense = 180,

        /// <summary>
        /// The Other,Group Category code for both income and expense 
        /// </summary>
        [EnumValue("Other", typeof(EnumerationsResx))]
        GainsOrLosses = 190,

        /// <summary>
        /// The Interest Expense,Group Category code for expense 
        /// </summary>
        [EnumValue("InterestExpense", typeof(EnumerationsResx))]
        InterestExpense = 200,

        /// <summary>
        /// The Income Taxes,Group Category code for expense 
        /// </summary>
        [EnumValue("IncomeTaxes", typeof(EnumerationsResx))]
        IncomeTaxes = 210,

       

        
    }
}