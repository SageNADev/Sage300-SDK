﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
    /// <summary>
    /// Enum of Income or Expense
    /// </summary>
    public enum IncomeExpense
    {
        /// <summary>
        /// Indicate this is for income
        /// </summary>
        Income,

        /// <summary>
        /// Indicate this is for expense
        /// </summary>
        Expense,

        /// <summary>
        /// Indicate this is for income and expense
        /// </summary>
        IncomeExpense
    }
}
