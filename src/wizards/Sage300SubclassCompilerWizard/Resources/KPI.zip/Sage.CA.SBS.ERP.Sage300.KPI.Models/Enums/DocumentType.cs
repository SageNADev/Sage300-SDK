 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for DocumentType 
    /// </summary>
	public enum DocumentType 
	{
			/// <summary>
		/// Gets or sets Invoice 
		/// </summary>	
        Invoice = 1,
		/// <summary>
		/// Gets or sets DebitNote 
		/// </summary>	
        DebitNote = 2,
		/// <summary>
		/// Gets or sets CreditNote 
		/// </summary>	
        CreditNote = 3,
		/// <summary>
		/// Gets or sets Interest 
		/// </summary>	
        Interest = 4,
		/// <summary>
		/// Gets or sets Prepayment 
		/// </summary>	
        Prepayment = 10,
		/// <summary>
		/// Gets or sets Payment 
		/// </summary>	
        Payment = 11,
	}
}
