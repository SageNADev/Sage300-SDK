
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for AccountsReceivableDocumentType 
    /// </summary>
	public enum AccountsReceivableDocumentType 
	{
			/// <summary>
		/// Gets or sets Invoice 
		/// </summary>	
        Invoice = 1,
		/// <summary>
		/// Gets or sets DebitNote 
		/// </summary>	
        DebitNote = 2,
		/// <summary>
		/// Gets or sets CreditNote 
		/// </summary>	
        CreditNote = 3,
		/// <summary>
		/// Gets or sets Interest 
		/// </summary>	
        Interest = 4,
		/// <summary>
		/// Gets or sets UnappliedCash 
		/// </summary>	
        UnappliedCash = 5,
		/// <summary>
		/// Gets or sets Prepayment 
		/// </summary>	
        Prepayment = 10,
		/// <summary>
		/// Gets or sets Receipt 
		/// </summary>	
        Receipt = 11,
		/// <summary>
		/// Gets or sets Refund 
		/// </summary>	
        Refund = 19,
	}
}
