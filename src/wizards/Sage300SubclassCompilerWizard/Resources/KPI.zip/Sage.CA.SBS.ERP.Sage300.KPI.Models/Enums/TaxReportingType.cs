 
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for TaxReportingType 
    /// </summary>
	public enum TaxReportingType 
	{
			/// <summary>
		/// Gets or sets None 
		/// </summary>	
        None = 0,
		/// <summary>
		/// Gets or sets Num1099 
		/// </summary>	
        Num1099 = 1,
		/// <summary>
		/// Gets or sets CPRS 
		/// </summary>	
        CPRS = 2,
	}
}
