
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums
{
	/// <summary>
    /// Enum for RetainageBase 
    /// </summary>
	public enum RetainageBase 
	{
			/// <summary>
		/// Gets or sets DocumentTotalAfterTaxes 
		/// </summary>	
        DocumentTotalAfterTaxes = 0,
		/// <summary>
		/// Gets or sets DocumentTotalBeforeTaxes 
		/// </summary>	
        DocumentTotalBeforeTaxes = 1,
	}
}
