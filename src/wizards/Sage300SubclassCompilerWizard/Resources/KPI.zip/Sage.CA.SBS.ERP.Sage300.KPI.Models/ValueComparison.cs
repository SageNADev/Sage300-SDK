﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// Model for value comparison
    /// </summary>
    public class ValueComparison : ApplicationModelBase
    {
        /// <summary>
        /// Gets or sets Date formatted as string
        /// </summary>
        public string FormattedDate { get; set; }

        /// <summary>
        /// Gets or sets Value1
        /// </summary>
        public decimal Value1 { get; set; }

        /// <summary>
        /// Gets or sets Value2
        /// </summary>
        public decimal Value2 { get; set; }
    }
}