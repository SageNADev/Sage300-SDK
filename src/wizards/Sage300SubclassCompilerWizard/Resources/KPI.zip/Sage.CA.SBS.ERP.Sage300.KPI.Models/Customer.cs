﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion


namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// Contains list of properties for Customer
    /// </summary>
    public partial class Customer : ApplicationModelBase
    {
        /// <summary>
        /// Gets or sets CustomerName 
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        public decimal Amount { get; set; }
    }
}
