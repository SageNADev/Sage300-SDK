/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
	public partial class NationalAccounts : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets NationalAccountNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "NationalAccountNumberRequired", ErrorMessageResourceType = typeof(AnnotationsResx))][StringLength(12, ErrorMessageResourceName = "NationalAccountNumberMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.NationalAccountNumber, Id = Index.NationalAccountNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
 		public string NationalAccountNumber {get; set;}
		 
  		 
  		/// <summary>
        /// Gets or sets NationalAccountName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "NationalAccountNameMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.NationalAccountName, Id = Index.NationalAccountName, FieldType = EntityFieldType.Char, Size = 60)]
 		public string NationalAccountName {get; set;}
		 
  				    }
}
