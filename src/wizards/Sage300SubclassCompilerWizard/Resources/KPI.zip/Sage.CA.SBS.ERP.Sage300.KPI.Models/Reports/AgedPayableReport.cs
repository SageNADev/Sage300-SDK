﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Reports
{
    /// <summary>
    /// This class is used to generate the report for Aged Payables
    /// </summary>
    public partial class AgedPayableReport : ReportBase
    {

        /// <summary>
        /// get or set AgeSequence
        /// </summary>
        public string AgeSequence { get; set; }

        /// <summary>
        /// get or set TransactionType
        /// </summary>
        public string TransactionType { get; set; }

        /// <summary>
        /// Get or set AgeasofDate
        /// </summary>
        public string AgeAsOfDate { get; set; }

        /// <summary>
        ///  get or set SelectFilter1
        /// </summary>
        public string SelectFilter1 { get; set; }

        /// <summary>
        /// get or set SelectFilter2
        /// </summary>
        public string SelectFilter2 { get; set; }

        /// <summary>
        /// get or set SelectFilter3
        /// </summary>
        public string SelectFilter3 { get; set; }

        /// <summary>
        /// get or set FilterValue1
        /// </summary>
        public string FilterValue1 { get; set; }

        /// <summary>
        /// get or set FilterValue2
        /// </summary>
        public string FilterValue2 { get; set; }

        /// <summary>
        /// get or set FilterValue3
        /// </summary>
        public string FilterValue3 { get; set; }

        /// <summary>
        /// get or set DueDocDate
        /// </summary>
        public string DueDocDate { get; set; }

        /// <summary>
        /// Gets or sets Current 
        /// </summary>
        public decimal Current { get; set; }

        /// <summary>
        /// Gets or sets FirstPeriod 
        /// </summary>
        public decimal FirstPeriod { get; set; }

        /// <summary>
        /// Gets or sets SecondPeriod 
        /// </summary>
        public decimal SecondPeriod { get; set; }

        /// <summary>
        /// Gets or sets ThirdPeriod 
        /// </summary>
        public decimal ThirdPeriod { get; set; }

        /// <summary>
        /// get or set the Amount Type
        /// </summary>
        public string AmountType { get; set; }

        /// <summary>
        /// Gets or Sets The Company Name
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// Gets or Sets CurrentPayables
        /// </summary>
        public string IncludeCurrentPayables { get; set; }

        /// <summary>
        /// Gets or Sets DecimalPlacesFunctional
        /// </summary>
        public string DecimalPlacesFunctional { get; set; }

        /// <summary>
        /// Gets or Sets DecimalPlacesVendor
        /// </summary>
        public string DecimalPlacesVendor { get; set; }

    }
}
