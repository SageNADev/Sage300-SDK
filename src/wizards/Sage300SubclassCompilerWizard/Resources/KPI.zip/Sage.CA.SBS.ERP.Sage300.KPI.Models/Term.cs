/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    public partial class Term : ModelBase
    {

        /// <summary>
        /// Gets or sets TermsCode 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }


    }
}
