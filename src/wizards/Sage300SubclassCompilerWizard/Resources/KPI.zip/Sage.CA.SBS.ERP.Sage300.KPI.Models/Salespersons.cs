/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
	public partial class Salespersons : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets Salesperson 
        /// </summary>
        [Required(ErrorMessageResourceName = "SalespersonRequired", ErrorMessageResourceType = typeof(AnnotationsResx))][StringLength(8, ErrorMessageResourceName = "SalespersonMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.Salesperson, Id = Index.Salesperson, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
 		public string Salesperson {get; set;}
		 
  		
		 
  		/// <summary>
        /// Gets or sets Name 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "NameMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
 		public string Name {get; set;}
		 
  		
		    }
}
