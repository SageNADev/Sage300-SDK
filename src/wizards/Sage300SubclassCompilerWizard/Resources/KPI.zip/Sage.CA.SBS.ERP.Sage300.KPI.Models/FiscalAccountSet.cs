﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.CS.Models;


namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class FiscalAccountSet: FiscalSet
    {
        /// <summary>
        /// 
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets the account group code
        /// </summary>
        public string AccountGroupCode { get; set; }

        /// <summary>
        /// Formatted Amount
        /// </summary>
        public string FormattedAccount { get; set; }

        #region Income And Expense

        /// <summary>
        /// This property will Gets or sets the Current Year Income data and will use to populate in UI
        /// </summary>
        public FiscalSet CurrentYearIncome { get; set; }

        /// <summary>
        /// This property will Gets or sets the Previous Year Income data and will use to populate in UI
        /// </summary>
        public FiscalSet PreviousYearIncome { get; set; }

        /// <summary>
        /// This property will Gets or sets the Current Year Expense data and will use to populate in UI
        /// </summary>
        public FiscalSet CurrentYearExpense { get; set; }

        /// <summary>
        /// This property will Gets or sets the Previous Year Expense data and will use to populate in UI
        /// </summary>
        public FiscalSet PreviousYearExpense { get; set; }


        /// <summary>
        /// This property will hold the number of period
        /// </summary>
        public string Periods { get; set; }

        /// <summary>
        /// Gets or sets Periods
        /// </summary>
        public decimal CurrentIncome { get; set; }

        /// <summary>
        /// Gets or sets PeriodIncome 
        /// </summary>
        public decimal CurrentExpense { get; set; }

        /// <summary>
        /// Gets or sets Periods
        /// </summary>
        public decimal PreviousIncome { get; set; }
        /// <summary>
        /// Gets or sets PreviousExpense 
        /// </summary>
        public decimal PreviousExpense { get; set; }

        /// <summary>
        /// Gets or sets Period01EndDate 
        /// </summary>
        public string Period01EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period02EndDate 
        /// </summary>
        public string Period02EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period03EndDate 
        /// </summary>
        public string Period03EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period04EndDate 
        /// </summary>
        public string Period04EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period05EndDate 
        /// </summary>
        public string Period05EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period06EndDate 
        /// </summary>
        public string Period06EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period07EndDate 
        /// </summary>
        public string Period07EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period08EndDate 
        /// </summary>
        public string Period08EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period09EndDate 
        /// </summary>
        public string Period09EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period10EndDate 
        /// </summary>
        public string Period10EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period11EndDate 
        /// </summary>
        public string Period11EndDate { get; set; }

        /// <summary>
        /// Gets or sets Period12EndDate 
        /// </summary>
        public string Period12EndDate { get; set; }

        #endregion
    }
}
