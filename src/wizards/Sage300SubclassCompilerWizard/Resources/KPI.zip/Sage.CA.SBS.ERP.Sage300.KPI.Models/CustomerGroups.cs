/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    public partial class CustomerGroups : ModelBase
    {

        /// <summary>
        /// Gets or sets GroupCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "GroupCodeRequired", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "GroupCodeMaximumLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "DescriptionMaximumLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

    }
}
