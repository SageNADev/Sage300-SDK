/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    public partial class AgedReceivable : ModelBase
    {
        /// <summary>
        /// Gets or sets Ageby 
        /// </summary>
        [ViewField(Name = Fields.AgeBy, Id = Index.AgeBy, FieldType = EntityFieldType.Int, Size = 2)]
        public Ageby AgeBy { get; set; }

        /// <summary>
        /// Gets or sets AgeasofDate 
        /// </summary>
        [ViewField(Name = Fields.AgeAsOfDate, Id = Index.AgeAsOfDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string AgeAsOfDate { get; set; }

        /// <summary>
        /// Gets or sets Current 
        /// </summary>
        [ViewField(Name = Fields.Current, Id = Index.Current, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal Current { get; set; }

        /// <summary>
        /// Gets or sets FirstPeriod 
        /// </summary>
        [ViewField(Name = Fields.FirstPeriod, Id = Index.FirstPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal FirstPeriod { get; set; }

        /// <summary>
        /// Gets or sets SecondPeriod 
        /// </summary>
        [ViewField(Name = Fields.SecondPeriod, Id = Index.SecondPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal SecondPeriod { get; set; }

        /// <summary>
        /// Gets or sets ThirdPeriod 
        /// </summary>
        [ViewField(Name = Fields.ThirdPeriod, Id = Index.ThirdPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal ThirdPeriod { get; set; }

        /// <summary>
        /// Gets or sets IncludePrepayment 
        /// </summary>
        [ViewField(Name = Fields.IncludePrepayment, Id = Index.IncludePrepayment, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePrepayment IncludePrepayment { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentAllowed
        /// </summary>
        public bool PrepaymentAllowed
        {
            get { return IncludePrepayment == IncludePrepayment.Yes; }
            set { IncludePrepayment = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeInvoice 
        /// </summary>
        [ViewField(Name = Fields.IncludeInvoice, Id = Index.IncludeInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePrepayment IncludeInvoice { get; set; }

        /// <summary>
        /// Gets or sets InvoiceAllowed 
        /// </summary>
        public bool InvoiceAllowed
        {
            get { return IncludeInvoice == IncludePrepayment.Yes; }
            set { IncludeInvoice = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeDebitNote 
        /// </summary>
        [ViewField(Name = Fields.IncludeDebitNote, Id = Index.IncludeDebitNote, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePrepayment IncludeDebitNote { get; set; }

        /// <summary>
        /// Gets or sets DebitNoteAllowed 
        /// </summary>
        public bool DebitNoteAllowed
        {
            get { return IncludeDebitNote == IncludePrepayment.Yes; }
            set { IncludeDebitNote = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeCreditNote 
        /// </summary>
        [ViewField(Name = Fields.IncludeCreditNote, Id = Index.IncludeCreditNote, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePrepayment IncludeCreditNote { get; set; }

        /// <summary>
        /// Gets or sets CreditNoteAllowed 
        /// </summary>
        public bool CreditNoteAllowed
        {
            get { return IncludeCreditNote == IncludePrepayment.Yes; }
            set { IncludeCreditNote = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeInterest 
        /// </summary>
        [ViewField(Name = Fields.IncludeInterest, Id = Index.IncludeInterest, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePrepayment IncludeInterest { get; set; }

        /// <summary>
        /// Gets or sets InterestAllowed 
        /// </summary>
        public bool InterestAllowed
        {
            get { return IncludeInterest == IncludePrepayment.Yes; }
            set { IncludeInterest = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeUnappliedCash 
        /// </summary>
        [ViewField(Name = Fields.IncludeUnappliedCash, Id = Index.IncludeUnappliedCash, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePrepayment IncludeUnappliedCash { get; set; }

        /// <summary>
        /// Gets or sets UnappliedCashAllowed 
        /// </summary>
        public bool UnappliedCashAllowed
        {
            get { return IncludeUnappliedCash == IncludePrepayment.Yes; }
            set { IncludeUnappliedCash = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeReceipt 
        /// </summary>
        [ViewField(Name = Fields.IncludeReceipt, Id = Index.IncludeReceipt, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePrepayment IncludeReceipt { get; set; }

        /// <summary>
        ///  Gets or sets ReceiptAllowed 
        /// </summary>
        public bool ReceiptAllowed
        {
            get { return IncludeReceipt == IncludePrepayment.Yes; }
            set { IncludeReceipt = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets Selection1Field 
        /// </summary>
        [ViewField(Name = Fields.Selection1Field, Id = Index.Selection1Field, FieldType = EntityFieldType.Int, Size = 2)]
        public AgedReceivableSelection1Field Selection1Field { get; set; }

        /// <summary>
        /// Gets or sets Selection1Operation 
        /// </summary>
        [ViewField(Name = Fields.Selection1Operation, Id = Index.Selection1Operation, FieldType = EntityFieldType.Int, Size = 2)]
        public Selection1Operation Selection1Operation { get; set; }

        /// <summary>
        /// Gets or sets Selection1From 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Selection1From, Id = Index.Selection1From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Selection1From { get; set; }

        /// <summary>
        /// Gets or sets Selection1To 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Selection1To, Id = Index.Selection1To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Selection1To { get; set; }

        /// <summary>
        /// Gets or sets Selection2Field 
        /// </summary>
        [ViewField(Name = Fields.Selection2Field, Id = Index.Selection2Field, FieldType = EntityFieldType.Int, Size = 2)]
        public AgedReceivableSelection1Field Selection2Field { get; set; }

        /// <summary>
        /// Gets or sets Selection2Operation 
        /// </summary>
        [ViewField(Name = Fields.Selection2Operation, Id = Index.Selection2Operation, FieldType = EntityFieldType.Int, Size = 2)]
        public Selection1Operation Selection2Operation { get; set; }

        /// <summary>
        /// Gets or sets Selection2From 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Selection2From, Id = Index.Selection2From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Selection2From { get; set; }

        /// <summary>
        /// Gets or sets Selection2To 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Selection2To, Id = Index.Selection2To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Selection2To { get; set; }

        /// <summary>
        /// Gets or sets Selection3Field 
        /// </summary>
        [ViewField(Name = Fields.Selection3Field, Id = Index.Selection3Field, FieldType = EntityFieldType.Int, Size = 2)]
        public AgedReceivableSelection1Field Selection3Field { get; set; }

        /// <summary>
        /// Gets or sets Selection3Operation 
        /// </summary>
        [ViewField(Name = Fields.Selection3Operation, Id = Index.Selection3Operation, FieldType = EntityFieldType.Int, Size = 2)]
        public Selection1Operation Selection3Operation { get; set; }

        /// <summary>
        /// Gets or sets Selection3From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Selection3From, Id = Index.Selection3From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Selection3From { get; set; }

        /// <summary>
        /// Gets or sets Selection3To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Selection3To, Id = Index.Selection3To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Selection3To { get; set; }

        /// <summary>
        /// Gets or sets Selection4Field 
        /// </summary>
        [ViewField(Name = Fields.Selection4Field, Id = Index.Selection4Field, FieldType = EntityFieldType.Int, Size = 2)]
        public AgedReceivableSelection1Field Selection4Field { get; set; }

        /// <summary>
        /// Gets or sets Selection4Operation 
        /// </summary>
        [ViewField(Name = Fields.Selection4Operation, Id = Index.Selection4Operation, FieldType = EntityFieldType.Int, Size = 2)]
        public Selection1Operation Selection4Operation { get; set; }

        /// <summary>
        /// Gets or sets Selection4From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Selection4From, Id = Index.Selection4From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Selection4From { get; set; }

        /// <summary>
        /// Gets or sets Selection4To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Selection4To, Id = Index.Selection4To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Selection4To { get; set; }

        /// <summary>
        /// Gets or sets IncludeCurrentReceivables 
        /// </summary>
        [ViewField(Name = Fields.IncludeCurrentReceivables, Id = Index.IncludeCurrentReceivables, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePrepayment IncludeCurrentReceivables { get; set; }

        /// <summary>
        /// Gets or sets CurrentReceivablesAllowed 
        /// </summary>
        public bool CurrentReceivablesAllowed
        {
            get { return IncludeCurrentReceivables == IncludePrepayment.Yes; }
            set { IncludeCurrentReceivables = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets GenerateDataFiles 
        /// </summary>
        [ViewField(Name = Fields.GenerateDataFiles, Id = Index.GenerateDataFiles, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePrepayment GenerateDataFiles { get; set; }

        /// <summary>
        /// Gets or sets AgeSequence 
        /// </summary>
        [ViewField(Name = Fields.AgeSequence, Id = Index.AgeSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long AgeSequence { get; set; }

        /// <summary>
        /// Gets or sets AmountDue1Functional 
        /// </summary>
        [ViewField(Name = Fields.AmountDue1Functional, Id = Index.AmountDue1Functional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDue1Functional { get; set; }

        /// <summary>
        /// Gets or sets AmountDue2Functional 
        /// </summary>
        [ViewField(Name = Fields.AmountDue2Functional, Id = Index.AmountDue2Functional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDue2Functional { get; set; }

        /// <summary>
        /// Gets or sets AmountDue3Functional 
        /// </summary>
        [ViewField(Name = Fields.AmountDue3Functional, Id = Index.AmountDue3Functional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDue3Functional { get; set; }

        /// <summary>
        /// Gets or sets AmountDue4Functional 
        /// </summary>
        [ViewField(Name = Fields.AmountDue4Functional, Id = Index.AmountDue4Functional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDue4Functional { get; set; }

        /// <summary>
        /// Gets or sets AmountDue5Functional 
        /// </summary>
        [ViewField(Name = Fields.AmountDue5Functional, Id = Index.AmountDue5Functional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDue5Functional { get; set; }

        /// <summary>
        /// Gets or sets AmountDueTotalFunctional 
        /// </summary>
        [ViewField(Name = Fields.AmountDueTotalFunctional, Id = Index.AmountDueTotalFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDueTotalFunctional { get; set; }

        /// <summary>
        /// Gets or sets NoRecordsInTheRange
        /// </summary>
        [ViewField(Name = Fields.NoRecordsInTheRange, Id = Index.NoRecordsInTheRange, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePrepayment NoRecordsInTheRange { get; set; }

        /// <summary>
        /// Gets or sets DecimalPlacesFunctional 
        /// </summary>
        [ViewField(Name = Fields.DecimalPlacesFunctional, Id = Index.DecimalPlacesFunctional, FieldType = EntityFieldType.Int, Size = 2)]
        public int DecimalPlacesFunctional { get; set; }

        /// <summary>
        /// Gets or sets DecimalPlacesCustomer 
        /// </summary>
        [ViewField(Name = Fields.DecimalPlacesCustomer, Id = Index.DecimalPlacesCustomer, FieldType = EntityFieldType.Int, Size = 2)]
        public int DecimalPlacesCustomer { get; set; }

        /// <summary>
        /// Gets or sets WidgetName
        /// </summary>
        public string WidgetName { get; set; }

        /// <summary>
        /// Gets or sets CurrencySymbol
        /// </summary>
        public string CurrencySymbol { get; set; }

        /// <summary>
        /// Gets or sets AmtDue1Functional 
        /// </summary>
        public string AmtDue1Functional { get; set; }

        /// <summary>
        /// Gets or sets AmtDue2Functional 
        /// </summary>
        public string AmtDue2Functional { get; set; }

        /// <summary>
        /// Gets or sets AmtDue3Functional 
        /// </summary>
        public string AmtDue3Functional { get; set; }

        /// <summary>
        /// Gets or sets AmtDue4Functional 
        /// </summary>
        public string AmtDue4Functional { get; set; }

        /// <summary>
        /// Gets or sets AmtDue5Functional 
        /// </summary>
        public string AmtDue5Functional { get; set; }
    }
}
