﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// Income from operations KPI model
    /// </summary>
    public partial class IncomeFromOperation : ApplicationModelBase
    {
        /// <summary>
        /// Period Sales
        /// </summary>
        public decimal PeriodSales { get; set; }

        /// <summary>
        /// Total Sales from the beginning of the Fiscal Year
        /// </summary>
        public decimal TotalSales { get; set; }

        /// <summary>
        /// Period Cost of Sales
        /// </summary>
        public decimal PeriodCostOfSales { get; set; }

        /// <summary>
        /// Cost of Sales from the beginning of the Fiscal Year
        /// </summary>
        public decimal TotalCostOfSales { get; set; }

        /// <summary>
        /// Period Depreciation Expenses
        /// </summary>
        public decimal PeriodDepreciationExpenses { get; set; }

        /// <summary>
        /// Depreciation Expenses from the beginning of the Fiscal Year
        /// </summary>
        public decimal TotalDepreciationExpenses { get; set; }

        /// <summary>
        /// Period Other Expenses
        /// </summary>
        public decimal PeriodOtherExpenses { get; set; }

        /// <summary>
        /// Other expenses from the beginning of the Fiscal Year
        /// </summary>
        public decimal TotalOtherExpenses { get; set; }

        /// <summary>
        /// Period Income from Operations
        /// </summary>
        public decimal PeriodIncomeFromOperation
        {
            get { return PeriodSales - (PeriodCostOfSales + PeriodDepreciationExpenses + PeriodOtherExpenses); }
        }

        /// <summary>
        /// Income from Operations from the beginning of the Fiscal Year
        /// </summary>
        public decimal TotalInomeFromOperation
        {
            get { return TotalSales - (TotalCostOfSales + TotalDepreciationExpenses + TotalOtherExpenses); } 
        }
    }
}