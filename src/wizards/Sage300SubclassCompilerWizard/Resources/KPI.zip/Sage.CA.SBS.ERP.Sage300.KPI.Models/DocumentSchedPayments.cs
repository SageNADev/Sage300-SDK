/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// 
    /// </summary>
    public partial class DocumentSchedPayments : ModelBase
    {

        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "VendorNumberRequired", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "VendorNumberMaximumLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "DocumentNumberRequired", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "DocumentNumberMaximumLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "PaymentNumberRequired", ErrorMessageResourceType = typeof(AnnotationsResx))]
        
        public decimal PaymentNumber { get; set; }

        

        /// <summary>
        /// Gets or sets DiscountDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "DiscountDateMaximumLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets FullyPaid 
        /// </summary>

        public FullyPaid FullyPaid { get; set; }

        
        /// <summary>
        /// Gets or sets RemainingDiscountFunc 
        /// </summary>

        public decimal RemainingDiscountFunc { get; set; }

        
        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>

        public DocumentType DocumentType { get; set; }

            }
}
