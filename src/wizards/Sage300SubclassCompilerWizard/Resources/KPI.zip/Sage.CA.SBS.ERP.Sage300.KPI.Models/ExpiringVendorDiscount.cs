﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// Contains list of properties for ExpiringVendorDiscount
    /// </summary>
    public partial class ExpiringVendorDiscount : ApplicationModelBase
    {
        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        public decimal Amount { get; set; }
    }
}
