﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// Cash Position KPI model
    /// </summary>
    public partial class CashPosition : ApplicationModelBase
    {
        /// <summary>
        /// Total Cash Amount
        /// </summary>
        public decimal TotalCashAmount { get; set; }

        /// <summary>
        /// Total Receivables Amount
        /// </summary>
        public decimal TotalReceivablesAmount { get; set; }

        /// <summary>
        /// Total Cash and Receivables Amount
        /// </summary>
        public decimal TotalCashAndReceivablesAmount
        {
            get { return TotalCashAmount + TotalReceivablesAmount; }
        }

        /// <summary>
        /// Total Liabilities Amount
        /// </summary>
        public decimal TotalLiabilitiesAmount { get; set; }

        /// <summary>
        /// Cash Position Amount
        /// </summary>
        public decimal CashPositionAmount
        {
            get { return TotalCashAndReceivablesAmount - TotalLiabilitiesAmount; }
        }
    }
}
