﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// Represents series data for Inventory Item Performance widget
    /// </summary>
    public partial class InventoryItemPerformance
        : ApplicationModelBase
    {
        /// <summary>
        /// Gets or sets Item Code
        /// </summary>
        public string ItemNo { get; set; }

        /// <summary>
        /// Gets or sets Item Description
        /// </summary>
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets total revenue value
        /// </summary>
        public decimal Revenue { get; set; }

        /// <summary>
        /// Gets or sets total revenue value of all series
        /// </summary>
        public decimal RevenueTotal { get; set; }

        /// <summary>
        /// Gets revenue percentage value for the series
        /// </summary>
        public decimal RevenuePercentage
        {
            get
            {
                if (Revenue == 0)
                    return 0;

                return decimal.Round(Revenue/RevenueTotal*100, 2, MidpointRounding.AwayFromZero);
            }
        }

        /// <summary>
        /// Gets or sets total number of units sold
        /// </summary>
        public int UnitsSold { get; set; }

        /// <summary>
        /// Gets or sets total cost of sales value
        /// </summary>
        public decimal CostOfSales { get; set; }

        /// <summary>
        /// Gets or sets returned amount
        /// </summary>
        public decimal ReturnAmount { get; set; }
    }
}
