/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
	public partial class StatementProcessingOptions : ModelBase
	{
	 
  		
  		/// <summary>
        /// Gets or sets AgingPeriod1 
        /// </summary>
        
 		[ViewField(Name = Fields.AgingPeriod1, Id = Index.AgingPeriod1, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal AgingPeriod1 {get; set;}
		 
  		/// <summary>
        /// Gets or sets AgingPeriod2 
        /// </summary>
        
 		[ViewField(Name = Fields.AgingPeriod2, Id = Index.AgingPeriod2, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal AgingPeriod2 {get; set;}
		 
  		/// <summary>
        /// Gets or sets AgingPeriod3 
        /// </summary>
        
 		[ViewField(Name = Fields.AgingPeriod3, Id = Index.AgingPeriod3, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal AgingPeriod3 {get; set;}
		 
  		
		    }
}
