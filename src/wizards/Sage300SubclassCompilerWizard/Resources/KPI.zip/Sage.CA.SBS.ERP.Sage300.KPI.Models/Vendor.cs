/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion


namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// Contains list of properties for Vendor
    /// </summary>
    public partial class Vendor : ApplicationModelBase
    {
        /// <summary>
        /// Gets or sets VendorName 
        /// </summary>
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        public decimal Amount { get; set; }
    }
}
