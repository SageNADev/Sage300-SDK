/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// List of Constants for Vendor
    /// </summary>
    public partial class Vendor
    {
        /// <summary>
        /// Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for VendorName 
            /// </summary>
            public const int VendorName = 1;
            /// <summary>
            /// Property Indexer for Amount 
            /// </summary>
            public const int Amount = 2;
            #endregion
        }
    }
}
