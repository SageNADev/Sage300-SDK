/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// List of Constants for ExpiringVendorDiscount 
    /// </summary>
    public partial class ExpiringVendorDiscount
	{
	 
		/// <summary>
        /// Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
            /// <summary>
            /// Property Indexer for Amount 
            /// </summary>
            public const int Amount = 1;
        #endregion
	    }

	
	}
}
	