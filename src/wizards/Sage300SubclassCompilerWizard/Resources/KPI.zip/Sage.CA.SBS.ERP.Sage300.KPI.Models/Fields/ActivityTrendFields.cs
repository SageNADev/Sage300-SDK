﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    public partial class ActivityTrend
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "CS0120";

        /// <summary>
        /// Contains list of ActivityTrend Fields Constants
        /// </summary>
        public class Fields
        {
        }


        /// <summary>
        /// Contains list of ActivityTrend Index Constants
        /// </summary>
        public class Index
        {
        }
    }
}
