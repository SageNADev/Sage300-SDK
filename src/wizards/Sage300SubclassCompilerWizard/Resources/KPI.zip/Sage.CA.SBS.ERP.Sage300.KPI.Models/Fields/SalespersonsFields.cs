/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Salespersons Constants 
    /// </summary>
	public partial class Salespersons 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0018";

        /// <summary>
        /// Contains list of Salespersons Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for Salesperson 
        /// </summary>
	    public const string Salesperson  = "CODESLSP";
	        
	            /// <summary>
        /// Property for Name 
        /// </summary>
	    public const string Name  = "NAMEEMPL";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of Salespersons Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for Salesperson 
        /// </summary>
	    public const int Salesperson  = 1;
	             
	             /// <summary>
        /// Property Indexer for Name 
        /// </summary>
	    public const int Name  = 6;
	             
        #endregion
	    }

	
	}
}
	