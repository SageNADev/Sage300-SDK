﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    public partial class InventoryItemPerformance
    {
        /// <summary>
        /// Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// ItemNo field index
            /// </summary>
            public const int ItemNo = 1;

            /// <summary>
            /// ItemDescription field index
            /// </summary>
            public const int ItemDescription = 2;

            /// <summary>
            /// Revenue field index
            /// </summary>
            public const int Revenue = 3;
            
            /// <summary>
            /// CostOfSales field index
            /// </summary>
            public const int CostOfSales = 4;

            /// <summary>
            /// UnitsSold field index
            /// </summary>
            public const int UnitsSold = 5;

            /// <summary>
            /// ReturnAmount field index
            /// </summary>
            public const int ReturnAmount = 8;

            #endregion
        }
    }
}
