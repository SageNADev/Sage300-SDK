﻿namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// 
    /// </summary>
    public partial class AccountBalanceOld
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0001";

        /// <summary>
        /// 
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for UnformattedAccount 
            /// </summary>
            public const string UnformattedAccount = "ACCTID";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "ACCTDESC";

            /// <summary>
            /// Property for NormalBalanceDROrCR 
            /// </summary>
            public const string NormalBalanceDrorCr = "ACCTBAL";

            /// <summary>
            /// Property for AccountNumber 
            /// </summary>
            public const string AccountNumber = "ACCTFMTTD";

            /// <summary>
            /// Property for AccountSegmentCode6 
            /// </summary>
            public const string AccountSegmentCode6 = "ACSEGVAL06";

            /// <summary>
            /// Property for AccountGroupCode 
            /// </summary>
            public const string AccountGroupCode = "ACCTGRPCOD";

            /// <summary>
            /// Property for AccountGroupSortCode 
            /// </summary>
            public const string AccountGroupSortCode = "ACCTGRPSCD";

            #endregion
        }

        /// <summary>
        /// 
        /// </summary>
        public class Index
        {

            #region Field Index
            /// <summary>
            /// Property Indexer for UnformattedAccount 
            /// </summary>
            public const int UnformattedAccount = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;

            /// <summary>
            /// Property Indexer for NormalBalanceDROrCR 
            /// </summary>
            public const int NormalBalanceDrorCr = 5;

            /// <summary>
            /// Property Indexer for AccountNumber 
            /// </summary>
            public const int AccountNumber = 21;

            /// <summary>
            /// Property Indexer for AccountSegmentCode8 
            /// </summary>
            public const int AccountSegmentCode8 = 29;

            /// <summary>
            /// Property Indexer for AccountGroupCode 
            /// </summary>
            public const int AccountGroupCode = 42;

            #endregion
        }
    }
}
