﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    public partial class ActivityTrendSeries
    {
        /// <summary>
        /// Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for Label 
            /// </summary>
            public const int Label = 1;
            /// <summary>
            /// Property Indexer for ValueOfPendingOrders 
            /// </summary>
            public const int ValueOfPendingOrders = 2;
            /// <summary>
            /// Property Indexer for ValueOfLostSales 
            /// </summary>
            public const int ValueOfLostSales = 3;
            /// <summary>
            /// Property Indexer for ValueOfShipments 
            /// </summary>
            public const int ValueOfShipments = 4;
            /// <summary>
            /// Property Indexer for NumOfOrders 
            /// </summary>
            public const int NumOfOrders = 5;
            #endregion
        }
    }
}
