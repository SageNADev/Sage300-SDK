﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// IncomeFromOperations Class.
    /// </summary>
    public partial class IncomeFromOperation
    {
        /// <summary>
        /// Accounts Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index
            /// <summary>
            /// Index of PeriodSalesField
            /// </summary>
            public const int PeriodSalesFieldIndex = 1;

            /// <summary>
            /// Index of TotalSalesField
            /// </summary>
            public const int TotalSalesFieldIndex = 2;

            /// <summary>
            /// Index of PeriodCostOfSalesField
            /// </summary>
            public const int PeriodCostOfSalesFieldIndex = 3;

            /// <summary>
            /// Index of TotalCostOfSalesField
            /// </summary>
            public const int TotalCostOfSalesFieldIndex = 4;

            /// <summary>
            /// Index of PeriodDepreciationExpensesField
            /// </summary>
            public const int PeriodDepreciationExpensesFieldIndex = 5;

            /// <summary>
            /// Index of TotalDepreciationExpensesField
            /// </summary>
            public const int TotalDepreciationExpensesFieldIndex = 6;

            /// <summary>
            /// Index of PeriodOtherExpensesField
            /// </summary>
            public const int PeriodOtherExpensesFieldIndex = 7;

            /// <summary>
            /// Index of TotalOtherExpensesField
            /// </summary>
            public const int TotalOtherExpensesFieldIndex = 8;

            #endregion
        }
    }
}
