﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Cash Position KPI fields
    /// </summary>
    public partial class CashPosition
    {
        /// <summary>
        /// Cash Position KPI field indexes
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// TotalCash field index
            /// </summary>
            public const int TotalCash = 1;

            /// <summary>
            /// TotalReceivables field index
            /// </summary>
            public const int TotalReceivables = 2;

            /// <summary>
            /// TotalLiabilities field index
            /// </summary>
            public const int TotalLiabilities = 3;

            #endregion
        }
    }
}
