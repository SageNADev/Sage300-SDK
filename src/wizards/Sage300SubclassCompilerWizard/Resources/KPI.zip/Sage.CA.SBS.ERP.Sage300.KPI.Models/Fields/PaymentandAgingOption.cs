/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PaymentandAgingOption Constants 
    /// </summary>
    public partial class PaymentandAgingOption
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0003";

        /// <summary>
        /// Contains list of PaymentandAgingOptions Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties

            /// <summary>
            /// Property for AgingPeriod1 
            /// </summary>
            public const string AgingPeriod1 = "AGINPRD1";
            /// <summary>
            /// Property for AgingPeriod2 
            /// </summary>
            public const string AgingPeriod2 = "AGINPRD2";
            /// <summary>
            /// Property for AgingPeriod3 
            /// </summary>
            public const string AgingPeriod3 = "AGINPRD3";


            #endregion
        }


        /// <summary>
        /// Contains list of PaymentandAgingOptions Index Constants
        /// </summary>
        public class Index
        {

            #region Properties

            /// <summary>
            /// Property Indexer for AgingPeriod1 
            /// </summary>
            public const int AgingPeriod1 = 11;
            /// <summary>
            /// Property Indexer for AgingPeriod2 
            /// </summary>
            public const int AgingPeriod2 = 12;
            /// <summary>
            /// Property Indexer for AgingPeriod3 
            /// </summary>
            public const int AgingPeriod3 = 13;


            #endregion
        }


    }
}
