﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

 
// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Reports
{

    /// <summary>
    /// Contains list of Aged Payables Report Constants 
    /// </summary>
    public partial class AgedPayableReport
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "a0ea8318-41e2-49c3-acad-218255e3ad1b";

        /// <summary>
        /// Contains list of Aged Payables Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties


            /// <summary>
            ///  Property for AgeSequence 
            /// </summary>
            public const string AgeSequence = "AGESEQ";

            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for Asofdate 
            /// </summary>
            public const string AgeASsOfDate = "ASOFDATE";

            /// <summary>
            /// Property for SelectFilter1 
            /// </summary>
            public const string SelectFilter1 = "FILTERSEL1";

            /// <summary>
            /// Property for SelectFilter2 
            /// </summary>
            public const string SelectFilter2 = "FILTERSEL2";

            /// <summary>
            /// Property for SelectFilter3 
            /// </summary>
            public const string SelectFilter3 = "FILTERSEL3";

            /// <summary>
            /// Property for FilterValue1 
            /// </summary>
            public const string FilterValue1 = "FILTERVALUE1";

            /// <summary>
            /// Property for FilterValue2 
            /// </summary>
            public const string FilterValue2 = "FILTERVALUE2";

            /// <summary>
            /// Property for FilterValue3 
            /// </summary>
            public const string FilterValue3 = "FILTERVALUE3";

            /// <summary>
            /// Property for DueDocDate 
            /// </summary>
            public const string DueDocDate = "DUEDOCDATE";

            /// <summary>
            /// Property for Current 
            /// </summary>
            public const string Current = "PERIOD1";

            /// <summary>
            /// Property for FirstPeriod 
            /// </summary>
            public const string FirstPeriod = "PERIOD2";

            /// <summary>
            /// Property for SecondPeriod 
            /// </summary>
            public const string SecondPeriod = "PERIOD3";

            /// <summary>
            /// Property for ThirdPeriod 
            /// </summary>
            public const string ThirdPeriod = "PERIOD4";

            /// <summary>
            /// Property for AmountType 
            /// </summary>
            public const string AmountType = "AMTTYPE";

            /// <summary>
            /// Property for CompanyName 
            /// </summary>
            public const string CompanyName = "CMPNAME";

            /// <summary>
            /// Property for IncludeCurrentPayables 
            /// </summary>
            public const string IncludeCurrentPayables = "INCLUDECURRENT";

            /// <summary>
            /// Property for DecimalPlacesFunctional 
            /// </summary>
            public const string DecimalPlacesFunctional = "HDECIMALS";

            /// <summary>
            /// Property for DecimalPlacesVendor 
            /// </summary>
            public const string DecimalPlacesVendor = "TDECIMALS";


            #endregion
        }


        /// <summary>
        /// Contains list of Aged Payables Index Constants
        /// </summary>
        public class Index
        {

            #region Properties


            /// <summary>
            /// Property for AgeSequence 
            /// </summary>
            public const int AgeSequence = 2;
            
            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const int TransactionType = 3;

            /// <summary>
            /// Property for AgeasofDate 
            /// </summary>
            public const int AgeAsOfDate = 4;

            /// <summary>
            /// Property for SelectFilter1 
            /// </summary>
            public const int SelectFilter1 =5;

            /// <summary>
            /// Property for SelectFilter2 
            /// </summary>
            public const int SelectFilter2 = 6;

            /// <summary>
            /// Property for SelectFilter3 
            /// </summary>
            public const int SelectFilter3 = 7;

            /// <summary>
            /// Property for FilterValue1 
            /// </summary>
            public const int FilterValue1 = 8;

            /// <summary>
            /// Property for FilterValue2 
            /// </summary>
            public const int FilterValue2 = 9;

            /// <summary>
            /// Property for FilterValue3 
            /// </summary>
            public const int FilterValue3 = 10;
            
            /// <summary>
            /// Property for DueDocDate 
            /// </summary>
            public const int DueDocDate = 11;

            /// <summary>
            /// Property for Current 
            /// </summary>
            public const int Current = 12;

            /// <summary>
            /// Property for FirstPeriod 
            /// </summary>
            public const int FirstPeriod = 13;

            /// <summary>
            /// Property for SecondPeriod 
            /// </summary>
            public const int SecondPeriod = 14;

            /// <summary>
            /// Property for ThirdPeriod 
            /// </summary>
            public const int ThirdPeriod = 15;

            /// <summary>
            /// Property for AmountType 
            /// </summary>
            public const int AmountType = 16;

            /// <summary>
            /// Property for CompanyName 
            /// </summary>
            public const int CompanyName = 17;

            /// <summary>
            /// Property for IncludeCurrentPayables 
            /// </summary>
            public const int IncludeCurrentPayables = 18;

            /// <summary>
            /// Property for DecimalPlacesFunctional 
            /// </summary>
            public const int DecimalPlacesFunctional = 19;

            /// <summary>
            /// Property for DecimalPlacesVendor 
            /// </summary>
            public const int DecimalPlacesVendor = 20;


            #endregion
        }
    }
}
