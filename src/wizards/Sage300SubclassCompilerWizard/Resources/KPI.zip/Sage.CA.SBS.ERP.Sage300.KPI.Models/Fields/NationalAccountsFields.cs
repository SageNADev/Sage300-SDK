/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of NationalAccounts Constants 
    /// </summary>
	public partial class NationalAccounts 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0028";

        /// <summary>
        /// Contains list of NationalAccounts Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for NationalAccountNumber 
        /// </summary>
	    public const string NationalAccountNumber  = "IDNATACCT";
	            
	            /// <summary>
        /// Property for NationalAccountName 
        /// </summary>
	    public const string NationalAccountName  = "NAMEACCT";
	            
        #endregion
	    }


		/// <summary>
        /// Contains list of NationalAccounts Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for NationalAccountNumber 
        /// </summary>
	    public const int NationalAccountNumber  = 1;
	             /// <summary>
        /// Property Indexer for NationalAccountName 
        /// </summary>
	    public const int NationalAccountName  = 10;

        #endregion
	    }

	
	}
}
	