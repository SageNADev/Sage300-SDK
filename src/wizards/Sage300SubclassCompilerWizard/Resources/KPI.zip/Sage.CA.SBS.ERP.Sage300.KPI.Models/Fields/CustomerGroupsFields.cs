/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CustomerGroups Constants 
    /// </summary>
	public partial class CustomerGroups 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0025";

        /// <summary>
        /// Contains list of CustomerGroups Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for GroupCode 
        /// </summary>
	    public const string GroupCode  = "IDGRP";
	            /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "TEXTDESC";
	    
        #endregion
	    }


		/// <summary>
        /// Contains list of CustomerGroups Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for GroupCode 
        /// </summary>
	    public const int GroupCode  = 1;
	             /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 2;
	     
        #endregion
	    }

	
	}
}
	