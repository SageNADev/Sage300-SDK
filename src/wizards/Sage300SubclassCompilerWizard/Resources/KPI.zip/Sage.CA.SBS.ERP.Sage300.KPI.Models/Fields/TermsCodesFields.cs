/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of TermsCodes Constants 
    /// </summary>
    public partial class TermsCodes
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0016";

        /// <summary>
        /// Contains list of TermsCodes Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for TermsCode 
            /// </summary>
            public const string TermsCode = "CODETERM";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";

            #endregion
        }


        /// <summary>
        /// Contains list of TermsCodes Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for TermsCode 
            /// </summary>
            public const int TermsCode = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            #endregion
        }


    }
}
