/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of StatementProcessingOptions Constants 
    /// </summary>
	public partial class StatementProcessingOptions 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0004";

        /// <summary>
        /// Contains list of StatementProcessingOptions Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	   
	            /// <summary>
        /// Property for AgingPeriod1 
        /// </summary>
	    public const string AgingPeriod1  = "AGINPERD1";
	            /// <summary>
        /// Property for AgingPeriod2 
        /// </summary>
	    public const string AgingPeriod2  = "AGINPERD2";
	            /// <summary>
        /// Property for AgingPeriod3 
        /// </summary>
	    public const string AgingPeriod3  = "AGINPERD3";
	    
        #endregion
	    }


		/// <summary>
        /// Contains list of StatementProcessingOptions Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	    
	             /// <summary>
        /// Property Indexer for AgingPeriod1 
        /// </summary>
	    public const int AgingPeriod1  = 3;
	             /// <summary>
        /// Property Indexer for AgingPeriod2 
        /// </summary>
	    public const int AgingPeriod2  = 4;
	             /// <summary>
        /// Property Indexer for AgingPeriod3 
        /// </summary>
	    public const int AgingPeriod3  = 5;
	     
        #endregion
	    }

	
	}
}
	