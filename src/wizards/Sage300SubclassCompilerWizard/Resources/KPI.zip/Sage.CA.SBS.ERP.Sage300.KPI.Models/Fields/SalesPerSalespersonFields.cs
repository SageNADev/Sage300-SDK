// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
	/// <summary>
	/// Contains list of SalesPerSalesperson Constants
	/// </summary>
	public partial class SalesPerSalesperson
	{
		#region Properties

		/// <summary>
		/// Contains list of SalesPerSalesperson Index Constants
		/// </summary>
		public class Index
		{
			/// <summary>
            /// Property Indexer for SalespersonIndex
			/// </summary>
            public const int SalespersonInitials = 1;

            /// <summary>
            /// Property Indexer for SalespersonName
            /// </summary>
            public const int SalespersonName = 2;

            /// <summary>
            /// Property Indexer for NumOfOrders
			/// </summary>
            public const int Sales = 3;
        }

		#endregion
	}
}
