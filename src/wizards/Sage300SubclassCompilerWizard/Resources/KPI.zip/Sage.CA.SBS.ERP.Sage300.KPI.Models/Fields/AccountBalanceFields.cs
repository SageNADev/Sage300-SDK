﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Account Balance model fields
    /// </summary>
    public partial class AccountBalance
    {
        /// <summary>
        /// Account Balance model field indexes
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// AccountId field index
            /// </summary>
            public const int AccountId = 1;

            /// <summary>
            /// AccountDescription field index
            /// </summary>
            public const int AccountDescription = 2;

            /// <summary>
            /// AccountNumber field index
            /// </summary>
            public const int AccountNumber = 3;

            /// <summary>
            /// Amount field index
            /// </summary>
            public const int Amount = 4;

            #endregion
        }
    }
}
