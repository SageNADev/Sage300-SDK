/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of AgedPayablePorletProcessor Constants 
    /// </summary>
    public partial class AgedPayable
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0137";

        /// <summary>
        /// Contains list of AgedPayablePorletProcessor Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for Ageby 
            /// </summary>
            public const string AgeBy = "AGEINVDTSW";
            /// <summary>
            /// Property for AgeasofDate 
            /// </summary>
            public const string AgeAsOfDate = "RUNDATE";
            /// <summary>
            /// Property for Current 
            /// </summary>
            public const string Current = "AGEPERIOD1";
            /// <summary>
            /// Property for FirstPeriod 
            /// </summary>
            public const string FirstPeriod = "AGEPERIOD2";
            /// <summary>
            /// Property for SecondPeriod 
            /// </summary>
            public const string SecondPeriod = "AGEPERIOD3";
            /// <summary>
            /// Property for ThirdPeriod 
            /// </summary>
            public const string ThirdPeriod = "AGEPERIOD4";
            /// <summary>
            /// Property for IncludePrepayment 
            /// </summary>
            public const string IncludePrepayment = "SWPREPAYMT";
            /// <summary>
            /// Property for IncludeInvoice 
            /// </summary>
            public const string IncludeInvoice = "SWINVOICE";
            /// <summary>
            /// Property for IncludeDebitNote 
            /// </summary>
            public const string IncludeDebitNote = "SWDEBIT";
            /// <summary>
            /// Property for IncludeCreditNote 
            /// </summary>
            public const string IncludeCreditNote = "SWCREDIT";
            /// <summary>
            /// Property for IncludeInterest 
            /// </summary>
            public const string IncludeInterest = "SWINTEREST";
            /// <summary>
            /// Property for IncludePayment 
            /// </summary>
            public const string IncludePayment = "SWPAYMENT";
            /// <summary>
            /// Property for Selection1Field 
            /// </summary>
            public const string Selection1Field = "SELFIELD1";
            /// <summary>
            /// Property for Selection1Operation 
            /// </summary>
            public const string Selection1Operation = "SELOP1";
            /// <summary>
            /// Property for Selection1From 
            /// </summary>
            public const string Selection1From = "SELFROM1";
            /// <summary>
            /// Property for Selection1To 
            /// </summary>
            public const string Selection1To = "SELTO1";
            /// <summary>
            /// Property for Selection2Field 
            /// </summary>
            public const string Selection2Field = "SELFIELD2";
            /// <summary>
            /// Property for Selection2Operation 
            /// </summary>
            public const string Selection2Operation = "SELOP2";
            /// <summary>
            /// Property for Selection2From 
            /// </summary>
            public const string Selection2From = "SELFROM2";
            /// <summary>
            /// Property for Selection2To 
            /// </summary>
            public const string Selection2To = "SELTO2";
            /// <summary>
            /// Property for Selection3Field 
            /// </summary>
            public const string Selection3Field = "SELFIELD3";
            /// <summary>
            /// Property for Selection3Operation 
            /// </summary>
            public const string Selection3Operation = "SELOP3";
            /// <summary>
            /// Property for Selection3From 
            /// </summary>
            public const string Selection3From = "SELFROM3";
            /// <summary>
            /// Property for Selection3To 
            /// </summary>
            public const string Selection3To = "SELTO3";
            /// <summary>
            /// Property for Selection4Field 
            /// </summary>
            public const string Selection4Field = "SELFIELD4";
            /// <summary>
            /// Property for Selection4Operation 
            /// </summary>
            public const string Selection4Operation = "SELOP4";
            /// <summary>
            /// Property for Selection4From 
            /// </summary>
            public const string Selection4From = "SELFROM4";
            /// <summary>
            /// Property for Selection4To 
            /// </summary>
            public const string Selection4To = "SELTO4";
            /// <summary>
            /// Property for IncludeCurrentPayables 
            /// </summary>
            public const string IncludeCurrentPayables = "SWINCLCUR";
            /// <summary>
            /// Property for GenerateDataFiles 
            /// </summary>
            public const string GenerateDataFiles = "SWGENDATA";
            /// <summary>
            /// Property for AgeSequence 
            /// </summary>
            public const string AgeSequence = "AGESEQ";
            /// <summary>
            /// Property for AmountDue1Vendor 
            /// </summary>
            public const string AmountDue1Vendor = "AMTDUE1TC";
            /// <summary>
            /// Property for AmountDue2Vendor 
            /// </summary>
            public const string AmountDue2Vendor = "AMTDUE2TC";
            /// <summary>
            /// Property for AmountDue3Vendor 
            /// </summary>
            public const string AmountDue3Vendor = "AMTDUE3TC";
            /// <summary>
            /// Property for AmountDue4Vendor 
            /// </summary>
            public const string AmountDue4Vendor = "AMTDUE4TC";
            /// <summary>
            /// Property for AmountDue5Vendor 
            /// </summary>
            public const string AmountDue5Vendor = "AMTDUE5TC";
            /// <summary>
            /// Property for AmountDue1Functional 
            /// </summary>
            public const string AmountDue1Functional = "AMTDUE1HC";
            /// <summary>
            /// Property for AmountDue2Functional 
            /// </summary>
            public const string AmountDue2Functional = "AMTDUE2HC";
            /// <summary>
            /// Property for AmountDue3Functional 
            /// </summary>
            public const string AmountDue3Functional = "AMTDUE3HC";
            /// <summary>
            /// Property for AmountDue4Functional 
            /// </summary>
            public const string AmountDue4Functional = "AMTDUE4HC";
            /// <summary>
            /// Property for AmountDue5Functional 
            /// </summary>
            public const string AmountDue5Functional = "AMTDUE5HC";
            /// <summary>
            /// Property for AmountDueTotalVendor 
            /// </summary>
            public const string AmountDueTotalVendor = "AMTTOTTC";
            /// <summary>
            /// Property for AmountDueTotalFunctional 
            /// </summary>
            public const string AmountDueTotalFunctional = "AMTTOTHC";
            /// <summary>
            /// Property for Norecordsintherange? 
            /// </summary>
            public const string NoRecordsInTheRange = "SWNORECORD";
            /// <summary>
            /// Property for DecimalPlacesFunctional 
            /// </summary>
            public const string DecimalPlacesFunctional = "HDECIMALS";
            /// <summary>
            /// Property for DecimalPlacesVendor 
            /// </summary>
            public const string DecimalPlacesVendor = "TDECIMALS";

            #endregion
        }


        /// <summary>
        /// Contains list of AgedPayablePorletProcessor Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for Ageby 
            /// </summary>
            public const int AgeBy = 1;
            /// <summary>
            /// Property Indexer for AgeasofDate 
            /// </summary>
            public const int AgeAsOfDate = 2;
            /// <summary>
            /// Property Indexer for Current 
            /// </summary>
            public const int Current = 3;
            /// <summary>
            /// Property Indexer for FirstPeriod 
            /// </summary>
            public const int FirstPeriod = 4;
            /// <summary>
            /// Property Indexer for SecondPeriod 
            /// </summary>
            public const int SecondPeriod = 5;
            /// <summary>
            /// Property Indexer for ThirdPeriod 
            /// </summary>
            public const int ThirdPeriod = 6;
            /// <summary>
            /// Property Indexer for IncludePrepayment 
            /// </summary>
            public const int IncludePrepayment = 7;
            /// <summary>
            /// Property Indexer for IncludeInvoice 
            /// </summary>
            public const int IncludeInvoice = 8;
            /// <summary>
            /// Property Indexer for IncludeDebitNote 
            /// </summary>
            public const int IncludeDebitNote = 9;
            /// <summary>
            /// Property Indexer for IncludeCreditNote 
            /// </summary>
            public const int IncludeCreditNote = 10;
            /// <summary>
            /// Property Indexer for IncludeInterest 
            /// </summary>
            public const int IncludeInterest = 11;
            /// <summary>
            /// Property Indexer for IncludePayment 
            /// </summary>
            public const int IncludePayment = 12;
            /// <summary>
            /// Property Indexer for Selection1Field 
            /// </summary>
            public const int Selection1Field = 13;
            /// <summary>
            /// Property Indexer for Selection1Operation 
            /// </summary>
            public const int Selection1Operation = 14;
            /// <summary>
            /// Property Indexer for Selection1From 
            /// </summary>
            public const int Selection1From = 15;
            /// <summary>
            /// Property Indexer for Selection1To 
            /// </summary>
            public const int Selection1To = 16;
            /// <summary>
            /// Property Indexer for Selection2Field 
            /// </summary>
            public const int Selection2Field = 17;
            /// <summary>
            /// Property Indexer for Selection2Operation 
            /// </summary>
            public const int Selection2Operation = 18;
            /// <summary>
            /// Property Indexer for Selection2From 
            /// </summary>
            public const int Selection2From = 19;
            /// <summary>
            /// Property Indexer for Selection2To 
            /// </summary>
            public const int Selection2To = 20;
            /// <summary>
            /// Property Indexer for Selection3Field 
            /// </summary>
            public const int Selection3Field = 21;
            /// <summary>
            /// Property Indexer for Selection3Operation 
            /// </summary>
            public const int Selection3Operation = 22;
            /// <summary>
            /// Property Indexer for Selection3From 
            /// </summary>
            public const int Selection3From = 23;
            /// <summary>
            /// Property Indexer for Selection3To 
            /// </summary>
            public const int Selection3To = 24;
            /// <summary>
            /// Property Indexer for Selection4Field 
            /// </summary>
            public const int Selection4Field = 25;
            /// <summary>
            /// Property Indexer for Selection4Operation 
            /// </summary>
            public const int Selection4Operation = 26;
            /// <summary>
            /// Property Indexer for Selection4From 
            /// </summary>
            public const int Selection4From = 27;
            /// <summary>
            /// Property Indexer for Selection4To 
            /// </summary>
            public const int Selection4To = 28;
            /// <summary>
            /// Property Indexer for IncludeCurrentPayables 
            /// </summary>
            public const int IncludeCurrentPayables = 29;
            /// <summary>
            /// Property Indexer for GenerateDataFiles 
            /// </summary>
            public const int GenerateDataFiles = 30;
            /// <summary>
            /// Property Indexer for AgeSequence 
            /// </summary>
            public const int AgeSequence = 31;
            /// <summary>
            /// Property Indexer for AmountDue1Vendor 
            /// </summary>
            public const int AmountDue1Vendor = 32;
            /// <summary>
            /// Property Indexer for AmountDue2Vendor 
            /// </summary>
            public const int AmountDue2Vendor = 33;
            /// <summary>
            /// Property Indexer for AmountDue3Vendor 
            /// </summary>
            public const int AmountDue3Vendor = 34;
            /// <summary>
            /// Property Indexer for AmountDue4Vendor 
            /// </summary>
            public const int AmountDue4Vendor = 35;
            /// <summary>
            /// Property Indexer for AmountDue5Vendor 
            /// </summary>
            public const int AmountDue5Vendor = 36;
            /// <summary>
            /// Property Indexer for AmountDue1Functional 
            /// </summary>
            public const int AmountDue1Functional = 37;
            /// <summary>
            /// Property Indexer for AmountDue2Functional 
            /// </summary>
            public const int AmountDue2Functional = 38;
            /// <summary>
            /// Property Indexer for AmountDue3Functional 
            /// </summary>
            public const int AmountDue3Functional = 39;
            /// <summary>
            /// Property Indexer for AmountDue4Functional 
            /// </summary>
            public const int AmountDue4Functional = 40;
            /// <summary>
            /// Property Indexer for AmountDue5Functional 
            /// </summary>
            public const int AmountDue5Functional = 41;
            /// <summary>
            /// Property Indexer for AmountDueTotalVendor 
            /// </summary>
            public const int AmountDueTotalVendor = 42;
            /// <summary>
            /// Property Indexer for AmountDueTotalFunctional 
            /// </summary>
            public const int AmountDueTotalFunctional = 43;
            /// <summary>
            /// Property Indexer for Norecordsintherange? 
            /// </summary>
            public const int NoRecordsInTheRange = 44;
            /// <summary>
            /// Property Indexer for DecimalPlacesFunctional 
            /// </summary>
            public const int DecimalPlacesFunctional = 45;
            /// <summary>
            /// Property Indexer for DecimalPlacesVendor 
            /// </summary>
            public const int DecimalPlacesVendor = 46;

            #endregion
        }


    }
}
