﻿///* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using Sage.CA.SBS.ERP.Sage300.Common.Models;

//namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
//{
//    /// <summary>
//    /// Activity Trend Widget model
//    /// </summary>
//    public partial class ActivityTrend
//        : ModelBase
//    {
//        /// <summary>
//        /// Gets or sets series data to display on the Graph. 
//        /// </summary>
//        public IEnumerable<ActivityTrendSeries> Series { get; set; }

//        /// <summary>
//        /// Returns the maximum value for the 'Count' axis based on current Series data.
//        /// </summary>
//        public int CountAxisMaximum
//        {
//            get
//            {
//                return Convert.ToInt32(
//                    Series.Max(x => x.NumOfOrders) * 1.05M);
//            }
//        }

//        /// <summary>
//        /// Returns the maximum value for the 'Value' axis based on current Series data.
//        /// </summary>
//        public decimal ValueAxisMaximum
//        {
//            get
//            {
//                return Series.Select(x => 
//                    x.ValueOfLostSales + x.ValueOfPendingOrders + x.ValueOfShipments)
//                    .Max() * 1.05M;
//            }
//        }
//    }
//}
