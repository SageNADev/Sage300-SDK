﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// Account Balance KPI model
    /// </summary>
    public partial class AccountBalance
        : ApplicationModelBase
    {
        /// <summary>
        /// Account Id
        /// </summary>
        public string AccountId { get; set; }

        /// <summary>
        /// Account Description
        /// </summary>
        public string AccountDescription { get; set; }

        /// <summary>
        /// Account balance
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// Account formatted code
        /// </summary>
        public string AccountNumber { get; set; }
    }
}
