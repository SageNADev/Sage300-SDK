﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.Collections.Generic;
using System.Linq;
using Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Preference
{
    /// <summary>
    /// Model for Account Balance Setting
    /// </summary>
    public class AccountBalanceSettings 
        : WidgetConfiguration
    {
        private IList<string> _accountNumbers = new List<string>();

        /// <summary>
        /// Gets or sets the List of formatted account numbers to report on
        /// </summary>
        public IList<string> AccountNumbers
        {
            get { return _accountNumbers; }
            set { _accountNumbers = value; }
        }

        /// <summary>
        /// Gets or Sets FiscalYear
        /// </summary>
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or Sets FiscalPeriod
        /// </summary>
        public int FiscalPeriod { get; set; }
    }
}
