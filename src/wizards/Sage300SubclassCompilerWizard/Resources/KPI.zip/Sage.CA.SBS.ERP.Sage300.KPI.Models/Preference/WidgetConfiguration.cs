﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Preference
{
    /// <summary>
    /// User Widget Preference Class
    /// </summary>
    public class WidgetConfiguration
    {
        /// <summary>
        /// Gets or Sets WidgetName
        /// </summary>
        public string WidgetName { get; set; }

        /// <summary>
        /// Gets or Sets Widget Title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Gets or Sets Fiscal Year for the Widget
        /// </summary>
        public string SelectedFiscalYear { get; set; }

        /// <summary>
        ///  Gets or Sets Fiscal Period for the Widget
        /// </summary>
        public int SelectedFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or Sets the SavePreference Success
        /// </summary>
        public bool SavePreferenceSuccess { get; set; }

        /// <summary>
        /// Gets or sets Number of IsConfiguration
        /// </summary>
        public bool IsConfiguration { get; set; }
    }
}
