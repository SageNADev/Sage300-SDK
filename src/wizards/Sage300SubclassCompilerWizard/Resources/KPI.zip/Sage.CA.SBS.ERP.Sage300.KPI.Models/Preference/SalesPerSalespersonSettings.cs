﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Preference
{
    public class SalesPerSalespersonSettings
        : WidgetConfiguration
    {
        /// <summary>
        /// Gets or sets Display Interval
        /// </summary>
        public SalesPerSalespersonInterval Interval { get; set; }

        /// <summary>
        /// Gets or sets Maximum Number of Salespersons
        /// </summary>
        public int MaxNumberOfSalespersons { get; set; }
    }
}
