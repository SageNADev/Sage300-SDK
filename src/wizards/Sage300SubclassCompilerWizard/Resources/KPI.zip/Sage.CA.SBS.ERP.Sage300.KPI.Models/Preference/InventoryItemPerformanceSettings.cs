﻿using Sage.CA.SBS.ERP.Sage300.Common.Resources.Portal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Preference
{
    public class InventoryItemPerformanceSettings
        : WidgetConfiguration
        
    {
        public InventoryItemPerformanceSettings()
        {
            Title = HomePageResx.InventoryItemPerformance;
        }

        /// <summary>
        /// Gets or Sets Start Fiscal Year for the Widget
        /// </summary>
        public int StartFiscalYear { get; set; }

        /// <summary>
        ///  Gets or Sets Start Fiscal Period for the Widget
        /// </summary>
        public int StartFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or Sets End Fiscal Year for the Widget
        /// </summary>
        public int EndFiscalYear { get; set; }

        /// <summary>
        ///  Gets or Sets End Fiscal Period for the Widget
        /// </summary>
        public int EndFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or Sets Sorting Order
        /// </summary>
        public int SortOrder { get; set; }
    }
}
