﻿namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Preference
{
    /// <summary>
    /// Cash Position settings model
    /// </summary>
    public class CashPositionSettings
        : WidgetConfiguration
    {
        /// <summary>
        /// Fiscal Year
        /// </summary>
        public string FiscalYear { get; set; }

        /// <summary>
        /// Fiscal Period
        /// </summary>
        public int FiscalPeriod { get; set; }
    }
}
