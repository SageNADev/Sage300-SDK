﻿using System;
using Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Preference
{
    /// <summary>
    /// Settings class for Aged Payable and Receivable Widgets
    /// </summary>
    public class AgedWidgetSettings : WidgetConfiguration
    {
        /// <summary>
        /// Gets or sets AgeSequence 
        /// </summary>
        public long AgeSequence { get; set; }

        /// <summary>
        /// Gets or sets AgeasofDate 
        /// </summary>
        public string AgeAsOfDate { get; set; }

        /// <summary>
        /// Gets or sets Ageby 
        /// </summary>
        public Ageby AgeBy { get; set; }

        /// <summary>
        /// Gets or sets Current 
        /// </summary>
        public int Current { get; set; }

        /// <summary>
        /// Gets or sets FirstPeriod 
        /// </summary>
        public int FirstPeriod { get; set; }

        /// <summary>
        /// Gets or sets SecondPeriod 
        /// </summary>
        public int SecondPeriod { get; set; }

        /// <summary>
        /// Gets or sets ThirdPeriod 
        /// </summary>
        public int ThirdPeriod { get; set; }

        /// <summary>
        /// Gets or sets IncludePrepayment 
        /// </summary>
        public IncludePrepayment IncludePrepayment { get; set; }

        /// <summary>
        /// Gets or sets Prepayment
        /// </summary>
        public bool PrepaymentAllowed
        {
            get { return IncludePrepayment == IncludePrepayment.Yes; }
            set { IncludePrepayment = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeInvoice 
        /// </summary>
        public IncludePrepayment IncludeInvoice { get; set; }

        /// <summary>
        ///  Gets or sets InvoiceAllowed 
        /// </summary>
        public bool InvoiceAllowed
        {
            get { return IncludeInvoice == IncludePrepayment.Yes; }
            set { IncludeInvoice = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeDebitNote 
        /// </summary>
        public IncludePrepayment IncludeDebitNote { get; set; }

        /// <summary>
        /// Gets or sets DebitNoteAllowed
        /// </summary>
        public bool DebitNoteAllowed
        {
            get { return IncludeDebitNote == IncludePrepayment.Yes; }
            set { IncludeDebitNote = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeCreditNote 
        /// </summary>
        public IncludePrepayment IncludeCreditNote { get; set; }

        /// <summary>
        /// Gets or sets CreditNoteAllowed
        /// </summary>
        public bool CreditNoteAllowed
        {
            get { return IncludeCreditNote == IncludePrepayment.Yes; }
            set { IncludeCreditNote = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeInterest 
        /// </summary>
        public IncludePrepayment IncludeInterest { get; set; }

        /// <summary>
        /// Gets or sets Interest
        /// </summary>
        public bool InterestAllowed
        {
            get { return IncludeInterest == IncludePrepayment.Yes; }
            set { IncludeInterest = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }


        /// <summary>
        /// Gets or sets IncludeCurrentPayables 
        /// </summary>
        public IncludePrepayment IncludeCurrentPayables { get; set; }

        /// <summary>
        /// Gets or sets CurrentPayables
        /// </summary>
        public bool CurrentPayablesAllowed
        {
            get { return IncludeCurrentPayables == IncludePrepayment.Yes; }
            set { IncludeCurrentPayables = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeCurrentReceivables 
        /// </summary>
        public IncludePrepayment IncludeCurrentReceivables { get; set; }

        /// <summary>
        /// Gets or sets CurrentReceivables 
        /// </summary>
        public bool CurrentReceivablesAllowed
        {
            get { return IncludeCurrentReceivables == IncludePrepayment.Yes; }
            set { IncludeCurrentReceivables = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }


        ///<summary>
        /// Gets or sets IncludeUnappliedCash 
        /// </summary>
        public IncludePrepayment IncludeUnappliedCash { get; set; }

        /// <summary>
        /// Gets or sets UnappliedCash 
        /// </summary>
        public bool UnappliedCashAllowed
        {
            get { return IncludeUnappliedCash == IncludePrepayment.Yes; }
            set { IncludeUnappliedCash = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets IncludeReceipt 
        /// </summary>
        public IncludePrepayment IncludeReceipt { get; set; }

        /// <summary>
        ///  Gets or sets Receipt 
        /// </summary>
        public bool ReceiptAllowed
        {
            get { return IncludeReceipt == IncludePrepayment.Yes; }
            set { IncludeReceipt = value == false ? IncludePrepayment.No : IncludePrepayment.Yes; }
        }

        /// <summary>
        /// Gets or sets Selection1Field 
        /// </summary>

        public Selection1Field Selection1Field { get; set; }

        /// <summary>
        /// Gets or sets Selection1Field 
        /// </summary>

        public AgedReceivableSelection1Field AgedReceivableSelection1Field { get; set; }

        /// <summary>
        /// Gets or sets Selection1Operation 
        /// </summary>

        public Selection1Operation Selection1Operation { get; set; }

        /// <summary>
        /// Gets or sets Selection1From 
        /// </summary>
        public string Selection1From { get; set; }

        /// <summary>
        /// Gets or sets Selection1To 
        /// </summary>
        public string Selection1To { get; set; }
    }
}
