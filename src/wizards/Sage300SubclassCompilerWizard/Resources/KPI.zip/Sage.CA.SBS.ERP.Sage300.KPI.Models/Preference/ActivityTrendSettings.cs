﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Resources.Portal;
using Sage.CA.SBS.ERP.Sage300.KPI.Models.Enums;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models.Preference
{
    /// <summary>
    /// Represents settings data for Activity Trend Widget
    /// </summary>
    public class ActivityTrendSettings : WidgetConfiguration
    {
        /// <summary>
        /// Gets or sets Display Interval
        /// </summary>
        public ActivityTrendInterval Interval { get; set; }

        /// <summary>
        /// Retruns Default widget settings
        /// </summary>
        public static ActivityTrendSettings Default
        {
            get
            {
                return new ActivityTrendSettings
                {
                    Title = HomePageResx.ActivityTrend,
                    Interval = ActivityTrendInterval.Week
                };  
            }
        }
    }
}
