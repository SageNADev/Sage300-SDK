﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.KPI.Models
{
    /// <summary>
    /// Represents series data for a certain period for Activity Trend KPI
    /// </summary>
    public partial class ActivityTrendSeries
        : ApplicationModelBase
    {
        /// <summary>
        /// Period label (will be displayed on X-axis of the graph)
        /// </summary>
        public string Label { get; set; }

        /// <summary>
        /// Number of orders placed
        /// </summary>
        public int NumOfOrders { get; set; }

        /// <summary>
        /// Dollar value of lost sales
        /// </summary>
        public decimal ValueOfLostSales { get; set; }

        /// <summary>
        /// Dollar value of pending orders
        /// </summary>
        public decimal ValueOfPendingOrders { get; set; }

        /// <summary>
        /// Dollar value of shipments
        /// </summary>
        public decimal ValueOfShipments { get; set; }
    }
}
