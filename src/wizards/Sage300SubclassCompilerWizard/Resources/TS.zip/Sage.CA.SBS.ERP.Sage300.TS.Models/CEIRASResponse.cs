﻿/* Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TS.Models
{
    /// <summary>
    /// Response from CE IRAS API endpoints
    /// </summary>
    public class CEIRASResponse
    {
        /// <summary>
        /// Error code
        /// </summary>
        public int Code { get; set; }

        /// <summary>
        /// Error messages
        /// </summary>
        public string Message { get; set; }
    }
}
