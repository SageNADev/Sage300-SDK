/* Copyright (c) 2018-2023 The Sage Group plc or its licensors.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TS.Models
{
    /// <summary>
    /// Contains list of GST F5 Report Constants 
    /// </summary>
    public partial class TsGstF5Report
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ReportGuid = "1ddeb9ad-8246-4f8e-8e4c-915be3879465";

        /// <summary>
        /// Contains list of Singapore GST F5 Report Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Tax Number
            /// </summary>
            public const string TaxNumber = "TAXNUMBER";

            /// <summary>
            /// Property for Legal Name
            /// </summary>
            public const string LegalName = "LEGALNAME";

            /// <summary>
            /// Property for Accpac User Id
            /// </summary>
            public const string AccpacUserId = "ACCPACUSERID";

            /// <summary>
            /// Property for Business Registration Number
            /// </summary>
            public const string BusRegNo = "BUSREGNO";

            /// <summary>
            /// Property for Form Year
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for From Period
            /// </summary>
            public const string FromPeriod = "FROMPERIOD";

            /// <summary>
            /// Property for To Year 
            /// </summary>
            public const string ToYear = "TOYEAR";

            /// <summary>
            /// Property for To Period 
            /// </summary>
            public const string ToPeriod = "TOPERIOD";

            /// <summary>
            /// Property for Box 1 - Value of Standard Rated 
            /// </summary>
            public const string Box1 = "BOX1";

            /// <summary>
            /// Property for Box 2 - Value of Zero-Reated Supp 
            /// </summary>
            public const string Box2 = "BOX2";

            /// <summary>
            /// Property for Box 3 - Value of Exempt Supplies
            /// </summary>
            public const string Box3 = "BOX3";

            /// <summary>
            /// Property for Box 4 - Value of Total of [1][2][3]
            /// </summary>
            public const string Box4 = "BOX4";

            /// <summary>
            /// Property for Box 5 - Value of Total of Taxable Purchas
            /// </summary>
            public const string Box5 = "BOX5";

            /// <summary>
            /// Property for Box 6 - Value of Output Tax Due
            /// </summary>
            public const string Box6 = "BOX6";

            /// <summary>
            /// Property for Box 7 - Value of Input Tax and Refunds CI 
            /// </summary>
            public const string Box7 = "BOX7";

            /// <summary>
            /// Property for Box 8 - Value of Net Payable to IRAS 
            /// </summary>
            public const string Box8 = "BOX8";

            /// <summary>
            /// Property for Box 9 - Value of Goods Imported
            /// </summary>
            public const string Box9 = "BOX9";

            /// <summary>
            /// Property for Box 10 - Value of GST Refunded to Tourist 
            /// </summary>
            public const string Box10 = "BOX10";

            /// <summary>
            /// Property for Box 11 - Value of GST Claim for Bad Debt
            /// </summary>
            public const string Box11 = "BOX11";

            /// <summary>
            /// Property for Box 12 - Value of GST Pre-registration CI
            /// </summary>
            public const string Box12 = "BOX12";

            /// <summary>
            /// Property for Box 13 - Value of Revenue for The Account
            /// </summary>
            public const string Box13 = "BOX13";

            /// <summary>
            /// Property for Box 14 - Imported services and L
            /// </summary>
            public const string Box14 = "BOX14";

            /// <summary>
            /// Property for Box 15 - Supply of remote servic
            /// </summary>
            public const string Box15 = "BOX15";

            /// <summary>
            /// Property for Box 16 - Supply of LVG as a rede
            /// </summary>
            public const string Box16 = "BOX16";

            /// <summary>
            /// Property for Box 17 - Own supply of LVG
            /// </summary>
            public const string Box17 = "BOX17";

            /// <summary>
            /// Property for Box 18 - Net GST per box 8 above
            /// </summary>
            public const string Box18 = "BOX18";

            /// <summary>
            /// Property for Box 19 - Deferred import GST pay
            /// </summary>
            public const string Box19 = "BOX19";

            /// <summary>
            /// Property for Box 20 - Total tax to be paid to
            /// </summary>
            public const string Box20 = "BOX20";

            /// <summary>
            /// Property for Box 21 - Total value of goods im
            /// </summary>
            public const string Box21 = "BOX21";

            /// <summary>
            /// Property for GST Form Type
            /// </summary>
            public const string GSTFormType = "FORMTYPE";

            #endregion
        }
    }
}