/* Copyright (c) 2018-2023 The Sage Group plc or its licensors.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TS.Models
{
    /// <summary>
    /// Contains list of GST F5 Processor Constants 
    /// </summary>
    public partial class TsGstF5
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "TS0250";

        /// <summary>
        /// Contains list of Singapore GST Tax Codes Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Form Year
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for From Period
            /// </summary>
            public const string FromPeriod = "FROMPERIOD";

            /// <summary>
            /// Property for To Year 
            /// </summary>
            public const string ToYear = "TOYEAR";

            /// <summary>
            /// Property for To Period 
            /// </summary>
            public const string ToPeriod = "TOPERIOD";

            /// <summary>
            /// Property for Box 1 - Value of Standard Rated 
            /// </summary>
            public const string Box1 = "BOX__1";

            /// <summary>
            /// Property for Box 2 - Value of Zero-Reated Supp 
            /// </summary>
            public const string Box2 = "BOX__2";

            /// <summary>
            /// Property for Box 3 - Value of Exempt Supplies
            /// </summary>
            public const string Box3 = "BOX__3";

            /// <summary>
            /// Property for Box 4 - Value of Total of [1][2][3]
            /// </summary>
            public const string Box4 = "BOX__4";

            /// <summary>
            /// Property for Box 5 - Value of Total of Taxable Purchas
            /// </summary>
            public const string Box5 = "BOX__5";

            /// <summary>
            /// Property for Box 6 - Value of Output Tax Due
            /// </summary>
            public const string Box6 = "BOX__6";

            /// <summary>
            /// Property for Box 7 - Value of Input Tax and Refunds CI 
            /// </summary>
            public const string Box7 = "BOX__7";

            /// <summary>
            /// Property for Box 8 - Value of Net Payable to IRAS 
            /// </summary>
            public const string Box8 = "BOX__8";

            /// <summary>
            /// Property for Box 9 - Value of Goods Imported
            /// </summary>
            public const string Box9 = "BOX__9";

            /// <summary>
            /// Property for Box 10 - Value of GST Refunded to Tourist 
            /// </summary>
            public const string Box10 = "BOX_10";

            /// <summary>
            /// Property for Box 11 - Value of GST Claim for Bad Debt
            /// </summary>
            public const string Box11 = "BOX_11";

            /// <summary>
            /// Property for Box 12 - Value of GST Pre-registration CI
            /// </summary>
            public const string Box12 = "BOX_12";

            /// <summary>
            /// Property for Box 13 - Value of Revenue for The Account
            /// </summary>
            public const string Box13 = "BOX_13";

            /// <summary>
            /// Property for Input Tax from Transactions
            /// </summary>
            public const string InputTax = "INPUTTAX";

            /// <summary>
            /// Property for Output Tax from Transactions 
            /// </summary>
            public const string OutputTax = "OUTPUTTAX";

            /// <summary>
            /// Property for Tax on Recovered Bad Debt 
            /// </summary>
            public const string RecoverTax = "RECOVERTAX";

            /// <summary>
            /// Property for Box 3 before Exchange Adjustment
            /// </summary>
            public const string Box3Pre = "BOX__3PRE";

            /// <summary>
            /// Property for Realized Exchange Gain/Loss(Fun 
            /// </summary>
            public const string RlGainLoss = "RLGAINLOSS";

            /// <summary>
            /// Property for Customer Accounted Tax
            /// </summary>
            public const string RevCharge = "REVCHARGE";

            /// <summary>
            /// Property for Box 14 - Imported services and L
            /// </summary>
            public const string Box14 = "BOX_14";

            /// <summary>
            /// Property for Box 15 - Supply of remote servic
            /// </summary>
            public const string Box15 = "BOX_15";

            /// <summary>
            /// Property for Box 16 - Supply of LVG as a rede
            /// </summary>
            public const string Box16 = "BOX_16";

            /// <summary>
            /// Property for Box 17 - Own supply of LVG
            /// </summary>
            public const string Box17 = "BOX_17";

            /// <summary>
            /// Property for Box 18 - Net GST per box 8 above
            /// </summary>
            public const string Box18 = "BOX_18";

            /// <summary>
            /// Property for Box 19 - Deferred import GST pay
            /// </summary>
            public const string Box19 = "BOX_19";

            /// <summary>
            /// Property for Box 20 - Total tax to be paid to
            /// </summary>
            public const string Box20 = "BOX_20";

            /// <summary>
            /// Property for Box 21 - Total value of goods im
            /// </summary>
            public const string Box21 = "BOX_21";

            /// <summary>
            /// Property for GST Form Type
            /// </summary>
            public const string GSTFormType = "FORMTYPE";

            /// <summary>
            /// Property for Process Action
            /// </summary>
            public const string ProcessAction = "ACTION";

            /// <summary>
            /// Property for Full Path JSON File Name
            /// </summary>
            public const string FullPathJSONFileName = "JSONFILENA";

            /// <summary>
            /// Property for Declarant Designation
            /// </summary>
            public const string DeclarantDesignation = "TITLE";

            /// <summary>
            /// Property for Contact Person
            /// </summary>
            public const string ContactPerson = "CONTACT";

            /// <summary>
            /// Property for Contact Telephone
            /// </summary>
            public const string ContactTelephone = "PHONE";

            /// <summary>
            /// Property for Contact Email
            /// </summary>
            public const string ContactEmail = "EMAIL";

            /// <summary>
            /// Property for CECredential
            /// </summary>
            public const string CECredential = "CREDENTIAL";

            /// <summary>
            /// Property for IRASURL
            /// </summary>
            public const string IRASURL = "IRASURL";

            /// <summary>
            /// Property for CEJobNumber
            /// </summary>
            public const string CEJobNumber = "CEJOBNUM";

            /// <summary>
            /// Property for IRASConfirmationNumber
            /// </summary>
            public const string IRASConfirmationNumber = "IRASCONNUM";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "STATUS";

            /// <summary>
            /// Property for IsResubmission
            /// </summary>
            public const string IsResubmission = "RESUBMIT";

            /// <summary>
            /// Property for DateSubmitted
            /// </summary>
            public const string DateSubmitted = "DATESUBMIT";

            /// <summary>
            /// Property for TimeSubmitted
            /// </summary>
            public const string TimeSubmitted = "TIMESUBMIT";

            /// <summary>
            /// Property for LastGSTReg
            /// </summary>
            public const string LastGSTReg = "LASTGSTREG";

            /// <summary>
            /// Property for TaxAgentFiling
            /// </summary>
            public const string TaxAgentFiling = "TAXAGENT";

            /// <summary>
            /// Property for Encrypted Customer Account
            /// </summary>
            public const string EncryptedCustomerAccount = "CUSTACCT";

            /// <summary>
            /// Property for FE4Error
            /// </summary>
            public const string FE4Error = "FE4BAD";

            /// <summary>
            /// Property for FE4ErrorMessage
            /// </summary>
            public const string FE4ErrorMessage = "FE4ERRMSG";

            /// <summary>
            /// Property for FE4ReasonToSkip
            /// </summary>
            public const string FE4ReasonToSkip = "FE4REASON";

            /// <summary>
            /// Property for FE4OtherReason
            /// </summary>
            public const string FE4OtherReason = "FE4ORWHAT";

            /// <summary>
            /// Property for FE5Error
            /// </summary>
            public const string FE5Error = "FE5BAD";

            /// <summary>
            /// Property for FE5ErrorMessage
            /// </summary>
            public const string FE5ErrorMessage = "FE5ERRMSG";

            /// <summary>
            /// Property for FE5ReasonToSkip
            /// </summary>
            public const string FE5ReasonToSkip = "FE5REASON";

            /// <summary>
            /// Property for FE5OtherReason
            /// </summary>
            public const string FE5OtherReason = "FE5ORWHAT";

            /// <summary>
            /// Property for FE6Error
            /// </summary>
            public const string FE6Error = "FE6BAD";

            /// <summary>
            /// Property for FE6ErrorMessage
            /// </summary>
            public const string FE6ErrorMessage = "FE6ERRMSG";

            /// <summary>
            /// Property for FE6ReasonToSkip
            /// </summary>
            public const string FE6ReasonToSkip = "FE6REASON";

            /// <summary>
            /// Property for FE6OtherReason
            /// </summary>
            public const string FE6OtherReason = "FE6ORWHAT";

            #endregion
        }

        /// <summary>
        /// Contains list of Singapore GST Tax Codes Index Constants
        /// </summary>
        public class Index
        {
            #region Indexes

            /// <summary>
            /// Index for Form Year
            /// </summary>
            public const int FromYear = 1;

            /// <summary>
            /// Index for From Period
            /// </summary>
            public const int FromPeriod = 2;

            /// <summary>
            /// Index for To Year 
            /// </summary>
            public const int ToYear = 3;

            /// <summary>
            /// Index for To Period 
            /// </summary>
            public const int ToPeriod = 4;

            /// <summary>
            /// Index for Box 1 - Value of Standard Rated 
            /// </summary>
            public const int Box1 = 5;

            /// <summary>
            /// Index for Box 2 - Value of Zero-Reated Supp 
            /// </summary>
            public const int Box2 = 6;

            /// <summary>
            /// Index for Box 3 - Value of Exempt Supplies
            /// </summary>
            public const int Box3 = 7;

            /// <summary>
            /// Index for Box 4 - Value of Total of [1][2][3]
            /// </summary>
            public const int Box4 = 8;

            /// <summary>
            /// Index for Box 5 - Value of Total of Taxable Purchas
            /// </summary>
            public const int Box5 = 9;

            /// <summary>
            /// Index for Box 6 - Value of Output Tax Due
            /// </summary>
            public const int Box6 = 10;

            /// <summary>
            /// Index for Box 7 - Value of Input Tax and Refunds CI 
            /// </summary>
            public const int Box7 = 11;

            /// <summary>
            /// Index for Box 8 - Value of Net Payable to IRAS 
            /// </summary>
            public const int Box8 = 12;

            /// <summary>
            /// Index for Box 9 - Value of Goods Imported
            /// </summary>
            public const int Box9 = 13;

            /// <summary>
            /// Index for Box 10 - Value of GST Refunded to Tourist 
            /// </summary>
            public const int Box10 = 14;

            /// <summary>
            /// Index for Box 11 - Value of GST Claim for Bad Debt
            /// </summary>
            public const int Box11 = 15;

            /// <summary>
            /// Index for Box 12 - Value of GST Pre-registration CI
            /// </summary>
            public const int Box12 = 16;

            /// <summary>
            /// Index for Box 13 - Value of Revenue for The Account
            /// </summary>
            public const int Box13 = 17;

            /// <summary>
            /// Index for Input Tax from Transactions
            /// </summary>
            public const int InputTax = 18;

            /// <summary>
            /// Index for Output Tax from Transactions 
            /// </summary>
            public const int OutputTax = 19;

            /// <summary>
            /// Index for Tax on Recovered Bad Debt 
            /// </summary>
            public const int RecoverTax = 20;

            /// <summary>
            /// Index for Box 3 before Exchange Adjustment 
            /// </summary>
            public const int Box3Pre = 21;

            /// <summary>
            /// Index for Realized Exchange Gain/Loss(Fun 
            /// </summary>
            public const int RlGainLoss = 22;

            /// <summary>
            /// Index for Customer Accounted Tax
            /// </summary>
            public const int RevCharge = 23;

            /// <summary>
            /// Index for Box 14 - Imported services and L
            /// </summary>
            public const int Box14 = 24;

            /// <summary>
            /// Index for Box 15 - Supply of remote servic
            /// </summary>
            public const int Box15 = 25;

            /// <summary>
            /// Index for Box 16 - Supply of LVG as a rede
            /// </summary>
            public const int Box16 = 26;

            /// <summary>
            /// Index for Box 17 - Own supply of LVG
            /// </summary>
            public const int Box17 = 27;

            /// <summary>
            /// Index for Box 18 - Net GST per box 8 above
            /// </summary>
            public const int Box18 = 28;

            /// <summary>
            /// Index for Box 19 - Deferred import GST pay
            /// </summary>
            public const int Box19 = 29;

            /// <summary>
            /// Index for Box 20 - Total tax to be paid to
            /// </summary>
            public const int Box20 = 30;

            /// <summary>
            /// Index for Box 21 - Total value of goods im
            /// </summary>
            public const int Box21 = 31;

            /// <summary>
            /// Index for GST Form Type
            /// </summary>
            public const int GSTFormType = 32;

            /// <summary>
            /// Index for Process Action
            /// </summary>
            public const int ProcessAction = 33;

            /// <summary>
            /// Index for Full Path JSON File Name
            /// </summary>
            public const int FullPathJSONFileName = 34;

            /// <summary>
            /// Index for Declarant Designation
            /// </summary>
            public const int DeclarantDesignation = 35;

            /// <summary>
            /// Index for Contact Person
            /// </summary>
            public const int ContactPerson = 36;

            /// <summary>
            /// Index for Contact Telephone
            /// </summary>
            public const int ContactTelephone = 37;

            /// <summary>
            /// Index for Contact Email
            /// </summary>
            public const int ContactEmail = 38;

            /// <summary>
            /// Index for CECredential
            /// </summary>
            public const int CECredential = 39;

            /// <summary>
            /// Index for IRASURL
            /// </summary>
            public const int IRASURL = 40;

            /// <summary>
            /// Index for CEJobNumber
            /// </summary>
            public const int CEJobNumber = 41;

            /// <summary>
            /// Index for IRASConfirmationNumber
            /// </summary>
            public const int IRASConfirmationNumber = 42;

            /// <summary>
            /// Index for Status
            /// </summary>
            public const int Status = 43;

            /// <summary>
            /// Index for IsResubmission
            /// </summary>
            public const int IsResubmission = 44;

            /// <summary>
            /// Index for DateSubmitted
            /// </summary>
            public const int DateSubmitted = 45;

            /// <summary>
            /// Index for TimeSubmitted
            /// </summary>
            public const int TimeSubmitted = 46;

            /// <summary>
            /// Index for LastGSTReg
            /// </summary>
            public const int LastGSTReg = 47;

            /// <summary>
            /// Index for TaxAgentFiling
            /// </summary>
            public const int TaxAgentFiling = 48;

            /// <summary>
            /// Index for Encrypted Customer Account
            /// </summary>
            public const int EncryptedCustomerAccount = 49;

            /// <summary>
            /// Property Indexer for FE4Error
            /// </summary>
            public const int FE4Error = 50;

            /// <summary>
            /// Property Indexer for FE4ErrorMessage
            /// </summary>
            public const int FE4ErrorMessage = 51;

            /// <summary>
            /// Property Indexer for FE4ReasonToSkip
            /// </summary>
            public const int FE4ReasonToSkip = 52;

            /// <summary>
            /// Property Indexer for FE4OtherReason
            /// </summary>
            public const int FE4OtherReason = 53;

            /// <summary>
            /// Property Indexer for FE5Error
            /// </summary>
            public const int FE5Error = 54;

            /// <summary>
            /// Property Indexer for FE5ErrorMessage
            /// </summary>
            public const int FE5ErrorMessage = 55;

            /// <summary>
            /// Property Indexer for FE5ReasonToSkip
            /// </summary>
            public const int FE5ReasonToSkip = 56;

            /// <summary>
            /// Property Indexer for FE5OtherReason
            /// </summary>
            public const int FE5OtherReason = 57;

            /// <summary>
            /// Property Indexer for FE6Error
            /// </summary>
            public const int FE6Error = 58;

            /// <summary>
            /// Property Indexer for FE6ErrorMessage
            /// </summary>
            public const int FE6ErrorMessage = 59;

            /// <summary>
            /// Property Indexer for FE6ReasonToSkip
            /// </summary>
            public const int FE6ReasonToSkip = 60;

            /// <summary>
            /// Property Indexer for FE6OtherReason
            /// </summary>
            public const int FE6OtherReason = 61;

            #endregion
        }
    }
}