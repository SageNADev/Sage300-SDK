/* Copyright (c) 2018-2023 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TS.Models
{
    /// <summary>
    /// Contains list of Singapore GST Tax Rate Codes Constants 
    /// </summary>
    public partial class TsRCode
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "TS0400";

        /// <summary>
        /// Contains list of Tax Rate Codes Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Effective Date 
            /// </summary>
            public const string EffDate = "EFFDATE";

            /// <summary>
            /// Property for Tax Authority 
            /// </summary>
            public const string Authority = "AUTHORITY";

            /// <summary>
            /// Property for Transaction Type 
            /// </summary>
            public const string TType = "TTYPE";

            /// <summary>
            /// Property for Buyer Class
            /// </summary>
            public const string BuyerClass = "BUYERCLASS";

            /// <summary>
            /// Property for Item Class 
            /// </summary>
            public const string ItemClass = "ITEMCLASS";

            /// <summary>
            /// Property for Tax Rate Code 
            /// </summary>
            public const string TaxRCode = "TAXRCODE";

            /// <summary>
            /// Property for Filter Delete Filter
            /// </summary>
            public const string DeleteFilter = "FILTER";

            /// <summary>
            /// Property for Perform Filter Delete
            /// </summary>
            public const string PerformFilterDelete = "DOFILDEL";

            #endregion
        }

        /// <summary>
        /// Contains list of Tax Rate Code Index Constants
        /// </summary>
        public class Index
        {
            #region Indexes

            /// <summary>
            /// Index for Effective Date 
            /// </summary>
            public const int EffDate = 1;

            /// <summary>
            /// Index for Tax Authority 
            /// </summary>
            public const int Authority = 2;

            /// <summary>
            /// Index for Transaction Type 
            /// </summary>
            public const int TType = 3;

            /// <summary>
            /// Index for Buyer Class
            /// </summary>
            public const int BuyerClass = 4;

            /// <summary>
            /// Index for Item Class 
            /// </summary>
            public const int ItemClass = 5;

            /// <summary>
            /// Index for Tax Rate Code 
            /// </summary>
            public const int TaxRCode = 6;

            /// <summary>
            /// Index for Filter Delete Filter
            /// </summary>
            public const int DeleteFilter = 50;

            /// <summary>
            /// Index for Perform Filter Delete
            /// </summary>
            public const int PerformFilterDelete = 51;

            #endregion
        }
    }
}