/* Copyright (c) 2018-2023 The Sage Group plc or its licensors.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.TS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.TS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TS.Models
{
    /// <summary>
    /// Class GST F5 Processor.
    /// </summary>
    public partial class TsGstF5 : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the GST F5
        /// </summary>
        public TsGstF5()
        {
        }

        /// <summary>
        /// Gets or set Form Year
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromYear", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FromYear, Id = Index.FromYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string FromYear { get; set; } = "2020";

        /// <summary>
        /// Gets or set From Period
        /// </summary>
        [MaxLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromPeriod", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FromPeriod, Id = Index.FromPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FromPeriod { get; set; } = 9;

        /// <summary>
        /// Gets or set To Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToYear", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.ToYear, Id = Index.ToYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string ToYear { get; set; } = "2020";

        /// <summary>
        /// Gets or set To Period 
        /// </summary>
        [MaxLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToPeriod", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.ToPeriod, Id = Index.ToPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ToPeriod { get; set; } = 9;

        /// <summary>
        /// Gets or set Box 1 - Value of Standard Rated 
        /// </summary>
        [Display(Name = nameof(GstF5Resx.Box1), ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box1, Id = Index.Box1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box1 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 2 - Value of Zero-Reated Supp 
        /// </summary>
        [Display(Name = nameof(GstF5Resx.Box2), ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box2, Id = Index.Box2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box2 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 3 - Value of Exempt Supplies
        /// </summary>
        [Display(Name = "Box3", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box3, Id = Index.Box3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box3 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 4 - Value of Total of [1][2][3]
        /// </summary>
        [Display(Name = "Box4", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box4, Id = Index.Box4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box4 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 5 - Value of Total of Taxable Purchas
        /// </summary>
        [Display(Name = "Box5", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box5, Id = Index.Box5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box5 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 6 - Value of Output Tax Due
        /// </summary>
        [Display(Name = "Box6", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box6, Id = Index.Box6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box6 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 7 - Value of Input Tax and Refunds CI 
        /// </summary>
        [Display(Name = "Box7", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box7, Id = Index.Box7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box7 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 8 - Value of Net Payable to IRAS 
        /// </summary>
        [Display(Name = "Box8", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box8, Id = Index.Box8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box8 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 9 - Value of Goods Imported
        /// </summary>
        [Display(Name = "Box9", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box9, Id = Index.Box9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box9 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 10 - Value of GST Refunded to Tourist 
        /// </summary>
        [Display(Name = "Box10", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box10, Id = Index.Box10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box10 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 11 - Value of GST Claim for Bad Debt
        /// </summary>
        [Display(Name = "Box11", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box11, Id = Index.Box11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box11 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 12 - Value of GST Pre-registration CI
        /// </summary>
        [Display(Name = "Box12", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box12, Id = Index.Box12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box12 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 13 - Value of Revenue for The Account
        /// </summary>
        [Display(Name = "Box13", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box13, Id = Index.Box13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box13 { get; set; } = 0;

        /// <summary>
        /// Gets or set Input Tax from Transactions
        /// </summary>
        [Display(Name = "InputTax", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.InputTax, Id = Index.InputTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InputTax { get; set; } = 0;

        /// <summary>
        /// Gets or set Output Tax from Transactions 
        /// </summary>
        [Display(Name = "OutputTax", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.OutputTax, Id = Index.OutputTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OutputTax { get; set; } = 0;

        /// <summary>
        /// Gets or set Tax on Recovered Bad Debt 
        /// </summary>
        [Display(Name = "RecoverTax", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.RecoverTax, Id = Index.RecoverTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RecoverTax { get; set; } = 0;

        /// <summary>
        /// Gets or set Tax on Recovered Bad Debt 
        /// </summary>
        [ViewField(Name = Fields.Box3Pre, Id = Index.Box3Pre, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box3Pre { get; set; } = 0;

        /// <summary>
        /// Gets or set Realized Exchange Gain/Loss(Fun 
        /// </summary>
        [ViewField(Name = Fields.RlGainLoss, Id = Index.RlGainLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RlGainLoss { get; set; } = 0;

        /// <summary>
        /// Gets or set Customer Accounted Tax
        /// </summary>
        [Display(Name = "RevCharge", ResourceType =typeof(GstF5Resx))]
        [ViewField(Name = Fields.RevCharge, Id = Index.RevCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RevCharge { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 14 - Imported services and L
        /// </summary>
        [Display(Name = "Box14", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box14, Id = Index.Box14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box14 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 15 - Supply of remote servic
        /// </summary>
        [Display(Name = "Box15", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box15, Id = Index.Box15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box15 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 16 - Supply of LVG as a rede
        /// </summary>
        [Display(Name = "Box16", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box16, Id = Index.Box16, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box16 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 17 - Own supply of LVG
        /// </summary>
        [Display(Name = "Box17", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box17, Id = Index.Box17, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box17 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 18 - Net GST per box 8 above
        /// </summary>
        [Display(Name = "Box18", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box18, Id = Index.Box18, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box18 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 19 - Deferred import GST pay
        /// </summary>
        [Display(Name = "Box19", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box19, Id = Index.Box19, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box19 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 20 - Total tax to be paid to
        /// </summary>
        [Display(Name = "Box20", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box20, Id = Index.Box20, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box20 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 21 - Total value of goods im
        /// </summary>
        [Display(Name = "Box21", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Box21, Id = Index.Box21, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Box21 { get; set; } = 0;

        /// <summary>
        /// Gets or set GST Form Type
        /// </summary>
        [Display(Name = "GSTFormType", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.GSTFormType, Id = Index.GSTFormType, FieldType = EntityFieldType.Int, Size = 2)]
        public GSTFormType GSTFormType { get; set; }

        /// <summary>
        /// Gets or set GST Form Type
        /// </summary>
        [Display(Name = "ProcessAction", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.ProcessAction, Id = Index.ProcessAction, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessAction ProcessAction { get; set; }

        /// <summary>
        /// Gets or sets Full Path JSON File Name 
        /// </summary>
        [StringLength(260, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FullPathJSONFileName", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FullPathJSONFileName, Id = Index.FullPathJSONFileName, FieldType = EntityFieldType.Char, Size = 260)]
        public string FullPathJSONFileName { get; set; }

        /// <summary>
        /// Gets or sets Declarant Designation 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DeclarantDesignation", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.DeclarantDesignation, Id = Index.DeclarantDesignation, FieldType = EntityFieldType.Char, Size = 60)]
        public string DeclarantDesignation { get; set; }

        /// <summary>
        /// Gets or sets Contact Person
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactPerson", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.ContactPerson, Id = Index.ContactPerson, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactPerson { get; set; }

        /// <summary>
        /// Gets or sets Contact Telephone
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactTelephone", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.ContactTelephone, Id = Index.ContactTelephone, FieldType = EntityFieldType.Char, Size = 30)]
        public string ContactTelephone { get; set; }

        /// <summary>
        /// Gets or sets Contact Email
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactEmail", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.ContactEmail, Id = Index.ContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactEmail { get; set; }

        /// <summary>
        /// Gets or sets Cloud Enablement Header/Credential
        /// </summary>
        [StringLength(1024, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CECredential", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.CECredential, Id = Index.CECredential, FieldType = EntityFieldType.Char, Size = 1024)]
        public string CECredential { get; set; }

        /// <summary>
        /// Gets or sets IRASURL
        /// </summary>
        [StringLength(200, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "IRASURL", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.IRASURL, Id = Index.IRASURL, FieldType = EntityFieldType.Char, Size = 200)]
        public string IRASURL { get; set; }

        /// <summary>
        /// Gets or sets CEJobNumber
        /// </summary>
        [Display(Name = "CEJobNumber", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.CEJobNumber, Id = Index.CEJobNumber, FieldType = EntityFieldType.Char, Size = 100)]
        public string CEJobNumber { get; set; }

        /// <summary>
        /// Gets or sets IRASConfirmationNumber
        /// </summary>
        [Display(Name = "IRASConfirmationNumber", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.IRASConfirmationNumber, Id = Index.IRASConfirmationNumber, FieldType = EntityFieldType.Char, Size = 20)]
        public string IRASConfirmationNumber { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets IsResubmission
        /// </summary>
        [Display(Name = "IsResubmission", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.IsResubmission, Id = Index.IsResubmission, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IsResubmission { get; set; }

        /// <summary>
        /// Gets or sets DateSubmitted
        /// </summary>
        [Display(Name = "DateSubmitted", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.DateSubmitted, Id = Index.DateSubmitted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateSubmitted { get; set; }

        /// <summary>
        /// Gets or sets TimeSubmitted
        /// </summary>
        [Display(Name = "TimeSubmitted", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.TimeSubmitted, Id = Index.TimeSubmitted, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime TimeSubmitted { get; set; }
 
        /// <summary>
        /// Gets or sets LastGSTReg
        /// </summary>
        [Display(Name = "LastGSTReg", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.LastGSTReg, Id = Index.LastGSTReg, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastGSTReg { get; set; }

        /// <summary>
        /// Gets or sets TaxAgentFiling
        /// </summary>
        [Display(Name = "TaxAgentFiling", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.TaxAgentFiling, Id = Index.TaxAgentFiling, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxAgentFiling { get; set; }

        /// <summary>
        /// Gets or sets Encrypted Customer Account
        /// </summary>
        [StringLength(1024, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EncryptedCustomerAccount", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.EncryptedCustomerAccount, Id = Index.EncryptedCustomerAccount, FieldType = EntityFieldType.Char, Size = 1024)]
        public string EncryptedCustomerAccount { get; set; }

        /// <summary>
        /// Gets or sets FE4Error
        /// </summary>
        [Display(Name = "FE4Error", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE4Error, Id = Index.FE4Error, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FE4Error { get; set; }

        /// <summary>
        /// Gets or sets FE4ErrorMessage
        /// </summary>
        [StringLength(256, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FE4ErrorMessage", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE4ErrorMessage, Id = Index.FE4ErrorMessage, FieldType = EntityFieldType.Char, Size = 256)]
        public string FE4ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets FE4ReasonToSkip
        /// </summary>
        [Display(Name = "FE4ReasonToSkip", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE4ReasonToSkip, Id = Index.FE4ReasonToSkip, FieldType = EntityFieldType.Int, Size = 2)]
        public FE4ReasonToSkip FE4ReasonToSkip { get; set; }

        /// <summary>
        /// Gets or sets FE4OtherReason
        /// </summary>
        [StringLength(200, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FE4OtherReason", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE4OtherReason, Id = Index.FE4OtherReason, FieldType = EntityFieldType.Char, Size = 200)]
        public string FE4OtherReason { get; set; }

        /// <summary>
        /// Gets or sets FE5Error
        /// </summary>
        [Display(Name = "FE5Error", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE5Error, Id = Index.FE5Error, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FE5Error { get; set; }

        /// <summary>
        /// Gets or sets FE5ErrorMessage
        /// </summary>
        [StringLength(256, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FE5ErrorMessage", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE5ErrorMessage, Id = Index.FE5ErrorMessage, FieldType = EntityFieldType.Char, Size = 256)]
        public string FE5ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets FE5ReasonToSkip
        /// </summary>
        [Display(Name = "FE5ReasonToSkip", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE5ReasonToSkip, Id = Index.FE5ReasonToSkip, FieldType = EntityFieldType.Int, Size = 2)]
        public FE5ReasonToSkip FE5ReasonToSkip { get; set; }

        /// <summary>
        /// Gets or sets FE5OtherReason
        /// </summary>
        [StringLength(200, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FE5OtherReason", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE5OtherReason, Id = Index.FE5OtherReason, FieldType = EntityFieldType.Char, Size = 200)]
        public string FE5OtherReason { get; set; }

        /// <summary>
        /// Gets or sets FE6Error
        /// </summary>
        [Display(Name = "FE6Error", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE6Error, Id = Index.FE6Error, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FE6Error { get; set; }

        /// <summary>
        /// Gets or sets FE6ErrorMessage
        /// </summary>
        [StringLength(256, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FE6ErrorMessage", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE6ErrorMessage, Id = Index.FE6ErrorMessage, FieldType = EntityFieldType.Char, Size = 256)]
        public string FE6ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets FE6ReasonToSkip
        /// </summary>
        [Display(Name = "FE6ReasonToSkip", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE6ReasonToSkip, Id = Index.FE6ReasonToSkip, FieldType = EntityFieldType.Int, Size = 2)]
        public FE6ReasonToSkip FE6ReasonToSkip { get; set; }

        /// <summary>
        /// Gets or sets FE6OtherReason
        /// </summary>
        [StringLength(200, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FE6OtherReason", ResourceType = typeof(GstF5Resx))]
        [ViewField(Name = Fields.FE6OtherReason, Id = Index.FE6OtherReason, FieldType = EntityFieldType.Char, Size = 200)]
        public string FE6OtherReason { get; set; }
    }
}