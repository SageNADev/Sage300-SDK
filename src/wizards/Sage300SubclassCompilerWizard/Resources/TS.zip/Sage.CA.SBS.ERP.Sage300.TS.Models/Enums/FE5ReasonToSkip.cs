// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TS.Models.Enums
{
    /// <summary>
    /// Enum for FE5ReasonToSkip
    /// </summary>
    public enum FE5ReasonToSkip
    {
        /// <summary>
        /// Gets or sets TouristRefund
        /// </summary>
        [EnumValue("TouristRefund", typeof(EnumerationsResx))]
        TouristRefund = 1,

        /// <summary>
        /// Gets or sets BadDebtsRelief
        /// </summary>
        [EnumValue("BadDebtsRelief", typeof(EnumerationsResx))]
        BadDebtsRelief = 2,

        /// <summary>
        /// Gets or sets CreditNotes
        /// </summary>
        [EnumValue("CreditNotes", typeof(EnumerationsResx))]
        CreditNotes = 3,

        /// <summary>
        /// Gets or sets Others
        /// </summary>
        [EnumValue("Others", typeof(EnumerationsResx))]
        Others = 4
	}
}
