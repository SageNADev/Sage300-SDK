﻿// /* Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.TS.Models.Enums
{
    public enum ProcessAction
    {
        /// <summary>
        /// Generate F5
        /// </summary>
        [EnumValue("GenerateF5", typeof(EnumerationsResx))]
        GenerateF5 = 1,

        /// <summary>
        /// Create JSON
        /// </summary>
        [EnumValue("CreateJSON", typeof(EnumerationsResx))]
        CreateJSON = 2,

        /// <summary>
        /// Write to Audit
        /// </summary>
        [EnumValue("WriteToAudit", typeof(EnumerationsResx))]
        WriteToAudit = 3,

        /// <summary>
        /// Check for Re-submission
        /// </summary>
        [EnumValue("CheckResubmission", typeof(EnumerationsResx))]
        CheckResubmission = 4,
    }
}
