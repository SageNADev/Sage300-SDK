// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TS.Models.Enums
{
    /// <summary>
    /// Enum for FE4ReasonToSkip
    /// </summary>
    public enum FE4ReasonToSkip
    {
		/// <summary>
		/// Gets or sets GSTonBadDebtRecovery
		/// </summary>
		[EnumValue("GSTonBadDebtRecovery", typeof(EnumerationsResx))]
		GSTonBadDebtRecovery = 1,

        /// <summary>
        /// Gets or sets GSTcollectedpriorToregistration
        /// </summary>
        [EnumValue("GSTcollectedpriorToregistration", typeof(EnumerationsResx))]
        GSTcollectedpriorToregistration = 2,

        /// <summary>
        /// Gets or sets Others
        /// </summary>
        [EnumValue("Others", typeof(EnumerationsResx))]
        Others = 3
	}
}
