// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TS.Models.Enums
{
    /// <summary>
    /// Enum for FE6ReasonToSkip
    /// </summary>
    public enum FE6ReasonToSkip
    {
        /// <summary>
        /// Gets or sets CreditNotes
        /// </summary>
        [EnumValue("CreditNotes", typeof(EnumerationsResx))]
        CreditNotes = 1,

        /// <summary>
        /// Gets or sets Others
        /// </summary>
        [EnumValue("Others", typeof(EnumerationsResx))]
        Others = 2
	}
}
