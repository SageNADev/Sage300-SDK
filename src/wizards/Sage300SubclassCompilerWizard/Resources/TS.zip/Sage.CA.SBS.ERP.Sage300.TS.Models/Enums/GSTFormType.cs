﻿// /* Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.TS.Models.Enums
{
    public enum GSTFormType
    {
        /// <summary>
        /// For F5
        /// </summary>
        [EnumValue("F5", typeof(EnumerationsResx))]
        F5 = 1,

        /// <summary>
        /// For F8
        /// </summary>
        [EnumValue("F8", typeof(EnumerationsResx))]
        F8 = 2,
    }
}
