﻿// /* Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TS.Models.Enums
{
    public enum Status
    {
        /// <summary>
        /// None
        /// </summary>
        None = 0,

        /// <summary>
        /// Succeed
        /// </summary>
        Succeed = 1,

        /// <summary>
        /// Failed
        /// </summary>
        Failed = 2,
    }
}
