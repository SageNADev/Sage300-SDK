/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.TS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.TS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TS.Models
{
    /// <summary>
    /// Class Generate IRAS Audit File.
    /// </summary>
    public partial class TsIAF : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the Generate IRAS Audit File
        /// </summary>
        public TsIAF()
        {
        }

        /// <summary>
        /// Gets or sets From Year
        /// </summary>
        [Display(Name = "FromYear", ResourceType = typeof(GstIAFGeneratorResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromYear { get; set; } = "2020";

        /// <summary>
        /// Gets or sets From Period
        /// </summary>
        [Display(Name = "FromPeriod", ResourceType = typeof(GstIAFGeneratorResx))]
        [MaxLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FromPeriod { get; set; } = 9;

        /// <summary>
        /// Gets or sets From Date
        /// </summary>
        [Display(Name = "FromDate", ResourceType = typeof(GstIAFGeneratorResx))]
        public DateTime FromDate { get; set; } = new DateTime(2020,9,1);

        /// <summary>
        /// Gets or sets From Year
        /// </summary>
        [Display(Name = "ToYear", ResourceType = typeof(GstIAFGeneratorResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToYear { get; set; } = "2020";

        /// <summary>
        /// Gets or sets From Period
        /// </summary>
        [Display(Name = "ToPeriod", ResourceType = typeof(GstIAFGeneratorResx))]
        [MaxLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int ToPeriod { get; set; } = 9;

        /// <summary>
        /// Gets or sets From Date
        /// </summary>
        [Display(Name = "ToDate", ResourceType = typeof(GstIAFGeneratorResx))]
        public DateTime ToDate { get; set; } = new DateTime(2020, 9, 30);

        /// <summary>
        /// Gets or sets Output Filename
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FileName { get; set; } = "IAF-20200901-20200930.txt";

        /// <summary>
        /// Gets or sets Overwrite Mode
        /// </summary>
        public OverwriteMode Overwirte { get; set; } = OverwriteMode.HaltOverwrite;

        /// <summary>
        /// Gets or sets Output Directory
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string OutPutDir { get; set; }

    }
}