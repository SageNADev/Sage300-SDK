/* Copyright (c) 2018-2023 The Sage Group plc or its licensors.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.TS.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TS.Models
{
    /// <summary>
    /// Class GST F5 Report.
    /// </summary>
    public partial class TsGstF5Report : ReportBase
    {
        /// <summary>
        /// Initializes a new instance of the GST F5
        /// </summary>
        public TsGstF5Report()
        {
        }

        /// <summary>
        /// Gets or set Tax Number
        /// </summary>
        public string TaxNumber { get; set; }

        /// <summary>
        /// Gets or set Legal Name
        /// </summary>
        public string LegalName { get; set; }

        /// <summary>
        /// Gets or set Accpac User Id
        /// </summary>
        public string AccpacUserId { get; set; }

        /// <summary>
        /// Get or set Business Registration Number
        /// </summary>
        public string BusRegNo { get; set; }
        /// <summary>
        /// Gets or set Form Year
        /// </summary>
        public string FromYear { get; set; } = "2020";

        /// <summary>
        /// Gets or set From Period
        /// </summary>
        public string FromPeriod { get; set; }

        /// <summary>
        /// Gets or set To Year 
        /// </summary>
        public string ToYear { get; set; } = "2020";

        /// <summary>
        /// Gets or set To Period 
        /// </summary>
        public string ToPeriod { get; set; }

        /// <summary>
        /// Gets or set Box 1 - Value of Standard Rated 
        /// </summary>
        public decimal Box1 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 2 - Value of Zero-Reated Supp 
        /// </summary>
        public decimal Box2 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 3 - Value of Exempt Supplies
        /// </summary>
        public decimal Box3 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 4 - Value of Total of [1][2][3]
        /// </summary>
        public decimal Box4 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 5 - Value of Total of Taxable Purchas
        /// </summary>
        public decimal Box5 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 6 - Value of Output Tax Due
        /// </summary>
        public decimal Box6 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 7 - Value of Input Tax and Refunds CI 
        /// </summary>
        public decimal Box7 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 8 - Value of Net Payable to IRAS 
        /// </summary>
        public decimal Box8 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 9 - Value of Goods Imported
        /// </summary>
        public decimal Box9 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 10 - Value of GST Refunded to Tourist 
        /// </summary>
        public decimal Box10 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 11 - Value of GST Claim for Bad Debt
        /// </summary>
        public decimal Box11 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 12 - Value of GST Pre-registration CI
        /// </summary>
        public decimal Box12 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 13 - Value of Revenue for The Account
        /// </summary>
        public decimal Box13 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 14 - Imported services and L
        /// </summary>
        public decimal Box14 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 15 - Supply of remote servic
        /// </summary>
        public decimal Box15 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 16 - Supply of LVG as a rede
        /// </summary>
        public decimal Box16 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 17 - Own supply of LVG
        /// </summary>
        public decimal Box17 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 18 - Net GST per box 8 above
        /// </summary>
        public decimal Box18 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 19 - Deferred import GST pay
        /// </summary>
        public decimal Box19 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 20 - Total tax to be paid to
        /// </summary>
        public decimal Box20 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 21 - Total value of goods im
        /// </summary>
        public decimal Box21 { get; set; } = 0;

        /// <summary>
        /// Gets or set GST Form Type
        /// </summary>
        public GSTFormType GSTFormType { get; set; }
    }
}