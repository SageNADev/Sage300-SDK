/* Copyright (c) 2018-2023 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.TS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TS.Models
{
    /// <summary>
    /// Class Tax Rate Codes.
    /// </summary>
    public partial class TsRCode : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the Tax Rate Code
        /// </summary>
        public TsRCode()
        {
        }

        /// <summary>
        /// Gets or sets Effective Date 
        /// </summary>
        [Key]
        [Display(Name = "EffectiveDate", ResourceType = typeof(TaxCodeMappingResx))]
        public DateTime EffDate { get; set; }

        /// <summary>
        /// Gets or sets Tax Authority
        /// </summary>
        [Key]
        [Display(Name = "TaxAuthority", ResourceType = typeof(TaxCodeMappingResx))]
        [MaxLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Authority { get; set; }

        /// <summary>
        /// Gets or sets Transaction Type 
        /// </summary>
        [Key]
        [Display(Name = "TransactionType", ResourceType = typeof(TaxCodeMappingResx))]
        public int TType { get; set; } = 0;

        /// <summary>
        /// Gets or sets Buyer Class 
        /// </summary>
        [Key]
        public int BuyerClass { get; set; } = 0;

        /// <summary>
        /// Gets or sets Item Class 
        /// </summary>
        [Key]
        public int ItemClass { get; set; } = 0;

        /// <summary>
        /// Gets or sets Tax Rate Code 
        /// </summary>
        [MaxLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TaxRCode { get; set; }

        /// <summary>
        /// Gets or sets Filter Delete Filter
        /// </summary>
        public string DeleteFilter { get; set; }

        /// <summary>
        /// Gets or sets Perform Filter Delete
        /// </summary>
        public bool PerformFilterDelete { get; set; }
    }
}