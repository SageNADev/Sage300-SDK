﻿using System.Collections.Specialized;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// This class is used for AP Invoice Entry fro the Taxes grid table.
    /// </summary>
    public class InvoiceTaxClass : ModelBase
    {
        /// <summary>
        /// Property to store Line Number
        /// </summary>
        public int LineNumber { get; set; }

        /// <summary>
        /// Property to store Tax Authority
        /// </summary>
        [Display(Name = "TaxAuthority", ResourceType = typeof(InvoiceEntryResx))]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Property to store Tax Class
        /// </summary>
        [Display(Name = "VendorTaxClass", ResourceType = typeof(InvoiceEntryResx))]
        public string TaxClass { get; set; }

        /// <summary>
        /// Property to store Tax Inclusive
        /// </summary>
        [Display(Name = "TaxIncluded", ResourceType = typeof(APCommonResx))]
        public string TaxInclusive { get; set; }

        /// <summary>
        /// Property to store Tax Base
        /// </summary>
        [Display(Name = "TaxBase", ResourceType = typeof(InvoiceEntryResx))]
        public decimal TaxBase { get; set; }

        /// <summary>
        /// Property to store Tax Amount
        /// </summary>
        [Display(Name = "TaxAmount", ResourceType = typeof(InvoiceEntryResx))]
        public decimal TaxAmount { get; set; }

        /// <summary>
        /// Property to store Retainage Tax Base
        /// </summary>
        [Display(Name = "RetainageTaxBase", ResourceType = typeof(APCommonResx))]
        public decimal RetainageTaxBase { get; set; }

        /// <summary>
        /// Property to store Tax Reporting Amount
        /// </summary>
        [Display(Name = "TaxReportingAmount", ResourceType = typeof(APCommonResx))]
        public decimal TaxReportingAmount { get; set; }

        /// <summary>
        /// Property to store Retainage Tax Amount
        /// </summary>
        [Display(Name = "RetainageTaxAmount", ResourceType = typeof(APCommonResx))]
        public decimal RetainageTaxAmount { get; set; }

        /// <summary>
        /// Property to store Total Tax Amount
        /// </summary>
        [Display(Name = "TotalTaxAmount", ResourceType = typeof(InvoiceEntryResx))]
        public decimal TotalTaxAmount { get; set; }

        
    }
}
