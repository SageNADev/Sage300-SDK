/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class AccountSet : ModelBase
    {
         /// <summary>
        /// Constructor
        /// </summary>
        public AccountSet()
        {
            Status = Status.Active;
        }

        /// <summary>
        /// Gets or sets AccountSetCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetCode", ResourceType = typeof(AccountSetsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.AccountSetCode, Id = Index.AccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetDesc", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        public string StatusString
        {
            get
            {
                return EnumUtility.GetStringValue(Status);
            }
        }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets PayablesControlAccount 
        /// </summary>
         [Display(Name = "PayablesControl", ResourceType = typeof(AccountSetsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PayablesControlAccount, Id = Index.PayablesControlAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string PayablesControlAccount { get; set; }

        /// <summary>
        /// Gets or sets DiscountsAccount 
        /// </summary>
        [Display(Name = "PurchaseDiscounts", ResourceType = typeof(AccountSetsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DiscountsAccount, Id = Index.DiscountsAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DiscountsAccount { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentAccount 
        /// </summary>
          [Display(Name = "Prepayment", ResourceType = typeof(AccountSetsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentAccount, Id = Index.PrepaymentAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string PrepaymentAccount { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCodeforAccount 
        /// </summary>
       [Display(Name = "Currency", ResourceType = typeof(AccountSetsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrencyCodeforAccount, Id = Index.CurrencyCodeforAccount, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCodeforAccount { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeGainAccount 
        /// </summary>
          [Display(Name = "UnrlzExchGain", ResourceType = typeof(AccountSetsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnrealizedExchangeGainAccount, Id = Index.UnrealizedExchangeGainAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnrealizedExchangeGainAccount { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeLossAccount 
        /// </summary>
                  [Display(Name = "UnrlzExchLoss", ResourceType = typeof(AccountSetsResx))] 
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnrealizedExchangeLossAccount, Id = Index.UnrealizedExchangeLossAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnrealizedExchangeLossAccount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeGainAccount 
        /// </summary>
                      [Display(Name = "RlzExchGain", ResourceType = typeof(AccountSetsResx))] 
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExchangeGainAccount, Id = Index.ExchangeGainAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExchangeGainAccount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeLossAccount 
        /// </summary>
         [Display(Name = "RlzEXchLoss", ResourceType = typeof(AccountSetsResx))] 
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExchangeLossAccount, Id = Index.ExchangeLossAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExchangeLossAccount { get; set; }
       

        /// <summary>
        /// Gets or sets RetainageAccount 
        /// </summary>
         [Display(Name = "Retainage", ResourceType = typeof(AccountSetsResx))] 
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageAccount, Id = Index.RetainageAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RetainageAccount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRoundingAccount 
        /// </summary>
           [Display(Name = "ExchRounding", ResourceType = typeof(AccountSetsResx))] 
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExchangeRoundingAccount, Id = Index.ExchangeRoundingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExchangeRoundingAccount { get; set; }
       
    }
}
