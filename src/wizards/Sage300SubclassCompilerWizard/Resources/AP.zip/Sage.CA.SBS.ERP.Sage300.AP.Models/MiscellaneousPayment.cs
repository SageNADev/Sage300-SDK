/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

using System;
using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class MiscellaneousPayment : ModelBase
    {

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BatchType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BatchNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "EntryNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "LineNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        public int SequenceNo { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets AccountNumber 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        [IgnoreExportImport]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets GLReference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLReference", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.GLReference, Id = Index.GLReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLReference { get; set; }

        /// <summary>
        /// Gets or sets GLDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLDescription", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.GLDescription, Id = Index.GLDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1 
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2 
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3 
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4 
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5 
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1 
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2 
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3 
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4 
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5 
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1 
        /// </summary>
        [Display(Name = "TaxRate1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2 
        /// </summary>
        [Display(Name = "TaxRate2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3 
        /// </summary>
        [Display(Name = "TaxRate3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4 
        /// </summary>
        [Display(Name = "TaxRate4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5 
        /// </summary>
        [Display(Name = "TaxRate5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1 
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2 
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3 
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4 
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5 
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal 
        /// </summary>
        [Display(Name = "TotalTax", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets DistAmount 
        /// </summary>
        [Display(Name = "DistAmount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DistAmount, Id = Index.DistAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistAmount { get; set; }

        /// <summary>
        /// Gets or sets DistAmountNetofTaxes 
        /// </summary>
        [Display(Name = "DistAmountNetofTaxes", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DistAmountNetofTaxes, Id = Index.DistAmountNetofTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistAmountNetofTaxes { get; set; }

        /// <summary>
        /// Gets or sets FuncDistAmount 
        /// </summary>
        [Display(Name = "FuncDistAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncDistAmount, Id = Index.FuncDistAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDistAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncDistAmountNetofTaxes 
        /// </summary>
        [Display(Name = "FuncDistAmountNetofTaxes", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncDistAmountNetofTaxes, Id = Index.FuncDistAmountNetofTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDistAmountNetofTaxes { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedTotal 
        /// </summary>
        [Display(Name = "TaxAllocatedTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedTotal, Id = Index.TaxAllocatedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1 
        /// </summary>
        [Display(Name = "TaxAllocatedAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2 
        /// </summary>
        [Display(Name = "TaxAllocatedAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3 
        /// </summary>
        [Display(Name = "TaxAllocatedAmount3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4 
        /// </summary>
        [Display(Name = "TaxAllocatedAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5 
        /// </summary>
        [Display(Name = "TaxAllocatedAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverable1 
        /// </summary>
        [Display(Name = "TaxRecoverable1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRecoverable1, Id = Index.TaxRecoverable1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverable1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverable2 
        /// </summary>
        [Display(Name = "TaxRecoverable2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRecoverable2, Id = Index.TaxRecoverable2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverable2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverable3 
        /// </summary>
        [Display(Name = "TaxRecoverable3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRecoverable3, Id = Index.TaxRecoverable3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverable3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverable4 
        /// </summary>
        [Display(Name = "TaxRecoverable4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRecoverable4, Id = Index.TaxRecoverable4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverable4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverable5 
        /// </summary>
        [Display(Name = "TaxRecoverable5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRecoverable5, Id = Index.TaxRecoverable5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverable5 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpensed1 
        /// </summary>
        [Display(Name = "TaxExpensed1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxExpensed1, Id = Index.TaxExpensed1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpensed1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpensed2 
        /// </summary>
        [Display(Name = "TaxExpensed2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxExpensed2, Id = Index.TaxExpensed2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpensed2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpensed3 
        /// </summary>
        [Display(Name = "TaxExpensed3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxExpensed3, Id = Index.TaxExpensed3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpensed3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpensed4 
        /// </summary>
        [Display(Name = "TaxExpensed4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxExpensed4, Id = Index.TaxExpensed4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpensed4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpensed5 
        /// </summary>
        [Display(Name = "TaxExpensed5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxExpensed5, Id = Index.TaxExpensed5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpensed5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1 
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2 
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3 
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4 
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5 
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotal 
        /// </summary>
        [Display(Name = "TaxReportingTotal", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TaxReportingTotal, Id = Index.TaxReportingTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount 
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount, Id = Index.TaxReportingAllocatedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt1 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt1, Id = Index.TaxReportingRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt2 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt2, Id = Index.TaxReportingRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt3 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt3, Id = Index.TaxReportingRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt4 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt4, Id = Index.TaxReportingRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt5 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt5, Id = Index.TaxReportingRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedAmount1 
        /// </summary>
        [Display(Name = "TaxReportingExpensedAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedAmount1, Id = Index.TaxReportingExpensedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedAmount2 
        /// </summary>
        [Display(Name = "TaxReportingExpensedAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedAmount2, Id = Index.TaxReportingExpensedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedAmount3 
        /// </summary>
        [Display(Name = "TaxReportingExpensedAmount3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedAmount3, Id = Index.TaxReportingExpensedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedAmount4 
        /// </summary>
        [Display(Name = "TaxReportingExpensedAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedAmount4, Id = Index.TaxReportingExpensedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedAmount5 
        /// </summary>
        [Display(Name = "TaxReportingExpensedAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedAmount5, Id = Index.TaxReportingExpensedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase1 
        /// </summary>
        [Display(Name = "FuncTaxBase1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase1, Id = Index.FuncTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase2 
        /// </summary>
        [Display(Name = "FuncTaxBase2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase2, Id = Index.FuncTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase3 
        /// </summary>
        [Display(Name = "FuncTaxBase3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase3, Id = Index.FuncTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase4 
        /// </summary>
        [Display(Name = "FuncTaxBase4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase4, Id = Index.FuncTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase5 
        /// </summary>
        [Display(Name = "FuncTaxBase5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase5, Id = Index.FuncTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount1 
        /// </summary>
        [Display(Name = "FuncTaxAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount1, Id = Index.FuncTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount2 
        /// </summary>
        [Display(Name = "FuncTaxAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount2, Id = Index.FuncTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount3 
        /// </summary>
        [Display(Name = "FuncTaxAmount3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount3, Id = Index.FuncTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount4 
        /// </summary>
        [Display(Name = "FuncTaxAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount4, Id = Index.FuncTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount5 
        /// </summary>
        [Display(Name = "FuncTaxAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount5, Id = Index.FuncTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedTotal 
        /// </summary>
        [Display(Name = "FuncTaxAllocatedTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedTotal, Id = Index.FuncTaxAllocatedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount1 
        /// </summary>
        [Display(Name = "FuncTaxAllocatedAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount1, Id = Index.FuncTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount2 
        /// </summary>
        [Display(Name = "FuncTaxAllocatedAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount2, Id = Index.FuncTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount3 
        /// </summary>
        [Display(Name = "FuncTaxAllocatedAmount3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount3, Id = Index.FuncTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount4 
        /// </summary>
        [Display(Name = "FuncTaxAllocatedAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount4, Id = Index.FuncTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount5 
        /// </summary>
        [Display(Name = "FuncTaxAllocatedAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount5, Id = Index.FuncTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverable1 
        /// </summary>
        [Display(Name = "FuncTaxRecoverable1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverable1, Id = Index.FuncTaxRecoverable1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverable1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverable2 
        /// </summary>
        [Display(Name = "FuncTaxRecoverable2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverable2, Id = Index.FuncTaxRecoverable2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverable2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverable3 
        /// </summary>
        [Display(Name = "FuncTaxRecoverable3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverable3, Id = Index.FuncTaxRecoverable3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverable3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverable4 
        /// </summary>
        [Display(Name = "FuncTaxRecoverable4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverable4, Id = Index.FuncTaxRecoverable4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverable4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverable5 
        /// </summary>
        [Display(Name = "FuncTaxRecoverable5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverable5, Id = Index.FuncTaxRecoverable5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverable5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpensed1 
        /// </summary>
        [Display(Name = "FuncTaxExpensed1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpensed1, Id = Index.FuncTaxExpensed1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpensed1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpensed2 
        /// </summary>
        [Display(Name = "FuncTaxExpensed2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpensed2, Id = Index.FuncTaxExpensed2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpensed2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpensed3 
        /// </summary>
        [Display(Name = "FuncTaxExpensed3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpensed3, Id = Index.FuncTaxExpensed3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpensed3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpensed4 
        /// </summary>
        [Display(Name = "FuncTaxExpensed4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpensed4, Id = Index.FuncTaxExpensed4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpensed4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpensed5 
        /// </summary>
        [Display(Name = "FuncTaxExpensed5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpensed5, Id = Index.FuncTaxExpensed5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpensed5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxTotal 
        /// </summary>
        [Display(Name = "FuncTaxTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxTotal, Id = Index.FuncTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets ContractCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectOrCategoryResource 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectOrCategoryResource", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ProjectOrCategoryResource, Id = Index.ProjectOrCategoryResource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string ProjectOrCategoryResource { get; set; }

        /// <summary>
        /// Gets or sets CostClass 
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public Common.Models.Enums.InvoiceEntry.CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets BillingType 
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitofMeasure 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitofMeasure", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.UnitofMeasure, Id = Index.UnitofMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitofMeasure { get; set; }

        /// <summary>
        /// Gets or sets Quantity 
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets Cost 
        /// </summary>
        [Display(Name = "Cost", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets BillingDate 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingDate, Id = Index.BillingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BillingDate { get; set; }

        /// <summary>
        /// Gets or sets BillingRate 
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHT1TC, Id = Index.AmtWHT1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHT2TC, Id = Index.AmtWHT2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHT3TC, Id = Index.AmtWHT3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHT4TC, Id = Index.AmtWHT4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHT5TC, Id = Index.AmtWHT5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtCXTX1TC, Id = Index.AmtCXTX1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXTX1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtCXTX2TC, Id = Index.AmtCXTX2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXTX2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtCXTX3TC, Id = Index.AmtCXTX3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXTX3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtCXTX4TC, Id = Index.AmtCXTX4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXTX4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtCXTX5TC, Id = Index.AmtCXTX5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXTX5TC { get; set; } = 0;

        /// <summary>
        /// the unformatted form of the ContractCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedContractCode", ResourceType = typeof(PaymentEntryResx))]
        [IgnoreExportImport]
        public string UnformattedContractCode { get; set; }

        /// <summary>
        /// the string representation of the CostClass property (an enumerated value)
        /// </summary>
        /// <value>the string representation of the CostClass property</value>
        [IgnoreExportImport]
        public string CostClassString => CostClass == Common.Models.Enums.InvoiceEntry.CostClass.None ? string.Empty : EnumUtility.GetStringValue(CostClass);

        /// <summary>
        /// the editable state for PJC properties in this model
        /// </summary>
        /// <remarks>
        /// a read-only dictionary mapping from the name of the model property to a boolean value indicating if that
        /// property is disabled. There is an additional entry with the name 'OtherCols' which contains the default
        /// boolean value for several PJC properties.<br/>
        /// Care should be taken with denormalized fields such as calculated string equivalents of enumerated types.
        /// Currently this must be specified as a Dictionary since the marshalling is unable to map from the client
        /// side data when the client sends a MiscellaneousPayment
        /// </remarks>
        [IgnoreExportImport]
        public Dictionary<string, bool> PMDisableDictionary { get; set; }

        /// <summary>
        /// a value indicating whether this detail line's project style is standard.
        /// </summary>
        [IgnoreExportImport]
        public bool IsProjectStyleStandard { get; set; }

        /// <summary>
        /// a value indicating whether this detail line's project style is basic.
        /// </summary>
        [IgnoreExportImport]
        public bool IsProjectStyleBasic { get; set; }

        /// <summary>
        /// a value indicating whether this detail line's project type is time and material.
        /// </summary>
        [IgnoreExportImport]
        public bool IsProjectTimeMaterial { get; set; }

        /// <summary>
        /// The list of values for the <see cref="BillingType"/> enumeration
        /// </summary>
        /// <remarks>
        /// Note that the list depends upon circumstances.
        /// </remarks>
        [IgnoreExportImport]
        public IEnumerable<CustomSelectList> BillingTypeList { get; set; }

    }
}
