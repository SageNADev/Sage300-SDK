﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region MyRegion

using Sage.CA.SBS.ERP.Sage300.AP.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Email;
using System.Collections.Generic; 

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Email
{
    /// <summary>
    /// Class for EmailReport
    /// </summary>
    public class LetterAndLabelEmail : EmailOption
    {      

        /// <summary>
        /// Gets or Sets Reports
        /// </summary>
        public List<LetterAndLabelReport> Reports { get; set; }
    }
}
