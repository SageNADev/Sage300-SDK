﻿// Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Email;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Email
{
    /// <summary>
    /// A simple symbol for the <see cref="EmailOption"/> for a list of <see cref="LetterAndLabelReport"/>
    /// </summary>
    public class LetterAndLabelEmail : ReportsEmailOption<LetterAndLabelReport>
    {
    }
}
