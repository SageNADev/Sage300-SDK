/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// A class for the view AP0029
    /// </summary>
    public partial class PostedPayment : ModelBase
    {
        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BankCode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "VendorNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber 
        /// </summary>
        [Key]
        [Display(Name = "CheckNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Char, Size = 18, Mask = "%-18D")]
        public string CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckSerialNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CheckSerialNumber", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.CheckSerialNumber, Id = Index.CheckSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long CheckSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckDate 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CheckDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CheckDate, Id = Index.CheckDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CheckDate { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        [Display(Name = "BatchDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BatchDate { get; set; }

        /// <summary>
        /// Gets or sets CheckAmountVendorCurrency 
        /// </summary>
        [Display(Name = "CheckAmount", ResourceType = typeof(APCommonResx))]
        public decimal CheckAmountVendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets PaymentAmount 
        /// </summary>
        [Display(Name = "PaymentAmount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PaymentAmount, Id = Index.PaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmount 
        /// </summary>
        [Display(Name = "DiscAmount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [Display(Name = "PaymentCode", ResourceType = typeof(APCommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [Display(Name = "CurrencyCode", ResourceType = typeof(APCommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets BankRateType 
        /// </summary>
        [Display(Name = "BankRateType", ResourceType = typeof(APCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankRateType, Id = Index.BankRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BankRateType { get; set; }

        /// <summary>
        /// Gets or sets BankExchangeRate 
        /// </summary>
        [Display(Name = "BankExchangeRate", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.BankExchangeRate, Id = Index.BankExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BankExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets BankRateOverridden 
        /// </summary>
        [Display(Name = "BankRateOverridden", ResourceType = typeof(PaymentBatchListResx))]
        [ViewField(Name = Fields.BankRateOverridden, Id = Index.BankRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden BankRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets ReasonforReversal 
        /// </summary>
        [Display(Name = "ReasonForReversal", ResourceType = typeof(PaymentInquiryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReasonforReversal, Id = Index.ReasonforReversal, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReasonforReversal { get; set; }

        /// <summary>
        /// Gets or sets AmountofRoundingError 
        /// </summary>
        [Display(Name = "AmountofRoundingError", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.AmountofRoundingError, Id = Index.AmountofRoundingError, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountofRoundingError { get; set; }

        /// <summary>
        /// Gets or sets BankRateDate 
        /// </summary>
        [Display(Name = "BankRateDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BankRateDate, Id = Index.BankRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BankRateDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [Display(Name = "FiscalYear", ResourceType = typeof(APCommonResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(APCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets RemitTo 
        /// </summary>
        [Display(Name = "RemitTo", ResourceType = typeof(APCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RemitTo, Id = Index.RemitTo, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitTo { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Display(Name = "CheckNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckCleared 
        /// </summary>
        [Display(Name = "CheckCleared", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.CheckCleared, Id = Index.CheckCleared, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckCleared CheckCleared { get; set; }

        /// <summary>
        /// Gets or sets CheckAmountFunctionalCurrency 
        /// </summary>
        [Display(Name = "CheckAmountFunctionalCurrency", ResourceType = typeof(PaymentInquiryResx))]
        public decimal CheckAmountFunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets AmountAdjusted 
        /// </summary>
        [Display(Name = "AmountAdjusted", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.AmountAdjusted, Id = Index.AmountAdjusted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountAdjusted { get; set; }

        /// <summary>
        /// Gets or sets DateCleared 
        /// </summary>
        [Display(Name = "DateCleared", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.DateCleared, Id = Index.DateCleared, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateCleared { get; set; }

        /// <summary>
        /// Gets or sets DateReversed 
        /// </summary>
        [Display(Name = "DateReversed", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.DateReversed, Id = Index.DateReversed, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateReversed { get; set; }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PostedPaymentDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [Display(Name = "DocumentNumber", ResourceType = typeof(APCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets RateOperator 
        /// </summary>
        [Display(Name = "RateOperator", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateOperator { get; set; }

        /// <summary>
        /// Gets or sets PaymentType 
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets ClientUniqueID 
        /// </summary>
        [Display(Name = "ClientUniqueID", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.ClientUniqueID, Id = Index.ClientUniqueID, FieldType = EntityFieldType.Long, Size = 4)]
        public long ClientUniqueID { get; set; }

        /// <summary>
        /// Gets or sets DrillDownApplicationSource 
        /// </summary>
        [Display(Name = "DrillDownApplicationSource", ResourceType = typeof(PaymentInquiryResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DrillDownApplicationSource, Id = Index.DrillDownApplicationSource, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string DrillDownApplicationSource { get; set; }

        /// <summary>
        /// Gets or sets DrillDownType 
        /// </summary>
        [Display(Name = "DrillDownType", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.DrillDownType, Id = Index.DrillDownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrillDownType { get; set; }

        /// <summary>
        /// Gets or sets DrillDownLinkNumber 
        /// </summary>
        [Display(Name = "DrillDownLinkNumber", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.DrillDownLinkNumber, Id = Index.DrillDownLinkNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrillDownLinkNumber { get; set; }

        /// <summary>
        /// Gets or sets GOrLAccount 
        /// </summary>
        [Display(Name = "GLAccount", ResourceType = typeof(APCommonResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets MiscPaymentFlag 
        /// </summary>
        [Display(Name = "MiscPaymentFlag", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.MiscPaymentFlag, Id = Index.MiscPaymentFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public int MiscPaymentFlag { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden JobRelated { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber 
        /// </summary>
        [Display(Name = "InvoiceNumber", ResourceType = typeof(APCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets CalculateTaxAmountControl 
        /// </summary>
        [Display(Name = "CalculateTaxAmountControl", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.CalculateTaxAmountControl, Id = Index.CalculateTaxAmountControl, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateTaxAmountControl CalculateTaxAmountControl { get; set; }

        /// <summary>
        /// Gets or sets CalculateTaxBaseControl 
        /// </summary>
        [Display(Name = "CalculateTaxBaseControl", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.CalculateTaxBaseControl, Id = Index.CalculateTaxBaseControl, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateTaxAmountControl CalculateTaxBaseControl { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [Display(Name = "TaxGroup", ResourceType = typeof(APCommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1 
        /// </summary>
        [Display(Name = "TaxAuthority1", ResourceType = typeof(PaymentInquiryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2 
        /// </summary>
        [Display(Name = "TaxAuthority2", ResourceType = typeof(PaymentInquiryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3 
        /// </summary>
        [Display(Name = "TaxAuthority3", ResourceType = typeof(PaymentInquiryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4 
        /// </summary>
        [Display(Name = "TaxAuthority4", ResourceType = typeof(PaymentInquiryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5 
        /// </summary>
        [Display(Name = "TaxAuthority5", ResourceType = typeof(PaymentInquiryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1 
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2 
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3 
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4 
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5 
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1 
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2 
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3 
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4 
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5 
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal 
        /// </summary>
        [Display(Name = "TaxTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets DistAmountNetofTaxes 
        /// </summary>
        [Display(Name = "DistAmountNetofTaxes", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.DistAmountNetofTaxes, Id = Index.DistAmountNetofTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistAmountNetofTaxes { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedTotal 
        /// </summary>
        [Display(Name = "TaxAllocatedTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxAllocatedTotal, Id = Index.TaxAllocatedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxExpensedTotal 
        /// </summary>
        [Display(Name = "TaxExpensedTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxExpensedTotal, Id = Index.TaxExpensedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpensedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableTotal 
        /// </summary>
        [Display(Name = "TaxRecoverableTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxRecoverableTotal, Id = Index.TaxRecoverableTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCode 
        /// </summary>
        [Display(Name = "TaxReportingCurrencyCode", ResourceType = typeof(PaymentInquiryResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCalculateMethod 
        /// </summary>
        [Display(Name = "TaxReportingCalculateMethod", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingCalculateMethod, Id = Index.TaxReportingCalculateMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateTaxAmountControl TaxReportingCalculateMethod { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchangeRate 
        /// </summary>
        [Display(Name = "TaxReportingExchangeRate", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingExchangeRate, Id = Index.TaxReportingExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType 
        /// </summary>
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(PaymentInquiryResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate 
        /// </summary>
        [Display(Name = "TaxReportingRateDate", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperator 
        /// </summary>
        [Display(Name = "TaxReportingRateOperator", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingRateOperator, Id = Index.TaxReportingRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1 
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2 
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3 
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4 
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5 
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotal 
        /// </summary>
        [Display(Name = "TaxReportingTotal", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TaxReportingTotal, Id = Index.TaxReportingTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedTotal 
        /// </summary>
        [Display(Name = "TaxReportingAllocatedTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedTotal, Id = Index.TaxReportingAllocatedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedTotal 
        /// </summary>
        [Display(Name = "TaxReportingExpensedTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedTotal, Id = Index.TaxReportingExpensedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableTotal 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableTotal, Id = Index.TaxReportingRecoverableTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase1 
        /// </summary>
        [Display(Name = "FuncTaxBase1", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxBase1, Id = Index.FuncTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase2 
        /// </summary>
        [Display(Name = "FuncTaxBase2", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxBase2, Id = Index.FuncTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase3 
        /// </summary>
        [Display(Name = "FuncTaxBase3", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxBase3, Id = Index.FuncTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase4 
        /// </summary>
        [Display(Name = "FuncTaxBase4", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxBase4, Id = Index.FuncTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase5 
        /// </summary>
        [Display(Name = "FuncTaxBase5", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxBase5, Id = Index.FuncTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount1 
        /// </summary>
        [Display(Name = "FuncTaxAmount1", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAmount1, Id = Index.FuncTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount2 
        /// </summary>
        [Display(Name = "FuncTaxAmount2", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAmount2, Id = Index.FuncTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount3 
        /// </summary>
        [Display(Name = "FuncTaxAmount3", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAmount3, Id = Index.FuncTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount4 
        /// </summary>
        [Display(Name = "FuncTaxAmount5", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAmount4, Id = Index.FuncTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount5 
        /// </summary>
        [Display(Name = "FuncTaxAmount5", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAmount5, Id = Index.FuncTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxTotal 
        /// </summary>
        [Display(Name = "FuncTaxTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxTotal, Id = Index.FuncTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncDistAmountNetofTaxes 
        /// </summary>
        [Display(Name = "FuncDistAmountNetofTaxes", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncDistAmountNetofTaxes, Id = Index.FuncDistAmountNetofTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDistAmountNetofTaxes { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedTotal 
        /// </summary>
        [Display(Name = "FuncTaxAllocatedTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedTotal, Id = Index.FuncTaxAllocatedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpensedTotal 
        /// </summary>
        [Display(Name = "FuncTaxExpensedTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxExpensedTotal, Id = Index.FuncTaxExpensedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpensedTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableTotal 
        /// </summary>
        [Display(Name = "FuncTaxRecoverableTotal", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableTotal, Id = Index.FuncTaxRecoverableTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableTotal { get; set; }

        /// <summary>
        /// Gets or sets NumberofAdvanceCreditClaims 
        /// </summary>
        [Display(Name = "NumberofAdvanceCreditClaims", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.NumberofAdvanceCreditClaims, Id = Index.NumberofAdvanceCreditClaims, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofAdvanceCreditClaims { get; set; }

        /// <summary>
        /// Gets or sets TotalAdvanceCreditClaim 
        /// </summary>
        [Display(Name = "TotalAdvanceCreditClaim", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.TotalAdvanceCreditClaim, Id = Index.TotalAdvanceCreditClaim, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdvanceCreditClaim { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalAdvanceCreditClaim 
        /// </summary>
        [Display(Name = "TotalAdvanceCreditClaim", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.FuncTotalAdvanceCreditClaim, Id = Index.FuncTotalAdvanceCreditClaim, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalAdvanceCreditClaim { get; set; }

        /// <summary>
        /// Gets or sets PostingDate 
        /// </summary>
        [Display(Name = "PostingDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PostingDate { get; set; }

        #region Custom Properties

        /// <summary>
        /// Gets or sets the Vendor Currency
        /// </summary>
        public string VendorCurrency { get; set; }

        /// <summary>
        /// A string value set while BankRateOverridden is selected
        /// </summary>
        public string BankRateOverriddenName
        {
            get { return EnumUtility.GetStringValue(BankRateOverridden); }
        }

        /// <summary>
        /// A string value of CheckCleared property
        /// </summary>
        public string CheckClearedName
        {
            get { return EnumUtility.GetStringValue(CheckCleared); }
        }

        /// <summary>
        /// A string value of DocumentType property
        /// </summary>
        public string DocumentTypeName
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// A string value of PaymentType property
        /// </summary>
        public string PaymentTypeName
        {
            get { return EnumUtility.GetStringValue(PaymentType); }
        }

        /// <summary>
        /// A string value of JobRelatedName property
        /// </summary>
        public string JobRelatedName
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// A string value of JobRelatedName property
        /// </summary>
        public string CalculateTaxAmountControlName
        {
            get { return EnumUtility.GetStringValue(CalculateTaxAmountControl); }
        }

        /// <summary>
        /// A string value of JobRelatedName property
        /// </summary>
        public string CalculateTaxBaseControlName
        {
            get { return EnumUtility.GetStringValue(CalculateTaxBaseControl); }
        }

        /// <summary>
        /// A string value of JobRelatedName property
        /// </summary>
        public string TaxReportingCalculateMethodName
        {
            get { return EnumUtility.GetStringValue(TaxReportingCalculateMethod); }
        }

        #endregion

    }
}
