// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.InvoiceEntry;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for Invoice Detail Optional Fields
    /// </summary>
    public partial class InvoiceOptionalFields : BaseInvoiceOptionalField
    {
        /// <summary>
        /// Gets or sets the serial number.
        /// </summary>
        public long SerialNumber { get; set; }
    }
}
