// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Partial class for ClearStatistic
    /// </summary>
    public partial class ClearStatistic : ModelBase
    {
        /// <summary>
        /// Gets or sets STRTVENID
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.STRTVENID, Id = Index.STRTVENID, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string STRTVENID { get; set; }

        /// <summary>
        /// Gets or sets ENDVENID
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ENDVENID, Id = Index.ENDVENID, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ENDVENID { get; set; }

        /// <summary>
        /// Gets or sets ClearFromGroupCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ClearFromGroupCode, Id = Index.ClearFromGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ClearFromGroupCode { get; set; }

        /// <summary>
        /// Gets or sets ClearThruGroupCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ClearThruGroupCode, Id = Index.ClearThruGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ClearThruGroupCode { get; set; }

        /// <summary>
        /// Gets or sets STRTCCSID
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.STRTCCSID, Id = Index.STRTCCSID, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string STRTCCSID { get; set; }

        /// <summary>
        /// Gets or sets ENDCCSID
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ENDCCSID, Id = Index.ENDCCSID, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ENDCCSID { get; set; }

        /// <summary>
        /// Gets or sets Through1099CPRSYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Through1099CPRSYear, Id = Index.Through1099CPRSYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string Through1099CPRSYear { get; set; }

        /// <summary>
        /// Gets or sets Through1099CPRSPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Through1099CPRSPeriod, Id = Index.Through1099CPRSPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string Through1099CPRSPeriod { get; set; }

        /// <summary>
        /// Gets or sets ClearVendorStatistics
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ClearVendorStatistics, Id = Index.ClearVendorStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public ClearVendorStatistics ClearVendorStatistics { get; set; }

        /// <summary>
        /// Gets or sets ClearGroupStatistics
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ClearGroupStatistics, Id = Index.ClearGroupStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public ClearGroupStatistics ClearGroupStatistics { get; set; }

        /// <summary>
        /// Gets or sets Clear1099CPRSStatistics
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Clear1099CPRSStatistics, Id = Index.Clear1099CPRSStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public Clear1099CPRSStatistics Clear1099CPRSStatistics { get; set; }

        /// <summary>
        /// Gets or sets ThroughVendorYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ThroughVendorYear, Id = Index.ThroughVendorYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string ThroughVendorYear { get; set; }

        /// <summary>
        /// Gets or sets ThroughVendorPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ThroughVendorPeriod, Id = Index.ThroughVendorPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string ThroughVendorPeriod { get; set; }

        /// <summary>
        /// Gets or sets ThroughGroupYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ThroughGroupYear, Id = Index.ThroughGroupYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string ThroughGroupYear { get; set; }

        /// <summary>
        /// Gets or sets ThroughGroupPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ThroughGroupPeriod, Id = Index.ThroughGroupPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string ThroughGroupPeriod { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ClearVendorStatistics string value
        /// </summary>
        public string ClearVendorStatisticsString
        {
            get { return EnumUtility.GetStringValue(ClearVendorStatistics); }
        }

        /// <summary>
        /// Gets ClearGroupStatistics string value
        /// </summary>
        public string ClearGroupStatisticsString
        {
            get { return EnumUtility.GetStringValue(ClearGroupStatistics); }
        }

        /// <summary>
        /// Gets Clear1099CPRSStatistics string value
        /// </summary>
        public string Clear1099CPRSStatisticsString
        {
            get { return EnumUtility.GetStringValue(Clear1099CPRSStatistics); }
        }
        /// <summary>
        /// 
        /// </summary>
        [Display(Name = "VendorStatistics", ResourceType = typeof(ClearStatisticResx))]
        public bool VendorStatistics { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [Display(Name = "VendorGroupStatistics", ResourceType = typeof(APCommonResx))]
        public bool VendorGroupStatistics { get; set; }

        /// <summary>
        /// Gets or sets MaxFromPerd
        /// </summary>
        public int MaxVendorPerd { get; set; }

        /// <summary>
        /// Gets or sets MinFromPerd
        /// </summary>
        public int MinVendorPerd { get; set; }

        #endregion
    }
}
