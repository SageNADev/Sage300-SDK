// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
	/// <summary>
	/// Partial class for ClearDeletedAndPostedBatche
	/// </summary>
	public partial class ClearDeletedAndPostedBatch : ModelBase
	{
		/// <summary>
		/// Gets or sets FromBatchNumber
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.FromBatchNumber, Id = Index.FromBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
		public decimal FromBatchNumber { get; set; }

		/// <summary>
		/// Gets or sets ToBatchNumber
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ToBatchNumber, Id = Index.ToBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
		public decimal ToBatchNumber { get; set; }

		/// <summary>
		/// Gets or sets BatchType
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Int, Size = 2)]
		public BatchType BatchType { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets BatchType string value
		/// </summary>
		public string BatchTypeString
		{
			get { return EnumUtility.GetStringValue(BatchType); }
		}

		#endregion
	}
}
