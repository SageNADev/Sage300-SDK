// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
	/// <summary>
	/// Partial class for DeleteInactiveRecord
	/// </summary>
	public partial class DeleteInactiveRecord : ModelBase
	{
		/// <summary>
		/// Gets or sets ClearFromVendorNumber
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ClearFromVendorNumber, Id = Index.ClearFromVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string ClearFromVendorNumber { get; set; }

		/// <summary>
		/// Gets or sets ClearThruVendorNumber
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ClearThruVendorNumber, Id = Index.ClearThruVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string ClearThruVendorNumber { get; set; }

		/// <summary>
		/// Gets or sets ClearFromGroupCode
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ClearFromGroupCode, Id = Index.ClearFromGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string ClearFromGroupCode { get; set; }

		/// <summary>
		/// Gets or sets ClearThruGroupCode
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ClearThruGroupCode, Id = Index.ClearThruGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string ClearThruGroupCode { get; set; }

		/// <summary>
		/// Gets or sets ClearRemitToFromVendorNo
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ClearRemitToFromVendorNo, Id = Index.ClearRemitToFromVendorNo, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string ClearRemitToFromVendorNo { get; set; }

		/// <summary>
		/// Gets or sets ClearRemitToThruVendorNo
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ClearRemitToThruVendorNo, Id = Index.ClearRemitToThruVendorNo, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string ClearRemitToThruVendorNo { get; set; }

		/// <summary>
		/// Gets or sets ClearFromDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
		[ViewField(Name = Fields.ClearFromDate, Id = Index.ClearFromDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? ClearFromDate { get; set; }

		/// <summary>
		/// Gets or sets ClearThruDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
		[ViewField(Name = Fields.ClearThruDate, Id = Index.ClearThruDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? ClearThruDate { get; set; }

		/// <summary>
		/// Gets or sets ClearInactiveVendors
		/// </summary>
		[ViewField(Name = Fields.ClearInactiveVendors, Id = Index.ClearInactiveVendors, FieldType = EntityFieldType.Int, Size = 2)]
		public ClearInactiveVendors ClearInactiveVendors { get; set; }

		/// <summary>
		/// Gets or sets ClearInactiveGroups
		/// </summary>
		[ViewField(Name = Fields.ClearInactiveGroups, Id = Index.ClearInactiveGroups, FieldType = EntityFieldType.Int, Size = 2)]
		public ClearInactiveGroups ClearInactiveGroups { get; set; }

		/// <summary>
		/// Gets or sets ClearInactiveRemitToLocation
		/// </summary>
		[ViewField(Name = Fields.ClearInactiveRemitToLocation, Id = Index.ClearInactiveRemitToLocation, FieldType = EntityFieldType.Int, Size = 2)]
		public ClearInactiveRemitToLocation ClearInactiveRemitToLocation { get; set; }

		/// <summary>
		/// Gets or sets ClearInactiveRecurringPayable
		/// </summary>
		[ViewField(Name = Fields.ClearInactiveRecurringPayable, Id = Index.ClearInactiveRecurringPayable, FieldType = EntityFieldType.Int, Size = 2)]
		public ClearInactiveRecurringPayable ClearInactiveRecurringPayable { get; set; }

		/// <summary>
		/// Gets or sets ClearFromRecurringPayable
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ClearFromRecurringPayable, Id = Index.ClearFromRecurringPayable, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-12C")]
		public string ClearFromRecurringPayable { get; set; }

		/// <summary>
		/// Gets or sets ClearThruRecurringPayable
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ClearThruRecurringPayable, Id = Index.ClearThruRecurringPayable, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
		public string ClearThruRecurringPayable { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets ClearInactiveVendors string value
		/// </summary>
		public string ClearInactiveVendorsString
		{
			get { return EnumUtility.GetStringValue(ClearInactiveVendors); }
		}

        /// <summary>
        /// Gets or sets ClearInactiveVendors bool value
        /// </summary>
        public bool ClearInactiveVendorsBool
        {
            get
            {
                return ClearInactiveVendors == ClearInactiveVendors.Yes;
            }
            set
            {
                //If Checkbox is checked set ClearInactiveVendors as No to return true value;
                ClearInactiveVendors = value ? ClearInactiveVendors.Yes : ClearInactiveVendors.No;
            }
        }

		/// <summary>
		/// Gets ClearInactiveGroups string value
		/// </summary>
		public string ClearInactiveGroupsString
		{
			get { return EnumUtility.GetStringValue(ClearInactiveGroups); }
		}

        /// <summary>
        /// Gets or sets ClearInactiveGroups bool value
        /// </summary>
        public bool ClearInactiveGroupsBool
        {
            get
            {
                return ClearInactiveGroups == ClearInactiveGroups.Yes;
            }
            set
            {
                //If Checkbox is checked set ClearInactiveGroups as No to return true value;
                ClearInactiveGroups = value ? ClearInactiveGroups.Yes : ClearInactiveGroups.No;
            }
        }

		/// <summary>
		/// Gets ClearInactiveRemitToLocation string value
		/// </summary>
		public string ClearInactiveRemitToLocationString
		{
			get { return EnumUtility.GetStringValue(ClearInactiveRemitToLocation); }
		}

        /// <summary>
        /// Gets or sets ClearInactiveRemitToLocation bool value
        /// </summary>
        public bool ClearInactiveRemitToLocationBool
        {
            get
            {
                return ClearInactiveRemitToLocation == ClearInactiveRemitToLocation.Yes;
            }
            set
            {
                //If Checkbox is checked set ClearInactiveRemitToLocation as No to return true value;
                ClearInactiveRemitToLocation = value ? ClearInactiveRemitToLocation.Yes : ClearInactiveRemitToLocation.No;
            }
        }

		/// <summary>
		/// Gets ClearInactiveRecurringPayable string value
		/// </summary>
		public string ClearInactiveRecurringPayableString
		{
			get { return EnumUtility.GetStringValue(ClearInactiveRecurringPayable); }
		}

        /// <summary>
        /// Gets or sets ClearInactiveRecurringPayable bool value
        /// </summary>
        public bool ClearInactiveRecurringPayableBool
        {
            get
            {
                return ClearInactiveRecurringPayable == ClearInactiveRecurringPayable.Yes;
            }
            set
            {
                //If Checkbox is checked set ClearInactiveRecurringPayable as No to return true value;
                ClearInactiveRecurringPayable = value ? ClearInactiveRecurringPayable.Yes : ClearInactiveRecurringPayable.No;
            }
        }

		#endregion
	}
}
