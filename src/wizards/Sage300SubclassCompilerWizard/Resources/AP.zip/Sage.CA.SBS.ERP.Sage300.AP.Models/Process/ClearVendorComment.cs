// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
	/// <summary>
	/// Partial class for ClearVendorComment
	/// </summary>
	public partial class ClearVendorComment : ModelBase
	{
		/// <summary>
		/// Gets or sets ClearFromVendorNumber
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ClearFromVendorNumber, Id = Index.ClearFromVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string ClearFromVendorNumber { get; set; }

		/// <summary>
		/// Gets or sets ClearThruVendorNumber
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ClearThruVendorNumber, Id = Index.ClearThruVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string ClearThruVendorNumber { get; set; }

		/// <summary>
		/// Gets or sets ClearThruDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ClearThruDate, Id = Index.ClearThruDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ClearThruDate { get; set; }

		#region UI Strings

		#endregion
	}
}
