// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    public partial class AgeRetainageDocument : ModelBase
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="AgeRetainageDocument"/> class.
        /// </summary>
        public AgeRetainageDocument()
        {
            Cutoffby = Cutoffby.DocDate;
            FuncOrVendorCurrency = FuncOrVendorCurrency.VendorCurrency;
            ATBOrOverdueRecReport = ATBOrOverdueRecReport.FutureRetainage;
            DetailOrSummaryReport = DetailOrSummaryReport.DetailbyDate;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets RunDate 
        /// </summary>
        [Display(Name = "RunDate", ResourceType = typeof(AgeRetainageResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RunDate, Id = Index.RunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RunDate { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDateCutoffDate 
        /// </summary>
        [Display(Name = "RetainageDueDateCutoffDate", ResourceType = typeof(AgeRetainageResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageDueDateCutoffDate, Id = Index.RetainageDueDateCutoffDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RetainageDueDateCutoffDate { get; set; }

        /// <summary>
        /// Gets or sets Cutoffby 
        /// </summary>
        [Display(Name = "Cutoffby", ResourceType = typeof(AgeRetainageResx))]
        [ViewField(Name = Fields.Cutoffby, Id = Index.Cutoffby, FieldType = EntityFieldType.Int, Size = 2)]
        public Cutoffby Cutoffby { get; set; }

        /// <summary>
        /// Gets or sets Year 
        /// </summary>
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period 
        /// </summary>
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string Period { get; set; }

        /// <summary>
        /// Gets or sets FuncOrVendorCurrency 
        /// </summary>
        [Display(Name = "FuncOrVendorCurrency", ResourceType = typeof(AgeRetainageResx))]
        [ViewField(Name = Fields.FuncOrVendorCurrency, Id = Index.FuncOrVendorCurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public FuncOrVendorCurrency FuncOrVendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets ATBOrOverdueRecReport 
        /// </summary>
        [Display(Name = "ATBOrOverdueRecReport", ResourceType = typeof(AgeRetainageResx))]
        [ViewField(Name = Fields.ATBOrOverdueRecReport, Id = Index.ATBOrOverdueRecReport, FieldType = EntityFieldType.Int, Size = 2)]
        public ATBOrOverdueRecReport ATBOrOverdueRecReport { get; set; }

        /// <summary>
        /// Gets or sets DetailOrSummaryReport 
        /// </summary>
        [Display(Name = "DetailOrSummaryReport", ResourceType = typeof(AgeRetainageResx))]
        [ViewField(Name = Fields.DetailOrSummaryReport, Id = Index.DetailOrSummaryReport, FieldType = EntityFieldType.Int, Size = 2)]
        public DetailOrSummaryReport DetailOrSummaryReport { get; set; }

        /// <summary>
        /// Gets or sets Current 
        /// </summary>
        [Display(Name = "Current", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Current, Id = Index.Current, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal Current { get; set; }

        /// <summary>
        /// Gets or sets FirstPeriod 
        /// </summary>
        [Display(Name = "_1st", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.FirstPeriod, Id = Index.FirstPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal FirstPeriod { get; set; }

        /// <summary>
        /// Gets or sets SecondPeriod 
        /// </summary>
        [Display(Name = "_2nd", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.SecondPeriod, Id = Index.SecondPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal SecondPeriod { get; set; }

        /// <summary>
        /// Gets or sets ThirdPeriod 
        /// </summary>
        [Display(Name = "_3rd", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ThirdPeriod, Id = Index.ThirdPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal ThirdPeriod { get; set; }

        /// <summary>
        /// Gets or sets Range1From 
        /// </summary>
        [ViewField(Name = Fields.Range1From, Id = Index.Range1From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range1From { get; set; }

        /// <summary>
        /// Gets or sets Range1To 
        /// </summary>
        [ViewField(Name = Fields.Range1To, Id = Index.Range1To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range1To { get; set; }

        /// <summary>
        /// Gets or sets Range1IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range1IndexValue, Id = Index.Range1IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range1IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range2From 
        /// </summary>
        [ViewField(Name = Fields.Range2From, Id = Index.Range2From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range2From { get; set; }

        /// <summary>
        /// Gets or sets Range2To 
        /// </summary>
        [ViewField(Name = Fields.Range2To, Id = Index.Range2To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range2To { get; set; }

        /// <summary>
        /// Gets or sets Range2IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range2IndexValue, Id = Index.Range2IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range2IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range3From 
        /// </summary>
        [ViewField(Name = Fields.Range3From, Id = Index.Range3From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range3From { get; set; }

        /// <summary>
        /// Gets or sets Range3To 
        /// </summary>
        [ViewField(Name = Fields.Range3To, Id = Index.Range3To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range3To { get; set; }

        /// <summary>
        /// Gets or sets Range3IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range3IndexValue, Id = Index.Range3IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range3IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range4From 
        /// </summary>
        [ViewField(Name = Fields.Range4From, Id = Index.Range4From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range4From { get; set; }

        /// <summary>
        /// Gets or sets Range4To 
        /// </summary>
        [ViewField(Name = Fields.Range4To, Id = Index.Range4To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range4To { get; set; }

        /// <summary>
        /// Gets or sets Range4IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range4IndexValue, Id = Index.Range4IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range4IndexValue { get; set; }

        /// <summary>
        /// Gets or sets SequenceNumber 
        /// </summary>
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets FieldName1 
        /// </summary>
        [ViewField(Name = Fields.FieldName1, Id = Index.FieldName1, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName1 { get; set; }

        /// <summary>
        /// Gets or sets FieldName2 
        /// </summary>
        [ViewField(Name = Fields.FieldName2, Id = Index.FieldName2, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName2 { get; set; }

        /// <summary>
        /// Gets or sets FieldName3 
        /// </summary>
        [ViewField(Name = Fields.FieldName3, Id = Index.FieldName3, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName3 { get; set; }

        /// <summary>
        /// Gets or sets FieldName4 
        /// </summary>
        [ViewField(Name = Fields.FieldName4, Id = Index.FieldName4, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName4 { get; set; }

        /// <summary>
        /// Gets or sets IncludeTaxes 
        /// </summary>
        [Display(Name = "IncludeTaxes", ResourceType = typeof(AgeRetainageResx))]
        [ViewField(Name = Fields.IncludeTaxes, Id = Index.IncludeTaxes, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeTaxes { get; set; }

        #endregion
    }
}
