// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Model Class for SelectVendor
    /// </summary>
    public partial class SelectVendor : ModelBase
    {
        #region Model properties

        /// <summary>
        /// Gets or sets SequenceNumber 
        /// </summary>
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets Range1From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range1From, Id = Index.Range1From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range1From { get; set; }

        /// <summary>
        /// Gets or sets Range1To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range1To, Id = Index.Range1To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range1To { get; set; }

        /// <summary>
        /// Gets or sets Range1IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range1IndexValue, Id = Index.Range1IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range1IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range2From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range2From, Id = Index.Range2From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range2From { get; set; }

        /// <summary>
        /// Gets or sets Range2To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range2To, Id = Index.Range2To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range2To { get; set; }

        /// <summary>
        /// Gets or sets Range2IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range2IndexValue, Id = Index.Range2IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range2IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range3From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range3From, Id = Index.Range3From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range3From { get; set; }

        /// <summary>
        /// Gets or sets Range3To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range3To, Id = Index.Range3To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range3To { get; set; }

        /// <summary>
        /// Gets or sets Range3IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range3IndexValue, Id = Index.Range3IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range3IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range4From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range4From, Id = Index.Range4From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range4From { get; set; }

        /// <summary>
        /// Gets or sets Range4To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range4To, Id = Index.Range4To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range4To { get; set; }

        /// <summary>
        /// Gets or sets Range4IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range4IndexValue, Id = Index.Range4IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range4IndexValue { get; set; }

        /// <summary>
        /// Gets or sets FieldName1 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FieldName1, Id = Index.FieldName1, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName1 { get; set; }

        /// <summary>
        /// Gets or sets FieldName2 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FieldName2, Id = Index.FieldName2, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName2 { get; set; }

        /// <summary>
        /// Gets or sets FieldName3 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FieldName3, Id = Index.FieldName3, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName3 { get; set; }

        /// <summary>
        /// Gets or sets FieldName4 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FieldName4, Id = Index.FieldName4, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName4 { get; set; }

        /// <summary>
        /// Gets or sets IncludeZeroBalances 
        /// </summary>
        [Display(Name = "IncludeVendorsWithZeroBalance", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludeZeroBalances, Id = Index.IncludeZeroBalances, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeZeroBalances { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex1 
        /// </summary>
        [ViewField(Name = Fields.SortFieldIndex1, Id = Index.SortFieldIndex1, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldIndex1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex2 
        /// </summary>
        [ViewField(Name = Fields.SortFieldIndex2, Id = Index.SortFieldIndex2, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldIndex2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex3 
        /// </summary>
        [ViewField(Name = Fields.SortFieldIndex3, Id = Index.SortFieldIndex3, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldIndex3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex4 
        /// </summary>
        [ViewField(Name = Fields.SortFieldIndex4, Id = Index.SortFieldIndex4, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldIndex4 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName1 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldName1, Id = Index.SortFieldName1, FieldType = EntityFieldType.Char, Size = 19)]
        public string SortFieldName1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName2 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldName2, Id = Index.SortFieldName2, FieldType = EntityFieldType.Char, Size = 19)]
        public string SortFieldName2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName3 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldName3, Id = Index.SortFieldName3, FieldType = EntityFieldType.Char, Size = 19)]
        public string SortFieldName3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName4 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldName4, Id = Index.SortFieldName4, FieldType = EntityFieldType.Char, Size = 19)]
        public string SortFieldName4 { get; set; }

        /// <summary>
        /// Gets or sets DisplayMeter 
        /// </summary>
        [ViewField(Name = Fields.DisplayMeter, Id = Index.DisplayMeter, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeZeroBalances DisplayMeter { get; set; }

        /// <summary>
        /// Gets or sets SortRecords 
        /// </summary>
        [ViewField(Name = Fields.SortRecords, Id = Index.SortRecords, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeZeroBalances SortRecords { get; set; }

        /// <summary>
        /// Gets or Sets OptFldsVisible
        /// </summary>
        public bool OptFldsVisible { get; set; }

        /// <summary>
        /// Gets or Sets Session Date
        /// </summary>
        public DateTime SessionDate { get; set; }

        #endregion
    }
}
