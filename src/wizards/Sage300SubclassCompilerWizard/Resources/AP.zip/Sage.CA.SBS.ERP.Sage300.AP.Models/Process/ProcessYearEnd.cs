/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Contains list of ProcessYearEnd Properties 
    /// </summary>
    public partial class ProcessYearEnd : ModelBase
    {
        #region Model properties

        /// <summary>
        /// Gets or sets ResetBatchNumbers 
        /// </summary>
        [Display(Name = "ResetBatchNumbers", ResourceType = typeof(ProcessYearEndResx))]
        [ViewField(Name = Fields.ResetBatchNumbers, Id = Index.ResetBatchNumbers, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ResetBatchNumbers { get; set; }

        /// <summary>
        /// Gets or sets ClearPaidInvoices 
        /// </summary>
        [Display(Name = "ClearPaidInvoices", ResourceType = typeof(ProcessYearEndResx))]
        [ViewField(Name = Fields.ClearPaidInvoices, Id = Index.ClearPaidInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ClearPaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets RollVendorStatstoLastYr 
        /// </summary>
        [Display(Name = "RollVendorStatstoLastYr", ResourceType = typeof(ProcessYearEndResx))]
        [ViewField(Name = Fields.RollVendorStatstoLastYr, Id = Index.RollVendorStatstoLastYr, FieldType = EntityFieldType.Int, Size = 2)]
        public bool RollVendorStatstoLastYr { get; set; }

        /// <summary>
        /// Gets or sets ClearRecurringPayables 
        /// </summary>
        [Display(Name = "ClearRecurringPayables", ResourceType = typeof(ProcessYearEndResx))]
        [ViewField(Name = Fields.ClearRecurringPayables, Id = Index.ClearRecurringPayables, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ClearRecurringPayables { get; set; }

        #endregion
    }
}
