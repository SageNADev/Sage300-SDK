// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. 

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// CprsAmountChecking Process class
    /// </summary>
	public partial class CprsAmountChecking : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets FromVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.FromVendorNumber, Id = Index.FromVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
 		public string FromVendorNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets ToVendorNumber 
        /// </summary>
         [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.ToVendorNumber, Id = Index.ToVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
 		public string ToVendorNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxReportingType 
        /// </summary>        
 		[ViewField(Name = Fields.TaxReportingType, Id = Index.TaxReportingType, FieldType = EntityFieldType.Int, Size = 2)]
 		public TaxReportingType TaxReportingType {get; set;}
		 
  		/// <summary>
        /// Gets or sets FromCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.FromCode, Id = Index.FromCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string FromCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets ToCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.ToCode, Id = Index.ToCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string ToCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
 		public string Year {get; set;}
		 
  		/// <summary>
        /// Gets or sets Atleastonevendorhasreportab 
        /// </summary>
        
 		[ViewField(Name = Fields.Atleastonevendorhasreportab, Id = Index.Atleastonevendorhasreportab, FieldType = EntityFieldType.Bool, Size = 2)]
 		public bool Atleastonevendorhasreportab {get; set;}
		 
  		/// <summary>
        /// Gets or sets CommandCode 
        /// </summary>

        [ViewField(Name = Fields.CommandCode, Id = Index.CommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public CommandCodes CommandCode { get; set; }
		 
  		/// <summary>
        /// Gets or sets FileName 
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.FileName, Id = Index.FileName, FieldType = EntityFieldType.Char, Size = 255)]
 		public string FileName {get; set;}

        /// <summary>
        /// Gets or sets File Type
        /// </summary>
        [ViewField(Name = Fields.FormType, Id = Index.FormType, FieldType = EntityFieldType.Int, Size = 2)]
        public int FormType { get; set; } = (int)Print1099FormTypes._1099Misc;

        /// <summary>
        /// Gets or sets CompanyName
        /// </summary>
        [ViewField(Name = Fields.CompanyName, Id = Index.CompanyName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CompanyName { get; set; }

        /// <summary>
        /// Gets or sets ForeignEntity
        /// </summary>
        [ViewField(Name = Fields.ForeignEntity, Id = Index.ForeignEntity, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForeignEntity { get; set; }

        /// <summary>
        /// Gets or sets LegalName
        /// </summary>
        [ViewField(Name = Fields.LegalName, Id = Index.LegalName, FieldType = EntityFieldType.Char, Size = 60)]
        public string LegalName { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1
        /// </summary>
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2
        /// </summary>
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State
        /// </summary>
        [ViewField(Name = Fields.State, Id = Index.State, FieldType = EntityFieldType.Char, Size = 30)]
        public string State { get; set; }

        /// <summary>
        /// Gets or sets ZipCode
        /// </summary>
        [ViewField(Name = Fields.ZipCode, Id = Index.ZipCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets TaxNumber
        /// </summary>
        [ViewField(Name = Fields.TaxNumber, Id = Index.TaxNumber, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxNumber { get; set; }

        /// <summary>
        /// Gets or sets TaxNumberType
        /// </summary>
        [ViewField(Name = Fields.TaxNumberType, Id = Index.TaxNumberType, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxNumberType TaxNumberType { get; set; }

        /// <summary>
        /// Gets or sets Telephone
        /// </summary>
        [ViewField(Name = Fields.Telephone, Id = Index.Telephone, FieldType = EntityFieldType.Char, Size = 30)]
        public string Telephone { get; set; }

        /// <summary>
        /// Gets or sets Fax
        /// </summary>
        [ViewField(Name = Fields.Fax, Id = Index.Fax, FieldType = EntityFieldType.Char, Size = 30)]
        public string Fax { get; set; }

        /// <summary>
        /// Gets or sets Contact
        /// </summary>
        [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets Title
        /// </summary>
        [ViewField(Name = Fields.Title, Id = Index.Title, FieldType = EntityFieldType.Char, Size = 260)]
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets TransferAgent
        /// </summary>
        [ViewField(Name = Fields.TransferAgent, Id = Index.TransferAgent, FieldType = EntityFieldType.Char, Size = 260)]
        public string TransferAgent { get; set; }

        /// <summary>
        /// Gets or sets FullAUFFileName
        /// </summary>
        [ViewField(Name = Fields.FullAUFFileName, Id = Index.FullAUFFileName, FieldType = EntityFieldType.Char, Size = 260)]
        public string FullAUFFileName { get; set; }

        /// <summary>
        /// Gets or sets Success or Error value 
        /// </summary>
        public bool Check1099Records { get; set; }
    }
}
