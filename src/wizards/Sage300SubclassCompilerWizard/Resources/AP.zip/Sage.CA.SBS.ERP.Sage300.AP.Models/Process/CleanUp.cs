﻿// Copyright (c) 2025 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    public class CleanUp
    {
        /// <summary>
        /// the SelectSequence that the Select process generated and was used as part of the associated report
        /// </summary>
        public string SelectSequence { get; set; }
    }
}