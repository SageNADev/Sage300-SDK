/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Model base for CreateGLBatch
    /// </summary>
    public partial class CreateGLBatch : ModelBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or sets ProcessPaymentBatch 
        /// </summary>
        [Display(Name = "Payments", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ProcessPaymentBatch, Id = Index.ProcessPaymentBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ProcessPaymentBatch { get; set; }

        /// <summary>
        /// Gets or sets ThruPaymentPostingSeqNo 
        /// </summary>
        [Display(Name = "PaymentsPostingSequenceNumber", ResourceType = typeof(CreateGLBatchResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ThruPaymentPostingSeqNo, Id = Index.ThruPaymentPostingSeqNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal ThruPaymentPostingSeqNo { get; set; }

        /// <summary>
        /// Gets or sets ProcessInvoiceBatch 
        /// </summary>
        [Display(Name = "InvoiceBatches", ResourceType = typeof(CreateGLBatchResx))]
        [ViewField(Name = Fields.ProcessInvoiceBatch, Id = Index.ProcessInvoiceBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ProcessInvoiceBatch { get; set; }

        /// <summary>
        /// Gets or sets ThruInvoicePostingSeqNo 
        /// </summary>
        [Display(Name = "InvoicePostingSequenceNumber", ResourceType = typeof(CreateGLBatchResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ThruInvoicePostingSeqNo, Id = Index.ThruInvoicePostingSeqNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal ThruInvoicePostingSeqNo { get; set; }

        /// <summary>
        /// Gets or sets ProcessAdjustmentBatch 
        /// </summary>
        [Display(Name = "Adjustments", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ProcessAdjustmentBatch, Id = Index.ProcessAdjustmentBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ProcessAdjustmentBatch { get; set; }

        /// <summary>
        /// Gets or sets ThruAdjustmentPostingSeqNo 
        /// </summary>
        [Display(Name = "AdjustmentsPostingSequenceNumber", ResourceType = typeof(CreateGLBatchResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ThruAdjustmentPostingSeqNo, Id = Index.ThruAdjustmentPostingSeqNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal ThruAdjustmentPostingSeqNo { get; set; }

        /// <summary>
        /// Gets or sets ProcessRevalueBatch 
        /// </summary>

        //[ViewField(Name = Fields.ProcessRevalueBatch, Id = Index.ProcessRevalueBatch, FieldType = EntityFieldType.Int, Size = 2)]
        //public ProcessRevalueBatch ProcessRevalueBatch { get; set; }
        [Display(Name = "Revaluation", ResourceType = typeof(APCommonResx))]
        public bool ProcessRevalueBatch { get; set; }

        /// <summary>
        /// Gets or sets ThruRevaluePostingSeqNo 
        /// </summary>
        [Display(Name = "RevaluationPostingSequenceNumber", ResourceType = typeof(CreateGLBatchResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ThruRevaluePostingSeqNo, Id = Index.ThruRevaluePostingSeqNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal ThruRevaluePostingSeqNo { get; set; }

        /// <summary>
        /// Gets or Sets ActivateMultiCurrency
        /// </summary>
        public bool ActivateMultiCurrency { get; set; }

        #endregion
    }
}
