/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Model base for CreateRecurringPayableBatch
    /// </summary>
    public partial class CreateRecurPayBatch : ModelBase
    {
        /// <summary>
        /// Gets or sets RunDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RunDate", ResourceType = typeof(CreateRecurringPayableBatchResx))]
        [ViewField(Name = Fields.RunDate, Id = Index.RunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RunDate { get; set; }

        /// <summary>
        /// Gets or sets Mode 
        /// </summary>
        [ViewField(Name = Fields.Mode, Id = Index.Mode, FieldType = EntityFieldType.Int, Size = 2)]
        public int Mode { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDateType
        /// </summary>
        public InvoiceDateType DateType { get; set; }

        /// <summary>
        /// Gets or sets InvoiceBatchType
        /// </summary>
        public InvoiceBatchType BatchType { get; set; }

        /// <summary>
        /// Gets or sets SelectRecordsBy 
        /// </summary>
        [Display(Name = "SelectRecordsBy", ResourceType = typeof(CreateRecurringPayableBatchResx))]
        [ViewField(Name = Fields.SelectRecordsBy, Id = Index.SelectRecordsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public SelectRecordsBy SelectRecordsBy { get; set; }

        /// <summary>
        /// Gets or sets StartingRecurringPayableCode 
        /// </summary>
        [Display(Name = "StartingRecurringPayableCode", ResourceType = typeof(CreateRecurringPayableBatchResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingRecurringPayableCode, Id = Index.StartingRecurringPayableCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string StartingRecurringPayableCode { get; set; }

        /// <summary>
        /// Gets or sets EndingRecurringPayableCode 
        /// </summary>
        [Display(Name = "EndingRecurringPayableCode", ResourceType = typeof(CreateRecurringPayableBatchResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EndingRecurringPayableCode, Id = Index.EndingRecurringPayableCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string EndingRecurringPayableCode { get; set; }

        /// <summary>
        /// Gets or sets StartingVendorNumber 
        /// </summary>
        [Display(Name = "StartingRecurringPayableCode", ResourceType = typeof(CreateRecurringPayableBatchResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingVendorNumber, Id = Index.StartingVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string StartingVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets EndingVendorNumber 
        /// </summary>
        [Display(Name = "EndingRecurringPayableCode", ResourceType = typeof(CreateRecurringPayableBatchResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EndingVendorNumber, Id = Index.EndingVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string EndingVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets StartingVendorGroupCode 
        /// </summary>
        [Display(Name = "StartingRecurringPayableCode", ResourceType = typeof(CreateRecurringPayableBatchResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingVendorGroupCode, Id = Index.StartingVendorGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StartingVendorGroupCode { get; set; }

        /// <summary>
        /// Gets or sets EndingVendorGroupCode 
        /// </summary>
        [Display(Name = "EndingRecurringPayableCode", ResourceType = typeof(CreateRecurringPayableBatchResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EndingVendorGroupCode, Id = Index.EndingVendorGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EndingVendorGroupCode { get; set; }

        /// <summary>
        /// Gets or sets ScheduleKey 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ScheduleKey, Id = Index.ScheduleKey, FieldType = EntityFieldType.Char, Size = 12)]
        public string ScheduleKey { get; set; }

        /// <summary>
        /// Gets or sets ScheduleLink 
        /// </summary>
        [ViewField(Name = Fields.ScheduleLink, Id = Index.ScheduleLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ScheduleLink { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public int Status { get; set; }

        /// <summary>
        /// Gets or sets DateGenerationMethod 
        /// </summary>
        [ViewField(Name = Fields.DateGenerationMethod, Id = Index.DateGenerationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public DateGenerationMethod DateGenerationMethod { get; set; }

        /// <summary>
        /// Gets or sets BatchGenerationMethod 
        /// </summary>
        [Display(Name = "BatchGenerationMethod", ResourceType = typeof(CreateRecurringPayableBatchResx))]
        [ViewField(Name = Fields.BatchGenerationMethod, Id = Index.BatchGenerationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchGenerationMethod BatchGenerationMethod { get; set; }

        /// <summary>
        /// Gets or sets ForcedInvoiceDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ForcedInvoiceDate, Id = Index.ForcedInvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ForcedInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets AppendtoBatchNumber 
        /// </summary>
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(APCommonResx))]
        //[ViewField(Name = Fields.AppendToBatchNumber, Id = Index.AppendToBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal AppendToBatchNumber { get; set; }

    }
}
