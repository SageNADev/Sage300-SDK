// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Partial class for Create Retainage Document Batch
    /// </summary>
    public partial class CreateRetainageDocumentBatch : ModelBase
    {
        /// <summary>
        /// Gets or sets Run Date
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RunDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.RunDate, Id = Index.RunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RunDate { get; set; }

        /// <summary>
        /// Gets or sets Mode
        /// </summary>
        [Display(Name = "Mode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Mode, Id = Index.Mode, FieldType = EntityFieldType.Int, Size = 2)]
        public int Mode { get; set; }

        /// <summary>
        /// Gets or sets Select Records By
        /// </summary>
        [ViewField(Name = Fields.SelectRecordsBy, Id = Index.SelectRecordsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public SelectDocumentsBy SelectRecordsBy { get; set; }

        /// <summary>
        /// Gets or sets Starting Document Number
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingDocumentNumber, Id = Index.StartingDocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string StartingDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets Ending Document Number
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EndingDocumentNumber, Id = Index.EndingDocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string EndingDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets Starting Vendor Number
        /// </summary>
        [ViewField(Name = Fields.StartingVendorNumber, Id = Index.StartingVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string StartingVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets Ending Vendor Number
        /// </summary>
        [ViewField(Name = Fields.EndingVendorNumber, Id = Index.EndingVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string EndingVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets Starting Vendor Group Code
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingVendorGroupCode, Id = Index.StartingVendorGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StartingVendorGroupCode { get; set; }

        /// <summary>
        /// Gets or sets Ending Vendor Group Code
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EndingVendorGroupCode, Id = Index.EndingVendorGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EndingVendorGroupCode { get; set; }

        /// <summary>
        /// Gets or sets Include Invoice
        /// </summary>
        [ViewField(Name = Fields.IncludeInvoice, Id = Index.IncludeInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeInvoice IncludeInvoice { get; set; }

        /// <summary>
        /// Gets or sets Include Debit Note
        /// </summary>
        [ViewField(Name = Fields.IncludeDebitNote, Id = Index.IncludeDebitNote, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeDebitNote IncludeDebitNote { get; set; }

        /// <summary>
        /// Gets or sets Include Credit Note
        /// </summary>
        [ViewField(Name = Fields.IncludeCreditNote, Id = Index.IncludeCreditNote, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeCreditNote IncludeCreditNote { get; set; }

        /// <summary>
        /// Gets or sets Days Before Retainage Due
        /// </summary>
        [Display(Name = "DaysInAdvance", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DaysBeforeRetainageDue, Id = Index.DaysBeforeRetainageDue, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysBeforeRetainageDue { get; set; }

        /// <summary>
        /// Gets or sets Command Code
        /// </summary>
        [ViewField(Name = Fields.CommandCode, Id = Index.CommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public CommandCode CommandCode { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public int Status { get; set; }
    }
}
