/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Age Documents class for to generate report process
    /// </summary>
    public partial class AgeDocument : ModelBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets CommandCode 
        /// </summary>
        [ViewField(Name = Fields.CommandCode, Id = Index.CommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public CommandCode CommandCode { get; set; }

        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber 
        /// </summary>
        [StringLength(18, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Char, Size = 18, Mask = "%-18D")]
        public string CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransactionType { get; set; }

        /// <summary>
        /// Gets or sets TransactionDescription 
        /// </summary>
        [ViewField(Name = Fields.TransactionDescription, Id = Index.TransactionDescription, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransactionDescription { get; set; }

        /// <summary>
        /// Gets or sets AmountDue 
        /// </summary>
        [ViewField(Name = Fields.AmountDue, Id = Index.AmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDue { get; set; }

        /// <summary>
        /// Gets or sets StartingInvoiceDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingInvoiceDate, Id = Index.StartingInvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StartingInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DueDate { get; set; }

        /// <summary>
        /// Gets or sets AgeasofDate 
        /// </summary>
        [Display(Name = "AgeAsOf", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AgeasofDate, Id = Index.AgeasofDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime AgeasofDate { get; set; }

        /// <summary>
        /// Gets or sets CutoffDate 
        /// </summary>
         [Display(Name = "CutoffDate", ResourceType = typeof(APCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CutoffDate, Id = Index.CutoffDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? CutoffDate { get; set; }

        /// <summary>
        /// Gets or sets DueDateOrInvoiceDate 
        /// </summary>
        [ViewField(Name = Fields.DueDateOrInvoiceDate, Id = Index.DueDateOrInvoiceDate, FieldType = EntityFieldType.Int, Size = 2)]
        public DueDateOrInvoiceDate DueDateOrInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets IncludePaymentsOnHold 
        /// </summary>
        [Display(Name = "VendorTransOnHold", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludePaymentsOnHold, Id = Index.IncludePaymentsOnHold, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludePaymentsOnHold { get; set; }

        /// <summary>
        /// Gets or sets IncludeZeroBalances 
        /// </summary>
        [Display(Name = "VendorsZeroBalance", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludeZeroBalances, Id = Index.IncludeZeroBalances, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeZeroBalances { get; set; }

        /// <summary>
        /// Gets or sets ATBOrOverdueRecurringReport 
        /// </summary>
        [ViewField(Name = Fields.ATBOrOverdueRecReport, Id = Index.ATBOrOverdueRecReport, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Process.ATBOrOverdueRecReport ATBOrOverdueRecReport { get; set; }

        /// <summary>
        /// Gets or sets Current 
        /// </summary>
        [ViewField(Name = Fields.Current, Id = Index.Current, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal Current { get; set; }

        /// <summary>
        /// Gets or sets FirstPeriod 
        /// </summary>
        [ViewField(Name = Fields.FirstPeriod, Id = Index.FirstPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal FirstPeriod { get; set; }

        /// <summary>
        /// Gets or sets SecondPeriod 
        /// </summary>
        [ViewField(Name = Fields.SecondPeriod, Id = Index.SecondPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal SecondPeriod { get; set; }

        /// <summary>
        /// Gets or sets ThirdPeriod 
        /// </summary>

        [ViewField(Name = Fields.ThirdPeriod, Id = Index.ThirdPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal ThirdPeriod { get; set; }

        /// <summary>
        /// Gets or sets FourthPeriod 
        /// </summary>
        [ViewField(Name = Fields.FourthPeriod, Id = Index.FourthPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal FourthPeriod { get; set; }

        /// <summary>
        /// Gets or sets FirstForwardPeriod 
        /// </summary>
        [ViewField(Name = Fields.FirstForwardPeriod, Id = Index.FirstForwardPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal FirstForwardPeriod { get; set; }

        /// <summary>
        /// Gets or sets SecondForwardPeriod 
        /// </summary>
        [ViewField(Name = Fields.SecondForwardPeriod, Id = Index.SecondForwardPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal SecondForwardPeriod { get; set; }

        /// <summary>
        /// Gets or sets ThirdForwardPeriod 
        /// </summary>
        [ViewField(Name = Fields.ThirdForwardPeriod, Id = Index.ThirdForwardPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal ThirdForwardPeriod { get; set; }

        /// <summary>
        /// Gets or sets FourthForwardPeriod 
        /// </summary>
        [ViewField(Name = Fields.FourthForwardPeriod, Id = Index.FourthForwardPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal FourthForwardPeriod { get; set; }

        /// <summary>
        /// Gets or sets IncludeOverCreditLimit 
        /// </summary>
        [ViewField(Name = Fields.IncludeOverCreditLimit, Id = Index.IncludeOverCreditLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeOverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets Range1From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range1From, Id = Index.Range1From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range1From { get; set; }

        /// <summary>
        /// Gets or sets Range1To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range1To, Id = Index.Range1To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range1To { get; set; }

        /// <summary>
        /// Gets or sets Range1IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range1IndexValue, Id = Index.Range1IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range1IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range2From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range2From, Id = Index.Range2From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range2From { get; set; }

        /// <summary>
        /// Gets or sets Range2To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range2To, Id = Index.Range2To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range2To { get; set; }

        /// <summary>
        /// Gets or sets Range2IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range2IndexValue, Id = Index.Range2IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range2IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range3From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range3From, Id = Index.Range3From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range3From { get; set; }

        /// <summary>
        /// Gets or sets Range3To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range3To, Id = Index.Range3To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range3To { get; set; }

        /// <summary>
        /// Gets or sets Range3IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range3IndexValue, Id = Index.Range3IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range3IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range4From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range4From, Id = Index.Range4From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range4From { get; set; }

        /// <summary>
        /// Gets or sets Range4To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Range4To, Id = Index.Range4To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range4To { get; set; }

        /// <summary>
        /// Gets or sets Range4IndexValue 
        /// </summary>
        [ViewField(Name = Fields.Range4IndexValue, Id = Index.Range4IndexValue, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range4IndexValue { get; set; }

        /// <summary>
        /// Gets or sets CurrentAmountDueSource 
        /// </summary>
        [ViewField(Name = Fields.CurrentAmountDueSource, Id = Index.CurrentAmountDueSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentAmountDueSource { get; set; }

        /// <summary>
        /// Gets or sets CurrentAmountDueFunctional 
        /// </summary>
        [ViewField(Name = Fields.CurrentAmountDueFunctional, Id = Index.CurrentAmountDueFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentAmountDueFunctional { get; set; }

        /// <summary>
        /// Gets or sets CurrentDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrentDate, Id = Index.CurrentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CurrentDate { get; set; }

        /// <summary>
        /// Gets or sets Period1AmountDueSource 
        /// </summary>
        [ViewField(Name = Fields.Period1AmountDueSource, Id = Index.Period1AmountDueSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period1AmountDueSource { get; set; }

        /// <summary>
        /// Gets or sets Period1AmountDueFunctional 
        /// </summary>
        [ViewField(Name = Fields.Period1AmountDueFunctional, Id = Index.Period1AmountDueFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period1AmountDueFunctional { get; set; }

        /// <summary>
        /// Gets or sets Period1Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Period1Date, Id = Index.Period1Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Period1Date { get; set; }

        /// <summary>
        /// Gets or sets Period2AmountDueSource 
        /// </summary>
        [ViewField(Name = Fields.Period2AmountDueSource, Id = Index.Period2AmountDueSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period2AmountDueSource { get; set; }

        /// <summary>
        /// Gets or sets Period2AmountDueFunctional 
        /// </summary>
        [ViewField(Name = Fields.Period2AmountDueFunctional, Id = Index.Period2AmountDueFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period2AmountDueFunctional { get; set; }

        /// <summary>
        /// Gets or sets Period2Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Period2Date, Id = Index.Period2Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Period2Date { get; set; }

        /// <summary>
        /// Gets or sets Period3AmountDueSource 
        /// </summary>
        [ViewField(Name = Fields.Period3AmountDueSource, Id = Index.Period3AmountDueSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period3AmountDueSource { get; set; }

        /// <summary>
        /// Gets or sets Period3AmountDueFunctional 
        /// </summary>
        [ViewField(Name = Fields.Period3AmountDueFunctional, Id = Index.Period3AmountDueFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period3AmountDueFunctional { get; set; }

        /// <summary>
        /// Gets or sets Period3Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Period3Date, Id = Index.Period3Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Period3Date { get; set; }

        /// <summary>
        /// Gets or sets Period4AmountDueSource 
        /// </summary>
        [ViewField(Name = Fields.Period4AmountDueSource, Id = Index.Period4AmountDueSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period4AmountDueSource { get; set; }

        /// <summary>
        /// Gets or sets Period4AmountDueFunctional 
        /// </summary>
        [ViewField(Name = Fields.Period4AmountDueFunctional, Id = Index.Period4AmountDueFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period4AmountDueFunctional { get; set; }

        /// <summary>
        /// Gets or sets Period4Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Period4Date, Id = Index.Period4Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Period4Date { get; set; }

        /// <summary>
        /// Gets or sets Period5AmountDueSource 
        /// </summary>
        [ViewField(Name = Fields.Period5AmountDueSource, Id = Index.Period5AmountDueSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period5AmountDueSource { get; set; }

        /// <summary>
        /// Gets or sets Period5AmountDueFunctional 
        /// </summary>
        [ViewField(Name = Fields.Period5AmountDueFunctional, Id = Index.Period5AmountDueFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period5AmountDueFunctional { get; set; }

        /// <summary>
        /// Gets or sets Period5Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Period5Date, Id = Index.Period5Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Period5Date { get; set; }

        /// <summary>
        /// Gets or sets Period6AmountDueSource 
        /// </summary>
        [ViewField(Name = Fields.Period6AmountDueSource, Id = Index.Period6AmountDueSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period6AmountDueSource { get; set; }

        /// <summary>
        /// Gets or sets Period6AmountDueFunctional 
        /// </summary>
        [ViewField(Name = Fields.Period6AmountDueFunctional, Id = Index.Period6AmountDueFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period6AmountDueFunctional { get; set; }

        /// <summary>
        /// Gets or sets Period6Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Period6Date, Id = Index.Period6Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Period6Date { get; set; }

        /// <summary>
        /// Gets or sets Period7AmountDueSource 
        /// </summary>
        [ViewField(Name = Fields.Period7AmountDueSource, Id = Index.Period7AmountDueSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period7AmountDueSource { get; set; }

        /// <summary>
        /// Gets or sets Period7AmountDueFunctional 
        /// </summary>
        [ViewField(Name = Fields.Period7AmountDueFunctional, Id = Index.Period7AmountDueFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period7AmountDueFunctional { get; set; }

        /// <summary>
        /// Gets or sets Period7Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Period7Date, Id = Index.Period7Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Period7Date { get; set; }

        /// <summary>
        /// Gets or sets Period8AmountDueSource 
        /// </summary>
        [ViewField(Name = Fields.Period8AmountDueSource, Id = Index.Period8AmountDueSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period8AmountDueSource { get; set; }

        /// <summary>
        /// Gets or sets Period8AmountDueFunctional 
        /// </summary>
        [ViewField(Name = Fields.Period8AmountDueFunctional, Id = Index.Period8AmountDueFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period8AmountDueFunctional { get; set; }

        /// <summary>
        /// Gets or sets Period8Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Period8Date, Id = Index.Period8Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Period8Date { get; set; }

        /// <summary>
        /// Gets or sets PeriodOpenItemScheduleDue 
        /// </summary>
        [ViewField(Name = Fields.PeriodOpenItemScheduleDue, Id = Index.PeriodOpenItemScheduleDue, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PeriodOpenItemScheduleDue { get; set; }

        /// <summary>
        /// Gets or sets TotalBackwardAgingSource 
        /// </summary>
        [ViewField(Name = Fields.TotalBackwardAgingSource, Id = Index.TotalBackwardAgingSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalBackwardAgingSource { get; set; }

        /// <summary>
        /// Gets or sets TotalBackwardAgingFunctional 
        /// </summary>
        [ViewField(Name = Fields.TotalBackwardAgingFunctional, Id = Index.TotalBackwardAgingFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalBackwardAgingFunctional { get; set; }

        /// <summary>
        /// Gets or sets TotalForwardAgingSource 
        /// </summary>
        [ViewField(Name = Fields.TotalForwardAgingSource, Id = Index.TotalForwardAgingSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalForwardAgingSource { get; set; }

        /// <summary>
        /// Gets or sets TotalForwardAgingFunctional 
        /// </summary>
        [ViewField(Name = Fields.TotalForwardAgingFunctional, Id = Index.TotalForwardAgingFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalForwardAgingFunctional { get; set; }

        /// <summary>
        /// Gets or sets DisplayMeter 
        /// </summary>
        [ViewField(Name = Fields.DisplayMeter, Id = Index.DisplayMeter, FieldType = EntityFieldType.Int, Size = 2)]
        public bool DisplayMeter { get; set; }

        /// <summary>
        /// Gets or sets IncludeAppliedDetails 
        /// </summary>
        [Display(Name = "AppliedDetails", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludeAppliedDetails, Id = Index.IncludeAppliedDetails, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeAppliedDetails { get; set; }

        /// <summary>
        /// Gets or sets TakeallAvailableDiscounts 
        /// </summary>
        [Display(Name = "AllAvailableDiscounts", ResourceType = typeof(APCommonReportResx))]
        [ViewField(Name = Fields.TakeallAvailableDiscounts, Id = Index.TakeallAvailableDiscounts, FieldType = EntityFieldType.Int, Size = 2)]
        public bool TakeallAvailableDiscounts { get; set; }

        /// <summary>
        /// Gets or sets Cutoffby 
        /// </summary>
        [ViewField(Name = Fields.Cutoffby, Id = Index.Cutoffby, FieldType = EntityFieldType.Int, Size = 2)]
        public Cutoffby Cutoffby { get; set; }

        /// <summary>
        /// Gets or sets CutoffYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CutoffYear, Id = Index.CutoffYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string CutoffYear { get; set; }

        /// <summary>
        /// Gets or sets CutoffPeriod 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CutoffPeriod, Id = Index.CutoffPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string CutoffPeriod { get; set; }

        /// <summary>
        /// Gets or sets FieldName1 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FieldName1, Id = Index.FieldName1, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName1 { get; set; }

        /// <summary>
        /// Gets or sets FieldName2 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FieldName2, Id = Index.FieldName2, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName2 { get; set; }

        /// <summary>
        /// Gets or sets FieldName3 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FieldName3, Id = Index.FieldName3, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName3 { get; set; }

        /// <summary>
        /// Gets or sets FieldName4 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FieldName4, Id = Index.FieldName4, FieldType = EntityFieldType.Char, Size = 19)]
        public string FieldName4 { get; set; }

        /// <summary>
        /// Gets or sets IncludePrepayment 
        /// </summary>
        [Display(Name = "Prepayment", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludePrepayment, Id = Index.IncludePrepayment, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludePrepayment { get; set; }

        /// <summary>
        /// Gets or sets AgingSequenceNumber 
        /// </summary>
        [ViewField(Name = Fields.AgingSequenceNumber, Id = Index.AgingSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long AgingSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex1 
        /// </summary>
        [ViewField(Name = Fields.SortFieldIndex1, Id = Index.SortFieldIndex1, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldIndex1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex2 
        /// </summary>
        [ViewField(Name = Fields.SortFieldIndex2, Id = Index.SortFieldIndex2, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldIndex2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex3 
        /// </summary>
        [ViewField(Name = Fields.SortFieldIndex3, Id = Index.SortFieldIndex3, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldIndex3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex4 
        /// </summary>
        [ViewField(Name = Fields.SortFieldIndex4, Id = Index.SortFieldIndex4, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldIndex4 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName1 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldName1, Id = Index.SortFieldName1, FieldType = EntityFieldType.Char, Size = 19)]
        public string SortFieldName1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName2 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldName2, Id = Index.SortFieldName2, FieldType = EntityFieldType.Char, Size = 19)]
        public string SortFieldName2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName3 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldName3, Id = Index.SortFieldName3, FieldType = EntityFieldType.Char, Size = 19)]
        public string SortFieldName3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName4 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldName4, Id = Index.SortFieldName4, FieldType = EntityFieldType.Char, Size = 19)]
        public string SortFieldName4 { get; set; }

        /// <summary>
        /// Gets or sets IncludeInvoice 
        /// </summary>
        [Display(Name = "Invoice1", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludeInvoice, Id = Index.IncludeInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeInvoice { get; set; }

        /// <summary>
        /// Gets or sets IncludeDebitNote 
        /// </summary>
        [Display(Name = "DebitNote", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludeDebitNote, Id = Index.IncludeDebitNote, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeDebitNote { get; set; }

        /// <summary>
        /// Gets or sets IncludeCreditNote 
        /// </summary>
        [Display(Name = "CreditNote", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludeCreditNote, Id = Index.IncludeCreditNote, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeCreditNote { get; set; }

        /// <summary>
        /// Gets or sets IncludeInterest 
        /// </summary>
        [Display(Name = "Interest", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludeInterest, Id = Index.IncludeInterest, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeInterest { get; set; }

        /// <summary>
        /// Gets or sets IncludePayment 
        /// </summary>
        [Display(Name = "Payment", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludePayment, Id = Index.IncludePayment, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludePayment { get; set; }

        /// <summary>
        /// Gets or sets IncludeFullyPaidTransactions 
        /// </summary>
        [Display(Name = "FullyPaidTransaction", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludeFullyPaidTransactions, Id = Index.IncludeFullyPaidTransactions, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeFullyPaidTransactions { get; set; }

        /// <summary>
        /// Gets or sets IncludeAdjustment 
        /// </summary>
        [Display(Name = "Adjustment", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.IncludeAdjustment, Id = Index.IncludeAdjustment, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeAdjustment { get; set; }

        /// <summary>
        /// Gets or sets FromDate 
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.FromDate, Id = Index.FromDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or sets FromYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromYear, Id = Index.FromYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets FromPeriod 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromPeriod, Id = Index.FromPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets ShowAgedRetainage 
        /// </summary>
        [Display(Name = "AgedRetainage", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ShowAgedRetainage, Id = Index.ShowAgedRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ShowAgedRetainage { get; set; }

        #endregion
    }
}
