// Copyright (c) 1994-2025 The Sage Group plc or its licensors.  All rights reserved. 

#region Usings
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Model class for CPRS Electronic Filing
    /// </summary>
    public partial class CPRSElectronicFiling : ModelBase
    {

        /// <summary>
        /// Gets or sets FromVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromVendorNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.FromVendorNumber, Id = Index.FromVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string FromVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets ToVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToVendorNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ToVendorNumber, Id = Index.ToVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ToVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets FromCPRSCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromCPRSCode", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.FromCPRSCode, Id = Index.FromCPRSCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FromCPRSCode { get; set; }

        /// <summary>
        /// Gets or sets ToCPRSCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToCPRSCode", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.ToCPRSCode, Id = Index.ToCPRSCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ToCPRSCode { get; set; }

        /// <summary>
        /// Gets or sets PaymentYear 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxYear", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.PaymentYear, Id = Index.PaymentYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string PaymentYear { get; set; }

        /// <summary>
        /// Gets or sets SubmissionReferenceID 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SubmissionReferenceID", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.SubmissionReferenceID, Id = Index.SubmissionReferenceID, FieldType = EntityFieldType.Char, Size = 8)]
        public string SubmissionReferenceID { get; set; }

        /// <summary>
        /// Gets or sets ReportType 
        /// </summary>
        [Display(Name = "ReportType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ReportType, Id = Index.ReportType, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportType ReportType { get; set; }

        /// <summary>
        /// Gets or sets TransmitterNumber 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransmitterNumber", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.TransmitterNumber, Id = Index.TransmitterNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "MM%-6D")]
        public string TransmitterNumber { get; set; }

        /// <summary>
        /// Gets or sets TransmitterLanguage 
        /// </summary>
        [Display(Name = "Language", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TransmitterLanguage, Id = Index.TransmitterLanguage, FieldType = EntityFieldType.Int, Size = 2)]
        public TransmitterLanguage TransmitterLanguage { get; set; }

        /// <summary>
        /// Gets or sets TransmitterNameLine1 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.TransmitterNameLine1, Id = Index.TransmitterNameLine1, FieldType = EntityFieldType.Char, Size = 30)]
        public string TransmitterNameLine1 { get; set; }

        /// <summary>
        /// Gets or sets TransmitterNameLine2 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name2", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.TransmitterNameLine2, Id = Index.TransmitterNameLine2, FieldType = EntityFieldType.Char, Size = 30)]
        public string TransmitterNameLine2 { get; set; }

        /// <summary>
        /// Gets or sets TransmitterAddressLine1 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.TransmitterAddressLine1, Id = Index.TransmitterAddressLine1, FieldType = EntityFieldType.Char, Size = 30)]
        public string TransmitterAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets TransmitterAddressLine2 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.TransmitterAddressLine2, Id = Index.TransmitterAddressLine2, FieldType = EntityFieldType.Char, Size = 30)]
        public string TransmitterAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets TransmitterCity 
        /// </summary>
        [StringLength(28, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TransmitterCity, Id = Index.TransmitterCity, FieldType = EntityFieldType.Char, Size = 28)]
        public string TransmitterCity { get; set; }

        /// <summary>
        /// Gets or sets TransmitterStateOrProvince 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProv", ResourceType = typeof(CompanyProfileResx))]
        [ViewField(Name = Fields.TransmitterStateOrProvince, Id = Index.TransmitterStateOrProvince, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TransmitterStateOrProvince { get; set; }

        /// <summary>
        /// Gets or sets TransmitterCountryCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CountryCode", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.TransmitterCountryCode, Id = Index.TransmitterCountryCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TransmitterCountryCode { get; set; }

        /// <summary>
        /// Gets or sets TransmitterZipOrPostalCode 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipOrPostalCode", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.TransmitterZipOrPostalCode, Id = Index.TransmitterZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 10)]
        public string TransmitterZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets TransmitterContactName 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TransmitterContactName, Id = Index.TransmitterContactName, FieldType = EntityFieldType.Char, Size = 22)]
        public string TransmitterContactName { get; set; }

        /// <summary>
        /// Gets or sets TransmitterPhoneNumber 
        /// </summary>
        [StringLength(34, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TransmitterPhoneNumber, Id = Index.TransmitterPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string TransmitterPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets TransmitterEmail 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmailAddress", ResourceType = typeof(InvoiceEntryResx))]
        [ViewField(Name = Fields.TransmitterEmail, Id = Index.TransmitterEmail, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransmitterEmail { get; set; }

        /// <summary>
        /// Gets or sets PayerAccountNumber 
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountNo", ResourceType = typeof(GLTransactionsReportResx))]
        [ViewField(Name = Fields.PayerAccountNumber, Id = Index.PayerAccountNumber, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-9D%-2A%-4D")]
        public string PayerAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets PayerNameLine1 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name1", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.PayerNameLine1, Id = Index.PayerNameLine1, FieldType = EntityFieldType.Char, Size = 30)]
        public string PayerNameLine1 { get; set; }

        /// <summary>
        /// Gets or sets PayerNameLine2 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name2", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.PayerNameLine2, Id = Index.PayerNameLine2, FieldType = EntityFieldType.Char, Size = 30)]
        public string PayerNameLine2 { get; set; }

        /// <summary>
        /// Gets or sets PayerAddressLine1 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.PayerAddressLine1, Id = Index.PayerAddressLine1, FieldType = EntityFieldType.Char, Size = 30)]
        public string PayerAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets PayerAddressLine2 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.PayerAddressLine2, Id = Index.PayerAddressLine2, FieldType = EntityFieldType.Char, Size = 30)]
        public string PayerAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets PayerCity 
        /// </summary>
        [StringLength(28, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PayerCity, Id = Index.PayerCity, FieldType = EntityFieldType.Char, Size = 28)]
        public string PayerCity { get; set; }

        /// <summary>
        /// Gets or sets PayerStateOrProvince 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProv", ResourceType = typeof(CompanyProfileResx))]
        [ViewField(Name = Fields.PayerStateOrProvince, Id = Index.PayerStateOrProvince, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PayerStateOrProvince { get; set; }

        /// <summary>
        /// Gets or sets PayerCountryCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CountryCode", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.PayerCountryCode, Id = Index.PayerCountryCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string PayerCountryCode { get; set; }

        /// <summary>
        /// Gets or sets PayerZipOrPostalCode 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipOrPostalCode", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.PayerZipOrPostalCode, Id = Index.PayerZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 10)]
        public string PayerZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets PayerContactName 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PayerContactName, Id = Index.PayerContactName, FieldType = EntityFieldType.Char, Size = 22)]
        public string PayerContactName { get; set; }

        /// <summary>
        /// Gets or sets PayerPhoneNumber 
        /// </summary>
        [StringLength(34, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.PayerPhoneNumber, Id = Index.PayerPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PayerPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FileName 
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FileName, Id = Index.FileName, FieldType = EntityFieldType.Char, Size = 255)]
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets T5018SlipCount 
        /// </summary>
        [ViewField(Name = Fields.T5018SlipCount, Id = Index.T5018SlipCount, FieldType = EntityFieldType.Long, Size = 4)]
        public long T5018SlipCount { get; set; }


        /// <summary>
        /// Gets or sets TransmitterAccountType
        /// </summary>
        [Display(Name = "TransmitterAccountType", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.TransmitterAccountType, Id = Index.TransmitterAccountType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransmitterAccountType TransmitterAccountType { get; set; }

        /// <summary>
        /// Gets or sets PayerContactName 
        /// </summary>
        [StringLength(7, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RepID", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.RepID, Id = Index.RepID, FieldType = EntityFieldType.Char, Size = 7, Mask = "%-7N")]
        public string RepID { get; set; }

        /// <summary>
        /// Gets or sets BN9AccountNumber
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BN9AccountNumber", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.BN9AccountNumber, Id = Index.BN9AccountNumber, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-9d")]
        public string BN9AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets BN15AccountNumber
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BN15AccountNumber", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.BN15AccountNumber, Id = Index.BN15AccountNumber, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-9d%-2A%-4d")]
        public string BN15AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets BN15AccountNumber
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRUSTAccountNumber", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.TRUSTAccountNumber, Id = Index.TRUSTAccountNumber, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-1A%-8d")]
        public string TRUSTAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets BN15AccountNumber
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NR4AccountNumber", ResourceType = typeof(T5018CPRSElectronicFilingResx))]
        [ViewField(Name = Fields.NR4AccountNumber, Id = Index.NR4AccountNumber, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-3A%-6d")]
        public string NR4AccountNumber { get; set; }



    /// <summary>
    /// Gets or Sets ApplyCPRSElectronicFilingProcess
    /// To check status of CPRSElectronicFiling in AP-option screen
    /// If Status is true then it should open page or else display error message
    /// </summary>
    public bool ApplyCPRSElectronicFilingProcess { get; set; }

        /// <summary>
        /// Gets or Sets IsFormatPhoneNo
        /// To check the status of FormatPhone number in Company screen
        /// If FormatPhoneNo yes then it should come in formatted way, else Unformatted
        /// </summary>
        public bool IsFormatPhoneNo { get; set; }

    }
}
