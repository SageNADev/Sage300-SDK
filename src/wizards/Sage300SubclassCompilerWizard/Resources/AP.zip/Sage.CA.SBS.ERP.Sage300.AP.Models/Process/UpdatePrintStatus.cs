// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Contains list of UpdatePrintStatus Properties. 
    /// </summary>
    public partial class UpdatePrintStatus : ModelBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or sets CommandCode 
        /// </summary>

        [ViewField(Name = Fields.CommandCode, Id = Index.CommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchCommandCode CommandCode { get; set; }

        /// <summary>
        /// Gets or sets StartingBatchRange 
        /// </summary>

        [ViewField(Name = Fields.StartingBatchRange, Id = Index.StartingBatchRange, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal StartingBatchRange { get; set; }

        /// <summary>
        /// Gets or sets EndingBatchRange 
        /// </summary>

        [ViewField(Name = Fields.EndingBatchRange, Id = Index.EndingBatchRange, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal EndingBatchRange { get; set; }

        /// <summary>
        /// Gets or sets StartingSequenceRange 
        /// </summary>

        [ViewField(Name = Fields.StartingSequenceRange, Id = Index.StartingSequenceRange, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal StartingSequenceRange { get; set; }

        /// <summary>
        /// Gets or sets EndingSequenceRange 
        /// </summary>

        [ViewField(Name = Fields.EndingSequenceRange, Id = Index.EndingSequenceRange, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal EndingSequenceRange { get; set; }

        /// <summary>
        /// Gets or sets StartingVendorRange 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingVendorRange, Id = Index.StartingVendorRange, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string StartingVendorRange { get; set; }

        /// <summary>
        /// Gets or sets EndingVendorRange 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EndingVendorRange, Id = Index.EndingVendorRange, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string EndingVendorRange { get; set; }

        /// <summary>
        /// Gets or sets PostedorUnposted 
        /// </summary>

        [ViewField(Name = Fields.PostedOrUnposted, Id = Index.PostedOrUnposted, FieldType = EntityFieldType.Int, Size = 2)]
        public PostedorUnposted PostedOrUnposted { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets FromDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromDate, Id = Index.FromDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FromDate { get; set; }

        /// <summary>
        /// Gets or sets ToDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToDate, Id = Index.ToDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Gets or sets BatchTypeEntered 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeEntered, Id = Index.BatchTypeEntered, FieldType = EntityFieldType.Int, Size = 2)]
        public int BatchTypeEntered { get; set; }

        /// <summary>
        /// Gets or sets BatchTypeImported 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeImported, Id = Index.BatchTypeImported, FieldType = EntityFieldType.Int, Size = 2)]
        public int BatchTypeImported { get; set; }

        /// <summary>
        /// Gets or sets BatchTypeGenerated 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeGenerated, Id = Index.BatchTypeGenerated, FieldType = EntityFieldType.Int, Size = 2)]
        public int BatchTypeGenerated { get; set; }

        /// <summary>
        /// Gets or sets BatchTypeSystem 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeSystem, Id = Index.BatchTypeSystem, FieldType = EntityFieldType.Int, Size = 2)]
        public int BatchTypeSystem { get; set; }

        /// <summary>
        /// Gets or sets BatchStatusOpen 
        /// </summary>

        [ViewField(Name = Fields.BatchStatusOpen, Id = Index.BatchStatusOpen, FieldType = EntityFieldType.Int, Size = 2)]
        public int BatchStatusOpen { get; set; }

        /// <summary>
        /// Gets or sets BatchStatusReadytoPost 
        /// </summary>

        [ViewField(Name = Fields.BatchStatusReadyToPost, Id = Index.BatchStatusReadyToPost, FieldType = EntityFieldType.Int, Size = 2)]
        public int BatchStatusReadyToPost { get; set; }

        /// <summary>
        /// Gets or sets BatchTypeRecurring 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeRecurring, Id = Index.BatchTypeRecurring, FieldType = EntityFieldType.Int, Size = 2)]
        public int BatchTypeRecurring { get; set; }

        /// <summary>
        /// Gets or sets BatchStatusPosted 
        /// </summary>

        [ViewField(Name = Fields.BatchStatusPosted, Id = Index.BatchStatusPosted, FieldType = EntityFieldType.Int, Size = 2)]
        public int BatchStatusPosted { get; set; }

        /// <summary>
        /// Gets or sets BatchTypeExternal 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeExternal, Id = Index.BatchTypeExternal, FieldType = EntityFieldType.Int, Size = 2)]
        public int BatchTypeExternal { get; set; }

        /// <summary>
        /// Gets or sets BatchTypeRetainage 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeRetainage, Id = Index.BatchTypeRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public int BatchTypeRetainage { get; set; }

        #endregion
    }
}
