// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 
#region

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Class SelectVendors
    /// </summary>
	public partial class SelectVendors : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets SequenceNumber 
        /// </summary>
        
 		public long SequenceNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range1From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Range1From {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range1To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Range1To {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range1IndexValue 
        /// </summary>
        
 		public int Range1IndexValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range2From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Range2From {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range2To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Range2To {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range2IndexValue 
        /// </summary>
        
 		public int Range2IndexValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range3From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Range3From {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range3To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Range3To {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range3IndexValue 
        /// </summary>
        
 		public int Range3IndexValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range4From 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Range4From {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range4To 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Range4To {get; set;}
		 
  		/// <summary>
        /// Gets or sets Range4IndexValue 
        /// </summary>
        
 		public int Range4IndexValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets FieldName1 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string FieldName1 {get; set;}
		 
  		/// <summary>
        /// Gets or sets FieldName2 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string FieldName2 {get; set;}
		 
  		/// <summary>
        /// Gets or sets FieldName3 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string FieldName3 {get; set;}
		 
  		/// <summary>
        /// Gets or sets FieldName4 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string FieldName4 {get; set;}
		 
  		/// <summary>
        /// Gets or sets IncludeZeroBalances 
        /// </summary>
        [Display(Name = "IncludeVendorsWithZeroBalance", ResourceType = typeof(APCommonResx))]
 		public bool IncludeZeroBalances {get; set;}
		 
  		/// <summary>
        /// Gets or sets SortFieldIndex1 
        /// </summary>
        
 		public int SortFieldIndex1 {get; set;}
		 
  		/// <summary>
        /// Gets or sets SortFieldIndex2 
        /// </summary>
        
 		public int SortFieldIndex2 {get; set;}
		 
  		/// <summary>
        /// Gets or sets SortFieldIndex3 
        /// </summary>
        
 		public int SortFieldIndex3 {get; set;}
		 
  		/// <summary>
        /// Gets or sets SortFieldIndex4 
        /// </summary>
        
 		public int SortFieldIndex4 {get; set;}
		 
  		/// <summary>
        /// Gets or sets SortFieldName1 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string SortFieldName1 {get; set;}
		 
  		/// <summary>
        /// Gets or sets SortFieldName2 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string SortFieldName2 {get; set;}
		 
  		/// <summary>
        /// Gets or sets SortFieldName3 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string SortFieldName3 {get; set;}
		 
  		/// <summary>
        /// Gets or sets SortFieldName4 
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string SortFieldName4 {get; set;}
		 
  		/// <summary>
        /// Gets or sets DisplayMeter 
        /// </summary>
        
 		public IncludeZeroBalances DisplayMeter {get; set;}
		 
  		/// <summary>
        /// Gets or sets SortRecords 
        /// </summary>
        
 		public IncludeZeroBalances SortRecords {get; set;}

        /// <summary>
        /// Gets or Sets OptFldsVisible
        /// </summary>
        public bool OptFldsVisible { get; set; }

        /// <summary>
        /// Gets or Sets Session Date
        /// </summary>
	    public DateTime SessionDate { get; set; }

    }
}
