// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
	/// <summary>
	/// Partial class for Clear History
	/// </summary>
	public partial class ClearHistory : ModelBase
	{
		/// <summary>
		/// Gets or sets Clear From Vendor Number
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromVendorNumber", ResourceType = typeof(APCommonResx))]
		[ViewField(Name = Fields.ClearFromVendorNumber, Id = Index.ClearFromVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string ClearFromVendorNumber { get; set; }

		/// <summary>
		/// Gets or sets Clear Through Vendor Number
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToVendorNumber", ResourceType = typeof(APCommonResx))]
		[ViewField(Name = Fields.ClearThruVendorNumber, Id = Index.ClearThruVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string ClearThruVendorNumber { get; set; }

		/// <summary>
		/// Gets or sets Posting Date Cut off
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Date", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PostingDateCutoff, Id = Index.PostingDateCutoff, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime PostingDateCutoff { get; set; }

		/// <summary>
		/// Gets or sets Clear Type
		/// </summary>
		[ViewField(Name = Fields.ClearType, Id = Index.ClearType, FieldType = EntityFieldType.Int, Size = 2)]
		public ClearType ClearType { get; set; }

		/// <summary>
		/// Gets or sets Batch Type
		/// </summary>
		[ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string BatchType { get; set; }

		/// <summary>
		/// Gets or sets Through Posting Sequence Number
		/// </summary>
        [Display(Name = "ThroughPostingSequenceNumber", ResourceType = typeof(ClearHistoryResx))]
		[ViewField(Name = Fields.ThruPostingSequenceNumber, Id = Index.ThruPostingSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
		public decimal ThruPostingSequenceNumber { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets Clear Type string value
		/// </summary>
		public string ClearTypeString
		{
			get { return EnumUtility.GetStringValue(ClearType); }
		}

        /// <summary>
        /// Gets CPRS Amount Through Month String
        /// </summary>
        public string CPRSAmountThroughMonthString
        {
            get { return EnumUtility.GetStringValue(CPRSAmountThroughMonth); }
        }

        /// <summary>
        /// Gets or sets From Vendor Comment
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromVendorComment { get; set; }

        /// <summary>
        /// Gets or sets To Vendor Comment
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToVendorComment { get; set; }

        /// <summary>
        /// Gets or sets Vendor Through Date
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Date", ResourceType = typeof(CommonResx))]
        public DateTime VendorThroughDate { get; set; }

        /// <summary>
        /// Gets or sets From CPRS Amount
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromCPRSAmount { get; set; }

        /// <summary>
        /// Gets or sets FromVendorNo
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToCPRSAmount { get; set; }

        [Display(Name = "Year", ResourceType = typeof(CommonResx))]
	    public string CPRSAmountThroughYear { get; set; }

        [Display(Name = "Month", ResourceType = typeof(APCommonResx))]        
        public Month CPRSAmountThroughMonth { get; set; }

	    /// <summary>
        /// Gets or sets Clear Fully Paid Documents Boolean value.
        /// </summary>
        [Display(Name = "FullyPaidDocuments", ResourceType = typeof(ClearHistoryResx))]
        public bool ClearFullyPaidDocuments{ get; set; }

        /// <summary>
        /// Gets or sets Clear Printed Posting Journal Boolean value.
        /// </summary>
        [Display(Name = "PrintedPostingJournals", ResourceType = typeof(ClearHistoryResx))]
        public bool ClearPrintedPostingJournals { get; set; }

        /// <summary>
        /// Gets or sets Clear Posting Errors Boolean value.
        /// </summary>
        [Display(Name = "PostingErrors", ResourceType = typeof(ClearHistoryResx))]
        public bool ClearPostingErrors { get; set; }

        /// <summary>
        /// Gets or sets Clear Posted Batches Boolean value.
        /// </summary>
        [Display(Name = "DeletedAndPostedBatches", ResourceType = typeof(ClearHistoryResx))]
        public bool ClearPostedBatches { get; set; }


        /// <summary>
        /// Gets or sets Clear Vendor Comments Boolean value.
        /// </summary>
        [Display(Name = "VendorComments", ResourceType = typeof(ClearHistoryResx))]
        public bool ClearVendorComments { get; set; }

        /// <summary>
        /// Gets or sets Clear CPRS Amounts Boolean value.
        /// </summary>
        [Display(Name = "_1099CPRSAmounts", ResourceType = typeof(ClearHistoryResx))]
        public bool ClearCPRSAmounts { get; set; }

        /// <summary>
        /// Gets or sets Posting Journal Invoices Boolean value.
        /// </summary>
        [Display(Name = "Invoices", ResourceType = typeof(APCommonResx))]
        public bool PostingJournalInvoices { get; set; }
        /// <summary>
        /// Gets or sets Posting Journal Payments Boolean value.
        /// </summary>
        [Display(Name = "Payments", ResourceType = typeof(APCommonResx))]
        public bool PostingJournalPayments { get; set; }
        /// <summary>
        /// Gets or sets Posting Journal Adjustments Boolean value.
        /// </summary>
        [Display(Name = "Adjustments", ResourceType = typeof(APCommonResx))]
        public bool PostingJournalAdjustments { get; set; }

        /// <summary>
        /// Gets or sets Posting Journal Revaluation Boolean value.
        /// </summary>
        [Display(Name = "Revaluation", ResourceType = typeof(APCommonResx))]
        public bool PostingJournalRevaluation { get; set; }

        /// <summary>
        /// Gets or sets Posting Errors Invoices Boolean value.
        /// </summary>
        [Display(Name = "Invoices", ResourceType = typeof(APCommonResx))]
        public bool PostingErrorsInvoices { get; set; }
        /// <summary>
        /// Gets or sets Posting Errors Payments Boolean value.
        /// </summary>
        [Display(Name = "Payments", ResourceType = typeof(APCommonResx))]
        public bool PostingErrorsPayments { get; set; }
        /// <summary>
        /// Gets or sets Posting Errors Adjustments Boolean value.
        /// </summary>
        [Display(Name = "Adjustments", ResourceType = typeof(APCommonResx))]
        public bool PostingErrorsAdjustments { get; set; }
        
        /// <summary>
        /// Gets or sets Posted Batches Invoices Boolean value.
        /// </summary>
        [Display(Name = "Invoices", ResourceType = typeof(APCommonResx))]
        public bool PostedBatchesInvoices { get; set; }
        /// <summary>
        /// Gets or sets Posted Batches Payments Boolean value.
        /// </summary>
        [Display(Name = "Payments", ResourceType = typeof(APCommonResx))]
        public bool PostedBatchesPayments { get; set; }
        /// <summary>
        /// Gets or sets Posted Batches Adjustments Boolean value.
        /// </summary>
        [Display(Name = "Adjustments", ResourceType = typeof(APCommonResx))]
        public bool PostedBatchesAdjustments { get; set; }

        /// <summary>
        /// Gets or sets Posting Journal Invoice Sequence 
        /// </summary>
        [Display(Name = "InvoicePostingSequence", ResourceType = typeof(APCommonResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal PostingJournalInvoiceSequence { get; set; }
        /// <summary>
        /// Gets or sets Posting Journal Payment Sequence 
        /// </summary>
        [Display(Name = "PaymentPostingSequence", ResourceType = typeof(APCommonResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal PostingJournalPaymentSequence { get; set; }
        /// <summary>
        /// Gets or sets Posting Journal Adjustment Sequence 
        /// </summary>
        [Display(Name = "AdjustmentPostingSequence", ResourceType = typeof(APCommonResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal PostingJournalAdjustmentSequence { get; set; }

        /// <summary>
        /// Gets or sets Posting Journal Revaluation Sequence 
        /// </summary>
        [Display(Name = "RevaluationPostingSequence", ResourceType = typeof(APCommonResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal PostingJournalRevaluationSequence { get; set; }
        /// <summary>
        /// Gets or sets Posting Error Invoice Sequence 
        /// </summary>
        [Display(Name = "InvoicePostingSequence", ResourceType = typeof(APCommonResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal PostingErrorInvoiceSequence { get; set; }
        /// <summary>
        /// Gets or sets Posting Error Payment Sequence 
        /// </summary>
        [Display(Name = "PaymentPostingSequence", ResourceType = typeof(APCommonResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal PostingErrorPaymentSequence { get; set; }
        /// <summary>
        /// Gets or sets Posting Error Adjustment Sequence 
        /// </summary>
        [Display(Name = "AdjustmentPostingSequence", ResourceType = typeof(APCommonResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal PostingErrorAdjustmentSequence { get; set; }

        /// <summary>
        /// Gets or sets To Invoice Batch 
        /// </summary>
        [Display(Name = "InvoiceBatches", ResourceType = typeof(APCommonResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal ToInvoiceBatch { get; set; }
        /// <summary>
        /// Gets or sets To Payment Batch 
        /// </summary>
        [Display(Name = "PaymentBatches", ResourceType = typeof(APCommonResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal ToPaymentBatch { get; set; }
        /// <summary>
        /// Gets or sets To Adjustment Batch 
        /// </summary>
        [Display(Name = "AdjustmentBatches", ResourceType = typeof(APCommonResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal ToAdjustmentBatch { get; set; }

        /// <summary>
        /// Boolean for MultiCurrency
        /// </summary>
        public bool IsMultiCurrency { get; set; }
        
		#endregion
	}
}
