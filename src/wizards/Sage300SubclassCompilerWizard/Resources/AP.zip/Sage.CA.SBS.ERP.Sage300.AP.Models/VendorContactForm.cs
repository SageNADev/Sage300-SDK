﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.Collections.Generic;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public class VendorContactForm : ModelBase
    {
            public VendorContactForm()
            {
                Columns = new Dictionary<string, string>();
            }
            public Dictionary<string, string> Columns { get; set; }
            /// <summary>
            /// Gets or sets LineNumber
            /// </summary>
            public long LineNumber { get; set; }

            /// <summary>
            /// Gets or sets CustomerNumber
            /// </summary>
            public string VENDORID { get; set; }

            /// <summary>
            /// Gets or sets contactId
            /// </summary>
            public string IDCONTACT { get; set; }

            /// <summary>
            /// Gets or sets Email address
            /// </summary>
            public string EMAIL { get; set; }
    }
}
