// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Status = Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Status;

#endregion Namespace

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of properties for Vendor
    /// </summary>
    public partial class VendorContactApplication : ModelBase
    {
        /// <summary>
        /// Gets or sets VendorNumber
        /// </summary>
        [Display(Name = "VendorNumber", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets ContactCode
        /// </summary>
        [Display(Name = "ContactCode", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.ContactCode, Id = Index.ContactCode, FieldType = EntityFieldType.Char, Size = 24)]
        public string ContactCode { get; set; }

        /// <summary>
        /// Gets or sets ApplicationID
        /// </summary>
        [Display(Name = "ApplicationID", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.ApplicationID, Id = Index.ApplicationID, FieldType = EntityFieldType.Char, Size = 2)]
        public string ApplicationID { get; set; }

        /// <summary>
        /// Gets or sets FormID
        /// </summary>
        [Display(Name = "FormID", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.FormID, Id = Index.FormID, FieldType = EntityFieldType.Int, Size = 2)]
        public int FormID { get; set; }

        /// <summary>
        /// Gets or sets Selected
        /// </summary>
        [Display(Name = "Selected", ResourceType = typeof(APCommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.Selected, Id = Index.Selected, FieldType = EntityFieldType.Bool, Size = 2)]
        public int Selected { get; set; }

        #region Properties for finder
        #endregion Properties for finder
    }

}
