/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class TermCodeHeader : ModelBase
    {
        /// <summary>
        /// Gets or sets TermsCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TermsCode", ResourceType = typeof (APCommonResx))]
        [Key]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ProcessingDescription", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary> 
        [Display(Name = "InactiveDate", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary> 
        [Display(Name = "DateLastMaintained", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets UsePaymentSchedule 
        /// </summary>
        [Display(Name = "UsePaymentSchedule", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.UsePaymentSchedule, Id = Index.UsePaymentSchedule, FieldType = EntityFieldType.Int, Size = 2)]
        public UsePaymentSchedule UsePaymentSchedule { get; set; }

        /// <summary>
        /// Gets or sets CalcBaseforDiscountwithTax 
        /// </summary>
        [Display(Name = "CalcBaseforDiscountwithTax", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.CalcBaseforDiscountwithTax, Id = Index.CalcBaseforDiscountwithTax, FieldType = EntityFieldType.Int, Size = 2)]
        public CalcBaseforDiscountwithTax CalcBaseforDiscountwithTax { get; set; }

        /// <summary>
        /// Gets Use CalcBaseforDiscountwithTax string value
        /// </summary>
        public string CalcBaseforDiscountwithTaxInText
        {
            get { return EnumUtility.GetStringValue(CalcBaseforDiscountwithTax); }
        }

        /// <summary>
        /// Gets or sets MethodofCalcforDiscountDate 
        /// </summary>
        [Display(Name = "MethodofCalcforDiscountDate", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.MethodofCalcforDiscountDate, Id = Index.MethodofCalcforDiscountDate, FieldType = EntityFieldType.Int, Size = 2)]
        public MethodofCalcforDiscountDate MethodofCalcforDiscountDate { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay1 
        /// </summary>
        [Display(Name = "DiscountTableStartingDay1", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableStartingDay1, Id = Index.DiscountTableStartingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay2 
        /// </summary>
        [Display(Name = "DiscountTableStartingDay2", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableStartingDay2, Id = Index.DiscountTableStartingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay3 
        /// </summary>
        [Display(Name = "DiscountTableStartingDay3", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableStartingDay3, Id = Index.DiscountTableStartingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay4 
        /// </summary>
        [Display(Name = "DiscountTableStartingDay4", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableStartingDay4, Id = Index.DiscountTableStartingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay1 
        /// </summary>
        [Display(Name = "DiscountTableEndingDay1", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableEndingDay1, Id = Index.DiscountTableEndingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay2 
        /// </summary>
        [Display(Name = "DiscountTableEndingDay2", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableEndingDay2, Id = Index.DiscountTableEndingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay3 
        /// </summary>
        [Display(Name = "DiscountTableEndingDay3", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableEndingDay3, Id = Index.DiscountTableEndingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay4 
        /// </summary>
        [Display(Name = "DiscountTableEndingDay4", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableEndingDay4, Id = Index.DiscountTableEndingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableAddMonths1 
        /// </summary>
        [Display(Name = "DiscountTableAddMonths1", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableAddMonths1, Id = Index.DiscountTableAddMonths1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableAddMonths1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableAddMonths2 
        /// </summary>
        [Display(Name = "DiscountTableAddMonths2", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableAddMonths2, Id = Index.DiscountTableAddMonths2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableAddMonths2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableAddMonths3 
        /// </summary>
        [Display(Name = "DiscountTableAddMonths3", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableAddMonths3, Id = Index.DiscountTableAddMonths3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableAddMonths3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableAddMonths4 
        /// </summary>
        [Display(Name = "DiscountTableAddMonths4", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableAddMonths4, Id = Index.DiscountTableAddMonths4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableAddMonths4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth1 
        /// </summary>
        [Display(Name = "DiscountTableDayofMonth1", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableDayofMonth1, Id = Index.DiscountTableDayofMonth1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth2 
        /// </summary>
        [Display(Name = "DiscountTableDayofMonth2", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableDayofMonth2, Id = Index.DiscountTableDayofMonth2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth3 
        /// </summary>
        [Display(Name = "DiscountTableDayofMonth3", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableDayofMonth3, Id = Index.DiscountTableDayofMonth3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth4 
        /// </summary> 
        [Display(Name = "DiscountTableDayofMonth4", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DiscountTableDayofMonth4, Id = Index.DiscountTableDayofMonth4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth4 { get; set; }

        /// <summary>
        /// Gets or sets MethodofCalcforDueDate 
        /// </summary>
        [Display(Name = "MethodofCalcforDueDate", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.MethodofCalcforDueDate, Id = Index.MethodofCalcforDueDate, FieldType = EntityFieldType.Int, Size = 2)]
        public MethodofCalcforDueDate MethodofCalcforDueDate { get; set; }

        /// <summary>
        /// Gets or sets DueTableStartingDay1 
        /// </summary>
        [Display(Name = "DueDateTableStartingDay1", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableStartingDay1, Id = Index.DueTableStartingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableStartingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DueTableStartingDay2 
        /// </summary>
        [Display(Name = "DueDateTableStartingDay2", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableStartingDay2, Id = Index.DueTableStartingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableStartingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DueTableStartingDay3 
        /// </summary>
        [Display(Name = "DueDateTableStartingDay3", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableStartingDay3, Id = Index.DueTableStartingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableStartingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DueTableStartingDay4 
        /// </summary>
        [Display(Name = "DueDateTableStartingDay4", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableStartingDay4, Id = Index.DueTableStartingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableStartingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DueTableEndingDay1 
        /// </summary>
        [Display(Name = "DueDateTableEndingDay1", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableEndingDay1, Id = Index.DueTableEndingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableEndingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DueTableEndingDay2 
        /// </summary>
        [Display(Name = "DueDateTableEndingDay2", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableEndingDay2, Id = Index.DueTableEndingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableEndingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DueTableEndingDay3 
        /// </summary>
        [Display(Name = "DueDateTableEndingDay3", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableEndingDay3, Id = Index.DueTableEndingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableEndingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DueTableEndingDay4 
        /// </summary>
        [Display(Name = "DueDateTableEndingDay4", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableEndingDay4, Id = Index.DueTableEndingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableEndingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DueTableAddMonths1 
        /// </summary>
        [Display(Name = "DueTableAddMonths1", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableAddMonths1, Id = Index.DueTableAddMonths1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableAddMonths1 { get; set; }

        /// <summary>
        /// Gets or sets DueTableAddMonths2 
        /// </summary>
        [Display(Name = "DueTableAddMonths2", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableAddMonths2, Id = Index.DueTableAddMonths2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableAddMonths2 { get; set; }

        /// <summary>
        /// Gets or sets DueTableAddMonths3 
        /// </summary>
        [Display(Name = "DueTableAddMonths3", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableAddMonths3, Id = Index.DueTableAddMonths3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableAddMonths3 { get; set; }

        /// <summary>
        /// Gets or sets DueTableAddMonths4 
        /// </summary>
        [Display(Name = "DueTableAddMonths4", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableAddMonths4, Id = Index.DueTableAddMonths4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableAddMonths4 { get; set; }

        /// <summary>
        /// Gets or sets DueTableDayofMonth1 
        /// </summary>
        [Display(Name = "DueTableDayofMonth1", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableDayofMonth1, Id = Index.DueTableDayofMonth1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableDayofMonth1 { get; set; }

        /// <summary>
        /// Gets or sets DueTableDayofMonth2 
        /// </summary>
        [Display(Name = "DueTableDayofMonth2", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableDayofMonth2, Id = Index.DueTableDayofMonth2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableDayofMonth2 { get; set; }

        /// <summary>
        /// Gets or sets DueTableDayofMonth3 
        /// </summary>
        [Display(Name = "DueTableDayofMonth3", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableDayofMonth3, Id = Index.DueTableDayofMonth3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableDayofMonth3 { get; set; }

        /// <summary>
        /// Gets or sets DueTableDayofMonth4 
        /// </summary>
        [Display(Name = "DueTableDayofMonth4", ResourceType = typeof (TermCodeResx))]
        [ViewField(Name = Fields.DueTableDayofMonth4, Id = Index.DueTableDayofMonth4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableDayofMonth4 { get; set; }

        /// <summary>
        /// Gets or sets NumberofPayments 
        /// </summary>
         [Display(Name = "NumberofPayments", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.NumberofPayments, Id = Index.NumberofPayments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPayments { get; set; }

        /// <summary>
        /// Gets or sets TotalPercentageDue 
        /// </summary>
         [Display(Name = "TotalPercentageDue", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.TotalPercentageDue, Id = Index.TotalPercentageDue, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TotalPercentageDue { get; set; }

        /// <summary>
        /// Gets or sets TermsCodeDetail.
        /// </summary>
        public EnumerableResponse<TermCodeDetail> TermCodeDetails { get; set; }

        /// <summary>
        /// IsStatusActive is for validating the inactive checkbox
        /// </summary> 
        public bool IsStatusActive
        {
            get { return Status == Status.Inactive; }
            set { Status = value == false ? Status.Active : Status.Inactive; }
        }

        /// <summary>
        /// Gets StatusInText string value
        /// </summary>
        public string StatusInText
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets UsePaymentScheduleInText string value
        /// </summary>
        public string UsePaymentScheduleInText
        {
            get { return EnumUtility.GetStringValue(UsePaymentSchedule); }
        }

        /// <summary>
        /// IsMultiplePaymentSchedule is for validating the inactive checkbox.
        /// </summary> 
        public bool IsMultiplePaymentSchedule
        {
            get
            {
                return (UsePaymentSchedule == UsePaymentSchedule.Yes);
            }
            set
            {
                if (value)
                {
                    UsePaymentSchedule = UsePaymentSchedule.Yes;
                }
                else
                {
                    UsePaymentSchedule = UsePaymentSchedule.No;
                }
            }
        }

        /// <summary>
        /// To get TotalResultsCount
        /// </summary>
        /// <value>TotalResultsCount</value>
        public long TotalResultsCount { get; set; }

        /// <summary>
        /// To get the string value of enumeration type MethodofCalcforDiscountDate 
        /// </summary>
        public string MethodofCalcforDiscountDateString
        {
            get
            {
                return EnumUtility.GetStringValue(MethodofCalcforDiscountDate);
            }
        }

        /// <summary>
        /// To get the string value of enumeration type DueDateTypeString 
        /// </summary>
        public string DueDateTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(MethodofCalcforDueDate);
            }
        }
    }
}
