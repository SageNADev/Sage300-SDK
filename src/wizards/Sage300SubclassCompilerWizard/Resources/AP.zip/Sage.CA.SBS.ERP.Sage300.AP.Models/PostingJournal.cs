/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class PostingJournal
    /// </summary>
    public partial class PostingJournal : ModelBase
    {

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNo 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.PostingSequenceNo, Id = Index.PostingSequenceNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets SystemDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.SystemDate, Id = Index.SystemDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime SystemDate { get; set; }

        /// <summary>
        /// Gets or sets DatePostedinAorP 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DatePostedinAorP, Id = Index.DatePostedinAorP, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DatePostedinAorP { get; set; }

        /// <summary>
        /// Gets or sets Printed
        /// </summary>
        [ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Int, Size = 2)]
        public Multicurrency Printed { get; set; }

        /// <summary>
        /// Gets or sets PostedtoGOrL
        /// </summary>
        [ViewField(Name = Fields.PostedtoGorL, Id = Index.PostedtoGorL, FieldType = EntityFieldType.Int, Size = 2)]
        public Multicurrency PostedtoGorL { get; set; }

        /// <summary>
        /// Gets or sets DatePostedtoGOrL 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DatePostedtoGorL, Id = Index.DatePostedtoGorL, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DatePostedtoGorL { get; set; }

        /// <summary>
        /// Gets or sets ConsolidatedforGOrL
        /// </summary>
        [ViewField(Name = Fields.ConsolidatedforGorL, Id = Index.ConsolidatedforGorL, FieldType = EntityFieldType.Int, Size = 2)]
        public int ConsolidatedforGorL { get; set; }

        /// <summary>
        /// Gets or sets ProgramVersion 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ProgramVersion, Id = Index.ProgramVersion, FieldType = EntityFieldType.Char, Size = 3)]
        public string ProgramVersion { get; set; }


        /// <summary>
        /// To get the string of Printed property
        /// </summary>
        public string PrintedString
        {
            get { return EnumUtility.GetStringValue(Printed); }
        }

        /// <summary>
        /// To get the string of PostedtoGOrL property
        /// </summary>
        public string PostedtoGorLString
        {
            get { return EnumUtility.GetStringValue(PostedtoGorL); }
        }
    }
}
