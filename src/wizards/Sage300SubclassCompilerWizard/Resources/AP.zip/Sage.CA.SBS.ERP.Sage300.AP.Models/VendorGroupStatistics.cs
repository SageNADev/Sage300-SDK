
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;

#region Name spaces

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models

#endregion
{
    /// <summary>
    /// Partial class for vendor group statistics.
    /// </summary>
    public partial class VendorGroupStatistics : ModelBase
    {
        /// <summary>
        /// Gets or sets Group code 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "GroupCode", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.Groupcode, Id = Index.Groupcode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Groupcode { get; set; }

        /// <summary>
        /// Gets or sets Year 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Year", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Period", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string Period { get; set; }

        /// <summary>
        /// Gets or sets NumberofInvoices 
        /// </summary>
        [Display(Name = "NumberofInvoices", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.NumberofInvoices, Id = Index.NumberofInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets NumberofCreditNotes 
        /// </summary>
        [Display(Name = "NumberofCreditNotes", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.NumberofCreditNotes, Id = Index.NumberofCreditNotes, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofCreditNotes { get; set; }

        /// <summary>
        /// Gets or sets NumberofDebitNotes 
        /// </summary>
        [Display(Name = "NumberofDebitNotes", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.NumberofDebitNotes, Id = Index.NumberofDebitNotes, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets NumberofPayments 
        /// </summary>
        [Display(Name = "NumberofPayments", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.NumberofPayments, Id = Index.NumberofPayments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPayments { get; set; }

        /// <summary>
        /// Gets or sets NumberofDiscounts 
        /// </summary>
        [Display(Name = "NumberofDiscounts", ResourceType = typeof(APCommonResx))]        
        [ViewField(Name = Fields.NumberofDiscounts, Id = Index.NumberofDiscounts, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofDiscounts { get; set; }

        /// <summary>
        /// Gets or sets NumberofDiscountsLost 
        /// </summary>
        [Display(Name = "NumberofDiscountsLost", ResourceType = typeof(APCommonResx))]  
        [ViewField(Name = Fields.NumberofDiscountsLost, Id = Index.NumberofDiscountsLost, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofDiscountsLost { get; set; }

        /// <summary>
        /// Gets or sets NumberofAdjustments 
        /// </summary>
        [Display(Name = "NumberofAdjustments", ResourceType = typeof(APCommonResx))]         
        [ViewField(Name = Fields.NumberofAdjustments, Id = Index.NumberofAdjustments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofAdjustments { get; set; }

        /// <summary>
        /// Gets or sets NumberofPaidInvoices 
        /// </summary>
        [Display(Name = "NumberofPaidInvoices", ResourceType = typeof(APCommonResx))]          
        [ViewField(Name = Fields.NumberofPaidInvoices, Id = Index.NumberofPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets NumberofDaystoPay 
        /// </summary>
        [Display(Name = "NumberofDaystoPay", ResourceType = typeof(APCommonResx))]    
        [ViewField(Name = Fields.NumberofDaystoPay, Id = Index.NumberofDaystoPay, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets TotalInvoicesAmount 
        /// </summary>
        [Display(Name = "TotalInvoicesAmount", ResourceType = typeof(APCommonResx))]            
        [ViewField(Name = Fields.TotalInvoicesAmount, Id = Index.TotalInvoicesAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInvoicesAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalCreditNoteAmount 
        /// </summary>
        [Display(Name = "TotalCreditNoteAmount", ResourceType = typeof(APCommonResx))]           
        [ViewField(Name = Fields.TotalCreditNoteAmount, Id = Index.TotalCreditNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCreditNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalDebitNoteAmount 
        /// </summary>
        [Display(Name = "TotalDebitNoteAmount", ResourceType = typeof(APCommonResx))]            
        [ViewField(Name = Fields.TotalDebitNoteAmount, Id = Index.TotalDebitNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDebitNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalPaymentAmount 
        /// </summary>
        [Display(Name = "TotalPaymentAmount", ResourceType = typeof(APCommonResx))]           
        [ViewField(Name = Fields.TotalPaymentAmount, Id = Index.TotalPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalDiscountAmount 
        /// </summary>
        [Display(Name = "TotalDiscountAmount", ResourceType = typeof(APCommonResx))]              
        [ViewField(Name = Fields.TotalDiscountAmount, Id = Index.TotalDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalDiscountAmountLost 
        /// </summary>
        [Display(Name = "TotalDiscountAmountLost", ResourceType = typeof(APCommonResx))]              
        [ViewField(Name = Fields.TotalDiscountAmountLost, Id = Index.TotalDiscountAmountLost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDiscountAmountLost { get; set; }

        /// <summary>
        /// Gets or sets TotalAdjustmentAmount 
        /// </summary>
        [Display(Name = "TotalAdjustmentAmount", ResourceType = typeof(APCommonResx))]          
        [ViewField(Name = Fields.TotalAdjustmentAmount, Id = Index.TotalAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalAmountofPaidInvoices 
        /// </summary>
        [Display(Name = "TotalAmountofPaidInvoices", ResourceType = typeof(APCommonResx))]          
        [ViewField(Name = Fields.TotalAmountofPaidInvoices, Id = Index.TotalAmountofPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAmountofPaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets AverageDaystoPay 
        /// </summary>
        [Display(Name = "AverageDaystoPay", ResourceType = typeof(APCommonResx))]             
        [ViewField(Name = Fields.AverageDaystoPay, Id = Index.AverageDaystoPay, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 1)]
        public decimal AverageDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberofInvoices 
        /// </summary>
        [Display(Name = "YTDNumberofInvoices", ResourceType = typeof(APCommonResx))]             
        [ViewField(Name = Fields.YTDNumberofInvoices, Id = Index.YTDNumberofInvoices, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberofCreditNotes 
        /// </summary>
        [Display(Name = "YTDNumberofCreditNotes", ResourceType = typeof(APCommonResx))]           
        [ViewField(Name = Fields.YTDNumberofCreditNotes, Id = Index.YTDNumberofCreditNotes, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberofCreditNotes { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberofDebitNotes 
        /// </summary>
        [Display(Name = "YTDNumberofDebitNotes", ResourceType = typeof(APCommonResx))]            
        [ViewField(Name = Fields.YTDNumberofDebitNotes, Id = Index.YTDNumberofDebitNotes, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberofDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberofPayments 
        /// </summary>
        [Display(Name = "YTDNumberofPayments", ResourceType = typeof(APCommonResx))]           
        [ViewField(Name = Fields.YTDNumberofPayments, Id = Index.YTDNumberofPayments, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberofPayments { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberofDiscounts 
        /// </summary>
        [Display(Name = "YTDNumberofDiscounts", ResourceType = typeof(APCommonResx))]           
        [ViewField(Name = Fields.YTDNumberofDiscounts, Id = Index.YTDNumberofDiscounts, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberofDiscounts { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberofDiscountsLost 
        /// </summary>
        [Display(Name = "YTDNumberofDiscountsLost", ResourceType = typeof(APCommonResx))]                
        [ViewField(Name = Fields.YTDNumberofDiscountsLost, Id = Index.YTDNumberofDiscountsLost, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberofDiscountsLost { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberofAdjustments 
        /// </summary>
        [Display(Name = "YTDNumberofAdjustments", ResourceType = typeof(APCommonResx))]              
        [ViewField(Name = Fields.YTDNumberofAdjustments, Id = Index.YTDNumberofAdjustments, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberofAdjustments { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberofPaidInvoices 
        /// </summary>
        [Display(Name = "YTDNumberofPaidInvoices", ResourceType = typeof(APCommonResx))]         
        [ViewField(Name = Fields.YTDNumberofPaidInvoices, Id = Index.YTDNumberofPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberofPaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberofDaystoPay 
        /// </summary>
        [Display(Name = "YTDNumberofDaystoPay", ResourceType = typeof(APCommonResx))]             
        [ViewField(Name = Fields.YTDNumberofDaystoPay, Id = Index.YTDNumberofDaystoPay, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberofDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets YTDInvoicesinFuncCurr 
        /// </summary>
        [Display(Name = "YTDInvoicesinFuncCurr", ResourceType = typeof(APCommonResx))]          
        [ViewField(Name = Fields.YTDInvoicesinFuncCurr, Id = Index.YTDInvoicesinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDInvoicesinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDCreditsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDCreditsinFuncCurr", ResourceType = typeof(APCommonResx))]             
        [ViewField(Name = Fields.YTDCreditsinFuncCurr, Id = Index.YTDCreditsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDCreditsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDDebitsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDDebitsinFuncCurr", ResourceType = typeof(APCommonResx))]           
        [ViewField(Name = Fields.YTDDebitsinFuncCurr, Id = Index.YTDDebitsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDDebitsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDPaymentsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDPaymentsinFuncCurr", ResourceType = typeof(APCommonResx))]           
        [ViewField(Name = Fields.YTDPaymentsinFuncCurr, Id = Index.YTDPaymentsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDPaymentsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDDiscountsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDDiscountsinFuncCurr", ResourceType = typeof(APCommonResx))]           
        [ViewField(Name = Fields.YTDDiscountsinFuncCurr, Id = Index.YTDDiscountsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDDiscountsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDDiscountsLostFuncCurr 
        /// </summary>
        [Display(Name = "YTDDiscountsLostFuncCurr", ResourceType = typeof(APCommonResx))]  
        [ViewField(Name = Fields.YTDDiscountsLostFuncCurr, Id = Index.YTDDiscountsLostFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDDiscountsLostFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDAdjustmentsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDAdjustmentsinFuncCurr", ResourceType = typeof(APCommonResx))]          
        [ViewField(Name = Fields.YTDAdjustmentsinFuncCurr, Id = Index.YTDAdjustmentsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDAdjustmentsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDInvoicesPdinFuncCurr 
        /// </summary>
        [Display(Name = "YTDInvoicesPdinFuncCurr", ResourceType = typeof(APCommonResx))]          
        [ViewField(Name = Fields.YTDInvoicesPdinFuncCurr, Id = Index.YTDInvoicesPdinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDInvoicesPdinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDAverageDaystoPay 
        /// </summary>
        [Display(Name = "YTDAverageDaysToPay", ResourceType = typeof(APCommonResx))]             
        [ViewField(Name = Fields.YTDAverageDaystoPay, Id = Index.YTDAverageDaystoPay, FieldType = EntityFieldType.Decimal, Size = 6, Precision = 1)]
        public decimal YTDAverageDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets EnableYTDCalculations 
        /// </summary>
        [Display(Name = "EnableYTDCalculations", ResourceType = typeof(APCommonResx))]           
        [ViewField(Name = Fields.EnableYTDCalculations, Id = Index.EnableYTDCalculations, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed EnableYTDCalculations { get; set; }
    }
}
