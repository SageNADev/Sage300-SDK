//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class Create PaymentBatch Detail
    /// </summary>
    public partial class CreatePaymentBatchDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets SelectionCriteria 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "SelectionCode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.SelectionCriteria, Id = Index.SelectionCriteria, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string SelectionCriteria { get; set; }

        /// <summary>
        /// Gets or sets ExcludeVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "VendorNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ExcludeVendorNumber, Id = Index.ExcludeVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ExcludeVendorNumber { get; set; }
        
        /// <summary>
        /// Gets or sets SerialNumber - Unique key for grid rows
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Line Number
        /// </summary>
        [IgnoreExportImport]
        public int LineNumber { get; set; }
       
        /// <summary>
        /// Gets or sets for VendorName
        /// </summary>
        public string VendorName { get; set; }

        /// <summary>
        ///  Gets or sets CreatePaymentBatch OptionalField Detail
        /// </summary>
        public EnumerableResponse<CreatePaymentBatchOptionalField> CreatePaymentBatchOptionalField { get; set; }
    }
}
