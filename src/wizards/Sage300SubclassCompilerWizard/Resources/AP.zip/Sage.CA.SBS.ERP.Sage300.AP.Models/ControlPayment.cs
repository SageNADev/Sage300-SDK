// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class Control Payment
    /// </summary>
    public partial class ControlPayment : ModelBase
    {
        /// <summary>
        /// Gets or sets RequestType 
        /// </summary>
        [ViewField(Name = Fields.RequestType, Id = Index.RequestType, FieldType = EntityFieldType.Int, Size = 2)]
        public ControlPaymentRequestType RequestType { get; set; }

        /// <summary>
        /// Gets or sets StartingVendorRange 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingVendorRange, Id = Index.StartingVendorRange, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string StartingVendorRange { get; set; }

        /// <summary>
        /// Gets or sets EndingVendorRange 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EndingVendorRange, Id = Index.EndingVendorRange, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string EndingVendorRange { get; set; }

        /// <summary>
        /// Gets or sets StartingGroupRange 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingGroupRange, Id = Index.StartingGroupRange, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StartingGroupRange { get; set; }

        /// <summary>
        /// Gets or sets EndingGroupRange 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EndingGroupRange, Id = Index.EndingGroupRange, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EndingGroupRange { get; set; }

        /// <summary>
        /// Gets or sets StartingDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingDocumentNumber, Id = Index.StartingDocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string StartingDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets EndingDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EndingDocumentNumber, Id = Index.EndingDocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string EndingDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets IncludeInvoices 
        /// </summary>
        [ViewField(Name = Fields.IncludeInvoices, Id = Index.IncludeInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeInvoice IncludeInvoices { get; set; }

        /// <summary>
        /// Gets or sets IncludeCreditsNotes 
        /// </summary>
        [ViewField(Name = Fields.IncludeCreditsNotes, Id = Index.IncludeCreditsNotes, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeInvoice IncludeCreditsNotes { get; set; }

        /// <summary>
        /// Gets or sets IncludeDebitsNotes 
        /// </summary>
        [ViewField(Name = Fields.IncludeDebitsNotes, Id = Index.IncludeDebitsNotes, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeInvoice IncludeDebitsNotes { get; set; }

        /// <summary>
        /// Gets or sets IncludePrepayments 
        /// </summary>
        [ViewField(Name = Fields.IncludePrepayments, Id = Index.IncludePrepayments, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeInvoice IncludePrepayments { get; set; }

        /// <summary>
        /// Gets or sets ScheduledPaymentNumber 
        /// </summary>
        [Display(Name = "PaymentNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ScheduledPaymentNumber, Id = Index.ScheduledPaymentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal ScheduledPaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets DesiredStatus 
        /// </summary>
        [ViewField(Name = Fields.DesiredStatus, Id = Index.DesiredStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public DesiredStatus DesiredStatus { get; set; }

        /// <summary>
        /// Gets or sets VendorDiscountAmount 
        /// </summary>
        [Display(Name = "DiscAmount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.VendorDiscountAmount, Id = Index.VendorDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DueDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DueDate { get; set; }

        /// <summary>
        /// Gets or sets DiscountDate 
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DiscountDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets ActivationDate 
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ActivationDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ActivationDate, Id = Index.ActivationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ActivationDate { get; set; }

        /// <summary>
        /// Gets or sets IncludeInterest 
        /// </summary>
        [ViewField(Name = Fields.IncludeInterest, Id = Index.IncludeInterest, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeInvoice IncludeInterest { get; set; }

        /// <summary>
        /// Gets or sets ClearPaymentLimit 
        /// </summary>
        [ViewField(Name = Fields.ClearPaymentLimit, Id = Index.ClearPaymentLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public ClearPaymentLimit ClearPaymentLimit { get; set; }

        /// <summary>
        /// Gets or sets PaymentLimit 
        /// </summary>
        [Display(Name = "PaymentLimit", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PaymentLimit, Id = Index.PaymentLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentLimit { get; set; }
    }
}
