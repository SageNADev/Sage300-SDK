
/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region Name spaces

using System;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Partial class for Vendor Group
    /// </summary>
    public partial class VendorGroup : ModelBase
    {
        #region System Generated

        /// <summary>
        /// Gets or sets Group Code 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "GroupCode", ResourceType = typeof(APCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets Status Description.
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        public string StatusDescription
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets formatted InactiveDate.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "InactiveDate", ResourceType = typeof(APCommonResx))]
        public DateTime InactiveDateFormated
        {
            get
            {
                return DateUtil.GetDate(InactiveDate, DateUtil.GetMinDate());
            }
        }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets InactiveDate Converted into DateTime 
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        public DateTime DateLastMaintainedFormated
        {
            get
            {
                return DateUtil.GetDate(DateLastMaintained, DateUtil.GetMinDate());
            }

        }

        /// <summary>
        /// Gets or sets AccountSet 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof(APCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(APCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(APCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(APCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets PrintSeparateChecks 
        /// </summary>
        [Display(Name = "PrintSeparateChecks", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.PrintSeparateChecks, Id = Index.PrintSeparateChecks, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed PrintSeparateChecks { get; set; }

        /// <summary>
        /// Gets Print Separate Checks Description
        /// </summary>
        [Display(Name = "PrintSeparateChecks", ResourceType = typeof(VendorGroupResx))]
        public string PrintSeparateChecksDesc
        {
            get { return EnumUtility.GetStringValue(PrintSeparateChecks); }
        }

        /// <summary>
        /// Gets or sets DistributionSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionSet", ResourceType = typeof(APCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DistributionSet, Id = Index.DistributionSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionSet { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [Display(Name = "DistributionCode", ResourceType = typeof(APCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets GeneralLedgerAccountNo 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLAccount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.GeneralLedgerAccountNo, Id = Index.GeneralLedgerAccountNo, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GeneralLedgerAccountNo { get; set; }

        /// <summary>
        /// Gets or sets Terms 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Terms", ResourceType = typeof(APCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets DuplicateAmountCode 
        /// </summary>
        [Display(Name = "DuplicateAmountCode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DuplicateAmountCode, Id = Index.DuplicateAmountCode, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckforDuplicateChecks DuplicateAmountCode { get; set; }

        /// <summary>
        /// Gets Finder Grid property Set.
        /// </summary>
        [Display(Name = "DuplicateAmountCode", ResourceType = typeof(APCommonResx))]
        public string DuplicateAmountCodeDesc
        {
            get { return EnumUtility.GetStringValue(DuplicateAmountCode); }
        }

        /// <summary>
        /// Gets or sets DuplicateDateCode 
        /// </summary>
        [Display(Name = "DuplicateDateCode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DuplicateDateCode, Id = Index.DuplicateDateCode, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckforDuplicateChecks DuplicateDateCode { get; set; }

        /// <summary>
        /// Gets Finder Grid property Set.
        /// </summary>
        [Display(Name = "DuplicateDateCode", ResourceType = typeof(APCommonResx))]
        public string DuplicateDateCodeDesc
        {
            get { return EnumUtility.GetStringValue(DuplicateDateCode); }
        }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(APCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingType 
        /// </summary>
        [Display(Name = "TaxReportingType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TaxReportingType, Id = Index.TaxReportingType, FieldType = EntityFieldType.Int, Size = 2)]
        public VendorGroupTaxReportingType TaxReportingType { get; set; }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        [Display(Name = "TaxReportingType", ResourceType = typeof(APCommonResx))]
        public string TaxReportingTypeDesc
        {
            get { return EnumUtility.GetStringValue(TaxReportingType); }
        }

        /// <summary>
        /// Gets or sets Num1099OrCPRSCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Num1099OrCPRSCode", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.Num1099OrCPRSCode, Id = Index.Num1099OrCPRSCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Num1099OrCPRSCode { get; set; }

        /// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentCode", ResourceType = typeof(APCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets DistributionType 
        /// </summary>
        [Display(Name = "DistributionType", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.DistributionType, Id = Index.DistributionType, FieldType = EntityFieldType.Int, Size = 2)]
        public VendorGroupDistributionType DistributionType { get; set; }

        /// <summary>
        /// Gets Finder Grid property Set.
        /// </summary>
         [Display(Name = "DistributionType", ResourceType = typeof(VendorGroupResx))]
        public string DistributionTypeDesc
        {
            get { return EnumUtility.GetStringValue(DistributionType); }
        }
        /// <summary>
        /// Gets or sets TaxIncluded1 
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets Finder Grid property Set.
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(VendorGroupResx))]
        public string TaxIncluded1Desc
        {
            get { return EnumUtility.GetStringValue(TaxIncluded1); }
        }

        /// <summary>
        /// Gets or sets TaxIncluded2 
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets Finder Grid property Set.
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(VendorGroupResx))]
        public string TaxIncluded2Desc
        {
            get { return EnumUtility.GetStringValue(TaxIncluded2); }
        }

        /// <summary>
        /// Gets or sets TaxIncluded3 
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets Finder Grid property Set.
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(VendorGroupResx))]
        public string TaxIncluded3Desc
        {
            get { return EnumUtility.GetStringValue(TaxIncluded3); }
        }

        /// <summary>
        /// Gets or sets TaxIncluded4 
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets Finder Grid property Set.
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(VendorGroupResx))]
        public string TaxIncluded4Desc
        {
            get { return EnumUtility.GetStringValue(TaxIncluded4); }
        }

        /// <summary>
        /// Gets or sets TaxIncluded5 
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets Finder Grid property Set.
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(VendorGroupResx))]
        public string TaxIncluded5Desc
        {
            get { return EnumUtility.GetStringValue(TaxIncluded5); }
        }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public VendorGroupsProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets Finder Grid property Set.
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(VendorGroupResx))]
        public string ProcessCommandCodeDesc
        {
            get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        #endregion

        #region UserEntered

        /// <summary>
        /// Gets or sets List of AP Vendor Optional Fields values
        /// </summary>
        /// <value>The recurring entries.</value>
        public EnumerableResponse<VendorGroupOptionalFieldValue> VendorGroupOptionalFieldValues { get; set; }

        /// <summary>
        /// Gets or Sets Active Status
        /// </summary>
        [Display(Name = "InactiveAsOfDate", ResourceType = typeof(CommonResx))]
        public bool IsActive
        {
            get
            {
                return Status != Status.Active;
            }
            set
            {
                Status = value ? Status.Inactive : Status.Active;
            }

        }

        /// <summary>
        /// Gets or sets Print Separate checks value
        /// </summary>
        [Display(Name = "GenerateSeperatePayments", ResourceType = typeof(VendorGroupResx))]
        public bool PrintSeparateChecksBool
        {
            get
            {
                return PrintSeparateChecks == Printed.Yes;
            }
            set
            {
                PrintSeparateChecks = value ? Printed.Yes : Printed.No;
            }
        }

        /// <summary>
        /// Gets or sets Fiscal Period
        /// </summary>
        public FiscalPeriod Period { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period Start  year
        /// </summary>
        public string StartYear { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period End year
        /// </summary>
        public string EndYear { get; set; }

        /// <summary>
        /// Gets ot sets Fiscal Year
        /// </summary>
        public DateTime FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period
        /// </summary>
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Check Language 
        /// </summary>
        public CheckLanguage CheckLanguage { get; set; }

        /// <summary>
        /// Gets or sets Is New Record
        /// </summary>
        public bool IsNewRecord { get; set; }

        #endregion
    }
}
