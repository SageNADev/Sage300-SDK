// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.InvoiceEntry;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Invoice Batch Class 
    /// </summary>
    public partial class InvoiceBatch : BaseInvoiceBatch
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InvoiceBatch"/> class.
        /// </summary>
        public InvoiceBatch()
        {
            PostInvoices = new PostInvoice();
        }

        /// <summary>
        /// Terms related to the Invoice Batch
        /// </summary>
        /// <value>The terms.</value>
        public Terms Terms { get; set; }

        /// <summary>
        /// Set Up Data
        /// </summary>
        public InvoiceBatchsSetup InvoiceBatchsSetup { get; set; }

        #region Security Related Variables

        /// <summary>
        /// Entries related to posting a Invoice
        /// </summary>
        /// <value>The post Invoice.</value>
        public PostInvoice PostInvoices { get; set; }

        /// <summary>
        /// Invoice Batch Entry
        /// </summary>
        public bool IsInvoiceBatchEntry { get; set; }

        /// <summary>
        /// Invoice Batch Inquiry
        /// </summary>
        public bool IsInvoiceBatchInquiry { get; set; }

        /// <summary>
        /// PrePay Inquiry
        /// </summary>
        public bool IsPrepayInquiry { get; set; }

        /// <summary>
        /// PrePay Modify
        /// </summary>
        public bool IsPrepayModify { get; set; }

        /// <summary>
        /// Transaction Optional Fields
        /// </summary>
        public bool IsTransactionOptionalFields { get; set; }

        /// <summary>
        /// Can Add Vendor
        /// </summary>
        public bool CanAddVendor { get; set; }

        /// <summary>
        /// Can AddRemit To
        /// </summary>
        public bool CanAddRemitTo { get; set; }

        /// <summary>
        /// Can Print Checks
        /// </summary>
        public bool CanPrintChecks { get; set; }

        #endregion

    }

    /// <summary>
    /// Invoice Batch Setup
    /// </summary>
    public class InvoiceBatchsSetup : ModelBase
    {
        /// <summary>
        /// OE Module
        /// </summary>
        public const string OEModule = "OE";

        /// <summary>
        /// GL Module
        /// </summary>
        public const string GLModule = "GL";

        /// <summary>
        /// PM Module
        /// </summary>
        public const string PMModule = "PM";

        /// <summary>
        /// IC Module
        /// </summary>
        public const string ICModule = "IC";

        /// <summary>
        /// PO Module
        /// </summary>
        public const string POModule = "PO";

        /// <summary>
        /// Is Multicurrency
        /// </summary>
        public bool IsMultiCurrency;

        /// <summary>
        /// Gets or sets the currencydecimals.
        /// </summary>
        //public string CurrencyDecimals;

        /// <summary>
        /// OE Exist
        /// </summary>
        public bool OEExist;

        /// <summary>
        /// GL Exist
        /// </summary>
        public bool GLExist;

        /// <summary>
        /// PM Exist
        /// </summary>
        public bool PMExist;

        /// <summary>
        /// IC Exist
        /// </summary>
        public bool ICExist;

        /// <summary>
        /// PO Exist
        /// </summary>
        public bool POExist;

        /// <summary>
        /// Is Quantities enabled
        /// </summary>
        public bool HasQuantities;

        /// <summary>
        /// Has Optional Field license
        /// </summary>
        public bool HasOptionalFields;
    }
}
