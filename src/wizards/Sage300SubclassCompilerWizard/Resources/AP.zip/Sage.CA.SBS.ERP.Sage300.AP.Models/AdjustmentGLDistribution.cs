/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class AdjustmentGLDistribution : ModelBase
    {
        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BatchType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BatchNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "EntryNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "LineNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets SequenceNo 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "SequenceNo", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.SequenceNo, Id = Index.SequenceNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal SequenceNo { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransactionType { get; set; }

        /// <summary>
        /// Gets or sets DistributionAmount 
        /// </summary>
        [Display(Name = "DistributionAmount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DistributionAmount, Id = Index.DistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets DistributionGOrLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionGLAccount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DistributionGLAccount, Id = Index.DistributionGLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DistributionGLAccount { get; set; }

        /// <summary>
        /// Gets or sets ContractCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectOrCategoryResource 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectOrCategoryResource", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ProjectOrCategoryResource, Id = Index.ProjectOrCategoryResource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string ProjectOrCategoryResource { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber 
        /// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets CostClass 
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public Common.Models.Enums.InvoiceEntry.CostClass CostClass { get; set; }

        /// <summary>
        /// To Get the Enum string of Cost Class
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(APCommonResx))]
        public string CostClassString { get; set; }

        /// <summary>
        /// Gets or sets BillingType 
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmount 
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets AppliedAmount 
        /// </summary>
        [Display(Name = "AppliedAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AppliedAmount, Id = Index.AppliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AppliedAmount { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitofMeasure 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitofMeasure", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.UnitofMeasure, Id = Index.UnitofMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitofMeasure { get; set; }

        /// <summary>
        /// Gets or sets Quantity 
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets Cost 
        /// </summary>
        [Display(Name = "Cost", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets BillingDate 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingDate, Id = Index.BillingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string BillingDate { get; set; }

        /// <summary>
        /// Gets or sets BillingRate 
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount 
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDate 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageDueDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.RetainageDueDate, Id = Index.RetainageDueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string RetainageDueDate { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage 
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets FuncDistributionAmount 
        /// </summary>
        [Display(Name = "FuncDistributionAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncDistributionAmount, Id = Index.FuncDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncDiscountAmount 
        /// </summary>
        [Display(Name = "FuncDiscountAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncDiscountAmount, Id = Index.FuncDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncAppliedAmount 
        /// </summary>
        [Display(Name = "FuncAppliedAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncAppliedAmount, Id = Index.FuncAppliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAppliedAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncRetainageAmount 
        /// </summary>
        [Display(Name = "FuncRetainageAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncRetainageAmount, Id = Index.FuncRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets DocumentLineNumber 
        /// </summary>
        [Display(Name = "DocumentLineNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DocumentLineNumber, Id = Index.DocumentLineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal DocumentLineNumber { get; set; }

        /// <summary>
        /// Gets or sets VendCurrencyAmountDue 
        /// </summary>
        [Display(Name = "VendCurrencyAmountDue", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendCurrencyAmountDue, Id = Index.VendCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        [Display(Name = "SerialNumber", ResourceType = typeof(PaymentEntryResx))]
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Account Description
        /// </summary>
        [Display(Name = "AccountDescription", ResourceType = typeof(APCommonResx))]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets the positive Distribution Amount 
        /// </summary>
        /// <value>The debit amount.</value>
        [Display(Name = "DebitAmount", ResourceType = typeof(PaymentEntryResx))]
        public decimal DebitAmount { get; set; }

        /// <summary>
        /// Gets or sets the negative Distribution Amount 
        /// </summary>
        /// <value>The credit amount.</value>
        [Display(Name = "CreditAmount", ResourceType = typeof(PaymentEntryResx))]
        public decimal CreditAmount { get; set; }

        /// <summary>
        /// Gets or sets DebitRetainageAmount  for grid 
        /// </summary>      
        public decimal DebitRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets creditRetainageAmount  for grid 
        /// </summary>      
        public decimal CreditRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1TC, Id = Index.AmtWHD1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2TC, Id = Index.AmtWHD2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3TC, Id = Index.AmtWHD3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4TC, Id = Index.AmtWHD4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5TC, Id = Index.AmtWHD5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1HC, Id = Index.AmtWHD1HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2HC, Id = Index.AmtWHD2HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3HC, Id = Index.AmtWHD3HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4HC, Id = Index.AmtWHD4HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5HC, Id = Index.AmtWHD5HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Tax Withheld Amount Total
        /// </summary>
        [ViewField(Name = Fields.AmtWHDTot, Id = Index.AmtWHDTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets ProjectStyle
        /// </summary>
        [ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets UnformattedContractCode
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.UnformattedContractCode, Id = Index.UnformattedContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string UnformattedContractCode { get; set; }
        
        /// <summary>
        /// Gets or sets editable state for PJC columns
        /// </summary>
        [IgnoreExportImport]
        public Dictionary<string, bool> PMDisableDictionary { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this detail line's project style is standard.
        /// </summary>
        [IgnoreExportImport]
        public bool IsProjectStyleStandard { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this detail line's project style is basic.
        /// </summary>
        [IgnoreExportImport]
        public bool IsProjectStyleBasic { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this detail line's project type is time and material.
        /// </summary>
        [IgnoreExportImport]
        public bool IsProjectTimeMaterial { get; set; }

        /// <summary>
        /// The list of values for the <see cref="BillingType"/> enumeration
        /// </summary>
        public IEnumerable<CustomSelectList> BillingTypeList { get; set; }
    }
}
