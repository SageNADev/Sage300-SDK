﻿
/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public class VendorInfo 
    {
        /// <summary>
        /// Gets Vendor Number 
        /// </summary>
        [Display(Name = "VendorNumber", ResourceType = typeof(VendorResx))]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets Vendor Name.
        /// </summary>
        [Display(Name = "VendorName", ResourceType = typeof(VendorResx))]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets Short Name 
        /// </summary>
        [Display(Name = "ShortName", ResourceType = typeof(VendorResx))]
        public string ShortName { get; set; }

        /// <summary>
        /// Gets Address Line1 
        /// </summary>
        [Display(Name = "AddressLine1", ResourceType = typeof(VendorResx))]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets Address Line2 
        /// </summary>
        [Display(Name = "AddressLine2", ResourceType = typeof(VendorResx))]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets Address Line3 
        /// </summary>
        [Display(Name = "AddressLine3", ResourceType = typeof(VendorResx))]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets Address Line4 
        /// </summary>
        [Display(Name = "AddressLine4", ResourceType = typeof(VendorResx))]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets City 
        /// </summary>
        [Display(Name = "City", ResourceType = typeof(VendorResx))]
        public string City { get; set; }

        /// <summary>
        /// Gets State Or Province
        /// </summary>
        [Display(Name = "StateProvince", ResourceType = typeof(VendorResx))]
        public string StateOrProvince { get; set; }

        /// <summary>
        /// Gets Zip Or Postal Code 
        /// </summary>
        [Display(Name = "ZipPostalCode", ResourceType = typeof(APCommonResx))]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets Country 
        /// </summary>
        [Display(Name = "Country", ResourceType = typeof(VendorResx))]
        public string Country { get; set; }

        /// <summary>
        /// Gets Phone Number 
        /// </summary>
        [Display(Name = "PhoneNumber", ResourceType = typeof(VendorResx))]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets Fax Number 
        /// </summary>
        [Display(Name = "FaxNumber", ResourceType = typeof(VendorResx))]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets Email 
        /// </summary>
        [Display(Name = "Email", ResourceType = typeof(APCommonResx))]
        public string Email { get; set; }

        /// <summary>
        /// Gets Contacts Name
        /// </summary>
        [Display(Name = "ContactsEmail", ResourceType = typeof(VendorResx))]
        public string ContactsName { get; set; }

        /// <summary>
        /// Gets Contacts Phone
        /// </summary>
        [Display(Name = "PhoneNumber", ResourceType = typeof(VendorResx))]
        public string ContactsPhone { get; set; }

        /// <summary>
        /// Gets Contacts Fax
        /// </summary>
        [Display(Name = "FaxNumber", ResourceType = typeof(VendorResx))]
        public string ContactsFax { get; set; }

        /// <summary>
        /// Gets Contacts Email 
        /// </summary>
        [Display(Name = "ContactsEmail", ResourceType = typeof(VendorResx))]
        public string ContactsEmail { get; set; }

        /// <summary>
        /// Gets or sets Tax Reporting Type 
        /// </summary>
        [Display(Name = "TaxReportingType", ResourceType = typeof(VendorGroupResx))]
        public TaxReportingType TaxReportingType { get; set; }

        /// <summary>
        /// Gets or sets OnHold 
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(VendorResx))]
        public OnHold OnHold { get; set; }
    }
}
