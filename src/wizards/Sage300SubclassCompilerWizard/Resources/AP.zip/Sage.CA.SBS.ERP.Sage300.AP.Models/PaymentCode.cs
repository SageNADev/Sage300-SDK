/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */


using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Paymentcode class
    /// </summary>
    public partial class PaymentCode : ModelBase
	{

        /// <summary>
        /// Constructor
        /// </summary>
        public PaymentCode()
        {
            Status = Status.Active;
            PaymentType = PaymentType.Cash;
        }

        /// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [Display(Name = "PaymentCode", ResourceType = typeof(PaymentCodesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
		[ViewField(Name = Fields.PaymentCodeKey, Id = Index.PaymentCodeKey, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string PaymentCodeKey {get; set;}

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [Display(Name = "PaymentCodeDesc", ResourceType = typeof(PaymentCodesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string Description {get; set;}
	 
		/// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
		[ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
		public Status Status {get; set;}

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(APCommonResx))]
		[ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime InactiveDate {get; set;}

        /// <summary>
        /// Gets status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }


		/// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateLastMaintained {get; set;}

        /// <summary>
        /// Gets or sets PaymentType 
        /// </summary>
         [Display(Name = "PaymentType", ResourceType = typeof(PaymentCodesResx))]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets string value of the PaymentType enum
        /// </summary>       
        public string PaymentTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(PaymentType);
            }
        }


    

	    }




}
