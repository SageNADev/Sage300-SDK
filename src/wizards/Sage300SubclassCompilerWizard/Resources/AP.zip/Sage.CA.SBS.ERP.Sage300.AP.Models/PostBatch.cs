﻿/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// PostBatch Model 
    /// </summary>
    public partial class PostBatch : ModelBase
    {
        /// <summary>
        /// Gets or sets PostAllBatchesSwitch
        /// </summary>
        /// <value>The post all batches switch</value>
        public PostAllBatchSwitch PostAllBatchSwitch { get; set; }

        /// <summary>
        /// Gets or sets ProvisionalPostSwitch
        /// </summary>
        /// <value>Provisional post switch</value>
        public PostBatchTypeSwitch PostBatchTypeSwitch { get; set; }

        /// <summary>
        /// Gets or sets FromBatchNumber
        /// </summary>
        /// <value>From batch number</value>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromBatchNumber", ResourceType = typeof(PostBatchesResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets ToBatchNumber
        /// </summary>
        /// <value>To batch number</value>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToBatchNumber", ResourceType = typeof(PostBatchesResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToBatchNumber { get; set; }

        /// <summary>
        /// Invoice button enabled
        /// </summary>
        public bool IsInvoiceEnabled { get; set; }

        /// <summary>
        /// Payment button enabled
        /// </summary>
        public bool IsPaymentEnabled { get; set; }

        /// <summary>
        /// Adjustment button enabled
        /// </summary>
        public bool IsAdjustmentEnabled { get; set; }
    }
}
