/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
	public partial class OptionalFields : ModelBase
	{	 
  		/// <summary>
        /// Gets or sets Location 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(VendorResx))]
        [Key]       
 		[ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
 		public Location Location {get; set;}
		 
  		/// <summary>
        /// Gets or sets OptionalField 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(APCommonResx))]
        [Key]
 		[ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
 		public string OptionalField {get; set;}
		 
  		/// <summary>
        /// Gets or sets DefaultValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValue", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.DefaultValue, Id = Index.DefaultValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
 		public string DefaultValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets Type 
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
 		public Type Type {get; set;}
		 
  		/// <summary>
        /// Gets or sets Length 
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
 		public int Length {get; set;}
		 
  		/// <summary>
        /// Gets or sets Decimals 
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
 		public int Decimals {get; set;}
		 
  		/// <summary>
        /// Gets or sets AllowBlank 
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
 		public AllowBlank AllowBlank {get; set;}
		 
  		/// <summary>
        /// Gets or sets Validate 
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
 		public AllowBlank Validate {get; set;}
		 
  		/// <summary>
        /// Gets or sets AutoInsert 
        /// </summary>
        [Display(Name = "AutoInsert", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.AutoInsert, Id = Index.AutoInsert, FieldType = EntityFieldType.Int, Size = 2)]
 		public AllowBlank AutoInsert {get; set;}
		 
  		/// <summary>
        /// Gets or sets PayablesControl 
        /// </summary>
        [Display(Name = "PayablesControl", ResourceType = typeof(VendorResx))]
 		[ViewField(Name = Fields.PayablesControl, Id = Index.PayablesControl, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl PayablesControl {get; set;}
		 
  		/// <summary>
        /// Gets or sets Retain age 
        /// </summary>
        [Display(Name = "Retainage", ResourceType = typeof(VendorResx))]
 		[ViewField(Name = Fields.Retainage, Id = Index.Retainage, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl Retainage {get; set;}
		 
  		/// <summary>
        /// Gets or sets PurchaseDiscount 
        /// </summary>
        [Display(Name = "PurchaseDiscount", ResourceType = typeof(VendorResx))]
 		[ViewField(Name = Fields.PurchaseDiscount, Id = Index.PurchaseDiscount, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl PurchaseDiscount {get; set;}
		 
  		/// <summary>
        /// Gets or sets RecoverableTax 
        /// </summary>
        [Display(Name = "RecoverableTax", ResourceType = typeof(VendorResx))]
 		[ViewField(Name = Fields.RecoverableTax, Id = Index.RecoverableTax, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl RecoverableTax {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExpenseTax 
        /// </summary>
        [Display(Name = "ExpenseTax", ResourceType = typeof(VendorResx))]
 		[ViewField(Name = Fields.ExpenseTax, Id = Index.ExpenseTax, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl ExpenseTax {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeGain 
        /// </summary>
        [Display(Name = "ExchangeGain", ResourceType = typeof(VendorResx))]
 		[ViewField(Name = Fields.ExchangeGain, Id = Index.ExchangeGain, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl ExchangeGain {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeLoss 
        /// </summary>
        [Display(Name = "ExchangeLoss", ResourceType = typeof(VendorResx))]
 		[ViewField(Name = Fields.ExchangeLoss, Id = Index.ExchangeLoss, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl ExchangeLoss {get; set;}
		 
  		/// <summary>
        /// Gets or sets UnrealizedExchangeGain 
        /// </summary>
        [Display(Name = "UnrealizedExchangeGain", ResourceType = typeof(VendorResx))]
 		[ViewField(Name = Fields.UnrealizedExchangeGain, Id = Index.UnrealizedExchangeGain, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl UnrealizedExchangeGain {get; set;}
		 
  		/// <summary>
        /// Gets or sets UnrealizedExchangeLoss 
        /// </summary>
        [Display(Name = "UnrealizedExchangeLoss", ResourceType = typeof(VendorResx))]
 		[ViewField(Name = Fields.UnrealizedExchangeLoss, Id = Index.UnrealizedExchangeLoss, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl UnrealizedExchangeLoss {get; set;}
		 
  		/// <summary>
        /// Gets or sets Rounding 
        /// </summary>
        [Display(Name = "Rounding", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.Rounding, Id = Index.Rounding, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl Rounding {get; set;}
		 
  		/// <summary>
        /// Gets or sets Distribution 
        /// </summary>
        [Display(Name = "Distribution", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.Distribution, Id = Index.Distribution, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl Distribution {get; set;}
		 
  		/// <summary>
        /// Gets or sets Prepayment 
        /// </summary>
        [Display(Name = "Prepayment", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.Prepayment, Id = Index.Prepayment, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl Prepayment {get; set;}
		 
  		/// <summary>
        /// Gets or sets MiscellaneousPayment 
        /// </summary>
        [Display(Name = "MiscellaneousPayment", ResourceType = typeof(VendorResx))] 
 		[ViewField(Name = Fields.MiscellaneousPayment, Id = Index.MiscellaneousPayment, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl MiscellaneousPayment {get; set;}
		 
  		/// <summary>
        /// Gets or sets Bank 
        /// </summary>
       [Display(Name = "Bank", ResourceType = typeof(APCommonResx))]  
 		[ViewField(Name = Fields.Bank, Id = Index.Bank, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl Bank {get; set;}
		 
  		/// <summary>
        /// Gets or sets Adjustment 
        /// </summary>
        [Display(Name = "Adjustment", ResourceType = typeof(APCommonResx))]  
 		[ViewField(Name = Fields.Adjustment, Id = Index.Adjustment, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl Adjustment {get; set;}
		 
  		/// <summary>
        /// Gets or sets Labor 
        /// </summary>
        [Display(Name = "Labor", ResourceType = typeof(APCommonResx))]  
 		[ViewField(Name = Fields.Labor, Id = Index.Labor, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl Labor {get; set;}
		 
  		/// <summary>
        /// Gets or sets Overhead 
        /// </summary>
        [Display(Name = "Overhead", ResourceType = typeof(APCommonResx))]   
 		[ViewField(Name = Fields.Overhead, Id = Index.Overhead, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl Overhead {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExternalCostTransactions 
        /// </summary>
        [Display(Name = "ExternalCostTransactions", ResourceType = typeof(VendorResx))]   
 		[ViewField(Name = Fields.ExternalCostTransactions, Id = Index.ExternalCostTransactions, FieldType = EntityFieldType.Int, Size = 2)]
 		public PayablesControl ExternalCostTransactions {get; set;}
		 
  		/// <summary>
        /// Gets or sets Required 
        /// </summary>
        [Display(Name = "Required", ResourceType = typeof(APCommonResx))]   
 		[ViewField(Name = Fields.Required, Id = Index.Required, FieldType = EntityFieldType.Int, Size = 2)]
 		public AllowBlank Required {get; set;}
		 
  		/// <summary>
        /// Gets or sets ValueSet 
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(APCommonResx))]   
 		[ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
 		public AllowBlank ValueSet {get; set;}
		 
  		/// <summary>
        /// Gets or sets TypedDefaultValueFieldIndex 
        /// </summary>
        [Display(Name = "TypedDefaultValueFieldIndex", ResourceType = typeof(VendorResx))] 
 		[ViewField(Name = Fields.TypedDefaultValueFieldIndex, Id = Index.TypedDefaultValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
 		public long TypedDefaultValueFieldIndex {get; set;}
		 
  		/// <summary>
        /// Gets or sets DefaultTextValue 
        /// </summary>
        [Display(Name = "DefaultTextValue", ResourceType = typeof(APCommonResx))] 
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.DefaultTextValue, Id = Index.DefaultTextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
 		public string DefaultTextValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets DefaultAmountValue 
        /// </summary>
        [Display(Name = "DefaultAmountValue", ResourceType = typeof(APCommonResx))] 
 		[ViewField(Name = Fields.DefaultAmountValue, Id = Index.DefaultAmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal DefaultAmountValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets DefaultNumberValue 
        /// </summary>
        [Display(Name = "DefaultNumberValue", ResourceType = typeof(APCommonResx))]  
 		[ViewField(Name = Fields.DefaultNumberValue, Id = Index.DefaultNumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
 		public decimal DefaultNumberValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets DefaultIntegerValue 
        /// </summary>
        [Display(Name = "DefaultIntegerValue", ResourceType = typeof(APCommonResx))]  
 		[ViewField(Name = Fields.DefaultIntegerValue, Id = Index.DefaultIntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
 		public long DefaultIntegerValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets DefaultYesOrNoValue 
        /// </summary>
        [Display(Name = "DefaultYesOrNoValue", ResourceType = typeof(APCommonResx))]   
 		[ViewField(Name = Fields.DefaultYesOrNoValue, Id = Index.DefaultYesOrNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
 		public AllowBlank DefaultYesOrNoValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets DefaultDateValue 
        /// </summary>
        [Display(Name = "DefaultDateValue", ResourceType = typeof(APCommonResx))]   
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.DefaultDateValue, Id = Index.DefaultDateValue, FieldType = EntityFieldType.Date, Size = 5)]
 		public string DefaultDateValue {get; set;}
		
		/// <summary>
        /// Gets or sets DefaultTimeValue 
        /// </summary>
		 //[ValidateDateFormat(ErrorMessage="*")]	
        [Display(Name = "DefaultTimeValue", ResourceType = typeof(APCommonResx))]   
        [ViewField(Name = Fields.DefaultTimeValue, Id = Index.DefaultTimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public System.DateTime DefaultTimeValue {get; set;}
	 
  		/// <summary>
        /// Gets or sets OptionalFieldDescription 
        /// </summary>
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(APCommonResx))]   
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
 		public string OptionalFieldDescription {get; set;}
		 
  		/// <summary>
        /// Gets or sets DefaultValueDescription 
        /// </summary>
        [Display(Name = "DefaultValueDescription", ResourceType = typeof(APCommonResx))]   
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.DefaultValueDescription, Id = Index.DefaultValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
 		public string DefaultValueDescription {get; set;}

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        [IgnoreExportImport]
        public string TypeString
        {
            get
            {
                return EnumUtility.GetStringValue(Type);
            }
        }

        /// <summary>
        /// To get the string of AllowBlank property
        /// </summary>
        [IgnoreExportImport]
	    public string AllowBlankString
	    {
	        get
	        {
	            return EnumUtility.GetStringValue(AllowBlank);
	        }
	    }

        /// <summary>
        /// To get the string of Validate property
        /// </summary>
        [IgnoreExportImport]
        public string ValidateString
        {
            get
            {
                return EnumUtility.GetStringValue(Validate);
            }
        }

        /// <summary>
        /// To get the string of AutoInsert property
        /// </summary>
        [IgnoreExportImport]
        public string AutoInsertString
        {
            get
            {
                return EnumUtility.GetStringValue(AutoInsert);
            }
        }

        /// <summary>
        /// To get the string of PayablesControl property
        /// </summary>
        [IgnoreExportImport]
        public string PayablesControlString
        {
            get
            {
                return EnumUtility.GetStringValue(PayablesControl);
            }
        }

        /// <summary>
        /// To get the string of Retainage property
        /// </summary>
        [IgnoreExportImport]
        public string RetainageString
        {
            get
            {
                return EnumUtility.GetStringValue(Retainage);
            }
        }

        /// <summary>
        /// To get the string of PurchaseDiscount property
        /// </summary>
        [IgnoreExportImport]
        public string PurchaseDiscountString
        {
            get
            {
                return EnumUtility.GetStringValue(PurchaseDiscount);
            }
        }


        /// <summary>
        /// To get the string of RecoverableTax property
        /// </summary>
        [IgnoreExportImport]
        public string RecoverableTaxString
        {
            get
            {
                return EnumUtility.GetStringValue(RecoverableTax);
            }
        }

        /// <summary>
        /// To get the string of ExpenseTax property
        /// </summary>
        [IgnoreExportImport]
        public string ExpenseTaxString
        {
            get
            {
                return EnumUtility.GetStringValue(ExpenseTax);
            }
        }

        /// <summary>
        /// To get the string of ExchangeGain property
        /// </summary>
        [IgnoreExportImport]
        public string ExchangeGainString
        {
            get
            {
                return EnumUtility.GetStringValue(ExchangeGain);
            }
        }

        /// <summary>
        /// To get the string of ExchangeLoss property
        /// </summary>
        [IgnoreExportImport]
        public string ExchangeLossString
        {
            get
            {
                return EnumUtility.GetStringValue(ExchangeLoss);
            }
        }

        /// <summary>
        /// To get the string of UnrealizedExchangeGain property
        /// </summary>
        [IgnoreExportImport]
        public string UnrealizedExchangeGainString
        {
            get
            {
                return EnumUtility.GetStringValue(UnrealizedExchangeGain);
            }
        }

        /// <summary>
        /// To get the string of UnrealizedExchangeLoss property
        /// </summary>
        [IgnoreExportImport]
        public string UnrealizedExchangeLossString
        {
            get
            {
                return EnumUtility.GetStringValue(UnrealizedExchangeLoss);
            }
        }

        /// <summary>
        /// To get the string of Rounding property
        /// </summary>
        [IgnoreExportImport]
        public string RoundingString
        {
            get
            {
                return EnumUtility.GetStringValue(Rounding);
            }
        }

        /// <summary>
        /// To get the string of Distribution property
        /// </summary>
        [IgnoreExportImport]
        public string DistributionString
        {
            get
            {
                return EnumUtility.GetStringValue(Distribution);
            }
        }

        /// <summary>
        /// To get the string of Prepayment property
        /// </summary>
        [IgnoreExportImport]
        public string PrepaymentString
        {
            get
            {
                return EnumUtility.GetStringValue(Prepayment);
            }
        }

        /// <summary>
        /// To get the string of MiscellaneousPayment property
        /// </summary>
        [IgnoreExportImport]
        public string MiscellaneousPaymentString
        {
            get
            {
                return EnumUtility.GetStringValue(MiscellaneousPayment);
            }
        }

        /// <summary>
        /// To get the string of Bank property
        /// </summary>
        [IgnoreExportImport]
        public string BankString
        {
            get
            {
                return EnumUtility.GetStringValue(Bank);
            }
        }

        /// <summary>
        /// To get the string of Adjustment property
        /// </summary>
        [IgnoreExportImport]
        public string AdjustmentString
        {
            get
            {
                return EnumUtility.GetStringValue(Adjustment);
            }
        }

        /// <summary>
        /// To get the string of Labor property
        /// </summary>
        [IgnoreExportImport]
        public string LaborString
        {
            get
            {
                return EnumUtility.GetStringValue(Labor);
            }
        }

        /// <summary>
        /// To get the string of Overhead property
        /// </summary>
        [IgnoreExportImport]
        public string OverheadString
        {
            get
            {
                return EnumUtility.GetStringValue(Overhead);
            }
        }

        /// <summary>
        /// To get the string of ExternalCostTransactions property
        /// </summary>
        [IgnoreExportImport]
        public string ExternalCostTransactionsString
        {
            get
            {
                return EnumUtility.GetStringValue(ExternalCostTransactions);
            }
        }

        /// <summary>
        /// To get the string of Required property
        /// </summary>
        [IgnoreExportImport]
        public string RequiredString
        {
            get
            {
                return EnumUtility.GetStringValue(Required);
            }
        }

        /// <summary>
        /// To get the string of ValueSet property
        /// </summary>
        [IgnoreExportImport]
        public string ValueSetString
        {
            get
            {
                return EnumUtility.GetStringValue(ValueSet);
            }
        }

        /// <summary>
        /// To get the string of DefaultYesOrNoValue property
        /// </summary>
        [IgnoreExportImport]
        public string DefaultYesOrNoValueString
        {
            get
            {
                return EnumUtility.GetStringValue(DefaultYesOrNoValue);
            }
        }

        /// <summary>
        /// To get the string of Location property
        /// </summary>
        [IgnoreExportImport]
        public string LocationString
        {
            get
            {
                return EnumUtility.GetStringValue(Location);
            }
        }
	}
}
