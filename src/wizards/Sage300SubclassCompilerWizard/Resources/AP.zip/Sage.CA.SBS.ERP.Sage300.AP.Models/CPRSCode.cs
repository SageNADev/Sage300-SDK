/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class CPRSCode : ModelBase
    {
        /// <summary>
        /// Constructor for 1099/CPRS Codes
        /// </summary>
        public CPRSCode()
        {
            Status = Status.Active;
        }

        /// <summary>
        /// Gets or sets 1099/CPRS Codes
        /// </summary>
        [Display(Name = "_1099CPRSCode", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.Code, Id = Index.Code, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [Display(Name = "CPRSCodeDesc", ResourceType=typeof(_1099CPRSCodesResx))]
       [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
          [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

          /// <summary>
          /// Gets or sets InactiveDate 
          /// </summary>  
          [Display(Name = "InactiveDate", ResourceType = typeof(APCommonResx))]
          [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime InactiveDate { get; set; }

         /// <summary>
         /// Gets status string value
         /// </summary>
         public string StatusString
         {
             get { return EnumUtility.GetStringValue(Status); }
         }

          /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Minimum Amount to Report 
        /// </summary>

        [Display(Name = "MinAmtToRpt", ResourceType = typeof(_1099CPRSCodesResx))]
      [ViewField(Name = Fields.MinimumAmountToReport, Id = Index.MinimumAmountToReport, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
      public decimal MinimumAmountToReport { get; set; }

        /// <summary>
        /// Gets or sets Tax Reporting Type
        /// </summary>
        [Display(Name = "TaxReportingType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TaxReportingType, Id = Index.TaxReportingType, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxReportingType TaxReportingType { get; set; } = TaxReportingType.None;

        /// <summary>
        /// Gets or sets Amount Type 
        /// </summary>
        [Display(Name = "AmountType", ResourceType = typeof(_1099CPRSCodesResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Int, Size = 2)]
        public Category Category { get; set; } = Category.None;

    }
}
