// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class Document Sched Payment
    /// </summary>
    public partial class DocumentSchedPayment : ModelBase
    {
        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber 
        /// </summary>
        [StringLength(18, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Char, Size = 18, Mask = "%-18D")]
        public string CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DueDate { get; set; }

        /// <summary>
        /// Gets or sets DiscountDate 
        /// </summary>
        [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets FullyPaid 
        /// </summary>
        [ViewField(Name = Fields.FullyPaid, Id = Index.FullyPaid, FieldType = EntityFieldType.Int, Size = 2)]
        public FullyPaid FullyPaid { get; set; }

        /// <summary>
        /// Gets or sets OriginalAmountFunc 
        /// </summary>
        [ViewField(Name = Fields.OriginalAmountFunc, Id = Index.OriginalAmountFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalAmountFunc { get; set; }

        /// <summary>
        /// Gets or sets OriginalDiscountFunc 
        /// </summary>
        [ViewField(Name = Fields.OriginalDiscountFunc, Id = Index.OriginalDiscountFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalDiscountFunc { get; set; }

        /// <summary>
        /// Gets or sets RemainingDiscountFunc 
        /// </summary>
        [ViewField(Name = Fields.RemainingDiscountFunc, Id = Index.RemainingDiscountFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingDiscountFunc { get; set; }

        /// <summary>
        /// Gets or sets RemainingAmountFunc 
        /// </summary>
        [ViewField(Name = Fields.RemainingAmountFunc, Id = Index.RemainingAmountFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingAmountFunc { get; set; }

        /// <summary>
        /// Gets or sets OriginalAmount 
        /// </summary>
        [ViewField(Name = Fields.OriginalAmount, Id = Index.OriginalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalAmount { get; set; }

        /// <summary>
        /// Gets or sets OriginalDiscount 
        /// </summary>
        [ViewField(Name = Fields.OriginalDiscount, Id = Index.OriginalDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalDiscount { get; set; }

        /// <summary>
        /// Gets or sets RemainingDiscount 
        /// </summary>
        [ViewField(Name = Fields.RemainingDiscount, Id = Index.RemainingDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingDiscount { get; set; }

        /// <summary>
        /// Gets or sets RemainingAmount 
        /// </summary>
        [ViewField(Name = Fields.RemainingAmount, Id = Index.RemainingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingAmount { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PONumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PONumber { get; set; }

        /// <summary>
        /// Gets or sets GroupCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets PrepayInvoiceNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepayInvoiceNumber, Id = Index.PrepayInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PrepayInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets DocumentDate 
        /// </summary>
        [ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocumentDate { get; set; }

        /// <summary>
        /// Gets or sets ActivationDate 
        /// </summary>
        [ViewField(Name = Fields.ActivationDate, Id = Index.ActivationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ActivationDate { get; set; }

        /// <summary>
        /// Gets or sets NumberofDaystoPay 
        /// </summary>
        [ViewField(Name = Fields.NumberofDaystoPay, Id = Index.NumberofDaystoPay, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberofDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public FullyPaid JobRelated { get; set; }

        /// <summary>
        /// Gets or sets PaymentLimit 
        /// </summary>
        [ViewField(Name = Fields.PaymentLimit, Id = Index.PaymentLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentLimit { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }

        #region Properties for finder

        /// <summary>
        /// Document Type String
        /// </summary>
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Transaction Type String
        /// </summary>
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        /// <summary>
        /// Fully Paid String
        /// </summary>
        public string FullyPaidString
        {
            get { return EnumUtility.GetStringValue(FullyPaid); }
        }

        /// <summary>
        /// Job Related String
        /// </summary>
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        #endregion
    }
}
