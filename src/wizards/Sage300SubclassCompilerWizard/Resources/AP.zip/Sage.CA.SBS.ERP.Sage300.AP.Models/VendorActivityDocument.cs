/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class VendorActivityDocument : ModelBase
    {
        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber 
        /// </summary>
        [StringLength(18, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Char, Size = 18, Mask = "%-18D")]
        public string CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PONumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DueDate { get; set; }

        /// <summary>
        /// Gets or sets RemitToLocation 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RemitToLocation, Id = Index.RemitToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RemitToLocation { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public VendorDocumentTransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BatchDate { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets GroupCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets DocDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DocDescription, Id = Index.DocDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DocDescription { get; set; }

        /// <summary>
        /// Gets or sets DocDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DocDate, Id = Index.DocDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceasofDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? InvoiceasOfDate { get; set; }

        /// <summary>
        /// Gets or sets Terms 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets DiscountDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateOverridden 
        /// </summary>
        [ViewField(Name = Fields.RateOverridden, Id = Index.RateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden RateOverridden { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyInvoiceAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalCurrencyInvoiceAmount, Id = Index.FunctionalCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyAmountDue 
        /// </summary>
        [ViewField(Name = Fields.FunctionalCurrencyAmountDue, Id = Index.FunctionalCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyTaxableAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalCurrencyTaxableAmount, Id = Index.FunctionalCurrencyTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyNonTaxableAmt 
        /// </summary>
        [ViewField(Name = Fields.FunctionalCurrencyNonTaxableAmt, Id = Index.FunctionalCurrencyNonTaxableAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyNonTaxableAmt { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyTaxAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalCurrencyTaxAmount, Id = Index.FunctionalCurrencyTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyDiscountAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalCurrencyDiscountAmount, Id = Index.FunctionalCurrencyDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyInvoiceAmount 
        /// </summary>
        [ViewField(Name = Fields.VendorCurrencyInvoiceAmount, Id = Index.VendorCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyAmountDue 
        /// </summary>
        [ViewField(Name = Fields.VendorCurrencyAmountDue, Id = Index.VendorCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyTaxableAmount 
        /// </summary>
        [ViewField(Name = Fields.VendorCurrencyTaxableAmount, Id = Index.VendorCurrencyTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyNonTaxableAmt 
        /// </summary>
        [ViewField(Name = Fields.VendorCurrencyNonTaxableAmt, Id = Index.VendorCurrencyNonTaxableAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyNonTaxableAmt { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyTaxAmount 
        /// </summary>
        [ViewField(Name = Fields.VendorCurrencyTaxAmount, Id = Index.VendorCurrencyTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyDiscountAmount 
        /// </summary>
        [ViewField(Name = Fields.VendorCurrencyDiscountAmount, Id = Index.VendorCurrencyDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FullyPaid 
        /// </summary>
        [ViewField(Name = Fields.FullyPaid, Id = Index.FullyPaid, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden FullyPaid { get; set; }

        /// <summary>
        /// Gets or sets LastActivityDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastActivityDate, Id = Index.LastActivityDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastActivityDate { get; set; }

        /// <summary>
        /// Gets or sets LastStatementDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastStatementDate, Id = Index.LastStatementDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastStatementDate { get; set; }

        /// <summary>
        /// Gets or sets NumberofScheduledPayments 
        /// </summary>
        [ViewField(Name = Fields.NumberofScheduledPayments, Id = Index.NumberofScheduledPayments, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofScheduledPayments { get; set; }

        /// <summary>
        /// Gets or sets LastPaymentNumberPaid 
        /// </summary>
        [ViewField(Name = Fields.LastPaymentNumberPaid, Id = Index.LastPaymentNumberPaid, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LastPaymentNumberPaid { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumberonLastStatement 
        /// </summary>
        [ViewField(Name = Fields.PaymentNumberonLastStatement, Id = Index.PaymentNumberonLastStatement, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumberonLastStatement { get; set; }

        /// <summary>
        /// Gets or sets PaymentAmountApplied 
        /// </summary>
        [ViewField(Name = Fields.PaymentAmountApplied, Id = Index.PaymentAmountApplied, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentAmountApplied { get; set; }

        /// <summary>
        /// Gets or sets LastAppliedPaymentSeqNo 
        /// </summary>
        [ViewField(Name = Fields.LastAppliedPaymentSeqNo, Id = Index.LastAppliedPaymentSeqNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LastAppliedPaymentSeqNo { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountControl 
        /// </summary>
        [ViewField(Name = Fields.TaxAmountControl, Id = Index.TaxAmountControl, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxAmountControl TaxAmountControl { get; set; }

        /// <summary>
        /// Gets or sets TaxAuth1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuth1, Id = Index.TaxAuth1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuth1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuth2 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuth2, Id = Index.TaxAuth2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuth2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuth3 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuth3, Id = Index.TaxAuth3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuth3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuth4 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuth4, Id = Index.TaxAuth4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuth4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuth5 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuth5, Id = Index.TaxAuth5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuth5 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount1 
        /// </summary>
        [ViewField(Name = Fields.FunctionalBaseAmount1, Id = Index.FunctionalBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount2 
        /// </summary>
        [ViewField(Name = Fields.FunctionalBaseAmount2, Id = Index.FunctionalBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount3 
        /// </summary>
        [ViewField(Name = Fields.FunctionalBaseAmount3, Id = Index.FunctionalBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount4 
        /// </summary>
        [ViewField(Name = Fields.FunctionalBaseAmount4, Id = Index.FunctionalBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount5 
        /// </summary>
        [ViewField(Name = Fields.FunctionalBaseAmount5, Id = Index.FunctionalBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncationalTaxAmount1 
        /// </summary>
        [ViewField(Name = Fields.FunctionalTaxAmount1, Id = Index.FunctionalTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncationalTaxAmount2 
        /// </summary>
        [ViewField(Name = Fields.FunctionalTaxAmount2, Id = Index.FunctionalTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncationalTaxAmount3 
        /// </summary>
        [ViewField(Name = Fields.FunctionalTaxAmount3, Id = Index.FunctionalTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncationalTaxAmount4 
        /// </summary>
        [ViewField(Name = Fields.FunctionalTaxAmount4, Id = Index.FunctionalTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncationalTaxAmount5 
        /// </summary>
        [ViewField(Name = Fields.FunctionalTaxAmount5, Id = Index.FunctionalTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets VendorBaseAmount1 
        /// </summary>
        [ViewField(Name = Fields.VendorBaseAmount1, Id = Index.VendorBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets VendorBaseAmount2 
        /// </summary>
        [ViewField(Name = Fields.VendorBaseAmount2, Id = Index.VendorBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets VendorBaseAmount3 
        /// </summary>
        [ViewField(Name = Fields.VendorBaseAmount3, Id = Index.VendorBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets VendorBaseAmount4 
        /// </summary>
        [ViewField(Name = Fields.VendorBaseAmount4, Id = Index.VendorBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets VendorBaseAmount5 
        /// </summary>
        [ViewField(Name = Fields.VendorBaseAmount5, Id = Index.VendorBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxAmount1 
        /// </summary>
        [ViewField(Name = Fields.VendorTaxAmount1, Id = Index.VendorTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxAmount2 
        /// </summary>
        [ViewField(Name = Fields.VendorTaxAmount2, Id = Index.VendorTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxAmount3 
        /// </summary>
        [ViewField(Name = Fields.VendorTaxAmount3, Id = Index.VendorTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxAmount4 
        /// </summary>
        [ViewField(Name = Fields.VendorTaxAmount4, Id = Index.VendorTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxAmount5 
        /// </summary>
        [ViewField(Name = Fields.VendorTaxAmount5, Id = Index.VendorTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets PrepayInvoiceNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepayInvoiceNumber, Id = Index.PrepayInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PrepayInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets Num1099OrCPRSCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Num1099OrCPRSCode, Id = Index.Num1099OrCPRSCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Num1099OrCPRSCode { get; set; }

        /// <summary>
        /// Gets or sets Num1099OrCPRSOriginalAmount 
        /// </summary>
        [ViewField(Name = Fields.Num1099OrCPRSOriginalAmount, Id = Index.Num1099OrCPRSOriginalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Num1099OrCPRSOriginalAmount { get; set; }

        /// <summary>
        /// Gets or sets Num1099OrCPRSRemainingAmount 
        /// </summary>
        [ViewField(Name = Fields.Num1099OrCPRSRemainingAmount, Id = Index.Num1099OrCPRSRemainingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Num1099OrCPRSRemainingAmount { get; set; }

        /// <summary>
        /// Gets or sets RateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator 
        /// </summary>
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateOperator { get; set; }

        /// <summary>
        /// Gets or sets LastActivityYearOrPeriod 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastActivityYearOrPeriod, Id = Index.LastActivityYearOrPeriod, FieldType = EntityFieldType.Char, Size = 6)]
        public string LastActivityYearOrPeriod { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets CheckSerialNumber 
        /// </summary>
        [ViewField(Name = Fields.CheckSerialNumber, Id = Index.CheckSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long CheckSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNo 
        /// </summary>
        [ViewField(Name = Fields.PostingSequenceNo, Id = Index.PostingSequenceNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden JobRelated { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage 
        /// </summary>
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageOutstanding 
        /// </summary>
        [ViewField(Name = Fields.RetainageOutstanding, Id = Index.RetainageOutstanding, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden RetainageOutstanding { get; set; }

        /// <summary>
        /// Gets or sets DateRetainageDue 
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateRetainageDue, Id = Index.DateRetainageDue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateRetainageDue { get; set; }

        /// <summary>
        /// Gets or sets FuncationalCurrencyOrigRtngAmt 
        /// </summary>
        [ViewField(Name = Fields.FunctionalCurrencyOrigRtngAmt, Id = Index.FunctionalCurrencyOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets FuncationalCurrencyRetainageAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalCurrencyRetainageAmount, Id = Index.FunctionalCurrencyRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyOrigRtngAmt 
        /// </summary>
        [ViewField(Name = Fields.VendorCurrencyOrigRtngAmt, Id = Index.VendorCurrencyOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyRetainageAmount 
        /// </summary>
        [ViewField(Name = Fields.VendorCurrencyRetainageAmount, Id = Index.VendorCurrencyRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }

        /// <summary>
        /// Gets or sets FunctionalPendingPaymentAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalPendingPaymentAmount, Id = Index.FunctionalPendingPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalPendingPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalPendingDiscountAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalPendingDiscountAmount, Id = Index.FunctionalPendingDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalPendingDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalPendingAdjustmentAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalPendingAdjustmentAmount, Id = Index.FunctionalPendingAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalPendingAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalPendingBalance 
        /// </summary>
        [ViewField(Name = Fields.FunctionalPendingBalance, Id = Index.FunctionalPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets PendingPaymentAmount 
        /// </summary>
        [ViewField(Name = Fields.PendingPaymentAmount, Id = Index.PendingPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingDiscountAmount 
        /// </summary>
        [ViewField(Name = Fields.PendingDiscountAmount, Id = Index.PendingDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingAdjustmentAmount 
        /// </summary>
        [ViewField(Name = Fields.PendingAdjustmentAmount, Id = Index.PendingAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingBalance 
        /// </summary>
        [ViewField(Name = Fields.PendingBalance, Id = Index.PendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingBalance { get; set; }

        /// <summary>
        /// Gets or sets VendorNoUsedtoCalculatePen 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorNoUsedtoCalculatePen, Id = Index.VendorNoUsedtoCalculatePen, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNoUsedtoCalculatePen { get; set; }

        /// <summary>
        /// Gets or sets ShowPendingAmountsSwitch 
        /// </summary>
        [ViewField(Name = Fields.ShowPendingAmountsSwitch, Id = Index.ShowPendingAmountsSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden ShowPendingAmountsSwitch { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets PaymentStatus 
        /// </summary>
        [ViewField(Name = Fields.PaymentStatus, Id = Index.PaymentStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentStatus PaymentStatus { get; set; }

        /// <summary>
        /// Gets or sets DatePaymentStatusChanged 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DatePaymentStatusChanged, Id = Index.DatePaymentStatusChanged, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DatePaymentStatusChanged { get; set; }

        /// <summary>
        /// Gets or sets AOrPVersionCreatedIn 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string APVersionCreatedIn { get; set; }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets NumberofOBLJDetails 
        /// </summary>
        [ViewField(Name = Fields.NumberofOBLJDetails, Id = Index.NumberofOBLJDetails, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofOBLJDetails { get; set; }

        /// <summary>
        /// Gets or sets PaymentLimit 
        /// </summary>
        [ViewField(Name = Fields.PaymentLimit, Id = Index.PaymentLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentLimit { get; set; }

        /// <summary>
        /// Gets or sets Obsolete 
        /// </summary>
        [ViewField(Name = Fields.Obsolete, Id = Index.Obsolete, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden Obsolete { get; set; }

        #region Properties for finder

        /// <summary>
        /// Transaction Type String
        /// </summary>
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        /// <summary>
        /// Document Type String
        /// </summary>
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Fully Paid String
        /// </summary>
        public string FullyPaidString
        {
            get { return EnumUtility.GetStringValue(FullyPaid); }
        }

        /// <summary>
        /// Rate Overridden String
        /// </summary>
        public string RateOverriddenString
        {
            get { return EnumUtility.GetStringValue(RateOverridden); }
        }

        /// <summary>
        /// Tax Amount Control String
        /// </summary>
        public string TaxAmountControlString
        {
            get { return EnumUtility.GetStringValue(TaxAmountControl); }
        }

        /// <summary>
        /// Job Related String
        /// </summary>
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Has Retainage String
        /// </summary>
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Retainage Outstanding String
        /// </summary>
        public string RetainageOutstandingString
        {
            get { return EnumUtility.GetStringValue(RetainageOutstanding); }
        }

        /// <summary>
        /// Retainage Exchange Rate String
        /// </summary>
        public string RetainageExchangeRateString
        {
            get { return EnumUtility.GetStringValue(RetainageExchangeRate); }
        }

        /// <summary>
        /// Payment Status String
        /// </summary>
        public string PaymentStatusString
        {
            get { return EnumUtility.GetStringValue(PaymentStatus); }
        }

        /// <summary>
        /// Obsolete String
        /// </summary>
        public string ObsoleteString
        {
            get { return EnumUtility.GetStringValue(Obsolete); }
        }

        #endregion
    }
}
