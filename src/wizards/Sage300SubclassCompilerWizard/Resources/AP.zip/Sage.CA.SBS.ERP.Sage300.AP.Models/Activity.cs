﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.  */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class Activity: ModelBase
    {
        /// <summary>
        /// Gets or sets Vendor Number
        /// </summary>
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets Currency Type.
        /// </summary>
        public string CurrencyType { get; set; }

        /// <summary>
        /// Gets or sets Statistics
        /// </summary>
        public string Statistics {  get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets Document Date.
        /// </summary>
        public string DocumentDate { get; set; }
    }
}
