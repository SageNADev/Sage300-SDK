/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{

    public partial class TermCodeDetail : ModelBase
    {

        /// <summary>
        /// Gets or sets TermsCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TermsCode", ResourceType = typeof(APCommonResx))]
        [Key]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentNumber", ResourceType = typeof(APCommonResx))]
        [Key]
        [ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary> 
        [Display(Name = "DateLastMaintained", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets PercentageDue 
        /// </summary>
        [Display(Name = "PercentageDue", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.PercentDue, Id = Index.PercentDue, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentDue { get; set; }

        /// <summary>
        /// Gets or sets DiscountType
        /// </summary>
        [Display(Name = "DiscType", ResourceType = typeof(TermCodeResx))]
        public int DISCTYPE { get; set; }

        /// <summary>
        /// Gets or sets DiscountPercent 
        /// </summary>
        [Display(Name = "DiscountPercent", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.DiscountPercent, Id = Index.DiscountPercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountPercent { get; set; }

        /// <summary>
        /// Gets or sets DiscountNumberofDays 
        /// </summary>
        [Display(Name = "DiscountNumberofDays", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.DiscountNumberofDays, Id = Index.DiscountNumberofDays, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountNumberofDays { get; set; }

        /// <summary>
        /// Gets or sets DiscountDayofMonth
        /// </summary>
        [Display(Name = "DiscountDayofMonth", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.DiscountDayofMonth, Id = Index.DiscountDayofMonth, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountDayofMonth { get; set; }

        /// <summary>
        /// Gets or sets DueType
        /// </summary>
        [Display(Name = "DueType", ResourceType = typeof(TermCodeResx))]
        public int DUETYPE { get; set; }

        /// <summary>
        /// Gets or sets DueNumberofDays
        /// </summary>
        [Display(Name = "DueNumberofDays", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.DueNumberofDays, Id = Index.DueNumberofDays, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueNumberofDays { get; set; }

        /// <summary>
        /// Gets or sets DayofMonth 
        /// </summary>
        [Display(Name = "DueDayofMonth", ResourceType = typeof(TermCodeResx))]
        [ViewField(Name = Fields.DueDayofMonth, Id = Index.DueDayofMonth, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDayofMonth { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber
        /// </summary>
        [Display(Name = "PaymentNumber", ResourceType = typeof(TermCodeResx))]
        public int LineNumber { get; set; }
    }
}
