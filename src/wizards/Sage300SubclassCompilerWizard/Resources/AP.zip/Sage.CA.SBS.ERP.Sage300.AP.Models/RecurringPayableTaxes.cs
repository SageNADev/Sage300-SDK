﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.  */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for tax class grid in Recurring Payable
    /// </summary>
    public class RecurringPayableTaxes : ModelBase
    {
        #region Properties

        /// <summary>
        /// Gets or Sets Recurring Payable Code
        /// </summary>
        public string RecurringPayableCode { get; set; }

        /// <summary>
        /// Gets or Sets VendorNumber
        /// </summary>
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or Sets LineNumber
        /// </summary>
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or Sets Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or Sets List of TaxClassGroup
        /// </summary>
        public List<TaxClassGroup> TaxClassGroups { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrency 
        /// </summary>
        public string TaxReportingCurrency { get; set; }

        #endregion
    }
}
