/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of DistributionSets Constants 
    /// </summary>
	public partial class DistributionSetHeader 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0009";

        /// <summary>
        /// Contains list of DistributionSets Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for DistributionSet 
        /// </summary>
	    public const string DistributionSet  = "DISTSET";
	            /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "TEXTDESC";
	            /// <summary>
        /// Property for Status 
        /// </summary>
	    public const string Status  = "SWACTV";
	            /// <summary>
        /// Property for InactiveDate 
        /// </summary>
	    public const string InactiveDate  = "DATEINACTV";
	            /// <summary>
        /// Property for DateLastMaintained 
        /// </summary>
	    public const string DateLastMaintained  = "DATELASTMN";
	            /// <summary>
        /// Property for CodeType 
        /// </summary>
	    public const string CodeType  = "CODETYPE";
	            /// <summary>
        /// Property for DistributionMethod 
        /// </summary>
	    public const string DistributionMethod  = "CODEMETH";
	            /// <summary>
        /// Property for DistributionsEntered 
        /// </summary>
	    public const string DistributionsEntered  = "CNTENTR";
	            /// <summary>
        /// Property for Currency 
        /// </summary>
	    public const string Currency  = "CURNCODE";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of DistributionSets Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for DistributionSet 
        /// </summary>
	    public const int DistributionSet  = 1;
	             /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 2;
	             /// <summary>
        /// Property Indexer for Status 
        /// </summary>
	    public const int Status  = 3;
	             /// <summary>
        /// Property Indexer for InactiveDate 
        /// </summary>
	    public const int InactiveDate  = 4;
	             /// <summary>
        /// Property Indexer for DateLastMaintained 
        /// </summary>
	    public const int DateLastMaintained  = 5;
	             /// <summary>
        /// Property Indexer for CodeType 
        /// </summary>
	    public const int CodeType  = 6;
	             /// <summary>
        /// Property Indexer for DistributionMethod 
        /// </summary>
	    public const int DistributionMethod  = 7;
	             /// <summary>
        /// Property Indexer for DistributionsEntered 
        /// </summary>
	    public const int DistributionsEntered  = 8;
	             /// <summary>
        /// Property Indexer for Currency 
        /// </summary>
	    public const int Currency  = 9;
	     
        #endregion
	    }

	
	}
}
	