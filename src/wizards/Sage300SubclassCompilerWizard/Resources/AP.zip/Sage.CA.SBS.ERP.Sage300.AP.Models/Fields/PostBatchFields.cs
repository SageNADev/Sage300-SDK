﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Fields
{
    /// <summary>
    ///  Post Batch Field class.
    /// </summary>
    public partial class PostBatchFields
    {
    }
}
