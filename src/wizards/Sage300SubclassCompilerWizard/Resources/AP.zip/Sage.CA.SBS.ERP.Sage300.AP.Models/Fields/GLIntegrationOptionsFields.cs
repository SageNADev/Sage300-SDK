// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of G/L Integration Options Constants 
    /// </summary>
    public partial class GLIntegrationOptions
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0004";

        /// <summary>
        /// Contains list of G/L Integration Options Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for OptionsRecordKey 
            /// </summary>
            public const string IntegrationOptionsKey = "RECID04";
            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";
            /// <summary>
            /// Property for DeferGLTransactions 
            /// </summary>
            public const string DeferGLTransactions = "SWGLPSTDFR";
            /// <summary>
            /// Property for CreateGLTransactionsBy 
            /// </summary>
            public const string CreateGLTransactionsBy = "SWGLAPDBTH";
            /// <summary>
            /// Property for ConsolidateGLTransactions 
            /// </summary>
            public const string ConsolidateGLTransactions = "SWGLPSTCON";
            /// <summary>
            /// Property for LastPaymentPostingSeqtoGL 
            /// </summary>
            public const string LastPaymentPostingSeqToGL = "CNTLASPAYM";
            /// <summary>
            /// Property for LastInvoicePostingSeqToGL 
            /// </summary>
            public const string LastInvoicePostingSeqToGL = "CNTLASINVC";
            /// <summary>
            /// Property for LastRevalPostingSeqToGL 
            /// </summary>
            public const string LastRevalPostingSeqToGL = "CNTLASRVAL";
            /// <summary>
            /// Property for LastAdjPostingSeqToGL 
            /// </summary>
            public const string LastAdjPostingSeqToGL = "CNTLASADJM";
            /// <summary>
            /// Property for GLSrcCodeInvoice 
            /// </summary>
            public const string GLSrcCodeInvoice = "SRCTYPEIN";
            /// <summary>
            /// Property for GLSrcCodeDebitNote 
            /// </summary>
            public const string GLSrcCodeDebitNote = "SRCTYPEDB";
            /// <summary>
            /// Property for GLSrcCodeCreditNote 
            /// </summary>
            public const string GLSrcCodeCreditNote = "SRCTYPECR";
            /// <summary>
            /// Property for GLSrcCodeInterest 
            /// </summary>
            public const string GLSrcCodeInterest = "SRCTYPEIT";
            /// <summary>
            /// Property for GLSrcCodePayment 
            /// </summary>
            public const string GLSrcCodePayment = "SRCTYPEPY";
            /// <summary>
            /// Property for GLSrcCodeDiscount 
            /// </summary>
            public const string GLSrcCodeDiscount = "SRCTYPEED";
            /// <summary>
            /// Property for GLSrcCodeRevaluation 
            /// </summary>
            public const string GLSrcCodeRevaluation = "SRCTYPEGL";
            /// <summary>
            /// Property for GLSrcCodeAdjustment 
            /// </summary>
            public const string GLSrcCodeAdjustment = "SRCTYPEAD";
            /// <summary>
            /// Property for GLSrcCodeConsolidation 
            /// </summary>
            public const string GLSrcCodeConsolidation = "SRCTYPECO";
            /// <summary>
            /// Property for GLSrcCodePrepayment 
            /// </summary>
            public const string GLSrcCodePrepayment = "SRCTYPEPI";
            /// <summary>
            /// Property for GLSrcCodeRounding 
            /// </summary>
            public const string GLSrcCodeRounding = "SRCTYPERD";
            /// <summary>
            /// Property for GLSrcCodePaymentReversal 
            /// </summary>
            public const string GLSrcCodePaymentReversal = "SRCTYPEPYR";
            /// <summary>
            /// Property for ProcessCommand 
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            #endregion
        }

        /// <summary>
        /// Contains list of G/L Integration Options Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for OptionsRecordKey 
            /// </summary>
            public const int IntegrationOptionsKey = 1;
            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 2;
            /// <summary>
            /// Property Indexer for DeferGLTransactions 
            /// </summary>
            public const int DeferGLTransactions = 4;
            /// <summary>
            /// Property Indexer for CreateGLTransactionsBy 
            /// </summary>
            public const int CreateGLTransactionsBy = 5;
            /// <summary>
            /// Property Indexer for ConsolidateGLTransactions 
            /// </summary>
            public const int ConsolidateGLTransactions = 6;
            /// <summary>
            /// Property Indexer for LastPaymentPostingSeqToGL 
            /// </summary>
            public const int LastPaymentPostingSeqToGL = 9;
            /// <summary>
            /// Property Indexer for LastInvoicePostingSeqToGL 
            /// </summary>
            public const int LastInvoicePostingSeqToGL = 10;
            /// <summary>
            /// Property Indexer for LastRevalPostingSeqToGL 
            /// </summary>
            public const int LastRevalPostingSeqToGL = 11;
            /// <summary>
            /// Property Indexer for LastAdjPostingSeqToGL 
            /// </summary>
            public const int LastAdjPostingSeqToGL = 12;
            /// <summary>
            /// Property Indexer for GLSrcCodeInvoice 
            /// </summary>
            public const int GLSrcCodeInvoice = 13;
            /// <summary>
            /// Property Indexer for GLSrcCodeDebitNote 
            /// </summary>
            public const int GLSrcCodeDebitNote = 14;
            /// <summary>
            /// Property Indexer for GLSrcCodeCreditNote 
            /// </summary>
            public const int GLSrcCodeCreditNote = 15;
            /// <summary>
            /// Property Indexer for GLSrcCodeInterest 
            /// </summary>
            public const int GLSrcCodeInterest = 16;
            /// <summary>
            /// Property Indexer for GLSrcCodePayment 
            /// </summary>
            public const int GLSrcCodePayment = 17;
            /// <summary>
            /// Property Indexer for GLSrcCodeDiscount 
            /// </summary>
            public const int GLSrcCodeDiscount = 18;
            /// <summary>
            /// Property Indexer for GLSrcCodeRevaluation 
            /// </summary>
            public const int GLSrcCodeRevaluation = 19;
            /// <summary>
            /// Property Indexer for GLSrcCodeAdjustment 
            /// </summary>
            public const int GLSrcCodeAdjustment = 20;
            /// <summary>
            /// Property Indexer for GLSrcCodeConsolidation 
            /// </summary>
            public const int GLSrcCodeConsolidation = 21;
            /// <summary>
            /// Property Indexer for GLSrcCodePrepayment 
            /// </summary>
            public const int GLSrcCodePrepayment = 22;
            /// <summary>
            /// Property Indexer for GLSrcCodeRounding 
            /// </summary>
            public const int GLSrcCodeRounding = 23;
            /// <summary>
            /// Property Indexer for GLSrcCodePaymentReversal 
            /// </summary>
            public const int GLSrcCodePaymentReversal = 24;
            /// <summary>
            /// Property Indexer for ProcessCommand 
            /// </summary>
            public const int ProcessCommand = 25;

            #endregion
        }
    }
}
