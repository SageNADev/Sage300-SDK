// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
	/// <summary>
	/// Contains list of PaymentAndAdjustmentBatche Constants
	/// </summary>
	public partial class AdjustmentBatch
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "AP0030";

		#region Properties

		/// <summary>
		/// Contains list of PaymentAndAdjustmentBatche Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for BatchSelector
			/// </summary>
			public const string BatchSelector = "PAYMTYPE";

			/// <summary>
			/// Property for BatchNumber
			/// </summary>
			public const string BatchNumber = "CNTBTCH";

			/// <summary>
			/// Property for BatchDate
			/// </summary>
			public const string BatchDate = "DATEBTCH";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "BATCHDESC";

			/// <summary>
			/// Property for NumberOfEntries
			/// </summary>
			public const string NumberOfEntries = "CNTENTER";

			/// <summary>
			/// Property for BatchTotal
			/// </summary>
			public const string BatchTotal = "AMTENTER";

			/// <summary>
			/// Property for BatchType
			/// </summary>
			public const string BatchType = "BATCHTYPE";

			/// <summary>
			/// Property for BatchStatus
			/// </summary>
			public const string BatchStatus = "BATCHSTAT";

			/// <summary>
			/// Property for BankCode
			/// </summary>
			public const string BankCode = "IDBANK";

			/// <summary>
			/// Property for BankCurrencyCode
			/// </summary>
			public const string BankCurrencyCode = "CODECURN";

			/// <summary>
			/// Property for BankRateDate
			/// </summary>
			public const string BankRateDate = "DATERATE";

			/// <summary>
			/// Property for LastEntryNumber
			/// </summary>
			public const string LastEntryNumber = "CNTLSTRMIT";

			/// <summary>
			/// Property for BankRateType
			/// </summary>
			public const string BankRateType = "RATETYPE";

			/// <summary>
			/// Property for BankExchangeRate
			/// </summary>
			public const string BankExchangeRate = "RATEEXCHHC";

			/// <summary>
			/// Property for FuncBatchTotal
			/// </summary>
			public const string FuncBatchTotal = "FUNCAMOUNT";

			/// <summary>
			/// Property for PostingSequenceNo
			/// </summary>
			public const string PostingSequenceNo = "POSTSEQNBR";

			/// <summary>
			/// Property for NumberOfErrors
			/// </summary>
			public const string NumberOfErrors = "NBRERRORS";

			/// <summary>
			/// Property for DateLastEdited
			/// </summary>
			public const string DateLastEdited = "DATELSTEDT";

			/// <summary>
			/// Property for BatchEdited
			/// </summary>
			public const string BatchEdited = "SWBTCHEDIT";

			/// <summary>
			/// Property for PaymentRegisterPrintstatus
			/// </summary>
			public const string PaymentRegisterPrintstatus = "SWPRECHKRG";

			/// <summary>
			/// Property for NumberOfPrintedChecks
			/// </summary>
			public const string NumberOfPrintedChecks = "CNTCHKPRNT";

			/// <summary>
			/// Property for NumberOfReapplies
			/// </summary>
			public const string NumberOfReapplies = "CNTREAPPLY";

			/// <summary>
			/// Property for BatchPrintedFlag
			/// </summary>
			public const string BatchPrintedFlag = "SWPRINTED";

			/// <summary>
			/// Property for BankRateOperator
			/// </summary>
			public const string BankRateOperator = "RATEOP";

			/// <summary>
			/// Property for BankRateOverridden
			/// </summary>
			public const string BankRateOverridden = "SWRATE";

			/// <summary>
			/// Property for SourceApplication
			/// </summary>
			public const string SourceApplication = "SRCEAPPL";

			/// <summary>
			/// Property for ProcessCommandCode
			/// </summary>
			public const string ProcessCommandCode = "PROCESSCMD";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of PaymentAndAdjustmentBatche Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for BatchSelector
			/// </summary>
			public const int BatchSelector = 1;

			/// <summary>
			/// Property Indexer for BatchNumber
			/// </summary>
			public const int BatchNumber = 2;

			/// <summary>
			/// Property Indexer for BatchDate
			/// </summary>
			public const int BatchDate = 3;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 4;

			/// <summary>
			/// Property Indexer for NumberOfEntries
			/// </summary>
			public const int NumberOfEntries = 5;

			/// <summary>
			/// Property Indexer for BatchTotal
			/// </summary>
			public const int BatchTotal = 6;

			/// <summary>
			/// Property Indexer for BatchType
			/// </summary>
			public const int BatchType = 7;

			/// <summary>
			/// Property Indexer for BatchStatus
			/// </summary>
			public const int BatchStatus = 8;

			/// <summary>
			/// Property Indexer for BankCode
			/// </summary>
			public const int BankCode = 9;

			/// <summary>
			/// Property Indexer for BankCurrencyCode
			/// </summary>
			public const int BankCurrencyCode = 11;

			/// <summary>
			/// Property Indexer for BankRateDate
			/// </summary>
			public const int BankRateDate = 12;

			/// <summary>
			/// Property Indexer for LastEntryNumber
			/// </summary>
			public const int LastEntryNumber = 13;

			/// <summary>
			/// Property Indexer for BankRateType
			/// </summary>
			public const int BankRateType = 14;

			/// <summary>
			/// Property Indexer for BankExchangeRate
			/// </summary>
			public const int BankExchangeRate = 15;

			/// <summary>
			/// Property Indexer for FuncBatchTotal
			/// </summary>
			public const int FuncBatchTotal = 18;

			/// <summary>
			/// Property Indexer for PostingSequenceNo
			/// </summary>
			public const int PostingSequenceNo = 19;

			/// <summary>
			/// Property Indexer for NumberOfErrors
			/// </summary>
			public const int NumberOfErrors = 20;

			/// <summary>
			/// Property Indexer for DateLastEdited
			/// </summary>
			public const int DateLastEdited = 21;

			/// <summary>
			/// Property Indexer for BatchEdited
			/// </summary>
			public const int BatchEdited = 24;

			/// <summary>
			/// Property Indexer for PaymentRegisterPrintstatus
			/// </summary>
			public const int PaymentRegisterPrintstatus = 25;

			/// <summary>
			/// Property Indexer for NumberOfPrintedChecks
			/// </summary>
			public const int NumberOfPrintedChecks = 26;

			/// <summary>
			/// Property Indexer for NumberOfReapplies
			/// </summary>
			public const int NumberOfReapplies = 27;

			/// <summary>
			/// Property Indexer for BatchPrintedFlag
			/// </summary>
			public const int BatchPrintedFlag = 28;

			/// <summary>
			/// Property Indexer for BankRateOperator
			/// </summary>
			public const int BankRateOperator = 29;

			/// <summary>
			/// Property Indexer for BankRateOverridden
			/// </summary>
			public const int BankRateOverridden = 30;

			/// <summary>
			/// Property Indexer for SourceApplication
			/// </summary>
			public const int SourceApplication = 31;

			/// <summary>
			/// Property Indexer for ProcessCommandCode
			/// </summary>
			public const int ProcessCommandCode = 32;

		}

		#endregion

	}
}
