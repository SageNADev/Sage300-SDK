﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of SelectedVendors Constants 
    /// </summary>
    public partial class SelectedVendor
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0420";

        /// <summary>
        /// Contains list of SelectedVendors Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for SequenceNumber 
            /// </summary>
            public const string SequenceNumber = "SELSEQ";
            /// <summary>
            /// Property for RecordNumber 
            /// </summary>
            public const string RecordNumber = "RECORDNO";
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";
            /// <summary>
            /// Property for DeliveryMethod 
            /// </summary>
            public const string DeliveryMethod = "DELMETHOD";
            /// <summary>
            /// Property for SortFieldValue1 
            /// </summary>
            public const string SortFieldValue1 = "SORTVALUE1";
            /// <summary>
            /// Property for SortFieldValue2 
            /// </summary>
            public const string SortFieldValue2 = "SORTVALUE2";
            /// <summary>
            /// Property for SortFieldValue3 
            /// </summary>
            public const string SortFieldValue3 = "SORTVALUE3";
            /// <summary>
            /// Property for SortFieldValue4 
            /// </summary>
            public const string SortFieldValue4 = "SORTVALUE4";
            /// <summary>
            /// Property for SortFieldType1 
            /// </summary>
            public const string SortFieldType1 = "SORTTYPE1";
            /// <summary>
            /// Property for SortFieldType2 
            /// </summary>
            public const string SortFieldType2 = "SORTTYPE2";
            /// <summary>
            /// Property for SortFieldType3 
            /// </summary>
            public const string SortFieldType3 = "SORTTYPE3";
            /// <summary>
            /// Property for SortFieldType4 
            /// </summary>
            public const string SortFieldType4 = "SORTTYPE4";

            #endregion
        }


        /// <summary>
        /// Contains list of SelectedVendors Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for SequenceNumber 
            /// </summary>
            public const int SequenceNumber = 1;
            /// <summary>
            /// Property Indexer for RecordNumber 
            /// </summary>
            public const int RecordNumber = 2;
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 3;
            /// <summary>
            /// Property Indexer for DeliveryMethod 
            /// </summary>
            public const int DeliveryMethod = 4;
            /// <summary>
            /// Property Indexer for SortFieldValue1 
            /// </summary>
            public const int SortFieldValue1 = 5;
            /// <summary>
            /// Property Indexer for SortFieldValue2 
            /// </summary>
            public const int SortFieldValue2 = 6;
            /// <summary>
            /// Property Indexer for SortFieldValue3 
            /// </summary>
            public const int SortFieldValue3 = 7;
            /// <summary>
            /// Property Indexer for SortFieldValue4 
            /// </summary>
            public const int SortFieldValue4 = 8;
            /// <summary>
            /// Property Indexer for SortFieldType1 
            /// </summary>
            public const int SortFieldType1 = 9;
            /// <summary>
            /// Property Indexer for SortFieldType2 
            /// </summary>
            public const int SortFieldType2 = 10;
            /// <summary>
            /// Property Indexer for SortFieldType3 
            /// </summary>
            public const int SortFieldType3 = 11;
            /// <summary>
            /// Property Indexer for SortFieldType4 
            /// </summary>
            public const int SortFieldType4 = 12;

            #endregion
        }


    }
}
