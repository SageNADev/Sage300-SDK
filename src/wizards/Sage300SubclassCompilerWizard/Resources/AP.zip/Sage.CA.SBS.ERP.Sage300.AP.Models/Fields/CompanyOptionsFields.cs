/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CompanyOptions Constants 
    /// </summary>
    public partial class CompanyOptions
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0001";

        /// <summary>
        /// Contains list of CompanyOptions Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for OptionsRecordKey 
            /// </summary>
            public const string OptionsRecordKey = "IDP01";
            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";
            /// <summary>
            /// Property for Multicurrency 
            /// </summary>
            public const string Multicurrency = "SWMULTCURN";
            /// <summary>
            /// Property for EditImports 
            /// </summary>
            public const string EditImports = "SWEDITIMPT";
            /// <summary>
            /// Property for ForceListingofBatches 
            /// </summary>
            public const string ForceListingofBatches = "SWFRCLST";

            //TODO: The naming convention of this property has to be relooked         
            /// <summary>
            /// Property for CNTARCVDAY 
            /// </summary>
            public const string CNTARCVDAY = "CNTARCVDAY";
            /// <summary>
            /// Property for EditVendorStatistics 
            /// </summary>
            public const string EditVendorStatistics = "SWEDITVNDR";
            /// <summary>
            /// Property for IncTaxinVendorStatistics 
            /// </summary>
            public const string IncTaxinVendorStatistics = "CODETAXVND";
            /// <summary>
            /// Property for VendorStatisticsYearType 
            /// </summary>
            public const string VendorStatisticsYearType = "CODECLDRVN";
            /// <summary>
            /// Property for VendorStatisticsPeriodType 
            /// </summary>
            public const string VendorStatisticsPeriodType = "CODEPERDVN";

            //TODO: The naming convention of this property has to be relooked        
            /// <summary>
            /// Property for SWBNKVNDR 
            /// </summary>
            public const string SWBNKVNDR = "SWBNKVNDR";
            /// <summary>
            /// Property for DefaultNoDaystoKeepComment 
            /// </summary>
            public const string DefaultNoDaystoKeepComment = "CMNTDAYS";
            /// <summary>
            /// Property for NextRevaluationPostingSequenc 
            /// </summary>
            public const string NextRevaluationPostingSequenc = "CNTRVALSEQ";
            /// <summary>
            /// Property for ContactName 
            /// </summary>
            public const string ContactName = "NAMECTAC";
            /// <summary>
            /// Property for TelephoneNumber 
            /// </summary>
            public const string TelephoneNumber = "TEXTPHON";
            /// <summary>
            /// Property for FaxNumber 
            /// </summary>
            public const string FaxNumber = "TEXTFAX";
            /// <summary>
            /// Property for KeepHistory 
            /// </summary>
            public const string KeepHistory = "SWKEEPDTLS";
            /// <summary>
            /// Property for KeepVendorStatistics 
            /// </summary>
            public const string KeepVendorStatistics = "SWACCUVNDR";
            /// <summary>
            /// Property for DefaultTaxAmountControl 
            /// </summary>
            public const string DefaultTaxAmountControl = "SWCALCTAX";
            /// <summary>
            /// Property for EditExternalBatches 
            /// </summary>
            public const string EditExternalBatches = "SWEDITSUB";
            /// <summary>
            /// Property for DefaultTaxBaseControl 
            /// </summary>
            public const string DefaultTaxBaseControl = "SWTXBSECTL";
            /// <summary>
            /// Property for DefaultTaxReportingControl 
            /// </summary>
            public const string DefaultTaxReportingControl = "SWTXCTLRC";
            /// <summary>
            /// Property for DefaultDetailTaxClass 
            /// </summary>
            public const string DefaultDetailTaxClass = "SWTXDTLCLS";

            #endregion
        }


        /// <summary>
        /// Contains list of CompanyOptions Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for OptionsRecordKey 
            /// </summary>
            public const int OptionsRecordKey = 1;
            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 2;
            /// <summary>
            /// Property Indexer for Multicurrency 
            /// </summary>
            public const int Multicurrency = 3;
            /// <summary>
            /// Property Indexer for EditImports 
            /// </summary>
            public const int EditImports = 4;
            /// <summary>
            /// Property Indexer for ForceListingofBatches 
            /// </summary>
            public const int ForceListingofBatches = 5;

            //TODO: The naming convention of this property has to be relooked         
            /// <summary>
            /// Property Indexer for CNTARCVDAY 
            /// </summary>
            public const int CNTARCVDAY = 6;
            /// <summary>
            /// Property Indexer for EditVendorStatistics 
            /// </summary>
            public const int EditVendorStatistics = 7;
            /// <summary>
            /// Property Indexer for IncTaxinVendorStatistics 
            /// </summary>
            public const int IncTaxinVendorStatistics = 8;
            /// <summary>
            /// Property Indexer for VendorStatisticsYearType 
            /// </summary>
            public const int VendorStatisticsYearType = 9;
            /// <summary>
            /// Property Indexer for VendorStatisticsPeriodType 
            /// </summary>
            public const int VendorStatisticsPeriodType = 10;

            //TODO: The naming convention of this property has to be relooked          
            /// <summary>
            /// Property Indexer for SWBNKVNDR 
            /// </summary>
            public const int SWBNKVNDR = 11;
            /// <summary>
            /// Property Indexer for DefaultNoDaystoKeepComment 
            /// </summary>
            public const int DefaultNoDaystoKeepComment = 12;
            /// <summary>
            /// Property Indexer for NextRevaluationPostingSequenc 
            /// </summary>
            public const int NextRevaluationPostingSequenc = 37;
            /// <summary>
            /// Property Indexer for ContactName 
            /// </summary>
            public const int ContactName = 38;
            /// <summary>
            /// Property Indexer for TelephoneNumber 
            /// </summary>
            public const int TelephoneNumber = 39;
            /// <summary>
            /// Property Indexer for FaxNumber 
            /// </summary>
            public const int FaxNumber = 40;
            /// <summary>
            /// Property Indexer for KeepHistory 
            /// </summary>
            public const int KeepHistory = 41;
            /// <summary>
            /// Property Indexer for KeepVendorStatistics 
            /// </summary>
            public const int KeepVendorStatistics = 42;
            /// <summary>
            /// Property Indexer for DefaultTaxAmountControl 
            /// </summary>
            public const int DefaultTaxAmountControl = 43;
            /// <summary>
            /// Property Indexer for EditExternalBatches 
            /// </summary>
            public const int EditExternalBatches = 44;
            /// <summary>
            /// Property Indexer for DefaultTaxBaseControl 
            /// </summary>
            public const int DefaultTaxBaseControl = 45;
            /// <summary>
            /// Property Indexer for DefaultTaxReportingControl 
            /// </summary>
            public const int DefaultTaxReportingControl = 46;
            /// <summary>
            /// Property Indexer for DefaultDetailTaxClass 
            /// </summary>
            public const int DefaultDetailTaxClass = 47;

            #endregion
        }


    }
}
