/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PaymentAdjustmentBatches Constants 
    /// </summary>
    public partial class PaymentAdjustmentBatch
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0030";

        /// <summary>
        /// Contains list of PaymentAdjustmentBatches Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchSelector 
            /// </summary>
            public const string BatchSelector = "PAYMTYPE";
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for BatchDate 
            /// </summary>
            public const string BatchDate = "DATEBTCH";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "BATCHDESC";
            /// <summary>
            /// Property for NumberofEntries 
            /// </summary>
            public const string NumberOfEntries = "CNTENTER";
            /// <summary>
            /// Property for BatchTotal 
            /// </summary>
            public const string BatchTotal = "AMTENTER";
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "BATCHTYPE";
            /// <summary>
            /// Property for BatchStatus 
            /// </summary>
            public const string BatchStatus = "BATCHSTAT";
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "IDBANK";

            //TODO: The naming convention of this property has to be relooked         
            /// <summary>
            /// Property for SWPRTDEP 
            /// </summary>
            public const string SWPRTDEP = "SWPRTDEP";
            /// <summary>
            /// Property for BankCurrencyCode 
            /// </summary>
            public const string BankCurrencyCode = "CODECURN";
            /// <summary>
            /// Property for BankRateDate 
            /// </summary>
            public const string BankRateDate = "DATERATE";
            /// <summary>
            /// Property for LastEntryNumber 
            /// </summary>
            public const string LastEntryNumber = "CNTLSTRMIT";
            /// <summary>
            /// Property for BankRateType 
            /// </summary>
            public const string BankRateType = "RATETYPE";
            /// <summary>
            /// Property for BankExchangeRate 
            /// </summary>
            public const string BankExchangeRate = "RATEEXCHHC";

            //TODO: The naming convention of this property has to be relooked         
            /// <summary>
            /// Property for CNTDEPNBR 
            /// </summary>
            public const string CNTDEPNBR = "CNTDEPNBR";

            //TODO: The naming convention of this property has to be relooked         
            /// <summary>
            /// Property for CNTDEPSEQ 
            /// </summary>
            public const string CNTDEPSEQ = "CNTDEPSEQ";

            /// <summary>
            /// Property for FuncBatchTotal 
            /// </summary>
            public const string FuncBatchTotal = "FUNCAMOUNT";

            /// <summary>
            /// Property for PostingSequenceNo 
            /// </summary>
            public const string PostingSequenceNo = "POSTSEQNBR";
            /// <summary>
            /// Property for NumberofErrors 
            /// </summary>
            public const string NumberOfErrors = "NBRERRORS";
            /// <summary>
            /// Property for DateLastEdited 
            /// </summary>
            public const string DateLastEdited = "DATELSTEDT";

            //TODO: The naming convention of this property has to be relooked         
            /// <summary>
            /// Property for CODECHKTYP 
            /// </summary>
            public const string CODECHKTYP = "CODECHKTYP";

            //TODO: The naming convention of this property has to be relooked         
            /// <summary>
            /// Property for PAYMFORM 
            /// </summary>
            public const string PAYMFORM = "PAYMFORM";

            /// <summary>
            /// Property for BatchEdited 
            /// </summary>
            public const string BatchEdited = "SWBTCHEDIT";
            /// <summary>
            /// Property for BatchEdited 
            /// </summary>
            public const string TypeBatchEdited = "SWBTCHEDIT";
            /// <summary>
            /// Property for PaymentRegisterPrintstatus 
            /// </summary>
            public const string PaymentRegisterPrintStatus = "SWPRECHKRG";
            /// <summary>
            /// Property for PaymentRegisterPrintstatus 
            /// </summary>
            public const string PaymentRegisterPrintStatusString = "SWPRECHKRG";
            /// <summary>
            /// Property for NumberofPrintedChecks 
            /// </summary>
            public const string NumberOfPrintedChecks = "CNTCHKPRNT";
            /// <summary>
            /// Property for NumberofReapplies 
            /// </summary>
            public const string NumberOfReapplies = "CNTREAPPLY";
            /// <summary>
            /// Property for BatchPrintedFlag 
            /// </summary>
            public const string BatchPrintedFlag = "SWPRINTED";
            /// <summary>
            /// Property for BatchPrintedFlag 
            /// </summary>
            public const string TypePrinted = "SWPRINTED";
            /// <summary>
            /// Property for BankRateOperator 
            /// </summary>
            public const string BankRateOperator = "RATEOP";
            /// <summary>
            /// Property for BankRateOverridden 
            /// </summary>
            public const string BankRateOverridden = "SWRATE";
            /// <summary>
            /// Property for BankRateOverridden 
            /// </summary>
            public const string TypeBankRateOverridden = "SWRATE";
            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPPL";
            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            #endregion

            /// <summary>
            /// New property for BatchDate to filter datetime value
            /// </summary>
            public const string BatchDateTime = BatchDate;

            /// <summary>
            /// New property for DateLastEdited to filter datetime value
            /// </summary>
            public const string LastEditedDateValue = DateLastEdited;

            /// <summary>
            /// New property for BankRateDate to filter datetime value
            /// </summary>
            public const string BankRateDateTimeValue = BankRateDate;

        }


        /// <summary>
        /// Contains list of PaymentAdjustmentBatches Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchSelector 
            /// </summary>
            public const int BatchSelector = 1;
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;
            /// <summary>
            /// Property Indexer for BatchDate 
            /// </summary>
            public const int BatchDate = 3;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 4;
            /// <summary>
            /// Property Indexer for NumberofEntries 
            /// </summary>
            public const int NumberofEntries = 5;
            /// <summary>
            /// Property Indexer for BatchTotal 
            /// </summary>
            public const int BatchTotal = 6;
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 7;
            /// <summary>
            /// Property Indexer for BatchStatus 
            /// </summary>
            public const int BatchStatus = 8;
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 9;

            //TODO: The naming convention of this property has to be relooked          
            /// <summary>
            /// Property Indexer for SWPRTDEP 
            /// </summary>
            public const int SWPRTDEP = 10;
            /// <summary>
            /// Property Indexer for BankCurrencyCode 
            /// </summary>
            public const int BankCurrencyCode = 11;
            /// <summary>
            /// Property Indexer for BankRateDate 
            /// </summary>
            public const int BankRateDate = 12;
            /// <summary>
            /// Property Indexer for LastEntryNumber 
            /// </summary>
            public const int LastEntryNumber = 13;
            /// <summary>
            /// Property Indexer for BankRateType 
            /// </summary>
            public const int BankRateType = 14;
            /// <summary>
            /// Property Indexer for BankExchangeRate 
            /// </summary>
            public const int BankExchangeRate = 15;

            //TODO: The naming convention of this property has to be relooked          
            /// <summary>
            /// Property Indexer for CNTDEPNBR 
            /// </summary>
            public const int CNTDEPNBR = 16;

            //TODO: The naming convention of this property has to be relooked          
            /// <summary>
            /// Property Indexer for CNTDEPSEQ 
            /// </summary>
            public const int CNTDEPSEQ = 17;
            /// <summary>
            /// Property Indexer for FuncBatchTotal 
            /// </summary>
            public const int FuncBatchTotal = 18;
            /// <summary>
            /// Property Indexer for PostingSequenceNo 
            /// </summary>
            public const int PostingSequenceNo = 19;
            /// <summary>
            /// Property Indexer for NumberofErrors 
            /// </summary>
            public const int NumberofErrors = 20;
            /// <summary>
            /// Property Indexer for DateLastEdited 
            /// </summary>
            public const int DateLastEdited = 21;

            //TODO: The naming convention of this property has to be relooked          
            /// <summary>
            /// Property Indexer for CODECHKTYP 
            /// </summary>
            public const int CODECHKTYP = 22;

            //TODO: The naming convention of this property has to be relooked          
            /// <summary>
            /// Property Indexer for PAYMFORM 
            /// </summary>
            public const int PAYMFORM = 23;
            /// <summary>
            /// Property Indexer for BatchEdited 
            /// </summary>
            public const int BatchEdited = 24;
            /// <summary>
            /// Property Indexer for PaymentRegisterPrintstatus 
            /// </summary>
            public const int PaymentRegisterPrintstatus = 25;
            /// <summary>
            /// Property Indexer for NumberofPrintedChecks 
            /// </summary>
            public const int NumberofPrintedChecks = 26;
            /// <summary>
            /// Property Indexer for NumberofReapplies 
            /// </summary>
            public const int NumberofReapplies = 27;
            /// <summary>
            /// Property Indexer for BatchPrintedFlag 
            /// </summary>
            public const int BatchPrintedFlag = 28;
            /// <summary>
            /// Property Indexer for BankRateOperator 
            /// </summary>
            public const int BankRateOperator = 29;
            /// <summary>
            /// Property Indexer for BankRateOverridden 
            /// </summary>
            public const int BankRateOverridden = 30;
            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 31;
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 32;

            #endregion
        }


    }
}
