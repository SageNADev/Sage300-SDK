/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PaymentCodes Constants 
    /// </summary>
	public partial class PaymentCode 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0010";

        /// <summary>
        /// Contains list of PaymentCodes Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for PaymentCode 
        /// </summary>
        public const string PaymentCodeKey = "PAYMCODE";
	            /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "TEXTDESC";
	            /// <summary>
        /// Property for Status 
        /// </summary>
	    public const string Status  = "ACTVSW";
	            /// <summary>
        /// Property for InactiveDate 
        /// </summary>
	    public const string InactiveDate  = "INACTDATE";
	            /// <summary>
        /// Property for DateLastMaintained 
        /// </summary>
	    public const string DateLastMaintained  = "DTELSTMTN";
	            /// <summary>
        /// Property for PaymentType 
        /// </summary>
	    public const string PaymentType  = "PAYMTYPE";


        /// <summary>
        /// Property for PaymentType string value
        /// </summary>
        public const string PaymentTypeString = "PAYMTYPE";

        /// <summary>
        /// Property for Status string value 
        /// </summary>
        public const string StatusString = "ACTVSW";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of PaymentCodes Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for PaymentCode 
        /// </summary>
        public const int PaymentCodeKey = 1;
	             /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 2;
	             /// <summary>
        /// Property Indexer for Status 
        /// </summary>
	    public const int Status  = 3;
	             /// <summary>
        /// Property Indexer for InactiveDate 
        /// </summary>
	    public const int InactiveDate  = 4;
	             /// <summary>
        /// Property Indexer for DateLastMaintained 
        /// </summary>
	    public const int DateLastMaintained  = 5;
	             /// <summary>
        /// Property Indexer for PaymentType 
        /// </summary>
	    public const int PaymentType  = 6;
	     
        #endregion
	    }

	
	}
}
	