/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Selection Criteria Detail Constants 
    /// </summary>
	public partial class SelectionCriteriaDetail
	{
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "AP0036";

        /// <summary>
        /// Contains list of Selection Criteria Detail Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Selection Criteria 
            /// </summary>
            public const string SelectionCriteria = "IDSELECT";

            /// <summary>
            /// Property for Exclude Vendor Number 
            /// </summary>
            public const string ExcludeVendorNumber = "IDVENDOR";

            #endregion
        }


        /// <summary>
        /// Contains list of Selection Criteria Details Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Selection Criteria 
            /// </summary>
            public const int SelectionCriteria = 1;

            /// <summary>
            /// Property Indexer for Exclude Vendor Number 
            /// </summary>
            public const int ExcludeVendorNumber = 2;

            #endregion
        }

	}
}
	