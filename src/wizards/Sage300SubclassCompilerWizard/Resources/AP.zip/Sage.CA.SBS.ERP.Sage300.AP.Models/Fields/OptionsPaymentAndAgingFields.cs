/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models 
{
    /// <summary>
    /// Contains list of OptionsPaymentandAging Constants 
    /// </summary>
    public partial class OptionsPaymentAndAging
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0003";

        /// <summary>
        /// Contains list of PaymentandAgingOptions Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for OptionsRecordKey 
            /// </summary>
            public const string OptionsRecordKey = "RECID03";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for NextPaymentBatchNumber 
            /// </summary>
            public const string NextPaymentBatchNumber = "DRCTBTCH";

            /// <summary>
            /// Property for NextAdjustmentBatchNumber 
            /// </summary>
            public const string NextAdjustmentBatchNumber = "ADJBTCH";

            /// <summary>
            /// Property for DefaultOrderofOpenDocuments 
            /// </summary>
            public const string DefaultOrderofOpenDocuments = "SWDOCORDR";

            /// <summary>
            /// Property for AgingPeriod1 
            /// </summary>
            public const string AgingPeriod1 = "AGINPRD1";

            /// <summary>
            /// Property for AgingPeriod2 
            /// </summary>
            public const string AgingPeriod2 = "AGINPRD2";

            /// <summary>
            /// Property for AgingPeriod3 
            /// </summary>
            public const string AgingPeriod3 = "AGINPRD3";

            /// <summary>
            /// Property for AgeCreditNotesDebitNotes 
            /// </summary>
            public const string AgeCreditNotesDebitNotes = "SWAGECR";

            /// <summary>
            /// Property for DateLastPreregistered 
            /// </summary>
            public const string DateLastPreregistered = "DTPREREG";

            /// <summary>
            /// Property for TimeLastPreregistered 
            /// </summary>
            public const string TimeLastPreregistered = "TMPREREG";

            /// <summary>
            /// Property for DateLastDirectCheck 
            /// </summary>
            public const string DateLastDirectCheck = "DTDRCTCHK";

            /// <summary>
            /// Property for TimeLastDirectCheck 
            /// </summary>
            public const string TimeLastDirectCheck = "TMDRCTCHK";

            /// <summary>
            /// Property for DateLastSysCheck 
            /// </summary>
            public const string DateLastSysCheck = "DTSYSCHK";

            /// <summary>
            /// Property for TimeLastSysCheck 
            /// </summary>
            public const string TimeLastSysCheck = "TMSYSCHK";

            /// <summary>
            /// Property for AllowEditofSystemBatches 
            /// </summary>
            public const string AllowEditofSystemBatches = "SWSYSBTCH";

            /// <summary>
            /// Property for DefaultBankCode 
            /// </summary>
            public const string DefaultBankCode = "IDDFLTBANK";

            /// <summary>
            /// Property for PaymentCode 
            /// </summary>
            public const string PaymentCode = "PAYMCODE";

            /// <summary>
            /// Property for NextPrepaymentNumber 
            /// </summary>
            public const string NextPrepaymentNumber = "CNTPPDBTCH";

            /// <summary>
            /// Property for NextPaymentPostingSequence 
            /// </summary>
            public const string NextPaymentPostingSequence = "CNTNXTPAYM";

            /// <summary>
            /// Property for NextAdjustmentPostingSequence 
            /// </summary>
            public const string NextAdjustmentPostingSequence = "CNTNXTADJM";

            /// <summary>
            /// Property for AllowAdjustmentsinPaymentBat 
            /// </summary>
            public const string AllowAdjustmentsinPaymentBat = "SWPAYMBTCH";

            /// <summary>
            /// Property for PrepaymentPrefix 
            /// </summary>
            public const string PrepaymentPrefix = "PPDPREFIX";

            /// <summary>
            /// Property for PrepaymentNumberLength 
            /// </summary>
            public const string PrepaymentNumberLength = "PPDPFXLEN";

            /// <summary>
            /// Property for AgeUnappliedCashPrepayments 
            /// </summary>
            public const string AgeUnappliedCashPrepayments = "SWAGEUAPL";

            /// <summary>
            /// Property for AdjustmentPrefix 
            /// </summary>
            public const string AdjustmentPrefix = "ADPFX";

            /// <summary>
            /// Property for AdjustmentNumberLength 
            /// </summary>
            public const string AdjustmentNumberLength = "ADPFXLEN";

            /// <summary>
            /// Property for NextAdjustmentNumber 
            /// </summary>
            public const string NextAdjustmentNumber = "ADNEXTSEQ";

            /// <summary>
            /// Property for RecurringPayablePrefix 
            /// </summary>
            public const string RecurringPayablePrefix = "RPPFX";

            /// <summary>
            /// Property for RecurringPayableNumberLength 
            /// </summary>
            public const string RecurringPayableNumberLength = "RPPFXLEN";

            /// <summary>
            /// Property for NextRecurringPayableNumber 
            /// </summary>
            public const string NextRecurringPayableNumber = "RPNEXTSEQ";

            /// <summary>
            /// Property for DefaultTransactionType 
            /// </summary>
            public const string DefaultTransactionType = "RMITTYPE";

            /// <summary>
            /// Property for PaymentPrefix 
            /// </summary>
            public const string PaymentPrefix = "PYPFX";

            /// <summary>
            /// Property for PaymentNumberLength 
            /// </summary>
            public const string PaymentNumberLength = "PYPFXLEN";

            /// <summary>
            /// Property for NextPaymentNumber 
            /// </summary>
            public const string NextPaymentNumber = "PYNEXTSEQ";

            /// <summary>
            /// Property for RetainageInvoicePrefix 
            /// </summary>
            public const string RetainageInvoicePrefix = "RIPFX";

            /// <summary>
            /// Property for RetainageInvoiceNumberLength 
            /// </summary>
            public const string RetainageInvoiceNumberLength = "RIPFXLEN";

            /// <summary>
            /// Property for NextRetainageInvoiceNumber 
            /// </summary>
            public const string NextRetainageInvoiceNumber = "RINEXTSEQ";

            /// <summary>
            /// Property for RetainageCreditNotePrefix 
            /// </summary>
            public const string RetainageCreditNotePrefix = "RCPFX";

            /// <summary>
            /// Property for RetainageCreditNoteNoLength 
            /// </summary>
            public const string RetainageCreditNoteNoLength = "RCPFXLEN";

            /// <summary>
            /// Property for NextRetainageCreditNoteNo 
            /// </summary>
            public const string NextRetainageCreditNoteNo = "RCNEXTSEQ";

            /// <summary>
            /// Property for RetainageDebitNotePrefix 
            /// </summary>
            public const string RetainageDebitNotePrefix = "RDPFX";

            /// <summary>
            /// Property for RetainageDebitNoteNoLength 
            /// </summary>
            public const string RetainageDebitNoteNoLength = "RDPFXLEN";

            /// <summary>
            /// Property for NextRetainageDebitNoteNo 
            /// </summary>
            public const string NextRetainageDebitNoteNo = "RDNEXTSEQ";

            /// <summary>
            /// Property for UseRetainage 
            /// </summary>
            public const string UseRetainage = "SWRTG";

            /// <summary>
            /// Property for RetainageBase 
            /// </summary>
            public const string RetainageBase = "SWRTGBASE";

            /// <summary>
            /// Property for RetainageSchedule 
            /// </summary>
            public const string RetainageSchedule = "RTGSCHDKEY";

            /// <summary>
            /// Property for RetainageScheduleLink 
            /// </summary>
            public const string RetainageScheduleLink = "RTGSCHDLNK";

            /// <summary>
            /// Property for DateRetainageSchedLastRun 
            /// </summary>
            public const string DateRetainageSchedLastRun = "RTGLASTRUN";

            /// <summary>
            /// Property for DaysRetained 
            /// </summary>
            public const string DaysRetained = "RTGDAYS";

            /// <summary>
            /// Property for PercentRetained 
            /// </summary>
            public const string PercentRetained = "RTGPERCENT";

            /// <summary>
            /// Property for DaysBeforeRetainageDue 
            /// </summary>
            public const string DaysBeforeRetainageDue = "RTGADVDAYS";

            /// <summary>
            /// Property for RetainageExchangeRate 
            /// </summary>
            public const string RetainageExchangeRate = "SWRTGRATE";

            /// <summary>
            /// Property for ReportRetainageTax 
            /// </summary>
            public const string ReportRetainageTax = "SWTXRTGRPT";

            /// <summary>
            /// Property for AllowEditofRemitToInfo 
            /// </summary>
            public const string AllowEditofRemitToInfo = "SWCHNGRMIT";

            /// <summary>
            /// Property for CheckforDuplicateChecks 
            /// </summary>
            public const string CheckforDuplicateChecks = "SWCHKDUP";

            /// <summary>
            /// Property for IncludePendingTransactions 
            /// </summary>
            public const string IncludePendingTransactions = "SWSHPYPND";

            /// <summary>
            /// Property for DefaultPostingDate 
            /// </summary>
            public const string DefaultPostingDate = "SWDATEBUS";

            /// <summary>
            /// Property for SortChecksBy 
            /// </summary>
            public const string SortChecksBy = "SORTCHKBY";

            #endregion
        }

        /// <summary>
        /// Contains list of PaymentandAgingOptions Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for OptionsRecordKey 
            /// </summary>
            public const int OptionsRecordKey = 1;

            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 2;

            /// <summary>
            /// Property Indexer for NextPaymentBatchNumber 
            /// </summary>
            public const int NextPaymentBatchNumber = 3;

            /// <summary>
            /// Property Indexer for NextAdjustmentBatchNumber 
            /// </summary>
            public const int NextAdjustmentBatchNumber = 5;

            /// <summary>
            /// Property Indexer for DefaultOrderofOpenDocuments 
            /// </summary>
            public const int DefaultOrderofOpenDocuments = 9;

            /// <summary>
            /// Property Indexer for AgingPeriod1 
            /// </summary>
            public const int AgingPeriod1 = 11;

            /// <summary>
            /// Property Indexer for AgingPeriod2 
            /// </summary>
            public const int AgingPeriod2 = 12;

            /// <summary>
            /// Property Indexer for AgingPeriod3 
            /// </summary>
            public const int AgingPeriod3 = 13;

            /// <summary>
            /// Property Indexer for AgeCreditNotesDebitNotes 
            /// </summary>
            public const int AgeCreditNotesDebitNotes = 14;

            /// <summary>
            /// Property Indexer for DateLastPreregistered 
            /// </summary>
            public const int DateLastPreregistered = 15;

            /// <summary>
            /// Property Indexer for TimeLastPreregistered 
            /// </summary>
            public const int TimeLastPreregistered = 16;

            /// <summary>
            /// Property Indexer for DateLastDirectCheck 
            /// </summary>
            public const int DateLastDirectCheck = 17;

            /// <summary>
            /// Property Indexer for TimeLastDirectCheck 
            /// </summary>
            public const int TimeLastDirectCheck = 18;

            /// <summary>
            /// Property Indexer for DateLastSysCheck 
            /// </summary>
            public const int DateLastSysCheck = 19;

            /// <summary>
            /// Property Indexer for TimeLastSysCheck 
            /// </summary>
            public const int TimeLastSysCheck = 20;

            /// <summary>
            /// Property Indexer for AllowEditofSystemBatches 
            /// </summary>
            public const int AllowEditofSystemBatches = 21;

            /// <summary>
            /// Property Indexer for DefaultBankCode 
            /// </summary>
            public const int DefaultBankCode = 23;

            /// <summary>
            /// Property Indexer for PaymentCode 
            /// </summary>
            public const int PaymentCode = 25;

            /// <summary>
            /// Property Indexer for NextPrepaymentNumber 
            /// </summary>
            public const int NextPrepaymentNumber = 26;

            /// <summary>
            /// Property Indexer for NextPaymentPostingSequence 
            /// </summary>
            public const int NextPaymentPostingSequence = 28;

            /// <summary>
            /// Property Indexer for NextAdjustmentPostingSequence 
            /// </summary>
            public const int NextAdjustmentPostingSequence = 29;

            /// <summary>
            /// Property Indexer for AllowAdjustmentsinPaymentBat 
            /// </summary>
            public const int AllowAdjustmentsinPaymentBat = 30;

            /// <summary>
            /// Property Indexer for PrepaymentPrefix 
            /// </summary>
            public const int PrepaymentPrefix = 31;

            /// <summary>
            /// Property Indexer for PrepaymentNumberLength 
            /// </summary>
            public const int PrepaymentNumberLength = 32;

            /// <summary>
            /// Property Indexer for AgeUnappliedCashPrepayments 
            /// </summary>
            public const int AgeUnappliedCashPrepayments = 33;

            /// <summary>
            /// Property Indexer for AdjustmentPrefix 
            /// </summary>
            public const int AdjustmentPrefix = 35;

            /// <summary>
            /// Property Indexer for AdjustmentNumberLength 
            /// </summary>
            public const int AdjustmentNumberLength = 36;

            /// <summary>
            /// Property Indexer for NextAdjustmentNumber 
            /// </summary>
            public const int NextAdjustmentNumber = 37;

            /// <summary>
            /// Property Indexer for RecurringPayablePrefix 
            /// </summary>
            public const int RecurringPayablePrefix = 38;

            /// <summary>
            /// Property Indexer for RecurringPayableNumberLength 
            /// </summary>
            public const int RecurringPayableNumberLength = 39;

            /// <summary>
            /// Property Indexer for NextRecurringPayableNumber 
            /// </summary>
            public const int NextRecurringPayableNumber = 40;

            /// <summary>
            /// Property Indexer for DefaultTransactionType 
            /// </summary>
            public const int DefaultTransactionType = 41;

            /// <summary>
            /// Property Indexer for PaymentPrefix 
            /// </summary>
            public const int PaymentPrefix = 42;

            /// <summary>
            /// Property Indexer for PaymentNumberLength 
            /// </summary>
            public const int PaymentNumberLength = 43;

            /// <summary>
            /// Property Indexer for NextPaymentNumber 
            /// </summary>
            public const int NextPaymentNumber = 44;

            /// <summary>
            /// Property Indexer for RetainageInvoicePrefix 
            /// </summary>
            public const int RetainageInvoicePrefix = 45;

            /// <summary>
            /// Property Indexer for RetainageInvoiceNumberLength 
            /// </summary>
            public const int RetainageInvoiceNumberLength = 46;

            /// <summary>
            /// Property Indexer for NextRetainageInvoiceNumber 
            /// </summary>
            public const int NextRetainageInvoiceNumber = 47;

            /// <summary>
            /// Property Indexer for RetainageCreditNotePrefix 
            /// </summary>
            public const int RetainageCreditNotePrefix = 48;

            /// <summary>
            /// Property Indexer for RetainageCreditNoteNoLength 
            /// </summary>
            public const int RetainageCreditNoteNoLength = 49;

            /// <summary>
            /// Property Indexer for NextRetainageCreditNoteNo 
            /// </summary>
            public const int NextRetainageCreditNoteNo = 50;

            /// <summary>
            /// Property Indexer for RetainageDebitNotePrefix 
            /// </summary>
            public const int RetainageDebitNotePrefix = 51;

            /// <summary>
            /// Property Indexer for RetainageDebitNoteNoLength 
            /// </summary>
            public const int RetainageDebitNoteNoLength = 52;

            /// <summary>
            /// Property Indexer for NextRetainageDebitNoteNo 
            /// </summary>
            public const int NextRetainageDebitNoteNo = 53;

            /// <summary>
            /// Property Indexer for UseRetainage 
            /// </summary>
            public const int UseRetainage = 54;

            /// <summary>
            /// Property Indexer for RetainageBase 
            /// </summary>
            public const int RetainageBase = 55;

            /// <summary>
            /// Property Indexer for RetainageSchedule 
            /// </summary>
            public const int RetainageSchedule = 56;

            /// <summary>
            /// Property Indexer for RetainageScheduleLink 
            /// </summary>
            public const int RetainageScheduleLink = 57;

            /// <summary>
            /// Property Indexer for DateRetainageSchedLastRun 
            /// </summary>
            public const int DateRetainageSchedLastRun = 58;

            /// <summary>
            /// Property Indexer for DaysRetained 
            /// </summary>
            public const int DaysRetained = 59;

            /// <summary>
            /// Property Indexer for PercentRetained 
            /// </summary>
            public const int PercentRetained = 60;

            /// <summary>
            /// Property Indexer for DaysBeforeRetainageDue 
            /// </summary>
            public const int DaysBeforeRetainageDue = 61;

            /// <summary>
            /// Property Indexer for RetainageExchangeRate 
            /// </summary>
            public const int RetainageExchangeRate = 62;

            /// <summary>
            /// Property Indexer for ReportRetainageTax 
            /// </summary>
            public const int ReportRetainageTax = 63;

            /// <summary>
            /// Property Indexer for AllowEditofRemitToInfo 
            /// </summary>
            public const int AllowEditofRemitToInfo = 64;

            /// <summary>
            /// Property Indexer for CheckforDuplicateChecks 
            /// </summary>
            public const int CheckforDuplicateChecks = 65;

            /// <summary>
            /// Property Indexer for IncludePendingTransactions 
            /// </summary>
            public const int IncludePendingTransactions = 66;

            /// <summary>
            /// Property Indexer for DefaultPostingDate 
            /// </summary>
            public const int DefaultPostingDate = 67;

            /// <summary>
            /// Property Indexer for SortChecksBy 
            /// </summary>
            public const int SortChecksBy = 68;

            #endregion
        }
    }
}


	