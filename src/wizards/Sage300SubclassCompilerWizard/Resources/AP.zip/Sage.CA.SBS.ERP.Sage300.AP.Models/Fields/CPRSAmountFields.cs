// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 


// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of CPRS Amounts Constants 
    /// </summary>
    public partial class CPRSAmount
    {

        /// <summary>
        /// EntityName Name
        /// </summary>
        public const string EntityName = "AP0013";

        /// <summary>
        /// Contains list of CPRSAmounts Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties

            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "VENDORID";

            /// <summary>
            /// Property for Code 
            /// </summary>
            public const string Code = "CLASFCID";

            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string Year = "CNTYEAR";

            /// <summary>
            /// Property for Month 
            /// </summary>
            public const string Month = "CNTMONTH";

            /// <summary>
            /// Property for LastPaymentDate 
            /// </summary>
            public const string LastPaymentDate = "LSTPYMDATE";

            /// <summary>
            /// Property for NumberofPayments 
            /// </summary>
            public const string NumberofPayments = "PAYMNTCNT";

            /// <summary>
            /// Property for PaymentAmount 
            /// </summary>
            public const string PaymentAmount = "PAYMNTAMT";

            #endregion
        }


        /// <summary>
        /// Contains list of CPRSAmounts Index Constants
        /// </summary>
        public class Index
        {

            #region Properties

            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 1;

            /// <summary>
            /// Property Indexer for Code 
            /// </summary>
            public const int Code = 2;

            /// <summary>
            /// Property Indexer for Year 
            /// </summary>
            public const int Year = 3;

            /// <summary>
            /// Property Indexer for Month 
            /// </summary>
            public const int Month = 4;

            /// <summary>
            /// Property Indexer for LastPaymentDate 
            /// </summary>
            public const int LastPaymentDate = 5;

            /// <summary>
            /// Property Indexer for NumberofPayments 
            /// </summary>
            public const int NumberofPayments = 6;

            /// <summary>
            /// Property Indexer for PaymentAmount 
            /// </summary>
            public const int PaymentAmount = 8;

            #endregion
        }


    }
}
	