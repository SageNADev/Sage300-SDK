/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of 1099/CPRS Codes Constants 
    /// </summary>
	public partial class CPRSCode 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "AP0007";

        /// <summary>
        /// Contains list of 1099CPRSCodes Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	    /// <summary>
        /// Property for Code 
        /// </summary>
	    public const string Code  = "CLASSID";
	    /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "CLASSDESC";
	    /// <summary>
        /// Property for Status 
        /// </summary>
	    public const string Status  = "SWACTV";
	    /// <summary>
        /// Property for InactiveDate 
        /// </summary>
	    public const string InactiveDate  = "DATEINACTV";
	    /// <summary>
        /// Property for DateLastMaintained 
        /// </summary>
	    public const string DateLastMaintained  = "DATELASTMN";
	     /// <summary>
        /// Property for MinimumAmountToReport 
        /// </summary>
	    public const string MinimumAmountToReport  = "MINAMT";
        /// <summary>
        /// Property for Status String
        /// </summary>
        public const string StatusString = "SWACTV";

            /// <summary>
            /// Property for Tax Report Type
            /// </summary>
            public const string TaxReportingType = "TAXRPTSW";

            /// <summary>
            /// Property for Amount Type 
            /// </summary>
            public const string Category = "CATEGORY";

            #endregion
        }


        /// <summary>
        /// Contains list of 1099CPRSCodes Index Constants
        /// </summary>
        public class Index
        {

        #region Properties
	    /// <summary>
        /// Property Indexer for Code 
        /// </summary>
	    public const int Code  = 1;
	    /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 2;
	    /// <summary>
        /// Property Indexer for Status 
        /// </summary>
	    public const int Status  = 3;
	    /// <summary>
        /// Property Indexer for InactiveDate 
        /// </summary>
	    public const int InactiveDate  = 4;
	   /// <summary>
        /// Property Indexer for DateLastMaintained 
        /// </summary>
	    public const int DateLastMaintained  = 5;
	    /// <summary>
        /// Property Indexer for MinimumAmountToReport 
        /// </summary>
	    public const int MinimumAmountToReport  = 14;

            /// <summary>
            /// Property Indexer for Tax Report Type
            /// </summary>
            public const int TaxReportingType = 15;

            /// <summary>
            /// Property Indexer for Amount Type 
            /// </summary>
            public const int Category = 16;

            #endregion
        }


    }
}
	
