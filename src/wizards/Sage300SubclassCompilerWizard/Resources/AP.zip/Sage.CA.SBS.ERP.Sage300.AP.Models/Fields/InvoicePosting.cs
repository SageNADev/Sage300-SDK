﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PostInvoices Constants 
    /// </summary>
    public partial class InvoicePosting
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "ZI0022";

        /// <summary>
        /// Contains list of InvoicePosting Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for ProcessAllBatches
            /// </summary>
            public const string ProcessAll = "SWALL";

            /// <summary>
            /// Property for FromBatch 
            /// </summary>
            public const string FromBatch = "FROMBTCH";

            /// <summary>
            /// Property for ToBatch 
            /// </summary>
            public const string ToBatch = "TOBTCH";

            #endregion
        }

        /// <summary>
        /// Contains list of InvoicePosting Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for ProcessAllBatches 
            /// </summary>
            public const int ProcessAll = 1;

            /// <summary>
            /// Property Indexer for FromBatch 
            /// </summary>
            public const int FromBatch = 2;

            /// <summary>
            /// Property Indexer for ToBatch 
            /// </summary>
            public const int ToBatch = 3;

            #endregion
        }
    }
}
