/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of Vendors Constants 
    /// </summary>
	public partial class Vendor 
	{
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "AP0015";

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0015";

        /// <summary>
        /// Contains list of Vendors Fields Constants
        /// </summary>
	    public class Fields
        {
            #region Properties

	        /// <summary>
            /// Property for VendorNumber 
            /// </summary>
	        public const string VendorNumber  = "VENDORID";
	        
            /// <summary>
            /// Property for ShortName 
            /// </summary>
	        public const string ShortName  = "SHORTNAME";
	       
            /// <summary>
            /// Property for GroupCode 
            /// </summary>
	        public const string GroupCode  = "IDGRP";
	      
            /// <summary>
            /// Property for Status 
            /// </summary>
	        public const string Status  = "SWACTV";
	       
            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
	        public const string InactiveDate  = "DATEINAC";
	       
            /// <summary>
            /// Property for LastMaintainedDate 
            /// </summary>
	        public const string LastMaintainedDate  = "DATELASTMN";
	       
            /// <summary>
            /// Property for OnHold 
            /// </summary>
	        public const string OnHold  = "SWHOLD";
	       
            /// <summary>
            /// Property for StartDate 
            /// </summary>
	        public const string StartDate  = "DATESTART";
	        
            /// <summary>
            /// Property for ParticipantID 
            /// </summary>
	        public const string ParticipantID  = "IDPPNT";
	       
            /// <summary>
            /// Property for VendorName 
            /// </summary>
	        public const string VendorName  = "VENDNAME";
	       
            /// <summary>
            /// Property for AddressLine1 
            /// </summary>
	        public const string AddressLine1  = "TEXTSTRE1";
	       
            /// <summary>
            /// Property for AddressLine2 
            /// </summary>
	        public const string AddressLine2  = "TEXTSTRE2";
	       
            /// <summary>
            /// Property for AddressLine3 
            /// </summary>
	        public const string AddressLine3  = "TEXTSTRE3";
	       
            /// <summary>
            /// Property for AddressLine4 
            /// </summary>
	        public const string AddressLine4  = "TEXTSTRE4";
	       
            /// <summary>
            /// Property for City 
            /// </summary>
	        public const string City  = "NAMECITY";
	       
            /// <summary>
            /// Property for StateOrProvince 
            /// </summary>
	        public const string StateOrProvince  = "CODESTTE";
	      
            /// <summary>
            /// Property for ZipOrPostalCode 
            /// </summary>
	        public const string ZipOrPostalCode  = "CODEPSTL";
	       
            /// <summary>
            /// Property for Country 
            /// </summary>
	        public const string Country  = "CODECTRY";
	         
            /// <summary>
            /// Property for ContactName 
            /// </summary>
	        public const string ContactName  = "NAMECTAC";
	        
            /// <summary>
            /// Property for PhoneNumber 
            /// </summary>
	        public const string PhoneNumber  = "TEXTPHON1";
	        
            /// <summary>
            /// Property for FaxNumber 
            /// </summary>
	        public const string FaxNumber  = "TEXTPHON2";
	        
            /// <summary>
            /// Property for PrimaryRemitToLocation 
            /// </summary>
	        public const string PrimaryRemitToLocation  = "PRIMRMIT";
	        
            /// <summary>
            /// Property for AccountSet 
            /// </summary>
	        public const string AccountSet  = "IDACCTSET";
	        
            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
	        public const string CurrencyCode  = "CURNCODE";
	        
            /// <summary>
            /// Property for RateType 
            /// </summary>
	        public const string RateType  = "RATETYPE";
	        
            /// <summary>
            /// Property for BankCode 
            /// </summary>
	        public const string BankCode  = "BANKID";
	        
            /// <summary>
            /// Property for PrintSeparateChecks 
            /// </summary>
	        public const string PrintSeparateChecks  = "PRTSEPCHKS";
	        
            /// <summary>
            /// Property for DistributionSet 
            /// </summary>
	        public const string DistributionSet  = "DISTSETID";
	        
            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
	        public const string DistributionCode  = "DISTCODE";
	        
            /// <summary>
            /// Property for GOrLAccount 
            /// </summary>
	        public const string GLAccount  = "GLACCNT";
	        
            /// <summary>
            /// Property for Terms 
            /// </summary>
	        public const string Terms  = "TERMSCODE";
	     
            /// <summary>
            /// Property for Duplicate Invoice Code 
            /// </summary>
            public const string DuplicateInvoiceCode = "DUPINVCCD";
	        
            /// <summary>
            /// Property for DuplicateAmountCode 
            /// </summary>
	        public const string DuplicateAmountCode  = "DUPAMTCODE";
	        
            /// <summary>
            /// Property for DuplicateDateCode 
            /// </summary>
	        public const string DuplicateDateCode  = "DUPDATECD";
	        
            /// <summary>
            /// Property for TaxGroup 
            /// </summary>
	        public const string TaxGroup  = "CODETAXGRP";
	        
            /// <summary>
            /// Property for TaxClassCode1 
            /// </summary>
	        public const string TaxClassCode1  = "TAXCLASS1";
	       
            /// <summary>
            /// Property for TaxClassCode2 
            /// </summary>
	        public const string TaxClassCode2  = "TAXCLASS2";
	        
            /// <summary>
            /// Property for TaxClassCode3 
            /// </summary>
	        public const string TaxClassCode3  = "TAXCLASS3";
	        
            /// <summary>
            /// Property for TaxClassCode4 
            /// </summary>
	        public const string TaxClassCode4  = "TAXCLASS4";
	        
            /// <summary>
            /// Property for TaxClassCode5 
            /// </summary>
	        public const string TaxClassCode5  = "TAXCLASS5";
	       
            /// <summary>
            /// Property for TaxReportingType 
            /// </summary>
	        public const string TaxReportingType  = "TAXRPTSW";
	     
            /// <summary>
            /// Property for Subject To With Hold 
            /// </summary>
            public const string SubjectToWithHold = "SUBJTOWTHH";
	         
            /// <summary>
            /// Property for CPRS Tax Number 
            /// </summary>
            public const string CprsTaxNumber = "TAXNBR";
	        
            /// <summary>
            /// Property for TaxType 
            /// </summary>
	        public const string TaxType  = "TAXIDTYPE";
	        
            /// <summary>
            /// Property for Tax Note to SW. 
            /// </summary>
            public const string TaxNote2Sw = "TAXNOTE2SW";
	        
            /// <summary>
            /// Property for CPRS Code 
            /// </summary>
            public const string CprsCode = "CLASID";
	        
            /// <summary>
            /// Property for CreditLimit 
            /// </summary>
	        public const string CreditLimit  = "AMTCRLIMT";
	        
            /// <summary>
            /// Property for BalanceDueinVendorCurrency 
            /// </summary>
	        public const string BalanceDueinVendorCurrency  = "AMTBALDUET";
	        
            /// <summary>
            /// Property for BalanceDueinFuncCurrency 
            /// </summary>
            public const string BalanceDueinFunctionCurrency = "AMTBALDUEH";
	        
            /// <summary>
            /// Property for TotalPrepaidInvoiceVendCurr 
            /// </summary>
            public const string TotalPrepaidInvoiceVendCurrency = "AMTPPDINVT";
	        
            /// <summary>
            /// Property for TotalPrepaidInvoiceFuncCurr 
            /// </summary>
            public const string TotalPrepaidInvoiceFunctionCurrency = "AMTPPDINVH";
	        
            /// <summary>
            /// Property for DateofLastRevaluation 
            /// </summary>
	        public const string DateofLastRevaluation  = "DTLASTRVAL";
	        
            /// <summary>
            /// Property for LastRevaluationBalance 
            /// </summary>
	        public const string LastRevaluationBalance  = "AMTBALLARV";
	        
            /// <summary>
            /// Property for NumberofOpenInvoices 
            /// </summary>
	        public const string NumberofOpenInvoices  = "CNTOPENINV";
	        
            /// <summary>
            /// Property for NumberofPrepaidInvoices 
            /// </summary>
	        public const string NumberofPrepaidInvoices  = "CNTPPDINVC";
	        
            /// <summary>
            /// Property for NumberofPaidInvoices 
            /// </summary>
	        public const string NumberofPaidInvoices  = "CNTINVPAID";
	        
            /// <summary>
            /// Property for NumberofDaystoPay 
            /// </summary>
	        public const string NumberofDaystoPay  = "DAYSTOPAY";
	        
            /// <summary>
            /// Property for DateofLargestInvoice 
            /// </summary>
	        public const string DateofLargestInvoice  = "DATEINVCHI";
	        
            /// <summary>
            /// Property for DateofHighestBalance 
            /// </summary>
	        public const string DateofHighestBalance  = "DATEBALHI";
	         
            /// <summary>
            /// Property for DateofLargestInvoiceLastYr 
            /// </summary>
	        public const string DateofLargestInvoiceLastYr  = "DATEINVHIL";
	        
            /// <summary>
            /// Property for DateofHighestBalanceLastYr 
            /// </summary>
	        public const string DateofHighestBalanceLastYr  = "DATEBALHIL";
	         
            /// <summary>
            /// Property for DateofLastActivity 
            /// </summary>
	        public const string DateofLastActivity  = "DATELASTAC";
	        
            /// <summary>
            /// Property for DateofLastInvoice 
            /// </summary>
	        public const string DateofLastInvoice  = "DATELASTIV";
	        
            /// <summary>
            /// Property for DateofLastCreditNote 
            /// </summary>
	        public const string DateofLastCreditNote  = "DATELASTCR";
	        
            /// <summary>
            /// Property for DateofLastDebitNote 
            /// </summary>
	        public const string DateofLastDebitNote  = "DATELASTDR";
	        
            /// <summary>
            /// Property for DateofLastPayment 
            /// </summary>
	        public const string DateofLastPayment  = "DATELASTPA";
	        
            /// <summary>
            /// Property for DateofLastDiscount 
            /// </summary>
	        public const string DateofLastDiscount  = "DATELASTDI";
	        
            /// <summary>
            /// Property for DateofLastAdjustment 
            /// </summary>
	        public const string DateofLastAdjustment  = "DATELSTADJ";
	        
            /// <summary>
            /// Property for NumberofLargestInvoice 
            /// </summary>
	        public const string NumberofLargestInvoice  = "IDINVCHI";
	        
            /// <summary>
            /// Property for NumberofLargestInvoiceLastY 
            /// </summary>
	        public const string NumberofLargestInvoiceLastY  = "IDINVCHILY";
	        
            /// <summary>
            /// Property for LargestInvoiceVendCurr 
            /// </summary>
            public const string LargestInvoiceVendCurrency = "AMTINVHIT";
	        
            /// <summary>
            /// Property for HighestBalanceVendCurr 
            /// </summary>
            public const string HighestBalanceVendCurrency = "AMTBALHIT";
	     
            /// <summary>
            /// Property for Amount Without Currency 
            /// </summary>
            public const string AmountWithoutCurrency = "AMTWTHTCUR";
	        
            /// <summary>
            /// Property for LargInvLastYrVendCurr 
            /// </summary>
            public const string LargestInvLastYrVendCurrency = "AMTINVHILT";
	        
            /// <summary>
            /// Property for HighBalLastYrVendCurr 
            /// </summary>
            public const string HighBalLastYrVendCurrency = "AMTBALHILT";
	     
            /// <summary>
            /// Property for Amount with lytc 
            /// </summary>
            public const string Amountwithlytc = "AMTWTHLYTC";
	        
            /// <summary>
            /// Property for LastInvoiceAmtVendCurr 
            /// </summary>
            public const string LastInvoiceAmtVendCurrency = "AMTLASTIVT";
	        
            /// <summary>
            /// Property for LastCrNoteAmtVendCurr 
            /// </summary>
            public const string LastCrNoteAmtVendCurrency = "AMTLASTCRT";
	        
            /// <summary>
            /// Property for LastDrNoteAmtVendCurr 
            /// </summary>
            public const string LastDrNoteAmtVendCurrency = "AMTLASTDRT";
	        
            /// <summary>
            /// Property for LastPaymentVendCurr 
            /// </summary>
            public const string LastPaymentVendCurrency = "AMTLASTPYT";
	        
            /// <summary>
            /// Property for LastDiscountAmtVendCurr 
            /// </summary>
            public const string LastDiscountAmtVendCurrency = "AMTLASTDIT";
	         
            /// <summary>
            /// Property for LastAdjAmtVendCurr 
            /// </summary>
            public const string LastAdjAmtVendCurrency = "AMTLASTADT";
	        
            /// <summary>
            /// Property for LargestInvoiceFuncCurr 
            /// </summary>
            public const string LargestInvoiceFunctionCurrency = "AMTINVHIH";
	         
            /// <summary>
            /// Property for HighestBalanceFuncCurr 
            /// </summary>
            public const string HighestBalanceFunctionCurrency = "AMTBALHIH";
	     
            /// <summary>
            /// Property for Amount With Currency 
            /// </summary>
            public const string AmountWithCurrency = "AMTWTHHCUR";
	        
            /// <summary>
            /// Property for LargInvLastYrFuncCurr 
            /// </summary>
            public const string LargestInvestLastYearFunctionCurrency = "AMTINVHILH";
	        
            /// <summary>
            /// Property for HighBalLastYrFuncCurr 
            /// </summary>
            public const string HighBalLastYearFunctionCurrency = "AMTBALHILH";
	     
            /// <summary>
            /// Property for Amount with lyhc 
            /// </summary>
            public const string Amountwithlyhc = "AMTWTHLYHC";
	        
            /// <summary>
            /// Property for LastInvoiceAmtFuncCurr 
            /// </summary>
            public const string LastInvoiceAmtFunctionCurrency = "AMTLASTIVH";
	        
            /// <summary>
            /// Property for LastCrNoteAmtFuncCurr 
            /// </summary>
            public const string LastCrNoteAmtFunctionCurrency = "AMTLASTCRH";
	        
            /// <summary>
            /// Property for LastDrNoteAmtFuncCurr 
            /// </summary>
            public const string LastDrNoteAmtFunctionCurrency = "AMTLASTDRH";
	         
            /// <summary>
            /// Property for LastPaymentFuncCurr 
            /// </summary>
            public const string LastPaymentFunctionCurrency = "AMTLASTPYH";
	        
            /// <summary>
            /// Property for LastDiscountAmtFuncCurr 
            /// </summary>
            public const string LastDiscountAmtFunctionCurrency = "AMTLASTDIH";
	        
            /// <summary>
            /// Property for LastAdjAmtFuncCurr 
            /// </summary>
            public const string LastAdjAmtFunctionCurrency = "AMTLASTADH";
	        
            /// <summary>
            /// Property for PaymentCode 
            /// </summary>
	        public const string PaymentCode  = "PAYMCODE";
	        
            /// <summary>
            /// Property for TaxRegistrationCode1 
            /// </summary>
	        public const string TaxRegistrationCode1  = "IDTAXREGI1";
	         
            /// <summary>
            /// Property for TaxRegistrationCode2 
            /// </summary>
	        public const string TaxRegistrationCode2  = "IDTAXREGI2";
	        
            /// <summary>
            /// Property for TaxRegistrationCode3 
            /// </summary>
	        public const string TaxRegistrationCode3  = "IDTAXREGI3";
	       
            /// <summary>
            /// Property for TaxRegistrationCode4 
            /// </summary>
	        public const string TaxRegistrationCode4  = "IDTAXREGI4";
	        
            /// <summary>
            /// Property for TaxRegistrationCode5 
            /// </summary>
	        public const string TaxRegistrationCode5  = "IDTAXREGI5";
	        
            /// <summary>
            /// Property for DistributionType 
            /// </summary>
	        public const string DistributionType  = "SWDISTBY";
	        
            /// <summary>
            /// Property for CheckLanguage 
            /// </summary>
	        public const string CheckLanguage  = "CODECHECK";
	        
            /// <summary>
            /// Property for AverageDaystoPay 
            /// </summary>
	        public const string AverageDaystoPay  = "AVGDAYSPAY";
	     
            /// <summary>
            /// Property for Average Payment 
            /// </summary>
            public const string AveragePayment = "AVGPAYMENT";
	        
            /// <summary>
            /// Property for TotalInvoicesPaidFuncCurr 
            /// </summary>
            public const string TotalInvoicesPaidFunctionCurrency = "AMTINVPDHC";
	        
            /// <summary>
            /// Property for TotalInvoicesPaidVendCurr 
            /// </summary>
            public const string TotalInvoicesPaidVendorCurrency = "AMTINVPDTC";
	        
            /// <summary>
            /// Property for TotalNumberofPayments 
            /// </summary>
            public const string TotalNumberofPayments = "CNTNBRCHKS";
	        
            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
	        public const string TaxIncluded1  = "SWTXINC1";
	        
            /// <summary>
            /// Property for TaxIncluded2 
            /// </summary>
	        public const string TaxIncluded2  = "SWTXINC2";
	        
            /// <summary>
            /// Property for TaxIncluded3 
            /// </summary>
	        public const string TaxIncluded3  = "SWTXINC3";
	        
            /// <summary>
            /// Property for TaxIncluded4 
            /// </summary>
	        public const string TaxIncluded4  = "SWTXINC4";
	        
            /// <summary>
            /// Property for TaxIncluded5 
            /// </summary>
	        public const string TaxIncluded5  = "SWTXINC5";
	        
            /// <summary>
            /// Property for ContactsEmail 
            /// </summary>
	        public const string ContactsEmail  = "EMAIL1";
	        
            /// <summary>
            /// Property for Email 
            /// </summary>
	        public const string Email  = "EMAIL2";
	        
            /// <summary>
            /// Property for WebSite 
            /// </summary>
	        public const string WebSite  = "WEBSITE";
	        
            /// <summary>
            /// Property for ContactsPhone 
            /// </summary>
	        public const string ContactsPhone  = "CTACPHONE";
	         
            /// <summary>
            /// Property for ContactsFax 
            /// </summary>
	        public const string ContactsFax  = "CTACFAX";
	        
            /// <summary>
            /// Property for DeliveryMethod 
            /// </summary>
	        public const string DeliveryMethod  = "DELMETHOD";
	        
            /// <summary>
            /// Property for PercentRetained 
            /// </summary>
	        public const string PercentRetained  = "RTGPERCENT";
	        
            /// <summary>
            /// Property for DaysRetained 
            /// </summary>
	        public const string DaysRetained  = "RTGDAYS";
	        
            /// <summary>
            /// Property for RetainageTermsCode 
            /// </summary>
	        public const string RetainageTermsCode  = "RTGTERMS";
	        
            /// <summary>
            /// Property for AmountRetainedVendCurr 
            /// </summary>
	        public const string AmountRetainedVendCurr  = "RTGAMTTC";
	        
            /// <summary>
            /// Property for AmountRetainedFuncCurr 
            /// </summary>
	        public const string AmountRetainedFuncCurr  = "RTGAMTHC";
	        
            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
	        public const string OptionalFields  = "VALUES";
	        
            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
	        public const string ProcessCommandCode  = "PROCESSCMD";
	         
            /// <summary>
            /// Property for NextClientUniqueID 
            /// </summary>
	        public const string NextClientUniqueID  = "NEXTCUID";
	        
            /// <summary>
            /// Property for VendorLegalName 
            /// </summary>
            public const string VendorLegalName = "LEGALNAME";
	        
            /// <summary>
            /// Property for Zero1099AmountWarning 
            /// </summary>
	        public const string Zero1099AmountWarning  = "CHK1099AMT";
	         
            /// <summary>
            /// Property for CustomerNumber 
            /// </summary>
	        public const string CustomerNumber  = "IDCUST";
	        
            /// <summary>
            /// Property for SuppressIntegration 
            /// </summary>
	        public const string SuppressIntegration  = "EWSUPPRESS";
	        
            /// <summary>
            /// Property for AP Version 
            /// </summary>
	        public const string ApVersion  = "EWAPVER";
	        
            /// <summary>
            /// Property for Database 
            /// </summary>
            public const string Database  = "EWORGID";

            /// <summary>
            /// Property for Mode 
            /// </summary>
	        public const string Mode  = "EWMODE";

            /// <summary>
            /// Property for BusinessRegistrationNumber
            /// </summary>
            public const string BusinessRegistrationNumber = "BRN";
    
            /// <summary>
            /// Property for FirstName
            /// </summary>
            public const string FirstName = "FIRSTNAME";
    
            /// <summary>
            /// Property for LastName
            /// </summary>
            public const string LastName = "LASTNAME";
    
            /// <summary>
            /// Property for FATCA
            /// </summary>
            public const string FATCA = "FATCA";
    
            /// <summary>
            /// Property for SecondTINNotice
            /// </summary>
            public const string SecondTINNotice = "SECONDTIN";
    
            /// <summary>
            /// Property for TaxWithholdingState
            /// </summary>
            public const string TaxWithholdingState = "TAXWHSTTE";
    
        #endregion
	    }

		/// <summary>
        /// Contains list of Vendors Index Constants
        /// </summary>
	    public class Index
        {
            #region Properties
	         
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
	        public const int VendorNumber  = 1;
	        
            /// <summary>
            /// Property Indexer for ShortName 
            /// </summary>
	        public const int ShortName  = 2;
	        
            /// <summary>
            /// Property Indexer for GroupCode 
            /// </summary>
	        public const int GroupCode  = 3;
	        
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
	        public const int Status  = 4;
	        
            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
	        public const int InactiveDate  = 5;
	        
            /// <summary>
            /// Property Indexer for LastMaintainedDate 
            /// </summary>
	        public const int LastMaintainedDate  = 6;
	        
            /// <summary>
            /// Property Indexer for OnHold 
            /// </summary>
	        public const int OnHold  = 7;
	        
            /// <summary>
            /// Property Indexer for StartDate 
            /// </summary>
	        public const int StartDate  = 8;
	        
            /// <summary>
            /// Property Indexer for ParticipantID 
            /// </summary>
	        public const int ParticipantID  = 9;
	        
            /// <summary>
            /// Property Indexer for VendorName 
            /// </summary>
	        public const int VendorName  = 10;
	        
            /// <summary>
            /// Property Indexer for AddressLine1 
            /// </summary>
	        public const int AddressLine1  = 11;
	        
            /// <summary>
            /// Property Indexer for AddressLine2 
            /// </summary>
	        public const int AddressLine2  = 12;
	        
            /// <summary>
            /// Property Indexer for AddressLine3 
            /// </summary>
	        public const int AddressLine3  = 13;
	        
            /// <summary>
            /// Property Indexer for AddressLine4 
            /// </summary>
	        public const int AddressLine4  = 14;
	        
            /// <summary>
            /// Property Indexer for City 
            /// </summary>
	        public const int City  = 15;
	        
            /// <summary>
            /// Property Indexer for StateOrProvince 
            /// </summary>
	        public const int StateOrProvince  = 16;
	        
            /// <summary>
            /// Property Indexer for ZipOrPostalCode 
            /// </summary>
	        public const int ZipOrPostalCode  = 17;
	        
            /// <summary>
            /// Property Indexer for Country 
            /// </summary>
	        public const int Country  = 18;
	        
            /// <summary>
            /// Property Indexer for ContactName 
            /// </summary>
	        public const int ContactName  = 19;
	        
            /// <summary>
            /// Property Indexer for PhoneNumber 
            /// </summary>
	        public const int PhoneNumber  = 20;
	        
            /// <summary>
            /// Property Indexer for FaxNumber 
            /// </summary>
	        public const int FaxNumber  = 21;
	        
            /// <summary>
            /// Property Indexer for PrimaryRemitToLocation 
            /// </summary>
	        public const int PrimaryRemitToLocation  = 22;
	        
            /// <summary>
            /// Property Indexer for AccountSet 
            /// </summary>
	        public const int AccountSet  = 23;
	        
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
	        public const int CurrencyCode  = 24;
	        
            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
	        public const int RateType  = 25;
	        
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
	        public const int BankCode  = 26;
	        
            /// <summary>
            /// Property Indexer for PrintSeparateChecks 
            /// </summary>
	        public const int PrintSeparateChecks  = 27;
	        
            /// <summary>
            /// Property Indexer for DistributionSet 
            /// </summary>
	        public const int DistributionSet  = 28;
	        
            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
	        public const int DistributionCode  = 29;
	        
            /// <summary>
            /// Property Indexer for GOrLAccount 
            /// </summary>
	        public const int GLAccount  = 30;
	        
            /// <summary>
            /// Property Indexer for Terms 
            /// </summary>
	        public const int Terms  = 31;
	     
            /// <summary>
            /// Property Indexer for DUPINVCCD 
            /// </summary>
	        public const int DUPINVCCD  = 32;
	        
            /// <summary>
            /// Property Indexer for DuplicateAmountCode 
            /// </summary>
	        public const int DuplicateAmountCode  = 33;
	        
            /// <summary>
            /// Property Indexer for DuplicateDateCode 
            /// </summary>
	        public const int DuplicateDateCode  = 34;
	        
            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
	        public const int TaxGroup  = 35;
	        
            /// <summary>
            /// Property Indexer for TaxClassCode1 
            /// </summary>
	        public const int TaxClassCode1  = 36;
	        
            /// <summary>
            /// Property Indexer for TaxClassCode2 
            /// </summary>
	        public const int TaxClassCode2  = 37;
	        
            /// <summary>
            /// Property Indexer for TaxClassCode3 
            /// </summary>
	        public const int TaxClassCode3  = 38;
	        
            /// <summary>
            /// Property Indexer for TaxClassCode4 
            /// </summary>
	        public const int TaxClassCode4  = 39;
	        
            /// <summary>
            /// Property Indexer for TaxClassCode5 
            /// </summary>
	        public const int TaxClassCode5  = 40;
	        
            /// <summary>
            /// Property Indexer for TaxReportingType 
            /// </summary>
	        public const int TaxReportingType  = 41;
	     
            /// <summary>
            /// Property Indexer for SUBJTOWTHH 
            /// </summary>
	        public const int SUBJTOWTHH  = 42;
	        
            /// <summary>
            /// Property Indexer for CprsTaxNumber 
            /// </summary>
            public const int CprsTaxNumber = 43;
	        
            /// <summary>
            /// Property Indexer for TaxType 
            /// </summary>
	        public const int TaxType  = 44;
	        
            /// <summary>
            /// Property Indexer for TAXNOTE2SW 
            /// </summary>
	        public const int TAXNOTE2SW  = 45;
	        
            /// <summary>
            /// Property Indexer for Num1099OrCPRSCode 
            /// </summary>
            public const int CprsCode = 46;
	        
            /// <summary>
            /// Property Indexer for CreditLimit 
            /// </summary>
	        public const int CreditLimit  = 47;
	        
            /// <summary>
            /// Property Indexer for BalanceDueinVendorCurrency 
            /// </summary>
	        public const int BalanceDueinVendorCurrency  = 48;
	        
            /// <summary>
            /// Property Indexer for BalanceDueinFuncCurrency 
            /// </summary>
            public const int BalanceDueinFuncCurrency = 49;
	        
            /// <summary>
            /// Property Indexer for TotalPrepaidInvoiceVendCurr 
            /// </summary>
            public const int TotalPrepaidInvoiceVendCurrency = 50;
	        
            /// <summary>
            /// Property Indexer for TotalPrepaidInvoiceFuncCurr 
            /// </summary>
            public const int TotalPrepaidInvoiceFunctionCurrency = 51;
	        
            /// <summary>
            /// Property Indexer for DateofLastRevaluation 
            /// </summary>
	        public const int DateofLastRevaluation  = 52;
	        
            /// <summary>
            /// Property Indexer for LastRevaluationBalance 
            /// </summary>
	        public const int LastRevaluationBalance  = 53;
	        
            /// <summary>
            /// Property Indexer for NumberofOpenInvoices 
            /// </summary>
	        public const int NumberofOpenInvoices  = 54;
	        
            /// <summary>
            /// Property Indexer for NumberofPrepaidInvoices 
            /// </summary>
	        public const int NumberofPrepaidInvoices  = 55;
	        
            /// <summary>
            /// Property Indexer for NumberofPaidInvoices 
            /// </summary>
	        public const int NumberofPaidInvoices  = 56;
	        
            /// <summary>
            /// Property Indexer for NumberofDaystoPay 
            /// </summary>
	        public const int NumberofDaystoPay  = 57;
	        
            /// <summary>
            /// Property Indexer for DateofLargestInvoice 
            /// </summary>
	        public const int DateofLargestInvoice  = 58;
	        
            /// <summary>
            /// Property Indexer for DateofHighestBalance 
            /// </summary>
	        public const int DateofHighestBalance  = 59;
	        
            /// <summary>
            /// Property Indexer for DateofLargestInvoiceLastYr 
            /// </summary>
	        public const int DateofLargestInvoiceLastYr  = 60;
	        
            /// <summary>
            /// Property Indexer for DateofHighestBalanceLastYr 
            /// </summary>
	        public const int DateofHighestBalanceLastYr  = 61;
	        
            /// <summary>
            /// Property Indexer for DateofLastActivity 
            /// </summary>
	        public const int DateofLastActivity  = 62;
	        
            /// <summary>
            /// Property Indexer for DateofLastInvoice 
            /// </summary>
	        public const int DateofLastInvoice  = 63;
	        
            /// <summary>
            /// Property Indexer for DateofLastCreditNote 
            /// </summary>
	        public const int DateofLastCreditNote  = 64;
	        
            /// <summary>
            /// Property Indexer for DateofLastDebitNote 
            /// </summary>
	        public const int DateofLastDebitNote  = 65;
	        
            /// <summary>
            /// Property Indexer for DateofLastPayment 
            /// </summary>
	        public const int DateofLastPayment  = 66;
	        
            /// <summary>
            /// Property Indexer for DateofLastDiscount 
            /// </summary>
	        public const int DateofLastDiscount  = 67;
	        
            /// <summary>
            /// Property Indexer for DateofLastAdjustment 
            /// </summary>
	        public const int DateofLastAdjustment  = 68;
	        
            /// <summary>
            /// Property Indexer for NumberofLargestInvoice 
            /// </summary>
	        public const int NumberofLargestInvoice  = 69;
	        
            /// <summary>
            /// Property Indexer for NumberofLargestInvoiceLastY 
            /// </summary>
	        public const int NumberofLargestInvoiceLastY  = 70;
	        
            /// <summary>
            /// Property Indexer for LargestInvoiceVendCurr 
            /// </summary>
            public const int LargestInvoiceVendCurrency = 71;
	        
            /// <summary>
            /// Property Indexer for HighestBalanceVendCurr 
            /// </summary>
            public const int HighestBalanceVendCurrency = 72;
	     
            /// <summary>
            /// Property Indexer for AMTWTHTCUR 
            /// </summary>
	        public const int AMTWTHTCUR  = 73;
	         
            /// <summary>
            /// Property Indexer for LargInvLastYrVendCurr 
            /// </summary>
            public const int LargestInvLastYrVendCurrency = 74;
	        
            /// <summary>
            /// Property Indexer for HighBalLastYrVendCurr 
            /// </summary>
            public const int HighBalLastYrVendCurrency = 75;
	     
            /// <summary>
            /// Property Indexer for AMTWTHLYTC 
            /// </summary>
	        public const int AMTWTHLYTC  = 76;
	        
            /// <summary>
            /// Property Indexer for LastInvoiceAmtVendCurr 
            /// </summary>
            public const int LastInvoiceAmtVendCurrency = 77;
	        
            /// <summary>
            /// Property Indexer for LastCrNoteAmtVendCurr 
            /// </summary>
            public const int LastCrNoteAmtVendCurrency = 78;
	        
            /// <summary>
            /// Property Indexer for LastDrNoteAmtVendCurr 
            /// </summary>
            public const int LastDrNoteAmtVendCurrency = 79;
	        
            /// <summary>
            /// Property Indexer for LastPaymentVendCurr 
            /// </summary>
            public const int LastPaymentVendCurrency = 80;
	        
            /// <summary>
            /// Property Indexer for LastDiscountAmtVendCurr 
            /// </summary>
            public const int LastDiscountAmtVendCurrency = 81;
	        
            /// <summary>
            /// Property Indexer for LastAdjAmtVendCurr 
            /// </summary>
            public const int LastAdjAmtVendCurrency = 82;
	        
            /// <summary>
            /// Property Indexer for LargestInvoiceFuncCurr 
            /// </summary>
            public const int LargestInvoiceFunctionCurrency = 83;
	        
            /// <summary>
            /// Property Indexer for HighestBalanceFuncCurr 
            /// </summary>
            public const int HighestBalanceFunctionCurrency = 84;
	     
            /// <summary>
            /// Property Indexer for AMTWTHHCUR 
            /// </summary>
	        public const int AMTWTHHCUR  = 85;
	        
            /// <summary>
            /// Property Indexer for LargInvLastYrFuncCurr 
            /// </summary>
            public const int LargestInvestLastYearFunctionCurrency = 86;
	        
            /// <summary>
            /// Property Indexer for HighBalLastYrFuncCurr 
            /// </summary>
            public const int HighBalLastYearFunctionCurrency = 87;
	     
            /// <summary>
            /// Property Indexer for AMTWTHLYHC 
            /// </summary>
	        public const int AMTWTHLYHC  = 88;
	        
            /// <summary>
            /// Property Indexer for LastInvoiceAmtFuncCurr 
            /// </summary>
            public const int LastInvoiceAmtFunctionCurrency = 89;
	        
            /// <summary>
            /// Property Indexer for LastCrNoteAmtFuncCurr 
            /// </summary>
            public const int LastCrNoteAmtFunctionCurrency = 90;
	        
            /// <summary>
            /// Property Indexer for LastDrNoteAmtFuncCurr 
            /// </summary>
            public const int LastDrNoteAmtFunctionCurrency = 91;
	        
            /// <summary>
            /// Property Indexer for LastPaymentFuncCurr 
            /// </summary>
            public const int LastPaymentFunctionCurrency = 92;
	        
            /// <summary>
            /// Property Indexer for LastDiscountAmtFuncCurr 
            /// </summary>
            public const int LastDiscountAmtFunctionCurrency = 93;
	        
            /// <summary>
            /// Property Indexer for LastAdjAmtFuncCurr 
            /// </summary>
            public const int LastAdjAmtFunctionCurrency = 94;
	        
            /// <summary>
            /// Property Indexer for PaymentCode 
            /// </summary>
	        public const int PaymentCode  = 103;
	        
            /// <summary>
            /// Property Indexer for TaxRegistrationCode1 
            /// </summary>
	        public const int TaxRegistrationCode1  = 104;
	        
            /// <summary>
            /// Property Indexer for TaxRegistrationCode2 
            /// </summary>
	        public const int TaxRegistrationCode2  = 105;
	        
            /// <summary>
            /// Property Indexer for TaxRegistrationCode3 
            /// </summary>
	        public const int TaxRegistrationCode3  = 106;
	        
            /// <summary>
            /// Property Indexer for TaxRegistrationCode4 
            /// </summary>
	        public const int TaxRegistrationCode4  = 107;
	        
            /// <summary>
            /// Property Indexer for TaxRegistrationCode5 
            /// </summary>
	        public const int TaxRegistrationCode5  = 108;
	        
            /// <summary>
            /// Property Indexer for DistributionType 
            /// </summary>
	        public const int DistributionType  = 109;
	        
            /// <summary>
            /// Property Indexer for CheckLanguage 
            /// </summary>
	        public const int CheckLanguage  = 110;
	        
            /// <summary>
            /// Property Indexer for AverageDaystoPay 
            /// </summary>
	        public const int AverageDaystoPay  = 111;
	     
            /// <summary>
            /// Property Indexer for AVGPAYMENT 
            /// </summary>
	        public const int AVGPAYMENT  = 112;
	       
            /// <summary>
            /// Property Indexer for TotalInvoicesPaidFuncCurr 
            /// </summary>
            public const int TotalInvoicesPaidFunctionCurrency = 113;
	        
            /// <summary>
            /// Property Indexer for TotalInvoicesPaidVendCurr 
            /// </summary>
            public const int TotalInvoicesPaidVendorCurrency = 114;
	        
            /// <summary>
            /// Property Indexer for TotalNumberofPayments 
            /// </summary>
	        public const int TotalNumberofPayments  = 115;
	        
            /// <summary>
            /// Property Indexer for TaxIncluded1 
            /// </summary>
	        public const int TaxIncluded1  = 116;
	        
            /// <summary>
            /// Property Indexer for TaxIncluded2 
            /// </summary>
	        public const int TaxIncluded2  = 117;
	        
            /// <summary>
            /// Property Indexer for TaxIncluded3 
            /// </summary>
	        public const int TaxIncluded3  = 118;
	        
            /// <summary>
            /// Property Indexer for TaxIncluded4 
            /// </summary>
	        public const int TaxIncluded4  = 119;
	        
            /// <summary>
            /// Property Indexer for TaxIncluded5 
            /// </summary>
	        public const int TaxIncluded5  = 120;
	        
            /// <summary>
            /// Property Indexer for ContactsEmail 
            /// </summary>
	        public const int ContactsEmail  = 121;
	        
            /// <summary>
            /// Property Indexer for Email 
            /// </summary>
	        public const int Email  = 122;
	        
            /// <summary>
            /// Property Indexer for WebSite 
            /// </summary>
	        public const int WebSite  = 123;
	        
            /// <summary>
            /// Property Indexer for ContactsPhone 
            /// </summary>
	        public const int ContactsPhone  = 124;
	        
            /// <summary>
            /// Property Indexer for ContactsFax 
            /// </summary>
	        public const int ContactsFax  = 125;
	        
            /// <summary>
            /// Property Indexer for DeliveryMethod 
            /// </summary>
	        public const int DeliveryMethod  = 126;
	        
            /// <summary>
            /// Property Indexer for PercentRetained 
            /// </summary>
	        public const int PercentRetained  = 127;
	        
            /// <summary>
            /// Property Indexer for DaysRetained 
            /// </summary>
	        public const int DaysRetained  = 128;
	        
            /// <summary>
            /// Property Indexer for RetainageTermsCode 
            /// </summary>
	        public const int RetainageTermsCode  = 129;
	        
            /// <summary>
            /// Property Indexer for AmountRetainedVendCurr 
            /// </summary>
	        public const int AmountRetainedVendCurr  = 130;
	        
            /// <summary>
            /// Property Indexer for AmountRetainedFuncCurr 
            /// </summary>
	        public const int AmountRetainedFuncCurr  = 131;
	        
            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
	        public const int OptionalFields  = 132;
	        
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
	        public const int ProcessCommandCode  = 133;
	        
            /// <summary>
            /// Property Indexer for NextClientUniqueID 
            /// </summary>
	        public const int NextClientUniqueID  = 134;
	        
            /// <summary>
            /// Property Indexer for VendorLegalName 
            /// </summary>
            public const int VendorLegalName = 135;
	        
            /// <summary>
            /// Property Indexer for Zero1099AmountWarning 
            /// </summary>
	        public const int Zero1099AmountWarning  = 136;
	        
            /// <summary>
            /// Property Indexer for CustomerNumber 
            /// </summary>
	        public const int CustomerNumber  = 137;
	        
            /// <summary>
            /// Property Indexer for SuppressIntegration 
            /// </summary>
	        public const int SuppressIntegration  = 138;
	        
            /// <summary>
            /// Property Indexer for AOrPVersion 
            /// </summary>
            public const int ApVersion  = 139;
	        
            /// <summary>
            /// Property Indexer for Database 
            /// </summary>
	        public const int Database  = 140;
	        
            /// <summary>
            /// Property Indexer for Mode 
            /// </summary>
	        public const int Mode  = 141;

            ///// <summary>
            ///// Property Indexer for BalanceDueinFunctionCurrency. This is used only for Export / Import.
            ///// </summary>
            //public const int BalanceDueinFunctionCurrency = 142;
            
            /// <summary>
            /// Property Indexer for BusinessRegistrationNumber
            /// </summary>
            public const int BusinessRegistrationNumber = 142;

            /// <summary>
            /// Property Indexer for FirstName
            /// </summary>
            public const int FirstName = 143;

            /// <summary>
            /// Property Indexer for LastName
            /// </summary>
            public const int LastName = 144;

            /// <summary>
            /// Property Indexer for FATCA
            /// </summary>
            public const int FATCA = 145;

            /// <summary>
            /// Property Indexer for SecondTINNotice
            /// </summary>
            public const int SecondTINNotice = 146;

            /// <summary>
            /// Property Indexer for TaxWithholdingState
            /// </summary>
            public const int TaxWithholdingState = 147;

        #endregion
	    }
	}
}
	