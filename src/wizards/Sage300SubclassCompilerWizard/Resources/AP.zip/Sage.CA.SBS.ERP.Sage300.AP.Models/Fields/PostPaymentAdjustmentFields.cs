// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PostPaymentsandAdjustments Constants 
    /// </summary>
    public partial class PostPaymentAdjustment
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0040";

        /// <summary>
        /// Contains list of PostPaymentsandAdjustments Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "TYPEBTCH";
            /// <summary>
            /// Property for PostAllBatches 
            /// </summary>
            public const string PostAllBatches = "ALLBTCHSW";
            /// <summary>
            /// Property for PostBatchFrom 
            /// </summary>
            public const string PostBatchFrom = "BATCHIDFR";
            /// <summary>
            /// Property for PostBatchTo 
            /// </summary>
            public const string PostBatchTo = "BATCHIDTO";

            #endregion
        }


        /// <summary>
        /// Contains list of PostPaymentsandAdjustments Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;
            /// <summary>
            /// Property Indexer for PostAllBatches 
            /// </summary>
            public const int PostAllBatches = 2;
            /// <summary>
            /// Property Indexer for PostBatchFrom 
            /// </summary>
            public const int PostBatchFrom = 3;
            /// <summary>
            /// Property Indexer for PostBatchTo 
            /// </summary>
            public const int PostBatchTo = 4;

            #endregion
        }


    }
}
