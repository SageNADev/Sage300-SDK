/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of PostedPayments Constants 
    /// </summary>
    public partial class PostedPayment
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0029";

        /// <summary>
        /// Contains list of PostedPayments Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "IDBANK";

            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";

            /// <summary>
            /// Property for CheckNumber 
            /// </summary>
            public const string CheckNumber = "IDRMIT";

            /// <summary>
            /// Property for CheckSerialNumber 
            /// </summary>
            public const string CheckSerialNumber = "LONGSERIAL";

            /// <summary>
            /// Property for CheckDate 
            /// </summary>
            public const string CheckDate = "DATERMIT";

            /// <summary>
            /// Property for BatchDate 
            /// </summary>
            public const string BatchDate = "DATEBATCH";

            /// <summary>
            /// Property for CheckAmountVendorCurrency 
            /// </summary>
            public const string CheckAmountVendorCurrency = "AMTRMITTC";

            /// <summary>
            /// Property for PaymentAmount 
            /// </summary>
            public const string PaymentAmount = "AMTPAYM";

            /// <summary>
            /// Property for DiscountAmount 
            /// </summary>
            public const string DiscountAmount = "AMTDISC";

            /// <summary>
            /// Property for PaymentCode 
            /// </summary>
            public const string PaymentCode = "PAYMCODE";

            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CODECURN";

            /// <summary>
            /// Property for BankRateType 
            /// </summary>
            public const string BankRateType = "IDRATETYPE";

            /// <summary>
            /// Property for BankExchangeRate 
            /// </summary>
            public const string BankExchangeRate = "RATEEXCHHC";

            /// <summary>
            /// Property for BankRateOverridden 
            /// </summary>
            public const string BankRateOverridden = "SWOVRDRATE";

            /// <summary>
            /// Property for ReasonforReversal 
            /// </summary>
            public const string ReasonforReversal = "TEXTRETRN";

            /// <summary>
            /// Property for AmountofRoundingError 
            /// </summary>
            public const string AmountofRoundingError = "AMTROUNDER";

            /// <summary>
            /// Property for BankRateDate 
            /// </summary>
            public const string BankRateDate = "DATERATE";

            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "CNTFISCYR";

            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "CNTFISCPER";

            /// <summary>
            /// Property for RemitTo 
            /// </summary>
            public const string RemitTo = "TEXTPAYOR";

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";

            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTITEM";

            /// <summary>
            /// Property for CheckCleared 
            /// </summary>
            public const string CheckCleared = "SWCHKCLRD";

            /// <summary>
            /// Property for CheckAmountFuncCurr 
            /// </summary>
            public const string CheckAmountFunctionalCurrency = "AMTRMITHC";

            /// <summary>
            /// Property for AmountAdjusted 
            /// </summary>
            public const string AmountAdjusted = "AMTADJ";

            /// <summary>
            /// Property for DateCleared 
            /// </summary>
            public const string DateCleared = "DATECLRD";

            /// <summary>
            /// Property for DateReversed 
            /// </summary>
            public const string DateReversed = "DATERVRSD";

            /// <summary>
            /// Property for DocumentType 
            /// </summary>
            public const string DocumentType = "TRXTYPETXT";

            /// <summary>
            /// Property for DocumentNo 
            /// </summary>
            public const string DocumentNumber = "IDINVC";

            /// <summary>
            /// Property for RateOperator 
            /// </summary>
            public const string RateOperator = "RATEOP";

            /// <summary>
            /// Property for PaymentType 
            /// </summary>
            public const string PaymentType = "PAYMTYPE";

            /// <summary>
            /// Property for ClientUniqueID 
            /// </summary>
            public const string ClientUniqueID = "CUID";

            /// <summary>
            /// Property for DrillDownApplicationSource 
            /// </summary>
            public const string DrillDownApplicationSource = "DRILLAPP";

            /// <summary>
            /// Property for DrillDownType 
            /// </summary>
            public const string DrillDownType = "DRILLTYPE";

            /// <summary>
            /// Property for DrillDownLinkNumber 
            /// </summary>
            public const string DrillDownLinkNumber = "DRILLDWNLK";

            /// <summary>
            /// Property for GLAccount
            /// </summary>
            public const string GLAccount = "IDACCT";

            /// <summary>
            /// Property for MiscPaymentFlag 
            /// </summary>
            public const string MiscPaymentFlag = "SWNONRCVBL";

            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelated = "SWJOB";

            /// <summary>
            /// Property for InvoiceNumber 
            /// </summary>
            public const string InvoiceNumber = "IDINVCMTCH";

            /// <summary>
            /// Property for CalculateTaxAmountControl 
            /// </summary>
            public const string CalculateTaxAmountControl = "SWTXAMTCTL";

            /// <summary>
            /// Property for CalculateTaxBaseControl 
            /// </summary>
            public const string CalculateTaxBaseControl = "SWTXBSECTL";

            /// <summary>
            /// Property for TaxGroup 
            /// </summary>
            public const string TaxGroup = "CODETAXGRP";

            /// <summary>
            /// Property for TaxAuthority1 
            /// </summary>
            public const string TaxAuthority1 = "CODETAX1";

            /// <summary>
            /// Property for TaxAuthority2 
            /// </summary>
            public const string TaxAuthority2 = "CODETAX2";

            /// <summary>
            /// Property for TaxAuthority3 
            /// </summary>
            public const string TaxAuthority3 = "CODETAX3";

            /// <summary>
            /// Property for TaxAuthority4 
            /// </summary>
            public const string TaxAuthority4 = "CODETAX4";

            /// <summary>
            /// Property for TaxAuthority5 
            /// </summary>
            public const string TaxAuthority5 = "CODETAX5";

            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxBase1 
            /// </summary>
            public const string TaxBase1 = "TXBSE1TC";

            /// <summary>
            /// Property for TaxBase2 
            /// </summary>
            public const string TaxBase2 = "TXBSE2TC";

            /// <summary>
            /// Property for TaxBase3 
            /// </summary>
            public const string TaxBase3 = "TXBSE3TC";

            /// <summary>
            /// Property for TaxBase4 
            /// </summary>
            public const string TaxBase4 = "TXBSE4TC";

            /// <summary>
            /// Property for TaxBase5 
            /// </summary>
            public const string TaxBase5 = "TXBSE5TC";

            /// <summary>
            /// Property for TaxAmount1 
            /// </summary>
            public const string TaxAmount1 = "TXAMT1TC";

            /// <summary>
            /// Property for TaxAmount2 
            /// </summary>
            public const string TaxAmount2 = "TXAMT2TC";

            /// <summary>
            /// Property for TaxAmount3 
            /// </summary>
            public const string TaxAmount3 = "TXAMT3TC";

            /// <summary>
            /// Property for TaxAmount4 
            /// </summary>
            public const string TaxAmount4 = "TXAMT4TC";

            /// <summary>
            /// Property for TaxAmount5 
            /// </summary>
            public const string TaxAmount5 = "TXAMT5TC";

            /// <summary>
            /// Property for TaxTotal 
            /// </summary>
            public const string TaxTotal = "TXTOTTC";

            /// <summary>
            /// Property for DistAmountNetofTaxes 
            /// </summary>
            public const string DistAmountNetofTaxes = "AMTNETTC";

            /// <summary>
            /// Property for TaxAllocatedTotal 
            /// </summary>
            public const string TaxAllocatedTotal = "TXALLTC";

            /// <summary>
            /// Property for TaxExpensedTotal 
            /// </summary>
            public const string TaxExpensedTotal = "TXEXPTC";

            /// <summary>
            /// Property for TaxRecoverableTotal 
            /// </summary>
            public const string TaxRecoverableTotal = "TXRECTC";

            /// <summary>
            /// Property for TaxReportingCurrencyCode 
            /// </summary>
            public const string TaxReportingCurrencyCode = "CODECURNRC";

            /// <summary>
            /// Property for TaxReportingCalculateMethod 
            /// </summary>
            public const string TaxReportingCalculateMethod = "SWTXCTLRC";

            /// <summary>
            /// Property for TaxReportingExchangeRate 
            /// </summary>
            public const string TaxReportingExchangeRate = "RATERC";

            /// <summary>
            /// Property for TaxReportingRateType 
            /// </summary>
            public const string TaxReportingRateType = "RATETYPERC";

            /// <summary>
            /// Property for TaxReportingRateDate 
            /// </summary>
            public const string TaxReportingRateDate = "RATEDATERC";

            /// <summary>
            /// Property for TaxReportingRateOperator 
            /// </summary>
            public const string TaxReportingRateOperator = "RATEOPRC";

            /// <summary>
            /// Property for TaxReportingAmount1 
            /// </summary>
            public const string TaxReportingAmount1 = "TXAMT1RC";

            /// <summary>
            /// Property for TaxReportingAmount2 
            /// </summary>
            public const string TaxReportingAmount2 = "TXAMT2RC";

            /// <summary>
            /// Property for TaxReportingAmount3 
            /// </summary>
            public const string TaxReportingAmount3 = "TXAMT3RC";

            /// <summary>
            /// Property for TaxReportingAmount4 
            /// </summary>
            public const string TaxReportingAmount4 = "TXAMT4RC";

            /// <summary>
            /// Property for TaxReportingAmount5 
            /// </summary>
            public const string TaxReportingAmount5 = "TXAMT5RC";

            /// <summary>
            /// Property for TaxReportingTotal 
            /// </summary>
            public const string TaxReportingTotal = "TXTOTRC";

            /// <summary>
            /// Property for TaxReportingAllocatedTotal 
            /// </summary>
            public const string TaxReportingAllocatedTotal = "TXALLRC";

            /// <summary>
            /// Property for TaxReportingExpensedTotal 
            /// </summary>
            public const string TaxReportingExpensedTotal = "TXEXPRC";

            /// <summary>
            /// Property for TaxReportingRecoverableTotal 
            /// </summary>
            public const string TaxReportingRecoverableTotal = "TXRECRC";

            /// <summary>
            /// Property for FuncTaxBase1 
            /// </summary>
            public const string FuncTaxBase1 = "TXBSE1HC";

            /// <summary>
            /// Property for FuncTaxBase2 
            /// </summary>
            public const string FuncTaxBase2 = "TXBSE2HC";

            /// <summary>
            /// Property for FuncTaxBase3 
            /// </summary>
            public const string FuncTaxBase3 = "TXBSE3HC";

            /// <summary>
            /// Property for FuncTaxBase4 
            /// </summary>
            public const string FuncTaxBase4 = "TXBSE4HC";

            /// <summary>
            /// Property for FuncTaxBase5 
            /// </summary>
            public const string FuncTaxBase5 = "TXBSE5HC";

            /// <summary>
            /// Property for FuncTaxAmount1 
            /// </summary>
            public const string FuncTaxAmount1 = "TXAMT1HC";

            /// <summary>
            /// Property for FuncTaxAmount2 
            /// </summary>
            public const string FuncTaxAmount2 = "TXAMT2HC";

            /// <summary>
            /// Property for FuncTaxAmount3 
            /// </summary>
            public const string FuncTaxAmount3 = "TXAMT3HC";

            /// <summary>
            /// Property for FuncTaxAmount4 
            /// </summary>
            public const string FuncTaxAmount4 = "TXAMT4HC";

            /// <summary>
            /// Property for FuncTaxAmount5 
            /// </summary>
            public const string FuncTaxAmount5 = "TXAMT5HC";

            /// <summary>
            /// Property for FuncTaxTotal 
            /// </summary>
            public const string FuncTaxTotal = "TXTOTHC";

            /// <summary>
            /// Property for FuncDistAmountNetofTaxes 
            /// </summary>
            public const string FuncDistAmountNetofTaxes = "AMTNETHC";

            /// <summary>
            /// Property for FuncTaxAllocatedTotal 
            /// </summary>
            public const string FuncTaxAllocatedTotal = "TXALLHC";

            /// <summary>
            /// Property for FuncTaxExpensedTotal 
            /// </summary>
            public const string FuncTaxExpensedTotal = "TXEXPHC";

            /// <summary>
            /// Property for FuncTaxRecoverableTotal 
            /// </summary>
            public const string FuncTaxRecoverableTotal = "TXRECHC";

            /// <summary>
            /// Property for NumberofAdvanceCreditClaims 
            /// </summary>
            public const string NumberofAdvanceCreditClaims = "CNTACC";

            /// <summary>
            /// Property for TotalAdvanceCreditClaim 
            /// </summary>
            public const string TotalAdvanceCreditClaim = "AMTACCTC";

            /// <summary>
            /// Property for FuncTotalAdvanceCreditClaim 
            /// </summary>
            public const string FuncTotalAdvanceCreditClaim = "AMTACCHC";

            /// <summary>
            /// Property for PostingDate 
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for BankRateOverridden
            /// </summary>
            public const string BankRateOverriddenName = "SWOVRDRATE";

            /// <summary>
            /// Property for CheckCleared
            /// </summary>
            public const string CheckClearedName = "SWCHKCLRD";

            /// <summary>
            /// Property for DocumentTypeName
            /// </summary>
            public const string DocumentTypeName = "TRXTYPETXT";

            /// <summary>
            /// Property for PaymentTypeName
            /// </summary>
            public const string PaymentTypeName = "PAYMTYPE";

            /// <summary>
            /// Property for JobRelatedName 
            /// </summary>
            public const string JobRelatedName = "SWJOB";

            /// <summary>
            /// Property for CalculateTaxAmountControlName 
            /// </summary>
            public const string CalculateTaxAmountControlName = "SWTXAMTCTL";

            /// <summary>
            /// Property for CalculateTaxBaseControlName 
            /// </summary>
            public const string CalculateTaxBaseControlName = "SWTXBSECTL";

            /// <summary>
            /// Property for TaxReportingCalculateMethod 
            /// </summary>
            public const string TaxReportingCalculateMethodName = "SWTXCTLRC";
            #endregion
        }


        /// <summary>
        /// Contains list of PostedPayments Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 1;

            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 2;

            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int CheckNumber = 3;

            /// <summary>
            /// Property Indexer for CheckSerialNumber 
            /// </summary>
            public const int CheckSerialNumber = 4;

            /// <summary>
            /// Property Indexer for CheckDate 
            /// </summary>
            public const int CheckDate = 5;

            /// <summary>
            /// Property Indexer for BatchDate 
            /// </summary>
            public const int BatchDate = 7;

            /// <summary>
            /// Property Indexer for CheckAmountVendCurr 
            /// </summary>
            public const int CheckAmountVendCurr = 8;

            /// <summary>
            /// Property Indexer for PaymentAmount 
            /// </summary>
            public const int PaymentAmount = 9;

            /// <summary>
            /// Property Indexer for DiscountAmount 
            /// </summary>
            public const int DiscountAmount = 10;

            /// <summary>
            /// Property Indexer for PaymentCode 
            /// </summary>
            public const int PaymentCode = 11;

            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 12;

            /// <summary>
            /// Property Indexer for BankRateType 
            /// </summary>
            public const int BankRateType = 13;

            /// <summary>
            /// Property Indexer for BankExchangeRate 
            /// </summary>
            public const int BankExchangeRate = 14;

            /// <summary>
            /// Property Indexer for BankRateOverridden 
            /// </summary>
            public const int BankRateOverridden = 15;

            /// <summary>
            /// Property Indexer for ReasonforReversal 
            /// </summary>
            public const int ReasonforReversal = 16;

            /// <summary>
            /// Property Indexer for AmountofRoundingError 
            /// </summary>
            public const int AmountofRoundingError = 19;

            /// <summary>
            /// Property Indexer for BankRateDate 
            /// </summary>
            public const int BankRateDate = 20;

            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 21;

            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 22;

            /// <summary>
            /// Property Indexer for RemitTo 
            /// </summary>
            public const int RemitTo = 23;

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 24;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 25;

            /// <summary>
            /// Property Indexer for CheckCleared 
            /// </summary>
            public const int CheckCleared = 26;

            /// <summary>
            /// Property Indexer for CheckAmountFuncCurr 
            /// </summary>
            public const int CheckAmountFuncCurr = 27;

            /// <summary>
            /// Property Indexer for AmountAdjusted 
            /// </summary>
            public const int AmountAdjusted = 28;

            /// <summary>
            /// Property Indexer for DateCleared 
            /// </summary>
            public const int DateCleared = 29;

            /// <summary>
            /// Property Indexer for DateReversed 
            /// </summary>
            public const int DateReversed = 30;

            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 31;

            /// <summary>
            /// Property Indexer for DocumentNo 
            /// </summary>
            public const int DocumentNo = 32;

            /// <summary>
            /// Property Indexer for RateOperator 
            /// </summary>
            public const int RateOperator = 33;

            /// <summary>
            /// Property Indexer for PaymentType 
            /// </summary>
            public const int PaymentType = 34;

            /// <summary>
            /// Property Indexer for ClientUniqueID 
            /// </summary>
            public const int ClientUniqueID = 39;

            /// <summary>
            /// Property Indexer for DrillDownApplicationSource 
            /// </summary>
            public const int DrillDownApplicationSource = 40;

            /// <summary>
            /// Property Indexer for DrillDownType 
            /// </summary>
            public const int DrillDownType = 41;

            /// <summary>
            /// Property Indexer for DrillDownLinkNumber 
            /// </summary>
            public const int DrillDownLinkNumber = 42;

            /// <summary>
            /// Property Indexer for GLAccount
            /// </summary>
            public const int GLAccount = 43;

            /// <summary>
            /// Property Indexer for MiscPaymentFlag 
            /// </summary>
            public const int MiscPaymentFlag = 44;

            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 45;

            /// <summary>
            /// Property Indexer for InvoiceNumber 
            /// </summary>
            public const int InvoiceNumber = 46;

            /// <summary>
            /// Property Indexer for CalculateTaxAmountControl 
            /// </summary>
            public const int CalculateTaxAmountControl = 47;

            /// <summary>
            /// Property Indexer for CalculateTaxBaseControl 
            /// </summary>
            public const int CalculateTaxBaseControl = 48;

            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroup = 49;

            /// <summary>
            /// Property Indexer for TaxAuthority1 
            /// </summary>
            public const int TaxAuthority1 = 50;

            /// <summary>
            /// Property Indexer for TaxAuthority2 
            /// </summary>
            public const int TaxAuthority2 = 51;

            /// <summary>
            /// Property Indexer for TaxAuthority3 
            /// </summary>
            public const int TaxAuthority3 = 52;

            /// <summary>
            /// Property Indexer for TaxAuthority4 
            /// </summary>
            public const int TaxAuthority4 = 53;

            /// <summary>
            /// Property Indexer for TaxAuthority5 
            /// </summary>
            public const int TaxAuthority5 = 54;

            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 55;

            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 56;

            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 57;

            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 58;

            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 59;

            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 60;

            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 61;

            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 62;

            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 63;

            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 64;

            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 65;

            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 66;

            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 67;

            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 68;

            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 69;

            /// <summary>
            /// Property Indexer for TaxTotal 
            /// </summary>
            public const int TaxTotal = 70;

            /// <summary>
            /// Property Indexer for DistAmountNetofTaxes 
            /// </summary>
            public const int DistAmountNetofTaxes = 71;

            /// <summary>
            /// Property Indexer for TaxAllocatedTotal 
            /// </summary>
            public const int TaxAllocatedTotal = 72;

            /// <summary>
            /// Property Indexer for TaxExpensedTotal 
            /// </summary>
            public const int TaxExpensedTotal = 73;

            /// <summary>
            /// Property Indexer for TaxRecoverableTotal 
            /// </summary>
            public const int TaxRecoverableTotal = 74;

            /// <summary>
            /// Property Indexer for TaxReportingCurrencyCode 
            /// </summary>
            public const int TaxReportingCurrencyCode = 75;

            /// <summary>
            /// Property Indexer for TaxReportingCalculateMethod 
            /// </summary>
            public const int TaxReportingCalculateMethod = 76;

            /// <summary>
            /// Property Indexer for TaxReportingExchangeRate 
            /// </summary>
            public const int TaxReportingExchangeRate = 77;

            /// <summary>
            /// Property Indexer for TaxReportingRateType 
            /// </summary>
            public const int TaxReportingRateType = 78;

            /// <summary>
            /// Property Indexer for TaxReportingRateDate 
            /// </summary>
            public const int TaxReportingRateDate = 79;

            /// <summary>
            /// Property Indexer for TaxReportingRateOperator 
            /// </summary>
            public const int TaxReportingRateOperator = 80;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1 
            /// </summary>
            public const int TaxReportingAmount1 = 81;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2 
            /// </summary>
            public const int TaxReportingAmount2 = 82;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3 
            /// </summary>
            public const int TaxReportingAmount3 = 83;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4 
            /// </summary>
            public const int TaxReportingAmount4 = 84;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5 
            /// </summary>
            public const int TaxReportingAmount5 = 85;

            /// <summary>
            /// Property Indexer for TaxReportingTotal 
            /// </summary>
            public const int TaxReportingTotal = 86;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedTotal 
            /// </summary>
            public const int TaxReportingAllocatedTotal = 87;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedTotal 
            /// </summary>
            public const int TaxReportingExpensedTotal = 88;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableTotal 
            /// </summary>
            public const int TaxReportingRecoverableTotal = 89;

            /// <summary>
            /// Property Indexer for FuncTaxBase1 
            /// </summary>
            public const int FuncTaxBase1 = 90;

            /// <summary>
            /// Property Indexer for FuncTaxBase2 
            /// </summary>
            public const int FuncTaxBase2 = 91;

            /// <summary>
            /// Property Indexer for FuncTaxBase3 
            /// </summary>
            public const int FuncTaxBase3 = 92;

            /// <summary>
            /// Property Indexer for FuncTaxBase4 
            /// </summary>
            public const int FuncTaxBase4 = 93;

            /// <summary>
            /// Property Indexer for FuncTaxBase5 
            /// </summary>
            public const int FuncTaxBase5 = 94;

            /// <summary>
            /// Property Indexer for FuncTaxAmount1 
            /// </summary>
            public const int FuncTaxAmount1 = 95;

            /// <summary>
            /// Property Indexer for FuncTaxAmount2 
            /// </summary>
            public const int FuncTaxAmount2 = 96;

            /// <summary>
            /// Property Indexer for FuncTaxAmount3 
            /// </summary>
            public const int FuncTaxAmount3 = 97;

            /// <summary>
            /// Property Indexer for FuncTaxAmount4 
            /// </summary>
            public const int FuncTaxAmount4 = 98;

            /// <summary>
            /// Property Indexer for FuncTaxAmount5 
            /// </summary>
            public const int FuncTaxAmount5 = 99;

            /// <summary>
            /// Property Indexer for FuncTaxTotal 
            /// </summary>
            public const int FuncTaxTotal = 100;

            /// <summary>
            /// Property Indexer for FuncDistAmountNetofTaxes 
            /// </summary>
            public const int FuncDistAmountNetofTaxes = 101;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedTotal 
            /// </summary>
            public const int FuncTaxAllocatedTotal = 102;

            /// <summary>
            /// Property Indexer for FuncTaxExpensedTotal 
            /// </summary>
            public const int FuncTaxExpensedTotal = 103;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableTotal 
            /// </summary>
            public const int FuncTaxRecoverableTotal = 104;

            /// <summary>
            /// Property Indexer for NumberofAdvanceCreditClaims 
            /// </summary>
            public const int NumberofAdvanceCreditClaims = 105;

            /// <summary>
            /// Property Indexer for TotalAdvanceCreditClaim 
            /// </summary>
            public const int TotalAdvanceCreditClaim = 106;

            /// <summary>
            /// Property Indexer for FuncTotalAdvanceCreditClaim 
            /// </summary>
            public const int FuncTotalAdvanceCreditClaim = 107;

            /// <summary>
            /// Property Indexer for PostingDate 
            /// </summary>
            public const int PostingDate = 108;

            /// <summary>
            /// Property Indexer for BankRateOverridden
            /// </summary>
            public const int BankRateOverriddenName = 15;

            /// <summary>
            /// Property Indexer for CheckCleared
            /// </summary>
            public const int CheckClearedName = 26;

            /// <summary>
            /// Property Indexer for DocumentTypeName
            /// </summary>
            public const int DocumentTypeName = 31;

            /// <summary>
            /// Property Indexer for PaymentTypeName
            /// </summary>
            public const int PaymentTypeName = 34;

            /// <summary>
            /// Property Indexer for JobRelatedName 
            /// </summary>
            public const int JobRelatedName = 45;

            /// <summary>
            /// Property Indexer for CalculateTaxAmountControl 
            /// </summary>
            public const int CalculateTaxAmountControlName = 47;

            /// <summary>
            /// Property Indexer for CalculateTaxBaseControlName 
            /// </summary>
            public const int CalculateTaxBaseControlName = 48;

            /// <summary>
            /// Property Indexer for TaxReportingCalculateMethod 
            /// </summary>
            public const int TaxReportingCalculateMethodName = 76;
            #endregion
        }

        /// <summary>
        /// Class Keys.
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int CheckNumber = 2;

            /// <summary>
            /// Property Indexer for CheckDate 
            /// </summary>
            public const int CheckDate = 4;
        }
    }
}
