// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models

{
    /// <summary>
    /// Contains list of GenerateSystemBatch Constants 
    /// </summary>
	public partial class GenerateSystemBatch 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "AP0056";

        /// <summary>
        /// Contains list of GenerateSystemBatch Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for RequestType 
        /// </summary>
	    public const string RequestType  = "SWREQTYPE";
	            /// <summary>
        /// Property for FileName 
        /// </summary>
	    public const string FileName  = "FILENAME";
	            /// <summary>
        /// Property for BatchDate 
        /// </summary>
	    public const string BatchDate  = "DATEBATCH";
	            /// <summary>
        /// Property for SelectionCriteria 
        /// </summary>
	    public const string SelectionCriteria  = "IDSELECT";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of GenerateSystemBatch Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for RequestType 
        /// </summary>
	    public const int RequestType  = 1;
	             /// <summary>
        /// Property Indexer for FileName 
        /// </summary>
	    public const int FileName  = 2;
	             /// <summary>
        /// Property Indexer for BatchDate 
        /// </summary>
	    public const int BatchDate  = 3;
	             /// <summary>
        /// Property Indexer for SelectionCriteria 
        /// </summary>
	    public const int SelectionCriteria  = 4;
	     
        #endregion
	    }

	
	}
}
	