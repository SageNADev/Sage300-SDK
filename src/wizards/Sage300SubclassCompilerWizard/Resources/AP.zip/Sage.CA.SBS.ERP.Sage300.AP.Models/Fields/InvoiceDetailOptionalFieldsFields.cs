// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.InvoiceEntry;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of InvoiceDetailOptionalFields Constants 
    /// </summary>
    public partial class InvoiceDetailOptionalFields
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0401";

        /// <summary>
        /// Contains list of InvoiceDetailOptionalFields Fields Constants
        /// </summary>
        public class Fields:BaseFields
        {
        }

        /// <summary>
        /// Contains list of InvoiceDetailOptionalFields Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 1;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 2;

            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 3;

            /// <summary>
            /// Property Indexer for OptionalField 
            /// </summary>
            public const int OptionalField = 4;

            /// <summary>
            /// Property Indexer for Value 
            /// </summary>
            public const int Value = 5;

            /// <summary>
            /// Property Indexer for Type 
            /// </summary>
            public const int Type = 6;

            /// <summary>
            /// Property Indexer for Length 
            /// </summary>
            public const int Length = 7;

            /// <summary>
            /// Property Indexer for Decimals 
            /// </summary>
            public const int Decimals = 8;

            /// <summary>
            /// Property Indexer for AllowBlank 
            /// </summary>
            public const int AllowBlank = 9;

            /// <summary>
            /// Property Indexer for Validate 
            /// </summary>
            public const int Validate = 10;

            /// <summary>
            /// Property Indexer for ValueSet 
            /// </summary>
            public const int ValueSet = 11;

            /// <summary>
            /// Property Indexer for TypedValueFieldIndex 
            /// </summary>
            public const int TypedValueFieldIndex = 20;

            /// <summary>
            /// Property Indexer for TextValue 
            /// </summary>
            public const int TextValue = 21;

            /// <summary>
            /// Property Indexer for AmountValue 
            /// </summary>
            public const int AmountValue = 22;

            /// <summary>
            /// Property Indexer for NumberValue 
            /// </summary>
            public const int NumberValue = 23;

            /// <summary>
            /// Property Indexer for IntegerValue 
            /// </summary>
            public const int IntegerValue = 24;

            /// <summary>
            /// Property Indexer for YesOrNoValue 
            /// </summary>
            public const int YesOrNoValue = 25;

            /// <summary>
            /// Property Indexer for DateValue 
            /// </summary>
            public const int DateValue = 26;

            /// <summary>
            /// Property Indexer for TimeValue 
            /// </summary>
            public const int TimeValue = 27;

            /// <summary>
            /// Property Indexer for OptionalFieldDescription 
            /// </summary>
            public const int OptionalFieldDescription = 28;

            /// <summary>
            /// Property Indexer for ValueDescription 
            /// </summary>
            public const int ValueDescription = 29;

            #endregion
        }


    }
}
