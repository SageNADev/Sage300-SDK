// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains Post Invoice Constants 
    /// </summary>
    public partial class PostInvoice
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0039";

        /// <summary>
        /// Post Invoice Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Process All Batches 
            /// </summary>
            public const string ProcessAllBatches = "SWALLBTCH";

            /// <summary>
            /// Property for From Batch 
            /// </summary>
            public const string FromBatch = "BATCHIDFR";

            /// <summary>
            /// Property for To Batch 
            /// </summary>
            public const string ToBatch = "BATCHIDTO";

            #endregion
        }

        /// <summary>
        /// Post Invoice Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Process All Batches 
            /// </summary>
            public const int ProcessAllBatches = 1;

            /// <summary>
            /// Property Indexer for From Batch 
            /// </summary>
            public const int FromBatch = 2;

            /// <summary>
            /// Property Indexer for To Batch 
            /// </summary>
            public const int ToBatch = 3;

            #endregion
        }
    }
}