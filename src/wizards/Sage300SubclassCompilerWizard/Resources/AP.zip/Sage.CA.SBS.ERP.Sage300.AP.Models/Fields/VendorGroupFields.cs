
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of VendorGroups Constants 
    /// </summary>
    public partial class VendorGroup
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0016";

        /// <summary>
        /// Contains list of VendorGroups Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties

            /// <summary>
            /// Property for GroupCode 
            /// </summary>
            public const string GroupCode = "GROUPID";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESCRIPTN";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "ACTIVESW";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string StatusDescription = "ACTIVESW";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "INACTIVEDT";

            /// <summary>
            /// New Property for filtering - InactiveDate
            /// </summary>
            public const string InactiveDateFormated = "INACTIVEDT";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "LSTMNTDATE";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintainedFormated = "LSTMNTDATE";

            /// <summary>
            /// Property for AccountSet 
            /// </summary>
            public const string AccountSet = "ACCTSETID";

            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CURNCODE";

            /// <summary>
            /// Property for RateType 
            /// </summary>
            public const string RateType = "RATETYPEID";

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANKID";

            /// <summary>
            /// Property for PrintSeparateChecks 
            /// </summary>
            public const string PrintSeparateChecks = "PRTSEPCHKS";

             /// <summary>
            /// Property for PrintSeparateChecks 
            /// </summary>
            public const string PrintSeparateChecksDesc = "PRTSEPCHKS";

            /// <summary>
            /// Property for DistributionSet 
            /// </summary>
            public const string DistributionSet = "DISTSETID";

            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "DISTCODE";

            /// <summary>
            /// Property for GeneralLedgerAccountNo 
            /// </summary>
            public const string GeneralLedgerAccountNo = "GLACCTID";

            /// <summary>
            /// Property for Terms 
            /// </summary>
            public const string Terms = "TERMCODE";

            /// <summary>
            /// Property for DUPLINVC 
            /// </summary>
            public const string DUPLINVC = "DUPLINVC";

            /// <summary>
            /// Property for DuplicateAmountCode 
            /// </summary>
            public const string DuplicateAmountCode = "DUPLAMT";

            /// <summary>
            /// Property for DuplicateAmountCode 
            /// </summary>
            public const string DuplicateAmountCodeDesc = "DUPLAMT";

            /// <summary>
            /// Property for DuplicateDateCode 
            /// </summary>
            public const string DuplicateDateCode = "DUPLDATE";

            /// <summary>
            /// Property for DuplicateDateCode 
            /// </summary>
            public const string DuplicateDateCodeDesc = "DUPLDATE";

            /// <summary>
            /// Property for TaxGroup 
            /// </summary>
            public const string TaxGroup = "TAXGRP";

            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxReportingType 
            /// </summary>
            public const string TaxReportingType = "TAXRPTSW";

            /// <summary>
            /// Property for TaxReportingType 
            /// </summary>
            public const string TaxReportingTypeDesc = "TAXRPTSW";

            /// <summary>
            /// Property for SUBJWTHHSW 
            /// </summary>
            public const string SUBJWTHHSW = "SUBJWTHHSW";

            /// <summary>
            /// Property for Num1099OrCPRSCode 
            /// </summary>
            public const string Num1099OrCPRSCode = "CLASSID";

            /// <summary>
            /// Property for PaymentCode 
            /// </summary>
            public const string PaymentCode = "PAYMCODE";

            /// <summary>
            /// Property for DistributionType 
            /// </summary>
            public const string DistributionType = "SWDISTBY";

            /// <summary>
            /// Property for DistributionType 
            /// </summary>
            public const string DistributionTypeDesc = "SWDISTBY";

            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded1 = "SWTXINC1";

            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded1Desc = "SWTXINC1";

            /// <summary>
            /// Property for TaxIncluded2 
            /// </summary>
            public const string TaxIncluded2 = "SWTXINC2";

            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded2Desc = "SWTXINC2";

            /// <summary>
            /// Property for TaxIncluded3 
            /// </summary>
            public const string TaxIncluded3 = "SWTXINC3";

            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded3Desc = "SWTXINC3";

            /// <summary>
            /// Property for TaxIncluded4 
            /// </summary>
            public const string TaxIncluded4 = "SWTXINC4";

            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded4Desc = "SWTXINC4";

            /// <summary>
            /// Property for TaxIncluded5 
            /// </summary>
            public const string TaxIncluded5 = "SWTXINC5";

            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded5Desc = "SWTXINC5";

            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCodeDesc = "PROCESSCMD";

            #endregion
        }


        /// <summary>
        /// Contains list of VendorGroups Index Constants
        /// </summary>
        public class Index
        {

            #region Properties

            /// <summary>
            /// Property Indexer for GroupCode 
            /// </summary>
            public const int GroupCode = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;

            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 4;

            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 5;

            /// <summary>
            /// Property Indexer for AccountSet 
            /// </summary>
            public const int AccountSet = 6;

            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 7;

            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 8;

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 9;

            /// <summary>
            /// Property Indexer for PrintSeparateChecks 
            /// </summary>
            public const int PrintSeparateChecks = 10;

            /// <summary>
            /// Property Indexer for DistributionSet 
            /// </summary>
            public const int DistributionSet = 11;

            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 12;

            /// <summary>
            /// Property Indexer for GeneralLedgerAccountNo 
            /// </summary>
            public const int GeneralLedgerAccountNo = 13;

            /// <summary>
            /// Property Indexer for Terms 
            /// </summary>
            public const int Terms = 14;
       
            /// <summary>
            /// Property Indexer for DUPLINVC 
            /// </summary>
            public const int DUPLINVC = 15;

            /// <summary>
            /// Property Indexer for DuplicateAmountCode 
            /// </summary>
            public const int DuplicateAmountCode = 16;

            /// <summary>
            /// Property Indexer for DuplicateDateCode 
            /// </summary>
            public const int DuplicateDateCode = 17;

            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroup = 18;

            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 19;

            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 20;

            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 21;

            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 22;

            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 23;

            /// <summary>
            /// Property Indexer for TaxReportingType 
            /// </summary>
            public const int TaxReportingType = 24;

            /// <summary>
            /// Property Indexer for SUBJWTHHSW 
            /// </summary>
            public const int SUBJWTHHSW = 25;

            /// <summary>
            /// Property Indexer for Num1099OrCPRSCode 
            /// </summary>
            public const int Num1099OrCPRSCode = 26;

            /// <summary>
            /// Property Indexer for PaymentCode 
            /// </summary>
            public const int PaymentCode = 35;

            /// <summary>
            /// Property Indexer for DistributionType 
            /// </summary>
            public const int DistributionType = 36;

            /// <summary>
            /// Property Indexer for TaxIncluded1 
            /// </summary>
            public const int TaxIncluded1 = 37;

            /// <summary>
            /// Property Indexer for TaxIncluded2 
            /// </summary>
            public const int TaxIncluded2 = 38;

            /// <summary>
            /// Property Indexer for TaxIncluded3 
            /// </summary>
            public const int TaxIncluded3 = 39;

            /// <summary>
            /// Property Indexer for TaxIncluded4 
            /// </summary>
            public const int TaxIncluded4 = 40;

            /// <summary>
            /// Property Indexer for TaxIncluded5 
            /// </summary>
            public const int TaxIncluded5 = 41;

            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 42;

            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 43;

            #endregion
        }
    }
}
