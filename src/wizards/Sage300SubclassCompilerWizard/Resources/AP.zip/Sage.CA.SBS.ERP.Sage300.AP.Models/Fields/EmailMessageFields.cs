// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of E-mail Message Constants 
    /// </summary>
    public partial class EmailMessage
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0120";

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0120";

        /// <summary>
        /// Contains list of E-mail Message Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for MessageType 
            /// </summary>
            public const string MessageType = "MSGTYPE";

            /// <summary>
            /// Property for MessageType 
            /// </summary>
            public const string MessageTypeDescription = "MSGTYPE";

            /// <summary>
            /// Property for MessageID 
            /// </summary>
            public const string MessageID = "MSGID";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "ACTIVESW";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string StatusDescription = "ACTIVESW";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "DATEINAC";

            /// <summary>
            /// New Property for filtering - InactiveDate
            /// </summary>
            public const string InactiveDateTime = InactiveDate;

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DTELSTMNTN";

            /// <summary>
            /// New Property for filtering - InactiveDate
            /// </summary>
            public const string DateTimeLastMaintained = DateLastMaintained;

            /// <summary>
            /// Property for EmailSubject 
            /// </summary>
            public const string EmailSubject = "SUBJECT";

            /// <summary>
            /// Property for EmailBody1 
            /// </summary>
            public const string EmailBody1 = "BODY1";

            /// <summary>
            /// Property for EmailBody2 
            /// </summary>
            public const string EmailBody2 = "BODY2";

            /// <summary>
            /// Property for EmailBody3 
            /// </summary>
            public const string EmailBody3 = "BODY3";

            /// <summary>
            /// Property for EmailBody4 
            /// </summary>
            public const string EmailBody4 = "BODY4";

            /// <summary>
            /// Property for EmailBody5 
            /// </summary>
            public const string EmailBody5 = "BODY5";

            /// <summary>
            /// Property for EmailBody6 
            /// </summary>
            public const string EmailBody6 = "BODY6";

            /// <summary>
            /// Property for EmailBody7 
            /// </summary>
            public const string EmailBody7 = "BODY7";

            /// <summary>
            /// Property for EmailBody8 
            /// </summary>
            public const string EmailBody8 = "BODY8";

            /// <summary>
            /// Property for EmailBody9 
            /// </summary>
            public const string EmailBody9 = "BODY9";

            /// <summary>
            /// Property for EmailBody10 
            /// </summary>
            public const string EmailBody10 = "BODY10";

            /// <summary>
            /// Property for EmailBody 
            /// </summary>
            public const string EmailBody = "BODY";

            #endregion
        }

        /// <summary>
        /// Contains list of E-mail Message Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for MessageType 
            /// </summary>
            public const int MessageType = 1;

            /// <summary>
            /// Property Indexer for MessageID 
            /// </summary>
            public const int MessageID = 2;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 4;

            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 5;

            /// <summary>
            /// Setting date filter property for InactiveDate 
            /// </summary>
            public const int InactiveDateTime = InactiveDate;

            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 6;

            /// <summary>
            /// Setting date filter property for InactiveDate 
            /// </summary>
            public const int DateTimeLastMaintained = DateLastMaintained;

            /// <summary>
            /// Property Indexer for EmailSubject 
            /// </summary>
            public const int EmailSubject = 7;

            /// <summary>
            /// Property Indexer for EmailBody1 
            /// </summary>
            public const int EmailBody1 = 8;

            /// <summary>
            /// Property Indexer for EmailBody2 
            /// </summary>
            public const int EmailBody2 = 9;

            /// <summary>
            /// Property Indexer for EmailBody3 
            /// </summary>
            public const int EmailBody3 = 10;

            /// <summary>
            /// Property Indexer for EmailBody4 
            /// </summary>
            public const int EmailBody4 = 11;

            /// <summary>
            /// Property Indexer for EmailBody5 
            /// </summary>
            public const int EmailBody5 = 12;

            /// <summary>
            /// Property Indexer for EmailBody6 
            /// </summary>
            public const int EmailBody6 = 13;

            /// <summary>
            /// Property Indexer for EmailBody7 
            /// </summary>
            public const int EmailBody7 = 14;

            /// <summary>
            /// Property Indexer for EmailBody8 
            /// </summary>
            public const int EmailBody8 = 15;

            /// <summary>
            /// Property Indexer for EmailBody9 
            /// </summary>
            public const int EmailBody9 = 16;

            /// <summary>
            /// Property Indexer for EmailBody10 
            /// </summary>
            public const int EmailBody10 = 17;

            /// <summary>
            /// Property Indexer for EmailBody 
            /// </summary>
            public const int EmailBody = 30;

            #endregion
        }
    }
}
