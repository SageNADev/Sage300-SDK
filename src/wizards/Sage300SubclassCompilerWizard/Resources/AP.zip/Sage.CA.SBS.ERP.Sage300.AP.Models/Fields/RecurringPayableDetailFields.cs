// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of Recurring Payable Details Constants.
    /// </summary>
    public partial class RecurringPayableDetail
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0065";

        /// <summary>
        /// EntityName for Export/Import
        /// </summary>
        public const string EntityName = "AP0065";

        /// <summary>
        /// Contains list of Recurring Payable Detail Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";
            
            /// <summary>
            /// Property for RecurringPayableCode 
            /// </summary>
            public const string RecurringPayableCode = "IDRECURR";
            
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "CNTLINE";
            
            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "IDDISTCODE";
            
            /// <summary>
            /// Property for DistributionDescription 
            /// </summary>
            public const string DistributionDescription = "DESC";
            
            /// <summary>
            /// Property for GOrLAccount 
            /// </summary>
            public const string GLAccount = "IDGLACCT";
            
            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";
            
            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";
            
            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";
            
            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";
            
            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";
            
            /// <summary>
            /// Property for TaxInclusive1 
            /// </summary>
            public const string TaxInclusive1 = "SWTAXINCL1";
            
            /// <summary>
            /// Property for TaxInclusive2 
            /// </summary>
            public const string TaxInclusive2 = "SWTAXINCL2";
            
            /// <summary>
            /// Property for TaxInclusive3 
            /// </summary>
            public const string TaxInclusive3 = "SWTAXINCL3";
            
            /// <summary>
            /// Property for TaxInclusive4 
            /// </summary>
            public const string TaxInclusive4 = "SWTAXINCL4";
            
            /// <summary>
            /// Property for TaxInclusive5 
            /// </summary>
            public const string TaxInclusive5 = "SWTAXINCL5";
            
            /// <summary>
            /// Property for TaxAmount1 
            /// </summary>
            public const string TaxAmount1 = "AMTTAX1";
            
            /// <summary>
            /// Property for TaxAmount2 
            /// </summary>
            public const string TaxAmount2 = "AMTTAX2";
            
            /// <summary>
            /// Property for TaxAmount3 
            /// </summary>
            public const string TaxAmount3 = "AMTTAX3";
            
            /// <summary>
            /// Property for TaxAmount4 
            /// </summary>
            public const string TaxAmount4 = "AMTTAX4";
            
            /// <summary>
            /// Property for TaxAmount5 
            /// </summary>
            public const string TaxAmount5 = "AMTTAX5";
            
            /// <summary>
            /// Property for DistributedAmount 
            /// </summary>
            public const string DistributedAmount = "AMTDIST";
            
            /// <summary>
            /// Property for DistributedAmountBeforeTaxes 
            /// </summary>
            public const string DistributedAmountBeforeTaxes = "AMTDISTNET";
            
            /// <summary>
            /// Property for DistTaxincludedinPrice 
            /// </summary>
            public const string DistTaxincludedinPrice = "AMTTAXINCL";
            
            /// <summary>
            /// Property for DistTaxexcludedfromPrice 
            /// </summary>
            public const string DistTaxexcludedfromPrice = "AMTTAXEXCL";
            
            /// <summary>
            /// Property for TaxAmountTotal 
            /// </summary>
            public const string TaxAmountTotal = "AMTTOTTAX";
            
            /// <summary>
            /// Property for TaxBase1 
            /// </summary>
            public const string TaxBase1 = "BASETAX1";
            
            /// <summary>
            /// Property for TaxBase2 
            /// </summary>
            public const string TaxBase2 = "BASETAX2";
            
            /// <summary>
            /// Property for TaxBase3 
            /// </summary>
            public const string TaxBase3 = "BASETAX3";
            
            /// <summary>
            /// Property for TaxBase4 
            /// </summary>
            public const string TaxBase4 = "BASETAX4";
            
            /// <summary>
            /// Property for TaxBase5 
            /// </summary>
            public const string TaxBase5 = "BASETAX5";
            
            /// <summary>
            /// Property for Discountable 
            /// </summary>
            public const string Discountable = "SWDISCABL";
            
            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";
            
            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";
            
            /// <summary>
            /// Property for Comment 
            /// </summary>
            public const string Comment = "COMMENT";
            
            /// <summary>
            /// Property for ContractCode 
            /// </summary>
            public const string ContractCode = "CONTRACT";
            
            /// <summary>
            /// Property for ProjectCode 
            /// </summary>
            public const string ProjectCode = "PROJECT";
            
            /// <summary>
            /// Property for CategoryCode 
            /// </summary>
            public const string CategoryCode = "CATEGORY";
            
            /// <summary>
            /// Property for ProjectOrCategoryResource 
            /// </summary>
            public const string ProjectOrCategoryResource = "RESOURCE";
            
            /// <summary>
            /// Property for CostClass 
            /// </summary>
            public const string CostClass = "COSTCLASS";
            
            /// <summary>
            /// Property for BillingType 
            /// </summary>
            public const string BillingType = "BILLTYPE";
            
            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "IDITEM";
            
            /// <summary>
            /// Property for UnitofMeasure 
            /// </summary>
            public const string UnitofMeasure = "UNITMEAS";
            
            /// <summary>
            /// Property for Quantity 
            /// </summary>
            public const string Quantity = "QTYINVC";
            
            /// <summary>
            /// Property for Cost 
            /// </summary>
            public const string Cost = "AMTCOST";
            
            /// <summary>
            /// Property for BillingRate 
            /// </summary>
            public const string BillingRate = "BILLRATE";
            
            /// <summary>
            /// Property for BillingCurrency 
            /// </summary>
            public const string BillingCurrency = "BILLCURN";

            #endregion
        }

        /// <summary>
        /// Contains list of Recurring Payable Details Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 1;
            
            /// <summary>
            /// Property Indexer for RecurringPayableCode 
            /// </summary>
            public const int RecurringPayableCode = 2;
            
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 3;
            
            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 4;
            
            /// <summary>
            /// Property Indexer for DistributionDescription 
            /// </summary>
            public const int DistributionDescription = 5;
            
            /// <summary>
            /// Property Indexer for GOrLAccount 
            /// </summary>
            public const int GLAccount = 6;
            
                    
            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 7;
            
            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 8;
            
            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 9;
            
            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 10;
            
            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 11;
            
            /// <summary>
            /// Property Indexer for TaxInclusive1 
            /// </summary>
            public const int TaxInclusive1 = 12;
            
            /// <summary>
            /// Property Indexer for TaxInclusive2 
            /// </summary>
            public const int TaxInclusive2 = 13;
            
            /// <summary>
            /// Property Indexer for TaxInclusive3 
            /// </summary>
            public const int TaxInclusive3 = 14;
            
            /// <summary>
            /// Property Indexer for TaxInclusive4 
            /// </summary>
            public const int TaxInclusive4 = 15;
            
            /// <summary>
            /// Property Indexer for TaxInclusive5 
            /// </summary>
            public const int TaxInclusive5 = 16;
            
            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 17;
            
            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 18;
            
            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 19;
            
            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 20;
            
            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 21;
            
            /// <summary>
            /// Property Indexer for DistributedAmount 
            /// </summary>
            public const int DistributedAmount = 22;
            
            /// <summary>
            /// Property Indexer for DistributedAmountBeforeTaxes 
            /// </summary>
            public const int DistributedAmountBeforeTaxes = 23;
            
            /// <summary>
            /// Property Indexer for DistTaxincludedinPrice 
            /// </summary>
            public const int DistTaxincludedinPrice = 24;
            
            /// <summary>
            /// Property Indexer for DistTaxexcludedfromPrice 
            /// </summary>
            public const int DistTaxexcludedfromPrice = 25;
            
            /// <summary>
            /// Property Indexer for TaxAmountTotal 
            /// </summary>
            public const int TaxAmountTotal = 26;
            
            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 27;
            
            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 28;
            
            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 29;
            
            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 30;
            
            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 31;
            
            /// <summary>
            /// Property Indexer for Discountable 
            /// </summary>
            public const int Discountable = 32;
            
            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 33;
            
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 34;
            

            /// <summary>
            /// Property Indexer for Comment 
            /// </summary>
            public const int Comment = 35;
            
            /// <summary>
            /// Property Indexer for ContractCode 
            /// </summary>
            public const int ContractCode = 36;
            
            /// <summary>
            /// Property Indexer for ProjectCode 
            /// </summary>
            public const int ProjectCode = 37;
            
            /// <summary>
            /// Property Indexer for CategoryCode 
            /// </summary>
            public const int CategoryCode = 38;
            
            /// <summary>
            /// Property Indexer for ProjectOrCategoryResource 
            /// </summary>
            public const int ProjectOrCategoryResource = 39;
            
            /// <summary>
            /// Property Indexer for CostClass 
            /// </summary>
            public const int CostClass = 40;
            
            /// <summary>
            /// Property Indexer for BillingType 
            /// </summary>
            public const int BillingType = 41;
            
            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 42;
            
            /// <summary>
            /// Property Indexer for UnitofMeasure 
            /// </summary>
            public const int UnitofMeasure = 43;
            
            /// <summary>
            /// Property Indexer for Quantity 
            /// </summary>
            public const int Quantity = 44;
            
            /// <summary>
            /// Property Indexer for Cost 
            /// </summary>
            public const int Cost = 45;
            
            /// <summary>
            /// Property Indexer for BillingRate 
            /// </summary>
            public const int BillingRate = 46;
            
            /// <summary>
            /// Property Indexer for BillingCurrency 
            /// </summary>
            public const int BillingCurrency = 47;

            /// <summary>
            /// Property Indexer for estimated tax withheld amount1
            /// </summary>
            public const int EstimatedTaxWithheld1 = 48;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount2
            /// </summary>
            public const int EstimatedTaxWithheld2 = 49;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount3
            /// </summary>
            public const int EstimatedTaxWithheld3 = 50;

            /// <summary>
            /// Property Indexer for estimated tax withheld amount4
            /// </summary>
            public const int EstimatedTaxWithheld4 = 51;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount5
            /// </summary>
            public const int EstimatedTaxWithheld5 = 52;
            /// <summary>
            /// Property Indexer for customer tax base 1
            /// </summary>
            public const int CustomerTaxBase1 = 48;
            /// <summary>
            /// Property Indexer for customer tax base 2
            /// </summary>
            public const int CustomerTaxBase2 = 49;
            /// <summary>
            /// Property Indexer for customer tax base 3
            /// </summary>
            public const int CustomerTaxBase3 = 50;
            /// <summary>
            /// Property Indexer for customer tax base 4
            /// </summary>
            public const int CustomerTaxBase4 = 51;
            /// <summary>
            /// Property Indexer for customer tax base 5
            /// </summary>
            public const int CustomerTaxBase5 = 52;
            /// <summary>
            /// Property Indexer for customer tax amount 1
            /// </summary>
            public const int CustomerTaxAmount1 = 53;
            /// <summary>
            /// Property Indexer for customer tax amount 2
            /// </summary>
            public const int CustomerTaxAmount2 = 54;
            /// <summary>
            /// Property Indexer for customer tax amount 3
            /// </summary>
            public const int CustomerTaxAmount3 = 55;
            /// <summary>
            /// Property Indexer for customer tax amount 4
            /// </summary>
            public const int CustomerTaxAmount4 = 56;
            /// <summary>
            /// Property Indexer for customer tax amount 5
            /// </summary>
            public const int CustomerTaxAmount5 = 57;
            /// <summary>
            /// Property Indexer for Negative Customer Tax Amount
            /// </summary>
            public const int NegativeCustomerTaxAmount = 52;
            /// <summary>
            /// Property Indexer for Net Vendor Tax Amount
            /// </summary>
            public const int NetVendorTaxAmount = 52;
            /// <summary>
            /// Property Indexer for Customer Tax Amount
            /// </summary>
            public const int CustomerTaxAmount = 52;

            #endregion
        }
    }
}
