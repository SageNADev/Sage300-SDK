/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PostingJournal Constants 
    /// </summary>
    public partial class PostingJournal
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0512";

        /// <summary>
        /// Contains list of PostingJournal Field Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Field Property for BatchType 
            /// </summary>
            public const string BatchType = "TYPEBTCH";

            /// <summary>
            /// Field Property for PostingSequenceNo 
            /// </summary>
            public const string PostingSequenceNo = "POSTSEQNCE";

            /// <summary>
            /// Field Property for SystemDate 
            /// </summary>
            public const string SystemDate = "DATEPOSTED";

            /// <summary>
            /// Field Property for DatePostedinAOrP 
            /// </summary>
            public const string DatePostedinAorP = "DATEBUS";

            /// <summary>
            /// Field Property for Printed 
            /// </summary>
            public const string Printed = "SWPRINTED";

            /// <summary>
            /// Field Property for Status String
            /// Added for Finder filter
            /// </summary>
            public const string PrintedString = "SWPRINTED";

            /// <summary>
            /// Field Property for PostedtoGorL 
            /// </summary>
            public const string PostedtoGorL = "SWPOSTGL";

            /// <summary>
            /// Field Property for DatePostedtoGOrL 
            /// </summary>
            public const string DatePostedtoGorL = "DATEPOSTGL";

            /// <summary>
            /// Field Property for ConsolidatedforGOrL 
            /// </summary>
            public const string ConsolidatedforGorL = "SWGLCONSL";

            /// <summary>
            /// Field Property for ProgramVersion 
            /// </summary>
            public const string ProgramVersion = "PGMVER";

            #endregion
        }


        /// <summary>
        /// Contains list of PostingJournal Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;

            /// <summary>
            /// Property Indexer for PostingSequenceNo 
            /// </summary>
            public const int PostingSequenceNo = 2;

            /// <summary>
            /// Property Indexer for SystemDate 
            /// </summary>
            public const int SystemDate = 3;

            /// <summary>
            /// Property Indexer for DatePostedinAOrP 
            /// </summary>
            public const int DatePostedinAorP = 4;

            /// <summary>
            /// Property Indexer for Printed 
            /// </summary>
            public const int Printed = 5;

            /// <summary>
            /// Property Indexer for PostedtoGOrL 
            /// </summary>
            public const int PostedtoGorL = 6;

            /// <summary>
            /// Property Indexer for DatePostedtoGOrL 
            /// </summary>
            public const int DatePostedtoGorL = 7;

            /// <summary>
            /// Property Indexer for ConsolidatedforGOrL 
            /// </summary>
            public const int ConsolidatedforGorL = 8;

            /// <summary>
            /// Property Indexer for ProgramVersion 
            /// </summary>
            public const int ProgramVersion = 9;

            #endregion
        }
    }
}