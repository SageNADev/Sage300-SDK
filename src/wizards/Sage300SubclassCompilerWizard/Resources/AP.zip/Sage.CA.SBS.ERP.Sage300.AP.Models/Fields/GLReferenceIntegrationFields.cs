// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of G/L Reference Integration Constants 
    /// </summary>
    public partial class GLReferenceIntegration
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0121";

        /// <summary>
        /// Contains list of G/L Reference Integration Fields Constants
        /// </summary>
        public class Fields : BaseFields
        {

        }

        /// <summary>
        /// Contains list of G/L Reference Integration Index Constants
        /// </summary>
        public class Index : BaseIndex
        {
            /// <summary>
            /// Property Index for Separator 
            /// </summary>
            public const int Separator = 3;

            /// <summary>
            /// Property Index for Example 
            /// </summary>
            public const int Example = 4;
        }
    }
}
