// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of Documents Constants 
    /// </summary>
    public partial class VendorActivityDocument
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0110";

        /// <summary>
        /// Contains list of Documents Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";

            /// <summary>
            /// Property for DocumentNumber 
            /// </summary>
            public const string DocumentNumber = "IDINVC";

            /// <summary>
            /// Property for CheckNumber 
            /// </summary>
            public const string CheckNumber = "IDRMIT";

            /// <summary>
            /// Property for OrderNumber 
            /// </summary>
            public const string OrderNumber = "IDORDERNBR";

            /// <summary>
            /// Property for PurchaseOrderNumber 
            /// </summary>
            public const string PurchaseOrderNumber = "IDPONBR";

            /// <summary>
            /// Property for DueDate 
            /// </summary>
            public const string DueDate = "DATEINVCDU";

            /// <summary>
            /// Property for RemitToLocation 
            /// </summary>
            public const string RemitToLocation = "IDRMITTO";

            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "IDTRXTYPE";

            /// <summary>
            /// Property for DocumentType 
            /// </summary>
            public const string DocumentType = "TXTTRXTYPE";

            /// <summary>
            /// Property for BatchDate 
            /// </summary>
            public const string BatchDate = "DATEBTCH";

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";

            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTITEM";

            /// <summary>
            /// Property for GroupCode 
            /// </summary>
            public const string GroupCode = "IDVENDGRP";

            /// <summary>
            /// Property for DocDescription 
            /// </summary>
            public const string DocDescription = "DESCINVC";

            /// <summary>
            /// Property for DocDate 
            /// </summary>
            public const string DocDate = "DATEINVC";

            /// <summary>
            /// Property for InvoiceasofDate 
            /// </summary>
            public const string InvoiceasofDate = "DATEASOF";

            /// <summary>
            /// Property for Terms 
            /// </summary>
            public const string Terms = "CODETERM";

            /// <summary>
            /// Property for DiscountDate 
            /// </summary>
            public const string DiscountDate = "DATEDISC";

            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CODECURN";

            /// <summary>
            /// Property for RateType 
            /// </summary>
            public const string RateType = "IDRATETYPE";

            /// <summary>
            /// Property for RateOverridden 
            /// </summary>
            public const string RateOverridden = "SWRATEOVRD";

            /// <summary>
            /// Property for ExchangeRate 
            /// </summary>
            public const string ExchangeRate = "EXCHRATEHC";

            /// <summary>
            /// Property for FunctionalCurrencyInvoiceAmount 
            /// </summary>
            public const string FunctionalCurrencyInvoiceAmount = "AMTINVCHC";

            /// <summary>
            /// Property for FunctionalCurrencyAmountDue 
            /// </summary>
            public const string FunctionalCurrencyAmountDue = "AMTDUEHC";

            /// <summary>
            /// Property for FunctionalCurrencyTaxableAmount 
            /// </summary>
            public const string FunctionalCurrencyTaxableAmount = "AMTTXBLHC";

            /// <summary>
            /// Property for FunctionalCurrencyNonTaxableAmt 
            /// </summary>
            public const string FunctionalCurrencyNonTaxableAmt = "AMTNONTXHC";

            /// <summary>
            /// Property for FunctionalCurrencyTaxAmount 
            /// </summary>
            public const string FunctionalCurrencyTaxAmount = "AMTTAXHC";

            /// <summary>
            /// Property for FunctionalCurrencyDiscountAmount 
            /// </summary>
            public const string FunctionalCurrencyDiscountAmount = "AMTDISCHC";

            /// <summary>
            /// Property for VendorCurrencyInvoiceAmount 
            /// </summary>
            public const string VendorCurrencyInvoiceAmount = "AMTINVCTC";

            /// <summary>
            /// Property for VendorCurrencyAmountDue 
            /// </summary>
            public const string VendorCurrencyAmountDue = "AMTDUETC";

            /// <summary>
            /// Property for VendorCurrencyTaxableAmount 
            /// </summary>
            public const string VendorCurrencyTaxableAmount = "AMTTXBLTC";

            /// <summary>
            /// Property for VendorCurrencyNonTaxableAmt 
            /// </summary>
            public const string VendorCurrencyNonTaxableAmt = "AMTNONTXTC";

            /// <summary>
            /// Property for VendorCurrencyTaxAmount 
            /// </summary>
            public const string VendorCurrencyTaxAmount = "AMTTAXTC";

            /// <summary>
            /// Property for VendorCurrencyDiscountAmount 
            /// </summary>
            public const string VendorCurrencyDiscountAmount = "AMTDISCTC";

            /// <summary>
            /// Property for FullyPaid 
            /// </summary>
            public const string FullyPaid = "SWPAID";

            /// <summary>
            /// Property for LastActivityDate 
            /// </summary>
            public const string LastActivityDate = "DATELSTACT";

            /// <summary>
            /// Property for LastStatementDate 
            /// </summary>
            public const string LastStatementDate = "DATELSTSTM";

            /// <summary>
            /// Property for NumberofScheduledPayments 
            /// </summary>
            public const string NumberofScheduledPayments = "CNTTOTPAYM";

            /// <summary>
            /// Property for LastPaymentNumberPaid 
            /// </summary>
            public const string LastPaymentNumberPaid = "CNTLSTPAYM";

            /// <summary>
            /// Property for PaymentNumberonLastStatement 
            /// </summary>
            public const string PaymentNumberonLastStatement = "CNTLSTPYST";

            /// <summary>
            /// Property for PaymentAmountApplied 
            /// </summary>
            public const string PaymentAmountApplied = "AMTREMIT";

            /// <summary>
            /// Property for LastAppliedPaymentSeqNo 
            /// </summary>
            public const string LastAppliedPaymentSeqNo = "CNTLASTSCH";

            /// <summary>
            /// Property for TaxAmountControl 
            /// </summary>
            public const string TaxAmountControl = "SWTAXOVRD";

            /// <summary>
            /// Property for TaxAuth1 
            /// </summary>
            public const string TaxAuth1 = "CODETAX1";

            /// <summary>
            /// Property for TaxAuth2 
            /// </summary>
            public const string TaxAuth2 = "CODETAX2";

            /// <summary>
            /// Property for TaxAuth3 
            /// </summary>
            public const string TaxAuth3 = "CODETAX3";

            /// <summary>
            /// Property for TaxAuth4 
            /// </summary>
            public const string TaxAuth4 = "CODETAX4";

            /// <summary>
            /// Property for TaxAuth5 
            /// </summary>
            public const string TaxAuth5 = "CODETAX5";

            /// <summary>
            /// Property for FunctionalBaseAmount1 
            /// </summary>
            public const string FunctionalBaseAmount1 = "AMTBASE1HC";

            /// <summary>
            /// Property for FunctionalBaseAmount2 
            /// </summary>
            public const string FunctionalBaseAmount2 = "AMTBASE2HC";

            /// <summary>
            /// Property for FunctionalBaseAmount3 
            /// </summary>
            public const string FunctionalBaseAmount3 = "AMTBASE3HC";

            /// <summary>
            /// Property for FunctionalBaseAmount4 
            /// </summary>
            public const string FunctionalBaseAmount4 = "AMTBASE4HC";

            /// <summary>
            /// Property for FunctionalBaseAmount5 
            /// </summary>
            public const string FunctionalBaseAmount5 = "AMTBASE5HC";

            /// <summary>
            /// Property for FunctionalTaxAmount1 
            /// </summary>
            public const string FunctionalTaxAmount1 = "AMTTAX1HC";

            /// <summary>
            /// Property for FunctionalTaxAmount2 
            /// </summary>
            public const string FunctionalTaxAmount2 = "AMTTAX2HC";

            /// <summary>
            /// Property for FunctionalTaxAmount3 
            /// </summary>
            public const string FunctionalTaxAmount3 = "AMTTAX3HC";

            /// <summary>
            /// Property for FunctionalTaxAmount4 
            /// </summary>
            public const string FunctionalTaxAmount4 = "AMTTAX4HC";

            /// <summary>
            /// Property for FunctionalTaxAmount5 
            /// </summary>
            public const string FunctionalTaxAmount5 = "AMTTAX5HC";

            /// <summary>
            /// Property for VendorBaseAmount1 
            /// </summary>
            public const string VendorBaseAmount1 = "AMTBASE1TC";

            /// <summary>
            /// Property for VendorBaseAmount2 
            /// </summary>
            public const string VendorBaseAmount2 = "AMTBASE2TC";

            /// <summary>
            /// Property for VendorBaseAmount3 
            /// </summary>
            public const string VendorBaseAmount3 = "AMTBASE3TC";

            /// <summary>
            /// Property for VendorBaseAmount4 
            /// </summary>
            public const string VendorBaseAmount4 = "AMTBASE4TC";

            /// <summary>
            /// Property for VendorBaseAmount5 
            /// </summary>
            public const string VendorBaseAmount5 = "AMTBASE5TC";

            /// <summary>
            /// Property for VendorTaxAmount1 
            /// </summary>
            public const string VendorTaxAmount1 = "AMTTAX1TC";

            /// <summary>
            /// Property for VendorTaxAmount2 
            /// </summary>
            public const string VendorTaxAmount2 = "AMTTAX2TC";

            /// <summary>
            /// Property for VendorTaxAmount3 
            /// </summary>
            public const string VendorTaxAmount3 = "AMTTAX3TC";

            /// <summary>
            /// Property for VendorTaxAmount4 
            /// </summary>
            public const string VendorTaxAmount4 = "AMTTAX4TC";

            /// <summary>
            /// Property for VendorTaxAmount5 
            /// </summary>
            public const string VendorTaxAmount5 = "AMTTAX5TC";

            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FISCYR";

            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FISCPER";

            /// <summary>
            /// Property for PrepayInvoiceNumber 
            /// </summary>
            public const string PrepayInvoiceNumber = "IDPREPAY";

            /// <summary>
            /// Property for PostingDate 
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for Num1099OrCPRSCode 
            /// </summary>
            public const string Num1099OrCPRSCode = "ID1099CLAS";

            /// <summary>
            /// Property for Num1099OrCPRSOriginalAmount 
            /// </summary>
            public const string Num1099OrCPRSOriginalAmount = "AMT1099ORG";

            /// <summary>
            /// Property for Num1099OrCPRSRemainingAmount 
            /// </summary>
            public const string Num1099OrCPRSRemainingAmount = "AMT1099REM";

            /// <summary>
            /// Property for RateDate 
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateOperator 
            /// </summary>
            public const string RateOperator = "RATEOP";

            /// <summary>
            /// Property for LastActivityYearOrPeriod 
            /// </summary>
            public const string LastActivityYearOrPeriod = "YPLASTACT";

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "IDBANK";

            /// <summary>
            /// Property for CheckSerialNumber 
            /// </summary>
            public const string CheckSerialNumber = "LONGSERIAL";

            /// <summary>
            /// Property for PostingSequenceNo 
            /// </summary>
            public const string PostingSequenceNo = "POSTSEQNCE";

            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelated = "SWJOB";

            /// <summary>
            /// Property for HasRetainage 
            /// </summary>
            public const string HasRetainage = "SWRTG";

            /// <summary>
            /// Property for RetainageOutstanding 
            /// </summary>
            public const string RetainageOutstanding = "SWRTGOUT";

            /// <summary>
            /// Property for DateRetainageDue 
            /// </summary>
            public const string DateRetainageDue = "RTGDATEDUE";

            /// <summary>
            /// Property for FunctionalCurrencyOrigRtngAmt 
            /// </summary>
            public const string FunctionalCurrencyOrigRtngAmt = "RTGOAMTHC";

            /// <summary>
            /// Property for FunctionalCurrencyRetainageAmount 
            /// </summary>
            public const string FunctionalCurrencyRetainageAmount = "RTGAMTHC";

            /// <summary>
            /// Property for VendorCurrencyOrigRtngAmt 
            /// </summary>
            public const string VendorCurrencyOrigRtngAmt = "RTGOAMTTC";

            /// <summary>
            /// Property for VendorCurrencyRetainageAmount 
            /// </summary>
            public const string VendorCurrencyRetainageAmount = "RTGAMTTC";

            /// <summary>
            /// Property for RetainageTermsCode 
            /// </summary>
            public const string RetainageTermsCode = "RTGTERMS";

            /// <summary>
            /// Property for RetainageExchangeRate 
            /// </summary>
            public const string RetainageExchangeRate = "SWRTGRATE";

            /// <summary>
            /// Property for OriginalDocNo 
            /// </summary>
            public const string OriginalDocNo = "RTGAPPLYTO";

            /// <summary>
            /// Property for FunctionalPendingPaymentAmount 
            /// </summary>
            public const string FunctionalPendingPaymentAmount = "PNDPAYTOTH";

            /// <summary>
            /// Property for FunctionalPendingDiscountAmount 
            /// </summary>
            public const string FunctionalPendingDiscountAmount = "PNDDSCTOTH";

            /// <summary>
            /// Property for FunctionalPendingAdjustmentAm 
            /// </summary>
            public const string FunctionalPendingAdjustmentAmount = "PNDADJTOTH";

            /// <summary>
            /// Property for FunctionalPendingBalance 
            /// </summary>
            public const string FunctionalPendingBalance = "PENDNGBALH";

            /// <summary>
            /// Property for PendingPaymentAmount 
            /// </summary>
            public const string PendingPaymentAmount = "PNDPAYTOT";

            /// <summary>
            /// Property for PendingDiscountAmount 
            /// </summary>
            public const string PendingDiscountAmount = "PNDDSCTOT";

            /// <summary>
            /// Property for PendingAdjustmentAmount 
            /// </summary>
            public const string PendingAdjustmentAmount = "PNDADJTOT";

            /// <summary>
            /// Property for PendingBalance 
            /// </summary>
            public const string PendingBalance = "PENDNGBAL";

            /// <summary>
            /// Property for VendorNoUsedtoCalculatePen 
            /// </summary>
            public const string VendorNoUsedtoCalculatePen = "IDVENDPEND";

            /// <summary>
            /// Property for ShowPendingAmountsSwitch 
            /// </summary>
            public const string ShowPendingAmountsSwitch = "SWSHOWPEND";

            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPPL";

            /// <summary>
            /// Property for PaymentStatus 
            /// </summary>
            public const string PaymentStatus = "SWPYSTTS";

            /// <summary>
            /// Property for DatePaymentStatusChanged 
            /// </summary>
            public const string DatePaymentStatusChanged = "DATEPYSTTS";

            /// <summary>
            /// Property for AOrPVersionCreatedIn 
            /// </summary>
            public const string AOrPVersionCreatedIn = "APVERSION";

            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "TYPEBTCH";

            /// <summary>
            /// Property for NumberofOBLJDetails 
            /// </summary>
            public const string NumberofOBLJDetails = "CNTOBLJ";

            /// <summary>
            /// Property for PaymentLimit 
            /// </summary>
            public const string PaymentLimit = "AMTPYMLMTC";

            /// <summary>
            /// Property for Obsolete 
            /// </summary>
            public const string Obsolete = "SWSHOWPAID";

            #endregion
        }

        /// <summary>
        /// Contains list of Documents Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 1;

            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 2;

            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int CheckNumber = 3;

            /// <summary>
            /// Property Indexer for OrderNumber 
            /// </summary>
            public const int OrderNumber = 4;

            /// <summary>
            /// Property Indexer for PONumber 
            /// </summary>
            public const int PurchaseOrderNumber = 5;

            /// <summary>
            /// Property Indexer for DueDate 
            /// </summary>
            public const int DueDate = 6;

            /// <summary>
            /// Property Indexer for RemitToLocation 
            /// </summary>
            public const int RemitToLocation = 7;

            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 8;

            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 9;

            /// <summary>
            /// Property Indexer for BatchDate 
            /// </summary>
            public const int BatchDate = 10;

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 11;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 12;

            /// <summary>
            /// Property Indexer for GroupCode 
            /// </summary>
            public const int GroupCode = 13;

            /// <summary>
            /// Property Indexer for DocDescription 
            /// </summary>
            public const int DocDescription = 14;

            /// <summary>
            /// Property Indexer for DocDate 
            /// </summary>
            public const int DocDate = 15;

            /// <summary>
            /// Property Indexer for InvoiceasofDate 
            /// </summary>
            public const int InvoiceasofDate = 16;

            /// <summary>
            /// Property Indexer for Terms 
            /// </summary>
            public const int Terms = 17;

            /// <summary>
            /// Property Indexer for DiscountDate 
            /// </summary>
            public const int DiscountDate = 18;

            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 19;

            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 20;

            /// <summary>
            /// Property Indexer for RateOverridden 
            /// </summary>
            public const int RateOverridden = 21;

            /// <summary>
            /// Property Indexer for ExchangeRate 
            /// </summary>
            public const int ExchangeRate = 22;

            /// <summary>
            /// Property Indexer for FunctionalCurrencyInvoiceAmount 
            /// </summary>
            public const int FunctionalCurrencyInvoiceAmount = 23;

            /// <summary>
            /// Property Indexer for FunctionalCurrencyAmountDue 
            /// </summary>
            public const int FunctionalCurrencyAmountDue = 24;

            /// <summary>
            /// Property Indexer for FunctionalCurrencyTaxableAmount 
            /// </summary>
            public const int FunctionalCurrencyTaxableAmount = 25;

            /// <summary>
            /// Property Indexer for FunctionalCurrencyNonTaxableAmt 
            /// </summary>
            public const int FunctionalCurrencyNonTaxableAmt = 26;

            /// <summary>
            /// Property Indexer for FunctionalCurrencyTaxAmount 
            /// </summary>
            public const int FunctionalCurrencyTaxAmount = 27;

            /// <summary>
            /// Property Indexer for FunctionalCurrencyDiscountAmount 
            /// </summary>
            public const int FunctionalCurrencyDiscountAmount = 28;

            /// <summary>
            /// Property Indexer for VendorCurrencyInvoiceAmount 
            /// </summary>
            public const int VendorCurrencyInvoiceAmount = 29;

            /// <summary>
            /// Property Indexer for VendorCurrencyAmountDue 
            /// </summary>
            public const int VendorCurrencyAmountDue = 30;

            /// <summary>
            /// Property Indexer for VendorCurrencyTaxableAmount 
            /// </summary>
            public const int VendorCurrencyTaxableAmount = 31;

            /// <summary>
            /// Property Indexer for VendorCurrencyNonTaxableAmt 
            /// </summary>
            public const int VendorCurrencyNonTaxableAmt = 32;

            /// <summary>
            /// Property Indexer for VendorCurrencyTaxAmount 
            /// </summary>
            public const int VendorCurrencyTaxAmount = 33;

            /// <summary>
            /// Property Indexer for VendorCurrencyDiscountAmount 
            /// </summary>
            public const int VendorCurrencyDiscountAmount = 34;

            /// <summary>
            /// Property Indexer for FullyPaid 
            /// </summary>
            public const int FullyPaid = 35;

            /// <summary>
            /// Property Indexer for LastActivityDate 
            /// </summary>
            public const int LastActivityDate = 36;

            /// <summary>
            /// Property Indexer for LastStatementDate 
            /// </summary>
            public const int LastStatementDate = 37;

            /// <summary>
            /// Property Indexer for NumberofScheduledPayments 
            /// </summary>
            public const int NumberofScheduledPayments = 38;

            /// <summary>
            /// Property Indexer for LastPaymentNumberPaid 
            /// </summary>
            public const int LastPaymentNumberPaid = 39;

            /// <summary>
            /// Property Indexer for PaymentNumberonLastStatement 
            /// </summary>
            public const int PaymentNumberonLastStatement = 40;

            /// <summary>
            /// Property Indexer for PaymentAmountApplied 
            /// </summary>
            public const int PaymentAmountApplied = 41;

            /// <summary>
            /// Property Indexer for LastAppliedPaymentSeqNo 
            /// </summary>
            public const int LastAppliedPaymentSeqNo = 42;

            /// <summary>
            /// Property Indexer for TaxAmountControl 
            /// </summary>
            public const int TaxAmountControl = 43;

            /// <summary>
            /// Property Indexer for TaxAuth1 
            /// </summary>
            public const int TaxAuth1 = 44;

            /// <summary>
            /// Property Indexer for TaxAuth2 
            /// </summary>
            public const int TaxAuth2 = 45;

            /// <summary>
            /// Property Indexer for TaxAuth3 
            /// </summary>
            public const int TaxAuth3 = 46;

            /// <summary>
            /// Property Indexer for TaxAuth4 
            /// </summary>
            public const int TaxAuth4 = 47;

            /// <summary>
            /// Property Indexer for TaxAuth5 
            /// </summary>
            public const int TaxAuth5 = 48;

            /// <summary>
            /// Property Indexer for FunctionalBaseAmount1 
            /// </summary>
            public const int FunctionalBaseAmount1 = 49;

            /// <summary>
            /// Property Indexer for FunctionalBaseAmount2 
            /// </summary>
            public const int FunctionalBaseAmount2 = 50;

            /// <summary>
            /// Property Indexer for FunctionalBaseAmount3 
            /// </summary>
            public const int FunctionalBaseAmount3 = 51;

            /// <summary>
            /// Property Indexer for FunctionalBaseAmount4 
            /// </summary>
            public const int FunctionalBaseAmount4 = 52;

            /// <summary>
            /// Property Indexer for FunctionalBaseAmount5 
            /// </summary>
            public const int FunctionalBaseAmount5 = 53;

            /// <summary>
            /// Property Indexer for FunctionalTaxAmount1 
            /// </summary>
            public const int FunctionalTaxAmount1 = 54;

            /// <summary>
            /// Property Indexer for FunctionalTaxAmount2 
            /// </summary>
            public const int FunctionalTaxAmount2 = 55;

            /// <summary>
            /// Property Indexer for FunctionalTaxAmount3 
            /// </summary>
            public const int FunctionalTaxAmount3 = 56;

            /// <summary>
            /// Property Indexer for FunctionalTaxAmount4 
            /// </summary>
            public const int FunctionalTaxAmount4 = 57;

            /// <summary>
            /// Property Indexer for FunctionalTaxAmount5 
            /// </summary>
            public const int FunctionalTaxAmount5 = 58;

            /// <summary>
            /// Property Indexer for VendorBaseAmount1 
            /// </summary>
            public const int VendorBaseAmount1 = 59;

            /// <summary>
            /// Property Indexer for VendorBaseAmount2 
            /// </summary>
            public const int VendorBaseAmount2 = 60;

            /// <summary>
            /// Property Indexer for VendorBaseAmount3 
            /// </summary>
            public const int VendorBaseAmount3 = 61;

            /// <summary>
            /// Property Indexer for VendorBaseAmount4 
            /// </summary>
            public const int VendorBaseAmount4 = 62;

            /// <summary>
            /// Property Indexer for VendorBaseAmount5 
            /// </summary>
            public const int VendorBaseAmount5 = 63;

            /// <summary>
            /// Property Indexer for VendorTaxAmount1 
            /// </summary>
            public const int VendorTaxAmount1 = 64;

            /// <summary>
            /// Property Indexer for VendorTaxAmount2 
            /// </summary>
            public const int VendorTaxAmount2 = 65;

            /// <summary>
            /// Property Indexer for VendorTaxAmount3 
            /// </summary>
            public const int VendorTaxAmount3 = 66;

            /// <summary>
            /// Property Indexer for VendorTaxAmount4 
            /// </summary>
            public const int VendorTaxAmount4 = 67;

            /// <summary>
            /// Property Indexer for VendorTaxAmount5 
            /// </summary>
            public const int VendorTaxAmount5 = 68;

            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 77;

            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 78;

            /// <summary>
            /// Property Indexer for PrepayInvoiceNumber 
            /// </summary>
            public const int PrepayInvoiceNumber = 79;

            /// <summary>
            /// Property Indexer for PostingDate 
            /// </summary>
            public const int PostingDate = 80;

            /// <summary>
            /// Property Indexer for Num1099OrCPRSCode 
            /// </summary>
            public const int Num1099OrCPRSCode = 81;

            /// <summary>
            /// Property Indexer for Num1099OrCPRSOriginalAmount 
            /// </summary>
            public const int Num1099OrCPRSOriginalAmount = 82;

            /// <summary>
            /// Property Indexer for Num1099OrCPRSRemainingAmount 
            /// </summary>
            public const int Num1099OrCPRSRemainingAmount = 83;

            /// <summary>
            /// Property Indexer for RateDate 
            /// </summary>
            public const int RateDate = 84;

            /// <summary>
            /// Property Indexer for RateOperator 
            /// </summary>
            public const int RateOperator = 85;

            /// <summary>
            /// Property Indexer for LastActivityYearOrPeriod 
            /// </summary>
            public const int LastActivityYearOrPeriod = 86;

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 87;

            /// <summary>
            /// Property Indexer for CheckSerialNumber 
            /// </summary>
            public const int CheckSerialNumber = 88;

            /// <summary>
            /// Property Indexer for PostingSequenceNo 
            /// </summary>
            public const int PostingSequenceNo = 89;

            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 90;

            /// <summary>
            /// Property Indexer for HasRetainage 
            /// </summary>
            public const int HasRetainage = 91;

            /// <summary>
            /// Property Indexer for RetainageOutstanding 
            /// </summary>
            public const int RetainageOutstanding = 92;

            /// <summary>
            /// Property Indexer for DateRetainageDue 
            /// </summary>
            public const int DateRetainageDue = 93;

            /// <summary>
            /// Property Indexer for FunctionalCurrencyOrigRtngAmt 
            /// </summary>
            public const int FunctionalCurrencyOrigRtngAmt = 94;

            /// <summary>
            /// Property Indexer for FunctionalCurrencyRetainageAmount 
            /// </summary>
            public const int FunctionalCurrencyRetainageAmount = 95;

            /// <summary>
            /// Property Indexer for VendorCurrencyOrigRtngAmt 
            /// </summary>
            public const int VendorCurrencyOrigRtngAmt = 96;

            /// <summary>
            /// Property Indexer for VendorCurrencyRetainageAmount 
            /// </summary>
            public const int VendorCurrencyRetainageAmount = 97;

            /// <summary>
            /// Property Indexer for RetainageTermsCode 
            /// </summary>
            public const int RetainageTermsCode = 98;

            /// <summary>
            /// Property Indexer for RetainageExchangeRate 
            /// </summary>
            public const int RetainageExchangeRate = 99;

            /// <summary>
            /// Property Indexer for OriginalDocNo 
            /// </summary>
            public const int OriginalDocNo = 100;

            /// <summary>
            /// Property Indexer for FunctionalPendingPaymentAmoun 
            /// </summary>
            public const int FunctionalPendingPaymentAmount = 101;

            /// <summary>
            /// Property Indexer for FunctionalPendingDiscountAmou 
            /// </summary>
            public const int FunctionalPendingDiscountAmount = 102;

            /// <summary>
            /// Property Indexer for FunctionalPendingAdjustmentAm 
            /// </summary>
            public const int FunctionalPendingAdjustmentAmount = 103;

            /// <summary>
            /// Property Indexer for FunctionalPendingBalance 
            /// </summary>
            public const int FunctionalPendingBalance = 104;

            /// <summary>
            /// Property Indexer for PendingPaymentAmount 
            /// </summary>
            public const int PendingPaymentAmount = 105;

            /// <summary>
            /// Property Indexer for PendingDiscountAmount 
            /// </summary>
            public const int PendingDiscountAmount = 106;

            /// <summary>
            /// Property Indexer for PendingAdjustmentAmount 
            /// </summary>
            public const int PendingAdjustmentAmount = 107;

            /// <summary>
            /// Property Indexer for PendingBalance 
            /// </summary>
            public const int PendingBalance = 108;

            /// <summary>
            /// Property Indexer for VendorNoUsedtoCalculatePen 
            /// </summary>
            public const int VendorNoUsedtoCalculatePen = 109;

            /// <summary>
            /// Property Indexer for ShowPendingAmountsSwitch 
            /// </summary>
            public const int ShowPendingAmountsSwitch = 110;

            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 111;

            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 112;

            /// <summary>
            /// Property Indexer for PaymentStatus 
            /// </summary>
            public const int PaymentStatus = 113;

            /// <summary>
            /// Property Indexer for DatePaymentStatusChanged 
            /// </summary>
            public const int DatePaymentStatusChanged = 114;

            /// <summary>
            /// Property Indexer for AOrPVersionCreatedIn 
            /// </summary>
            public const int AOrPVersionCreatedIn = 115;

            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 116;

            /// <summary>
            /// Property Indexer for NumberofOBLJDetails 
            /// </summary>
            public const int NumberofOBLJDetails = 117;

            /// <summary>
            /// Property Indexer for PaymentLimit 
            /// </summary>
            public const int PaymentLimit = 118;

            /// <summary>
            /// Property Indexer for Obsolete 
            /// </summary>
            public const int Obsolete = 119;

            #endregion
        }
    }
}
