/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of DistributionSetDetails Constants 
    /// </summary>
	public partial class DistributionSetDetail 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0008";

        /// <summary>
        /// Contains list of DistributionSetDetails Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for DistributionSet 
        /// </summary>
	    public const string DistributionSet  = "DISTSET";
	            /// <summary>
        /// Property for LineNumber 
        /// </summary>
	    public const string LineNumber  = "CNTLINE";
	            /// <summary>
        /// Property for DistributionCode 
        /// </summary>
	    public const string DistributionCode  = "DISTID";
	            /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "TEXTDESC";
	            /// <summary>
        /// Property for GOrLAccount 
        /// </summary>
	    public const string GLAccount  = "IDGLACCT";
	            /// <summary>
        /// Property for Discountable 
        /// </summary>
	    public const string Discountable  = "SWDISCABL";
	            /// <summary>
        /// Property for Percentage 
        /// </summary>
	    public const string Percentage  = "DISTPCT";
	            /// <summary>
        /// Property for Amount 
        /// </summary>
	    public const string Amount  = "DISTAMT";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of DistributionSetDetails Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for DistributionSet 
        /// </summary>
	    public const int DistributionSet  = 1;
	             /// <summary>
        /// Property Indexer for LineNumber 
        /// </summary>
	    public const int LineNumber  = 2;
	             /// <summary>
        /// Property Indexer for DistributionCode 
        /// </summary>
	    public const int DistributionCode  = 3;
	             /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 4;
	             /// <summary>
        /// Property Indexer for GOrLAccount 
        /// </summary>
	    public const int GLAccount  = 5;
	             /// <summary>
        /// Property Indexer for Discountable 
        /// </summary>
	    public const int Discountable  = 6;
	             /// <summary>
        /// Property Indexer for Percentage 
        /// </summary>
	    public const int Percentage  = 7;
	             /// <summary>
        /// Property Indexer for Amount 
        /// </summary>
	    public const int Amount  = 8;
	     
        #endregion
	    }

	
	}
}
	