/* Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of AdjustmentGLDistributions Constants 
    /// </summary>
	public partial class AdjustmentGLDistribution
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0034";

        /// <summary>
        /// Contains list of AdjustmentGLDistributions Fields Constants
        /// </summary>
	    public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "BATCHTYPE";
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTRMIT";
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "CNTLINE";
            /// <summary>
            /// Property for SequenceNo 
            /// </summary>
            public const string SequenceNo = "CNTSEQ";
            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "CODTRXTYPE";
            /// <summary>
            /// Property for DistributionAmount 
            /// </summary>
            public const string DistributionAmount = "AMTDIST";
            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "IDDISTCODE";
            /// <summary>
            /// Property for DistributionGOrLAccount 
            /// </summary>
            public const string DistributionGLAccount = "IDACCT";
            /// <summary>
            /// Property for ContractCode 
            /// </summary>
            public const string ContractCode = "CONTRACT";
            /// <summary>
            /// Property for ProjectCode 
            /// </summary>
            public const string ProjectCode = "PROJECT";
            /// <summary>
            /// Property for CategoryCode 
            /// </summary>
            public const string CategoryCode = "CATEGORY";
            /// <summary>
            /// Property for ProjectOrCategoryResource 
            /// </summary>
            public const string ProjectOrCategoryResource = "RESOURCE";
            /// <summary>
            /// Property for TransactionNumber 
            /// </summary>
            public const string TransactionNumber = "TRANSNBR";
            /// <summary>
            /// Property for CostClass 
            /// </summary>
            public const string CostClass = "COSTCLASS";
            /// <summary>
            /// Property for BillingType 
            /// </summary>
            public const string BillingType = "BILLTYPE";
            /// <summary>
            /// Property for DiscountAmount 
            /// </summary>
            public const string DiscountAmount = "AMTDISC";
            /// <summary>
            /// Property for AppliedAmount 
            /// </summary>
            public const string AppliedAmount = "AMTPAYM";
            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "IDITEM";
            /// <summary>
            /// Property for UnitofMeasure 
            /// </summary>
            public const string UnitofMeasure = "UNITMEAS";
            /// <summary>
            /// Property for Quantity 
            /// </summary>
            public const string Quantity = "QTYINVC";
            /// <summary>
            /// Property for Cost 
            /// </summary>
            public const string Cost = "AMTCOST";
            /// <summary>
            /// Property for BillingDate 
            /// </summary>
            public const string BillingDate = "BILLDATE";
            /// <summary>
            /// Property for BillingRate 
            /// </summary>
            public const string BillingRate = "BILLRATE";
            /// <summary>
            /// Property for BillingCurrency 
            /// </summary>
            public const string BillingCurrency = "BILLCURN";
            /// <summary>
            /// Property for RetainageAmount 
            /// </summary>
            public const string RetainageAmount = "RTGAMT";
            /// <summary>
            /// Property for RetainageDueDate 
            /// </summary>
            public const string RetainageDueDate = "RTGDATEDUE";
            /// <summary>
            /// Property for HasRetainage 
            /// </summary>
            public const string HasRetainage = "SWRTG";
            /// <summary>
            /// Property for FuncDistributionAmount 
            /// </summary>
            public const string FuncDistributionAmount = "AMTDISTHC";
            /// <summary>
            /// Property for FuncDiscountAmount 
            /// </summary>
            public const string FuncDiscountAmount = "AMTDISCHC";
            /// <summary>
            /// Property for FuncAppliedAmount 
            /// </summary>
            public const string FuncAppliedAmount = "AMTPAYMHC";
            /// <summary>
            /// Property for FuncRetainageAmount 
            /// </summary>
            public const string FuncRetainageAmount = "RTGAMTHC";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";
            /// <summary>
            /// Property for Reference 
            /// </summary>
            public const string Reference = "TEXTREF";
            /// <summary>
            /// Property for DocumentLineNumber 
            /// </summary>
            public const string DocumentLineNumber = "DOCLINE";
            /// <summary>
            /// Property for VendCurrencyAmountDue 
            /// </summary>
            public const string VendCurrencyAmountDue = "AMTDUETC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHD1TC = "AMTWHD1TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHD2TC = "AMTWHD2TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHD3TC = "AMTWHD3TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHD4TC = "AMTWHD4TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHD5TC = "AMTWHD5TC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHD1HC = "AMTWHD1HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHD2HC = "AMTWHD2HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHD3HC = "AMTWHD3HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHD4HC = "AMTWHD4HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHD5HC = "AMTWHD5HC";

            /// <summary>
            /// Property For Tax Withheld Amount Total
            /// </summary>
            public const string AmtWHDTot = "AMTWHDTOT";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "PROJSTYLE";

            /// <summary>
            /// Property for UnformattedContractCode 
            /// </summary>
            public const string UnformattedContractCode = "UNFMTCONT";
            #endregion
        }


        /// <summary>
        /// Contains list of AdjustmentGLDistributions Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 3;
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 4;
            /// <summary>
            /// Property Indexer for SequenceNo 
            /// </summary>
            public const int SequenceNo = 5;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 6;
            /// <summary>
            /// Property Indexer for DistributionAmount 
            /// </summary>
            public const int DistributionAmount = 7;
            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 8;
            /// <summary>
            /// Property Indexer for DistributionGOrLAccount 
            /// </summary>
            public const int DistributionGLAccount = 9;
            /// <summary>
            /// Property Indexer for ContractCode 
            /// </summary>
            public const int ContractCode = 10;
            /// <summary>
            /// Property Indexer for ProjectCode 
            /// </summary>
            public const int ProjectCode = 11;
            /// <summary>
            /// Property Indexer for CategoryCode 
            /// </summary>
            public const int CategoryCode = 12;
            /// <summary>
            /// Property Indexer for ProjectOrCategoryResource 
            /// </summary>
            public const int ProjectOrCategoryResource = 13;
            /// <summary>
            /// Property Indexer for TransactionNumber 
            /// </summary>
            public const int TransactionNumber = 14;
            /// <summary>
            /// Property Indexer for CostClass 
            /// </summary>
            public const int CostClass = 15;
            /// <summary>
            /// Property Indexer for BillingType 
            /// </summary>
            public const int BillingType = 16;
            /// <summary>
            /// Property Indexer for DiscountAmount 
            /// </summary>
            public const int DiscountAmount = 17;
            /// <summary>
            /// Property Indexer for AppliedAmount 
            /// </summary>
            public const int AppliedAmount = 18;
            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 19;
            /// <summary>
            /// Property Indexer for UnitofMeasure 
            /// </summary>
            public const int UnitofMeasure = 20;
            /// <summary>
            /// Property Indexer for Quantity 
            /// </summary>
            public const int Quantity = 21;
            /// <summary>
            /// Property Indexer for Cost 
            /// </summary>
            public const int Cost = 22;
            /// <summary>
            /// Property Indexer for BillingDate 
            /// </summary>
            public const int BillingDate = 23;
            /// <summary>
            /// Property Indexer for BillingRate 
            /// </summary>
            public const int BillingRate = 24;
            /// <summary>
            /// Property Indexer for BillingCurrency 
            /// </summary>
            public const int BillingCurrency = 25;
            /// <summary>
            /// Property Indexer for RetainageAmount 
            /// </summary>
            public const int RetainageAmount = 26;
            /// <summary>
            /// Property Indexer for RetainageDueDate 
            /// </summary>
            public const int RetainageDueDate = 27;
            /// <summary>
            /// Property Indexer for HasRetainage 
            /// </summary>
            public const int HasRetainage = 28;
            /// <summary>
            /// Property Indexer for FuncDistributionAmount 
            /// </summary>
            public const int FuncDistributionAmount = 29;
            /// <summary>
            /// Property Indexer for FuncDiscountAmount 
            /// </summary>
            public const int FuncDiscountAmount = 30;
            /// <summary>
            /// Property Indexer for FuncAppliedAmount 
            /// </summary>
            public const int FuncAppliedAmount = 31;
            /// <summary>
            /// Property Indexer for FuncRetainageAmount 
            /// </summary>
            public const int FuncRetainageAmount = 32;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 33;
            /// <summary>
            /// Property Indexer for Reference 
            /// </summary>
            public const int Reference = 34;
            /// <summary>
            /// Property Indexer for DocumentLineNumber 
            /// </summary>
            public const int DocumentLineNumber = 35;
            /// <summary>
            /// Property Indexer for VendCurrencyAmountDue 
            /// </summary>
            public const int VendCurrencyAmountDue = 36;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHD1TC = 37;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHD2TC = 38;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHD3TC = 39;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHD4TC = 40;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHD5TC = 41;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHD1HC = 42;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHD2HC = 43;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHD3HC = 44;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHD4HC = 45;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHD5HC = 46;

            /// <summary>
            /// Indexer For Tax Withheld Amount Total
            /// </summary>
            public const int AmtWHDTot = 47;
            
            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 48;

            /// <summary>
            /// Property Indexer for UnformattedContractCode 
            /// </summary>
            public const int UnformattedContractCode = 49;

            #endregion
        }


    }
}
