// /* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of InvoiceDetails Constants 
    /// </summary>
    public partial class InvoiceDetail 
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0022";

        /// <summary>
        /// Contains list of InvoiceDetails Fields Constants
        /// </summary>
        public  class Fields : BaseFields
        {
            
        }

        /// <summary>
        /// Contains list of InvoiceDetails Index Constants
        /// </summary>
        public  class Index : BaseIndex
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 1;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 2;

            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 3;

            /// <summary>
            /// Property Indexer for Destination 
            /// </summary>
            public const int Destination = 89;

            /// <summary>
            /// Property Indexer for RouteNo 
            /// </summary>
            public const int RouteNo = 90;

            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 4;

            /// <summary>
            /// Property Indexer for DistributionDescription 
            /// </summary>
            public const int DistributionDescription = 5;

            /// <summary>
            /// Property Indexer for TaxTotal 
            /// </summary>
            public const int TaxTotal = 7;

            /// <summary>
            /// Property Indexer for ManualTaxEntry 
            /// </summary>
            public const int ManualTaxEntry = 8;

            /// <summary>
            /// Property Indexer for BaseTax1 
            /// </summary>
            public const int BaseTax1 = 9;

            /// <summary>
            /// Property Indexer for BaseTax2 
            /// </summary>
            public const int BaseTax2 = 10;

            /// <summary>
            /// Property Indexer for BaseTax3 
            /// </summary>
            public const int BaseTax3 = 11;

            /// <summary>
            /// Property Indexer for BaseTax4 
            /// </summary>
            public const int BaseTax4 = 12;

            /// <summary>
            /// Property Indexer for BaseTax5 
            /// </summary>
            public const int BaseTax5 = 13;

            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 14;

            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 15;

            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 16;

            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 17;

            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 18;

            /// <summary>
            /// Property Indexer for TaxInclusive1 
            /// </summary>
            public const int TaxInclusive1 = 19;

            /// <summary>
            /// Property Indexer for TaxInclusive2 
            /// </summary>
            public const int TaxInclusive2 = 20;

            /// <summary>
            /// Property Indexer for TaxInclusive3 
            /// </summary>
            public const int TaxInclusive3 = 21;

            /// <summary>
            /// Property Indexer for TaxInclusive4 
            /// </summary>
            public const int TaxInclusive4 = 22;

            /// <summary>
            /// Property Indexer for TaxInclusive5 
            /// </summary>
            public const int TaxInclusive5 = 23;

            /// <summary>
            /// Property Indexer for TaxRate1 
            /// </summary>
            public const int TaxRate1 = 24;

            /// <summary>
            /// Property Indexer for TaxRate2 
            /// </summary>
            public const int TaxRate2 = 25;

            /// <summary>
            /// Property Indexer for TaxRate3 
            /// </summary>
            public const int TaxRate3 = 26;

            /// <summary>
            /// Property Indexer for TaxRate4 
            /// </summary>
            public const int TaxRate4 = 27;

            /// <summary>
            /// Property Indexer for TaxRate5 
            /// </summary>
            public const int TaxRate5 = 28;

            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 29;

            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 30;

            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 31;

            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 32;

            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 33;

            /// <summary>
            /// Property Indexer for GOrLAccount 
            /// </summary>
            public const int GLAccount = 34;

            /// <summary>
            /// Property Indexer for RetainageAllocatedTaxAccount 
            /// </summary>
            public const int RetainageAllocatedTaxAccount = 35;

            /// <summary>
            /// Property Indexer for DistributedAmount 
            /// </summary>
            public const int DistributedAmount = 37;

            /// <summary>
            /// Property Indexer for DistributedAmount 
            /// </summary>
            public const int GLDistributedAmount = 37;

            /// <summary>
            /// Property Indexer for Comment 
            /// </summary>
            public const int Comment = 38;

            /// <summary>
            /// Property Indexer for DistributedAmountBeforeTaxes 
            /// </summary>
            public const int DistributedAmountBeforeTaxes = 40;

            /// <summary>
            /// Property Indexer for TaxAmountIncludedinPrice 
            /// </summary>
            public const int TaxAmountIncludedinPrice = 41;

            /// <summary>
            /// Property Indexer for GOrLDistributedAmount 
            /// </summary>
            public const int GOrLDistributedAmount = 42;

            /// <summary>
            /// Property Indexer for RecoverableTaxAmount1 
            /// </summary>
            public const int RecoverableTaxAmount1 = 43;

            /// <summary>
            /// Property Indexer for RecoverableTaxAmount2 
            /// </summary>
            public const int RecoverableTaxAmount2 = 44;

            /// <summary>
            /// Property Indexer for RecoverableTaxAmount3 
            /// </summary>
            public const int RecoverableTaxAmount3 = 45;

            /// <summary>
            /// Property Indexer for RecoverableTaxAmount4 
            /// </summary>
            public const int RecoverableTaxAmount4 = 46;

            /// <summary>
            /// Property Indexer for RecoverableTaxAmount5 
            /// </summary>
            public const int RecoverableTaxAmount5 = 47;

            /// <summary>
            /// Property Indexer for ExpenseSepTaxAmount1 
            /// </summary>
            public const int ExpenseSepTaxAmount1 = 53;

            /// <summary>
            /// Property Indexer for ExpenseSepTaxAmount2 
            /// </summary>
            public const int ExpenseSepTaxAmount2 = 54;

            /// <summary>
            /// Property Indexer for ExpenseSepTaxAmount3 
            /// </summary>
            public const int ExpenseSepTaxAmount3 = 55;

            /// <summary>
            /// Property Indexer for ExpenseSepTaxAmount4 
            /// </summary>
            public const int ExpenseSepTaxAmount4 = 56;

            /// <summary>
            /// Property Indexer for ExpenseSepTaxAmount5 
            /// </summary>
            public const int ExpenseSepTaxAmount5 = 57;

            /// <summary>
            /// Property Indexer for TaxAllocatedTotal 
            /// </summary>
            public const int TaxAllocatedTotal = 63;

            /// <summary>
            /// Property Indexer for ContractCode 
            /// </summary>
            public const int ContractCode = 64;

            /// <summary>
            /// Property Indexer for ProjectCode 
            /// </summary>
            public const int ProjectCode = 65;

            /// <summary>
            /// Property Indexer for CategoryCode 
            /// </summary>
            public const int CategoryCode = 66;

            /// <summary>
            /// Property Indexer for ProjectOrCategoryResource 
            /// </summary>
            public const int ProjectOrCategoryResource = 67;

            /// <summary>
            /// Property Indexer for TransactionNumber 
            /// </summary>
            public const int TransactionNumber = 68;

            /// <summary>
            /// Property Indexer for CostClass 
            /// </summary>
            public const int CostClass = 69;

            /// <summary>
            /// Property Indexer for BillingType 
            /// </summary>
            public const int BillingType = 70;

            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 71;

            /// <summary>
            /// Property Indexer for UnitofMeasure 
            /// </summary>
            public const int UnitofMeasure = 72;

            /// <summary>
            /// Property Indexer for Quantity 
            /// </summary>
            public const int Quantity = 73;

            /// <summary>
            /// Property Indexer for Cost 
            /// </summary>
            public const int Cost = 74;

            /// <summary>
            /// Property Indexer for BillingDate 
            /// </summary>
            public const int BillingDate = 75;

            /// <summary>
            /// Property Indexer for BillingRate 
            /// </summary>
            public const int BillingRate = 76;

            /// <summary>
            /// Property Indexer for BillingCurrency 
            /// </summary>
            public const int BillingCurrency = 77;

            /// <summary>
            /// Property Indexer for CommentAttached 
            /// </summary>
            public const int CommentAttached = 78;

            /// <summary>
            /// Property Indexer for Discountable 
            /// </summary>
            public const int Discountable = 79;

            /// <summary>
            /// Property Indexer for OriginalLineIdentifier 
            /// </summary>
            public const int OriginalLineIdentifier = 80;

            /// <summary>
            /// Property Indexer for RetainageAmount 
            /// </summary>
            public const int RetainageAmount = 81;

            /// <summary>
            /// Property Indexer for PercentRetained 
            /// </summary>
            public const int PercentRetained = 82;

            /// <summary>
            /// Property Indexer for DaysRetained 
            /// </summary>
            public const int DaysRetained = 83;

            /// <summary>
            /// Property Indexer for RetainageDueDate 
            /// </summary>
            public const int RetainageDueDate = 84;

            /// <summary>
            /// Property Indexer for RetainageDueDateOverride 
            /// </summary>
            public const int RetainageDueDateOverride = 85;

            /// <summary>
            /// Property Indexer for RetainageAmountOverride 
            /// </summary>
            public const int RetainageAmountOverride = 86;

            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 87;

            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 88;

            /// <summary>
            /// Property Indexer for DestExists 
            /// </summary>
            public const int DestExists = 91;

            /// <summary>
            /// Property Indexer for DestDescription 
            /// </summary>
            public const int DestDescription = 92;

            /// <summary>
            /// Property Indexer for DestStatus 
            /// </summary>
            public const int DestStatus = 93;

            /// <summary>
            /// Property Indexer for DistCodeExists 
            /// </summary>
            public const int DistCodeExists = 95;

            /// <summary>
            /// Property Indexer for DistCodeDescription 
            /// </summary>
            public const int DistCodeDescription = 96;

            /// <summary>
            /// Property Indexer for DistCodeStatus 
            /// </summary>
            public const int DistCodeStatus = 97;

            /// <summary>
            /// Property Indexer for RouteExists 
            /// </summary>
            public const int RouteExists = 100;

            /// <summary>
            /// Property Indexer for RouteDescription 
            /// </summary>
            public const int RouteDescription = 101;

            /// <summary>
            /// Property Indexer for RouteStatus 
            /// </summary>
            public const int RouteStatus = 102;

            /// <summary>
            /// Property Indexer for AcctExists 
            /// </summary>
            public const int AcctExists = 105;

            /// <summary>
            /// Property Indexer for AcctDescription 
            /// </summary>
            public const int AcctDescription = 106;

            /// <summary>
            /// Property Indexer for AcctStatus 
            /// </summary>
            public const int AcctStatus = 107;

            /// <summary>
            /// Property Indexer for RetainageDistributionAmount 
            /// </summary>
            public const int RetainageDistributionAmount = 110;

            /// <summary>
            /// Property Indexer for InvoicedRetainageDistribution 
            /// </summary>
            public const int InvoicedRetainageDistribution = 111;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1 
            /// </summary>
            public const int TaxReportingAmount1 = 112;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2 
            /// </summary>
            public const int TaxReportingAmount2 = 113;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3 
            /// </summary>
            public const int TaxReportingAmount3 = 114;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4 
            /// </summary>
            public const int TaxReportingAmount4 = 115;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5 
            /// </summary>
            public const int TaxReportingAmount5 = 116;

            /// <summary>
            /// Property Indexer for TaxReportingTotal 
            /// </summary>
            public const int TaxReportingTotal = 117;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedTax 
            /// </summary>
            public const int TaxReportingAllocatedTax = 118;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedTax1 
            /// </summary>
            public const int TaxReportingExpensedTax1 = 119;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedTax2 
            /// </summary>
            public const int TaxReportingExpensedTax2 = 120;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedTax3 
            /// </summary>
            public const int TaxReportingExpensedTax3 = 121;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedTax4 
            /// </summary>
            public const int TaxReportingExpensedTax4 = 122;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedTax5 
            /// </summary>
            public const int TaxReportingExpensedTax5 = 123;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableTax1 
            /// </summary>
            public const int TaxReportingRecoverableTax1 = 124;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableTax2 
            /// </summary>
            public const int TaxReportingRecoverableTax2 = 125;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableTax3 
            /// </summary>
            public const int TaxReportingRecoverableTax3 = 126;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableTax4 
            /// </summary>
            public const int TaxReportingRecoverableTax4 = 127;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableTax5 
            /// </summary>
            public const int TaxReportingRecoverableTax5 = 128;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1 
            /// </summary>
            public const int RetainageTaxBase1 = 129;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2 
            /// </summary>
            public const int RetainageTaxBase2 = 130;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3 
            /// </summary>
            public const int RetainageTaxBase3 = 131;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4 
            /// </summary>
            public const int RetainageTaxBase4 = 132;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5 
            /// </summary>
            public const int RetainageTaxBase5 = 133;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1 
            /// </summary>
            public const int RetainageTaxAmount1 = 134;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2 
            /// </summary>
            public const int RetainageTaxAmount2 = 135;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3 
            /// </summary>
            public const int RetainageTaxAmount3 = 136;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4 
            /// </summary>
            public const int RetainageTaxAmount4 = 137;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5 
            /// </summary>
            public const int RetainageTaxAmount5 = 138;

            /// <summary>
            /// Property Indexer for FuncTaxBase1 
            /// </summary>
            public const int FuncTaxBase1 = 139;

            /// <summary>
            /// Property Indexer for FuncTaxBase2 
            /// </summary>
            public const int FuncTaxBase2 = 140;

            /// <summary>
            /// Property Indexer for FuncTaxBase3 
            /// </summary>
            public const int FuncTaxBase3 = 141;

            /// <summary>
            /// Property Indexer for FuncTaxBase4 
            /// </summary>
            public const int FuncTaxBase4 = 142;

            /// <summary>
            /// Property Indexer for FuncTaxBase5 
            /// </summary>
            public const int FuncTaxBase5 = 143;

            /// <summary>
            /// Property Indexer for FuncTaxAmount1 
            /// </summary>
            public const int FuncTaxAmount1 = 144;

            /// <summary>
            /// Property Indexer for FuncTaxAmount2 
            /// </summary>
            public const int FuncTaxAmount2 = 145;

            /// <summary>
            /// Property Indexer for FuncTaxAmount3 
            /// </summary>
            public const int FuncTaxAmount3 = 146;

            /// <summary>
            /// Property Indexer for FuncTaxAmount4 
            /// </summary>
            public const int FuncTaxAmount4 = 147;

            /// <summary>
            /// Property Indexer for FuncTaxAmount5 
            /// </summary>
            public const int FuncTaxAmount5 = 148;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount1 
            /// </summary>
            public const int FuncRetainageTaxAmount1 = 149;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount2 
            /// </summary>
            public const int FuncRetainageTaxAmount2 = 150;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount3 
            /// </summary>
            public const int FuncRetainageTaxAmount3 = 151;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount4 
            /// </summary>
            public const int FuncRetainageTaxAmount4 = 152;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount5 
            /// </summary>
            public const int FuncRetainageTaxAmount5 = 153;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount1 
            /// </summary>
            public const int FuncTaxRecoverableAmount1 = 154;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount2 
            /// </summary>
            public const int FuncTaxRecoverableAmount2 = 155;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount3 
            /// </summary>
            public const int FuncTaxRecoverableAmount3 = 156;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount4 
            /// </summary>
            public const int FuncTaxRecoverableAmount4 = 157;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount5 
            /// </summary>
            public const int FuncTaxRecoverableAmount5 = 158;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseSepAmount1 
            /// </summary>
            public const int FuncTaxExpenseSepAmount1 = 159;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseSepAmount2 
            /// </summary>
            public const int FuncTaxExpenseSepAmount2 = 160;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseSepAmount3 
            /// </summary>
            public const int FuncTaxExpenseSepAmount3 = 161;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseSepAmount4 
            /// </summary>
            public const int FuncTaxExpenseSepAmount4 = 162;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseSepAmount5 
            /// </summary>
            public const int FuncTaxExpenseSepAmount5 = 163;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedTotal 
            /// </summary>
            public const int FuncTaxAllocatedTotal = 164;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount1 
            /// </summary>
            public const int FuncTaxAllocatedAmount1 = 165;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount2 
            /// </summary>
            public const int FuncTaxAllocatedAmount2 = 166;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount3 
            /// </summary>
            public const int FuncTaxAllocatedAmount3 = 167;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount4 
            /// </summary>
            public const int FuncTaxAllocatedAmount4 = 168;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount5 
            /// </summary>
            public const int FuncTaxAllocatedAmount5 = 169;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1 
            /// </summary>
            public const int TaxAllocatedAmount1 = 170;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2 
            /// </summary>
            public const int TaxAllocatedAmount2 = 171;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3 
            /// </summary>
            public const int TaxAllocatedAmount3 = 172;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4 
            /// </summary>
            public const int TaxAllocatedAmount4 = 173;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5 
            /// </summary>
            public const int TaxAllocatedAmount5 = 174;

            /// <summary>
            /// Property Indexer for FuncCost 
            /// </summary>
            public const int FuncCost = 175;

            /// <summary>
            /// Property Indexer for FuncDistributedAmount 
            /// </summary>
            public const int FuncDistributedAmount = 176;

            /// <summary>
            /// Property Indexer for FuncDistributionNetofTaxes 
            /// </summary>
            public const int FuncDistributionNetofTaxes = 177;

            /// <summary>
            /// Property Indexer for FuncRetainageAmount 
            /// </summary>
            public const int FuncRetainageAmount = 178;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAllocated 
            /// </summary>
            public const int FuncRetainageTaxAllocated = 179;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocated 
            /// </summary>
            public const int RetainageTaxAllocated = 180;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxExpensed 
            /// </summary>
            public const int FuncRetainageTaxExpensed = 181;

            /// <summary>
            /// Property Indexer for RetainageTaxExpensed 
            /// </summary>
            public const int RetainageTaxExpensed = 182;

            /// <summary>
            /// Property Indexer for RetainageTaxTotal 
            /// </summary>
            public const int RetainageTaxTotal = 183;

            /// <summary>
            /// Property Indexer for TaxAmount1Total 
            /// </summary>
            public const int TaxAmount1Total = 184;

            /// <summary>
            /// Property Indexer for TaxAmount2Total 
            /// </summary>
            public const int TaxAmount2Total = 185;

            /// <summary>
            /// Property Indexer for TaxAmount3Total 
            /// </summary>
            public const int TaxAmount3Total = 186;

            /// <summary>
            /// Property Indexer for TaxAmount4Total 
            /// </summary>
            public const int TaxAmount4Total = 187;

            /// <summary>
            /// Property Indexer for TaxAmount5Total 
            /// </summary>
            public const int TaxAmount5Total = 188;

            /// <summary>
            /// Property Indexer for CurrRetainageAmount 
            /// </summary>
            public const int CurrRetainageAmount = 189;

            /// <summary>
            /// Property Indexer for CurrRetainageDistAmount 
            /// </summary>
            public const int CurrRetainageDistAmount = 190;

            /// <summary>
            /// Property Indexer for FixedAsset 
            /// </summary>
            public const int FixedAsset = 191;

            /// <summary>
            /// Property Indexer for SageFixedAssetsOrgid 
            /// </summary>
            public const int SageFixedAssetsOrgid = 192;

            /// <summary>
            /// Property Indexer for SageFixedAssetsDatabase 
            /// </summary>
            public const int SageFixedAssetsDatabase = 193;

            /// <summary>
            /// Property Indexer for SageFixedAssetsCompanyOrOrg 
            /// </summary>
            public const int SageFixedAssetsCompanyOrOrg = 194;

            /// <summary>
            /// Property Indexer for SageFixedAssetsTemplate 
            /// </summary>
            public const int SageFixedAssetsTemplate = 195;

            /// <summary>
            /// Property Indexer for SageFixedAssetsAssetDescript 
            /// </summary>
            public const int SageFixedAssetsAssetDescript = 196;
            
            /// <summary>
            /// Property Indexer for SageFixedAssetsAssetDescript 
            /// </summary>
            public const int SageFixedAssetsAssetDescription = 196;

            /// <summary>
            /// Property Indexer for SeparateAssets 
            /// </summary>
            public const int SeparateAssets = 197;

            /// <summary>
            /// Property Indexer for SageFixedAssetsQuantity 
            /// </summary>
            public const int SageFixedAssetsQuantity = 198;

            /// <summary>
            /// Property Indexer for SageFixedAssetsUnitofMeasure 
            /// </summary>
            public const int SageFixedAssetsUnitofMeasure = 199;

            /// <summary>
            /// Property Indexer for SageFixedAssetsAssetValue 
            /// </summary>
            public const int SageFixedAssetsAssetValue = 200;

            /// <summary>
            /// Property Indexer for SageFixedAssetsFuncAssetVa 
            /// </summary>
            public const int SageFixedAssetsFuncAssetVa = 201;

            #endregion
        }
    }
}
