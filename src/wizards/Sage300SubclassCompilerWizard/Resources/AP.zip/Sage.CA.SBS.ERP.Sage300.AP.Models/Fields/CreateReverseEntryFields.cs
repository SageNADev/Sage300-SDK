/* Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved. */
/* Portions co-modified with Claude Code */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of CreateReverseEntry Constants for APRIB (AP0530)
    /// </summary>
    public partial class CreateReverseEntry
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0530";

        /// <summary>
        /// Contains list of CreateReverseEntry Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for OptionSwitch
            /// </summary>
            public const string OptionSwitch = "SWOPTION";

            /// <summary>
            /// Property for SelectedBatchId
            /// </summary>
            public const string SelectedBatchId = "FRBTCHID";

            /// <summary>
            /// Property for SelectedEntry
            /// </summary>
            public const string SelectedEntry = "FRENTRY";

            /// <summary>
            /// Property for ReverseBatchId
            /// </summary>
            public const string ReverseBatchId = "BATCHID";

            /// <summary>
            /// Property for ReverseBatchDescription
            /// </summary>
            public const string ReverseBatchDescription = "BTCHDESC";

            /// <summary>
            /// Property for DocumentNumberOption
            /// </summary>
            public const string DocumentNumberOption = "DOCNUMOP";

            /// <summary>
            /// Property for ReverseDocumentNumber
            /// </summary>
            public const string ReverseDocumentNumber = "DOCNUMREV";

            /// <summary>
            /// Property for HeaderDescriptionOption
            /// </summary>
            public const string HeaderDescriptionOption = "HDRDESCOP";

            /// <summary>
            /// Property for HeaderDescription
            /// </summary>
            public const string HeaderDescription = "HDRDESC";

            /// <summary>
            /// Property for CreatedReverseEntryNo
            /// </summary>
            public const string CreatedReverseEntryNo = "CRENTRY";

            #endregion
        }

        /// <summary>
        /// Contains list of CreateReverseEntry Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for OptionSwitch
            /// </summary>
            public const int OptionSwitch = 1;

            /// <summary>
            /// Property Indexer for SelectedBatchId
            /// </summary>
            public const int SelectedBatchId = 2;

            /// <summary>
            /// Property Indexer for SelectedEntry
            /// </summary>
            public const int SelectedEntry = 3;

            /// <summary>
            /// Property Indexer for ReverseBatchId
            /// </summary>
            public const int ReverseBatchId = 4;

            /// <summary>
            /// Property Indexer for ReverseBatchDescription
            /// </summary>
            public const int ReverseBatchDescription = 5;

            /// <summary>
            /// Property Indexer for DocumentNumberOption
            /// </summary>
            public const int DocumentNumberOption = 6;

            /// <summary>
            /// Property Indexer for ReverseDocumentNumber
            /// </summary>
            public const int ReverseDocumentNumber = 7;

            /// <summary>
            /// Property Indexer for HeaderDescriptionOption
            /// </summary>
            public const int HeaderDescriptionOption = 8;

            /// <summary>
            /// Property Indexer for HeaderDescription
            /// </summary>
            public const int HeaderDescription = 9;

            /// <summary>
            /// Property Indexer for CreatedReverseEntryNo
            /// </summary>
            public const int CreatedReverseEntryNo = 10;

            #endregion
        }
    }
}
