/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of VendorStatistics Constants 
    /// </summary>
    public partial class VendorStatistics
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0019";

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0019";

        /// <summary>
        /// Contains list of VendorStatistics Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties

            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "VENDORID";

            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string Year = "CNTYR";

            /// <summary>
            /// Property for Period 
            /// </summary>
            public const string Period = "CNTPERD";

            /// <summary>
            /// Property for NumberofInvoices 
            /// </summary>
            public const string NumberofInvoices = "CNTINVC";

            /// <summary>
            /// Property for NumberofCreditNotes 
            /// </summary>
            public const string NumberofCreditNotes = "CNTCR";

            /// <summary>
            /// Property for NumberofDebitNotes 
            /// </summary>
            public const string NumberofDebitNotes = "CNTDR";

            /// <summary>
            /// Property for NumberofPayments 
            /// </summary>
            public const string NumberofPayments = "CNTPAYM";

            /// <summary>
            /// Property for NumberofDiscounts 
            /// </summary>
            public const string NumberofDiscounts = "CNTDISC";

            /// <summary>
            /// Property for NumberofDiscountsLost 
            /// </summary>
            public const string NumberofDiscountsLost = "CNTLOST";

            /// <summary>
            /// Property for NumberofAdjustments 
            /// </summary>
            public const string NumberofAdjustments = "CNTADJ";

            /// <summary>
            /// Property for NumberofPaidInvoices 
            /// </summary>
            public const string NumberofPaidInvoices = "CNTINVCPD";

            /// <summary>
            /// Property for NumberofDaystoPay 
            /// </summary>
            public const string NumberofDaystoPay = "CNTDTOPAY";

            /// <summary>
            /// Property for TotalInvoicesinFuncCurrency 
            /// </summary>
            public const string TotalInvoicesinFuncCurrency = "AMTINVCHC";

            /// <summary>
            /// Property for TotalCreditsinFuncCurrency 
            /// </summary>
            public const string TotalCreditsinFuncCurrency = "AMTCRHC";

            /// <summary>
            /// Property for TotalDebitsinFuncCurrency 
            /// </summary>
            public const string TotalDebitsinFuncCurrency = "AMTDRHC";

            /// <summary>
            /// Property for TotalPaymentsinFuncCurrency 
            /// </summary>
            public const string TotalPaymentsinFuncCurrency = "AMTPAYMHC";

            /// <summary>
            /// Property for TotalDiscountsinFuncCurr 
            /// </summary>
            public const string TotalDiscountsinFuncCurr = "AMTDISCHC";

            /// <summary>
            /// Property for TotalDiscountsLostFuncCur 
            /// </summary>
            public const string TotalDiscountsLostFuncCur = "AMTLOSTHC";

            /// <summary>
            /// Property for TotalAdjustmentsinFuncCurr 
            /// </summary>
            public const string TotalAdjustmentsinFuncCurr = "AMTADJHC";

            /// <summary>
            /// Property for AMTPURHC 
            /// </summary>
            public const string AMTPURHC = "AMTPURHC";

            /// <summary>
            /// Property for TotalInvoicesPdinFuncCurr 
            /// </summary>
            public const string TotalInvoicesPdinFuncCurr = "AMTINVPDHC";

            /// <summary>
            /// Property for TotalInvoicesinVendCurr 
            /// </summary>
            public const string TotalInvoicesinVendCurr = "AMTINVCTC";

            /// <summary>
            /// Property for TotalCreditsinVendCurr 
            /// </summary>
            public const string TotalCreditsinVendCurr = "AMTCRTC";

            /// <summary>
            /// Property for TotalDebitsinVendCurr 
            /// </summary>
            public const string TotalDebitsinVendCurr = "AMTDRTC";

            /// <summary>
            /// Property for TotalPaymentsinVendCurr 
            /// </summary>
            public const string TotalPaymentsinVendCurr = "AMTPAYMTC";

            /// <summary>
            /// Property for TotalDiscountsinVendCurr 
            /// </summary>
            public const string TotalDiscountsinVendCurr = "AMTDISCTC";

            /// <summary>
            /// Property for TotalDiscountsLostinVendCu 
            /// </summary>
            public const string TotalDiscountsLostinVendCu = "AMTLOSTTC";

            /// <summary>
            /// Property for TotalAdjustmentsinVendCurr 
            /// </summary>
            public const string TotalAdjustmentsinVendCurr = "AMTADJTC";

            /// <summary>
            /// Property for AMTPURTC 
            /// </summary>
            public const string AMTPURTC = "AMTPURTC";

            /// <summary>
            /// Property for TotalInvoicesPdinVendCurr 
            /// </summary>
            public const string TotalInvoicesPdinVendCurr = "AMTINPDTC";

            /// <summary>
            /// Property for RevaluationBalinVendCurr 
            /// </summary>
            public const string RevaluationBalinVendCurr = "AMTBLRVLTC";

            /// <summary>
            /// Property for CNTPUR 
            /// </summary>
            public const string CNTPUR = "CNTPUR";

            /// <summary>
            /// Property for AverageDaystoPay 
            /// </summary>
            public const string AverageDaystoPay = "AVGDAYSPAY";

            /// <summary>
            /// Property for YTDNumberofInvoices 
            /// </summary>
            public const string YTDNumberofInvoices = "YTDCNTIN";

            /// <summary>
            /// Property for YTDNumberofCreditNotes 
            /// </summary>
            public const string YTDNumberofCreditNotes = "YTDCNTCR";

            /// <summary>
            /// Property for YTDNumberofDebitNotes 
            /// </summary>
            public const string YTDNumberofDebitNotes = "YTDCNTDR";

            /// <summary>
            /// Property for YTDNumberofPayments 
            /// </summary>
            public const string YTDNumberofPayments = "YTDCNTPY";

            /// <summary>
            /// Property for YTDNumberofDiscounts 
            /// </summary>
            public const string YTDNumberofDiscounts = "YTDCNTED";

            /// <summary>
            /// Property for YTDNumberofDiscountsLost 
            /// </summary>
            public const string YTDNumberofDiscountsLost = "YTDCNTLOST";

            /// <summary>
            /// Property for YTDNumberofAdjustments 
            /// </summary>
            public const string YTDNumberofAdjustments = "YTDCNTAD";

            /// <summary>
            /// Property for YTDNumberofPaidInvoices 
            /// </summary>
            public const string YTDNumberofPaidInvoices = "YTDCNTINPD";

            /// <summary>
            /// Property for YTDNumberofDaystoPay 
            /// </summary>
            public const string YTDNumberofDaystoPay = "YTDCNTDTP";

            /// <summary>
            /// Property for YTDInvoicesinFuncCurr 
            /// </summary>
            public const string YTDInvoicesinFuncCurr = "YTDHCIN";

            /// <summary>
            /// Property for YTDCreditsinFuncCurr 
            /// </summary>
            public const string YTDCreditsinFuncCurr = "YTDHCCR";

            /// <summary>
            /// Property for YTDDebitsinFuncCurr 
            /// </summary>
            public const string YTDDebitsinFuncCurr = "YTDHCDR";

            /// <summary>
            /// Property for YTDPaymentsinFuncCurr 
            /// </summary>
            public const string YTDPaymentsinFuncCurr = "YTDHCPY";

            /// <summary>
            /// Property for YTDDiscountsinFuncCurr 
            /// </summary>
            public const string YTDDiscountsinFuncCurr = "YTDHCED";

            /// <summary>
            /// Property for YTDDiscountsLostFuncCurr 
            /// </summary>
            public const string YTDDiscountsLostFuncCurr = "YTDHCLOST";

            /// <summary>
            /// Property for YTDAdjustmentsinFuncCurr 
            /// </summary>
            public const string YTDAdjustmentsinFuncCurr = "YTDHCAD";

            /// <summary>
            /// Property for YTDInvoicesPdinFuncCurr 
            /// </summary>
            public const string YTDInvoicesPdinFuncCurr = "YTDHCINPD";

            /// <summary>
            /// Property for YTDInvoicesinVendCurr 
            /// </summary>
            public const string YTDInvoicesinVendCurr = "YTDTCIN";

            /// <summary>
            /// Property for YTDCreditsinVendCurr 
            /// </summary>
            public const string YTDCreditsinVendCurr = "YTDTCCR";

            /// <summary>
            /// Property for YTDDebitsinVendCurr 
            /// </summary>
            public const string YTDDebitsinVendCurr = "YTDTCDR";

            /// <summary>
            /// Property for YTDPaymentsinVendCurr 
            /// </summary>
            public const string YTDPaymentsinVendCurr = "YTDTCPY";

            /// <summary>
            /// Property for YTDDiscountsinVendCurr 
            /// </summary>
            public const string YTDDiscountsinVendCurr = "YTDTCED";

            /// <summary>
            /// Property for YTDDiscountsLostinVendCurr 
            /// </summary>
            public const string YTDDiscountsLostinVendCurr = "YTDTCLOST";

            /// <summary>
            /// Property for YTDAdjustmentsinVendCurr 
            /// </summary>
            public const string YTDAdjustmentsinVendCurr = "YTDTCAD";

            /// <summary>
            /// Property for YTDInvoicesPdinVendCurr 
            /// </summary>
            public const string YTDInvoicesPdinVendCurr = "YTDTCINPD";

            /// <summary>
            /// Property for YTDAverageDaystoPay 
            /// </summary>
            public const string YTDAverageDaystoPay = "YTDCNTADTP";

            /// <summary>
            /// Property for EnableYTDCalculations 
            /// </summary>
            public const string EnableYTDCalculations = "YTDACTIVE";

            #endregion
        }

        /// <summary>
        /// Contains list of VendorStatistics Index Constants
        /// </summary>
        public class Index
        {

            #region Properties

            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 1;

            /// <summary>
            /// Property Indexer for Year 
            /// </summary>
            public const int Year = 2;

            /// <summary>
            /// Property Indexer for Period 
            /// </summary>
            public const int Period = 3;

            /// <summary>
            /// Property Indexer for NumberofInvoices 
            /// </summary>
            public const int NumberofInvoices = 4;

            /// <summary>
            /// Property Indexer for NumberofCreditNotes 
            /// </summary>
            public const int NumberofCreditNotes = 5;

            /// <summary>
            /// Property Indexer for NumberofDebitNotes 
            /// </summary>
            public const int NumberofDebitNotes = 6;

            /// <summary>
            /// Property Indexer for NumberofPayments 
            /// </summary>
            public const int NumberofPayments = 7;

            /// <summary>
            /// Property Indexer for NumberofDiscounts 
            /// </summary>
            public const int NumberofDiscounts = 8;

            /// <summary>
            /// Property Indexer for NumberofDiscountsLost 
            /// </summary>
            public const int NumberofDiscountsLost = 9;

            /// <summary>
            /// Property Indexer for NumberofAdjustments 
            /// </summary>
            public const int NumberofAdjustments = 10;

            /// <summary>
            /// Property Indexer for NumberofPaidInvoices 
            /// </summary>
            public const int NumberofPaidInvoices = 11;

            /// <summary>
            /// Property Indexer for NumberofDaystoPay 
            /// </summary>
            public const int NumberofDaystoPay = 12;

            /// <summary>
            /// Property Indexer for TotalInvoicesinFuncCurrency 
            /// </summary>
            public const int TotalInvoicesinFuncCurrency = 13;

            /// <summary>
            /// Property Indexer for TotalCreditsinFuncCurrency 
            /// </summary>
            public const int TotalCreditsinFuncCurrency = 14;

            /// <summary>
            /// Property Indexer for TotalDebitsinFuncCurrency 
            /// </summary>
            public const int TotalDebitsinFuncCurrency = 15;

            /// <summary>
            /// Property Indexer for TotalPaymentsinFuncCurrency 
            /// </summary>
            public const int TotalPaymentsinFuncCurrency = 16;

            /// <summary>
            /// Property Indexer for TotalDiscountsinFuncCurr 
            /// </summary>
            public const int TotalDiscountsinFuncCurr = 17;

            /// <summary>
            /// Property Indexer for TotalDiscountsLostFuncCur 
            /// </summary>
            public const int TotalDiscountsLostFuncCur = 18;

            /// <summary>
            /// Property Indexer for TotalAdjustmentsinFuncCurr 
            /// </summary>
            public const int TotalAdjustmentsinFuncCurr = 19;
      
            /// <summary>
            /// Property Indexer for AMTPURHC 
            /// </summary>
            public const int AMTPURHC = 20;

            /// <summary>
            /// Property Indexer for TotalInvoicesPdinFuncCurr 
            /// </summary>
            public const int TotalInvoicesPdinFuncCurr = 21;

            /// <summary>
            /// Property Indexer for TotalInvoicesinVendCurr 
            /// </summary>
            public const int TotalInvoicesinVendCurr = 22;

            /// <summary>
            /// Property Indexer for TotalCreditsinVendCurr 
            /// </summary>
            public const int TotalCreditsinVendCurr = 23;

            /// <summary>
            /// Property Indexer for TotalDebitsinVendCurr 
            /// </summary>
            public const int TotalDebitsinVendCurr = 24;

            /// <summary>
            /// Property Indexer for TotalPaymentsinVendCurr 
            /// </summary>
            public const int TotalPaymentsinVendCurr = 25;

            /// <summary>
            /// Property Indexer for TotalDiscountsinVendCurr 
            /// </summary>
            public const int TotalDiscountsinVendCurr = 26;

            /// <summary>
            /// Property Indexer for TotalDiscountsLostinVendCu 
            /// </summary>
            public const int TotalDiscountsLostinVendCu = 27;

            /// <summary>
            /// Property Indexer for TotalAdjustmentsinVendCurr 
            /// </summary>
            public const int TotalAdjustmentsinVendCurr = 28;
       
            /// <summary>
            /// Property Indexer for AMTPURTC 
            /// </summary>
            public const int AMTPURTC = 29;

            /// <summary>
            /// Property Indexer for TotalInvoicesPdinVendCurr 
            /// </summary>
            public const int TotalInvoicesPdinVendCurr = 30;

            /// <summary>
            /// Property Indexer for RevaluationBalinVendCurr 
            /// </summary>
            public const int RevaluationBalinVendCurr = 31;
       
            /// <summary>
            /// Property Indexer for CNTPUR 
            /// </summary>
            public const int CNTPUR = 32;

            /// <summary>
            /// Property Indexer for AverageDaystoPay 
            /// </summary>
            public const int AverageDaystoPay = 33;

            /// <summary>
            /// Property Indexer for YTDNumberofInvoices 
            /// </summary>
            public const int YTDNumberofInvoices = 34;

            /// <summary>
            /// Property Indexer for YTDNumberofCreditNotes 
            /// </summary>
            public const int YTDNumberofCreditNotes = 35;

            /// <summary>
            /// Property Indexer for YTDNumberofDebitNotes 
            /// </summary>
            public const int YTDNumberofDebitNotes = 36;

            /// <summary>
            /// Property Indexer for YTDNumberofPayments 
            /// </summary>
            public const int YTDNumberofPayments = 37;

            /// <summary>
            /// Property Indexer for YTDNumberofDiscounts 
            /// </summary>
            public const int YTDNumberofDiscounts = 38;

            /// <summary>
            /// Property Indexer for YTDNumberofDiscountsLost 
            /// </summary>
            public const int YTDNumberofDiscountsLost = 39;

            /// <summary>
            /// Property Indexer for YTDNumberofAdjustments 
            /// </summary>
            public const int YTDNumberofAdjustments = 40;

            /// <summary>
            /// Property Indexer for YTDNumberofPaidInvoices 
            /// </summary>
            public const int YTDNumberofPaidInvoices = 41;

            /// <summary>
            /// Property Indexer for YTDNumberofDaystoPay 
            /// </summary>
            public const int YTDNumberofDaystoPay = 42;

            /// <summary>
            /// Property Indexer for YTDInvoicesinFuncCurr 
            /// </summary>
            public const int YTDInvoicesinFuncCurr = 43;

            /// <summary>
            /// Property Indexer for YTDCreditsinFuncCurr 
            /// </summary>
            public const int YTDCreditsinFuncCurr = 44;

            /// <summary>
            /// Property Indexer for YTDDebitsinFuncCurr 
            /// </summary>
            public const int YTDDebitsinFuncCurr = 45;

            /// <summary>
            /// Property Indexer for YTDPaymentsinFuncCurr 
            /// </summary>
            public const int YTDPaymentsinFuncCurr = 46;

            /// <summary>
            /// Property Indexer for YTDDiscountsinFuncCurr 
            /// </summary>
            public const int YTDDiscountsinFuncCurr = 47;

            /// <summary>
            /// Property Indexer for YTDDiscountsLostFuncCurr 
            /// </summary>
            public const int YTDDiscountsLostFuncCurr = 48;

            /// <summary>
            /// Property Indexer for YTDAdjustmentsinFuncCurr 
            /// </summary>
            public const int YTDAdjustmentsinFuncCurr = 49;

            /// <summary>
            /// Property Indexer for YTDInvoicesPdinFuncCurr 
            /// </summary>
            public const int YTDInvoicesPdinFuncCurr = 50;

            /// <summary>
            /// Property Indexer for YTDInvoicesinVendCurr 
            /// </summary>
            public const int YTDInvoicesinVendCurr = 51;

            /// <summary>
            /// Property Indexer for YTDCreditsinVendCurr 
            /// </summary>
            public const int YTDCreditsinVendCurr = 52;

            /// <summary>
            /// Property Indexer for YTDDebitsinVendCurr 
            /// </summary>
            public const int YTDDebitsinVendCurr = 53;

            /// <summary>
            /// Property Indexer for YTDPaymentsinVendCurr 
            /// </summary>
            public const int YTDPaymentsinVendCurr = 54;

            /// <summary>
            /// Property Indexer for YTDDiscountsinVendCurr 
            /// </summary>
            public const int YTDDiscountsinVendCurr = 55;

            /// <summary>
            /// Property Indexer for YTDDiscountsLostinVendCurr 
            /// </summary>
            public const int YTDDiscountsLostinVendCurr = 56;

            /// <summary>
            /// Property Indexer for YTDAdjustmentsinVendCurr 
            /// </summary>
            public const int YTDAdjustmentsinVendCurr = 57;

            /// <summary>
            /// Property Indexer for YTDInvoicesPdinVendCurr 
            /// </summary>
            public const int YTDInvoicesPdinVendCurr = 58;

            /// <summary>
            /// Property Indexer for YTDAverageDaystoPay 
            /// </summary>
            public const int YTDAverageDaystoPay = 59;

            /// <summary>
            /// Property Indexer for EnableYTDCalculations 
            /// </summary>
            public const int EnableYTDCalculations = 60;

            #endregion
        }


    }
}
