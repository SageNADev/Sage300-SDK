/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of InvoicingOptions Constants 
    /// </summary>
    public partial class OptionsInvoicing
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0002";

        /// <summary>
        /// Contains list of InvoicingOptions Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for OptionsRecordKey 
            /// </summary>
            public const string OptionsRecordKey = "RECID02";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for NextInvoiceBatchNumber 
            /// </summary>
            public const string NextInvoiceBatchNumber = "INVCBTCH";

            /// <summary>
            /// Property for Use1099OrCPRSReporting 
            /// </summary>
            public const string Use1099OrCPRSReporting = "SWUSE1099";

            /// <summary>
            /// Property for NextInvoicePostingSeqNumber 
            /// </summary>
            public const string NextInvoicePostingSeqNumber = "CNTNEXTINV";

            /// <summary>
            /// Property for Edit1099OrCPRSAmounts 
            /// </summary>
            public const string Edit1099OrCPRSAmounts = "SWEDIT1099";

            /// <summary>
            /// Property for Copy1099OrCPRSAmountfromTotal 
            /// </summary>
            public const string Copy1099OrCPRSAmountfromTotal = "SW1099COPY";

            /// <summary>
            /// Property for DefaultPostingDate 
            /// </summary>
            public const string DefaultPostingDate = "SWDATEBUS";

            #endregion
        }

        /// <summary>
        /// Contains list of InvoicingOptions Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for OptionsRecordKey 
            /// </summary>
            public const int OptionsRecordKey = 1;

            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 2;

            /// <summary>
            /// Property Indexer for NextInvoiceBatchNumber 
            /// </summary>
            public const int NextInvoiceBatchNumber = 3;

            /// <summary>
            /// Property Indexer for Use1099OrCPRSReporting 
            /// </summary>
            public const int Use1099OrCPRSReporting = 6;

            /// <summary>
            /// Property Indexer for NextInvoicePostingSeqNumber 
            /// </summary>
            public const int NextInvoicePostingSeqNumber = 32;

            /// <summary>
            /// Property Indexer for Edit1099OrCPRSAmounts 
            /// </summary>
            public const int Edit1099OrCPRSAmounts = 36;

            /// <summary>
            /// Property Indexer for Copy1099OrCPRSAmountfromTotal 
            /// </summary>
            public const int Copy1099OrCPRSAmountfromTotal = 37;

            /// <summary>
            /// Property Indexer for DefaultPostingDate 
            /// </summary>
            public const int DefaultPostingDate = 38;

            #endregion
        }
    }
}


	