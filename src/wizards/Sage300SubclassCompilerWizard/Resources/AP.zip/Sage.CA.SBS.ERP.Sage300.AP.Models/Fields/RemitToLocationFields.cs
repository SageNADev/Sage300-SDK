// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Remit-To Locations Constants 
    /// </summary>
    public partial class RemitToLocation
    {
        /// <summary>
        /// Entity Name for Import/Export
        /// </summary>
        public const string EntityName = "AP0018";

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0018";

        /// <summary>
        /// Contains list of Remit-To Locations Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Vendor Number 
            /// </summary>
            public const string VendorNumber = "IDVEND";

            /// <summary>
            /// Property for Remit-To Location Key 
            /// </summary>
            public const string RemitToLocationKey = "IDVENDRMIT";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "SWACTV";

            /// <summary>
            /// Property for Status String
            /// Added for Finder Filter
            /// </summary>
            [IsMvcSpecific]
            public const string StatusString = "SWACTV";

            /// <summary>
            /// Property for Inactive Date 
            /// </summary>
            public const string InActiveDate = "DATEINAC";

            /// <summary>
            /// Property for Date Last Maintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for Date of Last Activity 
            /// </summary>
            public const string DateOfLastActivity = "DATELASTIV";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "RMITNAME";

            /// <summary>
            /// Property for Address Line 1 
            /// </summary>
            public const string AddressLine1 = "TEXTSTRE1";

            /// <summary>
            /// Property for Address Line 2 
            /// </summary>
            public const string AddressLine2 = "TEXTSTRE2";

            /// <summary>
            /// Property for Address Line 3 
            /// </summary>
            public const string AddressLine3 = "TEXTSTRE3";

            /// <summary>
            /// Property for Address Line 4 
            /// </summary>
            public const string AddressLine4 = "TEXTSTRE4";

            /// <summary>
            /// Property for City 
            /// </summary>
            public const string City = "NAMECITY";

            /// <summary>
            /// Property for State Or Province
            /// </summary>
            public const string StateOrProvince = "CODESTTE";

            /// <summary>
            /// Property for Zip Or Postal Code 
            /// </summary>
            public const string ZipOrPostalCode = "CODEPSTL";

            /// <summary>
            /// Property for Country 
            /// </summary>
            public const string Country = "CODECTRY";

            /// <summary>
            /// Property for Contact Name 
            /// </summary>
            public const string ContactName = "NAMECTAC";

            /// <summary>
            /// Property for Phone Number 
            /// </summary>
            public const string PhoneNumber = "TEXTPHON1";

            /// <summary>
            /// Property for Fax Number 
            /// </summary>
            public const string FaxNumber = "TEXTPHON2";

            /// <summary>
            /// Property for Check Language 
            /// </summary>
            public const string CheckLanguage = "CODECHCKLG";

            /// <summary>
            /// Property for Check Language String 
            /// Added for finder Filter
            /// </summary>
            [IsMvcSpecific]
            public const string CheckLanguageString = "CODECHCKLG";

            /// <summary>
            /// Property for Primary Remit-to Indicator 
            /// </summary>
            public const string PrimaryRemitToIndicator = "PRIMARYSW";

            /// <summary>
            /// Property for Primary Remit-to Indicator String
            /// Added for Finder filter 
            /// </summary>
            [IsMvcSpecific]
            public const string PrimaryRemitToIndicatorString = "PRIMARYSW";

            /// <summary>
            /// Property for Email 
            /// </summary>
            public const string Email = "EMAIL";

            /// <summary>
            /// Property for Contacts Phone 
            /// </summary>
            public const string ContactsPhone = "CTACPHONE";

            /// <summary>
            /// Property for Contacts Fax 
            /// </summary>
            public const string ContactsFax = "CTACFAX";

            /// <summary>
            /// Property for Contacts Email 
            /// </summary>
            public const string ContactsEmail = "CTACEMAIL";

            /// <summary>
            /// Property for Optional Fields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for Process Command Code 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for Process Command Code String 
            /// Added for Finder Filter
            /// </summary>
            [IsMvcSpecific]
            public const string ProcessCommandCodeString = "PROCESSCMD";

            /// <summary>
            /// Property for Suppress Integration 
            /// </summary>
            public const string SuppressIntegration = "EWSUPPRESS";

            /// <summary>
            /// Property for Suppress Integration String 
            /// </summary>
            [IsMvcSpecific]
            public const string SuppressIntegrationString = "EWSUPPRESS";

            /// <summary>
            /// Property for A/P Version 
            /// </summary>
            public const string AorPVersion = "EWAPVER";

            /// <summary>
            /// Property for Data base 
            /// </summary>
            public const string DataBase = "EWORGID";

            /// <summary>
            /// Property for Mode 
            /// </summary>
            public const string Mode = "EWMODE";

            /// <summary>
            /// Property for Mode String
            /// Added for Finder Filter
            /// </summary>
            [IsMvcSpecific]
            public const string ModeString = "EWMODE";

            #endregion
        }


        /// <summary>
        /// Contains list of Remit-To Locations Index Constants
        /// </summary>
        public class Index
        {

            #region Properties

            /// <summary>
            /// Property Indexer for Vendor Number 
            /// </summary>
            public const int VendorNumber = 1;

            /// <summary>
            /// Property Indexer for Remit-To Location Key 
            /// </summary>
            public const int RemitToLocationKey = 2;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;

            /// <summary>
            /// Property Indexer for Inactive Date 
            /// </summary>
            public const int InActiveDate = 4;

            /// <summary>
            /// Property Indexer for Date Last Maintained 
            /// </summary>
            public const int DateLastMaintained = 5;

            /// <summary>
            /// Property Indexer for Date of Last Activity 
            /// </summary>
            public const int DateOfLastActivity = 6;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 7;

            /// <summary>
            /// Property Indexer for Address Line 1 
            /// </summary>
            public const int AddressLine1 = 8;

            /// <summary>
            /// Property Indexer for Address Line 2 
            /// </summary>
            public const int AddressLine2 = 9;

            /// <summary>
            /// Property Indexer for Address Line 3 
            /// </summary>
            public const int AddressLine3 = 10;

            /// <summary>
            /// Property Indexer for Address Line 4 
            /// </summary>
            public const int AddressLine4 = 11;

            /// <summary>
            /// Property Indexer for City 
            /// </summary>
            public const int City = 12;

            /// <summary>
            /// Property Indexer for State Or Province
            /// </summary>
            public const int StateOrProvince = 13;

            /// <summary>
            /// Property Indexer for Zip Or Postal Code 
            /// </summary>
            public const int ZipOrPostalCode = 14;

            /// <summary>
            /// Property Indexer for Country 
            /// </summary>
            public const int Country = 15;

            /// <summary>
            /// Property Indexer for Contact Name 
            /// </summary>
            public const int ContactName = 16;

            /// <summary>
            /// Property Indexer for Phone Number 
            /// </summary>
            public const int PhoneNumber = 17;

            /// <summary>
            /// Property Indexer for Fax Number 
            /// </summary>
            public const int FaxNumber = 18;

            /// <summary>
            /// Property Indexer for Check Language 
            /// </summary>
            public const int CheckLanguage = 19;

            /// <summary>
            /// Property Indexer for Primary Remit-to Indicator 
            /// </summary>
            public const int PrimaryRemitToIndicator = 28;

            /// <summary>
            /// Property Indexer for Email 
            /// </summary>
            public const int Email = 29;

            /// <summary>
            /// Property Indexer for Contacts Phone 
            /// </summary>
            public const int ContactsPhone = 30;

            /// <summary>
            /// Property Indexer for Contacts Fax 
            /// </summary>
            public const int ContactsFax = 31;

            /// <summary>
            /// Property Indexer for Contacts Email 
            /// </summary>
            public const int ContactsEmail = 32;

            /// <summary>
            /// Property Indexer for Optional Fields 
            /// </summary>
            public const int OptionalFields = 33;

            /// <summary>
            /// Property Indexer for Process Command Code 
            /// </summary>
            public const int ProcessCommandCode = 34;

            /// <summary>
            /// Property Indexer for Suppress Integration 
            /// </summary>
            public const int SuppressIntegration = 35;

            /// <summary>
            /// Property Indexer for A/P Version 
            /// </summary>
            public const int AorPVersion = 36;

            /// <summary>
            /// Property Indexer for Database 
            /// </summary>
            public const int DataBase = 37;

            /// <summary>
            /// Property Indexer for Mode 
            /// </summary>
            public const int Mode = 38;

            #endregion
        }
    }
}
	