// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of InvoicePaymentSchedules Constants 
    /// </summary>
    public partial class InvoicePaymentSchedules
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0023";

        /// <summary>
        /// Contains list of InvoicePaymentSchedules Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";

            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTITEM";

            /// <summary>
            /// Property for PaymentNumber 
            /// </summary>
            public const string PaymentNumber = "CNTPAYM";

            /// <summary>
            /// Property for DueDate 
            /// </summary>
            public const string DueDate = "DATEDUE";

            /// <summary>
            /// Property for AmountDue 
            /// </summary>
            public const string AmountDue = "AMTDUE";

            /// <summary>
            /// Property for DiscountDate 
            /// </summary>
            public const string DiscountDate = "DATEDISC";

            /// <summary>
            /// Property for DiscountAmount 
            /// </summary>
            public const string DiscountAmount = "AMTDISC";

            /// <summary>
            /// Property for FuncAmountDue 
            /// </summary>
            public const string FuncAmountDue = "AMTDUEHC";

            /// <summary>
            /// Property for FuncDiscountAmount 
            /// </summary>
            public const string FuncDiscountAmount = "AMTDISCHC";

            #endregion
        }

        /// <summary>
        /// Contains list of InvoicePaymentSchedules Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 1;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 2;

            /// <summary>
            /// Property Indexer for PaymentNumber 
            /// </summary>
            public const int PaymentNumber = 3;

            /// <summary>
            /// Property Indexer for DueDate 
            /// </summary>
            public const int DueDate = 4;

            /// <summary>
            /// Property Indexer for AmountDue 
            /// </summary>
            public const int AmountDue = 5;

            /// <summary>
            /// Property Indexer for DiscountDate 
            /// </summary>
            public const int DiscountDate = 6;

            /// <summary>
            /// Property Indexer for DiscountAmount 
            /// </summary>
            public const int DiscountAmount = 7;

            /// <summary>
            /// Property Indexer for FuncAmountDue 
            /// </summary>
            public const int FuncAmountDue = 8;

            /// <summary>
            /// Property Indexer for FuncDiscountAmount 
            /// </summary>
            public const int FuncDiscountAmount = 9;

            #endregion
        }


    }
}
