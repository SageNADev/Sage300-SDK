﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of SelectionCriteriaDetails Constants 
    /// </summary>
    public partial class CreatePaymentBatchDetail
    {
        #region Public Constants

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0036";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of CreatePaymentBatchDetail Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for SelectionCriteria 
            /// </summary>
            public const string SelectionCriteria = "IDSELECT";

            /// <summary>
            /// Property for ExcludeVendorNumber 
            /// </summary>
            public const string ExcludeVendorNumber = "IDVENDOR";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of CreatePaymentBatchDetail Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for SelectionCriteria 
            /// </summary>
            public const int SelectionCriteria = 1;

            /// <summary>
            /// Property Indexer for ExcludeVendorNumber 
            /// </summary>
            public const int ExcludeVendorNumber = 2;

            #endregion
        }

        #endregion
    }
}