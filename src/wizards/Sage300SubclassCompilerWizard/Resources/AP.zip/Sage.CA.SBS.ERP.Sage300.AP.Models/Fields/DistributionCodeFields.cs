/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of DistributionCodes Constants 
    /// </summary>
    public partial class DistributionCode
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0005";

        /// <summary>
        /// Contains list of DistributionCodes Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCodeKey = "DISTID";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";
            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "SWACTV";
            /// <summary>
            /// Property for StatusString
            /// Added for finder Filter 
            /// </summary>
            public const string StatusString = "SWACTV";
            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "DATEINAC";
            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";
            /// <summary>
            /// Property for GLAccount 
            /// </summary>
            public const string GLAccount = "IDGLACCT";
            /// <summary>
            /// Property for Discountable 
            /// </summary>
            public const string Discountable = "SWDISCABL";
            /// <summary>
            /// Property for Discountable String
            /// Added for Finder Filters
            /// </summary>
            public const string DiscountableString = "SWDISCABL";

            #endregion
        }


        /// <summary>
        /// Contains list of DistributionCodes Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCodeKey = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;
            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 4;
            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 5;
            /// <summary>
            /// Property Indexer for GLAccount 
            /// </summary>
            public const int GLAccount = 6;
            /// <summary>
            /// Property Indexer for Discountable 
            /// </summary>
            public const int Discountable = 8;

            #endregion
        }


    }
}
