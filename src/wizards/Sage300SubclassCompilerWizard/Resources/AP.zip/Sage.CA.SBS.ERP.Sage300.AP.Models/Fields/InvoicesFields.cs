// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Invoices Constants 
    /// </summary>
    public partial class Invoice
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0021";
        
        /// <summary>
        /// Contains list of Invoices Fields Constants
        /// </summary>
        public class Fields : BaseFields
        {
            

        }

        /// <summary>
        /// Contains list of Invoices Index Constants
        /// </summary>
        public class Index : BaseIndex
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 1;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 2;
            /// <summary>
            /// Property Indexer for InvoicePrinted 
            /// </summary>
            public const int InvoicePrinted = 15;
            /// <summary>
            /// Property Indexer for Originator 
            /// </summary>
            public const int Originator = 155;
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 3;
            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 4;
            /// <summary>
            /// Property Indexer for RemitToLocation 
            /// </summary>
            public const int RemitToLocation = 5;
            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 6;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int APTransactionType = 7;
            /// <summary>
            /// Property Indexer for OrderNumber 
            /// </summary>
            public const int OrderNumber = 9;
            /// <summary>
            /// Property Indexer for PONumber 
            /// </summary>
            public const int APPONumber = 10;
            /// <summary>
            /// Property Indexer for InvoiceDescription 
            /// </summary>
            public const int InvoiceDescription = 11;
            /// <summary>
            /// Property Indexer for ApplytoDocument 
            /// </summary>
            public const int ApplytoDocument = 13;
            /// <summary>
            /// Property Indexer for AccountSet 
            /// </summary>
            public const int AccountSet = 14;
            /// <summary>
            /// Property Indexer for DocumentDate 
            /// </summary>
            public const int DocumentDate = 15;
            /// <summary>
            /// Property Indexer for AsofDate 
            /// </summary>
            public const int AsofDate = 16;
            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 17;
            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 18;
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 19;
            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 20;
            /// <summary>
            /// Property Indexer for RateOverridden 
            /// </summary>
            public const int RateOverridden = 21;
            /// <summary>
            /// Property Indexer for ExchangeRate 
            /// </summary>
            public const int ExchangeRate = 22;
            /// <summary>
            /// Property Indexer for ApplytoExchangeRate 
            /// </summary>
            public const int ApplytoExchangeRate = 23;
            /// <summary>
            /// Property Indexer for Terms 
            /// </summary>
            public const int Terms = 24;
            /// <summary>
            /// Property Indexer for TermsOverridden 
            /// </summary>
            public const int TermsOverridden = 25;
            /// <summary>
            /// Property Indexer for DueDate 
            /// </summary>
            public const int DueDate = 26;
            /// <summary>
            /// Property Indexer for DiscountDate 
            /// </summary>
            public const int DiscountDate = 27;
            /// <summary>
            /// Property Indexer for DiscountPercentage 
            /// </summary>
            public const int DiscountPercentage = 28;
            /// <summary>
            /// Property Indexer for DiscountAmountAvailable 
            /// </summary>
            public const int DiscountAmountAvailable = 29;
            ///<summary>
            /// Property Indexer for NumberOfDetails 
            /// </summary>
            public const int NumberOfDetails = 30;
            /// <summary>
            /// Property Indexer for Taxable 
            /// </summary>
            public const int Taxable = 31;
            /// <summary>
            /// Property Indexer for TaxAmountControl 
            /// </summary>
            public const int TaxAmountControl = 32;
            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroup = 33;
            /// <summary>
            /// Property Indexer for TaxAuthority1 
            /// </summary>
            public const int TaxAuthority1 = 34;
            /// <summary>
            /// Property Indexer for TaxAuthority2 
            /// </summary>
            public const int TaxAuthority2 = 35;
            /// <summary>
            /// Property Indexer for TaxAuthority3 
            /// </summary>
            public const int TaxAuthority3 = 36;
            /// <summary>
            /// Property Indexer for TaxAuthority4 
            /// </summary>
            public const int TaxAuthority4 = 37;
            /// <summary>
            /// Property Indexer for TaxAuthority5 
            /// </summary>
            public const int TaxAuthority5 = 38;
            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 39;
            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 40;
            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 41;
            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 42;
            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 43;
            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int APTaxClass1 = 39;
            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int APTaxClass2 = 40;
            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int APTaxClass3 = 41;
            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int APTaxClass4 = 42;
            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int APTaxClass5 = 43;
            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 44;
            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 45;
            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 46;
            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 47;
            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 48;
            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 54;
            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 55;
            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 56;
            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 57;
            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 58;
            /// <summary>
            /// Property Indexer for Num1099OrCPRSAmount 
            /// </summary>
            public const int Num1099OrCPRSAmount = 67;
            /// <summary>
            /// Property Indexer for DistributionSetAmount 
            /// </summary>
            public const int DistributionSetAmount = 68;
            /// <summary>
            /// Property Indexer for TotalDistributedTax 
            /// </summary>
            public const int TotalDistributedTax = 69;
            /// <summary>
            /// Property Indexer for DocumentTotalBeforeTaxes 
            /// </summary>
            public const int DocumentTotalBeforeTaxes = 70;
            /// <summary>
            /// Property Indexer for DistributedAllocatedTaxes 
            /// </summary>
            public const int DistributedAllocatedTaxes = 71;
            /// <summary>
            /// Property Indexer for APNumberofScheduledPayments 
            /// </summary>
            public const int NumberofScheduledPayments = 72;

            /// <summary>
            /// Property Indexer for APNumberofScheduledPayments 
            /// </summary>
            public const int APNumberofScheduledPayments = 72;
            /// <summary>
            /// Property Indexer for DistributedTotalBeforeTaxes 
            /// </summary>
            public const int DistributedTotalBeforeTaxes = 73;
            /// <summary>
            /// Property Indexer for DistributedTotalIncludingTax 
            /// </summary>
            public const int DistributedTotalIncludingTax = 74;
            /// <summary>
            /// Property Indexer for PrepaymentNumber 
            /// </summary>
            public const int PrepaymentNumber = 75;
            /// <summary>
            /// Property Indexer for LocationName 
            /// </summary>
            public const int LocationName = 76;
            /// <summary>
            /// Property Indexer for AddressLine1 
            /// </summary>
            public const int AddressLine1 = 77;
            /// <summary>
            /// Property Indexer for AddressLine2 
            /// </summary>
            public const int AddressLine2 = 78;
            /// <summary>
            /// Property Indexer for AddressLine3 
            /// </summary>
            public const int AddressLine3 = 79;
            /// <summary>
            /// Property Indexer for AddressLine4 
            /// </summary>
            public const int AddressLine4 = 80;
            /// <summary>
            /// Property Indexer for City 
            /// </summary>
            public const int City = 81;
            /// <summary>
            /// Property Indexer for StateOrProv 
            /// </summary>
            public const int StateOrProv = 82;
            /// <summary>
            /// Property Indexer for ZipOrPostalCode 
            /// </summary>
            public const int ZipOrPostalCode = 83;
            /// <summary>
            /// Property Indexer for Country 
            /// </summary>
            public const int Country = 84;
            /// <summary>
            /// Property Indexer for ContactName 
            /// </summary>
            public const int ContactName = 85;
            /// <summary>
            /// Property Indexer for PhoneNumber 
            /// </summary>
            public const int PhoneNumber = 86;
            /// <summary>
            /// Property Indexer for FaxNumber 
            /// </summary>
            public const int FaxNumber = 87;
            /// <summary>
            /// Property Indexer for RateDate 
            /// </summary>
            public const int RateDate = 88;
            /// <summary>
            /// Property Indexer for RecoverableTaxes 
            /// </summary>
            public const int RecoverableTaxes = 89;
            /// <summary>
            /// Property Indexer for VendorGroupCode 
            /// </summary>
            public const int VendorGroupCode = 91;
            /// <summary>
            /// Property Indexer for TermsDescription 
            /// </summary>
            public const int TermsDescription = 92;
            /// <summary>
            /// Property Indexer for DistributionSet 
            /// </summary>
            public const int DistributionSet = 93;
            /// <summary>
            /// Property Indexer for Num1099OrCPRSCode 
            /// </summary>
            public const int Num1099OrCPRSCode = 94;
            /// <summary>
            /// Property Indexer for AMTDUE 
            /// </summary>
            public const int AmountDue = 95;
            /// <summary>
            /// Property Indexer for GeneratePaymentSchedule 
            /// </summary>
            public const int GeneratePaymentSchedule = 96;
            /// <summary>
            /// Property Indexer for TaxTotal 
            /// </summary>
            public const int TaxTotal = 97;
            /// <summary>
            /// Property Indexer for DocumentTotalIncludingTax 
            /// </summary>
            public const int DocumentTotalIncludingTax = 98;
            /// <summary>
            /// Property for DocumentTotalIncludingTax 
            /// </summary>
            public const int APDocumentTotalIncludingTax = 98;
            /// <summary>
            /// Property Indexer for UndistributedAmount 
            /// </summary>
            public const int UndistributedAmount = 100;
            /// <summary>
            /// Property Indexer for TaxInclusive1 
            /// </summary>
            public const int TaxInclusive1 = 101;
            /// <summary>
            /// Property Indexer for TaxInclusive2 
            /// </summary>
            public const int TaxInclusive2 = 102;
            /// <summary>
            /// Property Indexer for TaxInclusive3 
            /// </summary>
            public const int TaxInclusive3 = 103;
            /// <summary>
            /// Property Indexer for TaxInclusive4 
            /// </summary>
            public const int TaxInclusive4 = 104;
            /// <summary>
            /// Property Indexer for TaxInclusive5 
            /// </summary>
            public const int TaxInclusive5 = 105;
            /// <summary>
            /// Property Indexer for ExpensedSeparatelyTaxes 
            /// </summary>
            public const int ExpensedSeparatelyTaxes = 106;
            /// <summary>
            /// Property Indexer for TaxAmounttobeAllocated 
            /// </summary>
            public const int TaxAmountToBeAllocated = 107;
            /// <summary>
            /// Property Indexer for CurrencyCodeOperator 
            /// </summary>
            public const int CurrencyCodeOperator = 110;
            /// <summary>
            /// Property Indexer for RecoverableAccount1 
            /// </summary>
            public const int RecoverableAccount1 = 111;
            /// <summary>
            /// Property Indexer for RecoverableAccount2 
            /// </summary>
            public const int RecoverableAccount2 = 112;
            /// <summary>
            /// Property Indexer for RecoverableAccount3 
            /// </summary>
            public const int RecoverableAccount3 = 113;
            /// <summary>
            /// Property Indexer for RecoverableAccount4 
            /// </summary>
            public const int RecoverableAccount4 = 114;
            /// <summary>
            /// Property Indexer for RecoverableAccount5 
            /// </summary>
            public const int RecoverableAccount5 = 115;
            /// <summary>
            /// Property Indexer for ExpenseSepAccount1 
            /// </summary>
            public const int ExpenseSepAccount1 = 116;
            /// <summary>
            /// Property Indexer for ExpenseSepAccount2 
            /// </summary>
            public const int ExpenseSepAccount2 = 117;
            /// <summary>
            /// Property Indexer for ExpenseSepAccount3 
            /// </summary>
            public const int ExpenseSepAccount3 = 118;
            /// <summary>
            /// Property Indexer for ExpenseSepAccount4 
            /// </summary>
            public const int ExpenseSepAccount4 = 119;
            /// <summary>
            /// Property Indexer for ExpenseSepAccount5 
            /// </summary>
            public const int ExpenseSepAccount5 = 120;
            /// <summary>
            /// Property Indexer for DrillDownApplicationSource 
            /// </summary>
            public const int DrillDownApplicationSource = 121;
            /// <summary>
            /// Property Indexer for DrillDownType 
            /// </summary>
            public const int DrillDownType = 122;
            /// <summary>
            /// Property Indexer for DrillDownLinkNumber 
            /// </summary>
            public const int DrillDownLinkNumber = 123;
            /// <summary>
            /// Property Indexer for PropertyCode 
            /// </summary>
            public const int PropertyCode = 124;
            /// <summary>
            /// Property Indexer for PropertyValue 
            /// </summary>
            public const int PropertyValue = 125;
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 126;
            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 127;
            /// <summary>
            /// Property Indexer for DistRecoverableTaxes 
            /// </summary>
            public const int DistRecoverableTaxes = 128;
            /// <summary>
            /// Property Indexer for DistExpSeparatelyTaxes 
            /// </summary>
            public const int DistExpSeparatelyTaxes = 129;
            /// <summary>
            /// Property Indexer for ErrorBatch 
            /// </summary>
            public const int ErrorBatch = 130;
            /// <summary>
            /// Property Indexer for ErrorEntry 
            /// </summary>
            public const int ErrorEntry = 131;
            /// <summary>
            /// Property Indexer for Email 
            /// </summary>
            public const int Email = 132;
            /// <summary>
            /// Property Indexer for ContactsPhone 
            /// </summary>
            public const int ContactsPhone = 133;
            /// <summary>
            /// Property Indexer for ContactsFax 
            /// </summary>
            public const int ContactsFax = 134;
            /// <summary>
            /// Property Indexer for ContactsEmail 
            /// </summary>
            public const int ContactsEmail = 135;
            /// <summary>
            /// Property Indexer for PrepaymentAmount 
            /// </summary>
            public const int PrepaymentAmount = 136;
            /// <summary>
            /// Property Indexer for RecurringPayableCode 
            /// </summary>
            public const int RecurringPayableCode = 137;
            /// <summary>
            /// Property Indexer for DateGenerated 
            /// </summary>
            public const int DateGenerated = 138;
            /// <summary>
            /// Property Indexer for DiscountBaseWithTax 
            /// </summary>
            public const int DiscountBaseWithTax = 139;
            /// <summary>
            /// Property Indexer for DiscountBaseWithoutTax 
            /// </summary>
            public const int DiscountBaseWithoutTax = 140;
            /// <summary>
            /// Property Indexer for DiscountBase 
            /// </summary>
            public const int DiscountBase = 141;
            /// <summary>
            /// Property Indexer for RetainageInvoice 
            /// </summary>
            public const int RetainageInvoice = 142;
            /// <summary>
            /// Property Indexer for HasRetainage 
            /// </summary>
            public const int HasRetainage = 143;
            /// <summary>
            /// Property Indexer for OriginalDocNo 
            /// </summary>
            public const int OriginalDocNo = 144;
            /// <summary>
            /// Property Indexer for RetainageAmount 
            /// </summary>
            public const int RetainageAmount = 145;
            /// <summary>
            /// Property Indexer for PercentRetained 
            /// </summary>
            public const int PercentRetained = 146;
            /// <summary>
            /// Property Indexer for DaysRetained 
            /// </summary>
            public const int DaysRetained = 147;
            /// <summary>
            /// Property Indexer for RetainageDueDate 
            /// </summary>
            public const int RetainageDueDate = 148;
            /// <summary>
            /// Property Indexer for RetainageTermsCode 
            /// </summary>
            public const int RetainageTermsCode = 149;
            /// <summary>
            /// Property Indexer for RetainageDueDateOverride 
            /// </summary>
            public const int RetainageDueDateOverride = 150;
            /// <summary>
            /// Property Indexer for RetainageAmountOverride 
            /// </summary>
            public const int RetainageAmountOverride = 151;
            /// <summary>
            /// Property Indexer for RetainageExchangeRate 
            /// </summary>
            public const int RetainageExchangeRate = 152;
            /// <summary>
            /// Property Indexer for TaxBaseControl 
            /// </summary>
            public const int TaxBaseControl = 153;
            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 154;
            /// <summary>
            /// Property Indexer for DetailCount 
            /// </summary>
            public const int DetailCount = 156;
            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 157;
            /// <summary>
            /// Property Indexer for OnHold 
            /// </summary>
            public const int OnHold = 158;
            /// <summary>
            /// Property Indexer for OrigExists 
            /// </summary>
            public const int OrigExists = 200;
            /// <summary>
            /// Property Indexer for OrigName 
            /// </summary>
            public const int OrigName = 201;
            /// <summary>
            /// Property Indexer for OrigStatus 
            /// </summary>
            public const int OrigStatus = 202;
            /// <summary>
            /// Property Indexer for VendorExists 
            /// </summary>
            public const int VendorExists = 210;
            /// <summary>
            /// Property Indexer for VendorName 
            /// </summary>
            public const int VendorName = 211;
            /// <summary>
            /// Property Indexer for VendorDistType 
            /// </summary>
            public const int VendorDistType = 212;
            /// <summary>
            /// Property Indexer for VendorDistCode 
            /// </summary>
            public const int VendorDistCode = 213;
            /// <summary>
            /// Property Indexer for VendorAccount 
            /// </summary>
            public const int VendorAccount = 214;
            /// <summary>
            /// Property Indexer for VendorTaxReportType 
            /// </summary>
            public const int VendorTaxReportType = 215;
            /// <summary>
            /// Property Indexer for RemitExists 
            /// </summary>
            public const int RemitExists = 220;
            /// <summary>
            /// Property Indexer for RemitName 
            /// </summary>
            public const int RemitName = 221;
            /// <summary>
            /// Property Indexer for Num1099OrCPRSExists 
            /// </summary>
            public const int Num1099OrCPRSExists = 225;
            /// <summary>
            /// Property Indexer for Num1099OrCPRSDescription 
            /// </summary>
            public const int Num1099OrCPRSDescription = 226;
            /// <summary>
            /// Property Indexer for DistSetExists 
            /// </summary>
            public const int DistSetExists = 230;
            /// <summary>
            /// Property Indexer for DistSetDescription 
            /// </summary>
            public const int DistSetDescription = 231;
            /// <summary>
            /// Property Indexer for DistSetMethod 
            /// </summary>
            public const int DistSetMethod = 232;
            /// <summary>
            /// Property Indexer for TermExists 
            /// </summary>
            public const int TermExists = 235;
            /// <summary>
            /// Property Indexer for TermUsePaymentSchedule 
            /// </summary>
            public const int TermUsePaymentSchedule = 236;
            /// <summary>
            /// Property Indexer for RTGTermExists 
            /// </summary>
            public const int RTGTermExists = 240;
            /// <summary>
            /// Property Indexer for RTGTermDescription 
            /// </summary>
            public const int RTGTermDescription = 241;
            /// <summary>
            /// Property Indexer for PMLevel1Name 
            /// </summary>
            public const int PMLevel1Name = 245;
            /// <summary>
            /// Property Indexer for PMLevel2Name 
            /// </summary>
            public const int PMLevel2Name = 246;
            /// <summary>
            /// Property Indexer for PMLevel3Name 
            /// </summary>
            public const int PMLevel3Name = 247;
            /// <summary>
            /// Property Indexer for TaxGroupDescription 
            /// </summary>
            public const int TaxGroupDescription = 251;
            /// <summary>
            /// Property Indexer for TaxAuth1Description 
            /// </summary>
            public const int TaxAuth1Description = 260;
            /// <summary>
            /// Property Indexer for TaxAuth2Description 
            /// </summary>
            public const int TaxAuth2Description = 261;
            /// <summary>
            /// Property Indexer for TaxAuth3Description 
            /// </summary>
            public const int TaxAuth3Description = 262;
            /// <summary>
            /// Property Indexer for TaxAuth4Description 
            /// </summary>
            public const int TaxAuth4Description = 263;
            /// <summary>
            /// Property Indexer for TaxAuth5Description 
            /// </summary>
            public const int TaxAuth5Description = 264;
            /// <summary>
            /// Property Indexer for AOrPVersionCreatedIn 
            /// </summary>
            public const int AorPVersionCreatedIn = 270;
            /// <summary>
            /// Property Indexer for TaxStateVersion 
            /// </summary>
            public const int TaxStateVersion = 271;
            /// <summary>
            /// Property Indexer for ReportRetainageTax 
            /// </summary>
            public const int ReportRetainageTax = 272;
            /// <summary>
            /// Property Indexer for TaxReportingCurrencyCode 
            /// </summary>
            public const int TaxReportingCurrencyCode = 273;
            /// <summary>
            /// Property Indexer for TaxReportingCalculateMethod 
            /// </summary>
            public const int TaxReportingCalculateMethod = 274;
            /// <summary>
            /// Property Indexer for TaxReportingExchangeRate 
            /// </summary>
            public const int TaxReportingExchangeRate = 275;
            /// <summary>
            /// Property Indexer for TaxReportingRateType 
            /// </summary>
            public const int TaxReportingRateType = 276;
            /// <summary>
            /// Property Indexer for TaxReportingRateDate 
            /// </summary>
            public const int TaxReportingRateDate = 277;
            /// <summary>
            /// Property Indexer for TaxReportingRateOperator 
            /// </summary>
            public const int TaxReportingRateOperator = 278;
            /// <summary>
            /// Property Indexer for TaxReportingRateOverride 
            /// </summary>
            public const int TaxReportingRateOverride = 279;
            /// <summary>
            /// Property Indexer for TaxReportingAmount1 
            /// </summary>
            public const int TaxReportingAmount1 = 280;
            /// <summary>
            /// Property Indexer for TaxReportingAmount2 
            /// </summary>
            public const int TaxReportingAmount2 = 281;
            /// <summary>
            /// Property Indexer for TaxReportingAmount3 
            /// </summary>
            public const int TaxReportingAmount3 = 282;
            /// <summary>
            /// Property Indexer for TaxReportingAmount4 
            /// </summary>
            public const int TaxReportingAmount4 = 283;
            /// <summary>
            /// Property Indexer for TaxReportingAmount5 
            /// </summary>
            public const int TaxReportingAmount5 = 284;
            /// <summary>
            /// Property Indexer for TaxReportingTotal 
            /// </summary>
            public const int TaxReportingTotal = 285;
            /// <summary>
            /// Property Indexer for TaxReportingAllocatedTax 
            /// </summary>
            public const int TaxReportingAllocatedTax = 286;
            /// <summary>
            /// Property Indexer for TaxReportingExpensedTax 
            /// </summary>
            public const int TaxReportingExpensedTax = 287;
            /// <summary>
            /// Property Indexer for TaxReportingRecoverableTax 
            /// </summary>
            public const int TaxReportingRecoverableTax = 288;
            /// <summary>
            /// Property Indexer for RetainageTaxBase1 
            /// </summary>
            public const int RetainageTaxBase1 = 289;
            /// <summary>
            /// Property Indexer for RetainageTaxBase2 
            /// </summary>
            public const int RetainageTaxBase2 = 290;
            /// <summary>
            /// Property Indexer for RetainageTaxBase3 
            /// </summary>
            public const int RetainageTaxBase3 = 291;
            /// <summary>
            /// Property Indexer for RetainageTaxBase4 
            /// </summary>
            public const int RetainageTaxBase4 = 292;
            /// <summary>
            /// Property Indexer for RetainageTaxBase5 
            /// </summary>
            public const int RetainageTaxBase5 = 293;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount1 
            /// </summary>
            public const int RetainageTaxAmount1 = 294;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount2 
            /// </summary>
            public const int RetainageTaxAmount2 = 295;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount3 
            /// </summary>
            public const int RetainageTaxAmount3 = 296;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount4 
            /// </summary>
            public const int RetainageTaxAmount4 = 297;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount5 
            /// </summary>
            public const int RetainageTaxAmount5 = 298;
            /// <summary>
            /// Property Indexer for FuncTaxBase1 
            /// </summary>
            public const int FuncTaxBase1 = 299;
            /// <summary>
            /// Property Indexer for FuncTaxBase2 
            /// </summary>
            public const int FuncTaxBase2 = 300;
            /// <summary>
            /// Property Indexer for FuncTaxBase3 
            /// </summary>
            public const int FuncTaxBase3 = 301;
            /// <summary>
            /// Property Indexer for FuncTaxBase4 
            /// </summary>
            public const int FuncTaxBase4 = 302;
            /// <summary>
            /// Property Indexer for FuncTaxBase5 
            /// </summary>
            public const int FuncTaxBase5 = 303;
            /// <summary>
            /// Property Indexer for FuncTaxAmount1 
            /// </summary>
            public const int FuncTaxAmount1 = 304;
            /// <summary>
            /// Property Indexer for FuncTaxAmount2 
            /// </summary>
            public const int FuncTaxAmount2 = 305;
            /// <summary>
            /// Property Indexer for FuncTaxAmount3 
            /// </summary>
            public const int FuncTaxAmount3 = 306;
            /// <summary>
            /// Property Indexer for FuncTaxAmount4 
            /// </summary>
            public const int FuncTaxAmount4 = 307;
            /// <summary>
            /// Property Indexer for FuncTaxAmount5 
            /// </summary>
            public const int FuncTaxAmount5 = 308;
            /// <summary>
            /// Property Indexer for FuncDistributionwOrTaxTotal 
            /// </summary>
            public const int FuncDistributionOrTaxTotal = 309;
            /// <summary>
            /// Property Indexer for FuncRetainageAmount 
            /// </summary>
            public const int FuncRetainageAmount = 310;
            /// <summary>
            /// Property Indexer for FuncDiscountAmount 
            /// </summary>
            public const int FuncDiscountAmount = 311;
            /// <summary>
            /// Property Indexer for Func1099OrCPRSAmount 
            /// </summary>
            public const int Func1099OrCPRSAmount = 312;
            /// <summary>
            /// Property Indexer for FuncPrepaymentAmount 
            /// </summary>
            public const int FuncPrepaymentAmount = 313;

            /// <summary>
            /// Property Indexer for TaxAmountDue 
            /// </summary>
            public const int TaxAmountDue = 314;
            /// <summary>
            /// Property Indexer for FuncAmountDue 
            /// </summary>
            public const int FuncAmountDue = 315;

            /// <summary>
            /// Property Indexer for VendorNameTax 
            /// </summary>
            public const int VendorNameTax = 316;
            /// <summary>
            /// Property Indexer for RetainageTaxTotal 
            /// </summary>
            public const int RetainageTaxTotal = 317;
            /// <summary>
            /// Property Indexer for TaxAmount1Total 
            /// </summary>
            public const int TaxAmount1Total = 318;
            /// <summary>
            /// Property Indexer for TaxAmount2Total 
            /// </summary>
            public const int TaxAmount2Total = 319;
            /// <summary>
            /// Property Indexer for TaxAmount3Total 
            /// </summary>
            public const int TaxAmount3Total = 320;
            /// <summary>
            /// Property Indexer for TaxAmount4Total 
            /// </summary>
            public const int TaxAmount4Total = 321;
            /// <summary>
            /// Property Indexer for TaxAmount5Total 
            /// </summary>
            public const int TaxAmount5Total = 322;
            /// <summary>
            /// Property Indexer for RetainageAmountfromDetails 
            /// </summary>
            public const int RetainageAmountFromDetails = 323;
            /// <summary>
            /// Property Indexer for EnteredBy 
            /// </summary>
            public const int EnteredBy = 324;
            /// <summary>
            /// Property Indexer for PostingDate 
            /// </summary>
            public const int PostingDate = 325;
            /// <summary>
            /// Property Indexer for AcctSetDescription 
            /// </summary>
            public const int AcctSetDescription = 326;
            /// <summary>
            /// Property Indexer for Import Declaration Number
            /// </summary>
            public const int ImportDeclarationNumber = 327;

            /// <summary>
            /// Property Indexer for estimated tax withheld amount1
            /// </summary>
            public const int EstimatedTaxWithheld1 = 328;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount2
            /// </summary>
            public const int EstimatedTaxWithheld2 = 329;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount3
            /// </summary>
            public const int EstimatedTaxWithheld3 = 330;

            /// <summary>
            /// Property Indexer for estimated tax withheld amount4
            /// </summary>
            public const int EstimatedTaxWithheld4 = 331;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount5
            /// </summary>
            public const int EstimatedTaxWithheld5 = 332;
            /// <summary>
            /// Property Indexer for customer tax base 1
            /// </summary>
            public const int CustomerTaxBase1 = 333;
            /// <summary>
            /// Property Indexer for customer tax base 2
            /// </summary>
            public const int CustomerTaxBase2 = 334;
            /// <summary>
            /// Property Indexer for customer tax base 3
            /// </summary>
            public const int CustomerTaxBase3 = 335;
            /// <summary>
            /// Property Indexer for customer tax base 4
            /// </summary>
            public const int CustomerTaxBase4 = 336;
            /// <summary>
            /// Property Indexer for customer tax base 5
            /// </summary>
            public const int CustomerTaxBase5 = 337;
            /// <summary>
            /// Property Indexer for customer tax amount 1
            /// </summary>
            public const int CustomerTaxAmount1 = 338;
            /// <summary>
            /// Property Indexer for customer tax amount 2
            /// </summary>
            public const int CustomerTaxAmount2 = 339;
            /// <summary>
            /// Property Indexer for customer tax amount 3
            /// </summary>
            public const int CustomerTaxAmount3 = 340;
            /// <summary>
            /// Property Indexer for customer tax amount 4
            /// </summary>
            public const int CustomerTaxAmount4 = 341;
            /// <summary>
            /// Property Indexer for customer tax amount 5
            /// </summary>
            public const int CustomerTaxAmount5 = 342;
            /// <summary>
            /// Property Indexer for Negative Customer Tax Amount
            /// </summary>
            public const int NegativeCustomerTaxAmount = 343;
            /// <summary>
            /// Property Indexer for Net Vendor Tax Amount
            /// </summary>
            public const int NetVendorTaxAmount = 344;
            /// <summary>
            /// Property Indexer for Customer Tax Amount
            /// </summary>
            public const int CustomerTaxAmount = 345;
            /// <summary>
            /// Property Indexer for Total Tax Withholding
            /// </summary>
            public const int TotalTaxWithholding = 346;
            /// <summary>
            /// Property Indexer for Amount due with tax withholding
            /// </summary>
            public const int AmountDueWithTaxWithholding = 347;

            /// <summary>
            /// Property Indexer for Amount due with tax withholding adjusted
            /// </summary>
            public const int AmountDueWithTaxWithholdingAdjusted = 348;
            #endregion

        }
    }
}
