/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of MiscellaneousPayments Constants 
    /// </summary>
	public partial class MiscellaneousPayment
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0032";

        /// <summary>
        /// Contains list of MiscellaneousPayments Fields Constants
        /// </summary>
	    public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "BATCHTYPE";
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTRMIT";
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "CNTLINE";
            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "IDDISTCODE";
            /// <summary>
            /// Property for AccountNumber 
            /// </summary>
            public const string AccountNumber = "IDACCT";
            /// <summary>
            /// Property for GOrLReference 
            /// </summary>
            public const string GLReference = "GLREF";
            /// <summary>
            /// Property for GOrLDescription 
            /// </summary>
            public const string GLDescription = "GLDESC";
            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";
            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";
            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";
            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";
            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";
            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded1 = "SWTAXINCL1";
            /// <summary>
            /// Property for TaxIncluded2 
            /// </summary>
            public const string TaxIncluded2 = "SWTAXINCL2";
            /// <summary>
            /// Property for TaxIncluded3 
            /// </summary>
            public const string TaxIncluded3 = "SWTAXINCL3";
            /// <summary>
            /// Property for TaxIncluded4 
            /// </summary>
            public const string TaxIncluded4 = "SWTAXINCL4";
            /// <summary>
            /// Property for TaxIncluded5 
            /// </summary>
            public const string TaxIncluded5 = "SWTAXINCL5";
            /// <summary>
            /// Property for TaxBase1 
            /// </summary>
            public const string TaxBase1 = "TXBSE1TC";
            /// <summary>
            /// Property for TaxBase2 
            /// </summary>
            public const string TaxBase2 = "TXBSE2TC";
            /// <summary>
            /// Property for TaxBase3 
            /// </summary>
            public const string TaxBase3 = "TXBSE3TC";
            /// <summary>
            /// Property for TaxBase4 
            /// </summary>
            public const string TaxBase4 = "TXBSE4TC";
            /// <summary>
            /// Property for TaxBase5 
            /// </summary>
            public const string TaxBase5 = "TXBSE5TC";
            /// <summary>
            /// Property for TaxRate1 
            /// </summary>
            public const string TaxRate1 = "RATETAX1";
            /// <summary>
            /// Property for TaxRate2 
            /// </summary>
            public const string TaxRate2 = "RATETAX2";
            /// <summary>
            /// Property for TaxRate3 
            /// </summary>
            public const string TaxRate3 = "RATETAX3";
            /// <summary>
            /// Property for TaxRate4 
            /// </summary>
            public const string TaxRate4 = "RATETAX4";
            /// <summary>
            /// Property for TaxRate5 
            /// </summary>
            public const string TaxRate5 = "RATETAX5";
            /// <summary>
            /// Property for TaxAmount1 
            /// </summary>
            public const string TaxAmount1 = "TXAMT1TC";
            /// <summary>
            /// Property for TaxAmount2 
            /// </summary>
            public const string TaxAmount2 = "TXAMT2TC";
            /// <summary>
            /// Property for TaxAmount3 
            /// </summary>
            public const string TaxAmount3 = "TXAMT3TC";
            /// <summary>
            /// Property for TaxAmount4 
            /// </summary>
            public const string TaxAmount4 = "TXAMT4TC";
            /// <summary>
            /// Property for TaxAmount5 
            /// </summary>
            public const string TaxAmount5 = "TXAMT5TC";
            /// <summary>
            /// Property for TaxTotal 
            /// </summary>
            public const string TaxTotal = "TXTOTTC";
            /// <summary>
            /// Property for DistAmount 
            /// </summary>
            public const string DistAmount = "AMTDISTTC";
            /// <summary>
            /// Property for DistAmountNetofTaxes 
            /// </summary>
            public const string DistAmountNetofTaxes = "AMTNETTC";
            /// <summary>
            /// Property for FuncDistAmount 
            /// </summary>
            public const string FuncDistAmount = "AMTDISTHC";
            /// <summary>
            /// Property for FuncDistAmountNetofTaxes 
            /// </summary>
            public const string FuncDistAmountNetofTaxes = "AMTNETHC";
            /// <summary>
            /// Property for TaxAllocatedTotal 
            /// </summary>
            public const string TaxAllocatedTotal = "TXALLTC";
            /// <summary>
            /// Property for TaxAllocatedAmount1 
            /// </summary>
            public const string TaxAllocatedAmount1 = "TXALL1TC";
            /// <summary>
            /// Property for TaxAllocatedAmount2 
            /// </summary>
            public const string TaxAllocatedAmount2 = "TXALL2TC";
            /// <summary>
            /// Property for TaxAllocatedAmount3 
            /// </summary>
            public const string TaxAllocatedAmount3 = "TXALL3TC";
            /// <summary>
            /// Property for TaxAllocatedAmount4 
            /// </summary>
            public const string TaxAllocatedAmount4 = "TXALL4TC";
            /// <summary>
            /// Property for TaxAllocatedAmount5 
            /// </summary>
            public const string TaxAllocatedAmount5 = "TXALL5TC";
            /// <summary>
            /// Property for TaxRecoverable1 
            /// </summary>
            public const string TaxRecoverable1 = "TXREC1TC";
            /// <summary>
            /// Property for TaxRecoverable2 
            /// </summary>
            public const string TaxRecoverable2 = "TXREC2TC";
            /// <summary>
            /// Property for TaxRecoverable3 
            /// </summary>
            public const string TaxRecoverable3 = "TXREC3TC";
            /// <summary>
            /// Property for TaxRecoverable4 
            /// </summary>
            public const string TaxRecoverable4 = "TXREC4TC";
            /// <summary>
            /// Property for TaxRecoverable5 
            /// </summary>
            public const string TaxRecoverable5 = "TXREC5TC";
            /// <summary>
            /// Property for TaxExpensed1 
            /// </summary>
            public const string TaxExpensed1 = "TXEXP1TC";
            /// <summary>
            /// Property for TaxExpensed2 
            /// </summary>
            public const string TaxExpensed2 = "TXEXP2TC";
            /// <summary>
            /// Property for TaxExpensed3 
            /// </summary>
            public const string TaxExpensed3 = "TXEXP3TC";
            /// <summary>
            /// Property for TaxExpensed4 
            /// </summary>
            public const string TaxExpensed4 = "TXEXP4TC";
            /// <summary>
            /// Property for TaxExpensed5 
            /// </summary>
            public const string TaxExpensed5 = "TXEXP5TC";
            /// <summary>
            /// Property for TaxReportingAmount1 
            /// </summary>
            public const string TaxReportingAmount1 = "TXAMT1RC";
            /// <summary>
            /// Property for TaxReportingAmount2 
            /// </summary>
            public const string TaxReportingAmount2 = "TXAMT2RC";
            /// <summary>
            /// Property for TaxReportingAmount3 
            /// </summary>
            public const string TaxReportingAmount3 = "TXAMT3RC";
            /// <summary>
            /// Property for TaxReportingAmount4 
            /// </summary>
            public const string TaxReportingAmount4 = "TXAMT4RC";
            /// <summary>
            /// Property for TaxReportingAmount5 
            /// </summary>
            public const string TaxReportingAmount5 = "TXAMT5RC";
            /// <summary>
            /// Property for TaxReportingTotal 
            /// </summary>
            public const string TaxReportingTotal = "TXTOTRC";
            /// <summary>
            /// Property for TaxReportingAllocatedAmount 
            /// </summary>
            public const string TaxReportingAllocatedAmount = "TXALLRC";
            /// <summary>
            /// Property for TaxReportingRecoverableAmt1 
            /// </summary>
            public const string TaxReportingRecoverableAmt1 = "TXREC1RC";
            /// <summary>
            /// Property for TaxReportingRecoverableAmt2 
            /// </summary>
            public const string TaxReportingRecoverableAmt2 = "TXREC2RC";
            /// <summary>
            /// Property for TaxReportingRecoverableAmt3 
            /// </summary>
            public const string TaxReportingRecoverableAmt3 = "TXREC3RC";
            /// <summary>
            /// Property for TaxReportingRecoverableAmt4 
            /// </summary>
            public const string TaxReportingRecoverableAmt4 = "TXREC4RC";
            /// <summary>
            /// Property for TaxReportingRecoverableAmt5 
            /// </summary>
            public const string TaxReportingRecoverableAmt5 = "TXREC5RC";
            /// <summary>
            /// Property for TaxReportingExpensedAmount1 
            /// </summary>
            public const string TaxReportingExpensedAmount1 = "TXEXP1RC";
            /// <summary>
            /// Property for TaxReportingExpensedAmount2 
            /// </summary>
            public const string TaxReportingExpensedAmount2 = "TXEXP2RC";
            /// <summary>
            /// Property for TaxReportingExpensedAmount3 
            /// </summary>
            public const string TaxReportingExpensedAmount3 = "TXEXP3RC";
            /// <summary>
            /// Property for TaxReportingExpensedAmount4 
            /// </summary>
            public const string TaxReportingExpensedAmount4 = "TXEXP4RC";
            /// <summary>
            /// Property for TaxReportingExpensedAmount5 
            /// </summary>
            public const string TaxReportingExpensedAmount5 = "TXEXP5RC";
            /// <summary>
            /// Property for FuncTaxBase1 
            /// </summary>
            public const string FuncTaxBase1 = "TXBSE1HC";
            /// <summary>
            /// Property for FuncTaxBase2 
            /// </summary>
            public const string FuncTaxBase2 = "TXBSE2HC";
            /// <summary>
            /// Property for FuncTaxBase3 
            /// </summary>
            public const string FuncTaxBase3 = "TXBSE3HC";
            /// <summary>
            /// Property for FuncTaxBase4 
            /// </summary>
            public const string FuncTaxBase4 = "TXBSE4HC";
            /// <summary>
            /// Property for FuncTaxBase5 
            /// </summary>
            public const string FuncTaxBase5 = "TXBSE5HC";
            /// <summary>
            /// Property for FuncTaxAmount1 
            /// </summary>
            public const string FuncTaxAmount1 = "TXAMT1HC";
            /// <summary>
            /// Property for FuncTaxAmount2 
            /// </summary>
            public const string FuncTaxAmount2 = "TXAMT2HC";
            /// <summary>
            /// Property for FuncTaxAmount3 
            /// </summary>
            public const string FuncTaxAmount3 = "TXAMT3HC";
            /// <summary>
            /// Property for FuncTaxAmount4 
            /// </summary>
            public const string FuncTaxAmount4 = "TXAMT4HC";
            /// <summary>
            /// Property for FuncTaxAmount5 
            /// </summary>
            public const string FuncTaxAmount5 = "TXAMT5HC";
            /// <summary>
            /// Property for FuncTaxAllocatedTotal 
            /// </summary>
            public const string FuncTaxAllocatedTotal = "TXALLHC";
            /// <summary>
            /// Property for FuncTaxAllocatedAmount1 
            /// </summary>
            public const string FuncTaxAllocatedAmount1 = "TXALL1HC";
            /// <summary>
            /// Property for FuncTaxAllocatedAmount2 
            /// </summary>
            public const string FuncTaxAllocatedAmount2 = "TXALL2HC";
            /// <summary>
            /// Property for FuncTaxAllocatedAmount3 
            /// </summary>
            public const string FuncTaxAllocatedAmount3 = "TXALL3HC";
            /// <summary>
            /// Property for FuncTaxAllocatedAmount4 
            /// </summary>
            public const string FuncTaxAllocatedAmount4 = "TXALL4HC";
            /// <summary>
            /// Property for FuncTaxAllocatedAmount5 
            /// </summary>
            public const string FuncTaxAllocatedAmount5 = "TXALL5HC";
            /// <summary>
            /// Property for FuncTaxRecoverable1 
            /// </summary>
            public const string FuncTaxRecoverable1 = "TXREC1HC";
            /// <summary>
            /// Property for FuncTaxRecoverable2 
            /// </summary>
            public const string FuncTaxRecoverable2 = "TXREC2HC";
            /// <summary>
            /// Property for FuncTaxRecoverable3 
            /// </summary>
            public const string FuncTaxRecoverable3 = "TXREC3HC";
            /// <summary>
            /// Property for FuncTaxRecoverable4 
            /// </summary>
            public const string FuncTaxRecoverable4 = "TXREC4HC";
            /// <summary>
            /// Property for FuncTaxRecoverable5 
            /// </summary>
            public const string FuncTaxRecoverable5 = "TXREC5HC";
            /// <summary>
            /// Property for FuncTaxExpensed1 
            /// </summary>
            public const string FuncTaxExpensed1 = "TXEXP1HC";
            /// <summary>
            /// Property for FuncTaxExpensed2 
            /// </summary>
            public const string FuncTaxExpensed2 = "TXEXP2HC";
            /// <summary>
            /// Property for FuncTaxExpensed3 
            /// </summary>
            public const string FuncTaxExpensed3 = "TXEXP3HC";
            /// <summary>
            /// Property for FuncTaxExpensed4 
            /// </summary>
            public const string FuncTaxExpensed4 = "TXEXP4HC";
            /// <summary>
            /// Property for FuncTaxExpensed5 
            /// </summary>
            public const string FuncTaxExpensed5 = "TXEXP5HC";
            /// <summary>
            /// Property for FuncTaxTotal 
            /// </summary>
            public const string FuncTaxTotal = "TXTOTHC";
            /// <summary>
            /// Property for ContractCode 
            /// </summary>
            public const string ContractCode = "CONTRACT";
            /// <summary>
            /// Property for ProjectCode 
            /// </summary>
            public const string ProjectCode = "PROJECT";
            /// <summary>
            /// Property for CategoryCode 
            /// </summary>
            public const string CategoryCode = "CATEGORY";
            /// <summary>
            /// Property for ProjectOrCategoryResource 
            /// </summary>
            public const string ProjectOrCategoryResource = "RESOURCE";
            /// <summary>
            /// Property for CostClass 
            /// </summary>
            public const string CostClass = "COSTCLASS";
            /// <summary>
            /// Property for BillingType 
            /// </summary>
            public const string BillingType = "BILLTYPE";
            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "IDITEM";
            /// <summary>
            /// Property for UnitofMeasure 
            /// </summary>
            public const string UnitofMeasure = "UNITMEAS";
            /// <summary>
            /// Property for Quantity 
            /// </summary>
            public const string Quantity = "QTYINVC";
            /// <summary>
            /// Property for Cost 
            /// </summary>
            public const string Cost = "AMTCOST";
            /// <summary>
            /// Property for BillingDate 
            /// </summary>
            public const string BillingDate = "BILLDATE";
            /// <summary>
            /// Property for BillingRate 
            /// </summary>
            public const string BillingRate = "BILLRATE";
            /// <summary>
            /// Property for BillingCurrency 
            /// </summary>
            public const string BillingCurrency = "BILLCURN";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHT1TC = "AMTWHT1TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHT2TC = "AMTWHT2TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHT3TC = "AMTWHT3TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHT4TC = "AMTWHT4TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHT5TC = "AMTWHT5TC";

            /// <summary>
            /// Property for Reverse Charges Amount 1
            /// </summary>
            public const string AmtCXTX1TC = "AMTCXTX1TC";

            /// <summary>
            /// Property for Reverse Charges Amount 2
            /// </summary>
            public const string AmtCXTX2TC = "AMTCXTX2TC";

            /// <summary>
            /// Property for Reverse Charges Amount 3
            /// </summary>
            public const string AmtCXTX3TC = "AMTCXTX3TC";

            /// <summary>
            /// Property for Reverse Charges Amount 4
            /// </summary>
            public const string AmtCXTX4TC = "AMTCXTX4TC";

            /// <summary>
            /// Property for Reverse Charges Amount 5
            /// </summary>
            public const string AmtCXTX5TC = "AMTCXTX5TC";


            #endregion
        }


        /// <summary>
        /// Contains list of MiscellaneousPayments Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 3;
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 4;
            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 6;
            /// <summary>
            /// Property Indexer for AccountNumber 
            /// </summary>
            public const int AccountNumber = 7;
            /// <summary>
            /// Property Indexer for GOrLReference 
            /// </summary>
            public const int GLReference = 8;
            /// <summary>
            /// Property Indexer for GOrLDescription 
            /// </summary>
            public const int GLDescription = 9;
            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 13;
            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 14;
            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 15;
            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 16;
            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 17;
            /// <summary>
            /// Property Indexer for TaxIncluded1 
            /// </summary>
            public const int TaxIncluded1 = 18;
            /// <summary>
            /// Property Indexer for TaxIncluded2 
            /// </summary>
            public const int TaxIncluded2 = 19;
            /// <summary>
            /// Property Indexer for TaxIncluded3 
            /// </summary>
            public const int TaxIncluded3 = 20;
            /// <summary>
            /// Property Indexer for TaxIncluded4 
            /// </summary>
            public const int TaxIncluded4 = 21;
            /// <summary>
            /// Property Indexer for TaxIncluded5 
            /// </summary>
            public const int TaxIncluded5 = 22;
            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 23;
            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 24;
            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 25;
            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 26;
            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 27;
            /// <summary>
            /// Property Indexer for TaxRate1 
            /// </summary>
            public const int TaxRate1 = 28;
            /// <summary>
            /// Property Indexer for TaxRate2 
            /// </summary>
            public const int TaxRate2 = 29;
            /// <summary>
            /// Property Indexer for TaxRate3 
            /// </summary>
            public const int TaxRate3 = 30;
            /// <summary>
            /// Property Indexer for TaxRate4 
            /// </summary>
            public const int TaxRate4 = 31;
            /// <summary>
            /// Property Indexer for TaxRate5 
            /// </summary>
            public const int TaxRate5 = 32;
            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 33;
            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 34;
            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 35;
            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 36;
            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 37;
            /// <summary>
            /// Property Indexer for TaxTotal 
            /// </summary>
            public const int TaxTotal = 38;
            /// <summary>
            /// Property Indexer for DistAmount 
            /// </summary>
            public const int DistAmount = 39;
            /// <summary>
            /// Property Indexer for DistAmountNetofTaxes 
            /// </summary>
            public const int DistAmountNetofTaxes = 40;
            /// <summary>
            /// Property Indexer for FuncDistAmount 
            /// </summary>
            public const int FuncDistAmount = 41;
            /// <summary>
            /// Property Indexer for FuncDistAmountNetofTaxes 
            /// </summary>
            public const int FuncDistAmountNetofTaxes = 42;
            /// <summary>
            /// Property Indexer for TaxAllocatedTotal 
            /// </summary>
            public const int TaxAllocatedTotal = 43;
            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1 
            /// </summary>
            public const int TaxAllocatedAmount1 = 44;
            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2 
            /// </summary>
            public const int TaxAllocatedAmount2 = 45;
            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3 
            /// </summary>
            public const int TaxAllocatedAmount3 = 46;
            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4 
            /// </summary>
            public const int TaxAllocatedAmount4 = 47;
            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5 
            /// </summary>
            public const int TaxAllocatedAmount5 = 48;
            /// <summary>
            /// Property Indexer for TaxRecoverable1 
            /// </summary>
            public const int TaxRecoverable1 = 49;
            /// <summary>
            /// Property Indexer for TaxRecoverable2 
            /// </summary>
            public const int TaxRecoverable2 = 50;
            /// <summary>
            /// Property Indexer for TaxRecoverable3 
            /// </summary>
            public const int TaxRecoverable3 = 51;
            /// <summary>
            /// Property Indexer for TaxRecoverable4 
            /// </summary>
            public const int TaxRecoverable4 = 52;
            /// <summary>
            /// Property Indexer for TaxRecoverable5 
            /// </summary>
            public const int TaxRecoverable5 = 53;
            /// <summary>
            /// Property Indexer for TaxExpensed1 
            /// </summary>
            public const int TaxExpensed1 = 54;
            /// <summary>
            /// Property Indexer for TaxExpensed2 
            /// </summary>
            public const int TaxExpensed2 = 55;
            /// <summary>
            /// Property Indexer for TaxExpensed3 
            /// </summary>
            public const int TaxExpensed3 = 56;
            /// <summary>
            /// Property Indexer for TaxExpensed4 
            /// </summary>
            public const int TaxExpensed4 = 57;
            /// <summary>
            /// Property Indexer for TaxExpensed5 
            /// </summary>
            public const int TaxExpensed5 = 58;
            /// <summary>
            /// Property Indexer for TaxReportingAmount1 
            /// </summary>
            public const int TaxReportingAmount1 = 59;
            /// <summary>
            /// Property Indexer for TaxReportingAmount2 
            /// </summary>
            public const int TaxReportingAmount2 = 60;
            /// <summary>
            /// Property Indexer for TaxReportingAmount3 
            /// </summary>
            public const int TaxReportingAmount3 = 61;
            /// <summary>
            /// Property Indexer for TaxReportingAmount4 
            /// </summary>
            public const int TaxReportingAmount4 = 62;
            /// <summary>
            /// Property Indexer for TaxReportingAmount5 
            /// </summary>
            public const int TaxReportingAmount5 = 63;
            /// <summary>
            /// Property Indexer for TaxReportingTotal 
            /// </summary>
            public const int TaxReportingTotal = 64;
            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount 
            /// </summary>
            public const int TaxReportingAllocatedAmount = 65;
            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt1 
            /// </summary>
            public const int TaxReportingRecoverableAmt1 = 66;
            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt2 
            /// </summary>
            public const int TaxReportingRecoverableAmt2 = 67;
            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt3 
            /// </summary>
            public const int TaxReportingRecoverableAmt3 = 68;
            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt4 
            /// </summary>
            public const int TaxReportingRecoverableAmt4 = 69;
            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt5 
            /// </summary>
            public const int TaxReportingRecoverableAmt5 = 70;
            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount1 
            /// </summary>
            public const int TaxReportingExpensedAmount1 = 71;
            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount2 
            /// </summary>
            public const int TaxReportingExpensedAmount2 = 72;
            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount3 
            /// </summary>
            public const int TaxReportingExpensedAmount3 = 73;
            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount4 
            /// </summary>
            public const int TaxReportingExpensedAmount4 = 74;
            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount5 
            /// </summary>
            public const int TaxReportingExpensedAmount5 = 75;
            /// <summary>
            /// Property Indexer for FuncTaxBase1 
            /// </summary>
            public const int FuncTaxBase1 = 76;
            /// <summary>
            /// Property Indexer for FuncTaxBase2 
            /// </summary>
            public const int FuncTaxBase2 = 77;
            /// <summary>
            /// Property Indexer for FuncTaxBase3 
            /// </summary>
            public const int FuncTaxBase3 = 78;
            /// <summary>
            /// Property Indexer for FuncTaxBase4 
            /// </summary>
            public const int FuncTaxBase4 = 79;
            /// <summary>
            /// Property Indexer for FuncTaxBase5 
            /// </summary>
            public const int FuncTaxBase5 = 80;
            /// <summary>
            /// Property Indexer for FuncTaxAmount1 
            /// </summary>
            public const int FuncTaxAmount1 = 81;
            /// <summary>
            /// Property Indexer for FuncTaxAmount2 
            /// </summary>
            public const int FuncTaxAmount2 = 82;
            /// <summary>
            /// Property Indexer for FuncTaxAmount3 
            /// </summary>
            public const int FuncTaxAmount3 = 83;
            /// <summary>
            /// Property Indexer for FuncTaxAmount4 
            /// </summary>
            public const int FuncTaxAmount4 = 84;
            /// <summary>
            /// Property Indexer for FuncTaxAmount5 
            /// </summary>
            public const int FuncTaxAmount5 = 85;
            /// <summary>
            /// Property Indexer for FuncTaxAllocatedTotal 
            /// </summary>
            public const int FuncTaxAllocatedTotal = 86;
            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount1 
            /// </summary>
            public const int FuncTaxAllocatedAmount1 = 87;
            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount2 
            /// </summary>
            public const int FuncTaxAllocatedAmount2 = 88;
            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount3 
            /// </summary>
            public const int FuncTaxAllocatedAmount3 = 89;
            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount4 
            /// </summary>
            public const int FuncTaxAllocatedAmount4 = 90;
            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount5 
            /// </summary>
            public const int FuncTaxAllocatedAmount5 = 91;
            /// <summary>
            /// Property Indexer for FuncTaxRecoverable1 
            /// </summary>
            public const int FuncTaxRecoverable1 = 92;
            /// <summary>
            /// Property Indexer for FuncTaxRecoverable2 
            /// </summary>
            public const int FuncTaxRecoverable2 = 93;
            /// <summary>
            /// Property Indexer for FuncTaxRecoverable3 
            /// </summary>
            public const int FuncTaxRecoverable3 = 94;
            /// <summary>
            /// Property Indexer for FuncTaxRecoverable4 
            /// </summary>
            public const int FuncTaxRecoverable4 = 95;
            /// <summary>
            /// Property Indexer for FuncTaxRecoverable5 
            /// </summary>
            public const int FuncTaxRecoverable5 = 96;
            /// <summary>
            /// Property Indexer for FuncTaxExpensed1 
            /// </summary>
            public const int FuncTaxExpensed1 = 97;
            /// <summary>
            /// Property Indexer for FuncTaxExpensed2 
            /// </summary>
            public const int FuncTaxExpensed2 = 98;
            /// <summary>
            /// Property Indexer for FuncTaxExpensed3 
            /// </summary>
            public const int FuncTaxExpensed3 = 99;
            /// <summary>
            /// Property Indexer for FuncTaxExpensed4 
            /// </summary>
            public const int FuncTaxExpensed4 = 100;
            /// <summary>
            /// Property Indexer for FuncTaxExpensed5 
            /// </summary>
            public const int FuncTaxExpensed5 = 101;
            /// <summary>
            /// Property Indexer for FuncTaxTotal 
            /// </summary>
            public const int FuncTaxTotal = 102;
            /// <summary>
            /// Property Indexer for ContractCode 
            /// </summary>
            public const int ContractCode = 103;
            /// <summary>
            /// Property Indexer for ProjectCode 
            /// </summary>
            public const int ProjectCode = 104;
            /// <summary>
            /// Property Indexer for CategoryCode 
            /// </summary>
            public const int CategoryCode = 105;
            /// <summary>
            /// Property Indexer for ProjectOrCategoryResource 
            /// </summary>
            public const int ProjectOrCategoryResource = 106;
            /// <summary>
            /// Property Indexer for CostClass 
            /// </summary>
            public const int CostClass = 107;
            /// <summary>
            /// Property Indexer for BillingType 
            /// </summary>
            public const int BillingType = 108;
            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 109;
            /// <summary>
            /// Property Indexer for UnitofMeasure 
            /// </summary>
            public const int UnitofMeasure = 110;
            /// <summary>
            /// Property Indexer for Quantity 
            /// </summary>
            public const int Quantity = 111;
            /// <summary>
            /// Property Indexer for Cost 
            /// </summary>
            public const int Cost = 112;
            /// <summary>
            /// Property Indexer for BillingDate 
            /// </summary>
            public const int BillingDate = 113;
            /// <summary>
            /// Property Indexer for BillingRate 
            /// </summary>
            public const int BillingRate = 114;
            /// <summary>
            /// Property Indexer for BillingCurrency 
            /// </summary>
            public const int BillingCurrency = 115;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHT1TC = 116;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHT2TC = 117;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHT3TC = 118;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHT4TC = 119;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHT5TC = 120;
            /// <summary>
            /// Indexer for Reverse Charges Amount 1
            /// </summary>
            public const int AmtCXTX1TC = 121;

            /// <summary>
            /// Indexer for Reverse Charges Amount 2
            /// </summary>
            public const int AmtCXTX2TC = 122;

            /// <summary>
            /// Indexer for Reverse Charges Amount 3
            /// </summary>
            public const int AmtCXTX3TC = 123;

            /// <summary>
            /// Indexer for Reverse Charges Amount 4
            /// </summary>
            public const int AmtCXTX4TC = 124;

            /// <summary>
            /// Indexer for Reverse Charges Amount 5
            /// </summary>
            public const int AmtCXTX5TC = 125;

            #endregion
        }


    }
}
