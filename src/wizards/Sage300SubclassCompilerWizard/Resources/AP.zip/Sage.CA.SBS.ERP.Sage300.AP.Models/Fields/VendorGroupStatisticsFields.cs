/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of VendorGroupStatistics Constants 
    /// </summary>
	public partial class VendorGroupStatistics 
	{
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "AP0017";

        /// <summary>
        /// Contains list of VendorGroupStatistics Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties

	    /// <summary>
        /// Property for Groupcode 
        /// </summary>
	    public const string Groupcode  = "IDGRP";

	    /// <summary>
        /// Property for Year 
        /// </summary>
	    public const string Year  = "CNTYR";

	    /// <summary>
        /// Property for Period 
        /// </summary>
	    public const string Period  = "CNTPERD";

	    /// <summary>
        /// Property for NumberofInvoices 
        /// </summary>
	    public const string NumberofInvoices  = "CNTINVC";

	    /// <summary>
        /// Property for NumberofCreditNotes 
        /// </summary>
	    public const string NumberofCreditNotes  = "CNTCR";

	    /// <summary>
        /// Property for NumberofDebitNotes 
        /// </summary>
	    public const string NumberofDebitNotes  = "CNTDR";

	    /// <summary>
        /// Property for NumberofPayments 
        /// </summary>
	    public const string NumberofPayments  = "CNTPAYM";

	    /// <summary>
        /// Property for NumberofDiscounts 
        /// </summary>
	    public const string NumberofDiscounts  = "CNTDISC";

	    /// <summary>
        /// Property for NumberofDiscountsLost 
        /// </summary>
	    public const string NumberofDiscountsLost  = "CNTLOST";

	    /// <summary>
        /// Property for NumberofAdjustments 
        /// </summary>
	    public const string NumberofAdjustments  = "CNTADJ";

	    /// <summary>
        /// Property for NumberofPaidInvoices 
        /// </summary>
	    public const string NumberofPaidInvoices  = "CNTINVCPD";

	    /// <summary>
        /// Property for NumberofDaystoPay 
        /// </summary>
	    public const string NumberofDaystoPay  = "CNTDTOPAY";

	    /// <summary>
        /// Property for TotalInvoicesAmount 
        /// </summary>
	    public const string TotalInvoicesAmount  = "AMTINVCHC";

	    /// <summary>
        /// Property for TotalCreditNoteAmount 
        /// </summary>
	    public const string TotalCreditNoteAmount  = "AMTCRHC";

	     /// <summary>
        /// Property for TotalDebitNoteAmount 
        /// </summary>
	    public const string TotalDebitNoteAmount  = "AMTDRHC";

	    /// <summary>
        /// Property for TotalPaymentAmount 
        /// </summary>
	    public const string TotalPaymentAmount  = "AMTPAYMHC";

	    /// <summary>
        /// Property for TotalDiscountAmount 
        /// </summary>
	    public const string TotalDiscountAmount  = "AMTDISCHC";

	    /// <summary>
        /// Property for TotalDiscountAmountLost 
        /// </summary>
	    public const string TotalDiscountAmountLost  = "AMTLOSTHC";

	    /// <summary>
        /// Property for TotalAdjustmentAmount 
        /// </summary>
	    public const string TotalAdjustmentAmount  = "AMTADJHC";

	    /// <summary>
        /// Property for TotalAmountofPaidInvoices 
        /// </summary>
	    public const string TotalAmountofPaidInvoices  = "AMTINVPDHC";

	    /// <summary>
        /// Property for AverageDaystoPay 
        /// </summary>
	    public const string AverageDaystoPay  = "AVGDAYSPAY";

	    /// <summary>
        /// Property for YTDNumberofInvoices 
        /// </summary>
	    public const string YTDNumberofInvoices  = "YTDCNTIN";

	    /// <summary>
        /// Property for YTDNumberofCreditNotes 
        /// </summary>
	    public const string YTDNumberofCreditNotes  = "YTDCNTCR";

	    /// <summary>
        /// Property for YTDNumberofDebitNotes 
        /// </summary>
	    public const string YTDNumberofDebitNotes  = "YTDCNTDR";

	    /// <summary>
        /// Property for YTDNumberofPayments 
        /// </summary>
	    public const string YTDNumberofPayments  = "YTDCNTPY";

	    /// <summary>
        /// Property for YTDNumberofDiscounts 
        /// </summary>
	    public const string YTDNumberofDiscounts  = "YTDCNTED";

	    /// <summary>
        /// Property for YTDNumberofDiscountsLost 
        /// </summary>
	    public const string YTDNumberofDiscountsLost  = "YTDCNTLOST";

	    /// <summary>
        /// Property for YTDNumberofAdjustments 
        /// </summary>
	    public const string YTDNumberofAdjustments  = "YTDCNTAD";

	     /// <summary>
        /// Property for YTDNumberofPaidInvoices 
        /// </summary>
	    public const string YTDNumberofPaidInvoices  = "YTDCNTINPD";

	    /// <summary>
        /// Property for YTDNumberofDaystoPay 
        /// </summary>
	    public const string YTDNumberofDaystoPay  = "YTDCNTDTP";

	    /// <summary>
        /// Property for YTDInvoicesinFuncCurr 
        /// </summary>
	    public const string YTDInvoicesinFuncCurr  = "YTDHCIN";

	    /// <summary>
        /// Property for YTDCreditsinFuncCurr 
        /// </summary>
	    public const string YTDCreditsinFuncCurr  = "YTDHCCR";

	    /// <summary>
        /// Property for YTDDebitsinFuncCurr 
        /// </summary>
	    public const string YTDDebitsinFuncCurr  = "YTDHCDR";

	    /// <summary>
        /// Property for YTDPaymentsinFuncCurr 
        /// </summary>
	    public const string YTDPaymentsinFuncCurr  = "YTDHCPY";

	    /// <summary>
        /// Property for YTDDiscountsinFuncCurr 
        /// </summary>
	    public const string YTDDiscountsinFuncCurr  = "YTDHCED";

	    /// <summary>
        /// Property for YTDDiscountsLostFuncCurr 
        /// </summary>
	    public const string YTDDiscountsLostFuncCurr  = "YTDHCLOST";

	    /// <summary>
        /// Property for YTDAdjustmentsinFuncCurr 
        /// </summary>
	    public const string YTDAdjustmentsinFuncCurr  = "YTDHCAD";

	    /// <summary>
        /// Property for YTDInvoicesPdinFuncCurr 
        /// </summary>
	    public const string YTDInvoicesPdinFuncCurr  = "YTDHCINPD";

	    /// <summary>
        /// Property for YTDAverageDaystoPay 
        /// </summary>
	    public const string YTDAverageDaystoPay  = "YTDCNTADTP";

	    /// <summary>
        /// Property for EnableYTDCalculations 
        /// </summary>
	    public const string EnableYTDCalculations  = "YTDACTIVE";
	     
        #endregion
	    }
        
		/// <summary>
        /// Contains list of VendorGroupStatistics Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties

	    /// <summary>
        /// Property Indexer for Groupcode 
        /// </summary>
	    public const int Groupcode  = 1;

	    /// <summary>
        /// Property Indexer for Year 
        /// </summary>
	    public const int Year  = 2;

	    /// <summary>
        /// Property Indexer for Period 
        /// </summary>
	    public const int Period  = 3;

	    /// <summary>
        /// Property Indexer for NumberofInvoices 
        /// </summary>
	    public const int NumberofInvoices  = 4;

	     /// <summary>
        /// Property Indexer for NumberofCreditNotes 
        /// </summary>
	    public const int NumberofCreditNotes  = 5;

	    /// <summary>
        /// Property Indexer for NumberofDebitNotes 
        /// </summary>
	    public const int NumberofDebitNotes  = 6;

	     /// <summary>
        /// Property Indexer for NumberofPayments 
        /// </summary>
	    public const int NumberofPayments  = 7;

	     /// <summary>
        /// Property Indexer for NumberofDiscounts 
        /// </summary>
	    public const int NumberofDiscounts  = 8;

	    /// <summary>
        /// Property Indexer for NumberofDiscountsLost 
        /// </summary>
	    public const int NumberofDiscountsLost  = 9;

	    /// <summary>
        /// Property Indexer for NumberofAdjustments 
        /// </summary>
	    public const int NumberofAdjustments  = 10;

	    /// <summary>
        /// Property Indexer for NumberofPaidInvoices 
        /// </summary>
	    public const int NumberofPaidInvoices  = 11;

	    /// <summary>
        /// Property Indexer for NumberofDaystoPay 
        /// </summary>
	    public const int NumberofDaystoPay  = 12;

	    /// <summary>
        /// Property Indexer for TotalInvoicesAmount 
        /// </summary>
	    public const int TotalInvoicesAmount  = 13;

	    /// <summary>
        /// Property Indexer for TotalCreditNoteAmount 
        /// </summary>
	    public const int TotalCreditNoteAmount  = 14;

	    /// <summary>
        /// Property Indexer for TotalDebitNoteAmount 
        /// </summary>
	    public const int TotalDebitNoteAmount  = 15;

	    /// <summary>
        /// Property Indexer for TotalPaymentAmount 
        /// </summary>
	    public const int TotalPaymentAmount  = 16;

	    /// <summary>
        /// Property Indexer for TotalDiscountAmount 
        /// </summary>
	    public const int TotalDiscountAmount  = 17;

	    /// <summary>
        /// Property Indexer for TotalDiscountAmountLost 
        /// </summary>
	    public const int TotalDiscountAmountLost  = 18;

	    /// <summary>
        /// Property Indexer for TotalAdjustmentAmount 
        /// </summary>
	    public const int TotalAdjustmentAmount  = 19;

	    /// <summary>
        /// Property Indexer for TotalAmountofPaidInvoices 
        /// </summary>
	    public const int TotalAmountofPaidInvoices  = 20;

	    /// <summary>
        /// Property Indexer for AverageDaystoPay 
        /// </summary>
	    public const int AverageDaystoPay  = 21;

	    /// <summary>
        /// Property Indexer for YTDNumberofInvoices 
        /// </summary>
	    public const int YTDNumberofInvoices  = 23;

	    /// <summary>
        /// Property Indexer for YTDNumberofCreditNotes 
        /// </summary>
	    public const int YTDNumberofCreditNotes  = 24;

	    /// <summary>
        /// Property Indexer for YTDNumberofDebitNotes 
        /// </summary>
	    public const int YTDNumberofDebitNotes  = 25;

	    /// <summary>
        /// Property Indexer for YTDNumberofPayments 
        /// </summary>
	    public const int YTDNumberofPayments  = 26;

	    /// <summary>
        /// Property Indexer for YTDNumberofDiscounts 
        /// </summary>
	    public const int YTDNumberofDiscounts  = 27;

	    /// <summary>
        /// Property Indexer for YTDNumberofDiscountsLost 
        /// </summary>
	    public const int YTDNumberofDiscountsLost  = 28;

	    /// <summary>
        /// Property Indexer for YTDNumberofAdjustments 
        /// </summary>
	    public const int YTDNumberofAdjustments  = 29;

	    /// <summary>
        /// Property Indexer for YTDNumberofPaidInvoices 
        /// </summary>
	    public const int YTDNumberofPaidInvoices  = 30;

	    /// <summary>
        /// Property Indexer for YTDNumberofDaystoPay 
        /// </summary>
	    public const int YTDNumberofDaystoPay  = 31;

	    /// <summary>
        /// Property Indexer for YTDInvoicesinFuncCurr 
        /// </summary>
	    public const int YTDInvoicesinFuncCurr  = 32;

	    /// <summary>
        /// Property Indexer for YTDCreditsinFuncCurr 
        /// </summary>
	    public const int YTDCreditsinFuncCurr  = 33;

	     /// <summary>
        /// Property Indexer for YTDDebitsinFuncCurr 
        /// </summary>
	    public const int YTDDebitsinFuncCurr  = 34;

	    /// <summary>
        /// Property Indexer for YTDPaymentsinFuncCurr 
        /// </summary>
	    public const int YTDPaymentsinFuncCurr  = 35;

	     /// <summary>
        /// Property Indexer for YTDDiscountsinFuncCurr 
        /// </summary>
	    public const int YTDDiscountsinFuncCurr  = 36;

	    /// <summary>
        /// Property Indexer for YTDDiscountsLostFuncCurr 
        /// </summary>
	    public const int YTDDiscountsLostFuncCurr  = 37;

	    /// <summary>
        /// Property Indexer for YTDAdjustmentsinFuncCurr 
        /// </summary>
	    public const int YTDAdjustmentsinFuncCurr  = 38;

	    /// <summary>
        /// Property Indexer for YTDInvoicesPdinFuncCurr 
        /// </summary>
	    public const int YTDInvoicesPdinFuncCurr  = 39;

	     /// <summary>
        /// Property Indexer for YTDAverageDaystoPay 
        /// </summary>
	    public const int YTDAverageDaystoPay  = 40;

	    /// <summary>
        /// Property Indexer for EnableYTDCalculations 
        /// </summary>
	    public const int EnableYTDCalculations  = 41;
	     
        #endregion
	    }
	}
}
	