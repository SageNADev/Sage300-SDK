/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of Terms Code Detail Constants 
    /// </summary>
    public partial class TermCodeDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0011";

        /// <summary>
        /// Contains list of TermsCodeDetail Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for TermsCode 
            /// </summary>
            public const string TermsCode = "TERMSCODE";
            /// <summary>
            /// Property for PaymentNumber 
            /// </summary>
            public const string PaymentNumber = "PAYMNBR";
            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";
            /// <summary>
            /// Property for PercentageDue 
            /// </summary>
            public const string PercentDue = "PCTPAYMDUE";
            /// <summary>
            /// Property for DiscountPercent 
            /// </summary>
            public const string DiscountPercent = "PCTDISC";
            /// <summary>
            /// Property for DiscountNumberofDays 
            /// </summary>
            public const string DiscountNumberofDays = "DISNBRDAYS";
            /// <summary>
            /// Property for DiscountDayofMonth 
            /// </summary>
            public const string DiscountDayofMonth = "DISCDAY";
            /// <summary>
            /// Property for DueNumberofDays 
            /// </summary>
            public const string DueNumberofDays = "DUENBRDAYS";
            /// <summary>
            /// Property for DueDayofMonth 
            /// </summary>
            public const string DueDayofMonth = "DUEDAY";

            #endregion
        }


        /// <summary>
        /// Contains list of TermsCodeDetail Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for TermsCode 
            /// </summary>
            public const int TermsCode = 1;
            /// <summary>
            /// Property Indexer for PaymentNumber 
            /// </summary>
            public const int PaymentNumber = 2;
            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 3;
            /// <summary>
            /// Property Indexer for PercentageDue 
            /// </summary>
            public const int PercentDue = 4;
            /// <summary>
            /// Property Indexer for DiscountPercent 
            /// </summary>
            public const int DiscountPercent = 6;
            /// <summary>
            /// Property Indexer for DiscountNumberofDays 
            /// </summary>
            public const int DiscountNumberofDays = 7;
            /// <summary>
            /// Property Indexer for DiscountDayofMonth 
            /// </summary>
            public const int DiscountDayofMonth = 8;
            /// <summary>
            /// Property Indexer for DueNumberofDays 
            /// </summary>
            public const int DueNumberofDays = 10;
            /// <summary>
            /// Property Indexer for DueDayofMonth 
            /// </summary>
            public const int DueDayofMonth = 11;

            #endregion
        }
    }
}
