// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CreateOpenDocumentList Constants 
    /// </summary>
	public partial class CreateOpenDocumentList
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0048";

        /// <summary>
        /// Contains list of CreateOpenDocumentList Fields Constants
        /// </summary>
	    public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for PaymentType 
            /// </summary>
            public const string PaymentType = "PAYMTYPE";
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTRMIT";
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "CNTKEY";
            /// <summary>
            /// Property for NumberofPaymentsScheduled 
            /// </summary>
            public const string NumberofPaymentsScheduled = "PAYMSCHD";
            /// <summary>
            /// Property for ProcessType 
            /// </summary>
            public const string ProcessType = "PROTYPE";
            /// <summary>
            /// Property for ShowType 
            /// </summary>
            public const string ShowType = "SHOWTYPE";
            /// <summary>
            /// Property for OrderBy 
            /// </summary>
            public const string OrderBy = "ORDERBY";
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";
            /// <summary>
            /// Property for InvoiceNumber 
            /// </summary>
            public const string InvoiceNumber = "IDINVC";
            /// <summary>
            /// Property for CheckNumber 
            /// </summary>
            public const string CheckNumber = "IDRMIT";
            /// <summary>
            /// Property for PONumber 
            /// </summary>
            public const string PONumber = "VENDPO";
            /// <summary>
            /// Property for OrderNumber 
            /// </summary>
            public const string OrderNumber = "ORDRNBR";
            /// <summary>
            /// Property for DocumentType 
            /// </summary>
            public const string DocumentType = "TRXTYPE";
            /// <summary>
            /// Property for DueDate 
            /// </summary>
            public const string DueDate = "DATEDUE";
            /// <summary>
            /// Property for DiscountDate 
            /// </summary>
            public const string DiscountDate = "DATEDISC";
            /// <summary>
            /// Property for InvoiceDate 
            /// </summary>
            public const string InvoiceDate = "DATEINVC";
            /// <summary>
            /// Property for PaymentScheduleAmountDue 
            /// </summary>
            public const string PaymentScheduleAmountDue = "AMTDUE";
            /// <summary>
            /// Property for PaymentScheduleAmountNet 
            /// </summary>
            public const string PaymentScheduleAmountNet = "AMTNET";
            /// <summary>
            /// Property for PaymentScheduleAmountDisc 
            /// </summary>
            public const string PaymentScheduleAmountDisc = "AMTDISC";
            /// <summary>
            /// Property for PaymentAmount 
            /// </summary>
            public const string PaymentAmount = "PAYMAMT";
            /// <summary>
            /// Property for DiscountAmountTaken 
            /// </summary>
            public const string DiscountAmountTaken = "DISCAMT";
            /// <summary>
            /// Property for Apply 
            /// </summary>
            public const string Apply = "APPLY";
            /// <summary>
            /// Property for Mode 
            /// </summary>
            public const string Mode = "MODE";
            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "IDTRXTYPE";
            /// <summary>
            /// Property for AdjustmentAmount 
            /// </summary>
            public const string AdjustmentAmount = "ADJAMT";
            /// <summary>
            /// Property for StartingDocumentNumber 
            /// </summary>
            public const string StartingDocumentNumber = "STDOCSTR";
            /// <summary>
            /// Property for StartingDate 
            /// </summary>
            public const string StartingDate = "STDOCDTE";
            /// <summary>
            /// Property for StartingAmount 
            /// </summary>
            public const string StartingAmount = "STDOCAMT";
            /// <summary>
            /// Property for RemitAmount 
            /// </summary>
            public const string RemitAmount = "AMTRMIT";
            /// <summary>
            /// Property for PaymentSchedDiscountAvail 
            /// </summary>
            public const string PaymentSchedDiscountAvail = "OBSDISC";
            /// <summary>
            /// Property for TCPLineNumber 
            /// </summary>
            public const string TCPLineNumber = "TCPLINE";
            /// <summary>
            /// Property for StartingVendorNumber 
            /// </summary>
            public const string StartingVendorNumber = "STRTVEND";
            /// <summary>
            /// Property for OriginalApply 
            /// </summary>
            public const string OriginalApply = "ORIGAPLY";
            /// <summary>
            /// Property for PendingPaymentAmount 
            /// </summary>
            public const string PendingPaymentAmount = "PNDPAYTOT";
            /// <summary>
            /// Property for PendingDiscountAmount 
            /// </summary>
            public const string PendingDiscountAmount = "PNDDSCTOT";
            /// <summary>
            /// Property for PendingAdjustmentAmount 
            /// </summary>
            public const string PendingAdjustmentAmount = "PNDADJTOT";
            /// <summary>
            /// Property for PendingBalance 
            /// </summary>
            public const string PendingBalance = "AMTPNDBAL";
            /// <summary>
            /// Property for OriginalDocumentTotal 
            /// </summary>
            public const string OriginalDocumentTotal = "AMTORIGDOC";
            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelated = "SWJOB";
            /// <summary>
            /// Property for OriginalDocNo 
            /// </summary>
            public const string OriginalDocNo = "RTGAPPLYTO";
            /// <summary>
            /// Property for OnHold 
            /// </summary>
            public const string OnHold = "SWHOLD";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";
            /// <summary>
            /// Property for Reference 
            /// </summary>
            public const string Reference = "TEXTREF";

            /// <summary>
            /// Property For Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHD1TC = "AMTWHD1TC";

            /// <summary>
            /// Property For Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHD2TC = "AMTWHD2TC";

            /// <summary>
            /// Property For Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHD3TC = "AMTWHD3TC";

            /// <summary>
            /// Property For Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHD4TC = "AMTWHD4TC";

            /// <summary>
            /// Property For Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHD5TC = "AMTWHD5TC";

            /// <summary>
            /// Property For Tax Withheld Amount Total
            /// </summary>
            public const string AmtWHDTot = "AMTWHDTOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 1
            /// </summary>
            public const string PndWHD1Tot = "PNDWHD1TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 2
            /// </summary>
            public const string PndWHD2Tot = "PNDWHD2TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 3
            /// </summary>
            public const string PndWHD3Tot = "PNDWHD3TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 4
            /// </summary>
            public const string PndWHD4Tot = "PNDWHD4TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 5
            /// </summary>
            public const string PndWHD5Tot = "PNDWHD5TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Total
            /// </summary>
            public const string PndWHDTot = "PNDWHDTOT";

            /// <summary>
            /// Property For Document Tax Authority 1
            /// </summary>
            public const string CodeTax1 = "CODETAX1";

            /// <summary>
            /// Property For Document Tax Authority 2
            /// </summary>
            public const string CodeTax2 = "CODETAX2";

            /// <summary>
            /// Property For Document Tax Authority 3
            /// </summary>
            public const string CodeTax3 = "CODETAX3";

            /// <summary>
            /// Property For Document Tax Authority 4
            /// </summary>
            public const string CodeTax4 = "CODETAX4";

            /// <summary>
            /// Property For Document Tax Authority 5
            /// </summary>
            public const string CodeTax5 = "CODETAX5";

            /// <summary>
            /// Property For Tax Auth 1 Description
            /// </summary>
            public const string TaxAuth1Description = "TXAU1DESC";

            /// <summary>
            /// Property For Tax Auth 2 Description
            /// </summary>
            public const string TaxAuth2Description = "TXAU2DESC";

            /// <summary>
            /// Property For Tax Auth 3 Description
            /// </summary>
            public const string TaxAuth3Description = "TXAU3DESC";

            /// <summary>
            /// Property For Tax Auth 4 Description
            /// </summary>
            public const string TaxAuth4Description = "TXAU4DESC";

            /// <summary>
            /// Property For Tax Auth 5 Description
            /// </summary>
            public const string TaxAuth5Description = "TXAU5DESC";

            /// <summary>
            /// Property for JobApplyMethod 
            /// </summary>
            public const string JobApplyMethod = "APPLYMETH";

            #endregion
        }


        /// <summary>
        /// Contains list of CreateOpenDocumentList Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for PaymentType 
            /// </summary>
            public const int PaymentType = 1;
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 3;
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 4;
            /// <summary>
            /// Property Indexer for NumberofPaymentsScheduled 
            /// </summary>
            public const int NumberofPaymentsScheduled = 5;
            /// <summary>
            /// Property Indexer for ProcessType 
            /// </summary>
            public const int ProcessType = 6;
            /// <summary>
            /// Property Indexer for ShowType 
            /// </summary>
            public const int ShowType = 7;
            /// <summary>
            /// Property Indexer for OrderBy 
            /// </summary>
            public const int OrderBy = 8;
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 9;
            /// <summary>
            /// Property Indexer for InvoiceNumber 
            /// </summary>
            public const int InvoiceNumber = 10;
            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int CheckNumber = 11;
            /// <summary>
            /// Property Indexer for PONumber 
            /// </summary>
            public const int PONumber = 12;
            /// <summary>
            /// Property Indexer for OrderNumber 
            /// </summary>
            public const int OrderNumber = 13;
            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 14;
            /// <summary>
            /// Property Indexer for DueDate 
            /// </summary>
            public const int DueDate = 15;
            /// <summary>
            /// Property Indexer for DiscountDate 
            /// </summary>
            public const int DiscountDate = 16;
            /// <summary>
            /// Property Indexer for InvoiceDate 
            /// </summary>
            public const int InvoiceDate = 17;
            /// <summary>
            /// Property Indexer for PaymentScheduleAmountDue 
            /// </summary>
            public const int PaymentScheduleAmountDue = 18;
            /// <summary>
            /// Property Indexer for PaymentScheduleAmountNet 
            /// </summary>
            public const int PaymentScheduleAmountNet = 19;
            /// <summary>
            /// Property Indexer for PaymentScheduleAmountDisc 
            /// </summary>
            public const int PaymentScheduleAmountDisc = 20;
            /// <summary>
            /// Property Indexer for PaymentAmount 
            /// </summary>
            public const int PaymentAmount = 21;
            /// <summary>
            /// Property Indexer for DiscountAmountTaken 
            /// </summary>
            public const int DiscountAmountTaken = 22;
            /// <summary>
            /// Property Indexer for Apply 
            /// </summary>
            public const int Apply = 23;
            /// <summary>
            /// Property Indexer for Mode 
            /// </summary>
            public const int Mode = 24;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 25;
            /// <summary>
            /// Property Indexer for AdjustmentAmount 
            /// </summary>
            public const int AdjustmentAmount = 26;
            /// <summary>
            /// Property Indexer for StartingDocumentNumber 
            /// </summary>
            public const int StartingDocumentNumber = 27;
            /// <summary>
            /// Property Indexer for StartingDate 
            /// </summary>
            public const int StartingDate = 28;
            /// <summary>
            /// Property Indexer for StartingAmount 
            /// </summary>
            public const int StartingAmount = 29;
            /// <summary>
            /// Property Indexer for RemitAmount 
            /// </summary>
            public const int RemitAmount = 30;
            /// <summary>
            /// Property Indexer for PaymentSchedDiscountAvail 
            /// </summary>
            public const int PaymentSchedDiscountAvail = 31;
            /// <summary>
            /// Property Indexer for TCPLineNumber 
            /// </summary>
            public const int TCPLineNumber = 32;
            /// <summary>
            /// Property Indexer for StartingVendorNumber 
            /// </summary>
            public const int StartingVendorNumber = 33;
            /// <summary>
            /// Property Indexer for OriginalApply 
            /// </summary>
            public const int OriginalApply = 34;
            /// <summary>
            /// Property Indexer for PendingPaymentAmount 
            /// </summary>
            public const int PendingPaymentAmount = 35;
            /// <summary>
            /// Property Indexer for PendingDiscountAmount 
            /// </summary>
            public const int PendingDiscountAmount = 36;
            /// <summary>
            /// Property Indexer for PendingAdjustmentAmount 
            /// </summary>
            public const int PendingAdjustmentAmount = 37;
            /// <summary>
            /// Property Indexer for PendingBalance 
            /// </summary>
            public const int PendingBalance = 38;
            /// <summary>
            /// Property Indexer for OriginalDocumentTotal 
            /// </summary>
            public const int OriginalDocumentTotal = 39;
            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 40;
            /// <summary>
            /// Property Indexer for OriginalDocNo 
            /// </summary>
            public const int OriginalDocNo = 41;
            /// <summary>
            /// Property Indexer for OnHold 
            /// </summary>
            public const int OnHold = 42;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 43;
            /// <summary>
            /// Property Indexer for Reference 
            /// </summary>
            public const int Reference = 44;

            /// <summary>
            /// Indexer For Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHD1TC = 45;

            /// <summary>
            /// Indexer For Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHD2TC = 46;

            /// <summary>
            /// Indexer For Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHD3TC = 47;

            /// <summary>
            /// Indexer For Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHD4TC = 48;

            /// <summary>
            /// Indexer For Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHD5TC = 49;

            /// <summary>
            /// Indexer For Tax Withheld Amount Total
            /// </summary>
            public const int AmtWHDTot = 50;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 1
            /// </summary>
            public const int PndWHD1Tot = 51;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 2
            /// </summary>
            public const int PndWHD2Tot = 52;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 3
            /// </summary>
            public const int PndWHD3Tot = 53;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 4
            /// </summary>
            public const int PndWHD4Tot = 54;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 5
            /// </summary>
            public const int PndWHD5Tot = 55;

            /// <summary>
            /// Indexer For Pending Tax Withheld Total
            /// </summary>
            public const int PndWHDTot = 56;

            /// <summary>
            /// Indexer For Document Tax Authority 1
            /// </summary>
            public const int CodeTax1 = 57;

            /// <summary>
            /// Indexer For Document Tax Authority 2
            /// </summary>
            public const int CodeTax2 = 58;

            /// <summary>
            /// Indexer For Document Tax Authority 3
            /// </summary>
            public const int CodeTax3 = 59;

            /// <summary>
            /// Indexer For Document Tax Authority 4
            /// </summary>
            public const int CodeTax4 = 60;

            /// <summary>
            /// Indexer For Document Tax Authority 5
            /// </summary>
            public const int CodeTax5 = 61;

            /// <summary>
            /// Indexer For Tax Auth 1 Description
            /// </summary>
            public const int TaxAuth1Description = 65;

            /// <summary>
            /// Indexer For Tax Auth 2 Description
            /// </summary>
            public const int TaxAuth2Description = 66;

            /// <summary>
            /// Indexer For Tax Auth 3 Description
            /// </summary>
            public const int TaxAuth3Description = 67;

            /// <summary>
            /// Indexer For Tax Auth 4 Description
            /// </summary>
            public const int TaxAuth4Description = 68;

            /// <summary>
            /// Indexer For Tax Auth 5 Description
            /// </summary>
            public const int TaxAuth5Description = 69;


            /// <summary>
            /// Indexer For ApplyMeth
            /// </summary>
            public const int JobApplyMethod = 70;

            #endregion
        }


    }
}
