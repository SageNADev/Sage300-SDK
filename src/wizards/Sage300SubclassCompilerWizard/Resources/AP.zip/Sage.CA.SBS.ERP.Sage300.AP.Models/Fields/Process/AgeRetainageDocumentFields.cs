// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of AgeRetainageDocuments Constants 
    /// </summary>
    public partial class AgeRetainageDocument
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0310";

        #endregion

        /// <summary>
        /// Contains list of AgeRetainageDocuments Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for RunDate 
            /// </summary>
            public const string RunDate = "RUNDATE";
            /// <summary>
            /// Property for RetainageDueDateCutoffDate 
            /// </summary>
            public const string RetainageDueDateCutoffDate = "CUTOFFDATE";
            /// <summary>
            /// Property for Cutoffby 
            /// </summary>
            public const string Cutoffby = "SWCUTOFFBY";
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string Year = "CUTOFFYEAR";
            /// <summary>
            /// Property for Period 
            /// </summary>
            public const string Period = "CUTOFFPERD";
            /// <summary>
            /// Property for FuncOrVendorCurrency 
            /// </summary>
            public const string FuncOrVendorCurrency = "AGETCURSW";
            /// <summary>
            /// Property for ATBOrOverdueRecReport 
            /// </summary>
            public const string ATBOrOverdueRecReport = "PASTDUESW";
            /// <summary>
            /// Property for DetailOrSummaryReport 
            /// </summary>
            public const string DetailOrSummaryReport = "SWDETAIL";
            /// <summary>
            /// Property for Current 
            /// </summary>
            public const string Current = "AGEPERIOD1";
            /// <summary>
            /// Property for FirstPeriod 
            /// </summary>
            public const string FirstPeriod = "AGEPERIOD2";
            /// <summary>
            /// Property for SecondPeriod 
            /// </summary>
            public const string SecondPeriod = "AGEPERIOD3";
            /// <summary>
            /// Property for ThirdPeriod 
            /// </summary>
            public const string ThirdPeriod = "AGEPERIOD4";
            /// <summary>
            /// Property for Range1From 
            /// </summary>
            public const string Range1From = "IDFROM1";
            /// <summary>
            /// Property for Range1To 
            /// </summary>
            public const string Range1To = "IDTO1";
            /// <summary>
            /// Property for Range1IndexValue 
            /// </summary>
            public const string Range1IndexValue = "INDEX1";
            /// <summary>
            /// Property for Range2From 
            /// </summary>
            public const string Range2From = "IDFROM2";
            /// <summary>
            /// Property for Range2To 
            /// </summary>
            public const string Range2To = "IDTO2";
            /// <summary>
            /// Property for Range2IndexValue 
            /// </summary>
            public const string Range2IndexValue = "INDEX2";
            /// <summary>
            /// Property for Range3From 
            /// </summary>
            public const string Range3From = "IDFROM3";
            /// <summary>
            /// Property for Range3To 
            /// </summary>
            public const string Range3To = "IDTO3";
            /// <summary>
            /// Property for Range3IndexValue 
            /// </summary>
            public const string Range3IndexValue = "INDEX3";
            /// <summary>
            /// Property for Range4From 
            /// </summary>
            public const string Range4From = "IDFROM4";
            /// <summary>
            /// Property for Range4To 
            /// </summary>
            public const string Range4To = "IDTO4";
            /// <summary>
            /// Property for Range4IndexValue 
            /// </summary>
            public const string Range4IndexValue = "INDEX4";
            /// <summary>
            /// Property for SequenceNumber 
            /// </summary>
            public const string SequenceNumber = "RTGSEQ";
            /// <summary>
            /// Property for FieldName1 
            /// </summary>
            public const string FieldName1 = "FIELDNAME1";
            /// <summary>
            /// Property for FieldName2 
            /// </summary>
            public const string FieldName2 = "FIELDNAME2";
            /// <summary>
            /// Property for FieldName3 
            /// </summary>
            public const string FieldName3 = "FIELDNAME3";
            /// <summary>
            /// Property for FieldName4 
            /// </summary>
            public const string FieldName4 = "FIELDNAME4";
            /// <summary>
            /// Property for IncludeTaxes 
            /// </summary>
            public const string IncludeTaxes = "SWTAX";

            #endregion
        }
        
        /// <summary>
        /// Contains list of AgeRetainageDocuments Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for RunDate 
            /// </summary>
            public const int RunDate = 1;
            /// <summary>
            /// Property Indexer for RetainageDueDateCutoffDate 
            /// </summary>
            public const int RetainageDueDateCutoffDate = 2;
            /// <summary>
            /// Property Indexer for Cutoffby 
            /// </summary>
            public const int Cutoffby = 3;
            /// <summary>
            /// Property Indexer for Year 
            /// </summary>
            public const int Year = 4;
            /// <summary>
            /// Property Indexer for Period 
            /// </summary>
            public const int Period = 5;
            /// <summary>
            /// Property Indexer for FuncOrVendorCurrency 
            /// </summary>
            public const int FuncOrVendorCurrency = 6;
            /// <summary>
            /// Property Indexer for ATBOrOverdueRecReport 
            /// </summary>
            public const int ATBOrOverdueRecReport = 7;
            /// <summary>
            /// Property Indexer for DetailOrSummaryReport 
            /// </summary>
            public const int DetailOrSummaryReport = 8;
            /// <summary>
            /// Property Indexer for Current 
            /// </summary>
            public const int Current = 9;
            /// <summary>
            /// Property Indexer for FirstPeriod 
            /// </summary>
            public const int FirstPeriod = 10;
            /// <summary>
            /// Property Indexer for SecondPeriod 
            /// </summary>
            public const int SecondPeriod = 11;
            /// <summary>
            /// Property Indexer for ThirdPeriod 
            /// </summary>
            public const int ThirdPeriod = 12;
            /// <summary>
            /// Property Indexer for Range1From 
            /// </summary>
            public const int Range1From = 13;
            /// <summary>
            /// Property Indexer for Range1To 
            /// </summary>
            public const int Range1To = 14;
            /// <summary>
            /// Property Indexer for Range1IndexValue 
            /// </summary>
            public const int Range1IndexValue = 15;
            /// <summary>
            /// Property Indexer for Range2From 
            /// </summary>
            public const int Range2From = 16;
            /// <summary>
            /// Property Indexer for Range2To 
            /// </summary>
            public const int Range2To = 17;
            /// <summary>
            /// Property Indexer for Range2IndexValue 
            /// </summary>
            public const int Range2IndexValue = 18;
            /// <summary>
            /// Property Indexer for Range3From 
            /// </summary>
            public const int Range3From = 19;
            /// <summary>
            /// Property Indexer for Range3To 
            /// </summary>
            public const int Range3To = 20;
            /// <summary>
            /// Property Indexer for Range3IndexValue 
            /// </summary>
            public const int Range3IndexValue = 21;
            /// <summary>
            /// Property Indexer for Range4From 
            /// </summary>
            public const int Range4From = 22;
            /// <summary>
            /// Property Indexer for Range4To 
            /// </summary>
            public const int Range4To = 23;
            /// <summary>
            /// Property Indexer for Range4IndexValue 
            /// </summary>
            public const int Range4IndexValue = 24;
            /// <summary>
            /// Property Indexer for SequenceNumber 
            /// </summary>
            public const int SequenceNumber = 25;
            /// <summary>
            /// Property Indexer for FieldName1 
            /// </summary>
            public const int FieldName1 = 26;
            /// <summary>
            /// Property Indexer for FieldName2 
            /// </summary>
            public const int FieldName2 = 27;
            /// <summary>
            /// Property Indexer for FieldName3 
            /// </summary>
            public const int FieldName3 = 28;
            /// <summary>
            /// Property Indexer for FieldName4 
            /// </summary>
            public const int FieldName4 = 29;
            /// <summary>
            /// Property Indexer for IncludeTaxes 
            /// </summary>
            public const int IncludeTaxes = 30;

            #endregion
        }
    }
}
