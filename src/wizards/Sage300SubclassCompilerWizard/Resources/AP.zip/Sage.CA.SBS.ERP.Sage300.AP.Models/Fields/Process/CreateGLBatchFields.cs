// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CreateGLBatch Constants 
    /// </summary>
    public partial class CreateGLBatch
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0042";

        #endregion

        /// <summary>
        /// Contains list of CreateGLBatch Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for ProcessPaymentBatch 
            /// </summary>
            public const string ProcessPaymentBatch = "SWPRCSSCA";

            /// <summary>
            /// Property for ThruPaymentPostingSeqNo 
            /// </summary>
            public const string ThruPaymentPostingSeqNo = "CATHRPSTSQ";

            /// <summary>
            /// Property for ProcessInvoiceBatch 
            /// </summary>
            public const string ProcessInvoiceBatch = "SWPRCSSIN";

            /// <summary>
            /// Property for ThruInvoicePostingSeqNo 
            /// </summary>
            public const string ThruInvoicePostingSeqNo = "INTHRPSTSQ";

            /// <summary>
            /// Property for ProcessAdjustmentBatch 
            /// </summary>
            public const string ProcessAdjustmentBatch = "SWPRCSSAD";

            /// <summary>
            /// Property for ThruAdjustmentPostingSeqNo 
            /// </summary>
            public const string ThruAdjustmentPostingSeqNo = "ADTHRPSTSQ";

            /// <summary>
            /// Property for ProcessRevalueBatch 
            /// </summary>
            public const string ProcessRevalueBatch = "SWPRCSSRV";

            /// <summary>
            /// Property for ThruRevaluePostingSeqNo 
            /// </summary>
            public const string ThruRevaluePostingSeqNo = "RVTHRPSTSQ";

            #endregion
        }

        /// <summary>
        /// Contains list of CreateGLBatch Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for ProcessPaymentBatch 
            /// </summary>
            public const int ProcessPaymentBatch = 1;

            /// <summary>
            /// Property Indexer for ThruPaymentPostingSeqNo 
            /// </summary>
            public const int ThruPaymentPostingSeqNo = 2;

            /// <summary>
            /// Property Indexer for ProcessInvoiceBatch 
            /// </summary>
            public const int ProcessInvoiceBatch = 3;

            /// <summary>
            /// Property Indexer for ThruInvoicePostingSeqNo 
            /// </summary>
            public const int ThruInvoicePostingSeqNo = 4;

            /// <summary>
            /// Property Indexer for ProcessAdjustmentBatch 
            /// </summary>
            public const int ProcessAdjustmentBatch = 5;

            /// <summary>
            /// Property Indexer for ThruAdjustmentPostingSeqNo 
            /// </summary>
            public const int ThruAdjustmentPostingSeqNo = 6;

            /// <summary>
            /// Property Indexer for ProcessRevalueBatch 
            /// </summary>
            public const int ProcessRevalueBatch = 7;

            /// <summary>
            /// Property Indexer for ThruRevaluePostingSeqNo 
            /// </summary>
            public const int ThruRevaluePostingSeqNo = 8;

            #endregion
        }
    }
}