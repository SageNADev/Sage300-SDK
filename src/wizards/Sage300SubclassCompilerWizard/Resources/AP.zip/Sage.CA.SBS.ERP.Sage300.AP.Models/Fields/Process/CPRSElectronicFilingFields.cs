/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Contains list of T5018(CPRS)ElectronicFiling Constants 
    /// </summary>
    public partial class CPRSElectronicFiling
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0112";

        /// <summary>
        /// Contains list of T5018(CPRS)ElectronicFiling Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for FromVendorNumber 
            /// </summary>
            public const string FromVendorNumber = "VENDORFROM";

            /// <summary>
            /// Property for ToVendorNumber 
            /// </summary>
            public const string ToVendorNumber = "VENDORTO";

            /// <summary>
            /// Property for FromCPRSCode 
            /// </summary>
            public const string FromCPRSCode = "CIDFROM";

            /// <summary>
            /// Property for ToCPRSCode 
            /// </summary>
            public const string ToCPRSCode = "CIDTO";

            /// <summary>
            /// Property for PaymentYear 
            /// </summary>
            public const string PaymentYear = "YEAR";

            /// <summary>
            /// Property for SubmissionReferenceID 
            /// </summary>
            public const string SubmissionReferenceID = "SBMTREFID";

            /// <summary>
            /// Property for ReportType 
            /// </summary>
            public const string ReportType = "FILETYPE";

            /// <summary>
            /// Property for TransmitterNumber 
            /// </summary>
            public const string TransmitterNumber = "TRANSNO";

            /// <summary>
            /// Property for TransmitterLanguage 
            /// </summary>
            public const string TransmitterLanguage = "TRANSLANG";

            /// <summary>
            /// Property for TransmitterNameLine1 
            /// </summary>
            public const string TransmitterNameLine1 = "TRANSNAME1";

            /// <summary>
            /// Property for TransmitterNameLine2 
            /// </summary>
            public const string TransmitterNameLine2 = "TRANSNAME2";

            /// <summary>
            /// Property for TransmitterAddressLine1 
            /// </summary>
            public const string TransmitterAddressLine1 = "TRANSADDR1";

            /// <summary>
            /// Property for TransmitterAddressLine2 
            /// </summary>
            public const string TransmitterAddressLine2 = "TRANSADDR2";

            /// <summary>
            /// Property for TransmitterCity 
            /// </summary>
            public const string TransmitterCity = "TRANSCITY";

            /// <summary>
            /// Property for TransmitterStateOrProvince 
            /// </summary>
            public const string TransmitterStateOrProvince = "TRANSSTATE";

            /// <summary>
            /// Property for TransmitterCountryCode 
            /// </summary>
            public const string TransmitterCountryCode = "TRANSCTRY";

            /// <summary>
            /// Property for TransmitterZipOrPostalCode 
            /// </summary>
            public const string TransmitterZipOrPostalCode = "TRANSZIP";

            /// <summary>
            /// Property for TransmitterContactName 
            /// </summary>
            public const string TransmitterContactName = "TRANSCNTCN";

            /// <summary>
            /// Property for TransmitterPhoneNumber 
            /// </summary>
            public const string TransmitterPhoneNumber = "TRANSPHONE";

            /// <summary>
            /// Property for TransmitterEmail 
            /// </summary>
            public const string TransmitterEmail = "TRANSEMAIL";

            /// <summary>
            /// Property for PayerAccountNumber 
            /// </summary>
            public const string PayerAccountNumber = "PAYERBN";

            /// <summary>
            /// Property for PayerNameLine1 
            /// </summary>
            public const string PayerNameLine1 = "PAYERNAME1";

            /// <summary>
            /// Property for PayerNameLine2 
            /// </summary>
            public const string PayerNameLine2 = "PAYERNAME2";

            /// <summary>
            /// Property for PayerAddressLine1 
            /// </summary>
            public const string PayerAddressLine1 = "PAYERADDR1";

            /// <summary>
            /// Property for PayerAddressLine2 
            /// </summary>
            public const string PayerAddressLine2 = "PAYERADDR2";

            /// <summary>
            /// Property for PayerCity 
            /// </summary>
            public const string PayerCity = "PAYERCITY";

            /// <summary>
            /// Property for PayerStateOrProvince 
            /// </summary>
            public const string PayerStateOrProvince = "PAYERSTATE";

            /// <summary>
            /// Property for PayerCountryCode 
            /// </summary>
            public const string PayerCountryCode = "PAYERCTRY";

            /// <summary>
            /// Property for PayerZipOrPostalCode 
            /// </summary>
            public const string PayerZipOrPostalCode = "PAYERZIP";

            /// <summary>
            /// Property for PayerContactName 
            /// </summary>
            public const string PayerContactName = "PAYERCNTCN";

            /// <summary>
            /// Property for PayerPhoneNumber 
            /// </summary>
            public const string PayerPhoneNumber = "PAYERPHONE";

            /// <summary>
            /// Property for FileName 
            /// </summary>
            public const string FileName = "FILENAME";

            /// <summary>
            /// Property for T5018SlipCount 
            /// </summary>
            public const string T5018SlipCount = "SLIPCOUNT";

            #endregion
        }


        /// <summary>
        /// Contains list of T5018(CPRS)ElectronicFiling Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for FromVendorNumber 
            /// </summary>
            public const int FromVendorNumber = 1;

            /// <summary>
            /// Property Indexer for ToVendorNumber 
            /// </summary>
            public const int ToVendorNumber = 2;

            /// <summary>
            /// Property Indexer for FromCPRSCode 
            /// </summary>
            public const int FromCPRSCode = 3;

            /// <summary>
            /// Property Indexer for ToCPRSCode 
            /// </summary>
            public const int ToCPRSCode = 4;

            /// <summary>
            /// Property Indexer for PaymentYear 
            /// </summary>
            public const int PaymentYear = 5;

            /// <summary>
            /// Property Indexer for SubmissionReferenceID 
            /// </summary>
            public const int SubmissionReferenceID = 6;

            /// <summary>
            /// Property Indexer for ReportType 
            /// </summary>
            public const int ReportType = 7;

            /// <summary>
            /// Property Indexer for TransmitterNumber 
            /// </summary>
            public const int TransmitterNumber = 8;

            /// <summary>
            /// Property Indexer for TransmitterLanguage 
            /// </summary>
            public const int TransmitterLanguage = 9;

            /// <summary>
            /// Property Indexer for TransmitterNameLine1 
            /// </summary>
            public const int TransmitterNameLine1 = 10;

            /// <summary>
            /// Property Indexer for TransmitterNameLine2 
            /// </summary>
            public const int TransmitterNameLine2 = 11;

            /// <summary>
            /// Property Indexer for TransmitterAddressLine1 
            /// </summary>
            public const int TransmitterAddressLine1 = 12;

            /// <summary>
            /// Property Indexer for TransmitterAddressLine2 
            /// </summary>
            public const int TransmitterAddressLine2 = 13;

            /// <summary>
            /// Property Indexer for TransmitterCity 
            /// </summary>
            public const int TransmitterCity = 14;

            /// <summary>
            /// Property Indexer for TransmitterStateOrProvince 
            /// </summary>
            public const int TransmitterStateOrProvince = 15;

            /// <summary>
            /// Property Indexer for TransmitterCountryCode 
            /// </summary>
            public const int TransmitterCountryCode = 16;

            /// <summary>
            /// Property Indexer for TransmitterZipOrPostalCode 
            /// </summary>
            public const int TransmitterZipOrPostalCode = 17;

            /// <summary>
            /// Property Indexer for TransmitterContactName 
            /// </summary>
            public const int TransmitterContactName = 18;

            /// <summary>
            /// Property Indexer for TransmitterPhoneNumber 
            /// </summary>
            public const int TransmitterPhoneNumber = 19;

            /// <summary>
            /// Property Indexer for TransmitterEmail 
            /// </summary>
            public const int TransmitterEmail = 20;

            /// <summary>
            /// Property Indexer for PayerAccountNumber 
            /// </summary>
            public const int PayerAccountNumber = 21;

            /// <summary>
            /// Property Indexer for PayerNameLine1 
            /// </summary>
            public const int PayerNameLine1 = 22;

            /// <summary>
            /// Property Indexer for PayerNameLine2 
            /// </summary>
            public const int PayerNameLine2 = 23;

            /// <summary>
            /// Property Indexer for PayerAddressLine1 
            /// </summary>
            public const int PayerAddressLine1 = 24;

            /// <summary>
            /// Property Indexer for PayerAddressLine2 
            /// </summary>
            public const int PayerAddressLine2 = 25;

            /// <summary>
            /// Property Indexer for PayerCity 
            /// </summary>
            public const int PayerCity = 26;

            /// <summary>
            /// Property Indexer for PayerStateOrProvince 
            /// </summary>
            public const int PayerStateOrProvince = 27;

            /// <summary>
            /// Property Indexer for PayerCountryCode 
            /// </summary>
            public const int PayerCountryCode = 28;

            /// <summary>
            /// Property Indexer for PayerZipOrPostalCode 
            /// </summary>
            public const int PayerZipOrPostalCode = 29;

            /// <summary>
            /// Property Indexer for PayerContactName 
            /// </summary>
            public const int PayerContactName = 30;

            /// <summary>
            /// Property Indexer for PayerPhoneNumber 
            /// </summary>
            public const int PayerPhoneNumber = 31;

            /// <summary>
            /// Property Indexer for FileName 
            /// </summary>
            public const int FileName = 32;

            /// <summary>
            /// Property Indexer for T5018SlipCount 
            /// </summary>
            public const int T5018SlipCount = 33;

            /// <summary>
            /// Property Indexer for IsCPRSElectronicFilingProcess 
            /// </summary>
            public const int ApplyCPRSElectronicFilingProcess = 34;

            /// <summary>
            /// Property Indexer for IsFormatPhoneNo 
            /// </summary>
            public const int IsFormatPhoneNo = 35;

            #endregion
        }
    }
}
