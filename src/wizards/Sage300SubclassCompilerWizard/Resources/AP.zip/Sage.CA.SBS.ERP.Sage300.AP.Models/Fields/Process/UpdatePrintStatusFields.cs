// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process

// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of UpdatePrintStatus Constants 
    /// </summary>
    public partial class UpdatePrintStatus
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0055";

        /// <summary>
        /// Contains list of UpdatePrintStatus Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for CommandCode 
            /// </summary>
            public const string CommandCode = "CMNDCODE";
            /// <summary>
            /// Property for StartingBatchRange 
            /// </summary>
            public const string StartingBatchRange = "CNTBTCHFRM";
            /// <summary>
            /// Property for EndingBatchRange 
            /// </summary>
            public const string EndingBatchRange = "CNTBTCHTO";
            /// <summary>
            /// Property for StartingSequenceRange 
            /// </summary>
            public const string StartingSequenceRange = "CNTSEQFROM";
            /// <summary>
            /// Property for EndingSequenceRange 
            /// </summary>
            public const string EndingSequenceRange = "CNTSEQTO";
            /// <summary>
            /// Property for StartingVendorRange 
            /// </summary>
            public const string StartingVendorRange = "IDCUSTFROM";
            /// <summary>
            /// Property for EndingVendorRange 
            /// </summary>
            public const string EndingVendorRange = "IDCUSTTO";
            /// <summary>
            /// Property for PostedOrUnposted 
            /// </summary>
            public const string PostedOrUnposted = "SWPOSTED";
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "IDBANK";
            /// <summary>
            /// Property for FromDate 
            /// </summary>
            public const string FromDate = "DATEFROM";
            /// <summary>
            /// Property for ToDate 
            /// </summary>
            public const string ToDate = "DATETO";
            /// <summary>
            /// Property for BatchTypeEntered 
            /// </summary>
            public const string BatchTypeEntered = "TYPEENTER";
            /// <summary>
            /// Property for BatchTypeImported 
            /// </summary>
            public const string BatchTypeImported = "TYPEIMPORT";
            /// <summary>
            /// Property for BatchTypeGenerated 
            /// </summary>
            public const string BatchTypeGenerated = "TYPEGENRTD";
            /// <summary>
            /// Property for BatchTypeSystem 
            /// </summary>
            public const string BatchTypeSystem = "TYPESYSTEM";
            /// <summary>
            /// Property for BatchStatusOpen 
            /// </summary>
            public const string BatchStatusOpen = "STTSOPEN";
            /// <summary>
            /// Property for BatchStatusReadytoPost 
            /// </summary>
            public const string BatchStatusReadyToPost = "STTSRDYTPT";
            /// <summary>
            /// Property for BatchTypeRecurring 
            /// </summary>
            public const string BatchTypeRecurring = "TYPERECURR";
            /// <summary>
            /// Property for BatchStatusPosted 
            /// </summary>
            public const string BatchStatusPosted = "STTSPOSTED";
            /// <summary>
            /// Property for BatchTypeExternal 
            /// </summary>
            public const string BatchTypeExternal = "TYPEEXTERN";
            /// <summary>
            /// Property for BatchTypeRetainage 
            /// </summary>
            public const string BatchTypeRetainage = "TYPERTNG";

            #endregion
        }

        /// <summary>
        /// Contains list of UpdatePrintStatus Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for CommandCode 
            /// </summary>
            public const int CommandCode = 1;
            /// <summary>
            /// Property Indexer for StartingBatchRange 
            /// </summary>
            public const int StartingBatchRange = 2;
            /// <summary>
            /// Property Indexer for EndingBatchRange 
            /// </summary>
            public const int EndingBatchRange = 3;
            /// <summary>
            /// Property Indexer for StartingSequenceRange 
            /// </summary>
            public const int StartingSequenceRange = 4;
            /// <summary>
            /// Property Indexer for EndingSequenceRange 
            /// </summary>
            public const int EndingSequenceRange = 5;
            /// <summary>
            /// Property Indexer for StartingVendorRange 
            /// </summary>
            public const int StartingVendorRange = 6;
            /// <summary>
            /// Property Indexer for EndingVendorRange 
            /// </summary>
            public const int EndingVendorRange = 7;
            /// <summary>
            /// Property Indexer for PostedOrUnposted 
            /// </summary>
            public const int PostedOrUnposted = 8;
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 9;
            /// <summary>
            /// Property Indexer for FromDate 
            /// </summary>
            public const int FromDate = 10;
            /// <summary>
            /// Property Indexer for ToDate 
            /// </summary>
            public const int ToDate = 11;
            /// <summary>
            /// Property Indexer for BatchTypeEntered 
            /// </summary>
            public const int BatchTypeEntered = 12;
            /// <summary>
            /// Property Indexer for BatchTypeImported 
            /// </summary>
            public const int BatchTypeImported = 13;
            /// <summary>
            /// Property Indexer for BatchTypeGenerated 
            /// </summary>
            public const int BatchTypeGenerated = 14;
            /// <summary>
            /// Property Indexer for BatchTypeSystem 
            /// </summary>
            public const int BatchTypeSystem = 15;
            /// <summary>
            /// Property Indexer for BatchStatusOpen 
            /// </summary>
            public const int BatchStatusOpen = 16;
            /// <summary>
            /// Property Indexer for BatchStatusReadytoPost 
            /// </summary>
            public const int BatchStatusReadyToPost = 17;
            /// <summary>
            /// Property Indexer for BatchTypeRecurring 
            /// </summary>
            public const int BatchTypeRecurring = 18;
            /// <summary>
            /// Property Indexer for BatchStatusPosted 
            /// </summary>
            public const int BatchStatusPosted = 19;
            /// <summary>
            /// Property Indexer for BatchTypeExternal 
            /// </summary>
            public const int BatchTypeExternal = 20;
            /// <summary>
            /// Property Indexer for BatchTypeRetainage 
            /// </summary>
            public const int BatchTypeRetainage = 21;

            #endregion
        }
    }
}
