// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
	/// <summary>
	/// Contains list of ClearFullyPaidDocument Constants
	/// </summary>
	public partial class ClearHistory
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "AP0049";

		#region Fields Properties

		/// <summary>
		/// Contains list of ClearFullyPaidDocument Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ClearFromVendorNumber
			/// </summary>
			public const string ClearFromVendorNumber = "STRTVENID";

			/// <summary>
			/// Property for ClearThruVendorNumber
			/// </summary>
			public const string ClearThruVendorNumber = "ENDVENID";

			/// <summary>
			/// Property for PostingDateCutoff
			/// </summary>
			public const string PostingDateCutoff = "CUTDATE";

			/// <summary>
			/// Property for ClearType
			/// </summary>
			public const string ClearType = "ATRPURGESW";

			/// <summary>
			/// Property for BatchType
			/// </summary>
			public const string BatchType = "TYPEBTCH";

			/// <summary>
			/// Property for ThruPostingSequenceNumber
			/// </summary>
			public const string ThruPostingSequenceNumber = "THRUPOST";

		}

		#endregion

		#region Index Properties

		/// <summary>
		/// Contains list of ClearFullyPaidDocument Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ClearFromVendorNumber
			/// </summary>
			public const int ClearFromVendorNumber = 1;

			/// <summary>
			/// Property Indexer for ClearThruVendorNumber
			/// </summary>
			public const int ClearThruVendorNumber = 2;

			/// <summary>
			/// Property Indexer for PostingDateCutoff
			/// </summary>
			public const int PostingDateCutoff = 3;

			/// <summary>
			/// Property Indexer for ClearType
			/// </summary>
			public const int ClearType = 4;

			/// <summary>
			/// Property Indexer for BatchType
			/// </summary>
			public const int BatchType = 5;

			/// <summary>
			/// Property Indexer for ThruPostingSequenceNumber
			/// </summary>
			public const int ThruPostingSequenceNumber = 6;

		}

		#endregion

	}
}
