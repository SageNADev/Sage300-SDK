// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Create Retainage Document Batch Constants
    /// </summary>
    public partial class CreateRetainageDocumentBatch
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0300";

        #endregion 

        #region Fields Properties

        /// <summary>
        /// Contains list of Create Retainage Document Batch Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Run Date
            /// </summary>
            public const string RunDate = "DATERUN";

            /// <summary>
            /// Property for Mode
            /// </summary>
            public const string Mode = "MODE";

            /// <summary>
            /// Property for Select Records By
            /// </summary>
            public const string SelectRecordsBy = "SELECTBY";

            /// <summary>
            /// Property for Starting Document Number
            /// </summary>
            public const string StartingDocumentNumber = "IDINVCFROM";

            /// <summary>
            /// Property for Ending Document Number
            /// </summary>
            public const string EndingDocumentNumber = "IDINVCTO";

            /// <summary>
            /// Property for Starting Vendor Number
            /// </summary>
            public const string StartingVendorNumber = "VENIDFROM";

            /// <summary>
            /// Property for Ending Vendor Number
            /// </summary>
            public const string EndingVendorNumber = "VENIDTO";

            /// <summary>
            /// Property for Starting Vendor Group Code
            /// </summary>
            public const string StartingVendorGroupCode = "VENGRPFROM";

            /// <summary>
            /// Property for Ending Vendor Group Code
            /// </summary>
            public const string EndingVendorGroupCode = "VENGRPTO";

            /// <summary>
            /// Property for Include Invoice
            /// </summary>
            public const string IncludeInvoice = "SWINVOICE";

            /// <summary>
            /// Property for Include Debit Note
            /// </summary>
            public const string IncludeDebitNote = "SWDEBIT";

            /// <summary>
            /// Property for Include Credit Note
            /// </summary>
            public const string IncludeCreditNote = "SWCREDIT";

            /// <summary>
            /// Property for Days Before Retainage Due
            /// </summary>
            public const string DaysBeforeRetainageDue = "RTGADVDAYS";

            /// <summary>
            /// Property for Command Code
            /// </summary>
            public const string CommandCode = "CMNDCODE";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "STATUS";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of Create Retainage Document Batch Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Run Date
            /// </summary>
            public const int RunDate = 1;

            /// <summary>
            /// Property Indexer for Mode
            /// </summary>
            public const int Mode = 2;

            /// <summary>
            /// Property Indexer for Select Records By
            /// </summary>
            public const int SelectRecordsBy = 3;

            /// <summary>
            /// Property Indexer for Starting Document Number
            /// </summary>
            public const int StartingDocumentNumber = 4;

            /// <summary>
            /// Property Indexer for Ending Document Number
            /// </summary>
            public const int EndingDocumentNumber = 5;

            /// <summary>
            /// Property Indexer for Starting Vendor Number
            /// </summary>
            public const int StartingVendorNumber = 6;

            /// <summary>
            /// Property Indexer for Ending Vendor Number
            /// </summary>
            public const int EndingVendorNumber = 7;

            /// <summary>
            /// Property Indexer for Starting Vendor Group Code
            /// </summary>
            public const int StartingVendorGroupCode = 8;

            /// <summary>
            /// Property Indexer for Ending Vendor Group Code
            /// </summary>
            public const int EndingVendorGroupCode = 9;

            /// <summary>
            /// Property Indexer for Include Invoice
            /// </summary>
            public const int IncludeInvoice = 10;

            /// <summary>
            /// Property Indexer for Include Debit Note
            /// </summary>
            public const int IncludeDebitNote = 11;

            /// <summary>
            /// Property Indexer for Include Credit Note
            /// </summary>
            public const int IncludeCreditNote = 12;

            /// <summary>
            /// Property Indexer for Days Before Retainage Due
            /// </summary>
            public const int DaysBeforeRetainageDue = 13;

            /// <summary>
            /// Property Indexer for Command Code
            /// </summary>
            public const int CommandCode = 14;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 15;
        }

        #endregion
    }
}
