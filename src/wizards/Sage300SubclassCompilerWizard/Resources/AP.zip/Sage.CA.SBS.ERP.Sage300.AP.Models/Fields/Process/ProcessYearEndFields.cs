﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ProcessYearEnd Constants 
    /// </summary>
    public partial class ProcessYearEnd
    {
        #region Constants

        /// <summary>
        /// View Name for AP0044
        /// </summary>
        public const string ViewName = "AP0044";

        #endregion

        /// <summary>
        /// Contains list of ProcessYearEnd Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for ResetBatchNumbers 
            /// </summary>
            public const string ResetBatchNumbers = "SWCLRBAT";

            /// <summary>
            /// Property for ClearPaidInvoices 
            /// </summary>
            public const string ClearPaidInvoices = "SWCLRINVPD";

            /// <summary>
            /// Property for RollVendorStatstoLastYr 
            /// </summary>
            public const string RollVendorStatstoLastYr = "SWROLLSTTS";

            /// <summary>
            /// Property for ClearRecurringPayables 
            /// </summary>
            public const string ClearRecurringPayables = "SWCLRRCUR";

            #endregion
        }
        
        /// <summary>
        /// Contains list of ProcessYearEnd Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for ResetBatchNumbers 
            /// </summary>
            public const int ResetBatchNumbers = 2;

            /// <summary>
            /// Property Indexer for ClearPaidInvoices 
            /// </summary>
            public const int ClearPaidInvoices = 3;

            /// <summary>
            /// Property Indexer for RollVendorStatstoLastYr 
            /// </summary>
            public const int RollVendorStatstoLastYr = 4;

            /// <summary>
            /// Property Indexer for ClearRecurringPayables 
            /// </summary>
            public const int ClearRecurringPayables = 5;

            #endregion
        }
    }
}
