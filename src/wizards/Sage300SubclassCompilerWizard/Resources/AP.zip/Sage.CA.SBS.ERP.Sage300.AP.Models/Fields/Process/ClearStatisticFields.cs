// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Contains list of ClearStatistic Constants
    /// </summary>
    public partial class ClearStatistic
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0051";

        #region Properties

        /// <summary>
        /// Contains list of ClearStatistic Field Constants
        /// </summary>
        public class Fields
        {

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for STRTVENID
            /// </summary>
            public const string STRTVENID = "STRTVENID";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ENDVENID
            /// </summary>
            public const string ENDVENID = "ENDVENID";

            /// <summary>
            /// Property for ClearFromGroupCode
            /// </summary>
            public const string ClearFromGroupCode = "STRTGRPID";

            /// <summary>
            /// Property for ClearThruGroupCode
            /// </summary>
            public const string ClearThruGroupCode = "ENDGRPID";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for STRTCCSID
            /// </summary>
            public const string STRTCCSID = "STRTCCSID";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ENDCCSID
            /// </summary>
            public const string ENDCCSID = "ENDCCSID";

            /// <summary>
            /// Property for Through1099CPRSYear
            /// </summary>
            public const string Through1099CPRSYear = "THRUYEAR";

            /// <summary>
            /// Property for Through1099CPRSPeriod
            /// </summary>
            public const string Through1099CPRSPeriod = "THRUPERD";

            /// <summary>
            /// Property for ClearVendorStatistics
            /// </summary>
            public const string ClearVendorStatistics = "SWPRGVSM";

            /// <summary>
            /// Property for ClearGroupStatistics
            /// </summary>
            public const string ClearGroupStatistics = "SWPRGVGS";

            /// <summary>
            /// Property for Clear1099CPRSStatistics
            /// </summary>
            public const string Clear1099CPRSStatistics = "SWPRGCCS";

            /// <summary>
            /// Property for ThroughVendorYear
            /// </summary>
            public const string ThroughVendorYear = "THRUVENYR";

            /// <summary>
            /// Property for ThroughVendorPeriod
            /// </summary>
            public const string ThroughVendorPeriod = "THRUVENPER";

            /// <summary>
            /// Property for ThroughGroupYear
            /// </summary>
            public const string ThroughGroupYear = "THRUGRPYR";

            /// <summary>
            /// Property for ThroughGroupPeriod
            /// </summary>
            public const string ThroughGroupPeriod = "THRUGRPPER";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of ClearStatistic Index Constants
        /// </summary>
        public class Index
        {

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for STRTVENID
            /// </summary>
            public const int STRTVENID = 1;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ENDVENID
            /// </summary>
            public const int ENDVENID = 2;

            /// <summary>
            /// Property Indexer for ClearFromGroupCode
            /// </summary>
            public const int ClearFromGroupCode = 3;

            /// <summary>
            /// Property Indexer for ClearThruGroupCode
            /// </summary>
            public const int ClearThruGroupCode = 4;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for STRTCCSID
            /// </summary>
            public const int STRTCCSID = 5;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ENDCCSID
            /// </summary>
            public const int ENDCCSID = 6;

            /// <summary>
            /// Property Indexer for Through1099CPRSYear
            /// </summary>
            public const int Through1099CPRSYear = 7;

            /// <summary>
            /// Property Indexer for Through1099CPRSPeriod
            /// </summary>
            public const int Through1099CPRSPeriod = 8;

            /// <summary>
            /// Property Indexer for ClearVendorStatistics
            /// </summary>
            public const int ClearVendorStatistics = 9;

            /// <summary>
            /// Property Indexer for ClearGroupStatistics
            /// </summary>
            public const int ClearGroupStatistics = 10;

            /// <summary>
            /// Property Indexer for Clear1099CPRSStatistics
            /// </summary>
            public const int Clear1099CPRSStatistics = 11;

            /// <summary>
            /// Property Indexer for ThroughVendorYear
            /// </summary>
            public const int ThroughVendorYear = 12;

            /// <summary>
            /// Property Indexer for ThroughVendorPeriod
            /// </summary>
            public const int ThroughVendorPeriod = 13;

            /// <summary>
            /// Property Indexer for ThroughGroupYear
            /// </summary>
            public const int ThroughGroupYear = 14;

            /// <summary>
            /// Property Indexer for ThroughGroupPeriod
            /// </summary>
            public const int ThroughGroupPeriod = 15;

        }

        #endregion
    }
}
