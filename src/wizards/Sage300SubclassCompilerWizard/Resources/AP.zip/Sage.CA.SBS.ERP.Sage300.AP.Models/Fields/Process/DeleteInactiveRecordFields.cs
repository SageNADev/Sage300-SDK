// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
	/// <summary>
	/// Contains list of DeleteInactiveRecord Constants
	/// </summary>
	public partial class DeleteInactiveRecord
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "AP0052";

		/// <summary>
		/// Dynamic Attributes contain a reverse mapping of field and property
		/// </summary>
		[IgnoreExportImport]
		public static Dictionary<string, string> DynamicAttributes
		{
			get
			{
				return new Dictionary<string, string>
				{
				};
			}
		}

		#region Properties

		/// <summary>
		/// Contains list of DeleteInactiveRecord Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ClearFromVendorNumber
			/// </summary>
			public const string ClearFromVendorNumber = "STRTVENID";

			/// <summary>
			/// Property for ClearThruVendorNumber
			/// </summary>
			public const string ClearThruVendorNumber = "ENDVENID";

			/// <summary>
			/// Property for ClearFromGroupCode
			/// </summary>
			public const string ClearFromGroupCode = "STRTGRPID";

			/// <summary>
			/// Property for ClearThruGroupCode
			/// </summary>
			public const string ClearThruGroupCode = "ENDGRPID";

			/// <summary>
			/// Property for ClearRemitToFromVendorNo
			/// </summary>
			public const string ClearRemitToFromVendorNo = "STRTRMTVEN";

			/// <summary>
			/// Property for ClearRemitToThruVendorNo
			/// </summary>
			public const string ClearRemitToThruVendorNo = "ENDRMTVEN";

			/// <summary>
			/// Property for ClearFromDate
			/// </summary>
			public const string ClearFromDate = "STRTDATE";

			/// <summary>
			/// Property for ClearThruDate
			/// </summary>
			public const string ClearThruDate = "ENDDATE";

			/// <summary>
			/// Property for ClearInactiveVendors
			/// </summary>
			public const string ClearInactiveVendors = "SWPRGVEN";

			/// <summary>
			/// Property for ClearInactiveGroups
			/// </summary>
			public const string ClearInactiveGroups = "SWPRGGRP";

			/// <summary>
			/// Property for ClearInactiveRemitToLocation
			/// </summary>
			public const string ClearInactiveRemitToLocation = "SWPRGRMT";

			/// <summary>
			/// Property for ClearInactiveRecurringPayable
			/// </summary>
			public const string ClearInactiveRecurringPayable = "SWPRGRPH";

			/// <summary>
			/// Property for ClearFromRecurringPayable
			/// </summary>
			public const string ClearFromRecurringPayable = "STRTRECURR";

			/// <summary>
			/// Property for ClearThruRecurringPayable
			/// </summary>
			public const string ClearThruRecurringPayable = "ENDRECURR";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of DeleteInactiveRecord Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ClearFromVendorNumber
			/// </summary>
			public const int ClearFromVendorNumber = 1;

			/// <summary>
			/// Property Indexer for ClearThruVendorNumber
			/// </summary>
			public const int ClearThruVendorNumber = 2;

			/// <summary>
			/// Property Indexer for ClearFromGroupCode
			/// </summary>
			public const int ClearFromGroupCode = 3;

			/// <summary>
			/// Property Indexer for ClearThruGroupCode
			/// </summary>
			public const int ClearThruGroupCode = 4;

			/// <summary>
			/// Property Indexer for ClearRemitToFromVendorNo
			/// </summary>
			public const int ClearRemitToFromVendorNo = 5;

			/// <summary>
			/// Property Indexer for ClearRemitToThruVendorNo
			/// </summary>
			public const int ClearRemitToThruVendorNo = 6;

			/// <summary>
			/// Property Indexer for ClearFromDate
			/// </summary>
			public const int ClearFromDate = 7;

			/// <summary>
			/// Property Indexer for ClearThruDate
			/// </summary>
			public const int ClearThruDate = 8;

			/// <summary>
			/// Property Indexer for ClearInactiveVendors
			/// </summary>
			public const int ClearInactiveVendors = 9;

			/// <summary>
			/// Property Indexer for ClearInactiveGroups
			/// </summary>
			public const int ClearInactiveGroups = 10;

			/// <summary>
			/// Property Indexer for ClearInactiveRemitToLocation
			/// </summary>
			public const int ClearInactiveRemitToLocation = 11;

			/// <summary>
			/// Property Indexer for ClearInactiveRecurringPayable
			/// </summary>
			public const int ClearInactiveRecurringPayable = 12;

			/// <summary>
			/// Property Indexer for ClearFromRecurringPayable
			/// </summary>
			public const int ClearFromRecurringPayable = 13;

			/// <summary>
			/// Property Indexer for ClearThruRecurringPayable
			/// </summary>
			public const int ClearThruRecurringPayable = 14;

		}

		#endregion

	}
}
