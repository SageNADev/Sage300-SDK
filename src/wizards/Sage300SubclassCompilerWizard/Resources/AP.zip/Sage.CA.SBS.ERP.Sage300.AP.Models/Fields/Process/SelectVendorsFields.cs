// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process

// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of SelectVendors Constants 
    /// </summary>
	public partial class SelectVendors 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "AP0421";

        /// <summary>
        /// Contains list of SelectVendors Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for SequenceNumber 
        /// </summary>
	    public const string SequenceNumber  = "SELSEQ";
	            /// <summary>
        /// Property for Range1From 
        /// </summary>
	    public const string Range1From  = "IDFROM1";
	            /// <summary>
        /// Property for Range1To 
        /// </summary>
	    public const string Range1To  = "IDTO1";
	            /// <summary>
        /// Property for Range1IndexValue 
        /// </summary>
	    public const string Range1IndexValue  = "INDEX1";
	            /// <summary>
        /// Property for Range2From 
        /// </summary>
	    public const string Range2From  = "IDFROM2";
	            /// <summary>
        /// Property for Range2To 
        /// </summary>
	    public const string Range2To  = "IDTO2";
	            /// <summary>
        /// Property for Range2IndexValue 
        /// </summary>
	    public const string Range2IndexValue  = "INDEX2";
	            /// <summary>
        /// Property for Range3From 
        /// </summary>
	    public const string Range3From  = "IDFROM3";
	            /// <summary>
        /// Property for Range3To 
        /// </summary>
	    public const string Range3To  = "IDTO3";
	            /// <summary>
        /// Property for Range3IndexValue 
        /// </summary>
	    public const string Range3IndexValue  = "INDEX3";
	            /// <summary>
        /// Property for Range4From 
        /// </summary>
	    public const string Range4From  = "IDFROM4";
	            /// <summary>
        /// Property for Range4To 
        /// </summary>
	    public const string Range4To  = "IDTO4";
	            /// <summary>
        /// Property for Range4IndexValue 
        /// </summary>
	    public const string Range4IndexValue  = "INDEX4";
	            /// <summary>
        /// Property for FieldName1 
        /// </summary>
	    public const string FieldName1  = "FIELDNAME1";
	            /// <summary>
        /// Property for FieldName2 
        /// </summary>
	    public const string FieldName2  = "FIELDNAME2";
	            /// <summary>
        /// Property for FieldName3 
        /// </summary>
	    public const string FieldName3  = "FIELDNAME3";
	            /// <summary>
        /// Property for FieldName4 
        /// </summary>
	    public const string FieldName4  = "FIELDNAME4";
	            /// <summary>
        /// Property for IncludeZeroBalances 
        /// </summary>
	    public const string IncludeZeroBalances  = "ZEROBALSW";
	            /// <summary>
        /// Property for SortFieldIndex1 
        /// </summary>
	    public const string SortFieldIndex1  = "SORTINDEX1";
	            /// <summary>
        /// Property for SortFieldIndex2 
        /// </summary>
	    public const string SortFieldIndex2  = "SORTINDEX2";
	            /// <summary>
        /// Property for SortFieldIndex3 
        /// </summary>
	    public const string SortFieldIndex3  = "SORTINDEX3";
	            /// <summary>
        /// Property for SortFieldIndex4 
        /// </summary>
	    public const string SortFieldIndex4  = "SORTINDEX4";
	            /// <summary>
        /// Property for SortFieldName1 
        /// </summary>
	    public const string SortFieldName1  = "SORTNAME1";
	            /// <summary>
        /// Property for SortFieldName2 
        /// </summary>
	    public const string SortFieldName2  = "SORTNAME2";
	            /// <summary>
        /// Property for SortFieldName3 
        /// </summary>
	    public const string SortFieldName3  = "SORTNAME3";
	            /// <summary>
        /// Property for SortFieldName4 
        /// </summary>
	    public const string SortFieldName4  = "SORTNAME4";
	            /// <summary>
        /// Property for DisplayMeter 
        /// </summary>
	    public const string DisplayMeter  = "SWOPTMETER";
	            /// <summary>
        /// Property for SortRecords 
        /// </summary>
	    public const string SortRecords  = "SWSORTREC";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of SelectVendors Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for SequenceNumber 
        /// </summary>
	    public const int SequenceNumber  = 1;
	             /// <summary>
        /// Property Indexer for Range1From 
        /// </summary>
	    public const int Range1From  = 2;
	             /// <summary>
        /// Property Indexer for Range1To 
        /// </summary>
	    public const int Range1To  = 3;
	             /// <summary>
        /// Property Indexer for Range1IndexValue 
        /// </summary>
	    public const int Range1IndexValue  = 4;
	             /// <summary>
        /// Property Indexer for Range2From 
        /// </summary>
	    public const int Range2From  = 5;
	             /// <summary>
        /// Property Indexer for Range2To 
        /// </summary>
	    public const int Range2To  = 6;
	             /// <summary>
        /// Property Indexer for Range2IndexValue 
        /// </summary>
	    public const int Range2IndexValue  = 7;
	             /// <summary>
        /// Property Indexer for Range3From 
        /// </summary>
	    public const int Range3From  = 8;
	             /// <summary>
        /// Property Indexer for Range3To 
        /// </summary>
	    public const int Range3To  = 9;
	             /// <summary>
        /// Property Indexer for Range3IndexValue 
        /// </summary>
	    public const int Range3IndexValue  = 10;
	             /// <summary>
        /// Property Indexer for Range4From 
        /// </summary>
	    public const int Range4From  = 11;
	             /// <summary>
        /// Property Indexer for Range4To 
        /// </summary>
	    public const int Range4To  = 12;
	             /// <summary>
        /// Property Indexer for Range4IndexValue 
        /// </summary>
	    public const int Range4IndexValue  = 13;
	             /// <summary>
        /// Property Indexer for FieldName1 
        /// </summary>
	    public const int FieldName1  = 14;
	             /// <summary>
        /// Property Indexer for FieldName2 
        /// </summary>
	    public const int FieldName2  = 15;
	             /// <summary>
        /// Property Indexer for FieldName3 
        /// </summary>
	    public const int FieldName3  = 16;
	             /// <summary>
        /// Property Indexer for FieldName4 
        /// </summary>
	    public const int FieldName4  = 17;
	             /// <summary>
        /// Property Indexer for IncludeZeroBalances 
        /// </summary>
	    public const int IncludeZeroBalances  = 18;
	             /// <summary>
        /// Property Indexer for SortFieldIndex1 
        /// </summary>
	    public const int SortFieldIndex1  = 19;
	             /// <summary>
        /// Property Indexer for SortFieldIndex2 
        /// </summary>
	    public const int SortFieldIndex2  = 20;
	             /// <summary>
        /// Property Indexer for SortFieldIndex3 
        /// </summary>
	    public const int SortFieldIndex3  = 21;
	             /// <summary>
        /// Property Indexer for SortFieldIndex4 
        /// </summary>
	    public const int SortFieldIndex4  = 22;
	             /// <summary>
        /// Property Indexer for SortFieldName1 
        /// </summary>
	    public const int SortFieldName1  = 23;
	             /// <summary>
        /// Property Indexer for SortFieldName2 
        /// </summary>
	    public const int SortFieldName2  = 24;
	             /// <summary>
        /// Property Indexer for SortFieldName3 
        /// </summary>
	    public const int SortFieldName3  = 25;
	             /// <summary>
        /// Property Indexer for SortFieldName4 
        /// </summary>
	    public const int SortFieldName4  = 26;
	             /// <summary>
        /// Property Indexer for DisplayMeter 
        /// </summary>
	    public const int DisplayMeter  = 27;
	             /// <summary>
        /// Property Indexer for SortRecords 
        /// </summary>
	    public const int SortRecords  = 28;
	     
        #endregion
	    }

	
	}
}
	