// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
	/// <summary>
	/// Contains list of ClearVendorComment Constants
	/// </summary>
	public partial class ClearVendorComment
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "AP0050";

		#region Properties

		/// <summary>
		/// Contains list of ClearVendorComment Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ClearFromVendorNumber
			/// </summary>
			public const string ClearFromVendorNumber = "STRTVENID";

			/// <summary>
			/// Property for ClearThruVendorNumber
			/// </summary>
			public const string ClearThruVendorNumber = "ENDVENID";

			/// <summary>
			/// Property for ClearThruDate
			/// </summary>
			public const string ClearThruDate = "DATETHRU";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ClearVendorComment Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ClearFromVendorNumber
			/// </summary>
			public const int ClearFromVendorNumber = 1;

			/// <summary>
			/// Property Indexer for ClearThruVendorNumber
			/// </summary>
			public const int ClearThruVendorNumber = 2;

			/// <summary>
			/// Property Indexer for ClearThruDate
			/// </summary>
			public const int ClearThruDate = 3;

		}

		#endregion

	}
}
