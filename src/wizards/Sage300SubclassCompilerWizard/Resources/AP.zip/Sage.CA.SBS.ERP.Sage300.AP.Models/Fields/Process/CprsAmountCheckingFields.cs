// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Contains list of 1099CPRSAmountChecking Constants 
    /// </summary>
	public partial class CprsAmountChecking
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0111";

        /// <summary>
        /// Contains list of 1099CPRSAmountChecking Fields Constants
        /// </summary>
	    public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for FromVendorNumber 
            /// </summary>
            public const string FromVendorNumber = "VENDORFROM";
            /// <summary>
            /// Property for ToVendorNumber 
            /// </summary>
            public const string ToVendorNumber = "VENDORTO";
            /// <summary>
            /// Property for TaxReportingType 
            /// </summary>
            public const string TaxReportingType = "TAXRPTSW";
            /// <summary>
            /// Property for FromCode 
            /// </summary>
            public const string FromCode = "CIDFROM";
            /// <summary>
            /// Property for ToCode 
            /// </summary>
            public const string ToCode = "CIDTO";
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string Year = "CNTYEAR";
            /// <summary>
            /// Property for Atleastonevendorhasreportab 
            /// </summary>
            public const string Atleastonevendorhasreportab = "REPORTABLE";
            /// <summary>
            /// Property for CommandCode 
            /// </summary>
            public const string CommandCode = "CMNDCODE";
            /// <summary>
            /// Property for FileName 
            /// </summary>
            public const string FileName = "FILENAME";
            /// <summary>
            /// Property for Form Name
            /// </summary>
            public const string FormType = "FORMTYPE";
            /// <summary>
            /// Property for CompanyName
            /// </summary>
            public const string CompanyName = "CONAME";
            /// <summary>
            /// Property for ForeignEntity
            /// </summary>
            public const string ForeignEntity = "FOREIGNENT";
            /// <summary>
            /// Property for LegalName
            /// </summary>
            public const string LegalName = "LEGALNAME";
            /// <summary>
            /// Property for AddressLine1
            /// </summary>
            public const string AddressLine1 = "ADDR01";
            /// <summary>
            /// Property for AddressLine2
            /// </summary>
            public const string AddressLine2 = "ADDR02";
            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "CITY";
            /// <summary>
            /// Property for State
            /// </summary>
            public const string State = "STATE";
            /// <summary>
            /// Property for ZipCode
            /// </summary>
            public const string ZipCode = "POSTAL";
            /// <summary>
            /// Property for Country
            /// </summary>
            public const string Country = "COUNTRY";
            /// <summary>
            /// Property for TaxNumber
            /// </summary>
            public const string TaxNumber = "TAXNBR";
            /// <summary>
            /// Property for TaxNumberType
            /// </summary>
            public const string TaxNumberType = "TAXNOTYPE";
            /// <summary>
            /// Property for Telephone
            /// </summary>
            public const string Telephone = "PHONE";
            /// <summary>
            /// Property for Tax Fax
            /// </summary>
            public const string Fax = "FAX";
            /// <summary>
            /// Property for Contact
            /// </summary>
            public const string Contact = "CONTACT";
            /// <summary>
            /// Property for E-mail
            /// </summary>
            public const string Email = "EMAIL";
            /// <summary>
            /// Property for Title
            /// </summary>
            public const string Title = "TITLE";
            /// <summary>
            /// Property for TransferAgent
            /// </summary>
            public const string TransferAgent = "TAGENT";
            /// <summary>
            /// Property for FullAUFFileName
            /// </summary>
            public const string FullAUFFileName = "AUFFILENAM";

            #endregion
        }


        /// <summary>
        /// Contains list of 1099CPRSAmountChecking Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for FromVendorNumber
            /// </summary>
            public const int FromVendorNumber = 1;
            /// <summary>
            /// Property Indexer for ToVendorNumber
            /// </summary>
            public const int ToVendorNumber = 2;
            /// <summary>
            /// Property Indexer for TaxReportingType
            /// </summary>
            public const int TaxReportingType = 3;
            /// <summary>
            /// Property Indexer for FromCode
            /// </summary>
            public const int FromCode = 4;
            /// <summary>
            /// Property Indexer for ToCode
            /// </summary>
            public const int ToCode = 5;
            /// <summary>
            /// Property Indexer for Year
            /// </summary>
            public const int Year = 6;
            /// <summary>
            /// Property Indexer for Atleastonevendorhasreportab
            /// </summary>
            public const int Atleastonevendorhasreportab = 7;
            /// <summary>
            /// Property Indexer for CommandCode
            /// </summary>
            public const int CommandCode = 8;
            /// <summary>
            /// Property Indexer for FileName
            /// </summary>
            public const int FileName = 9;
            /// <summary>
            /// Property Indexer for FormName
            /// </summary>
            public const int FormType = 10;
            /// <summary>
            /// Property Indexer for CompanyName
            /// </summary>
            public const int CompanyName = 11;
            /// <summary>
            /// Property Indexer for ForeignEntity
            /// </summary>
            public const int ForeignEntity = 12;
            /// <summary>
            /// Property Indexer for LegalName
            /// </summary>
            public const int LegalName = 13;
            /// <summary>
            /// Property Indexer for AddressLine1
            /// </summary>
            public const int AddressLine1 = 14;
            /// <summary>
            /// Property Indexer for AddressLine2
            /// </summary>
            public const int AddressLine2 = 15;
            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 16;
            /// <summary>
            /// Property Indexer for State
            /// </summary>
            public const int State = 17;
            /// <summary>
            /// Property Indexer for ZipCode
            /// </summary>
            public const int ZipCode = 18;
            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 19;
            /// <summary>
            /// Property Indexer for TaxNumber
            /// </summary>
            public const int TaxNumber = 20;
            /// <summary>
            /// Property Indexer for TaxNumberType
            /// </summary>
            public const int TaxNumberType = 21;
            /// <summary>
            /// Property Indexer for Telephone
            /// </summary>
            public const int Telephone = 22;
            /// <summary>
            /// Property Indexer for Tax Fax
            /// </summary>
            public const int Fax = 23;
            /// <summary>
            /// Property Indexer for Contact
            /// </summary>
            public const int Contact = 24;
            /// <summary>
            /// Property Indexer for E-mail
            /// </summary>
            public const int Email = 25;
            /// <summary>
            /// Property Indexer for Title
            /// </summary>
            public const int Title = 26;
            /// <summary>
            /// Property Indexer for TransferAgent
            /// </summary>
            public const int TransferAgent = 27;
            /// <summary>
            /// Property Indexer for FullAUFFileName
            /// </summary>
            public const int FullAUFFileName = 28;

            #endregion
        }


    }
}
