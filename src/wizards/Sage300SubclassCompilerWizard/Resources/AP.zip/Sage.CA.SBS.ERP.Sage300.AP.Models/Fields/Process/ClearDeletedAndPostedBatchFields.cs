// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
	/// <summary>
	/// Contains list of ClearDeletedAndPostedBatche Constants
	/// </summary>
	public partial class ClearDeletedAndPostedBatch
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "AP0059";

		#region Properties

		/// <summary>
		/// Contains list of ClearDeletedAndPostedBatche Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for FromBatchNumber
			/// </summary>
			public const string FromBatchNumber = "FROMBATCH";

			/// <summary>
			/// Property for ToBatchNumber
			/// </summary>
			public const string ToBatchNumber = "TOBATCH";

			/// <summary>
			/// Property for BatchType
			/// </summary>
			public const string BatchType = "BTCHTYPE";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ClearDeletedAndPostedBatche Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for FromBatchNumber
			/// </summary>
			public const int FromBatchNumber = 1;

			/// <summary>
			/// Property Indexer for ToBatchNumber
			/// </summary>
			public const int ToBatchNumber = 2;

			/// <summary>
			/// Property Indexer for BatchType
			/// </summary>
			public const int BatchType = 3;

		}

		#endregion

	}
}
