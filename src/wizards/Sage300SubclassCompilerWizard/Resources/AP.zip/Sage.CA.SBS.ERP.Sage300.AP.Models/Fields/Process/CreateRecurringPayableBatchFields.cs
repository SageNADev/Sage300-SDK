// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CreateRecurringPayableBatch Constants 
    /// </summary>
    public partial class CreateRecurPayBatch
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0066";

        #endregion

        /// <summary>
        /// Contains list of CreateRecurringPayableBatch Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for RunDate 
            /// </summary>         
            public const string RunDate = "DATERUN";

            /// <summary>
            /// Property for Mode 
            /// </summary>
            public const string Mode = "MODE";

            /// <summary>
            /// Property for SelectRecordsBy 
            /// </summary>
            public const string SelectRecordsBy = "SELECTBY";

            /// <summary>
            /// Property for StartingRecurringPayableCode 
            /// </summary>
            public const string StartingRecurringPayableCode = "RECURRFROM";

            /// <summary>
            /// Property for EndingRecurringPayableCode 
            /// </summary>
            public const string EndingRecurringPayableCode = "RECURRTO";

            /// <summary>
            /// Property for StartingVendorNumber 
            /// </summary>
            public const string StartingVendorNumber = "VENIDFROM";

            /// <summary>
            /// Property for EndingVendorNumber 
            /// </summary>
            public const string EndingVendorNumber = "VENIDTO";

            /// <summary>
            /// Property for StartingVendorGroupCode 
            /// </summary>
            public const string StartingVendorGroupCode = "VENGRPFROM";

            /// <summary>
            /// Property for EndingVendorGroupCode 
            /// </summary>
            public const string EndingVendorGroupCode = "VENGRPTO";

            /// <summary>
            /// Property for ScheduleKey 
            /// </summary>
            public const string ScheduleKey = "SCHEDKEY";

            /// <summary>
            /// Property for ScheduleLink 
            /// </summary>
            public const string ScheduleLink = "SCHEDLINK";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "STATUS";

            /// <summary>
            /// Property for DateGenerationMethod 
            /// </summary>
            public const string DateGenerationMethod = "SWDATEMETH";

            /// <summary>
            /// Property for BatchGenerationMethod 
            /// </summary>
            public const string BatchGenerationMethod = "SWBTCHMETH";

            /// <summary>
            /// Property for ForcedInvoiceDate 
            /// </summary>
            public const string ForcedInvoiceDate = "DATEFORCED";

            /// <summary>
            /// Property for AppendtoBatchNumber 
            /// </summary>
            public const string AppendtoBatchNumber = "BTCHAPPEND";

            #endregion
        }

        /// <summary>
        /// Contains list of CreateRecurringPayableBatch Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for RunDate 
            /// </summary>
            public const int RunDate = 1;

            /// <summary>
            /// Property Indexer for Mode 
            /// </summary>
            public const int Mode = 2;

            /// <summary>
            /// Property Indexer for SelectRecordsBy 
            /// </summary>
            public const int SelectRecordsBy = 3;

            /// <summary>
            /// Property Indexer for StartingRecurringPayableCode 
            /// </summary>
            public const int StartingRecurringPayableCode = 4;

            /// <summary>
            /// Property Indexer for EndingRecurringPayableCode 
            /// </summary>
            public const int EndingRecurringPayableCode = 5;

            /// <summary>
            /// Property Indexer for StartingVendorNumber 
            /// </summary>
            public const int StartingVendorNumber = 6;

            /// <summary>
            /// Property Indexer for EndingVendorNumber 
            /// </summary>
            public const int EndingVendorNumber = 7;

            /// <summary>
            /// Property Indexer for StartingVendorGroupCode 
            /// </summary>
            public const int StartingVendorGroupCode = 8;

            /// <summary>
            /// Property Indexer for EndingVendorGroupCode 
            /// </summary>
            public const int EndingVendorGroupCode = 9;

            /// <summary>
            /// Property Indexer for ScheduleKey 
            /// </summary>
            public const int ScheduleKey = 10;

            /// <summary>
            /// Property Indexer for ScheduleLink 
            /// </summary>
            public const int ScheduleLink = 11;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 12;

            /// <summary>
            /// Property Indexer for DateGenerationMethod 
            /// </summary>
            public const int DateGenerationMethod = 13;

            /// <summary>
            /// Property Indexer for BatchGenerationMethod 
            /// </summary>
            public const int BatchGenerationMethod = 14;

            /// <summary>
            /// Property Indexer for ForcedInvoiceDate 
            /// </summary>
            public const int ForcedInvoiceDate = 15;

            /// <summary>
            /// Property Indexer for AppendtoBatchNumber 
            /// </summary>
            public const int AppendToBatchNumber = 16;

            #endregion
        }
    }
}