/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Process
{
    /// <summary>
    /// Contains list of Aged Payables Constants 
    /// </summary>
    public partial class AgeDocument
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0043";

        #endregion

        /// <summary>
        /// Contains list of Aged Payables Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for CommandCode 
            /// </summary>
            public const string CommandCode = "CMNDCODE";

            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";

            /// <summary>
            /// Property for PostingDate 
            /// </summary>
            public const string PostingDate = "BUSDATE";

            /// <summary>
            /// Property for DocumentNumber 
            /// </summary>
            public const string DocumentNumber = "INVOICEID";

            /// <summary>
            /// Property for CheckNumber 
            /// </summary>
            public const string CheckNumber = "IDRMIT";

            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TRXTYPETXT";

            /// <summary>
            /// Property for TransactionDescription 
            /// </summary>
            public const string TransactionDescription = "TRXTYPEID";

            /// <summary>
            /// Property for AmountDue 
            /// </summary>
            public const string AmountDue = "OBLAMTDUE";

            /// <summary>
            /// Property for StartingInvoiceDate 
            /// </summary>
            public const string StartingInvoiceDate = "INVCBEGNDT";

            /// <summary>
            /// Property for DueDate 
            /// </summary>
            public const string DueDate = "DUEDATE";

            /// <summary>
            /// Property for AgeasofDate 
            /// </summary>
            public const string AgeasofDate = "RUNDATE";

            /// <summary>
            /// Property for CutoffDate 
            /// </summary>
            public const string CutoffDate = "CUTOFFDATE";

            /// <summary>
            /// Property for DueDateOrInvoiceDate 
            /// </summary>
            public const string DueDateOrInvoiceDate = "AGEINVDTSW";

            /// <summary>
            /// Property for IncludePaymentsOnHold 
            /// </summary>
            public const string IncludePaymentsOnHold = "INCLOBLHLD";

            /// <summary>
            /// Property for IncludeZeroBalances 
            /// </summary>
            public const string IncludeZeroBalances = "ZEROBALSW";

            /// <summary>
            /// Property for ATBOrOverdueRecurringReport 
            /// </summary>
            public const string ATBOrOverdueRecReport  = "PASTDUESW";

            /// <summary>
            /// Property for Current 
            /// </summary>
            public const string Current = "AGEPERIOD1";

            /// <summary>
            /// Property for FirstPeriod 
            /// </summary>
            public const string FirstPeriod = "AGEPERIOD2";

            /// <summary>
            /// Property for SecondPeriod 
            /// </summary>
            public const string SecondPeriod = "AGEPERIOD3";

            /// <summary>
            /// Property for ThirdPeriod 
            /// </summary>
            public const string ThirdPeriod = "AGEPERIOD4";

            /// <summary>
            /// Property for FourthPeriod 
            /// </summary>
            public const string FourthPeriod = "AGEPERIOD5";

            /// <summary>
            /// Property for FirstForwardPeriod 
            /// </summary>
            public const string FirstForwardPeriod = "AGEPERIOD6";

            /// <summary>
            /// Property for SecondForwardPeriod 
            /// </summary>
            public const string SecondForwardPeriod = "AGEPERIOD7";

            /// <summary>
            /// Property for ThirdForwardPeriod 
            /// </summary>
            public const string ThirdForwardPeriod = "AGEPERIOD8";

            /// <summary>
            /// Property for FourthForwardPeriod 
            /// </summary>
            public const string FourthForwardPeriod = "AGEPERIOD9";

            /// <summary>
            /// Property for IncludeOverCreditLimit 
            /// </summary>
            public const string IncludeOverCreditLimit = "SWCUSTCRLM";

            /// <summary>
            /// Property for Range1From 
            /// </summary>
            public const string Range1From = "IDFROM1";

            /// <summary>
            /// Property for Range1To 
            /// </summary>
            public const string Range1To = "IDTO1";

            /// <summary>
            /// Property for Range1IndexValue 
            /// </summary>
            public const string Range1IndexValue = "INDEX1";

            /// <summary>
            /// Property for Range2From 
            /// </summary>
            public const string Range2From = "IDFROM2";

            /// <summary>
            /// Property for Range2To 
            /// </summary>
            public const string Range2To = "IDTO2";

            /// <summary>
            /// Property for Range2IndexValue 
            /// </summary>
            public const string Range2IndexValue = "INDEX2";

            /// <summary>
            /// Property for Range3From 
            /// </summary>
            public const string Range3From = "IDFROM3";

            /// <summary>
            /// Property for Range3To 
            /// </summary>
            public const string Range3To = "IDTO3";

            /// <summary>
            /// Property for Range3IndexValue 
            /// </summary>
            public const string Range3IndexValue = "INDEX3";

            /// <summary>
            /// Property for Range4From 
            /// </summary>
            public const string Range4From = "IDFROM4";

            /// <summary>
            /// Property for Range4To 
            /// </summary>
            public const string Range4To = "IDTO4";

            /// <summary>
            /// Property for Range4IndexValue 
            /// </summary>
            public const string Range4IndexValue = "INDEX4";

            /// <summary>
            /// Property for CurrentAmountDueSource 
            /// </summary>
            public const string CurrentAmountDueSource = "AMTDUE1TC";

            /// <summary>
            /// Property for CurrentAmountDueFunctional 
            /// </summary>
            public const string CurrentAmountDueFunctional = "AMTDUE1HC";

            /// <summary>
            /// Property for CurrentDate 
            /// </summary>
            public const string CurrentDate = "DATEDUE1";

            /// <summary>
            /// Property for Period1AmountDueSource 
            /// </summary>
            public const string Period1AmountDueSource = "AMTDUE2TC";

            /// <summary>
            /// Property for Period1AmountDueFunctional 
            /// </summary>
            public const string Period1AmountDueFunctional = "AMTDUE2HC";

            /// <summary>
            /// Property for Period1Date 
            /// </summary>
            public const string Period1Date = "DATEDUE2";

            /// <summary>
            /// Property for Period2AmountDueSource 
            /// </summary>
            public const string Period2AmountDueSource = "AMTDUE3TC";

            /// <summary>
            /// Property for Period2AmountDueFunctional 
            /// </summary>
            public const string Period2AmountDueFunctional = "AMTDUE3HC";

            /// <summary>
            /// Property for Period2Date 
            /// </summary>
            public const string Period2Date = "DATEDUE3";

            /// <summary>
            /// Property for Period3AmountDueSource 
            /// </summary>
            public const string Period3AmountDueSource = "AMTDUE4TC";

            /// <summary>
            /// Property for Period3AmountDueFunctional 
            /// </summary>
            public const string Period3AmountDueFunctional = "AMTDUE4HC";

            /// <summary>
            /// Property for Period3Date 
            /// </summary>
            public const string Period3Date = "DATEDUE4";

            /// <summary>
            /// Property for Period4AmountDueSource 
            /// </summary>
            public const string Period4AmountDueSource = "AMTDUE5TC";

            /// <summary>
            /// Property for Period4AmountDueFunctional 
            /// </summary>
            public const string Period4AmountDueFunctional = "AMTDUE5HC";

            /// <summary>
            /// Property for Period4Date 
            /// </summary>
            public const string Period4Date = "DATEDUE5";

            /// <summary>
            /// Property for Period5AmountDueSource 
            /// </summary>
            public const string Period5AmountDueSource = "AMTDUE6TC";

            /// <summary>
            /// Property for Period5AmountDueFunctional 
            /// </summary>
            public const string Period5AmountDueFunctional = "AMTDUE6HC";

            /// <summary>
            /// Property for Period5Date 
            /// </summary>
            public const string Period5Date = "DATEDUE6";

            /// <summary>
            /// Property for Period6AmountDueSource 
            /// </summary>
            public const string Period6AmountDueSource = "AMTDUE7TC";

            /// <summary>
            /// Property for Period6AmountDueFunctional 
            /// </summary>
            public const string Period6AmountDueFunctional = "AMTDUE7HC";

            /// <summary>
            /// Property for Period6Date 
            /// </summary>
            public const string Period6Date = "DATEDUE7";

            /// <summary>
            /// Property for Period7AmountDueSource 
            /// </summary>
            public const string Period7AmountDueSource = "AMTDUE8TC";

            /// <summary>
            /// Property for Period7AmountDueFunctional 
            /// </summary>
            public const string Period7AmountDueFunctional = "AMTDUE8HC";

            /// <summary>
            /// Property for Period7Date 
            /// </summary>
            public const string Period7Date = "DATEDUE8";

            /// <summary>
            /// Property for Period8AmountDueSource 
            /// </summary>
            public const string Period8AmountDueSource = "AMTDUE9TC";

            /// <summary>
            /// Property for Period8AmountDueFunctional 
            /// </summary>
            public const string Period8AmountDueFunctional = "AMTDUE9HC";

            /// <summary>
            /// Property for Period8Date 
            /// </summary>
            public const string Period8Date = "DATEDUE9";

            /// <summary>
            /// Property for PeriodOpenItemScheduleDue 
            /// </summary>
            public const string PeriodOpenItemScheduleDue = "CNTPERDDUE";

            /// <summary>
            /// Property for TotalBackwardAgingSource 
            /// </summary>
            public const string TotalBackwardAgingSource = "TOTBKWDTC";

            /// <summary>
            /// Property for TotalBackwardAgingFunctional 
            /// </summary>
            public const string TotalBackwardAgingFunctional = "TOTBKWDHC";

            /// <summary>
            /// Property for TotalForwardAgingSource 
            /// </summary>
            public const string TotalForwardAgingSource = "TOTFWDTC";

            /// <summary>
            /// Property for TotalForwardAgingFunctional 
            /// </summary>
            public const string TotalForwardAgingFunctional = "TOTFWDHC";

            /// <summary>
            /// Property for DisplayMeter 
            /// </summary>
            public const string DisplayMeter = "SWOPTMETER";

            /// <summary>
            /// Property for IncludeAppliedDetails 
            /// </summary>
            public const string IncludeAppliedDetails = "SWMATCHING";

            /// <summary>
            /// Property for TakeallAvailableDiscounts 
            /// </summary>
            public const string TakeallAvailableDiscounts = "TAKEAVDISC";
            /// <summary>
            /// Property for Cutoffby 
            /// </summary>
            public const string Cutoffby = "SWCUTOFFBY";

            /// <summary>
            /// Property for CutoffYear 
            /// </summary>
            public const string CutoffYear = "CUTOFFYEAR";

            /// <summary>
            /// Property for CutoffPeriod 
            /// </summary>
            public const string CutoffPeriod = "CUTOFFPERD";

            /// <summary>
            /// Property for FieldName1 
            /// </summary>
            public const string FieldName1 = "FIELDNAME1";

            /// <summary>
            /// Property for FieldName2 
            /// </summary>
            public const string FieldName2 = "FIELDNAME2";

            /// <summary>
            /// Property for FieldName3 
            /// </summary>
            public const string FieldName3 = "FIELDNAME3";

            /// <summary>
            /// Property for FieldName4 
            /// </summary>
            public const string FieldName4 = "FIELDNAME4";

            /// <summary>
            /// Property for IncludePrepayment 
            /// </summary>
            public const string IncludePrepayment = "SWPREPAYMT";

            /// <summary>
            /// Property for AgingSequenceNumber 
            /// </summary>
            public const string AgingSequenceNumber = "AGESEQ";

            /// <summary>
            /// Property for SortFieldIndex1 
            /// </summary>
            public const string SortFieldIndex1 = "SORTINDEX1";

            /// <summary>
            /// Property for SortFieldIndex2 
            /// </summary>
            public const string SortFieldIndex2 = "SORTINDEX2";


            /// <summary>
            /// Property for SortFieldIndex3 
            /// </summary>
            public const string SortFieldIndex3 = "SORTINDEX3";

            /// <summary>
            /// Property for SortFieldIndex4 
            /// </summary>
            public const string SortFieldIndex4 = "SORTINDEX4";

            /// <summary>
            /// Property for SortFieldName1 
            /// </summary>
            public const string SortFieldName1 = "SORTNAME1";

            /// <summary>
            /// Property for SortFieldName2 
            /// </summary>
            public const string SortFieldName2 = "SORTNAME2";

            /// <summary>
            /// Property for SortFieldName3 
            /// </summary>
            public const string SortFieldName3 = "SORTNAME3";

            /// <summary>
            /// Property for SortFieldName4 
            /// </summary>
            public const string SortFieldName4 = "SORTNAME4";

            /// <summary>
            /// Property for IncludeInvoice 
            /// </summary>
            public const string IncludeInvoice = "SWINVOICE";

            /// <summary>
            /// Property for IncludeDebitNote 
            /// </summary>
            public const string IncludeDebitNote = "SWDEBIT";

            /// <summary>
            /// Property for IncludeCreditNote 
            /// </summary>
            public const string IncludeCreditNote = "SWCREDIT";

            /// <summary>
            /// Property for IncludeInterest 
            /// </summary>
            public const string IncludeInterest = "SWINTEREST";

            /// <summary>
            /// Property for IncludePayment 
            /// </summary>
            public const string IncludePayment = "SWPAYMENT";

            /// <summary>
            /// Property for IncludeFullyPaidTransactions 
            /// </summary>
            public const string IncludeFullyPaidTransactions = "SWINCLPAID";

            /// <summary>
            /// Property for IncludeAdjustment 
            /// </summary>
            public const string IncludeAdjustment = "SWADJUST";

            /// <summary>
            /// Property for FromDate 
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for FromYear 
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for FromPeriod 
            /// </summary>
            public const string FromPeriod = "FROMPERD";

            /// <summary>
            /// Property for ShowAgedRetainage 
            /// </summary>
            public const string ShowAgedRetainage = "SWAGERTG";

            #endregion
        }
        
        /// <summary>
        /// Contains list of Aged Payables Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for CommandCode 
            /// </summary>
            public const int CommandCode = 1;

            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 2;

            /// <summary>
            /// Property Indexer for PostingDate 
            /// </summary>
            public const int PostingDate = 3;

            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 4;

            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int CheckNumber = 5;

            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 6;

            /// <summary>
            /// Property Indexer for TransactionDescription 
            /// </summary>
            public const int TransactionDescription = 7;

            /// <summary>
            /// Property Indexer for AmountDue 
            /// </summary>
            public const int AmountDue = 8;

            /// <summary>
            /// Property Indexer for StartingInvoiceDate 
            /// </summary>
            public const int StartingInvoiceDate = 9;

            /// <summary>
            /// Property Indexer for DueDate 
            /// </summary>
            public const int DueDate = 10;

            /// <summary>
            /// Property Indexer for AgeasofDate 
            /// </summary>
            public const int AgeasofDate = 11;

            /// <summary>
            /// Property Indexer for CutoffDate 
            /// </summary>
            public const int CutoffDate = 12;

            /// <summary>
            /// Property Indexer for DueDateOrInvoiceDate 
            /// </summary>
            public const int DueDateOrInvoiceDate = 13;

            /// <summary>
            /// Property Indexer for IncludePaymentsOnHold 
            /// </summary>
            public const int IncludePaymentsOnHold = 14;

            /// <summary>
            /// Property Indexer for IncludeZeroBalances 
            /// </summary>
            public const int IncludeZeroBalances = 15;

            /// <summary>
            /// Property Indexer for ATBOrOverdueRecurringReport 
            /// </summary>
            public const int ATBOrOverdueRecReport  = 16;

            /// <summary>
            /// Property Indexer for Current 
            /// </summary>
            public const int Current = 17;

            /// <summary>
            /// Property Indexer for FirstPeriod 
            /// </summary>
            public const int FirstPeriod = 18;

            /// <summary>
            /// Property Indexer for SecondPeriod 
            /// </summary>
            public const int SecondPeriod = 19;

            /// <summary>
            /// Property Indexer for ThirdPeriod 
            /// </summary>
            public const int ThirdPeriod = 20;

            /// <summary>
            /// Property Indexer for FourthPeriod 
            /// </summary>
            public const int FourthPeriod = 21;

            /// <summary>
            /// Property Indexer for FirstForwardPeriod 
            /// </summary>
            public const int FirstForwardPeriod = 22;

            /// <summary>
            /// Property Indexer for SecondForwardPeriod 
            /// </summary>
            public const int SecondForwardPeriod = 23;

            /// <summary>
            /// Property Indexer for ThirdForwardPeriod 
            /// </summary>
            public const int ThirdForwardPeriod = 24;

            /// <summary>
            /// Property Indexer for FourthForwardPeriod 
            /// </summary>
            public const int FourthForwardPeriod = 25;

            /// <summary>
            /// Property Indexer for IncludeOverCreditLimit 
            /// </summary>
            public const int IncludeOverCreditLimit = 26;

            /// <summary>
            /// Property Indexer for Range1From 
            /// </summary>
            public const int Range1From = 27;

            /// <summary>
            /// Property Indexer for Range1To 
            /// </summary>
            public const int Range1To = 28;

            /// <summary>
            /// Property Indexer for Range1IndexValue 
            /// </summary>
            public const int Range1IndexValue = 29;

            /// <summary>
            /// Property Indexer for Range2From 
            /// </summary>
            public const int Range2From = 30;

            /// <summary>
            /// Property Indexer for Range2To 
            /// </summary>
            public const int Range2To = 31;

            /// <summary>
            /// Property Indexer for Range2IndexValue 
            /// </summary>
            public const int Range2IndexValue = 32;

            /// <summary>
            /// Property Indexer for Range3From 
            /// </summary>
            public const int Range3From = 33;

            /// <summary>
            /// Property Indexer for Range3To 
            /// </summary>
            public const int Range3To = 34;

            /// <summary>
            /// Property Indexer for Range3IndexValue 
            /// </summary>
            public const int Range3IndexValue = 35;

            /// <summary>
            /// Property Indexer for Range4From 
            /// </summary>
            public const int Range4From = 36;

            /// <summary>
            /// Property Indexer for Range4To 
            /// </summary>
            public const int Range4To = 37;

            /// <summary>
            /// Property Indexer for Range4IndexValue 
            /// </summary>
            public const int Range4IndexValue = 38;

            /// <summary>
            /// Property Indexer for CurrentAmountDueSource 
            /// </summary>
            public const int CurrentAmountDueSource = 39;

            /// <summary>
            /// Property Indexer for CurrentAmountDueFunctional 
            /// </summary>
            public const int CurrentAmountDueFunctional = 40;

            /// <summary>
            /// Property Indexer for CurrentDate 
            /// </summary>
            public const int CurrentDate = 41;

            /// <summary>
            /// Property Indexer for Period1AmountDueSource 
            /// </summary>
            public const int Period1AmountDueSource = 42;
            
            /// <summary>
            /// Property Indexer for Period1AmountDueFunctional 
            /// </summary>
            public const int Period1AmountDueFunctional = 43;

            /// <summary>
            /// Property Indexer for Period1Date 
            /// </summary>
            public const int Period1Date = 44;

            /// <summary>
            /// Property Indexer for Period2AmountDueSource 
            /// </summary>
            public const int Period2AmountDueSource = 45;

            /// <summary>
            /// Property Indexer for Period2AmountDueFunctional 
            /// </summary>
            public const int Period2AmountDueFunctional = 46;

            /// <summary>
            /// Property Indexer for Period2Date 
            /// </summary>
            public const int Period2Date = 47;

            /// <summary>
            /// Property Indexer for Period3AmountDueSource 
            /// </summary>
            public const int Period3AmountDueSource = 48;

            /// <summary>
            /// Property Indexer for Period3AmountDueFunctional 
            /// </summary>
            public const int Period3AmountDueFunctional = 49;

            /// <summary>
            /// Property Indexer for Period3Date 
            /// </summary>
            public const int Period3Date = 50;

            /// <summary>
            /// Property Indexer for Period4AmountDueSource 
            /// </summary>
            public const int Period4AmountDueSource = 51;

            /// <summary>
            /// Property Indexer for Period4AmountDueFunctional 
            /// </summary>
            public const int Period4AmountDueFunctional = 52;

            /// <summary>
            /// Property Indexer for Period4Date 
            /// </summary>
            public const int Period4Date = 53;

            /// <summary>
            /// Property Indexer for Period5AmountDueSource 
            /// </summary>
            public const int Period5AmountDueSource = 54;

            /// <summary>
            /// Property Indexer for Period5AmountDueFunctional 
            /// </summary>
            public const int Period5AmountDueFunctional = 55;

            /// <summary>
            /// Property Indexer for Period5Date 
            /// </summary>
            public const int Period5Date = 56;

            /// <summary>
            /// Property Indexer for Period6AmountDueSource 
            /// </summary>
            public const int Period6AmountDueSource = 57;

            /// <summary>
            /// Property Indexer for Period6AmountDueFunctional 
            /// </summary>
            public const int Period6AmountDueFunctional = 58;

            /// <summary>
            /// Property Indexer for Period6Date 
            /// </summary>
            public const int Period6Date = 59;

            /// <summary>
            /// Property Indexer for Period7AmountDueSource 
            /// </summary>
            public const int Period7AmountDueSource = 60;

            /// <summary>
            /// Property Indexer for Period7AmountDueFunctional 
            /// </summary>
            public const int Period7AmountDueFunctional = 61;

            /// <summary>
            /// Property Indexer for Period7Date 
            /// </summary>
            public const int Period7Date = 62;

            /// <summary>
            /// Property Indexer for Period8AmountDueSource 
            /// </summary>
            public const int Period8AmountDueSource = 63;

            /// <summary>
            /// Property Indexer for Period8AmountDueFunctional 
            /// </summary>
            public const int Period8AmountDueFunctional = 64;

            /// <summary>
            /// Property Indexer for Period8Date 
            /// </summary>
            public const int Period8Date = 65;

            /// <summary>
            /// Property Indexer for PeriodOpenItemScheduleDue 
            /// </summary>
            public const int PeriodOpenItemScheduleDue = 66;

            /// <summary>
            /// Property Indexer for TotalBackwardAgingSource 
            /// </summary>
            public const int TotalBackwardAgingSource = 67;

            /// <summary>
            /// Property Indexer for TotalBackwardAgingFunctional 
            /// </summary>
            public const int TotalBackwardAgingFunctional = 68;

            /// <summary>
            /// Property Indexer for TotalForwardAgingSource 
            /// </summary>
            public const int TotalForwardAgingSource = 69;

            /// <summary>
            /// Property Indexer for TotalForwardAgingFunctional 
            /// </summary>
            public const int TotalForwardAgingFunctional = 70;

            /// <summary>
            /// Property Indexer for DisplayMeter 
            /// </summary>
            public const int DisplayMeter = 71;

            /// <summary>
            /// Property Indexer for IncludeAppliedDetails 
            /// </summary>
            public const int IncludeAppliedDetails = 72;
            
            /// <summary>
            /// Property Indexer for TakeallAvailableDiscounts 
            /// </summary>
            public const int TakeallAvailableDiscounts = 73;

            /// <summary>
            /// Property Indexer for Cutoffby 
            /// </summary>
            public const int Cutoffby = 74;

            /// <summary>
            /// Property Indexer for CutoffYear 
            /// </summary>
            public const int CutoffYear = 75;

            /// <summary>
            /// Property Indexer for CutoffPeriod 
            /// </summary>
            public const int CutoffPeriod = 76;

            /// <summary>
            /// Property Indexer for FieldName1 
            /// </summary>
            public const int FieldName1 = 77;

            /// <summary>
            /// Property Indexer for FieldName2 
            /// </summary>
            public const int FieldName2 = 78;

            /// <summary>
            /// Property Indexer for FieldName3 
            /// </summary>
            public const int FieldName3 = 79;

            /// <summary>
            /// Property Indexer for FieldName4 
            /// </summary>
            public const int FieldName4 = 80;

            /// <summary>
            /// Property Indexer for IncludePrepayment 
            /// </summary>
            public const int IncludePrepayment = 81;

            /// <summary>
            /// Property Indexer for AgingSequenceNumber 
            /// </summary>
            public const int AgingSequenceNumber = 82;

            /// <summary>
            /// Property Indexer for SortFieldIndex1 
            /// </summary>
            public const int SortFieldIndex1 = 83;

            /// <summary>
            /// Property Indexer for SortFieldIndex2 
            /// </summary>
            public const int SortFieldIndex2 = 84;

            /// <summary>
            /// Property Indexer for SortFieldIndex3 
            /// </summary>
            public const int SortFieldIndex3 = 85;

            /// <summary>
            /// Property Indexer for SortFieldIndex4 
            /// </summary>
            public const int SortFieldIndex4 = 86;

            /// <summary>
            /// Property Indexer for SortFieldName1 
            /// </summary>
            public const int SortFieldName1 = 87;

            /// <summary>
            /// Property Indexer for SortFieldName2 
            /// </summary>
            public const int SortFieldName2 = 88;

            /// <summary>
            /// Property Indexer for SortFieldName3 
            /// </summary>
            public const int SortFieldName3 = 89;

            /// <summary>
            /// Property Indexer for SortFieldName4 
            /// </summary>
            public const int SortFieldName4 = 90;

            /// <summary>
            /// Property Indexer for IncludeInvoice 
            /// </summary>
            public const int IncludeInvoice = 91;

            /// <summary>
            /// Property Indexer for IncludeDebitNote 
            /// </summary>
            public const int IncludeDebitNote = 92;

            /// <summary>
            /// Property Indexer for IncludeCreditNote 
            /// </summary>
            public const int IncludeCreditNote = 93;

            /// <summary>
            /// Property Indexer for IncludeInterest 
            /// </summary>
            public const int IncludeInterest = 94;

            /// <summary>
            /// Property Indexer for IncludePayment 
            /// </summary>
            public const int IncludePayment = 95;

            /// <summary>
            /// Property Indexer for IncludeFullyPaidTransactions 
            /// </summary>
            public const int IncludeFullyPaidTransactions = 96;

            /// <summary>
            /// Property Indexer for IncludeAdjustment 
            /// </summary>
            public const int IncludeAdjustment = 97;

            /// <summary>
            /// Property Indexer for FromDate 
            /// </summary>
            public const int FromDate = 98;

            /// <summary>
            /// Property Indexer for FromYear 
            /// </summary>
            public const int FromYear = 99;

            /// <summary>
            /// Property Indexer for FromPeriod 
            /// </summary>
            public const int FromPeriod = 100;

            /// <summary>
            /// Property Indexer for ShowAgedRetainage 
            /// </summary>
            public const int ShowAgedRetainage = 101;

            #endregion
        }
    }
}