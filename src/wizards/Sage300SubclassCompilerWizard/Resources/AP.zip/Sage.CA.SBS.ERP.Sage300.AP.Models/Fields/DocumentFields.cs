// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Document Constants 
    /// </summary>
    public partial class Document
    {
        #region Public Variables

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0025";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of Documents Fields Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";

            /// <summary>
            /// Property for DocumentNumber 
            /// </summary>
            public const string DocumentNumber = "IDINVC";

            /// <summary>
            /// Property for CheckNumber 
            /// </summary>
            public const string CheckNumber = "IDRMIT";

            /// <summary>
            /// Property for OrderNumber 
            /// </summary>
            public const string OrderNumber = "IDORDERNBR";

            /// <summary>
            /// Property for PONumber 
            /// </summary>
            public const string PONumber = "IDPONBR";

            /// <summary>
            /// Property for DueDate 
            /// </summary>
            public const string DueDate = "DATEINVCDU";

            /// <summary>
            /// Property for RemitToLocation 
            /// </summary>
            public const string RemitToLocation = "IDRMITTO";

            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "IDTRXTYPE";

            /// <summary>
            /// Property for DocumentType 
            /// </summary>
            public const string DocumentType = "TXTTRXTYPE";

            /// <summary>
            /// Property for DocumentTypeString 
            /// </summary>
            public const string DocumentTypeString = "TXTTRXTYPE";

            /// <summary>
            /// Property for BatchDate 
            /// </summary>
            public const string BatchDate = "DATEBTCH";

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";

            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTITEM";

            /// <summary>
            /// Property for GroupCode 
            /// </summary>
            public const string GroupCode = "IDVENDGRP";

            /// <summary>
            /// Property for DocDescription 
            /// </summary>
            public const string DocDescription = "DESCINVC";

            /// <summary>
            /// Property for DocDate 
            /// </summary>
            public const string DocDate = "DATEINVC";

            /// <summary>
            /// Property for InvoiceasofDate 
            /// </summary>
            public const string InvoiceasofDate = "DATEASOF";

            /// <summary>
            /// Property for Terms 
            /// </summary>
            public const string Terms = "CODETERM";

            /// <summary>
            /// Property for DiscountDate 
            /// </summary>
            public const string DiscountDate = "DATEDISC";

            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CODECURN";

            /// <summary>
            /// Property for RateType 
            /// </summary>
            public const string RateType = "IDRATETYPE";

            /// <summary>
            /// Property for RateOverridden 
            /// </summary>
            public const string RateOverridden = "SWRATEOVRD";

            /// <summary>
            /// Property for ExchangeRate 
            /// </summary>
            public const string ExchangeRate = "EXCHRATEHC";

            /// <summary>
            /// Property for FuncCurrencyInvoiceAmount 
            /// </summary>
            public const string FuncCurrencyInvoiceAmount = "AMTINVCHC";

            /// <summary>
            /// Property for FuncCurrencyAmountDue 
            /// </summary>
            public const string FuncCurrencyAmountDue = "AMTDUEHC";

            /// <summary>
            /// Property for FuncCurrencyTaxableAmount 
            /// </summary>
            public const string FuncCurrencyTaxableAmount = "AMTTXBLHC";

            /// <summary>
            /// Property for FuncCurrencyNonTaxableAmt 
            /// </summary>
            public const string FuncCurrencyNonTaxableAmt = "AMTNONTXHC";

            /// <summary>
            /// Property for FuncCurrencyTaxAmount 
            /// </summary>
            public const string FuncCurrencyTaxAmount = "AMTTAXHC";

            /// <summary>
            /// Property for FuncCurrencyDiscountAmount 
            /// </summary>
            public const string FuncCurrencyDiscountAmount = "AMTDISCHC";

            /// <summary>
            /// Property for VendCurrencyInvoiceAmount 
            /// </summary>
            public const string VendCurrencyInvoiceAmount = "AMTINVCTC";

            /// <summary>
            /// Property for VendCurrencyAmountDue 
            /// </summary>
            public const string VendCurrencyAmountDue = "AMTDUETC";

            /// <summary>
            /// Property for VendCurrencyTaxableAmount 
            /// </summary>
            public const string VendCurrencyTaxableAmount = "AMTTXBLTC";

            /// <summary>
            /// Property for VendCurrencyNonTaxableAmt 
            /// </summary>
            public const string VendCurrencyNonTaxableAmt = "AMTNONTXTC";

            /// <summary>
            /// Property for VendCurrencyTaxAmount 
            /// </summary>
            public const string VendCurrencyTaxAmount = "AMTTAXTC";

            /// <summary>
            /// Property for VendCurrencyDiscountAmount 
            /// </summary>
            public const string VendCurrencyDiscountAmount = "AMTDISCTC";

            /// <summary>
            /// Property for FullyPaid 
            /// </summary>
            public const string FullyPaid = "SWPAID";

            /// <summary>
            /// Property for LastActivityDate 
            /// </summary>
            public const string LastActivityDate = "DATELSTACT";

            /// <summary>
            /// Property for LastStatementDate 
            /// </summary>
            public const string LastStatementDate = "DATELSTSTM";

            /// <summary>
            /// Property for NumberofScheduledPayments 
            /// </summary>
            public const string NumberofScheduledPayments = "CNTTOTPAYM";

            /// <summary>
            /// Property for PaymentNumberonLastStatement 
            /// </summary>
            public const string PaymentNumberonLastStatement = "CNTLSTPYST";

            /// <summary>
            /// Property for LastAppliedPaymentSeqNo 
            /// </summary>
            public const string LastAppliedPaymentSeqNo = "CNTLASTSCH";

            /// <summary>
            /// Property for TaxAmountControl 
            /// </summary>
            public const string TaxAmountControl = "SWTAXOVRD";

            /// <summary>
            /// Property for TaxAuth1 
            /// </summary>
            public const string TaxAuth1 = "CODETAX1";

            /// <summary>
            /// Property for TaxAuth2 
            /// </summary>
            public const string TaxAuth2 = "CODETAX2";

            /// <summary>
            /// Property for TaxAuth3 
            /// </summary>
            public const string TaxAuth3 = "CODETAX3";

            /// <summary>
            /// Property for TaxAuth4 
            /// </summary>
            public const string TaxAuth4 = "CODETAX4";

            /// <summary>
            /// Property for TaxAuth5 
            /// </summary>
            public const string TaxAuth5 = "CODETAX5";

            /// <summary>
            /// Property for FuncBaseAmount1 
            /// </summary>
            public const string FuncBaseAmount1 = "AMTBASE1HC";

            /// <summary>
            /// Property for FuncBaseAmount2 
            /// </summary>
            public const string FuncBaseAmount2 = "AMTBASE2HC";

            /// <summary>
            /// Property for FuncBaseAmount3 
            /// </summary>
            public const string FuncBaseAmount3 = "AMTBASE3HC";

            /// <summary>
            /// Property for FuncBaseAmount4 
            /// </summary>
            public const string FuncBaseAmount4 = "AMTBASE4HC";

            /// <summary>
            /// Property for FuncBaseAmount5 
            /// </summary>
            public const string FuncBaseAmount5 = "AMTBASE5HC";

            /// <summary>
            /// Property for FuncTaxAmount1 
            /// </summary>
            public const string FuncTaxAmount1 = "AMTTAX1HC";

            /// <summary>
            /// Property for FuncTaxAmount2 
            /// </summary>
            public const string FuncTaxAmount2 = "AMTTAX2HC";

            /// <summary>
            /// Property for FuncTaxAmount3 
            /// </summary>
            public const string FuncTaxAmount3 = "AMTTAX3HC";

            /// <summary>
            /// Property for FuncTaxAmount4 
            /// </summary>
            public const string FuncTaxAmount4 = "AMTTAX4HC";

            /// <summary>
            /// Property for FuncTaxAmount5 
            /// </summary>
            public const string FuncTaxAmount5 = "AMTTAX5HC";

            /// <summary>
            /// Property for VendBaseAmount1 
            /// </summary>
            public const string VendBaseAmount1 = "AMTBASE1TC";

            /// <summary>
            /// Property for VendBaseAmount2 
            /// </summary>
            public const string VendBaseAmount2 = "AMTBASE2TC";

            /// <summary>
            /// Property for VendBaseAmount3 
            /// </summary>
            public const string VendBaseAmount3 = "AMTBASE3TC";

            /// <summary>
            /// Property for VendBaseAmount4 
            /// </summary>
            public const string VendBaseAmount4 = "AMTBASE4TC";

            /// <summary>
            /// Property for VendBaseAmount5 
            /// </summary>
            public const string VendBaseAmount5 = "AMTBASE5TC";

            /// <summary>
            /// Property for VendTaxAmount1 
            /// </summary>
            public const string VendTaxAmount1 = "AMTTAX1TC";

            /// <summary>
            /// Property for VendTaxAmount2 
            /// </summary>
            public const string VendTaxAmount2 = "AMTTAX2TC";

            /// <summary>
            /// Property for VendTaxAmount3 
            /// </summary>
            public const string VendTaxAmount3 = "AMTTAX3TC";

            /// <summary>
            /// Property for VendTaxAmount4 
            /// </summary>
            public const string VendTaxAmount4 = "AMTTAX4TC";

            /// <summary>
            /// Property for VendTaxAmount5 
            /// </summary>
            public const string VendTaxAmount5 = "AMTTAX5TC";

            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FISCYR";

            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FISCPER";

            /// <summary>
            /// Property for PrepayInvoiceNumber 
            /// </summary>
            public const string PrepayInvoiceNumber = "IDPREPAY";

            /// <summary>
            /// Property for PostingDate 
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for Num1099OrCPRSCode 
            /// </summary>
            public const string Num1099OrCPRSCode = "ID1099CLAS";

            /// <summary>
            /// Property for Num1099OrCPRSOriginalAmount 
            /// </summary>
            public const string Num1099OrCPRSOriginalAmount = "AMT1099ORG";

            /// <summary>
            /// Property for Num1099OrCPRSRemainingAmount 
            /// </summary>
            public const string Num1099OrCPRSRemainingAmount = "AMT1099REM";

            /// <summary>
            /// Property for RateDate 
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateOperator 
            /// </summary>
            public const string RateOperator = "RATEOP";

            /// <summary>
            /// Property for LastActivityYearOrPeriod 
            /// </summary>
            public const string LastActivityYearOrPeriod = "YPLASTACT";

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "IDBANK";

            /// <summary>
            /// Property for CheckSerialNumber 
            /// </summary>
            public const string CheckSerialNumber = "LONGSERIAL";

            /// <summary>
            /// Property for PostingSequenceNo 
            /// </summary>
            public const string PostingSequenceNo = "POSTSEQNCE";

            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelated = "SWJOB";

            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelatedString = "SWJOB";
            /// <summary>
            /// Property for HasRetainage 
            /// </summary>
            public const string HasRetainage = "SWRTG";

            /// <summary>
            /// Property for RetainageOutstanding 
            /// </summary>
            public const string RetainageOutstanding = "SWRTGOUT";

            /// <summary>
            /// Property for DateRetainageDue 
            /// </summary>
            public const string DateRetainageDue = "RTGDATEDUE";

            /// <summary>
            /// Property for FuncCurrOrigRtngAmt 
            /// </summary>
            public const string FuncCurrOrigRtngAmt = "RTGOAMTHC";

            /// <summary>
            /// Property for FuncCurrRetainageAmount 
            /// </summary>
            public const string FuncCurrRetainageAmount = "RTGAMTHC";

            /// <summary>
            /// Property for VendCurrOrigRtngAmt 
            /// </summary>
            public const string VendCurrOrigRtngAmt = "RTGOAMTTC";

            /// <summary>
            /// Property for VendCurrRetainageAmount 
            /// </summary>
            public const string VendCurrRetainageAmount = "RTGAMTTC";

            /// <summary>
            /// Property for RetainageTermsCode 
            /// </summary>
            public const string RetainageTermsCode = "RTGTERMS";

            /// <summary>
            /// Property for RetainageExchangeRate 
            /// </summary>
            public const string RetainageExchangeRate = "SWRTGRATE";

            /// <summary>
            /// Property for OriginalDocNo 
            /// </summary>
            public const string OriginalDocNo = "RTGAPPLYTO";

            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPPL";

            /// <summary>
            /// Property for PaymentStatus 
            /// </summary>
            public const string PaymentStatus = "SWPYSTTS";

            /// <summary>
            /// Property for DatePaymentStatusChanged 
            /// </summary>
            public const string DatePaymentStatusChanged = "DATEPYSTTS";

            /// <summary>
            /// Property for AOrPVersionCreatedIn 
            /// </summary>
            public const string AOrPVersionCreatedIn = "APVERSION";

            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "TYPEBTCH";

            /// <summary>
            /// Property for NumberofOBLJDetails 
            /// </summary>
            public const string NumberofOBLJDetails = "CNTOBLJ";

            /// <summary>
            /// Property for TaxReportingCurrencyCode 
            /// </summary>
            public const string TaxReportingCurrencyCode = "CODECURNRC";

            /// <summary>
            /// Property for TaxReportingExchangeRate 
            /// </summary>
            public const string TaxReportingExchangeRate = "RATERC";

            /// <summary>
            /// Property for TaxReportingRateType 
            /// </summary>
            public const string TaxReportingRateType = "RATETYPERC";

            /// <summary>
            /// Property for TaxReportingRateDate 
            /// </summary>
            public const string TaxReportingRateDate = "RATEDATERC";

            /// <summary>
            /// Property for TaxReportingRateOperator 
            /// </summary>
            public const string TaxReportingRateOperator = "RATEOPRC";

            /// <summary>
            /// Property for TaxReportingRateOverride 
            /// </summary>
            public const string TaxReportingRateOverride = "SWRATERC";

            /// <summary>
            /// Property for ReportRetainageTax 
            /// </summary>
            public const string ReportRetainageTax = "SWTXRTGRPT";

            /// <summary>
            /// Property for TaxGroup 
            /// </summary>
            public const string TaxGroup = "CODETAXGRP";

            /// <summary>
            /// Property for TaxStateVersion 
            /// </summary>
            public const string TaxStateVersion = "TAXVERSION";

            /// <summary>
            /// Property for TaxBaseCalculateMethod 
            /// </summary>
            public const string TaxBaseCalculateMethod = "SWTXBSECTL";

            /// <summary>
            /// Property for TaxReportingCalculateMethod 
            /// </summary>
            public const string TaxReportingCalculateMethod = "SWTXCTLRC";

            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded1 = "SWTAXINCL1";

            /// <summary>
            /// Property for TaxIncluded2 
            /// </summary>
            public const string TaxIncluded2 = "SWTAXINCL2";

            /// <summary>
            /// Property for TaxIncluded3 
            /// </summary>
            public const string TaxIncluded3 = "SWTAXINCL3";

            /// <summary>
            /// Property for TaxIncluded4 
            /// </summary>
            public const string TaxIncluded4 = "SWTAXINCL4";

            /// <summary>
            /// Property for TaxIncluded5 
            /// </summary>
            public const string TaxIncluded5 = "SWTAXINCL5";

            /// <summary>
            /// Property for TaxBase1 
            /// </summary>
            public const string TaxBase1 = "TXBSERT1TC";

            /// <summary>
            /// Property for TaxBase2 
            /// </summary>
            public const string TaxBase2 = "TXBSERT2TC";

            /// <summary>
            /// Property for TaxBase3 
            /// </summary>
            public const string TaxBase3 = "TXBSERT3TC";

            /// <summary>
            /// Property for TaxBase4 
            /// </summary>
            public const string TaxBase4 = "TXBSERT4TC";

            /// <summary>
            /// Property for TaxBase5 
            /// </summary>
            public const string TaxBase5 = "TXBSERT5TC";

            /// <summary>
            /// Property for TaxAmount1 
            /// </summary>
            public const string TaxAmount1 = "TXAMTRT1TC";

            /// <summary>
            /// Property for TaxAmount2 
            /// </summary>
            public const string TaxAmount2 = "TXAMTRT2TC";

            /// <summary>
            /// Property for TaxAmount3 
            /// </summary>
            public const string TaxAmount3 = "TXAMTRT3TC";

            /// <summary>
            /// Property for TaxAmount4 
            /// </summary>
            public const string TaxAmount4 = "TXAMTRT4TC";

            /// <summary>
            /// Property for TaxAmount5 
            /// </summary>
            public const string TaxAmount5 = "TXAMTRT5TC";

            /// <summary>
            /// Property for EarliestBackdatedActivityDate 
            /// </summary>
            public const string EarliestBackdatedActivityDate = "DATEFRSTBK";

            /// <summary>
            /// Property for LastRevaluationDate 
            /// </summary>
            public const string LastRevaluationDate = "DATELSTRVL";

            /// <summary>
            /// Property for OrigExchangeRate 
            /// </summary>
            public const string OrigExchangeRate = "ORATE";

            /// <summary>
            /// Property for OrigRateType 
            /// </summary>
            public const string OrigRateType = "ORATETYPE";

            /// <summary>
            /// Property for OrigRateDate 
            /// </summary>
            public const string OrigRateDate = "ORATEDATE";

            /// <summary>
            /// Property for OrigRateOperator 
            /// </summary>
            public const string OrigRateOperator = "ORATEOP";

            /// <summary>
            /// Property for OrigRateOverrideFlag 
            /// </summary>
            public const string OrigRateOverrideFlag = "OSWRATE";

            /// <summary>
            /// Property for AccountSet 
            /// </summary>
            public const string AccountSet = "IDACCTSET";

            /// <summary>
            /// Property for DatePaid 
            /// </summary>
            public const string DatePaid = "DATEPAID";

            /// <summary>
            /// Property for MiscPaymentFlag 
            /// </summary>
            public const string MiscPaymentFlag = "SWNONRCVBL";
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of Documents Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 1;

            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 2;

            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int CheckNumber = 3;

            /// <summary>
            /// Property Indexer for OrderNumber 
            /// </summary>
            public const int OrderNumber = 4;

            /// <summary>
            /// Property Indexer for PONumber 
            /// </summary>
            public const int PONumber = 5;

            /// <summary>
            /// Property Indexer for DueDate 
            /// </summary>
            public const int DueDate = 6;

            /// <summary>
            /// Property Indexer for RemitToLocation 
            /// </summary>
            public const int RemitToLocation = 7;

            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 8;

            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 9;

            /// <summary>
            /// Property Indexer for BatchDate 
            /// </summary>
            public const int BatchDate = 10;

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 11;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 12;

            /// <summary>
            /// Property Indexer for GroupCode 
            /// </summary>
            public const int GroupCode = 13;

            /// <summary>
            /// Property Indexer for DocDescription 
            /// </summary>
            public const int DocDescription = 14;

            /// <summary>
            /// Property Indexer for DocDate 
            /// </summary>
            public const int DocDate = 15;

            /// <summary>
            /// Property Indexer for InvoiceasofDate 
            /// </summary>
            public const int InvoiceasofDate = 16;

            /// <summary>
            /// Property Indexer for Terms 
            /// </summary>
            public const int Terms = 17;

            /// <summary>
            /// Property Indexer for DiscountDate 
            /// </summary>
            public const int DiscountDate = 18;

            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 19;

            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 20;

            /// <summary>
            /// Property Indexer for RateOverridden 
            /// </summary>
            public const int RateOverridden = 21;

            /// <summary>
            /// Property Indexer for ExchangeRate 
            /// </summary>
            public const int ExchangeRate = 22;

            /// <summary>
            /// Property Indexer for FuncCurrencyInvoiceAmount 
            /// </summary>
            public const int FuncCurrencyInvoiceAmount = 23;

            /// <summary>
            /// Property Indexer for FuncCurrencyAmountDue 
            /// </summary>
            public const int FuncCurrencyAmountDue = 24;

            /// <summary>
            /// Property Indexer for FuncCurrencyTaxableAmount 
            /// </summary>
            public const int FuncCurrencyTaxableAmount = 25;

            /// <summary>
            /// Property Indexer for FuncCurrencyNonTaxableAmt 
            /// </summary>
            public const int FuncCurrencyNonTaxableAmt = 26;

            /// <summary>
            /// Property Indexer for FuncCurrencyTaxAmount 
            /// </summary>
            public const int FuncCurrencyTaxAmount = 27;

            /// <summary>
            /// Property Indexer for FuncCurrencyDiscountAmount 
            /// </summary>
            public const int FuncCurrencyDiscountAmount = 28;

            /// <summary>
            /// Property Indexer for VendCurrencyInvoiceAmount 
            /// </summary>
            public const int VendCurrencyInvoiceAmount = 29;

            /// <summary>
            /// Property Indexer for VendCurrencyAmountDue 
            /// </summary>
            public const int VendCurrencyAmountDue = 30;

            /// <summary>
            /// Property Indexer for VendCurrencyTaxableAmount 
            /// </summary>
            public const int VendCurrencyTaxableAmount = 31;

            /// <summary>
            /// Property Indexer for VendCurrencyNonTaxableAmt 
            /// </summary>
            public const int VendCurrencyNonTaxableAmt = 32;

            /// <summary>
            /// Property Indexer for VendCurrencyTaxAmount 
            /// </summary>
            public const int VendCurrencyTaxAmount = 33;

            /// <summary>
            /// Property Indexer for VendCurrencyDiscountAmount 
            /// </summary>
            public const int VendCurrencyDiscountAmount = 34;

            /// <summary>
            /// Property Indexer for FullyPaid 
            /// </summary>
            public const int FullyPaid = 35;

            /// <summary>
            /// Property Indexer for LastActivityDate 
            /// </summary>
            public const int LastActivityDate = 36;

            /// <summary>
            /// Property Indexer for LastStatementDate 
            /// </summary>
            public const int LastStatementDate = 37;

            /// <summary>
            /// Property Indexer for NumberofScheduledPayments 
            /// </summary>
            public const int NumberofScheduledPayments = 38;

            /// <summary>
            /// Property Indexer for PaymentNumberonLastStatement 
            /// </summary>
            public const int PaymentNumberonLastStatement = 40;

            /// <summary>
            /// Property Indexer for LastAppliedPaymentSeqNo 
            /// </summary>
            public const int LastAppliedPaymentSeqNo = 42;

            /// <summary>
            /// Property Indexer for TaxAmountControl 
            /// </summary>
            public const int TaxAmountControl = 43;

            /// <summary>
            /// Property Indexer for TaxAuth1 
            /// </summary>
            public const int TaxAuth1 = 44;

            /// <summary>
            /// Property Indexer for TaxAuth2 
            /// </summary>
            public const int TaxAuth2 = 45;

            /// <summary>
            /// Property Indexer for TaxAuth3 
            /// </summary>
            public const int TaxAuth3 = 46;

            /// <summary>
            /// Property Indexer for TaxAuth4 
            /// </summary>
            public const int TaxAuth4 = 47;

            /// <summary>
            /// Property Indexer for TaxAuth5 
            /// </summary>
            public const int TaxAuth5 = 48;

            /// <summary>
            /// Property Indexer for FuncBaseAmount1 
            /// </summary>
            public const int FuncBaseAmount1 = 49;

            /// <summary>
            /// Property Indexer for FuncBaseAmount2 
            /// </summary>
            public const int FuncBaseAmount2 = 50;

            /// <summary>
            /// Property Indexer for FuncBaseAmount3 
            /// </summary>
            public const int FuncBaseAmount3 = 51;

            /// <summary>
            /// Property Indexer for FuncBaseAmount4 
            /// </summary>
            public const int FuncBaseAmount4 = 52;

            /// <summary>
            /// Property Indexer for FuncBaseAmount5 
            /// </summary>
            public const int FuncBaseAmount5 = 53;

            /// <summary>
            /// Property Indexer for FuncTaxAmount1 
            /// </summary>
            public const int FuncTaxAmount1 = 54;

            /// <summary>
            /// Property Indexer for FuncTaxAmount2 
            /// </summary>
            public const int FuncTaxAmount2 = 55;

            /// <summary>
            /// Property Indexer for FuncTaxAmount3 
            /// </summary>
            public const int FuncTaxAmount3 = 56;

            /// <summary>
            /// Property Indexer for FuncTaxAmount4 
            /// </summary>
            public const int FuncTaxAmount4 = 57;

            /// <summary>
            /// Property Indexer for FuncTaxAmount5 
            /// </summary>
            public const int FuncTaxAmount5 = 58;

            /// <summary>
            /// Property Indexer for VendBaseAmount1 
            /// </summary>
            public const int VendBaseAmount1 = 59;

            /// <summary>
            /// Property Indexer for VendBaseAmount2 
            /// </summary>
            public const int VendBaseAmount2 = 60;

            /// <summary>
            /// Property Indexer for VendBaseAmount3 
            /// </summary>
            public const int VendBaseAmount3 = 61;

            /// <summary>
            /// Property Indexer for VendBaseAmount4 
            /// </summary>
            public const int VendBaseAmount4 = 62;

            /// <summary>
            /// Property Indexer for VendBaseAmount5 
            /// </summary>
            public const int VendBaseAmount5 = 63;

            /// <summary>
            /// Property Indexer for VendTaxAmount1 
            /// </summary>
            public const int VendTaxAmount1 = 64;

            /// <summary>
            /// Property Indexer for VendTaxAmount2 
            /// </summary>
            public const int VendTaxAmount2 = 65;

            /// <summary>
            /// Property Indexer for VendTaxAmount3 
            /// </summary>
            public const int VendTaxAmount3 = 66;

            /// <summary>
            /// Property Indexer for VendTaxAmount4 
            /// </summary>
            public const int VendTaxAmount4 = 67;

            /// <summary>
            /// Property Indexer for VendTaxAmount5 
            /// </summary>
            public const int VendTaxAmount5 = 68;

            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 77;

            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 78;

            /// <summary>
            /// Property Indexer for PrepayInvoiceNumber 
            /// </summary>
            public const int PrepayInvoiceNumber = 79;

            /// <summary>
            /// Property Indexer for PostingDate 
            /// </summary>
            public const int PostingDate = 80;

            /// <summary>
            /// Property Indexer for Num1099OrCPRSCode 
            /// </summary>
            public const int Num1099OrCPRSCode = 81;

            /// <summary>
            /// Property Indexer for Num1099OrCPRSOriginalAmount 
            /// </summary>
            public const int Num1099OrCPRSOriginalAmount = 82;

            /// <summary>
            /// Property Indexer for Num1099OrCPRSRemainingAmount 
            /// </summary>
            public const int Num1099OrCPRSRemainingAmount = 83;

            /// <summary>
            /// Property Indexer for RateDate 
            /// </summary>
            public const int RateDate = 84;

            /// <summary>
            /// Property Indexer for RateOperator 
            /// </summary>
            public const int RateOperator = 85;

            /// <summary>
            /// Property Indexer for LastActivityYearOrPeriod 
            /// </summary>
            public const int LastActivityYearOrPeriod = 86;

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 87;

            /// <summary>
            /// Property Indexer for CheckSerialNumber 
            /// </summary>
            public const int CheckSerialNumber = 88;

            /// <summary>
            /// Property Indexer for PostingSequenceNo 
            /// </summary>
            public const int PostingSequenceNo = 89;

            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 90;

            /// <summary>
            /// Property Indexer for HasRetainage 
            /// </summary>
            public const int HasRetainage = 91;

            /// <summary>
            /// Property Indexer for RetainageOutstanding 
            /// </summary>
            public const int RetainageOutstanding = 92;

            /// <summary>
            /// Property Indexer for DateRetainageDue 
            /// </summary>
            public const int DateRetainageDue = 93;

            /// <summary>
            /// Property Indexer for FuncCurrOrigRtngAmt 
            /// </summary>
            public const int FuncCurrOrigRtngAmt = 94;

            /// <summary>
            /// Property Indexer for FuncCurrRetainageAmount 
            /// </summary>
            public const int FuncCurrRetainageAmount = 95;

            /// <summary>
            /// Property Indexer for VendCurrOrigRtngAmt 
            /// </summary>
            public const int VendCurrOrigRtngAmt = 96;

            /// <summary>
            /// Property Indexer for VendCurrRetainageAmount 
            /// </summary>
            public const int VendCurrRetainageAmount = 97;

            /// <summary>
            /// Property Indexer for RetainageTermsCode 
            /// </summary>
            public const int RetainageTermsCode = 98;

            /// <summary>
            /// Property Indexer for RetainageExchangeRate 
            /// </summary>
            public const int RetainageExchangeRate = 99;

            /// <summary>
            /// Property Indexer for OriginalDocNo 
            /// </summary>
            public const int OriginalDocNo = 100;

            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 101;

            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 102;

            /// <summary>
            /// Property Indexer for PaymentStatus 
            /// </summary>
            public const int PaymentStatus = 103;

            /// <summary>
            /// Property Indexer for DatePaymentStatusChanged 
            /// </summary>
            public const int DatePaymentStatusChanged = 104;

            /// <summary>
            /// Property Indexer for AOrPVersionCreatedIn 
            /// </summary>
            public const int AOrPVersionCreatedIn = 105;

            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 106;

            /// <summary>
            /// Property Indexer for NumberofOBLJDetails 
            /// </summary>
            public const int NumberofOBLJDetails = 107;

            /// <summary>
            /// Property Indexer for TaxReportingCurrencyCode 
            /// </summary>
            public const int TaxReportingCurrencyCode = 108;

            /// <summary>
            /// Property Indexer for TaxReportingExchangeRate 
            /// </summary>
            public const int TaxReportingExchangeRate = 109;

            /// <summary>
            /// Property Indexer for TaxReportingRateType 
            /// </summary>
            public const int TaxReportingRateType = 110;

            /// <summary>
            /// Property Indexer for TaxReportingRateDate 
            /// </summary>
            public const int TaxReportingRateDate = 111;

            /// <summary>
            /// Property Indexer for TaxReportingRateOperator 
            /// </summary>
            public const int TaxReportingRateOperator = 112;

            /// <summary>
            /// Property Indexer for TaxReportingRateOverride 
            /// </summary>
            public const int TaxReportingRateOverride = 113;

            /// <summary>
            /// Property Indexer for ReportRetainageTax 
            /// </summary>
            public const int ReportRetainageTax = 114;

            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroup = 115;

            /// <summary>
            /// Property Indexer for TaxStateVersion 
            /// </summary>
            public const int TaxStateVersion = 116;

            /// <summary>
            /// Property Indexer for TaxBaseCalculateMethod 
            /// </summary>
            public const int TaxBaseCalculateMethod = 117;

            /// <summary>
            /// Property Indexer for TaxReportingCalculateMethod 
            /// </summary>
            public const int TaxReportingCalculateMethod = 118;

            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 119;

            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 120;

            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 121;

            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 122;

            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 123;

            /// <summary>
            /// Property Indexer for TaxIncluded1 
            /// </summary>
            public const int TaxIncluded1 = 124;

            /// <summary>
            /// Property Indexer for TaxIncluded2 
            /// </summary>
            public const int TaxIncluded2 = 125;

            /// <summary>
            /// Property Indexer for TaxIncluded3 
            /// </summary>
            public const int TaxIncluded3 = 126;

            /// <summary>
            /// Property Indexer for TaxIncluded4 
            /// </summary>
            public const int TaxIncluded4 = 127;

            /// <summary>
            /// Property Indexer for TaxIncluded5 
            /// </summary>
            public const int TaxIncluded5 = 128;

            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 129;

            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 130;

            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 131;

            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 132;

            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 133;

            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 134;

            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 135;

            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 136;

            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 137;

            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 138;

            /// <summary>
            /// Property Indexer for EarliestBackdatedActivityDate 
            /// </summary>
            public const int EarliestBackdatedActivityDate = 139;

            /// <summary>
            /// Property Indexer for LastRevaluationDate 
            /// </summary>
            public const int LastRevaluationDate = 140;

            /// <summary>
            /// Property Indexer for OrigExchangeRate 
            /// </summary>
            public const int OrigExchangeRate = 141;

            /// <summary>
            /// Property Indexer for OrigRateType 
            /// </summary>
            public const int OrigRateType = 142;

            /// <summary>
            /// Property Indexer for OrigRateDate 
            /// </summary>
            public const int OrigRateDate = 143;

            /// <summary>
            /// Property Indexer for OrigRateOperator 
            /// </summary>
            public const int OrigRateOperator = 144;

            /// <summary>
            /// Property Indexer for OrigRateOverrideFlag 
            /// </summary>
            public const int OrigRateOverrideFlag = 145;

            /// <summary>
            /// Property Indexer for AccountSet 
            /// </summary>
            public const int AccountSet = 146;

            /// <summary>
            /// Property Indexer for DatePaid 
            /// </summary>
            public const int DatePaid = 147;

            /// <summary>
            /// Property Indexer for MiscPaymentFlag 
            /// </summary>
            public const int MiscPaymentFlag = 148;
        }

        #endregion
    }
}