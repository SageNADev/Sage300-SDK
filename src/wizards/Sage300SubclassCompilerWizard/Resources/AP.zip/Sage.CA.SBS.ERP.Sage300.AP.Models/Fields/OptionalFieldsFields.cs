/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of OptionalFields Constants 
    /// </summary>
	public partial class OptionalFields 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "AP0500";

        /// <summary>
        /// Contains list of OptionalFields Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for Location 
        /// </summary>
	    public const string Location  = "LOCATION";
	            /// <summary>
        /// Property for OptionalField 
        /// </summary>
	    public const string OptionalField  = "OPTFIELD";
	            /// <summary>
        /// Property for DefaultValue 
        /// </summary>
	    public const string DefaultValue  = "DEFVAL";
	            /// <summary>
        /// Property for Type 
        /// </summary>
	    public const string Type  = "TYPE";
	            /// <summary>
        /// Property for Length 
        /// </summary>
	    public const string Length  = "LENGTH";
	            /// <summary>
        /// Property for Decimals 
        /// </summary>
	    public const string Decimals  = "DECIMALS";
	            /// <summary>
        /// Property for AllowBlank 
        /// </summary>
	    public const string AllowBlank  = "ALLOWNULL";
	            /// <summary>
        /// Property for Validate 
        /// </summary>
	    public const string Validate  = "VALIDATE";
	            /// <summary>
        /// Property for AutoInsert 
        /// </summary>
	    public const string AutoInsert  = "INITFLAG";
	            /// <summary>
        /// Property for PayablesControl 
        /// </summary>
	    public const string PayablesControl  = "SWCONTROL";
	            /// <summary>
        /// Property for Retainage 
        /// </summary>
	    public const string Retainage  = "SWRTG";
	            /// <summary>
        /// Property for PurchaseDiscount 
        /// </summary>
	    public const string PurchaseDiscount  = "SWDISCOUNT";
	            /// <summary>
        /// Property for RecoverableTax 
        /// </summary>
	    public const string RecoverableTax  = "SWTAXRECOV";
	            /// <summary>
        /// Property for ExpenseTax 
        /// </summary>
	    public const string ExpenseTax  = "SWTAXEXP";
	            /// <summary>
        /// Property for ExchangeGain 
        /// </summary>
	    public const string ExchangeGain  = "SWREXCHG";
	            /// <summary>
        /// Property for ExchangeLoss 
        /// </summary>
	    public const string ExchangeLoss  = "SWREXCHL";
	            /// <summary>
        /// Property for UnrealizedExchangeGain 
        /// </summary>
	    public const string UnrealizedExchangeGain  = "SWUREXCHG";
	            /// <summary>
        /// Property for UnrealizedExchangeLoss 
        /// </summary>
	    public const string UnrealizedExchangeLoss  = "SWUREXCHL";
	            /// <summary>
        /// Property for Rounding 
        /// </summary>
	    public const string Rounding  = "SWROUND";
	            /// <summary>
        /// Property for Distribution 
        /// </summary>
	    public const string Distribution  = "SWDISTRIB";
	            /// <summary>
        /// Property for Prepayment 
        /// </summary>
	    public const string Prepayment  = "SWPREPAY";
	            /// <summary>
        /// Property for MiscellaneousPayment 
        /// </summary>
	    public const string MiscellaneousPayment  = "SWMISCPAY";
	            /// <summary>
        /// Property for Bank 
        /// </summary>
	    public const string Bank  = "SWBANK";
	            /// <summary>
        /// Property for Adjustment 
        /// </summary>
	    public const string Adjustment  = "SWADJ";
	            /// <summary>
        /// Property for Labor 
        /// </summary>
	    public const string Labor  = "SWLABOUR";
	            /// <summary>
        /// Property for Overhead 
        /// </summary>
	    public const string Overhead  = "SWOHEAD";
	            /// <summary>
        /// Property for ExternalCostTransactions 
        /// </summary>
	    public const string ExternalCostTransactions  = "SWPM";
	            /// <summary>
        /// Property for Required 
        /// </summary>
	    public const string Required  = "SWREQUIRED";
	            /// <summary>
        /// Property for ValueSet 
        /// </summary>
	    public const string ValueSet  = "SWSET";
	            /// <summary>
        /// Property for TypedDefaultValueFieldIndex 
        /// </summary>
	    public const string TypedDefaultValueFieldIndex  = "DVINDEX";
	            /// <summary>
        /// Property for DefaultTextValue 
        /// </summary>
	    public const string DefaultTextValue  = "DVIFTEXT";
	            /// <summary>
        /// Property for DefaultAmountValue 
        /// </summary>
	    public const string DefaultAmountValue  = "DVIFMONEY";
	            /// <summary>
        /// Property for DefaultNumberValue 
        /// </summary>
	    public const string DefaultNumberValue  = "DVIFNUM";
	            /// <summary>
        /// Property for DefaultIntegerValue 
        /// </summary>
	    public const string DefaultIntegerValue  = "DVIFLONG";
	            /// <summary>
        /// Property for DefaultYesOrNoValue 
        /// </summary>
	    public const string DefaultYesOrNoValue  = "DVIFBOOL";
	            /// <summary>
        /// Property for DefaultDateValue 
        /// </summary>
	    public const string DefaultDateValue  = "DVIFDATE";
	            /// <summary>
        /// Property for DefaultTimeValue 
        /// </summary>
	    public const string DefaultTimeValue  = "DVIFTIME";
	            /// <summary>
        /// Property for OptionalFieldDescription 
        /// </summary>
	    public const string OptionalFieldDescription  = "FDESC";
	            /// <summary>
        /// Property for DefaultValueDescription 
        /// </summary>
	    public const string DefaultValueDescription  = "VDESC";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of OptionalFields Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for Location 
        /// </summary>
	    public const int Location  = 1;
	             /// <summary>
        /// Property Indexer for OptionalField 
        /// </summary>
	    public const int OptionalField  = 2;
	             /// <summary>
        /// Property Indexer for DefaultValue 
        /// </summary>
	    public const int DefaultValue  = 3;
	             /// <summary>
        /// Property Indexer for Type 
        /// </summary>
	    public const int Type  = 4;
	             /// <summary>
        /// Property Indexer for Length 
        /// </summary>
	    public const int Length  = 5;
	             /// <summary>
        /// Property Indexer for Decimals 
        /// </summary>
	    public const int Decimals  = 6;
	             /// <summary>
        /// Property Indexer for AllowBlank 
        /// </summary>
	    public const int AllowBlank  = 7;
	             /// <summary>
        /// Property Indexer for Validate 
        /// </summary>
	    public const int Validate  = 8;
	             /// <summary>
        /// Property Indexer for AutoInsert 
        /// </summary>
	    public const int AutoInsert  = 9;
	             /// <summary>
        /// Property Indexer for PayablesControl 
        /// </summary>
	    public const int PayablesControl  = 10;
	             /// <summary>
        /// Property Indexer for Retainage 
        /// </summary>
	    public const int Retainage  = 11;
	             /// <summary>
        /// Property Indexer for PurchaseDiscount 
        /// </summary>
	    public const int PurchaseDiscount  = 12;
	             /// <summary>
        /// Property Indexer for RecoverableTax 
        /// </summary>
	    public const int RecoverableTax  = 13;
	             /// <summary>
        /// Property Indexer for ExpenseTax 
        /// </summary>
	    public const int ExpenseTax  = 14;
	             /// <summary>
        /// Property Indexer for ExchangeGain 
        /// </summary>
	    public const int ExchangeGain  = 15;
	             /// <summary>
        /// Property Indexer for ExchangeLoss 
        /// </summary>
	    public const int ExchangeLoss  = 16;
	             /// <summary>
        /// Property Indexer for UnrealizedExchangeGain 
        /// </summary>
	    public const int UnrealizedExchangeGain  = 17;
	             /// <summary>
        /// Property Indexer for UnrealizedExchangeLoss 
        /// </summary>
	    public const int UnrealizedExchangeLoss  = 18;
	             /// <summary>
        /// Property Indexer for Rounding 
        /// </summary>
	    public const int Rounding  = 19;
	             /// <summary>
        /// Property Indexer for Distribution 
        /// </summary>
	    public const int Distribution  = 20;
	             /// <summary>
        /// Property Indexer for Prepayment 
        /// </summary>
	    public const int Prepayment  = 21;
	             /// <summary>
        /// Property Indexer for MiscellaneousPayment 
        /// </summary>
	    public const int MiscellaneousPayment  = 22;
	             /// <summary>
        /// Property Indexer for Bank 
        /// </summary>
	    public const int Bank  = 23;
	             /// <summary>
        /// Property Indexer for Adjustment 
        /// </summary>
	    public const int Adjustment  = 24;
	             /// <summary>
        /// Property Indexer for Labor 
        /// </summary>
	    public const int Labor  = 25;
	             /// <summary>
        /// Property Indexer for Overhead 
        /// </summary>
	    public const int Overhead  = 26;
	             /// <summary>
        /// Property Indexer for ExternalCostTransactions 
        /// </summary>
	    public const int ExternalCostTransactions  = 27;
	             /// <summary>
        /// Property Indexer for Required 
        /// </summary>
	    public const int Required  = 28;
	             /// <summary>
        /// Property Indexer for ValueSet 
        /// </summary>
	    public const int ValueSet  = 29;
	             /// <summary>
        /// Property Indexer for TypedDefaultValueFieldIndex 
        /// </summary>
	    public const int TypedDefaultValueFieldIndex  = 35;
	             /// <summary>
        /// Property Indexer for DefaultTextValue 
        /// </summary>
	    public const int DefaultTextValue  = 36;
	             /// <summary>
        /// Property Indexer for DefaultAmountValue 
        /// </summary>
	    public const int DefaultAmountValue  = 37;
	             /// <summary>
        /// Property Indexer for DefaultNumberValue 
        /// </summary>
	    public const int DefaultNumberValue  = 38;
	             /// <summary>
        /// Property Indexer for DefaultIntegerValue 
        /// </summary>
	    public const int DefaultIntegerValue  = 39;
	             /// <summary>
        /// Property Indexer for DefaultYesOrNoValue 
        /// </summary>
	    public const int DefaultYesOrNoValue  = 40;
	             /// <summary>
        /// Property Indexer for DefaultDateValue 
        /// </summary>
	    public const int DefaultDateValue  = 41;
	             /// <summary>
        /// Property Indexer for DefaultTimeValue 
        /// </summary>
	    public const int DefaultTimeValue  = 42;
	             /// <summary>
        /// Property Indexer for OptionalFieldDescription 
        /// </summary>
	    public const int OptionalFieldDescription  = 43;
	             /// <summary>
        /// Property Indexer for DefaultValueDescription 
        /// </summary>
	    public const int DefaultValueDescription  = 44;
	     
        #endregion
	    }

	
	}
}
	