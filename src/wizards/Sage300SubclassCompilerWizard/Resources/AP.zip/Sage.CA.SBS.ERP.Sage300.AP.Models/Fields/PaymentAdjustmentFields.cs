/* Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PaymentsAdjustments Constants 
    /// </summary>
	public partial class PaymentAdjustment
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0031";

        /// <summary>
        /// Contains list of PaymentsAdjustments Fields Constants
        /// </summary>
	    public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "BTCHTYPE";
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTENTR";
            /// <summary>
            /// Property for CheckNumber 
            /// </summary>
            public const string CheckNumber = "IDRMIT";
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";
            /// <summary>
            /// Property for PaymentDateOrAdjustmentDate 
            /// </summary>
            public const string PaymentDateOrAdjustmentDate = "DATERMIT";
            /// <summary>
            /// Property for EntryDescription 
            /// </summary>
            public const string EntryDescription = "TEXTRMIT";
            /// <summary>
            /// Property for VendorOrPayeeName 
            /// </summary>
            public const string VendorOrPayeeName = "NAMERMIT";
            /// <summary>
            /// Property for CheckAmountinBankCurr 
            /// </summary>
            public const string CheckAmountinBankCurr = "AMTRMIT";
            /// <summary>
            /// Property for CheckAmountinVendorCurr 
            /// </summary>
            public const string CheckAmountinVendorCurr = "AMTRMITTC";
            /// <summary>
            /// Property for VendorExchangeRate 
            /// </summary>
            public const string VendorExchangeRate = "RATEEXCHTC";
            /// <summary>
            /// Property for VendorRateOverridden 
            /// </summary>
            public const string VendorRateOverridden = "SWRATETC";
            /// <summary>
            /// Property for VendorRateOverriddenString 
            /// </summary>
            public const string VendorRateOverriddenString = "SWRATETC";
            /// <summary>
            /// Property for NumberofPaymentsEntered 
            /// </summary>
            public const string NumberofPaymentsEntered = "CNTPAYMENT";
            /// <summary>
            /// Property for TotalPrepayVendorCurr 
            /// </summary>
            public const string TotalPrepayVendorCurr = "AMTPPAYTC";
            /// <summary>
            /// Property for TotalDiscountVendorCurr 
            /// </summary>
            public const string TotalDiscountVendorCurr = "AMTDISCTC";
            /// <summary>
            /// Property for PaymentCode 
            /// </summary>
            public const string PaymentCode = "PAYMCODE";
            /// <summary>
            /// Property for VendorCurrencyCode 
            /// </summary>
            public const string VendorCurrencyCode = "CODECURN";
            /// <summary>
            /// Property for BankRateType 
            /// </summary>
            public const string BankRateType = "RATETYPEHC";
            /// <summary>
            /// Property for BankExchangeRate 
            /// </summary>
            public const string BankExchangeRate = "RATEEXCHHC";
            /// <summary>
            /// Property for BankRateOverridden 
            /// </summary>
            public const string BankRateOverridden = "SWRATEHC";
            /// <summary>
            /// Property for BankRateOverriddenString 
            /// </summary>
            public const string BankRateOverriddenString = "SWRATEHC";
            /// <summary>
            /// Property for PaymentTransType 
            /// </summary>
            public const string PaymentTransType = "RMITTYPE";

            /// <summary>
            /// Property for PaymentTransTypeString
            /// </summary>
            public const string PaymentTransTypeString = "RMITTYPE";
            /// <summary>
            /// Property for DocumentType 
            /// </summary>
            public const string DocumentType = "DOCTYPE";
            /// <summary>
            /// Property for DocumentTypeString
            /// </summary>
            public const string DocumentTypeString = "DOCTYPE";
            /// <summary>
            /// Property for LastLineNumber 
            /// </summary>
            public const string LastLineNumber = "CNTLSTLINE";
            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FISCYR";
            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FISCPER";
            /// <summary>
            /// Property for VendorRateDate 
            /// </summary>
            public const string VendorRateDate = "DATERATETC";
            /// <summary>
            /// Property for VendorRateType 
            /// </summary>
            public const string VendorRateType = "RATETYPETC";
            /// <summary>
            /// Property for TotalPaymentAdjVendorCurr 
            /// </summary>
            public const string TotalPaymentAdjVendorCurr = "AMTADJTCUR";
            /// <summary>
            /// Property for BankRateDate 
            /// </summary>
            public const string BankRateDate = "DATERATEHC";
            /// <summary>
            /// Property for TotalReapplyRemainingVendorC 
            /// </summary>
            public const string TotalReapplyRemainingVendorC = "REMREAPLTC";
            /// <summary>
            /// Property for AdjDebitAmtFuncCurr 
            /// </summary>
            public const string AdjDebitAmtFuncCurr = "ADJTOTDBHC";
            /// <summary>
            /// Property for CheckAmountFuncCurr 
            /// </summary>
            public const string CheckAmountFuncCurr = "AMTRMITHC";
            /// <summary>
            /// Property for DocumentNumber 
            /// </summary>
            public const string DocumentNumber = "DOCNBR";
            /// <summary>
            /// Property for PaymentEdited 
            /// </summary>
            public const string PaymentEdited = "PAYMSTTS";
            /// <summary>
            /// Property for PaymentEditedString 
            /// </summary>
            public const string PaymentEditedString = "PAYMSTTS";
            /// <summary>
            /// Property for CheckPrintRequired 
            /// </summary>
            public const string CheckPrintRequired = "SWPRNTRMIT";
            /// <summary>
            /// Property for CheckPrintRequiredString
            /// </summary>
            public const string CheckPrintRequiredString = "SWPRNTRMIT";
            /// <summary>
            /// Property for VendorRemitToLocation 
            /// </summary>
            public const string VendorRemitToLocation = "IDRMITTO";
            /// <summary>
            /// Property for EntryReference 
            /// </summary>
            public const string EntryReference = "TXTRMITREF";
            /// <summary>
            /// Property for AdjCreditAmtFuncCurr 
            /// </summary>
            public const string AdjCreditAmtFuncCurr = "ADJTOTCRHC";
            /// <summary>
            /// Property for TotalAdjAmtFuncCurr 
            /// </summary>
            public const string TotalAdjAmtFuncCurr = "AMTADJHCUR";
            /// <summary>
            /// Property for CheckSequenceNo 
            /// </summary>
            public const string CheckSequenceNo = "CNTDEPSSEQ";
            /// <summary>
            /// Property for CheckPrintedStatus 
            /// </summary>
            public const string CheckPrintedStatus = "SWPRINTED";
            /// <summary>
            /// Property for CheckPrintedStatusString 
            /// </summary>
            public const string CheckPrintedStatusString = "SWPRINTED";
            /// <summary>
            /// Property for AddressLine1 
            /// </summary>
            public const string AddressLine1 = "TEXTSTRE1";
            /// <summary>
            /// Property for AddressLine2 
            /// </summary>
            public const string AddressLine2 = "TEXTSTRE2";
            /// <summary>
            /// Property for AddressLine3 
            /// </summary>
            public const string AddressLine3 = "TEXTSTRE3";
            /// <summary>
            /// Property for AddressLine4 
            /// </summary>
            public const string AddressLine4 = "TEXTSTRE4";
            /// <summary>
            /// Property for City 
            /// </summary>
            public const string City = "NAMECITY";
            /// <summary>
            /// Property for State 
            /// </summary>
            public const string State = "CODESTTE";
            /// <summary>
            /// Property for ZipOrPostalCode 
            /// </summary>
            public const string ZipOrPostalCode = "CODEPSTL";
            /// <summary>
            /// Property for Country 
            /// </summary>
            public const string Country = "CODECTRY";
            /// <summary>
            /// Property for PaymentLanguage 
            /// </summary>
            public const string PaymentLanguage = "CHECKLANG";
            /// <summary>
            /// Property for PaymentLanguageString
            /// </summary>
            public const string PaymentLanguageString = "CHECKLANG";
            /// <summary>
            /// Property for BankRateOperator 
            /// </summary>
            public const string BankRateOperator = "OPERBANK";
            /// <summary>
            /// Property for BankRateOperatorString 
            /// </summary>
            public const string BankRateOperatorString = "OPERBANK";
            /// <summary>
            /// Property for VendorRateOperator 
            /// </summary>
            public const string VendorRateOperator = "OPERVEND";
            /// <summary>
            /// Property for VendorRateOperatorString
            /// </summary>
            public const string VendorRateOperatorString = "OPERVEND";
            /// <summary>
            /// Property for AdjDebitAmtVendorCurr 
            /// </summary>
            public const string AdjDebitAmtVendorCurr = "ADJTOTDBTC";
            /// <summary>
            /// Property for AdjCreditAmtVendorCurr 
            /// </summary>
            public const string AdjCreditAmtVendorCurr = "ADJTOTCRTC";
            /// <summary>
            /// Property for PrepayActivationDate 
            /// </summary>
            public const string PrepayActivationDate = "DATEACTVPP";
            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelated = "SWJOB";
            /// <summary>
            /// Property for JobRelatedString 
            /// </summary>
            public const string JobRelatedString = "SWJOB";
            /// <summary>
            /// Property for JobApplyMethod 
            /// </summary>
            public const string JobApplyMethod = "APPLYMETH";
            /// <summary>
            /// Property for JobApplyMethodString
            /// </summary>
            public const string JobApplyMethodString = "APPLYMETH";
            /// <summary>
            /// Property for ErrorBatch 
            /// </summary>
            public const string ErrorBatch = "ERRBATCH";
            /// <summary>
            /// Property for ErrorEntry 
            /// </summary>
            public const string ErrorEntry = "ERRENTRY";
            /// <summary>
            /// Property for MatchingDocumentNumber 
            /// </summary>
            public const string MatchingDocumentNumber = "IDINVCMTCH";
            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";
            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";
            /// <summary>
            /// Property for ProcessCommandCodeString
            /// </summary>
            public const string ProcessCommandCodeString = "PROCESSCMD";
            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPPL";
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "IDBANK";
            /// <summary>
            /// Property for BankCurrencyCode 
            /// </summary>
            public const string BankCurrencyCode = "CODECURNBC";
            /// <summary>
            /// Property for PaymentType 
            /// </summary>
            public const string PaymentType = "PAYMTYPE";
            /// <summary>
            /// Property for PaymentTypeString 
            /// </summary>
            public const string PaymentTypeString = "PAYMTYPE";
            /// <summary>
            /// Property for CashAccount 
            /// </summary>
            public const string CashAccount = "CASHACCT";
            /// <summary>
            /// Property for DrillDownApplicationSource 
            /// </summary>
            public const string DrillDownApplicationSource = "DRILLAPP";
            /// <summary>
            /// Property for DrillDownType 
            /// </summary>
            public const string DrillDownType = "DRILLTYPE";
            /// <summary>
            /// Property for DrillDownLinkNumber 
            /// </summary>
            public const string DrillDownLinkNumber = "DRILLDWNLK";
            /// <summary>
            /// Property for Num1099OrCPRSCode 
            /// </summary>
            public const string Num1099OrCPRSCode = "CODE1099";
            /// <summary>
            /// Property for Num1099OrCPRSAmount 
            /// </summary>
            public const string Num1099OrCPRSAmount = "AMT1099";
            /// <summary>
            /// Property for CalculateTaxAmountControl 
            /// </summary>
            public const string CalculateTaxAmountControl = "SWTXAMTCTL";
            /// <summary>
            /// Property for CalculateTaxAmountControlString
            /// </summary>
            public const string CalculateTaxAmountControlString = "SWTXAMTCTL";
            /// <summary>
            /// Property for CalculateTaxBaseControl 
            /// </summary>
            public const string CalculateTaxBaseControl = "SWTXBSECTL";
            /// <summary>
            /// Property for CalculateTaxBaseControlString
            /// </summary>
            public const string CalculateTaxBaseControlString = "SWTXBSECTL";
            /// <summary>
            /// Property for TaxGroup 
            /// </summary>
            public const string TaxGroup = "CODETAXGRP";
            /// <summary>
            /// Property for TaxStateVersion 
            /// </summary>
            public const string TaxStateVersion = "TAXVERSION";
            /// <summary>
            /// Property for TaxAuthority1 
            /// </summary>
            public const string TaxAuthority1 = "CODETAX1";
            /// <summary>
            /// Property for TaxAuthority2 
            /// </summary>
            public const string TaxAuthority2 = "CODETAX2";
            /// <summary>
            /// Property for TaxAuthority3 
            /// </summary>
            public const string TaxAuthority3 = "CODETAX3";
            /// <summary>
            /// Property for TaxAuthority4 
            /// </summary>
            public const string TaxAuthority4 = "CODETAX4";
            /// <summary>
            /// Property for TaxAuthority5 
            /// </summary>
            public const string TaxAuthority5 = "CODETAX5";
            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";
            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";
            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";
            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";
            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";
            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded1 = "SWTAXINCL1";
            /// <summary>
            /// Property for TaxIncluded1String
            /// </summary>
            public const string TaxIncluded1String = "SWTAXINCL1";
            /// <summary>
            /// Property for TaxIncluded2 
            /// </summary>
            public const string TaxIncluded2 = "SWTAXINCL2";
            /// <summary>
            /// Property for TaxIncluded2String 
            /// </summary>
            public const string TaxIncluded2String = "SWTAXINCL2";
            /// <summary>
            /// Property for TaxIncluded3 
            /// </summary>
            public const string TaxIncluded3 = "SWTAXINCL3";
            /// <summary>
            /// Property for TaxIncluded3String 
            /// </summary>
            public const string TaxIncluded3String = "SWTAXINCL3";
            /// <summary>
            /// Property for TaxIncluded4 
            /// </summary>
            public const string TaxIncluded4 = "SWTAXINCL4";
            /// <summary>
            /// Property for TaxIncluded4String 
            /// </summary>
            public const string TaxIncluded4String = "SWTAXINCL4";
            /// <summary>
            /// Property for TaxIncluded5 
            /// </summary>
            public const string TaxIncluded5 = "SWTAXINCL5";
            /// <summary>
            /// Property for TaxIncluded5String 
            /// </summary>
            public const string TaxIncluded5String = "SWTAXINCL5";
            /// <summary>
            /// Property for TaxBase1 
            /// </summary>
            public const string TaxBase1 = "TXBSE1TC";
            /// <summary>
            /// Property for TaxBase2 
            /// </summary>
            public const string TaxBase2 = "TXBSE2TC";
            /// <summary>
            /// Property for TaxBase3 
            /// </summary>
            public const string TaxBase3 = "TXBSE3TC";
            /// <summary>
            /// Property for TaxBase4 
            /// </summary>
            public const string TaxBase4 = "TXBSE4TC";
            /// <summary>
            /// Property for TaxBase5 
            /// </summary>
            public const string TaxBase5 = "TXBSE5TC";
            /// <summary>
            /// Property for TaxAmount1 
            /// </summary>
            public const string TaxAmount1 = "TXAMT1TC";
            /// <summary>
            /// Property for TaxAmount2 
            /// </summary>
            public const string TaxAmount2 = "TXAMT2TC";
            /// <summary>
            /// Property for TaxAmount3 
            /// </summary>
            public const string TaxAmount3 = "TXAMT3TC";
            /// <summary>
            /// Property for TaxAmount4 
            /// </summary>
            public const string TaxAmount4 = "TXAMT4TC";
            /// <summary>
            /// Property for TaxAmount5 
            /// </summary>
            public const string TaxAmount5 = "TXAMT5TC";
            /// <summary>
            /// Property for TaxTotal 
            /// </summary>
            public const string TaxTotal = "TXTOTTC";
            /// <summary>
            /// Property for DistAmountNetofTaxes 
            /// </summary>
            public const string DistAmountNetofTaxes = "AMTNETTC";
            /// <summary>
            /// Property for TaxAllocatedTotal 
            /// </summary>
            public const string TaxAllocatedTotal = "TXALLTC";
            /// <summary>
            /// Property for TaxExpensedTotal 
            /// </summary>
            public const string TaxExpensedTotal = "TXEXPTC";
            /// <summary>
            /// Property for TaxRecoverableTotal 
            /// </summary>
            public const string TaxRecoverableTotal = "TXRECTC";
            /// <summary>
            /// Property for TaxReportingCurrencyCode 
            /// </summary>
            public const string TaxReportingCurrencyCode = "CODECURNRC";
            /// <summary>
            /// Property for TaxReportingCalculateMethod 
            /// </summary>
            public const string TaxReportingCalculateMethod = "SWTXCTLRC";
            /// <summary>
            /// Property for TaxReportingCalculateMethodString 
            /// </summary>
            public const string TaxReportingCalculateMethodString = "SWTXCTLRC";
            /// <summary>
            /// Property for TaxReportingExchangeRate 
            /// </summary>
            public const string TaxReportingExchangeRate = "RATERC";
            /// <summary>
            /// Property for TaxReportingRateType 
            /// </summary>
            public const string TaxReportingRateType = "RATETYPERC";
            /// <summary>
            /// Property for TaxReportingRateDate 
            /// </summary>
            public const string TaxReportingRateDate = "RATEDATERC";
            /// <summary>
            /// Property for TaxReportingRateOperator 
            /// </summary>
            public const string TaxReportingRateOperator = "RATEOPRC";
            /// <summary>
            /// Property for TaxReportingRateOperatorString 
            /// </summary>
            public const string TaxReportingRateOperatorString = "RATEOPRC";
            /// <summary>
            /// Property for TaxReportingRateOverride 
            /// </summary>
            public const string TaxReportingRateOverride = "SWRATERC";
            /// <summary>
            /// Property for TaxReportingRateOverrideString 
            /// </summary>
            public const string TaxReportingRateOverrideString = "SWRATERC";
            /// <summary>
            /// Property for TaxReportingAmount1 
            /// </summary>
            public const string TaxReportingAmount1 = "TXAMT1RC";
            /// <summary>
            /// Property for TaxReportingAmount2 
            /// </summary>
            public const string TaxReportingAmount2 = "TXAMT2RC";
            /// <summary>
            /// Property for TaxReportingAmount3 
            /// </summary>
            public const string TaxReportingAmount3 = "TXAMT3RC";
            /// <summary>
            /// Property for TaxReportingAmount4 
            /// </summary>
            public const string TaxReportingAmount4 = "TXAMT4RC";
            /// <summary>
            /// Property for TaxReportingAmount5 
            /// </summary>
            public const string TaxReportingAmount5 = "TXAMT5RC";
            /// <summary>
            /// Property for TaxReportingTotal 
            /// </summary>
            public const string TaxReportingTotal = "TXTOTRC";
            /// <summary>
            /// Property for TaxReportingAllocatedTotal 
            /// </summary>
            public const string TaxReportingAllocatedTotal = "TXALLRC";
            /// <summary>
            /// Property for TaxReportingExpensedTotal 
            /// </summary>
            public const string TaxReportingExpensedTotal = "TXEXPRC";
            /// <summary>
            /// Property for TaxReportingRecoverableTotal 
            /// </summary>
            public const string TaxReportingRecoverableTotal = "TXRECRC";
            /// <summary>
            /// Property for TotalPrepayFuncCurr 
            /// </summary>
            public const string TotalPrepayFuncCurr = "AMTPPAYHC";
            /// <summary>
            /// Property for TotalDiscountFuncCurr 
            /// </summary>
            public const string TotalDiscountFuncCurr = "AMTDISCHC";
            /// <summary>
            /// Property for TotalReapplyRemainingFuncCu 
            /// </summary>
            public const string TotalReapplyRemainingFuncCu = "REMREAPLHC";
            /// <summary>
            /// Property for FuncTaxBase1 
            /// </summary>
            public const string FuncTaxBase1 = "TXBSE1HC";
            /// <summary>
            /// Property for FuncTaxBase2 
            /// </summary>
            public const string FuncTaxBase2 = "TXBSE2HC";
            /// <summary>
            /// Property for FuncTaxBase3 
            /// </summary>
            public const string FuncTaxBase3 = "TXBSE3HC";
            /// <summary>
            /// Property for FuncTaxBase4 
            /// </summary>
            public const string FuncTaxBase4 = "TXBSE4HC";
            /// <summary>
            /// Property for FuncTaxBase5 
            /// </summary>
            public const string FuncTaxBase5 = "TXBSE5HC";
            /// <summary>
            /// Property for FuncTaxAmount1 
            /// </summary>
            public const string FuncTaxAmount1 = "TXAMT1HC";
            /// <summary>
            /// Property for FuncTaxAmount2 
            /// </summary>
            public const string FuncTaxAmount2 = "TXAMT2HC";
            /// <summary>
            /// Property for FuncTaxAmount3 
            /// </summary>
            public const string FuncTaxAmount3 = "TXAMT3HC";
            /// <summary>
            /// Property for FuncTaxAmount4 
            /// </summary>
            public const string FuncTaxAmount4 = "TXAMT4HC";
            /// <summary>
            /// Property for FuncTaxAmount5 
            /// </summary>
            public const string FuncTaxAmount5 = "TXAMT5HC";
            /// <summary>
            /// Property for FuncTaxTotal 
            /// </summary>
            public const string FuncTaxTotal = "TXTOTHC";
            /// <summary>
            /// Property for FuncDistAmountNetofTaxes 
            /// </summary>
            public const string FuncDistAmountNetofTaxes = "AMTNETHC";
            /// <summary>
            /// Property for FuncTaxAllocatedTotal 
            /// </summary>
            public const string FuncTaxAllocatedTotal = "TXALLHC";
            /// <summary>
            /// Property for FuncTaxExpensedTotal 
            /// </summary>
            public const string FuncTaxExpensedTotal = "TXEXPHC";
            /// <summary>
            /// Property for FuncTaxRecoverableTotal 
            /// </summary>
            public const string FuncTaxRecoverableTotal = "TXRECHC";
            /// <summary>
            /// Property for AOrPVersionCreatedIn 
            /// </summary>
            public const string AOrPVersionCreatedIn = "APVERSION";
            /// <summary>
            /// Property for NumberofAdvanceCreditClaims 
            /// </summary>
            public const string NumberofAdvanceCreditClaims = "CNTACC";
            /// <summary>
            /// Property for TotalAdvanceCreditClaim 
            /// </summary>
            public const string TotalAdvanceCreditClaim = "AMTACCTC";
            /// <summary>
            /// Property for FuncTotalAdvanceCreditClaim 
            /// </summary>
            public const string FuncTotalAdvanceCreditClaim = "AMTACCHC";
            /// <summary>
            /// Property for EnteredBy 
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";
            /// <summary>
            /// Property for PostingDate 
            /// </summary>
            public const string PostingDate = "DATEBUS";
            /// <summary>
            /// Property for AccountSet 
            /// </summary>
            public const string AccountSet = "IDACCTSET";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHT1TC = "AMTWHT1TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHT2TC = "AMTWHT2TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHT3TC = "AMTWHT3TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHT4TC = "AMTWHT4TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHT5TC = "AMTWHT5TC";

            /// <summary>
            /// Property for Reverse Charges Base 1
            /// </summary>
            public const string AmtCXBS1TC = "AMTCXBS1TC";

            /// <summary>
            /// Property for Reverse Charges Base 2
            /// </summary>
            public const string AmtCXBS2TC = "AMTCXBS2TC";

            /// <summary>
            /// Property for Reverse Charges Base 3
            /// </summary>
            public const string AmtCXBS3TC = "AMTCXBS3TC";

            /// <summary>
            /// Property for Reverse Charges Base 4
            /// </summary>
            public const string AmtCXBS4TC = "AMTCXBS4TC";
            /// <summary>
            /// Property for Reverse Charges Base 5
            /// </summary>
            public const string AmtCXBS5TC = "AMTCXBS5TC";

            /// <summary>
            /// Property for Reverse Charges Amount 1
            /// </summary>
            public const string AmtCXTX1TC = "AMTCXTX1TC";

            /// <summary>
            /// Property for Reverse Charges Amount 2
            /// </summary>
            public const string AmtCXTX2TC = "AMTCXTX2TC";

            /// <summary>
            /// Property for Reverse Charges Amount 3
            /// </summary>
            public const string AmtCXTX3TC = "AMTCXTX3TC";

            /// <summary>
            /// Property for Reverse Charges Amount 4
            /// </summary>
            public const string AmtCXTX4TC = "AMTCXTX4TC";

            /// <summary>
            /// Property for Reverse Charges Amount 5
            /// </summary>
            public const string AmtCXTX5TC = "AMTCXTX5TC";

            /// <summary>
            /// Property for Misc Payment Document Total
            /// </summary>
            public const string AmtTGROSDST = "AMTTGROSDST";

            #endregion
        }


        /// <summary>
        /// Contains list of PaymentsAdjustments Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 3;
            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int CheckNumber = 4;
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 5;
            /// <summary>
            /// Property Indexer for PaymentDateOrAdjustmentDate 
            /// </summary>
            public const int PaymentDateOrAdjustmentDate = 6;
            /// <summary>
            /// Property Indexer for EntryDescription 
            /// </summary>
            public const int EntryDescription = 7;
            /// <summary>
            /// Property Indexer for VendorOrPayeeName 
            /// </summary>
            public const int VendorOrPayeeName = 8;
            /// <summary>
            /// Property Indexer for CheckAmountinBankCurr 
            /// </summary>
            public const int CheckAmountinBankCurr = 9;
            /// <summary>
            /// Property Indexer for CheckAmountinVendorCurr 
            /// </summary>
            public const int CheckAmountinVendorCurr = 10;
            /// <summary>
            /// Property Indexer for VendorExchangeRate 
            /// </summary>
            public const int VendorExchangeRate = 11;
            /// <summary>
            /// Property Indexer for VendorRateOverridden 
            /// </summary>
            public const int VendorRateOverridden = 12;
            /// <summary>
            /// Property Indexer for NumberofPaymentsEntered 
            /// </summary>
            public const int NumberofPaymentsEntered = 13;
            /// <summary>
            /// Property Indexer for TotalPrepayVendorCurr 
            /// </summary>
            public const int TotalPrepayVendorCurr = 14;
            /// <summary>
            /// Property Indexer for TotalDiscountVendorCurr 
            /// </summary>
            public const int TotalDiscountVendorCurr = 15;
            /// <summary>
            /// Property Indexer for PaymentCode 
            /// </summary>
            public const int PaymentCode = 16;
            /// <summary>
            /// Property Indexer for VendorCurrencyCode 
            /// </summary>
            public const int VendorCurrencyCode = 17;
            /// <summary>
            /// Property Indexer for BankRateType 
            /// </summary>
            public const int BankRateType = 18;
            /// <summary>
            /// Property Indexer for BankExchangeRate 
            /// </summary>
            public const int BankExchangeRate = 19;
            /// <summary>
            /// Property Indexer for BankRateOverridden 
            /// </summary>
            public const int BankRateOverridden = 20;
            /// <summary>
            /// Property Indexer for PaymentTransType 
            /// </summary>
            public const int PaymentTransType = 21;
            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 22;
            /// <summary>
            /// Property Indexer for LastLineNumber 
            /// </summary>
            public const int LastLineNumber = 23;
            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 24;
            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 25;
            /// <summary>
            /// Property Indexer for VendorRateDate 
            /// </summary>
            public const int VendorRateDate = 26;
            /// <summary>
            /// Property Indexer for VendorRateType 
            /// </summary>
            public const int VendorRateType = 27;
            /// <summary>
            /// Property Indexer for TotalPaymentAdjVendorCurr 
            /// </summary>
            public const int TotalPaymentAdjVendorCurr = 28;
            /// <summary>
            /// Property Indexer for BankRateDate 
            /// </summary>
            public const int BankRateDate = 29;
            /// <summary>
            /// Property Indexer for TotalReapplyRemainingVendorC 
            /// </summary>
            public const int TotalReapplyRemainingVendorC = 30;
            /// <summary>
            /// Property Indexer for AdjDebitAmtFuncCurr 
            /// </summary>
            public const int AdjDebitAmtFuncCurr = 31;
            /// <summary>
            /// Property Indexer for CheckAmountFuncCurr 
            /// </summary>
            public const int CheckAmountFuncCurr = 32;
            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 33;
            /// <summary>
            /// Property Indexer for PaymentEdited 
            /// </summary>
            public const int PaymentEdited = 34;
            /// <summary>
            /// Property Indexer for CheckPrintRequired 
            /// </summary>
            public const int CheckPrintRequired = 35;
            /// <summary>
            /// Property Indexer for VendorRemitToLocation 
            /// </summary>
            public const int VendorRemitToLocation = 36;
            /// <summary>
            /// Property Indexer for EntryReference 
            /// </summary>
            public const int EntryReference = 37;
            /// <summary>
            /// Property Indexer for AdjCreditAmtFuncCurr 
            /// </summary>
            public const int AdjCreditAmtFuncCurr = 39;
            /// <summary>
            /// Property Indexer for TotalAdjAmtFuncCurr 
            /// </summary>
            public const int TotalAdjAmtFuncCurr = 40;
            /// <summary>
            /// Property Indexer for CheckSequenceNo 
            /// </summary>
            public const int CheckSequenceNo = 41;
            /// <summary>
            /// Property Indexer for CheckPrintedStatus 
            /// </summary>
            public const int CheckPrintedStatus = 42;
            /// <summary>
            /// Property Indexer for AddressLine1 
            /// </summary>
            public const int AddressLine1 = 43;
            /// <summary>
            /// Property Indexer for AddressLine2 
            /// </summary>
            public const int AddressLine2 = 44;
            /// <summary>
            /// Property Indexer for AddressLine3 
            /// </summary>
            public const int AddressLine3 = 45;
            /// <summary>
            /// Property Indexer for AddressLine4 
            /// </summary>
            public const int AddressLine4 = 46;
            /// <summary>
            /// Property Indexer for City 
            /// </summary>
            public const int City = 47;
            /// <summary>
            /// Property Indexer for State 
            /// </summary>
            public const int State = 48;
            /// <summary>
            /// Property Indexer for ZipOrPostalCode 
            /// </summary>
            public const int ZipOrPostalCode = 49;
            /// <summary>
            /// Property Indexer for Country 
            /// </summary>
            public const int Country = 50;
            /// <summary>
            /// Property Indexer for PaymentLanguage 
            /// </summary>
            public const int PaymentLanguage = 51;
            /// <summary>
            /// Property Indexer for BankRateOperator 
            /// </summary>
            public const int BankRateOperator = 52;
            /// <summary>
            /// Property Indexer for VendorRateOperator 
            /// </summary>
            public const int VendorRateOperator = 53;
            /// <summary>
            /// Property Indexer for AdjDebitAmtVendorCurr 
            /// </summary>
            public const int AdjDebitAmtVendorCurr = 54;
            /// <summary>
            /// Property Indexer for AdjCreditAmtVendorCurr 
            /// </summary>
            public const int AdjCreditAmtVendorCurr = 55;
            /// <summary>
            /// Property Indexer for PrepayActivationDate 
            /// </summary>
            public const int PrepayActivationDate = 56;
            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 57;
            /// <summary>
            /// Property Indexer for JobApplyMethod 
            /// </summary>
            public const int JobApplyMethod = 58;
            /// <summary>
            /// Property Indexer for ErrorBatch 
            /// </summary>
            public const int ErrorBatch = 59;
            /// <summary>
            /// Property Indexer for ErrorEntry 
            /// </summary>
            public const int ErrorEntry = 60;
            /// <summary>
            /// Property Indexer for MatchingDocumentNumber 
            /// </summary>
            public const int MatchingDocumentNumber = 61;
            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 62;
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 63;
            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 64;
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 65;
            /// <summary>
            /// Property Indexer for BankCurrencyCode 
            /// </summary>
            public const int BankCurrencyCode = 66;
            /// <summary>
            /// Property Indexer for PaymentType 
            /// </summary>
            public const int PaymentType = 67;
            /// <summary>
            /// Property Indexer for CashAccount 
            /// </summary>
            public const int CashAccount = 73;
            /// <summary>
            /// Property Indexer for DrillDownApplicationSource 
            /// </summary>
            public const int DrillDownApplicationSource = 74;
            /// <summary>
            /// Property Indexer for DrillDownType 
            /// </summary>
            public const int DrillDownType = 75;
            /// <summary>
            /// Property Indexer for DrillDownLinkNumber 
            /// </summary>
            public const int DrillDownLinkNumber = 76;
            /// <summary>
            /// Property Indexer for Num1099OrCPRSCode 
            /// </summary>
            public const int Num1099OrCPRSCode = 77;
            /// <summary>
            /// Property Indexer for Num1099OrCPRSAmount 
            /// </summary>
            public const int Num1099OrCPRSAmount = 78;
            /// <summary>
            /// Property Indexer for CalculateTaxAmountControl 
            /// </summary>
            public const int CalculateTaxAmountControl = 79;
            /// <summary>
            /// Property Indexer for CalculateTaxBaseControl 
            /// </summary>
            public const int CalculateTaxBaseControl = 80;
            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroup = 81;
            /// <summary>
            /// Property Indexer for TaxStateVersion 
            /// </summary>
            public const int TaxStateVersion = 82;
            /// <summary>
            /// Property Indexer for TaxAuthority1 
            /// </summary>
            public const int TaxAuthority1 = 83;
            /// <summary>
            /// Property Indexer for TaxAuthority2 
            /// </summary>
            public const int TaxAuthority2 = 84;
            /// <summary>
            /// Property Indexer for TaxAuthority3 
            /// </summary>
            public const int TaxAuthority3 = 85;
            /// <summary>
            /// Property Indexer for TaxAuthority4 
            /// </summary>
            public const int TaxAuthority4 = 86;
            /// <summary>
            /// Property Indexer for TaxAuthority5 
            /// </summary>
            public const int TaxAuthority5 = 87;
            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 88;
            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 89;
            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 90;
            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 91;
            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 92;
            /// <summary>
            /// Property Indexer for TaxIncluded1 
            /// </summary>
            public const int TaxIncluded1 = 93;
            /// <summary>
            /// Property Indexer for TaxIncluded2 
            /// </summary>
            public const int TaxIncluded2 = 94;
            /// <summary>
            /// Property Indexer for TaxIncluded3 
            /// </summary>
            public const int TaxIncluded3 = 95;
            /// <summary>
            /// Property Indexer for TaxIncluded4 
            /// </summary>
            public const int TaxIncluded4 = 96;
            /// <summary>
            /// Property Indexer for TaxIncluded5 
            /// </summary>
            public const int TaxIncluded5 = 97;
            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 98;
            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 99;
            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 100;
            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 101;
            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 102;
            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 103;
            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 104;
            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 105;
            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 106;
            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 107;
            /// <summary>
            /// Property Indexer for TaxTotal 
            /// </summary>
            public const int TaxTotal = 108;
            /// <summary>
            /// Property Indexer for DistAmountNetofTaxes 
            /// </summary>
            public const int DistAmountNetofTaxes = 109;
            /// <summary>
            /// Property Indexer for TaxAllocatedTotal 
            /// </summary>
            public const int TaxAllocatedTotal = 110;
            /// <summary>
            /// Property Indexer for TaxExpensedTotal 
            /// </summary>
            public const int TaxExpensedTotal = 111;
            /// <summary>
            /// Property Indexer for TaxRecoverableTotal 
            /// </summary>
            public const int TaxRecoverableTotal = 112;
            /// <summary>
            /// Property Indexer for TaxReportingCurrencyCode 
            /// </summary>
            public const int TaxReportingCurrencyCode = 113;
            /// <summary>
            /// Property Indexer for TaxReportingCalculateMethod 
            /// </summary>
            public const int TaxReportingCalculateMethod = 114;
            /// <summary>
            /// Property Indexer for TaxReportingExchangeRate 
            /// </summary>
            public const int TaxReportingExchangeRate = 115;
            /// <summary>
            /// Property Indexer for TaxReportingRateType 
            /// </summary>
            public const int TaxReportingRateType = 116;
            /// <summary>
            /// Property Indexer for TaxReportingRateDate 
            /// </summary>
            public const int TaxReportingRateDate = 117;
            /// <summary>
            /// Property Indexer for TaxReportingRateOperator 
            /// </summary>
            public const int TaxReportingRateOperator = 118;
            /// <summary>
            /// Property Indexer for TaxReportingRateOverride 
            /// </summary>
            public const int TaxReportingRateOverride = 119;
            /// <summary>
            /// Property Indexer for TaxReportingAmount1 
            /// </summary>
            public const int TaxReportingAmount1 = 120;
            /// <summary>
            /// Property Indexer for TaxReportingAmount2 
            /// </summary>
            public const int TaxReportingAmount2 = 121;
            /// <summary>
            /// Property Indexer for TaxReportingAmount3 
            /// </summary>
            public const int TaxReportingAmount3 = 122;
            /// <summary>
            /// Property Indexer for TaxReportingAmount4 
            /// </summary>
            public const int TaxReportingAmount4 = 123;
            /// <summary>
            /// Property Indexer for TaxReportingAmount5 
            /// </summary>
            public const int TaxReportingAmount5 = 124;
            /// <summary>
            /// Property Indexer for TaxReportingTotal 
            /// </summary>
            public const int TaxReportingTotal = 125;
            /// <summary>
            /// Property Indexer for TaxReportingAllocatedTotal 
            /// </summary>
            public const int TaxReportingAllocatedTotal = 126;
            /// <summary>
            /// Property Indexer for TaxReportingExpensedTotal 
            /// </summary>
            public const int TaxReportingExpensedTotal = 127;
            /// <summary>
            /// Property Indexer for TaxReportingRecoverableTotal 
            /// </summary>
            public const int TaxReportingRecoverableTotal = 128;
            /// <summary>
            /// Property Indexer for TotalPrepayFuncCurr 
            /// </summary>
            public const int TotalPrepayFuncCurr = 130;
            /// <summary>
            /// Property Indexer for TotalDiscountFuncCurr 
            /// </summary>
            public const int TotalDiscountFuncCurr = 131;
            /// <summary>
            /// Property Indexer for TotalReapplyRemainingFuncCu 
            /// </summary>
            public const int TotalReapplyRemainingFuncCu = 132;
            /// <summary>
            /// Property Indexer for FuncTaxBase1 
            /// </summary>
            public const int FuncTaxBase1 = 133;
            /// <summary>
            /// Property Indexer for FuncTaxBase2 
            /// </summary>
            public const int FuncTaxBase2 = 134;
            /// <summary>
            /// Property Indexer for FuncTaxBase3 
            /// </summary>
            public const int FuncTaxBase3 = 135;
            /// <summary>
            /// Property Indexer for FuncTaxBase4 
            /// </summary>
            public const int FuncTaxBase4 = 136;
            /// <summary>
            /// Property Indexer for FuncTaxBase5 
            /// </summary>
            public const int FuncTaxBase5 = 137;
            /// <summary>
            /// Property Indexer for FuncTaxAmount1 
            /// </summary>
            public const int FuncTaxAmount1 = 138;
            /// <summary>
            /// Property Indexer for FuncTaxAmount2 
            /// </summary>
            public const int FuncTaxAmount2 = 139;
            /// <summary>
            /// Property Indexer for FuncTaxAmount3 
            /// </summary>
            public const int FuncTaxAmount3 = 140;
            /// <summary>
            /// Property Indexer for FuncTaxAmount4 
            /// </summary>
            public const int FuncTaxAmount4 = 141;
            /// <summary>
            /// Property Indexer for FuncTaxAmount5 
            /// </summary>
            public const int FuncTaxAmount5 = 142;
            /// <summary>
            /// Property Indexer for FuncTaxTotal 
            /// </summary>
            public const int FuncTaxTotal = 143;
            /// <summary>
            /// Property Indexer for FuncDistAmountNetofTaxes 
            /// </summary>
            public const int FuncDistAmountNetofTaxes = 144;
            /// <summary>
            /// Property Indexer for FuncTaxAllocatedTotal 
            /// </summary>
            public const int FuncTaxAllocatedTotal = 145;
            /// <summary>
            /// Property Indexer for FuncTaxExpensedTotal 
            /// </summary>
            public const int FuncTaxExpensedTotal = 146;
            /// <summary>
            /// Property Indexer for FuncTaxRecoverableTotal 
            /// </summary>
            public const int FuncTaxRecoverableTotal = 147;
            /// <summary>
            /// Property Indexer for AOrPVersionCreatedIn 
            /// </summary>
            public const int AOrPVersionCreatedIn = 148;
            /// <summary>
            /// Property Indexer for NumberofAdvanceCreditClaims 
            /// </summary>
            public const int NumberofAdvanceCreditClaims = 149;
            /// <summary>
            /// Property Indexer for TotalAdvanceCreditClaim 
            /// </summary>
            public const int TotalAdvanceCreditClaim = 150;
            /// <summary>
            /// Property Indexer for FuncTotalAdvanceCreditClaim 
            /// </summary>
            public const int FuncTotalAdvanceCreditClaim = 151;
            /// <summary>
            /// Property Indexer for EnteredBy 
            /// </summary>
            public const int EnteredBy = 152;
            /// <summary>
            /// Property Indexer for PostingDate 
            /// </summary>
            public const int PostingDate = 153;
            /// <summary>
            /// Property Indexer for AccountSet 
            /// </summary>
            public const int AccountSet = 154;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHT1TC = 155;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHT2TC = 156;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHT3TC = 157;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHT4TC = 158;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHT5TC = 159;

            /// <summary>
            /// Indexer for Reverse Charges Base 1
            /// </summary>
            public const int AmtCXBS1TC = 160;

            /// <summary>
            /// Indexer for Reverse Charges Base 2
            /// </summary>
            public const int AmtCXBS2TC = 161;

            /// <summary>
            /// Indexer for Reverse Charges Base 3
            /// </summary>
            public const int AmtCXBS3TC = 162;

            /// <summary>
            /// Indexer for Reverse Charges Base 4
            /// </summary>
            public const int AmtCXBS4TC = 163;
            /// <summary>
            /// Indexer for Reverse Charges Base 5
            /// </summary>
            public const int AmtCXBS5TC = 164;

            /// <summary>
            /// Indexer for Reverse Charges Amount 1
            /// </summary>
            public const int AmtCXTX1TC = 165;

            /// <summary>
            /// Indexer for Reverse Charges Amount 2
            /// </summary>
            public const int AmtCXTX2TC = 166;

            /// <summary>
            /// Indexer for Reverse Charges Amount 3
            /// </summary>
            public const int AmtCXTX3TC = 167;

            /// <summary>
            /// Indexer for Reverse Charges Amount 4
            /// </summary>
            public const int AmtCXTX4TC = 168;

            /// <summary>
            /// Indexer for Reverse Charges Amount 5
            /// </summary>
            public const int AmtCXTX5TC = 169;

            /// <summary>
            /// Indexer for Misc Payment Document Total
            /// </summary>
            public const int AmtTGROSDST = 170;

            #endregion
        }


    }
}
