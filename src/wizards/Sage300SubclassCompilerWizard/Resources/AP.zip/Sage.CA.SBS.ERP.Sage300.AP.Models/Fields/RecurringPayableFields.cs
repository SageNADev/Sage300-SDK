// Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of Recurring Payables Constants 
    /// </summary>
    public partial class RecurringPayable
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0064";

        /// <summary>
        /// EntityName for Export/Import
        /// </summary>
        public const string EntityName = "AP0064";

        /// <summary>
        /// Contains list of Recurring Payables Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for Vendor Number 
            /// </summary>
            public const string VendorNumber = "IDVEND";

            /// <summary>
            /// Property for Recurring Payable Code 
            /// </summary>
            public const string RecurringPayableCode = "IDRECURR";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "SWACTV";


            /// <summary>
            /// Property for Status in Finder
            /// </summary>
            public const string StatusDescription = "SWACTV";

            /// <summary>
            /// Property for Inactive Date 
            /// </summary>
            public const string InactiveDate = "DATEINACTV";

            /// <summary>
            /// Property for Inactive Date for Finder
            /// </summary>
            public const string InactiveDateDesc = "DATEINACTV";

            /// <summary>
            /// Property for Date Last Maintained 
            /// </summary>
            public const string DateLastMaintained = "DATELSTMTN";

            /// <summary>
            /// Property for Date Last Maintained for finder
            /// </summary>
            public const string DateLastMaintainedDesc = "DATELSTMTN";

            /// <summary>
            /// Property for Effective Date 
            /// </summary>
            public const string EffectiveDate = "DATEEFF";

            /// <summary>
            /// Property for Effective Date 
            /// </summary>
            public const string EffectiveDateDesc = "DATEEFF";

            /// <summary>
            /// Property for Expiration Type 
            /// </summary>
            public const string ExpirationType = "EXPIRETYPE";

            /// <summary>
            /// Property for Expiration Type 
            /// </summary>
            public const string ExpirationTypeDesc = "EXPIRETYPE";


            /// <summary>
            /// Property for Expiration Date 
            /// </summary>
            public const string ExpirationDate = "DATEEXPIRE";

            /// <summary>
            /// Property for Expiration Date 
            /// </summary>
            public const string ExpirationDateDesc = "DATEEXPIRE";

            /// <summary>
            /// Property for MaximumNumber of Invoices 
            /// </summary>
            public const string MaximumNumberofInvoices = "MAXCOUNT";

            /// <summary>
            /// Property for Maximum Total Invoice Amount 
            /// </summary>
            public const string MaximumTotalInvoiceAmount = "MAXAMT";

            /// <summary>
            /// Property for Last Invoice Date Posted 
            /// </summary>
            public const string LastInvoiceDatePosted = "LASTDATE";


            /// <summary>
            /// Property for Last Invoice Date Posted 
            /// </summary>
            public const string LastInvoiceDatePostedDesc = "LASTDATE";

            /// <summary>
            /// Property for Last Invoice Amount Posted 
            /// </summary>
            public const string LastInvoiceAmountPosted = "LASTAMT";

            /// <summary>
            /// Property for YTD Number of Invoices 
            /// </summary>
            public const string YearToDateNumberofInvoices = "YTDCOUNT";

            /// <summary>
            /// Property for YTD Total Invoice Amount 
            /// </summary>
            public const string YearToDateTotalInvoiceAmount = "YTDAMT";

            /// <summary>
            /// Property for Order Number 
            /// </summary>
            public const string OrderNumber = "ORDERNBR";

            /// <summary>
            /// Property for PO Number 
            /// </summary>
            public const string PONumber = "PONBR";

            /// <summary>
            /// Property for Invoice Description 
            /// </summary>
            public const string InvoiceDescription = "INVCDESC";

            /// <summary>
            /// Property for Remit To Location 
            /// </summary>
            public const string RemitToLocation = "IDRMITTO";

            /// <summary>
            /// Property for Currency Code 
            /// </summary>
            public const string CurrencyCode = "CODECURN";

            /// <summary>
            /// Property for Rate Type 
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for Terms 
            /// </summary>
            public const string Terms = "TERMSCODE";

            /// <summary>
            /// Property for Distribution Set 
            /// </summary>
            public const string DistributionSet = "IDDISTSET";

            /// <summary>
            /// Property for Distribution Amount 
            /// </summary>
            public const string DistributionAmount = "AMTDISTSET";

            /// <summary>
            /// Property for Tax Group 
            /// </summary>
            public const string TaxGroup = "TAXGRP";

            /// <summary>
            /// Property for Tax Amount Control 
            /// </summary>
            public const string TaxAmountControl = "SWCALCTAX";


            /// <summary>
            /// Property for Tax Amount Control Desc for finder 
            /// </summary>
            public const string TaxAmountControlDesc = "SWCALCTAX";


            /// <summary>
            /// Property for Tax Authority 1 
            /// </summary>
            public const string TaxAuthority1 = "TAXAUTH1";

            /// <summary>
            /// Property for Tax Authority 2 
            /// </summary>
            public const string TaxAuthority2 = "TAXAUTH2";

            /// <summary>
            /// Property for Tax Authority 3 
            /// </summary>
            public const string TaxAuthority3 = "TAXAUTH3";
            /// <summary>
            /// Property for Tax Authority 4 
            /// </summary>
            public const string TaxAuthority4 = "TAXAUTH4";

            /// <summary>
            /// Property for Tax Authority 5 
            /// </summary>
            public const string TaxAuthority5 = "TAXAUTH5";

            /// <summary>
            /// Property for Tax Class 1 
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for Tax Class 2 
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for Tax Class 3 
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for Tax Class 4 
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for Tax Class 5 
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for Tax Inclusive 1 
            /// </summary>
            public const string TaxInclusive1 = "SWTAXINCL1";

            /// <summary>
            /// Property for Tax Inclusive 1 for finder 
            /// </summary>
            public const string TaxInclusive1Desc = "SWTAXINCL1";

            /// <summary>
            /// Property for Tax Inclusive 2 
            /// </summary>
            public const string TaxInclusive2 = "SWTAXINCL2";

            /// <summary>
            /// Property for Tax Inclusive 2 for finder 
            /// </summary>
            public const string TaxInclusive2Desc = "SWTAXINCL2";

            /// <summary>
            /// Property for Tax Inclusive 3 
            /// </summary>
            public const string TaxInclusive3 = "SWTAXINCL3";

            /// <summary>
            /// Property for Tax Inclusive 3 for finder 
            /// </summary>
            public const string TaxInclusive3Desc = "SWTAXINCL3";

            /// <summary>
            /// Property for Tax Inclusive 4 
            /// </summary>
            public const string TaxInclusive4 = "SWTAXINCL4";

            /// <summary>
            /// Property for TaxInclusive4 for finder 
            /// </summary>
            public const string TaxInclusive4Desc = "SWTAXINCL4";

            /// <summary>
            /// Property for Tax Inclusive 5 
            /// </summary>
            public const string TaxInclusive5 = "SWTAXINCL5";

            /// <summary>
            /// Property for Tax Inclusive 5 for finder 
            /// </summary>
            public const string TaxInclusive5Desc = "SWTAXINCL5";

            /// <summary>
            /// Property for Tax Amount1 
            /// </summary>
            public const string TaxAmount1 = "AMTTAX1";

            /// <summary>
            /// Property for Tax Amount2 
            /// </summary>
            public const string TaxAmount2 = "AMTTAX2";

            /// <summary>
            /// Property for Tax Amount3 
            /// </summary>
            public const string TaxAmount3 = "AMTTAX3";

            /// <summary>
            /// Property for Tax Amount4 
            /// </summary>
            public const string TaxAmount4 = "AMTTAX4";

            /// <summary>
            /// Property for Tax Amount5 
            /// </summary>
            public const string TaxAmount5 = "AMTTAX5";

            /// <summary>
            /// Property for DistributedTotalBeforeTaxes 
            /// </summary>
            public const string DistributedTotalBeforeTaxes = "AMTDISTNET";

            /// <summary>
            /// Property for Invoice Subtotal 
            /// </summary>
            public const string InvoiceSubtotal = "AMTDIST";

            /// <summary>
            /// Property for Num1099 Or CPRSCode 
            /// </summary>
            public const string Num1099OrCprsCode = "CODE1099";

            /// <summary>
            /// Property for Num1099 Or CPRSAmount 
            /// </summary>
            public const string Num1099OrCprsAmount = "AMT1099";

            /// <summary>
            /// Property for Last Detail SeqNo 
            /// </summary>
            public const string LastDetailSeqNo = "LASTLINE";

            /// <summary>
            /// Property for Schedule 
            /// </summary>
            public const string Schedule = "SCHEDKEY";

            /// <summary>
            /// Property for Schedule Link 
            /// </summary>
            public const string ScheduleLink = "SCHEDLINK";

            /// <summary>
            /// Property for Document Total 
            /// </summary>
            public const string DocumentTotal = "AMTTOTAL";

            /// <summary>
            /// Property for Tax Base1 
            /// </summary>
            public const string TaxBase1 = "BASETAX1";

            /// <summary>
            /// Property for Tax Base2 
            /// </summary>
            public const string TaxBase2 = "BASETAX2";

            /// <summary>
            /// Property for Tax Base3 
            /// </summary>
            public const string TaxBase3 = "BASETAX3";

            /// <summary>
            /// Property for Tax Base4 
            /// </summary>
            public const string TaxBase4 = "BASETAX4";

            /// <summary>
            /// Property for Tax Base5 
            /// </summary>
            public const string TaxBase5 = "BASETAX5";

            /// <summary>
            /// Property for InvoiceTaxable 
            /// </summary>
            public const string InvoiceTaxable = "SWTAXBL";

            /// <summary>
            /// Property for InvoiceTaxable 
            /// </summary>
            public const string InvoiceTaxableDesc = "SWTAXBL";

            /// <summary>
            /// Property for Tax Base Control 
            /// </summary>
            public const string TaxBaseControl = "SWTXBSECTL";

            /// <summary>
            /// Property for Tax Base Control 
            /// </summary>
            public const string TaxBaseControlDesc = "SWTXBSECTL";

            /// <summary>
            /// Property for Total Dist Tax incl in Price 
            /// </summary>
            public const string TotalDistTaxinclinPrice = "AMTTAXINCL";

            /// <summary>
            /// Property for Total Dist Tax excl from Price 
            /// </summary>
            public const string TotalDistTaxexclfromPrice = "AMTTAXEXCL";

            /// <summary>
            /// Property for Total Tax Amount 
            /// </summary>
            public const string TotalTaxAmount = "AMTTAXTOT";

            /// <summary>
            /// Property for Optional Fields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for Process Command 
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Property for Process Command 
            /// </summary>
            public const string ProcessCommandDesc = "PROCESSCMD";

            /// <summary>
            /// Property for Job Related 
            /// </summary>
            public const string JobRelated = "SWJOB";

            /// <summary>
            /// Property for Job Related 
            /// </summary>
            //public const string JobRelatedString = "SWJOB";

            /// <summary>
            /// Property for Next Scheduled Date 
            /// </summary>
            public const string NextScheduledDate = "DATENEXT";

            /// <summary>
            /// Property for Next Scheduled Date 
            /// </summary>
            public const string NextScheduledDateDesc = "DATENEXT";

            /// <summary>
            /// Property for Last Invoice Date Generated 
            /// </summary>
            public const string LastInvoiceDateGenerated = "DATELSTGEN";

            /// <summary>
            /// Property for Last Invoice Date Generated 
            /// </summary>
            public const string LastInvoiceDateGeneratedDesc = "DATELSTGEN";

            /// <summary>
            /// Property for Unposted Number of Invoices 
            /// </summary>
            public const string UnpostedNumberofInvoices = "OPENCOUNT";

            /// <summary>
            /// Property for Unposted Total Invoice Amount 
            /// </summary>
            public const string UnpostedTotalInvoiceAmount = "OPENAMOUNT";

            /// <summary>
            /// Property for Posted Number of Invoices 
            /// </summary>
            public const string PostedNumberofInvoices = "POSTCOUNT";

            /// <summary>
            /// Property for Posted Total Invoice Amount 
            /// </summary>
            public const string PostedTotalInvoiceAmount = "POSTAMOUNT";

            /// <summary>
            /// Property for Last Invoice Number Posted 
            /// </summary>
            public const string LastInvoiceNumberPosted = "LSTIDINVC";

            /// <summary>
            /// Property for Last Batch Number Posted 
            /// </summary>
            public const string LastBatchNumberPosted = "LSTCNTBTCH";

            /// <summary>
            /// Property for Last Entry Number Posted 
            /// </summary>
            public const string LastEntryNumberPosted = "LSTCNTITEM";

            /// <summary>
            /// Property for Last Posting Sequence Number 
            /// </summary>
            public const string LastPostingSequenceNumber = "LSTPOSTSEQ";

            /// <summary>
            /// Property for Account Set 
            /// </summary>
            public const string AccountSet = "IDACCTSET";

            #endregion
        }

        /// <summary>
        /// Contains list of Recurring Payables Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Vendor Number 
            /// </summary>
            public const int VendorNumber = 1;

            /// <summary>
            /// Property Indexer for Recurring PayableCode 
            /// </summary>
            public const int RecurringPayableCode = 2;
            
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 4;

            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 5;

            /// <summary>
            /// Property Indexer for Date Last Maintained 
            /// </summary>
            public const int DateLastMaintained = 6;

            /// <summary>
            /// Property Indexer for Effective Date 
            /// </summary>
            public const int EffectiveDate = 7;

            /// <summary>
            /// Property Indexer for Expiration Type 
            /// </summary>
            public const int ExpirationType = 8;

            /// <summary>
            /// Property Indexer for Expiration Date 
            /// </summary>
            public const int ExpirationDate = 9;

            /// <summary>
            /// Property Indexer for Maximum Number of Invoices 
            /// </summary>
            public const int MaximumNumberofInvoices = 10;

            /// <summary>
            /// Property Indexer for Maximum Total Invoice Amount 
            /// </summary>
            public const int MaximumTotalInvoiceAmount = 11;

            /// <summary>
            /// Property Indexer for LastInvoiceDatePosted 
            /// </summary>
            public const int LastInvoiceDatePosted = 12;

            /// <summary>
            /// Property Indexer for Last Invoice Amount Posted 
            /// </summary>
            public const int LastInvoiceAmountPosted = 13;

            /// <summary>
            /// Property Indexer for YTD Number of Invoices 
            /// </summary>
            public const int YearToDateNumberofInvoices = 14;

            /// <summary>
            /// Property Indexer for YTD Total Invoice Amount 
            /// </summary>
            public const int YearToDateTotalInvoiceAmount = 15;

            /// <summary>
            /// Property Indexer for Order Number 
            /// </summary>
            public const int OrderNumber = 16;

            /// <summary>
            /// Property Indexer for PO Number 
            /// </summary>
            public const int PONumber = 17;

            /// <summary>
            /// Property Indexer for Invoice Description 
            /// </summary>
            public const int InvoiceDescription = 18;

            /// <summary>
            /// Property Indexer for Remit To Location 
            /// </summary>
            public const int RemitToLocation = 19;

            /// <summary>
            /// Property Indexer for Currency Code 
            /// </summary>
            public const int CurrencyCode = 20;

            /// <summary>
            /// Property Indexer for Rate Type 
            /// </summary>
            public const int RateType = 21;

            /// <summary>
            /// Property Indexer for Terms 
            /// </summary>
            public const int Terms = 22;
            /// <summary>
            /// Property Indexer for Distribution Set 
            /// </summary>
            public const int DistributionSet = 24;

            /// <summary>
            /// Property Indexer for Distribution Amount 
            /// </summary>
            public const int DistributionAmount = 25;

            /// <summary>
            /// Property Indexer for Tax Group 
            /// </summary>
            public const int TaxGroup = 26;
            /// <summary>
            /// Property Indexer for TaxAmount Control 
            /// </summary>
            public const int TaxAmountControl = 27;

            /// <summary>
            /// Property Indexer for Tax Authority 1 
            /// </summary>
            public const int TaxAuthority1 = 36;

            /// <summary>
            /// Property Indexer for Tax Authority 2 
            /// </summary>
            public const int TaxAuthority2 = 37;

            /// <summary>
            /// Property Indexer for Tax Authority 3 
            /// </summary>
            public const int TaxAuthority3 = 38;

            /// <summary>
            /// Property Indexer for Tax Authority 4 
            /// </summary>
            public const int TaxAuthority4 = 39;

            /// <summary>
            /// Property Indexer for Tax Authority 5 
            /// </summary>
            public const int TaxAuthority5 = 40;

            /// <summary>
            /// Property Indexer for Tax Class 1 
            /// </summary>
            public const int TaxClass1 = 41;

            /// <summary>
            /// Property Indexer for Tax Class 2 
            /// </summary>
            public const int TaxClass2 = 42;

            /// <summary>
            /// Property Indexer for Tax Class 3 
            /// </summary>
            public const int TaxClass3 = 43;

            /// <summary>
            /// Property Indexer for Ta xClass 4 
            /// </summary>
            public const int TaxClass4 = 44;

            /// <summary>
            /// Property Indexer for Tax Class 5 
            /// </summary>
            public const int TaxClass5 = 45;

            /// <summary>
            /// Property Indexer for Tax Inclusive 1 
            /// </summary>
            public const int TaxInclusive1 = 46;

            /// <summary>
            /// Property Indexer for Tax Inclusive 2 
            /// </summary>
            public const int TaxInclusive2 = 47;

            /// <summary>
            /// Property Indexer for Tax Inclusive 3 
            /// </summary>
            public const int TaxInclusive3 = 48;

            /// <summary>
            /// Property Indexer for Tax Inclusive 4 
            /// </summary>
            public const int TaxInclusive4 = 49;

            /// <summary>
            /// Property Indexer for Tax Inclusive 5 
            /// </summary>
            public const int TaxInclusive5 = 50;

            /// <summary>
            /// Property Indexer for Tax Amount 1 
            /// </summary>
            public const int TaxAmount1 = 51;

            /// <summary>
            /// Property Indexer for Tax Amount 2 
            /// </summary>
            public const int TaxAmount2 = 52;

            /// <summary>
            /// Property Indexer for Tax Amount 3 
            /// </summary>
            public const int TaxAmount3 = 53;

            /// <summary>
            /// Property Indexer for Tax Amount 4 
            /// </summary>
            public const int TaxAmount4 = 54;

            /// <summary>
            /// Property Indexer for Tax Amount 5 
            /// </summary>
            public const int TaxAmount5 = 55;

            /// <summary>
            /// Property Indexer for Distributed Total Before Taxes 
            /// </summary>
            public const int DistributedTotalBeforeTaxes = 56;
            /// <summary>
            /// 
            /// Property Indexer for Invoice Subtotal 
            /// </summary>
            public const int InvoiceSubtotal = 57;

            /// <summary>
            /// Property Indexer for Num1099 Or CPRSCode 
            /// </summary>
            public const int Num1099OrCprsCode = 58;

            /// <summary>
            /// Property Indexer for Num1099 Or CPRSAmount 
            /// </summary>
            public const int Num1099OrCprsAmount = 59;

            /// <summary>
            /// Property Indexer for Last Detail SeqNo 
            /// </summary>
            public const int LastDetailSeqNo = 60;

            /// <summary>
            /// Property Indexer for Schedule 
            /// </summary>
            public const int Schedule = 61;

            /// <summary>
            /// Property Indexer for Schedule Link 
            /// </summary>
            public const int ScheduleLink = 62;

            /// <summary>
            /// Property Indexer for Document Total 
            /// </summary>
            public const int DocumentTotal = 63;

            /// <summary>
            /// Property Indexer for Tax Base 1 
            /// </summary>
            public const int TaxBase1 = 64;

            /// <summary>
            /// Property Indexer for Tax Base 2 
            /// </summary>
            public const int TaxBase2 = 65;

            /// <summary>
            /// Property Indexer for Tax Base 3 
            /// </summary>
            public const int TaxBase3 = 66;

            /// <summary>
            /// Property Indexer for Tax Base 4 
            /// </summary>
            public const int TaxBase4 = 67;

            /// <summary>
            /// Property Indexer for Tax Base 5 
            /// </summary>
            public const int TaxBase5 = 68;

            /// <summary>
            /// Property Indexer for Invoice Taxable 
            /// </summary>
            public const int InvoiceTaxable = 69;

            /// <summary>
            /// Property Indexer for Tax Base Control 
            /// </summary>
            public const int TaxBaseControl = 70;

            /// <summary>
            /// Property Indexer for Total Dist Tax incl in Price 
            /// </summary>
            public const int TotalDistTaxinclinPrice = 76;

            /// <summary>
            /// Property Indexer for Total Dist Tax excl from Price 
            /// </summary>
            public const int TotalDistTaxexclfromPrice = 77;

            /// <summary>
            /// Property Indexer for Total Tax Amount 
            /// </summary>
            public const int TotalTaxAmount = 78;

            /// <summary>
            /// Property Indexer for Optional Fields 
            /// </summary>
            public const int OptionalFields = 84;

            /// <summary>
            /// Property Indexer for Process Command 
            /// </summary>
            public const int ProcessCommand = 85;

            /// <summary>
            /// Property Indexer for Job Related 
            /// </summary>
            public const int JobRelated = 86;

            /// <summary>
            /// Property Indexer for Next Scheduled Date 
            /// </summary>
            public const int NextScheduledDate = 87;

            /// <summary>
            /// Property Indexer for Last Invoice Date Generated 
            /// </summary>
            public const int LastInvoiceDateGenerated = 88;

            /// <summary>
            /// Property Indexer for Unposted Number of Invoices 
            /// </summary>
            public const int UnpostedNumberofInvoices = 89;

            /// <summary>
            /// Property Indexer for Unposted Total Invoice Amount 
            /// </summary>
            public const int UnpostedTotalInvoiceAmount = 90;

            /// <summary>
            /// Property Indexer for Posted Number of Invoices 
            /// </summary>
            public const int PostedNumberofInvoices = 91;

            /// <summary>
            /// Property Indexer for Posted Total Invoice Amount 
            /// </summary>
            public const int PostedTotalInvoiceAmount = 92;

            /// <summary>
            /// Property Indexer for Last Invoice Number Posted 
            /// </summary>
            public const int LastInvoiceNumberPosted = 93;
            
            /// <summary>
            /// Property Indexer for Last Batch Number Posted 
            /// </summary>
            public const int LastBatchNumberPosted = 94;

            /// <summary>
            /// Property Indexer for Last Entry Number Posted 
            /// </summary>
            public const int LastEntryNumberPosted = 95;

            /// <summary>
            /// Property Indexer for Last Posting Sequence Number 
            /// </summary>
            public const int LastPostingSequenceNumber = 96;

            /// <summary>
            /// Property Indexer for Account Set 
            /// </summary>
            public const int AccountSet = 97;

            /// <summary>
            /// Property Indexer for estimated tax withheld amount1
            /// </summary>
            public const int EstimatedTaxWithheld1 = 98;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount2
            /// </summary>
            public const int EstimatedTaxWithheld2 = 99;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount3
            /// </summary>
            public const int EstimatedTaxWithheld3 = 100;

            /// <summary>
            /// Property Indexer for estimated tax withheld amount4
            /// </summary>
            public const int EstimatedTaxWithheld4 = 101;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount5
            /// </summary>
            public const int EstimatedTaxWithheld5 = 102;
            /// <summary>
            /// Property Indexer for customer tax base 1
            /// </summary>
            public const int CustomerTaxBase1 = 103;
            /// <summary>
            /// Property Indexer for customer tax base 2
            /// </summary>
            public const int CustomerTaxBase2 = 104;
            /// <summary>
            /// Property Indexer for customer tax base 3
            /// </summary>
            public const int CustomerTaxBase3 = 105;
            /// <summary>
            /// Property Indexer for customer tax base 4
            /// </summary>
            public const int CustomerTaxBase4 = 106;
            /// <summary>
            /// Property Indexer for customer tax base 5
            /// </summary>
            public const int CustomerTaxBase5 = 107;
            /// <summary>
            /// Property Indexer for customer tax amount 1
            /// </summary>
            public const int CustomerTaxAmount1 = 108;
            /// <summary>
            /// Property Indexer for customer tax amount 2
            /// </summary>
            public const int CustomerTaxAmount2 = 109;
            /// <summary>
            /// Property Indexer for customer tax amount 3
            /// </summary>
            public const int CustomerTaxAmount3 = 110;
            /// <summary>
            /// Property Indexer for customer tax amount 4
            /// </summary>
            public const int CustomerTaxAmount4 = 111;
            /// <summary>
            /// Property Indexer for customer tax amount 5
            /// </summary>
            public const int CustomerTaxAmount5 = 112;
            /// <summary>
            /// Property Indexer for Negative Customer Tax Amount
            /// </summary>
            public const int NegativeCustomerTaxAmount = 102;
            /// <summary>
            /// Property Indexer for Net Vendor Tax Amount
            /// </summary>
            public const int NetVendorTaxAmount = 102;
            /// <summary>
            /// Property Indexer for Customer Tax Amount
            /// </summary>
            public const int CustomerTaxAmount = 102;

            #endregion
        }

        /// <summary>
        /// Class Keys.
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Property Indexer for VendorNumber
            /// </summary>
            public const int VendorNumber = 0;

            /// <summary>
            /// Property Indexer for RecurringPayableCode
            /// </summary>
            public const int RecurringPayableCode = 1;
        }
    }
}
