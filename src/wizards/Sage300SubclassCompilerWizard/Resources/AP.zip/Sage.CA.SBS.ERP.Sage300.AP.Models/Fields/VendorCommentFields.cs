/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for Vendor Comment Constants 
    /// </summary>
    public partial class VendorComment 
	{
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "AP0014";

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0014";

        /// <summary>
        /// Contains list of Vendor Comment Field Constants
        /// </summary>
	    public class Fields
        {
            #region Properties

	        /// <summary>
            /// Property for Vendor Number 
            /// </summary>
	        public const string VendorNumber  = "VENDORID";

	        /// <summary>
            /// Property for Date Entered 
            /// </summary>
	        public const string DateEntered  = "DATEENTR";

	        /// <summary>
            /// Property for Comment Number 
            /// </summary>
	        public const string CommentNumber  = "CNTUNIQ";

	        /// <summary>
            /// Property for Expiration Date 
            /// </summary>
	        public const string ExpirationDate  = "DATEEXPR";

	        /// <summary>
            /// Property for Follow up Date 
            /// </summary>
	        public const string FollowupDate  = "DATEFLUP";

	        /// <summary>
            /// Property for Comment 
            /// </summary>
	        public const string Comment  = "TEXTCMNT";

	        /// <summary>
            /// Property for Reverse Count 
            /// </summary>
	        public const string ReverseCount  = "REVCOM";

	        /// <summary>
            /// Property for Comment1 
            /// </summary>
	        public const string Comment1  = "TEXTCMNT1";

	        /// <summary>
            /// Property for Comment2 
            /// </summary>
	        public const string Comment2  = "TEXTCMNT2";

	        /// <summary>
            /// Property for Comment3
            /// </summary>
	        public const string Comment3 = "TEXTCMNT3";

	        /// <summary>
            /// Property for Comment4 
            /// </summary>
	        public const string Comment4  = "TEXTCMNT4";

	        /// <summary>
            /// Property for Comment5 
            /// </summary>
	        public const string Comment5  = "TEXTCMNT5";

	        /// <summary>
            /// Property for Comment6 
            /// </summary>
	        public const string Comment6  = "TEXTCMNT6";

	        /// <summary>
            /// Property for Comment7 
            /// </summary>
	        public const string Comment7  = "TEXTCMNT7";

	        /// <summary>
            /// Property for Comment8 
            /// </summary>
	        public const string Comment8  = "TEXTCMNT8";
	        
            /// <summary>
            /// Property for Comment9
            /// </summary>
	        public const string Comment9  = "TEXTCMNT9";
	        
            /// <summary>
            /// Property for Comment10 
            /// </summary>
	        public const string Comment10  = "TEXTCMNT10";
	     
            #endregion
	    }

		/// <summary>
        /// Class for list of Vendor Comment Index Constants
        /// </summary>
	    public class Index
        {
            #region Properties
	        
            /// <summary>
            /// Property Indexer for Vendor Number 
            /// </summary>
	        public const int VendorNumber  = 1;

	        /// <summary>
            /// Property Indexer for Date Entered 
            /// </summary>
	        public const int DateEntered  = 2;
	        
            /// <summary>
            /// Property Indexer for Comment Number 
            /// </summary>
	        public const int CommentNumber  = 3;
	        
            /// <summary>
            /// Property Indexer for Expiration Date 
            /// </summary>
	        public const int ExpirationDate  = 4;
	        
            /// <summary>
            /// Property Indexer for Follow up Date 
            /// </summary>
	        public const int FollowupDate  = 5;
	        
            /// <summary>
            /// Property Indexer for Comment 
            /// </summary>
	        public const int Comment  = 6;
	        
            /// <summary>
            /// Property Indexer for Reverse Count 
            /// </summary>
	        public const int ReverseCount  = 7;
	        
            /// <summary>
            /// Property Indexer for Comment1 
            /// </summary>
	        public const int Comment1  = 8;
	          
            /// <summary>
            /// Property Indexer for Comment2 
            /// </summary>
	        public const int Comment2  = 9;
	        
            /// <summary>
            /// Property Indexer for Comment3
            /// </summary>
	        public const int Comment3  = 10;
	        
            /// <summary>
            /// Property Indexer for Comment4
            /// </summary>
	        public const int Comment4  = 11;
	        
            /// <summary>
            /// Property Indexer for Comment5 
            /// </summary>
	        public const int Comment5  = 12;
	        
            /// <summary>
            /// Property Indexer for Comment6 
            /// </summary>
	        public const int Comment6  = 13;
	        
            /// <summary>
            /// Property Indexer for Comment7 
            /// </summary>
	        public const int Comment7  = 14;
	        
            /// <summary>
            /// Property Indexer for Comment8
            /// </summary>
	        public const int Comment8  = 15;
	        
            /// <summary>
            /// Property Indexer for Comment9 
            /// </summary>
	        public const int Comment9  = 16;
	        
            /// <summary>
            /// Property Indexer for Comment10
            /// </summary>
	        public const int Comment10  = 17;
	     
            #endregion
	    }
	}
}
	