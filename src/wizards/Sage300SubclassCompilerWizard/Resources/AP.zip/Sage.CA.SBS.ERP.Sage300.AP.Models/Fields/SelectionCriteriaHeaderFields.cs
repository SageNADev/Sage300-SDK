// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Selection Criteria Header Constants 
    /// </summary>
	public partial class SelectionCriteriaHeader 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "AP0035";

        /// <summary>
        /// Contains list of Selection Criteria Header Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Selection Criteria 
            /// </summary>
            public const string SelectionCriteria = "IDSELECT";

            /// <summary>
            /// Property for Date Last Maintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASMNT";

            /// <summary>
            /// Property for Documents to Process 
            /// </summary>
            public const string DocumentstoProcess = "SWDOCSPROC";

            /// <summary>
            /// Property for Documents to Process 
            /// </summary>
            public const string DocumentstoProcessString = "SWDOCSPROC";

            /// <summary>
            /// Property for Select Documents by 
            /// </summary>
            public const string SelectDocumentsby = "SWSELLBY";

            /// <summary>
            /// Property for Select Documents by 
            /// </summary>
            public const string SelectDocumentsbyString = "SWSELLBY";

            /// <summary>
            /// Property for Date Due 
            /// </summary>
            public const string DateDue = "DATEDUE";

            /// <summary>
            /// Property for From Discount Date 
            /// </summary>
            public const string FromDiscountDate = "DTEDISCFRM";

            /// <summary>
            /// Property for From Group Code 
            /// </summary>
            public const string FromGroupCode = "IDGRPFROM";

            /// <summary>
            /// Property for Thru Group Code 
            /// </summary>
            public const string ThruGroupCode = "IDGRPTHRU";

            /// <summary>
            /// Property for From Vendor Number 
            /// </summary>
            public const string FromVendorNumber = "IDVENDFROM";

            /// <summary>
            /// Property for Thru Vendor Number 
            /// </summary>
            public const string ThruVendorNumber = "IDVENDTHRU";

            /// <summary>
            /// Property for From Account Set 
            /// </summary>
            public const string FromAccountSet = "ACCTSETFR";

            /// <summary>
            /// Property for Thru Account Set 
            /// </summary>
            public const string ThruAccountSet = "ACCTSETTHR";

            /// <summary>
            /// Property for Exclude Vendor 
            /// </summary>
            public const string ExcludeVendor = "SWVENDEXCL";

            /// <summary>
            /// Property for Exclude Vendor String
            /// </summary>
            public const string ExcludeVendorString = "SWVENDEXCL";

            /// <summary>
            /// Property for Vendor Currency Code 
            /// </summary>
            public const string VendorCurrencyCode = "CODECURNTC";

            /// <summary>
            /// Property for Payment Bank Code 
            /// </summary>
            public const string PaymentBankCode = "IDBANKPAYM";

            /// <summary>
            /// Property for Bank Currency Code 
            /// </summary>
            public const string BankCurrencyCode = "CODECURNPY";

            /// <summary>
            /// Property for Minimum Payment Amount 
            /// </summary>
            public const string MinimumPaymentAmount = "AMTMINCHK";

            /// <summary>
            /// Property for Maximum Payment Amount 
            /// </summary>
            public const string MaximumPaymentAmount = "AMTMAXCHK";

            /// <summary>
            /// Property for Bank Match 
            /// </summary>
            public const string BankMatch = "SWBANKMTCH";

            /// <summary>
            /// Property for Bank Match String
            /// </summary>
            public const string BankMatchString = "SWBANKMTCH";

            /// <summary>
            /// Property for Payment Date 
            /// </summary>
            public const string PaymentDate = "DATECHECK";

            /// <summary>
            /// Property for Inactive Date 
            /// </summary>
            public const string InactiveDate = "DATEINACT";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "SWACTV";

            /// <summary>
            /// Property for Status String 
            /// </summary>
            public const string StatusString = "SWACTV";

            /// <summary>
            /// Property for Vendor Rate Type 
            /// </summary>
            public const string VendorRateType = "CODERATETC";

            /// <summary>
            /// Property for Bank Rate Type 
            /// </summary>
            public const string BankRateType = "CODERATEBC";

            /// <summary>
            /// Property for Vendor Exchange Rate 
            /// </summary>
            public const string VendorExchangeRate = "EXCHRATETC";

            /// <summary>
            /// Property for Bank Exchange Rate 
            /// </summary>
            public const string BankExchangeRate = "EXCHRATEBC";

            /// <summary>
            /// Property for Vendor Rate Date 
            /// </summary>
            public const string VendorRateDate = "RATEDATETC";

            /// <summary>
            /// Property for Bank Rate Date 
            /// </summary>
            public const string BankRateDate = "RATEDATEBC";

            /// <summary>
            /// Property for CSV File name 
            /// </summary>
            public const string CsvFilename = "CSVFILE";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";

            /// <summary>
            /// Property for Thru Discount Date 
            /// </summary>
            public const string ThruDiscountDate = "DTEDISCTHR";

            /// <summary>
            /// Property for Batch Date 
            /// </summary>
            public const string BatchDate = "DTEBATCH";

            /// <summary>
            /// Property for Vendor Rate Operator
            /// </summary>
            public const string VendorRateOperator = "RATEOPTC";

            /// <summary>
            /// Property for Bank Rate Operator 
            /// </summary>
            public const string BankRateOperator = "RATEOPBC";

            /// <summary>
            /// Property for Vendor Rate Overridden 
            /// </summary>
            public const string VendorRateOverridden = "SWRATETC";

            /// <summary>
            /// Property for Bank Rate Overridden 
            /// </summary>
            public const string BankRateOverridden = "SWRATEBC";

            /// <summary>
            /// Property for Job Apply Method 
            /// </summary>
            public const string JobApplyMethod = "APPLYMETH";

            /// <summary>
            /// Property for Job Apply Method String
            /// </summary>
            public const string JobApplyMethodString = "APPLYMETH";

            /// <summary>
            /// Property for Generated Selection Criteria 
            /// </summary>
            public const string GeneratedSelectionCriteria = "IDSELECTED";

            /// <summary>
            /// Property for Optional Fields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for Process CommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for Process CommandCode String
            /// </summary>
            public const string ProcessCommandCodeString = "PROCESSCMD";

            /// <summary>
            /// Property for From Payment Code 
            /// </summary>
            public const string FromPaymentCode = "PMCODEFROM";

            /// <summary>
            /// Property for Thru Payment Code 
            /// </summary>
            public const string ThruPaymentCode = "PMCODETHRU";

            /// <summary>
            /// Property for Optional Field 
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Type Srting
            /// </summary>
            public const string TypeString = "TYPE";

            /// <summary>
            /// Property for Length 
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Decimals 
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for From Optional Field Value 
            /// </summary>
            public const string FromOptionalFieldValue = "VALUEFROM";

            /// <summary>
            /// Property for Thru Optional Field Value 
            /// </summary>
            public const string ThruOptionalFieldValue = "VALUETHRU";

            #endregion
        }

        /// <summary>
        /// Contains list of Selection Criteria Header Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Selection Criteria 
            /// </summary>
            public const int SelectionCriteria = 1;

            /// <summary>
            /// Property Indexer for Date Last Maintained 
            /// </summary>
            public const int DateLastMaintained = 2;

            /// <summary>
            /// Property Indexer for Documents to Process 
            /// </summary>
            public const int DocumentstoProcess = 3;

            /// <summary>
            /// Property Indexer for Select Documents by 
            /// </summary>
            public const int SelectDocumentsby = 4;

            /// <summary>
            /// Property Indexer for Date Due 
            /// </summary>
            public const int DateDue = 5;

            /// <summary>
            /// Property Indexer for From Discount Date 
            /// </summary>
            public const int FromDiscountDate = 6;

            /// <summary>
            /// Property Indexer for From Group Code 
            /// </summary>
            public const int FromGroupCode = 7;

            /// <summary>
            /// Property Indexer for Thru Group Code 
            /// </summary>
            public const int ThruGroupCode = 8;

            /// <summary>
            /// Property Indexer for From Vendor Number 
            /// </summary>
            public const int FromVendorNumber = 9;

            /// <summary>
            /// Property Indexer for Thru Vendor Number 
            /// </summary>
            public const int ThruVendorNumber = 10;

            /// <summary>
            /// Property Indexer for From Account Set 
            /// </summary>
            public const int FromAccountSet = 11;

            /// <summary>
            /// Property Indexer for Thru Account Set 
            /// </summary>
            public const int ThruAccountSet = 12;

            /// <summary>
            /// Property Indexer for Exclude Vendor 
            /// </summary>
            public const int ExcludeVendor = 13;

            /// <summary>
            /// Property Indexer for Vendor Currency Code 
            /// </summary>
            public const int VendorCurrencyCode = 15;

            /// <summary>
            /// Property Indexer for Payment Bank Code 
            /// </summary>
            public const int PaymentBankCode = 16;

            /// <summary>
            /// Property Indexer for Bank Currency Code 
            /// </summary>
            public const int BankCurrencyCode = 17;

            /// <summary>
            /// Property Indexer for Minimum Payment Amount 
            /// </summary>
            public const int MinimumPaymentAmount = 20;

            /// <summary>
            /// Property Indexer for Maximum Payment Amount 
            /// </summary>
            public const int MaximumPaymentAmount = 21;

            /// <summary>
            /// Property Indexer for Bank Match 
            /// </summary>
            public const int BankMatch = 22;

            /// <summary>
            /// Property Indexer for Payment Date 
            /// </summary>
            public const int PaymentDate = 23;

            /// <summary>
            /// Property Indexer for Inactive Date 
            /// </summary>
            public const int InactiveDate = 24;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 25;

            /// <summary>
            /// Property Indexer for Vendor Rate Type 
            /// </summary>
            public const int VendorRateType = 26;

            /// <summary>
            /// Property Indexer for Bank Rate Type 
            /// </summary>
            public const int BankRateType = 27;

            /// <summary>
            /// Property Indexer for Vendor Exchange Rate 
            /// </summary>
            public const int VendorExchangeRate = 28;

            /// <summary>
            /// Property Indexer for Bank Exchange Rate 
            /// </summary>
            public const int BankExchangeRate = 29;

            /// <summary>
            /// Property Indexer for Vendor Rate Date 
            /// </summary>
            public const int VendorRateDate = 30;

            /// <summary>
            /// Property Indexer for Bank Rate Date 
            /// </summary>
            public const int BankRateDate = 31;

            /// <summary>
            /// Property Indexer for CSV File name 
            /// </summary>
            public const int CsvFilename = 32;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 33;

            /// <summary>
            /// Property Indexer for Thru Discount Date 
            /// </summary>
            public const int ThruDiscountDate = 34;

            /// <summary>
            /// Property Indexer for Batch Date 
            /// </summary>
            public const int BatchDate = 35;

            /// <summary>
            /// Property Indexer for Vendor Rate Operator 
            /// </summary>
            public const int VendorRateOperator = 36;

            /// <summary>
            /// Property Indexer for Bank Rate Operator 
            /// </summary>
            public const int BankRateOperator = 37;

            /// <summary>
            /// Property Indexer for Vendor Rate Overridden 
            /// </summary>
            public const int VendorRateOverridden = 38;

            /// <summary>
            /// Property Indexer for Bank Rate Overridden 
            /// </summary>
            public const int BankRateOverridden = 39;

            /// <summary>
            /// Property Indexer for Job Apply Method 
            /// </summary>
            public const int JobApplyMethod = 40;

            /// <summary>
            /// Property Indexer for Generated Selection Criteria 
            /// </summary>
            public const int GeneratedSelectionCriteria = 41;

            /// <summary>
            /// Property Indexer for Optional Fields 
            /// </summary>
            public const int OptionalFields = 42;

            /// <summary>
            /// Property Indexer for Process Command Code 
            /// </summary>
            public const int ProcessCommandCode = 43;

            /// <summary>
            /// Property Indexer for From Payment Code 
            /// </summary>
            public const int FromPaymentCode = 44;

            /// <summary>
            /// Property Indexer for Thru Payment Code 
            /// </summary>
            public const int ThruPaymentCode = 45;

            /// <summary>
            /// Property Indexer for Optional Field 
            /// </summary>
            public const int OptionalField = 46;

            /// <summary>
            /// Property Indexer for Type 
            /// </summary>
            public const int Type = 47;

            /// <summary>
            /// Property Indexer for Length 
            /// </summary>
            public const int Length = 48;

            /// <summary>
            /// Property Indexer for Decimals 
            /// </summary>
            public const int Decimals = 49;

            /// <summary>
            /// Property Indexer for From Optional Field Value 
            /// </summary>
            public const int FromOptionalFieldValue = 50;

            /// <summary>
            /// Property Indexer for Thru Optional Field Value 
            /// </summary>
            public const int ThruOptionalFieldValue = 51;

            #endregion
        }


	}
}
	