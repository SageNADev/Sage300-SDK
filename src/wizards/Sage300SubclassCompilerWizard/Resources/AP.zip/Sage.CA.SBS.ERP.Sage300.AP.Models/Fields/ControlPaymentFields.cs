// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ControlPayment Constants 
    /// </summary>
    public partial class ControlPayment
    {
        #region Public Variables

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0057";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of ControlPayments Fields Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for RequestType 
            /// </summary>
            public const string RequestType = "SWREQTYPE";

            /// <summary>
            /// Property for StartingVendorRange 
            /// </summary>
            public const string StartingVendorRange = "IDVENDSTRT";

            /// <summary>
            /// Property for EndingVendorRange 
            /// </summary>
            public const string EndingVendorRange = "IDVENDEND";

            /// <summary>
            /// Property for StartingGroupRange 
            /// </summary>
            public const string StartingGroupRange = "IDVGRPSTRT";

            /// <summary>
            /// Property for EndingGroupRange 
            /// </summary>
            public const string EndingGroupRange = "IDVGRPEND";

            /// <summary>
            /// Property for StartingDocumentNumber 
            /// </summary>
            public const string StartingDocumentNumber = "IDDOCSTART";

            /// <summary>
            /// Property for EndingDocumentNumber 
            /// </summary>
            public const string EndingDocumentNumber = "IDDOCEND";

            /// <summary>
            /// Property for IncludeInvoices 
            /// </summary>
            public const string IncludeInvoices = "SWINCLINVC";

            /// <summary>
            /// Property for IncludeCreditsNotes 
            /// </summary>
            public const string IncludeCreditsNotes = "SWINCLCRED";

            /// <summary>
            /// Property for IncludeDebitsNotes 
            /// </summary>
            public const string IncludeDebitsNotes = "SWINCLDEB";

            /// <summary>
            /// Property for IncludePrepayments 
            /// </summary>
            public const string IncludePrepayments = "SWINCLPPD";

            /// <summary>
            /// Property for ScheduledPaymentNumber 
            /// </summary>
            public const string ScheduledPaymentNumber = "CNTPAYSCHD";

            /// <summary>
            /// Property for DesiredStatus 
            /// </summary>
            public const string DesiredStatus = "SWSTATUS";

            /// <summary>
            /// Property for VendorDiscountAmount 
            /// </summary>
            public const string VendorDiscountAmount = "AMTDISC";

            /// <summary>
            /// Property for DueDate 
            /// </summary>
            public const string DueDate = "DATEDUE";

            /// <summary>
            /// Property for DiscountDate 
            /// </summary>
            public const string DiscountDate = "DATEDISC";

            /// <summary>
            /// Property for ActivationDate 
            /// </summary>
            public const string ActivationDate = "DATEACTIVE";

            /// <summary>
            /// Property for IncludeInterest 
            /// </summary>
            public const string IncludeInterest = "SWINCLINT";

            /// <summary>
            /// Property for ClearPaymentLimit 
            /// </summary>
            public const string ClearPaymentLimit = "SWPYMLM";

            /// <summary>
            /// Property for PaymentLimit 
            /// </summary>
            public const string PaymentLimit = "AMTPYMLM";
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of ControlPayments Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for RequestType 
            /// </summary>
            public const int RequestType = 1;

            /// <summary>
            /// Property Indexer for StartingVendorRange 
            /// </summary>
            public const int StartingVendorRange = 2;

            /// <summary>
            /// Property Indexer for EndingVendorRange 
            /// </summary>
            public const int EndingVendorRange = 3;

            /// <summary>
            /// Property Indexer for StartingGroupRange 
            /// </summary>
            public const int StartingGroupRange = 4;

            /// <summary>
            /// Property Indexer for EndingGroupRange 
            /// </summary>
            public const int EndingGroupRange = 5;

            /// <summary>
            /// Property Indexer for StartingDocumentNumber 
            /// </summary>
            public const int StartingDocumentNumber = 6;

            /// <summary>
            /// Property Indexer for EndingDocumentNumber 
            /// </summary>
            public const int EndingDocumentNumber = 7;

            /// <summary>
            /// Property Indexer for IncludeInvoices 
            /// </summary>
            public const int IncludeInvoices = 8;

            /// <summary>
            /// Property Indexer for IncludeCreditsNotes 
            /// </summary>
            public const int IncludeCreditsNotes = 9;

            /// <summary>
            /// Property Indexer for IncludeDebitsNotes 
            /// </summary>
            public const int IncludeDebitsNotes = 10;

            /// <summary>
            /// Property Indexer for IncludePrepayments 
            /// </summary>
            public const int IncludePrepayments = 11;

            /// <summary>
            /// Property Indexer for ScheduledPaymentNumber 
            /// </summary>
            public const int ScheduledPaymentNumber = 12;

            /// <summary>
            /// Property Indexer for DesiredStatus 
            /// </summary>
            public const int DesiredStatus = 13;

            /// <summary>
            /// Property Indexer for VendorDiscountAmount 
            /// </summary>
            public const int VendorDiscountAmount = 14;

            /// <summary>
            /// Property Indexer for DueDate 
            /// </summary>
            public const int DueDate = 15;

            /// <summary>
            /// Property Indexer for DiscountDate 
            /// </summary>
            public const int DiscountDate = 16;

            /// <summary>
            /// Property Indexer for ActivationDate 
            /// </summary>
            public const int ActivationDate = 17;

            /// <summary>
            /// Property Indexer for IncludeInterest 
            /// </summary>
            public const int IncludeInterest = 18;

            /// <summary>
            /// Property Indexer for ClearPaymentLimit 
            /// </summary>
            public const int ClearPaymentLimit = 19;

            /// <summary>
            /// Property Indexer for PaymentLimit 
            /// </summary>
            public const int PaymentLimit = 20;
        }

        #endregion
    }
}