// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PostingJournal Constants
    /// </summary>
    public partial class PostingJournal
    {
        #region ViewName

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "08fc7986-c4c4-4b25-b0b6-f0f9d3b2c1f6";

        #endregion

        #region Field Properties

        /// <summary>
        /// Contains list of PostingJournal Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for FromSequence
            /// </summary>
            public const string FromSequence = "FROMSEQ";

            /// <summary>
            /// Property for ToSequence
            /// </summary>
            public const string ToSequence = "TOSEQ";

            /// <summary>
            /// Property for Reprint
            /// </summary>
            public const string Reprint = "REPRINT";

            /// <summary>
            /// Property for ShowJobDetails
            /// </summary>
            public const string ShowJobDetails = "SWJOBDETAILS";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "OPTFLDS?";

            /// <summary>
            /// Property for SortBy
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// Property for SwitchGlRefDescription
            /// </summary>
            public const string SwitchGlRefDescription = "SWGLREFDESC";

            /// <summary>
            /// Property for MultiCurrency
            /// </summary>
            public const string MultiCurrency = "MULTCURN";

            /// <summary>
            /// Property for HomeCurrency
            /// </summary>
            public const string HomeCurrency = "HCURN";

            /// <summary>
            /// Property for HomeCurrencyDecimal
            /// </summary>
            public const string HomeCurrencyDecimal = "HCURNDEC";

            /// <summary>
            /// Property for SwitchPmActive
            /// </summary>
            public const string SwitchPmActive = "SWPMACTIVE";

            /// <summary>
            /// Property for Level1Name
            /// </summary>
            public const string Level1Name = "LEVEL1NAME";

            /// <summary>
            /// Property for Level2Name
            /// </summary>
            public const string Level2Name = "LEVEL2NAME";

            /// <summary>
            /// Property for Level3Name
            /// </summary>
            public const string Level3Name = "LEVEL3NAME";

            /// <summary>
            /// Property for SwitchGlActive
            /// </summary>
            public const string SwitchGlActive = "SWGLACTIVE";

            /// <summary>
            /// Property for SwitchRtg
            /// </summary>
            public const string SwitchRtg = "SWRTG";

            /// <summary>
            /// Property for SwitchZiActive
            /// </summary>
            public const string SwitchZiActive = "SWZIACTIVE";

            /// <summary>
            /// Property for ZiMultiCurrency
            /// </summary>
            public const string ZiMultiCurrency = "ZIMULTCURN";

            /// <summary>
            /// Property for ZiDetails
            /// </summary>
            public const string ZiDetails = "ZIDETAILS";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of PostingJournal Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for FromSequence
            /// </summary>
            public const int FromSequence = 2;

            /// <summary>
            /// Property Indexer for TosToSequenceeq
            /// </summary>
            public const int ToSequence = 3;

            /// <summary>
            /// Property Indexer for Reprint
            /// </summary>
            public const int Reprint = 4;

            /// <summary>
            /// Property Indexer for ShowJobDetails
            /// </summary>
            public const int ShowJobDetails = 5;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 6;

            /// <summary>
            /// Property Indexer for SortBy
            /// </summary>
            public const int SortBy = 7;

            /// <summary>
            /// Property Indexer for SwitchGlRefDescription
            /// </summary>
            public const int SwitchGlRefDescription = 8;

            /// <summary>
            /// Property Indexer for MultiCurrency
            /// </summary>
            public const int MultiCurrency = 9;

            /// <summary>
            /// Property Indexer for HomeCurrency
            /// </summary>
            public const int HomeCurrency = 10;

            /// <summary>
            /// Property Indexer for HomeCurrencyDecimal
            /// </summary>
            public const int HomeCurrencyDecimal = 11;

            /// <summary>
            /// Property Indexer for SwitchPmActive
            /// </summary>
            public const int SwitchPmActive = 12;

            /// <summary>
            /// Property Indexer for Level1Name
            /// </summary>
            public const int Level1Name = 13;

            /// <summary>
            /// Property Indexer for Level2Name
            /// </summary>
            public const int Level2Name = 14;

            /// <summary>
            /// Property Indexer for Level3Name
            /// </summary>
            public const int Level3Name = 15;

            /// <summary>
            /// Property Indexer for SwitchGlActive
            /// </summary>
            public const int SwitchGlActive = 16;

            /// <summary>
            /// Property Indexer for SwitchRtg
            /// </summary>
            public const int SwitchRtg = 17;

            /// <summary>
            /// Property Indexer for SwitchZiActive
            /// </summary>
            public const int SwitchZiActive = 18;

            /// <summary>
            /// Property Indexer for ZiMultiCurrency
            /// </summary>
            public const int ZiMultiCurrency = 19;

            /// <summary>
            /// Property Indexer for ZiDetails
            /// </summary>
            public const int ZiDetails = 20;
        }

        #endregion
    }
}
