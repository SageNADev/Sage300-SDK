﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    // ReSharper restore CheckNamespace
    public partial class LetterAndLabelReport
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "7EB25418-CD6E-4ED6-9191-05D821A581A9";

        #endregion

        /// <summary>
        /// Contains list of APLetter Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Zipcode 
            /// </summary>
            public const string ZipCode = "ZIPCODE";

            /// <summary>
            /// Property for Address 1 
            /// </summary>
            public const string Address1 = "ADDR1";

            /// <summary>
            /// Property for Address 2 
            /// </summary>
            public const string Address2 = "ADDR2";

            /// <summary>
            /// Property for Address 3 
            /// </summary>
            public const string Address3 = "ADDR3";

            /// <summary>
            /// Property for Address 4
            /// </summary>
            public const string Address4 = "ADDR4";

            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "CITY";

            /// <summary>
            /// Property for Country 
            /// </summary>
            public const string Country = "COUNTRY";

            /// <summary>
            /// Property for SessionDate 
            /// </summary>
            public const string SessionDate = "SESSDATE";

            /// <summary>
            /// Property for EmailSendTo
            /// </summary>
            public const string EmailSendTo = "EMAILSENDTO";

            /// <summary>
            /// Property for EmailSubject
            /// </summary>
            public const string EmailSubject = "EMAILSUBJECT";

            /// <summary>
            /// Property for EmailMessageBody
            /// </summary>
            public const string EmailMessageBody = "EMAILTEXT";
            
            #endregion
        }

        /// <summary>
        /// Contains list of APLetter Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for ZipCode
            /// </summary>
            public const int ZipCode = 2;

            /// <summary>
            /// Property Indexer for Address1
            /// </summary>
            public const int Address1 = 3;

            /// <summary>
            /// Property Indexer for Address2
            /// </summary>
            public const int Address2 = 4;

            /// <summary>
            /// Property Indexer for Address3
            /// </summary>
            public const int Address3 = 5;

            /// <summary>
            /// Property Indexer for Address4
            /// </summary>
            public const int Address4 = 6;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 7;

            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 8;

            /// <summary>
            /// Property Indexer for SessionDate
            /// </summary>
            public const int SessionDate = 9;

            #endregion
        }
    }
}
