﻿/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Contains list of Vendor Report Constants
    /// </summary>
    public partial class VendorReport
    {
        #region Constants

        /// <summary>
        /// View Name - New Guid
        /// </summary>
        public const string ViewName = "9BF6570C-63D2-4135-B2C8-3E2E09AA01A3";

        #endregion

        /// <summary>
        /// Vendor Report Field Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for Address
            /// </summary>
            public const string Address = "ADDRESS?";

            /// <summary>
            /// Property for Profile
            /// </summary>
            public const string Profile = "PROFILE?";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS?";

            /// <summary>
            /// Property for FromCmtDt
            /// </summary>
            public const string FromCmtDt = "FROMCMTDT";

            /// <summary>
            /// Property for ToCmtDt
            /// </summary>
            public const string ToCmtDt = "TOCMTDT";

            /// <summary>
            /// Property for PhoneFmt
            /// </summary>
            public const string PhoneFmt = "PHONEFMT?";

            /// <summary>
            /// Property for Select1
            /// </summary>
            public const string Select1 = "SELECT1";

            /// <summary>
            /// Property for From1
            /// </summary>
            public const string From1 = "FROM1";

            /// <summary>
            /// Property for To1
            /// </summary>
            public const string To1 = "TO1";

            /// <summary>
            /// Property for Select2
            /// </summary>
            public const string Select2 = "SELECT2";

            /// <summary>
            /// Property for From2
            /// </summary>
            public const string From2 = "FROM2";

            /// <summary>
            /// Property for To2
            /// </summary>
            public const string To2 = "TO2";

            /// <summary>
            /// Property for Select3 
            /// </summary>
            public const string Select3 = "SELECT3";

            /// <summary>
            /// Property for From3
            /// </summary>
            public const string From3 = "FROM3";

            /// <summary>
            /// Property for To3
            /// </summary>
            public const string To3 = "TO3";

            /// <summary>
            /// Property for Select4
            /// </summary>
            public const string Select4 = "SELECT4";

            /// <summary>
            /// Property for From4
            /// </summary>
            public const string From4 = "FROM4";

            /// <summary>
            /// Property for To4
            /// </summary>
            public const string To4 = "TO4";

            /// <summary>
            /// Property for SortBy
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// Property for Sort1
            /// </summary>
            public const string Sort1 = "SORT1";

            /// <summary>
            /// Property for Sort2
            /// </summary>
            public const string Sort2 = "SORT2";

            /// <summary>
            /// Property for Sort3
            /// </summary>
            public const string Sort3 = "SORT3";

            /// <summary>
            /// Property for Sort4
            /// </summary>
            public const string Sort4 = "SORT4";

            /// <summary>
            /// Property for Type1
            /// </summary>
            public const string Type1 = "TYPE1";

            /// <summary>
            /// Property for Type2
            /// </summary>
            public const string Type2 = "TYPE2";

            /// <summary>
            /// Property for Type3
            /// </summary>
            public const string Type3 = "TYPE3";

            /// <summary>
            /// Property for Type4
            /// </summary>
            public const string Type4 = "TYPE4";

            /// <summary>
            /// Property for OptFlds
            /// </summary>
            public const string OptFlds = "OPTFLDS?";

            /// <summary>
            /// Property for SelSeq
            /// </summary>
            public const string SelSeq = "SELSEQ";

            /// <summary>
            /// Property for Recurring
            /// </summary>
            public const string Recurring = "RECURRING?";

            /// <summary>
            /// Property for Recurring
            /// </summary>
            public const string MaskTaxNum = "MASKTAXNBR?";

            /// <summary>
            /// Property for McurCust
            /// </summary>
            public const string McurCust = "MCURCUST?";

            /// <summary>
            /// Property for FcurnDec
            /// </summary>
            public const string FcurnDec = "FCURNDEC";

            /// <summary>
            /// Property for MultCurn
            /// </summary>
            public const string MultCurn = "MULTCURN";

            /// <summary>
            /// Property for Counts
            /// </summary>
            public const string Counts = "COUNTS?";

            /// <summary>
            /// Property for CountCst
            /// </summary>
            public const string CountCst = "COUNTCST";

            /// <summary>
            /// Property for FromYear
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for ToYear
            /// </summary>
            public const string ToYear = "TOYEAR";

            /// <summary>
            /// Property for FromPerd
            /// </summary>
            public const string FromPerd = "FROMPERD";

            /// <summary>
            /// Property for ToPerd
            /// </summary>
            public const string ToPerd = "TOPERD";

            #endregion
        }

        /// <summary>
        /// Vendor Report Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for Address
            /// </summary>
            public const string Address = "2";

            /// <summary>
            /// Property Indexer for Profile
            /// </summary>
            public const string Profile = "3";

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const string Comments = "4";

            /// <summary>
            /// Property Indexer for FromCmtDt
            /// </summary>
            public const string FromCmtDt = "5";

            /// <summary>
            /// Property Indexer for ToCmtDt
            /// </summary>
            public const string ToCmtDt = "6";

            /// <summary>
            /// Property Indexer for PhoneFmt
            /// </summary>
            public const string PhoneFmt = "7";

            /// <summary>
            /// Property Indexer for Select1
            /// </summary>
            public const string Select1 = "8";

            /// <summary>
            /// Property Indexer for From1
            /// </summary>
            public const string From1 = "9";

            /// <summary>
            /// Property Indexer for To1
            /// </summary>
            public const string To1 = "10";

            /// <summary>
            /// Property Indexer for Select2
            /// </summary>
            public const string Select2 = "11";

            /// <summary>
            /// Property Indexer for From2
            /// </summary>
            public const string From2 = "12";

            /// <summary>
            /// Property Indexer for To2
            /// </summary>
            public const string To2 = "13";

            /// <summary>
            /// Property Indexer for Select3 
            /// </summary>
            public const string Select3 = "14";

            /// <summary>
            /// Property Indexer for From3
            /// </summary>
            public const string From3 = "15";

            /// <summary>
            /// Property Indexer for To3
            /// </summary>
            public const string To3 = "16";

            /// <summary>
            /// Property Indexer for Select4
            /// </summary>
            public const string Select4 = "17";

            /// <summary>
            /// Property Indexer for From4
            /// </summary>
            public const string From4 = "18";

            /// <summary>
            /// Property Indexer for To4
            /// </summary>
            public const string To4 = "19";

            /// <summary>
            /// Property Indexer for SortBy
            /// </summary>
            public const string SortBy = "20";

            /// <summary>
            /// Property Indexer for Sort1
            /// </summary>
            public const string Sort1 = "21";

            /// <summary>
            /// Property Indexer for Sort2
            /// </summary>
            public const string Sort2 = "22";

            /// <summary>
            /// Property Indexer for Sort3
            /// </summary>
            public const string Sort3 = "23";

            /// <summary>
            /// Property Indexer for Sort4
            /// </summary>
            public const string Sort4 = "24";

            /// <summary>
            /// Property Indexer for Type1
            /// </summary>
            public const string Type1 = "25";

            /// <summary>
            /// Property Indexer for Type2
            /// </summary>
            public const string Type2 = "26";

            /// <summary>
            /// Property Indexer for Type3
            /// </summary>
            public const string Type3 = "27";

            /// <summary>
            /// Property Indexer for Type4
            /// </summary>
            public const string Type4 = "28";

            /// <summary>
            /// Property Indexer for OptFlds
            /// </summary>
            public const string OptFlds = "29";

            /// <summary>
            /// Property Indexer for SelSeq
            /// </summary>
            public const string SelSeq = "30";

            /// <summary>
            /// Property Indexer for Recurring
            /// </summary>
            public const string Recurring = "31";

            /// <summary>
            /// Property Indexer for MaskTaxNum
            /// </summary>
            public const string MaskTaxNum = "32";
            #endregion
        }
    }
}
