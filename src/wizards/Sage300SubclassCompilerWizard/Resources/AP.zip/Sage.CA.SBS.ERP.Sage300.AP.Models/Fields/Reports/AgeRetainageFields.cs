/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of AgeRetainageDocuments Constants 
    /// </summary>
    public partial class AgeRetainage
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "D0989446-ECB8-460A-98EE-24CCE2725EC8";

        #endregion

        /// <summary>
        /// Contains list of AgeRetainageDocuments Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for RunDate 
            /// </summary>
            public const string RunDate = "ASOFDATE";
            /// <summary>
            /// Property for RetainageDueDateCutoffDate 
            /// </summary>
            public const string RetainageDueDateCutoffDate = "CUTOFFDT";
            /// <summary>
            /// Property for Cutoffby 
            /// </summary>
            public const string Cutoffby = "CUTOFFBY";
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string Year = "CUTOFFYEAR";
            /// <summary>
            /// Property for Period 
            /// </summary>
            public const string Period = "CUTOFFPERD";
            /// <summary>
            /// Property for FuncOrVendorCurrency 
            /// </summary>
            public const string FuncOrVendorCurrency = "FCURNDEC"; //
            /// <summary>
            /// Property for ATBOrOverdueRecReport 
            /// </summary>
            public const string ATBOrOverdueRecReport = "SWOVERDUERPT";
            /// <summary>
            /// Property for DetailOrSummaryReport 
            /// </summary>
            public const string DetailOrSummaryReport = "PRTTYPE";//
            /// <summary>
            /// Property for Current 
            /// </summary>
            public const string Period1 = "PERIOD1";
            /// <summary>
            /// Property for FirstPeriod 
            /// </summary>
            public const string Period2 = "PERIOD2";
            /// <summary>
            /// Property for SecondPeriod 
            /// </summary>
            public const string Period3 = "PERIOD3";
            /// <summary>
            /// Property for ThirdPeriod 
            /// </summary>
            public const string Period4 = "PERIOD4";


            /// <summary>
            /// Property for Select1 
            /// </summary>
            public const string Select1 = "SELECT1";

            /// <summary>
            /// Property for Range1From 
            /// </summary>
            public const string Range1From = "FROM1";
            /// <summary>
            /// Property for Range1To 
            /// </summary>
            public const string Range1To = "TO1";
            /// <summary>
            /// Property for Range1IndexValue 
            /// </summary>
            public const string Range1IndexValue = "TYPE1";

            /// <summary>
            /// Property for Select2 
            /// </summary>
            public const string Select2 = "SELECT2";

            /// <summary>
            /// Property for Range2From 
            /// </summary>
            public const string Range2From = "FROM2";
            /// <summary>
            /// Property for Range2To 
            /// </summary>
            public const string Range2To = "TO2";
            /// <summary>
            /// Property for Range2IndexValue 
            /// </summary>
            public const string Range2IndexValue = "TYPE2";

            /// <summary>
            /// Property for Select3 
            /// </summary>
            public const string Select3 = "SELECT3";
            /// <summary>
            /// Property for Range3From 
            /// </summary>
            public const string Range3From = "FROM3";
            /// <summary>
            /// Property for Range3To 
            /// </summary>
            public const string Range3To = "TO3";
            /// <summary>
            /// Property for Range3IndexValue 
            /// </summary>
            public const string Range3IndexValue = "TYPE3";
            /// <summary>
            /// Property for Select4 
            /// </summary>
            public const string Select4 = "SELECT4";
            /// <summary>
            /// Property for Range4From 
            /// </summary>
            public const string Range4From = "FROM4";
            /// <summary>
            /// Property for Range4To 
            /// </summary>
            public const string Range4To = "TO4";
            /// <summary>
            /// Property for Range4IndexValue 
            /// </summary>
            public const string Range4IndexValue = "TYPE4";
            /// <summary>
            /// Property for SequenceNumber 
            /// </summary>
            public const string SequenceNumber = "RTGSEQ";

            /// <summary>
            /// Property for SortOrder
            /// </summary>
            public const string Sortorder = "SORTORDER";
            /// <summary>
            /// Property for Sort1 
            /// </summary>
            public const string Sort1 = "SORT1";
            /// <summary>
            /// Property for Sort2 
            /// </summary>
            public const string Sort2 = "SORT2";
            /// <summary>
            /// Property for Sort3 
            /// </summary>
            public const string Sort3 = "SORT3";
            /// <summary>
            /// Property for Sort4 
            /// </summary>
            public const string Sort4 = "SORT4";

            /// <summary>
            /// Property for IncludeTaxes 
            /// </summary>
            public const string IncludeTaxes = "SWTAX";

            /// <summary>
            /// Property for GRP1TITLE 
            /// </summary>
            public const string Grp1Title = "GRP1TITLE?";


            /// <summary>
            /// Property for GRP2TITLE 
            /// </summary>
            public const string Grp2Title = "GRP2TITLE?";


            /// <summary>
            /// Property for GRP3TITLE 
            /// </summary>
            public const string Grp3Title = "GRP3TITLE?";


            /// <summary>
            /// Property for GRP4TITLE 
            /// </summary>
            public const string Grp4Title = "GRP4TITLE?";

            /// <summary>
            /// Property for GRP1TOTAL 
            /// </summary>
            public const string Grp1Total = "GRP1TOTAL?";


            /// <summary>
            /// Property for GRP2TITLE 
            /// </summary>
            public const string Grp2Total = "GRP2TOTAL?";


            /// <summary>
            /// Property for GRP3TITLE 
            /// </summary>
            public const string Grp3Total = "GRP3TOTAL?";


            /// <summary>
            /// Property for GRP4TITLE 
            /// </summary>
            public const string Grp4Total = "GRP4TOTAL?";

            /// <summary>
            /// Property for Amount Type 
            /// </summary>
            public const string AmountType = "AMTTYPE";

            /// <summary>
            /// Property for Report Title 
            /// </summary>
            public const string ReportTitle = "RPTTITLE";

            /// <summary>
            /// Property for MultiCurrency
            /// </summary>
            public const string MultiCurrency = "MCURCUST?";

            #endregion
        }
        
        /// <summary>
        /// Contains list of AgeRetainageDocuments Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for RunDate 
            /// </summary>
            public const int RunDate = 18;
            /// <summary>
            /// Property Indexer for RetainageDueDateCutoffDate 
            /// </summary>
            public const int RetainageDueDateCutoffDate = 19;
            /// <summary>
            /// Property Indexer for Cutoffby 
            /// </summary>
            public const int Cutoffby = 15;
            /// <summary>
            /// Property Indexer for Year 
            /// </summary>
            public const int Year = 16;
            /// <summary>
            /// Property Indexer for Period 
            /// </summary>
            public const int Period = 17;
            /// <summary>
            /// Property Indexer for FuncOrVendorCurrency 
            /// </summary>
            public const int FuncOrVendorCurrency = 20;
            /// <summary>
            /// Property Indexer for ATBOrOverdueRecReport 
            /// </summary>
            public const int ATBOrOverdueRecReport = 34;
            /// <summary>
            /// Property Indexer for DetailOrSummaryReport 
            /// </summary>
            public const int DetailOrSummaryReport = 22;
            /// <summary>
            /// Property Indexer for Current 
            /// </summary>
            public const int Period1 = 28;
            /// <summary>
            /// Property Indexer for FirstPeriod 
            /// </summary>
            public const int Period2 = 29;
            /// <summary>
            /// Property Indexer for SecondPeriod 
            /// </summary>
            public const int Period3 = 30;
            /// <summary>
            /// Property Indexer for ThirdPeriod 
            /// </summary>
            public const int Period4 = 31;
            /// <summary>
            /// Property Indexer for Range1From 
            /// </summary>
            public const int Range1From = 3;
            /// <summary>
            /// Property Indexer for Range1To 
            /// </summary>
            public const int Range1To = 4;
            /// <summary>
            /// Property Indexer for Range1IndexValue 
            /// </summary>
            public const int Range1IndexValue = 35;
            /// <summary>
            /// Property Indexer for Range2From 
            /// </summary>
            public const int Range2From = 6;
            /// <summary>
            /// Property Indexer for Range2To 
            /// </summary>
            public const int Range2To = 7;
            /// <summary>
            /// Property Indexer for Range2IndexValue 
            /// </summary>
            public const int Range2IndexValue = 36;
            /// <summary>
            /// Property Indexer for Range3From 
            /// </summary>
            public const int Range3From = 9;
            /// <summary>
            /// Property Indexer for Range3To 
            /// </summary>
            public const int Range3To = 10;
            /// <summary>
            /// Property Indexer for Range3IndexValue 
            /// </summary>
            public const int Range3IndexValue = 37;
            /// <summary>
            /// Property Indexer for Range4From 
            /// </summary>
            public const int Range4From = 12;
            /// <summary>
            /// Property Indexer for Range4To 
            /// </summary>
            public const int Range4To = 13;
            /// <summary>
            /// Property Indexer for Range4IndexValue 
            /// </summary>
            public const int Range4IndexValue = 38;
            /// <summary>
            /// Property Indexer for SequenceNumber 
            /// </summary>
            public const int SequenceNumber = 33;
            /// <summary>
            /// Property Indexer for FieldName1 
            /// </summary>
            public const int Sort1 = 24;
            /// <summary>
            /// Property Indexer for FieldName2 
            /// </summary>
            public const int Sort2 = 25;
            /// <summary>
            /// Property Indexer for FieldName3 
            /// </summary>
            public const int Sort3 = 26;
            /// <summary>
            /// Property Indexer for FieldName4 
            /// </summary>
            public const int Sort4 = 27;
            /// <summary>
            /// Property Indexer for IncludeTaxes 
            /// </summary>
            public const int IncludeTaxes = 39;

            /// <summary>
            /// Property  Indexer for GRP1TOTAL 
            /// </summary>
            public const int Grp1Total = 40;


            /// <summary>
            /// Property  Indexer for GRP2TITLE 
            /// </summary>
            public const int Grp2Total = 41;


            /// <summary>
            /// Property  Indexer for GRP3TITLE 
            /// </summary>
            public const int Grp3Total = 42;


            /// <summary>
            /// Property  Indexer for GRP4TITLE 
            /// </summary>
            public const int Grp4Total = 43;

            /// <summary>
            /// Property  Indexer for GRP1TITLE 
            /// </summary>
            public const int Grp1Title = 44;


            /// <summary>
            /// Property  Indexer for GRP2TITLE 
            /// </summary>
            public const int Grp2Title = 45;


            /// <summary>
            /// Property  Indexer for GRP3TITLE 
            /// </summary>
            public const int Grp3Title = 46;


            /// <summary>
            /// Property  Indexer for GRP4TITLE 
            /// </summary>
            public const int Grp4Title = 47;



            /// <summary>
            /// Property  Indexer for Amount Type 
            /// </summary>
            public const int AmountType = 21;

            /// <summary>
            /// Property  Indexer for Report Title 
            /// </summary>
            public const int ReportTitle = 32;

            /// <summary>
            /// Property  Indexer for Sort order
            /// </summary>
            public const int Sortorder = 23;

            /// <summary>
            /// Property  Indexer for MultiCurrency
            /// </summary>
            public const int MultiCurrency = 14;

            /// <summary>
            /// Property  Indexer for Select1
            /// </summary>
            public const int Select1 = 2;

            /// <summary>
            /// Property  Indexer for Select2
            /// </summary>
            public const int Select2 = 5;

            /// <summary>
            /// Property  Indexer for Select3
            /// </summary>
            public const int Select3 = 8;
            /// <summary>
            /// Property  Indexer for Select4
            /// </summary>
            public const int Select4 = 11;

            #endregion
        }
    }
}
