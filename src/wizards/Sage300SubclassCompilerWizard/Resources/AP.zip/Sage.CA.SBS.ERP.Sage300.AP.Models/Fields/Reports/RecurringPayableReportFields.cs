// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Contains list of Recurring Payable Constants
    /// </summary>
    public partial class RecurringPayableReport
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "3b28f968-568d-4a0d-97cf-96342e8e0872";

        #region Properties
        /// <summary>
        /// Contains list of Recurring Payable Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Homecurn
            /// </summary>
            public const string Homecurn = "HOMECURN";

            /// <summary>
            /// Property for Fromcode
            /// </summary>
            public const string Fromcode = "FROMCODE";

            /// <summary>
            /// Property for Tocode
            /// </summary>
            public const string Tocode = "TOCODE";

            /// <summary>
            /// Property for Fromvend
            /// </summary>
            public const string Fromvend = "FROMVEND";

            /// <summary>
            /// Property for Tovend
            /// </summary>
            public const string Tovend = "TOVEND";

            /// <summary>
            /// Property for Schedule
            /// </summary>
            public const string Schedule = "SCHEDULE?";

            /// <summary>
            /// Property for Optflds
            /// </summary>
            public const string Optflds = "OPTFLDS?";

            /// <summary>
            /// Property for Swmulticurn
            /// </summary>
            public const string Swmulticurn = "SWMULTICURN";

            /// <summary>
            /// Property for Swglactive
            /// </summary>
            public const string Swglactive = "SWGLACTIVE";

            /// <summary>
            /// Property for Swpmactive
            /// </summary>
            public const string Swpmactive = "SWPMACTIVE";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of RecurringPayable Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Homecurn
            /// </summary>
            public const int Homecurn = 2;

            /// <summary>
            /// Property Indexer for Fromcode
            /// </summary>
            public const int Fromcode = 3;

            /// <summary>
            /// Property Indexer for Tocode
            /// </summary>
            public const int Tocode = 4;

            /// <summary>
            /// Property Indexer for Fromvend
            /// </summary>
            public const int Fromvend = 5;

            /// <summary>
            /// Property Indexer for Tovend
            /// </summary>
            public const int Tovend = 6;

            /// <summary>
            /// Property Indexer for Schedule
            /// </summary>
            public const int Schedule = 7;

            /// <summary>
            /// Property Indexer for Optflds
            /// </summary>
            public const int Optflds = 8;

            /// <summary>
            /// Property Indexer for Swmulticurn
            /// </summary>
            public const int Swmulticurn = 9;

            /// <summary>
            /// Property Indexer for Swglactive
            /// </summary>
            public const int Swglactive = 10;

            /// <summary>
            /// Property Indexer for Swpmactive
            /// </summary>
            public const int Swpmactive = 11;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 12;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 13;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 14;
        }
        #endregion
    }
}