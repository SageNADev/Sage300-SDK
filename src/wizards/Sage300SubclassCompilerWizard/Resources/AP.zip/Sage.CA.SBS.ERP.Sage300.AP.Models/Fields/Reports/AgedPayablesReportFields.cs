﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Contains list of Aged Payables Report Constants 
    /// </summary>
    public partial class AgedPayableReport
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "a0ea8318-41e2-49c3-acad-218255e3ad1b";

        #endregion

        /// <summary>
        /// Contains list of Aged Payables Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Select1 
            /// </summary>
            public const string Select1 = "SELECT1";

            /// <summary>
            ///  Property for From1 
            /// </summary>
            public const string From1 = "FROM1";

            /// <summary>
            /// Property for To1 
            /// </summary>
            public const string To1 = "TO1";

            /// <summary>
            /// Property for Select2 
            /// </summary>
            public const string Select2 = "SELECT2";

            /// <summary>
            /// Property for From2
            /// </summary>
            public const string From2 = "FROM2";

            /// <summary>
            /// Property for To2 
            /// </summary>
            public const string To2 = "TO2";

            /// <summary>
            /// Property for Select3 
            /// </summary>
            public const string Select3 = "SELECT3";

            /// <summary>
            /// Property for From3 
            /// </summary>
            public const string From3 = "FROM3";

            /// <summary>
            /// Property for To3 
            /// </summary>
            public const string To3 = "TO3";

            /// <summary>
            /// Property for Select4 
            /// </summary>
            public const string Select4 = "SELECT4";

            /// <summary>
            /// Property for From4 
            /// </summary>
            public const string From4 = "FROM4";

            /// <summary>
            /// Property for From4 
            /// </summary>
            public const string To4 = "TO4";

            /// <summary>
            /// Property for PhoneFormat 
            /// </summary>
            public const string PhoneFormat = "PHNFMT";

            /// <summary>
            /// Property for Sortorder 
            /// </summary>
            public const string Sortorder = "SORTORDER";

            /// <summary>
            /// Property for Multicurrency 
            /// </summary>
            public const string Multicurrency = "MCURCUST";

            /// <summary>
            /// Property for Cutoffby 
            /// </summary>
            public const string Cutoffby = "CUTOFFBY";

            /// <summary>
            /// Property for CUTOFFYEAR 
            /// </summary> 
            public const string Cutoffyear = "CUTOFFYEAR";

            /// <summary>
            ///  Property for CutoffPeriod 
            /// </summary>
            public const string CutoffPeriod = "CUTOFFPERD";

            /// <summary>
            ///  Property for AgeSequence 
            /// </summary>
            public const string AgeSequence = "AGESEQ";

            /// <summary>
            /// Property for Asofdate 
            /// </summary>
            public const string AgeasofDate = "ASOFDATE";

            /// <summary>
            /// Property for CutoffDate 
            /// </summary>
            public const string CutoffDate = "CUTOFFDT";

            /// <summary>
            /// Property for FunctionalCurrencyDecimal 
            /// </summary>
            public const string FunctionalCurrencyDecimal = "FCURNDEC";

            /// <summary>
            /// Property for Contact 
            /// </summary>
            public const string IncludeContact = "CONTACT";

            /// <summary>
            /// Property for AmountType 
            /// </summary>
            public const string AmountType = "AMTTYPE";

            /// <summary>
            /// Property for PrintReportType 
            /// </summary>
            public const string PrintReportType = "PRTTYPE";

            /// <summary>
            /// Property for IncludePaymentsOnHold 
            /// </summary>
            public const string IncludePaymentsOnHold = "ONHOLD";

            /// <summary>
            /// Property for Comment 
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for AppliedDetails 
            /// </summary>
            public const string AppliedDetails = "APPLDETL";

            /// <summary>
            /// Property for ReportTitle 
            /// </summary>
            public const string ReportTitle = "RPTTITLE";

            /// <summary>
            /// Property for Sort1 
            /// </summary>
            public const string Sort1 = "SORT1";

            /// <summary>
            /// Property for Sort2 
            /// </summary>
            public const string Sort2 = "SORT2";

            /// <summary>
            /// Property for Sort3 
            /// </summary>
            public const string Sort3 = "SORT3";

            /// <summary>
            /// Property for Sort4 
            /// </summary>
            public const string Sort4 = "SORT4";

            /// <summary>
            /// Property for ZeroBalance 
            /// </summary>
            public const string IncludeZeroBalance = "SWZEROBAL";

            /// <summary>
            /// Property for Type1 
            /// </summary>
            public const string Type1 = "TYPE1";

            /// <summary>
            /// Property for Type2 
            /// </summary>
            public const string Type2 = "TYPE2";

            /// <summary>
            /// Property for Type3 
            /// </summary>
            public const string Type3 = "TYPE3";

            /// <summary>
            /// Property for Type4 
            /// </summary>
            public const string Type4 = "TYPE4";

            /// <summary>
            /// Property for IncludePrePayment 
            /// </summary>
            public const string IncludePrePayment = "INCLPREPAY";

            /// <summary>
            /// Property for Period1 
            /// </summary>
            public const string Period1 = "PERIOD1";

            /// <summary>
            /// Property for Period2 
            /// </summary>
            public const string Period2 = "PERIOD2";

            /// <summary>
            /// Property for Period3 
            /// </summary>
            public const string Period3 = "PERIOD3";

            /// <summary>
            /// Property for Period4 
            /// </summary>
            public const string Period4 = "PERIOD4";

            /// <summary>
            /// Property for Group1Total 
            /// </summary>
            public const string Group1Total = "GRP1TOTAL";

            /// <summary>
            /// Property for Group2Total 
            /// </summary>
            public const string Group2Total = "GRP2TOTAL";

            /// <summary>
            /// Property for Group3Total 
            /// </summary>
            public const string Group3Total = "GRP3TOTAL";

            /// <summary>
            /// Property for Group4Total 
            /// </summary>
            public const string Group4Total = "GRP4TOTAL";

            /// <summary>
            /// Property for IncludeInvoice 
            /// </summary>
            public const string IncludeInvoice = "INVOICE";

            /// <summary>
            /// Property for IncludeDebit 
            /// </summary>
            public const string IncludeDebit = "DEBIT";

            /// <summary>
            /// Property for IncludeCredit 
            /// </summary>
            public const string IncludeCredit = "CREDIT";

            /// <summary>
            /// Property for IncludeInterest 
            /// </summary>
            public const string IncludeInterest = "INTEREST";

            /// <summary>
            /// Property for IncludePayment 
            /// </summary>
            public const string IncludePayment = "PAYMENT";

            /// <summary>
            /// Property for IncludeFullyPaid 
            /// </summary>
            public const string IncludeFullyPaid = "FULLYPAID";

            /// <summary>
            /// Property for FromDate 
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for FromYear 
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for FromPeriod 
            /// </summary>
            public const string FromPeriod = "FROMPERD";

            /// <summary>
            /// Property for IncludeAdjustment 
            /// </summary>
            public const string IncludeAdjustment = "ADJUSTMENT";

            /// <summary>
            /// Property for SortbyTransactionType 
            /// </summary>
            public const string SortByTransactionType = "SORTBYTRANSTYPE";

            /// <summary>
            /// Property for HasRetainage 
            /// </summary>
            public const string HasRetainage = "HASRTG";

            /// <summary>
            /// Property for AgeRetainage 
            /// </summary>
            public const string AgeRetainage = "AGERTG";

            /// <summary>
            /// Property for Group1Title 
            /// </summary>
            public const string Group1Title = "GRP1TITLE";
            /// <summary>
            /// 
            /// Property for Group2Title 
            /// </summary>
            public const string Group2Title = "GRP2TITLE";

            /// <summary>
            /// Property for Group3Title 
            /// </summary>
            public const string Group3Title = "GRP3TITLE";

            /// <summary>
            /// Property for Group4Title 
            /// </summary>
            public const string Group4Title = "GRP4TITLE";

            #endregion
        }
        
        /// <summary>
        /// Contains list of Aged Payables Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Select1
            /// </summary>
            public const int Select1 = 2;

            /// <summary>
            /// Property Indexer for From1
            /// </summary>
            public const int From1 = 3;

            /// <summary>
            /// Property Indexer for To1
            /// </summary>
            public const int To1 = 4;

            /// <summary>
            /// Property Indexer for Select2
            /// </summary>
            public const int Select2 = 5;

            /// <summary>
            ///  Property Indexer for From2
            /// </summary>
            public const int From2 = 6;

            /// <summary>
            /// Property Indexer for To2
            /// </summary>
            public const int To2 = 7;

            /// <summary>
            ///  Property Indexer for Select3
            /// </summary>
            public const int Select3 = 8;

            /// <summary>
            ///  Property Indexer for From3
            /// </summary>
            public const int From3 = 9;

            /// <summary>
            /// Property Indexer for To3
            /// </summary>
            public const int To3 = 10;

            /// <summary>
            ///  Property Indexer for Select4
            /// </summary>
            public const int Select4 = 11;

            /// <summary>
            ///  Property Indexer for From4
            /// </summary>
            public const int From4 = 12;

            /// <summary>
            /// Property Indexer for To4
            /// </summary>
            public const int To4 = 13;

            /// <summary>
            /// Property Indexer for PhoneFormat
            /// </summary>
            public const int PhoneFormat = 14;

            /// <summary>
            /// Property Indexer for Sortorder
            /// </summary>
            public const int Sortorder = 15;

            /// <summary>
            /// Property Indexer for Multicurrency
            /// </summary>
            public const int Multicurrency = 16;

            /// <summary>
            ///  Property Indexer for Cutoffby
            /// </summary>
            public const int Cutoffby = 17;

            /// <summary>
            ///  Property Indexer for Cutoffyear
            /// </summary>
            public const int Cutoffyear = 18;

            /// <summary>
            ///  Property Indexer for CutoffPeriod
            /// </summary>
            public const int CutoffPeriod = 19;

            /// <summary>
            /// Property Indexer for AgeSequence
            /// </summary>
            public const int AgeSequence = 20;

            /// <summary>
            /// Property Indexer for AsofDate
            /// </summary>
            public const int AgeasofDate = 21;

            /// <summary>
            /// Property Indexer for CutoffDate
            /// </summary>
            public const int CutoffDate = 22;

            /// <summary>
            /// Property Indexer for FunctionalCurrencyDecimal
            /// </summary>
            public const int FunctionalCurrencyDecimal = 23;

            /// <summary>
            /// Property Indexer for Contact
            /// </summary>
            public const int IncludeContact = 24;

            /// <summary>
            /// Property Indexer for AmountType
            /// </summary>
            public const int AmountType = 25;

            /// <summary>
            /// Property Indexer for PrintReportType
            /// </summary>
            public const int PrintReportType = 26;

            /// <summary>
            /// Property Indexer for IncludePaymentsOnHold
            /// </summary>
            public const int IncludePaymentsOnHold = 27;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 28;

            /// <summary>
            /// Property Indexer for AppliedDetails
            /// </summary>
            public const int AppliedDetails = 29;

            /// <summary>
            /// Property Indexer for ReportTitle
            /// </summary>
            public const int ReportTitle = 30;

            /// <summary>
            /// Property Indexer for Sort1
            /// </summary>
            public const int Sort1 = 31;

            /// <summary>
            /// Property Indexer for Sort2
            /// </summary>
            public const int Sort2 = 32;

            /// <summary>
            /// Property Indexer for Sort3
            /// </summary>
            public const int Sort3 = 33;

            /// <summary>
            /// Property Indexer for Sort4
            /// </summary>
            public const int Sort4 = 34;

            /// <summary>
            /// Property Indexer for ZeroBalance
            /// </summary>
            public const int IncludeZeroBalance = 35;

            /// <summary>
            /// Property Indexer for Type1
            /// </summary>
            public const int Type1 = 36;

            /// <summary>
            /// Property Indexer for Type2
            /// </summary>
            public const int Type2 = 37;

            /// <summary>
            /// Property Indexer for Type3
            /// </summary>
            public const int Type3 = 38;

            /// <summary>
            ///  Property Indexer for Type4
            /// </summary>
            public const int Type4 = 39;

            /// <summary>
            ///  Property Indexer for IncludePrePayment
            /// </summary>
            public const int IncludePrePayment = 40;

            /// <summary>
            ///  Property Indexer for Period1
            /// </summary>
            public const int Period1 = 41;

            /// <summary>
            ///  Property Indexer for Period2
            /// </summary>
            public const int Period2 = 42;

            /// <summary>
            ///   Property Indexer for Period3
            /// </summary>
            public const int Period3 = 43;

            /// <summary>
            ///   Property Indexer for Period4
            /// </summary>
            public const int Period4 = 44;

            /// <summary>
            ///   Property Indexer for Group1Total
            /// </summary>
            public const int Group1Total = 45;

            /// <summary>
            ///   Property Indexer for Group2Total
            /// </summary>
            public const int Group2Total = 46;

            /// <summary>
            ///   Property Indexer for Group3Total
            /// </summary>
            public const int Group3Total = 47;

            /// <summary>
            ///   Property Indexer for Group4Total
            /// </summary>
            public const int Group4Total = 48;

            /// <summary>
            /// Property Indexer for IncludeInvoice
            /// </summary>
            public const int IncludeInvoice = 49;

            /// <summary>
            /// Property Indexer for IncludeDebit
            /// </summary>
            public const int IncludeDebit = 50;

            /// <summary>
            ///  Property Indexer for IncludeCredit
            /// </summary>
            public const int IncludeCredit = 51;

            /// <summary>
            ///  Property Indexer for IncludeInterest
            /// </summary>
            public const int IncludeInterest = 52;

            /// <summary>
            ///  Property Indexer for IncludePayment
            /// </summary>
            public const int IncludePayment = 53;

            /// <summary>
            ///  Property Indexer for IncludeFullyPaid
            /// </summary>
            public const int IncludeFullyPaid = 54;

            /// <summary>
            /// Property Indexer for FromDate
            /// </summary>
            public const int FromDate = 55;

            /// <summary>
            ///  Property Indexer for FromYear
            /// </summary>
            public const int FromYear = 56;

            /// <summary>
            ///  Property Indexer for FromPeriod
            /// </summary>
            public const int FromPeriod = 57;

            /// <summary>
            ///  Property Indexer for IncludeAdjustment
            /// </summary>
            public const int IncludeAdjustment = 58;

            /// <summary>
            ///  Property Indexer for SortbyTransactionType
            /// </summary>
            public const int SortbyTransactionType = 59;

            /// <summary>
            ///  Property Indexer for HasRetainage
            /// </summary>
            public const int HasRetainage = 60;

            /// <summary>
            ///  Property Indexer for AgeRetainage
            /// </summary>
            public const int AgeRetainage = 61;

            /// <summary>
            ///  Property Indexer for Group1Title
            /// </summary> 
            public const int Group1Title = 62;

            /// <summary>
            ///  Property Indexer for Group2Title
            /// </summary>
            public const int Group2Title = 63;

            /// <summary>
            ///  Property Indexer for Group3Title
            /// </summary>
            public const int Group3Title = 64;

            /// <summary>
            ///  Property Indexer for Group4Title
            /// </summary>
            public const int Group4Title = 65;

            #endregion
        }
    }
}
