﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.ElectronicFiling
{
    /// <summary>
    /// Contains list of 1099 ElectronicFiling Constants 
    /// </summary>
    public partial class ElectronicFilingReport
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "A3D183DC-BF85-47D6-BAD3-2E105DD53F2D";

        /// <summary>
        /// Contains list of 1099 ElectronicFiling Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties

            /// <summary>
            /// Property for PaymentYear 
            /// </summary>
            public const string PaymentYear = "PAYMENTYEAR";

            /// <summary>
            /// Property for TrasmitterTaxNumber 
            /// </summary>
            public const string TrasmitterTaxNumber = "TRANSTIN";

            /// <summary>
            /// Property for ControlCode 
            /// </summary>
            public const string ControlCode = "TRANSCTRLCODE";

            /// <summary>
            /// Property for TestFile
            /// </summary>
            public const string TestFile = "TESTFILEFLAG";

            /// <summary>
            /// Property for TransmitterForeignEntity
            /// </summary>
            public const string TransmitterForeignEntity = "SWTRANSFOREIGN";

            /// <summary>
            /// Property for TransmitterName
            /// </summary>
            public const string TransmitterName = "TRANSNAME";

            /// <summary>
            /// Property for TransmitterCompany
            /// </summary>
            public const string TransmitterCompany = "TRANSCOMPANY";

            /// <summary>
            /// Property for TransmitterAddress
            /// </summary>
            public const string TransmitterAddress = "TRANSADDRESS";

            /// <summary>
            /// Property for TransmitterCity
            /// </summary>
            public const string TransmitterCity = "TRANSCITY";

            /// <summary>
            /// Property for TransmitterStateOrProvince
            /// </summary>
            public const string TransmitterStateOrProvince = "TRANSSTATE";

            /// <summary>
            /// Property for TransmitterZipOrPostalCode
            /// </summary>
            public const string TransmitterZipOrPostalCode = "TRANSZIP";

            /// <summary>
            /// Property for PayeeCount
            /// </summary>
            public const string PayeeCount = "PAYEECOUNT";

            /// <summary>
            /// Property for TransmitterContactName
            /// </summary>
            public const string TransmitterContactName = "TRANSCONTACTNAME";

            /// <summary>
            /// Property for TransmitterPhoneNumber
            /// </summary>
            public const string TransmitterPhoneNumber = "TRANSCONTACTPHONE";

            /// <summary>
            /// Property for TransmitterEmail
            /// </summary>
            public const string TransmitterEmail = "TRANSCONTACTEMAIL";

            /// <summary>
            /// Property for PayerTaxNumber
            /// </summary>
            public const string PayerTaxNumber = "PAYERTIN";

            /// <summary>
            /// Property for PayerFinalFiling
            /// </summary>
            public const string PayerFinalFiling = "SWFINALFILING";

            /// <summary>
            /// Property for PayerForeignEntity
            /// </summary>
            public const string PayerForeignEntity = "SWPAYERFOREIGN";

            /// <summary>
            /// Property for PayerNameControl
            /// </summary>
            public const string PayerNameControl = "PAYERNAME";

            /// <summary>
            /// Property for AgentName
            /// </summary>
            public const string AgentName = "AGENTNAME";

            /// <summary>
            /// Property for PayerTransferAgent
            /// </summary>
            public const string PayerTransferAgent = "SWXFERAGENT";

            /// <summary>
            /// Property for PayerAddress
            /// </summary>
            public const string PayerAddress = "PAYERADDRESS";
            
            /// <summary>
            /// Property for PayerCity
            /// </summary>
            public const string PayerCity = "PAYERCITY";
            
            /// <summary>
            /// Property for PayerStateOrProvince
            /// </summary>
            public const string PayerStateOrProvince = "PAYERSTATE";
            
            /// <summary>
            /// Property for PayerZipOrPostalCode
            /// </summary>
            public const string PayerZipOrPostalCode = "PAYERZIP";

            /// <summary>
            /// Property for PayerPhoneNumber
            /// </summary>
            public const string PayerPhoneNumber = "PAYERPHONE";

            /// <summary>
            /// Property for PayerOfficeBranch
            /// </summary>
            public const string PayerOfficeBranch = "PAYEROFFICE";
            
            /// <summary>
            /// Property for OutputFile
            /// </summary>
            public const string OutputFile = "FILENAME";

            #endregion
        }


        ///// <summary>
        ///// Contains list of 1099 ElectronicFiling Index Constants
        ///// </summary>
        //public class Index
        //{

        //    #region Properties

        //    /// <summary>
        //    /// Property Indexer for PaymentYear 
        //    /// </summary>
        //    public const int PaymentYear = 1;

        //    /// <summary>
        //    /// Property Indexer for TrasmitterTaxNumber 
        //    /// </summary>
        //    public const int TrasmitterTaxNumber = 2;

        //    /// <summary>
        //    /// Property Indexer for ControlCode 
        //    /// </summary>
        //    public const int ControlCode = 3;

        //    /// <summary>
        //    /// Property Indexer for TestFile
        //    /// </summary>
        //    public const int TestFile = 4;

        //    /// <summary>
        //    /// Property Indexer for TransmitterForeignEntity
        //    /// </summary>
        //    public const int TransmitterForeignEntity = 5;

        //    /// <summary>
        //    /// Property Indexer for TransmitterName
        //    /// </summary>
        //    public const int TransmitterName = 6;

        //    /// <summary>
        //    /// Property Indexer for TransmitterCompany
        //    /// </summary>
        //    public const int TransmitterCompany = 7;

        //    /// <summary>
        //    /// Property Indexer for TransmitterAddress
        //    /// </summary>
        //    public const int TransmitterAddress = 8;

        //    /// <summary>
        //    /// Property Indexer for TransmitterCity
        //    /// </summary>
        //    public const int TransmitterCity = 9;

        //    /// <summary>
        //    /// Property Indexer for TransmitterStateOrProvince
        //    /// </summary>
        //    public const int TransmitterStateOrProvince = 10;

        //    /// <summary>
        //    /// Property Indexer for TransmitterZipOrPostalCode
        //    /// </summary>
        //    public const int TransmitterZipOrPostalCode = 11;

        //    /// <summary>
        //    /// Property Indexer for PayeeCount
        //    /// </summary>
        //    public const int PayeeCount = 12;

        //    /// <summary>
        //    /// Property Indexer for TransmitterContactName
        //    /// </summary>
        //    public const int TransmitterContactName = 13;

        //    /// <summary>
        //    /// Property Indexer for TransmitterPhoneNumber
        //    /// </summary>
        //    public const int TransmitterPhoneNumber = 14;

        //    /// <summary>
        //    /// Property Indexer for TransmitterEmail
        //    /// </summary>
        //    public const int TransmitterEmail = 15;

        //    /// <summary>
        //    /// Property Indexer for PayerTaxNumber
        //    /// </summary>
        //    public const int PayerTaxNumber = 16;

        //    /// <summary>
        //    /// Property Indexer for PayerFinalFiling
        //    /// </summary>
        //    public const int PayerFinalFiling = 17;

        //    /// <summary>
        //    /// Property Indexer for PayerForeignEntity
        //    /// </summary>
        //    public const int PayerForeignEntity = 18;

        //    /// <summary>
        //    /// Property Indexer for PayerNameControl
        //    /// </summary>
        //    public const int PayerNameControl = 19;

        //    /// <summary>
        //    /// Property Indexer for AgentName
        //    /// </summary>
        //    public const int AgentName = 20;

        //    /// <summary>
        //    /// Property Indexer for PayerTransferAgent
        //    /// </summary>
        //    public const int PayerTransferAgent = 21;

        //    /// <summary>
        //    /// Property Indexer for PayerAddress
        //    /// </summary>
        //    public const int PayerAddress = 22;

        //    /// <summary>
        //    /// Property Indexer for PayerCity
        //    /// </summary>
        //    public const int PayerCity = 23;

        //    /// <summary>
        //    /// Property Indexer for PayerStateOrProvince
        //    /// </summary>
        //    public const int PayerStateOrProvince = 24;

        //    /// <summary>
        //    /// Property Indexer for PayerZipOrPostalCode
        //    /// </summary>
        //    public const int PayerZipOrPostalCode = 25;

        //    /// <summary>
        //    /// Property Indexer for PayerPhoneNumber
        //    /// </summary>
        //    public const int PayerPhoneNumber = 26;

        //    /// <summary>
        //    /// Property Indexer for PayerOfficeBranch
        //    /// </summary>
        //    public const int PayerOfficeBranch = 27;

        //    /// <summary>
        //    /// Property Indexer for OutputFile
        //    /// </summary>
        //    public const int OutputFile = 28;

        //    #endregion
        //}


    }
}
