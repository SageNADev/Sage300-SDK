// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 


// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports

{
    /// <summary>
    /// Contains list of PrintT5018CprsReport Constants 
    /// </summary>
    public partial class PrintT5018CprsReport
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "AP0111";

        /// <summary>
        /// Contains list of 1099CPRSAmountChecking Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for FromVendorNumber 
        /// </summary>
            public const string FromVendorNumber = "FromVen";
	            /// <summary>
        /// Property for ToVendorNumber 
        /// </summary>
            public const string ToVendorNumber = "ToVen";
	            /// <summary>
        /// Property for TaxReportingType 
        /// </summary>
	    public const string TaxReportingType  = "TAXRPTSW";
	            /// <summary>
        /// Property for FromCode 
        /// </summary>
        public const string FromCode = "CodeFrom";
	            /// <summary>
        /// Property for ToCode 
        /// </summary>
        public const string ToCode = "CodeTo";
	            /// <summary>
        /// Property for Year 
        /// </summary>
        public const string Year = "Year";
	            /// <summary>
        /// Property for Atleast one vendor has reportab 
        /// </summary>
	    public const string Atleastonevendorhasreportab  = "REPORTABLE";
	            /// <summary>
        /// Property for CommandCode 
        /// </summary>
	    public const string CommandCode  = "CMNDCODE";
	            /// <summary>
        /// Property for FileName 
        /// </summary>
	    public const string FileName  = "FILENAME";

        /// <summary>
        /// Property for FileName 
        /// </summary>
        public const string FederalTaxId = "FedId";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of PrintT5018CprsReport Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for FromVendorNumber 
        /// </summary>
	    public const int FromVendorNumber  = 1;
	             /// <summary>
        /// Property Indexer for ToVendorNumber 
        /// </summary>
	    public const int ToVendorNumber  = 2;
	             /// <summary>
        /// Property Indexer for TaxReportingType 
        /// </summary>
	    public const int TaxReportingType  = 3;
	             /// <summary>
        /// Property Indexer for FromCode 
        /// </summary>
	    public const int FromCode  = 4;
	             /// <summary>
        /// Property Indexer for ToCode 
        /// </summary>
	    public const int ToCode  = 5;
	             /// <summary>
        /// Property Indexer for Year 
        /// </summary>
	    public const int Year  = 6;
	             /// <summary>
        /// Property Indexer for Atleastonevendorhasreportab 
        /// </summary>
	    public const int Atleastonevendorhasreportab  = 7;
	             /// <summary>
        /// Property Indexer for CommandCode 
        /// </summary>
	    public const int CommandCode  = 8;
	             /// <summary>
        /// Property Indexer for FileName 
        /// </summary>
	    public const int FileName  = 9;

        /// <summary>
        /// The federal tax identifier
        /// </summary>
	     public const int FederalTaxId = 10;

		    #endregion
        }

	
	}
}
	