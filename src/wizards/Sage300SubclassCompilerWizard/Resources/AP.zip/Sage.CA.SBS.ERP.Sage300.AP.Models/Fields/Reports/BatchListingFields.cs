﻿/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports

{
    /// <summary>
    /// Contains list of BatchListingReport Constants 
    /// </summary>
    public partial class BatchListing
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "85178407-C7FD-44DB-9142-7ED8B2F039D3";

        #endregion

        /// <summary>
        /// Contains list of BatchListingReport Fields Constants 
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for Functional Currency Decimal 
            /// </summary>
            public const string FunctionalCurrDecimal = "FCURNDEC";

            /// <summary>
            /// Property for From Batch Number  
            /// </summary>
            public const string FromBatch = "FROMBATCH";

            /// <summary>
            /// Property for To Batch Number  
            /// </summary>
            public const string ToBatch = "TOBATCH";

            /// <summary>
            /// Property for FromDate  
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for ToDate  
            /// </summary>
            public const string ToDate = "TODATE";

            /// <summary>
            /// Property for Query  
            /// </summary>
            public const string Query = "QUERY";

            /// <summary>
            /// Property for BatchType  
            /// </summary>
            public const string BatchType = "BATCHTYPE";

            /// <summary>
            /// Property for BatchStatus  
            /// </summary>
            public const string BatchStatus = "BATCHSTATUS";

            /// <summary>
            /// Property for Schedule  
            /// </summary>
            public const string Schedule = "SCHED";

            /// <summary>
            /// Property for Reprint Previously Printed Batches
            /// </summary>
            public const string IncludePrinted = "INCLPRNDBTCH";

            /// <summary>
            /// Property for MultiCurrency
            /// </summary>
            public const string MultiCurrency = "MULTCURN";

            /// <summary>
            /// Property for TaxDetail  
            /// </summary>
            public const string TaxDetail = "TAXDETAIL";

            /// <summary>
            /// Property for Show Job Details
            /// </summary>
            public const string ShowJob = "SHOWJOB";

            /// <summary>
            /// Property for Switch PM Active  
            /// </summary>
            public const string SwitchPmActive = "SWPMACTIVE";

            /// <summary>
            /// Property for Contract  
            /// </summary>  
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project  
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category  
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Show Comments  
            /// </summary>
            public const string ShowCmts = "SHOWCMTS";

            /// <summary>
            /// Property for Optional Field  
            /// </summary>
            public const string OptionalField = "OPTFLDS?";

            /// <summary>
            /// Property for ZI MultiCurrency 
            /// </summary>
            public const string ZiMultiCurrency = "ZIMULTCURN";

            /// <summary>
            /// Property for Switch Retainage
            /// </summary>
            public const string SwitchRetainage = "SWRET";

            /// <summary>
            /// Property for Retainage Details
            /// </summary>
            public const string RetainageDetail = "RETDETAIL";

            /// <summary>
            /// Property for Home Currency
            /// </summary>
            public const string HomeCurrency = "HCURN";

            /// <summary>
            /// Property for Source
            /// </summary>
            public const string Source = "SOURCE";

            /// <summary>
            /// Property for Discount
            /// </summary>
            public const string Discount = "DISCOUNT";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "AMOUNT";

            /// <summary>
            /// Property for Allow Adjustments In PaymentBatch
            /// </summary>
            public const string AllowAdjustmentsInPaymentBat = "ADJ";

            /// <summary>
            /// Property for Bank
            /// </summary>
            public const string Bank = "BANK";

            /// <summary>
            /// Property for Is MultiCurrency Visible
            /// </summary>
            public const string IsMultiCurrency = "MULTIC";

            /// <summary>
            /// Property for System
            /// </summary>
            public const string System = "SYSTEM";

            /// <summary>
            /// Property for Show Adjustment Details  
            /// </summary>
            public const string ShowAdjDetails = "SWSHOWADJ";

            /// <summary>
            /// Property for Credit
            /// </summary>
            public const string Credit = "CREDIT";

            /// <summary>
            /// Property for Debit
            /// </summary>
            public const string Debit = "DEBIT";

            /// <summary>
            /// Property for Entered  
            /// </summary>
            public const string Entered = "ENTERED";

            /// <summary>
            /// Property for Imported  
            /// </summary>
            public const string Imported = "IMPORTED";

            /// <summary>
            /// Property for Recurring  
            /// </summary>
            public const string Recurring = "RECURRING";

            /// <summary>
            /// Property for Generated  
            /// </summary>
            public const string Generated = "GENERATED";

            /// <summary>
            /// Property for Open  
            /// </summary>
            public const string Open = "OPEN";

            /// <summary>
            /// Property for Readypost  
            /// </summary>
            public const string ReadyToPost = "READYPOST";

            /// <summary>
            /// Property for Posted  
            /// </summary>
            public const string Posted = "POSTED";

            /// <summary>
            /// Property for External  
            /// </summary>
            public const string External = "EXTERNAL";

            /// <summary>
            /// Property for Retainage  
            /// </summary>
            public const string Retainage = "RETAINAGE";

            /// <summary>
            /// Field for ShowRcWht
            /// </summary>
            public const string ShowRcWht = "ShowRcWht";

            #endregion
        }
    }
}


