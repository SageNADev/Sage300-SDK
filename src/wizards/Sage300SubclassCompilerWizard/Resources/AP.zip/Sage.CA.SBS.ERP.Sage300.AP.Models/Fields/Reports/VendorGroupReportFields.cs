// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Contains list of VendorGroupReport Constants
    /// </summary>
    public partial class VendorGroupReport
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "c31f1742-3524-4c25-8d58-77e8f9b3c59a";

        #region Properties
        /// <summary>
        /// Contains list of VendorGroupReport Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Fromyear
            /// </summary>
            public const string Fromyear = "FROMYEAR";

            /// <summary>
            /// Property for Toyear
            /// </summary>
            public const string Toyear = "TOYEAR";

            /// <summary>
            /// Property for Fromperd
            /// </summary>
            public const string Fromperd = "FROMPERD";

            /// <summary>
            /// Property for Toperd
            /// </summary>
            public const string Toperd = "TOPERD";

            /// <summary>
            /// Property for Fromgrp
            /// </summary>
            public const string Fromgrp = "FROMGRP";

            /// <summary>
            /// Property for Togrp
            /// </summary>
            public const string Togrp = "TOGRP";

            /// <summary>
            /// Property for Fcurndec
            /// </summary>
            public const string Fcurndec = "FCURNDEC";

            /// <summary>
            /// Property for Counts
            /// </summary>
            public const string Counts = "COUNTS?";

            /// <summary>
            /// Property for Phonefmt
            /// </summary>
            public const string Phonefmt = "PHONEFMT?";

            /// <summary>
            /// Property for Profile
            /// </summary>
            public const string Profile = "PROFILE?";

            /// <summary>
            /// Property for Members
            /// </summary>
            public const string Members = "MEMBERS?";

            /// <summary>
            /// Property for Optflds
            /// </summary>
            public const string Optflds = "OPTFLDS?";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of VendorGroupReport Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Fromyear
            /// </summary>
            public const int Fromyear = 2;

            /// <summary>
            /// Property Indexer for Toyear
            /// </summary>
            public const int Toyear = 3;

            /// <summary>
            /// Property Indexer for Fromperd
            /// </summary>
            public const int Fromperd = 4;

            /// <summary>
            /// Property Indexer for Toperd
            /// </summary>
            public const int Toperd = 5;

            /// <summary>
            /// Property Indexer for Fromgrp
            /// </summary>
            public const int Fromgrp = 6;

            /// <summary>
            /// Property Indexer for Togrp
            /// </summary>
            public const int Togrp = 7;

            /// <summary>
            /// Property Indexer for Fcurndec
            /// </summary>
            public const int Fcurndec = 8;

            /// <summary>
            /// Property Indexer for Counts
            /// </summary>
            public const int Counts = 9;

            /// <summary>
            /// Property Indexer for Counts
            /// </summary>
            public const int Phonefmt = 10;

            /// <summary>
            /// Property Indexer for Counts
            /// </summary>
            public const int Profile = 11;

            /// <summary>
            /// Property Indexer for Counts
            /// </summary>
            public const int Members = 12;

            /// <summary>
            /// Property Indexer for Counts
            /// </summary>
            public const int Optflds = 13;
        }
        #endregion
    }
}