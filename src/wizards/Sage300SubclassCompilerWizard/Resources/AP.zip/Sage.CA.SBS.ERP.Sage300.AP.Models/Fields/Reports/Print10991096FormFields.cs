// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Contains list of Print10991096Form Constants 
    /// </summary>
    public partial class Print10991096Form
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "FF06AC0E-06FB-4B46-B2EE-8DB6B703668C";

        #endregion

        /// <summary>
        /// Contains list of Print10991096Form Fields Constants
        /// </summary>
        public class Fields
        {
            
            #region Properties

            /// <summary>
            /// Property for FedId 
            /// </summary>
            public const string FedId = "FEDID";
            /// <summary>
            /// Property for ToVendorNumber 
            /// </summary>
            public const string Address1 = "ADDRESS1";
            /// <summary>
            /// Property for TaxReportingType 
            /// </summary>
            public const string Address2 = "ADDRESS2";
            /// <summary>
            /// Property for City 
            /// </summary>
            public const string City = "CITY";
            /// <summary>
            /// Property for State 
            /// </summary>
            public const string State = "STATE";
            /// <summary>
            /// Property for Zip 
            /// </summary>
            public const string Zip = "ZIP";
            /// <summary>
            /// Property for Country 
            /// </summary>
            public const string Country = "COUNTRY";
            /// <summary>
            /// Property for Contact 
            /// </summary>
            public const string Contact = "CONTACT";
            /// <summary>
            /// Property for Phone 
            /// </summary>
            public const string Phone = "PHONE";
            /// <summary>
            /// Property for Email 
            /// </summary>
            public const string Email = "EMAIL";
            /// <summary>
            /// Property for Fax 
            /// </summary>
            public const string Fax = "FAX";
            /// <summary>
            /// Property for FormatPhoneNumber 
            /// </summary>
            public const string FormatPhoneNumber = "PHNFORMAT";
            /// <summary>
            /// Property for FileName 
            /// </summary>
            public const string FileName = "FILENAME";
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string PayerName = "PAYERNAME";
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string PreaddressedForm = "PREADDRESSED";
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string FinalFiling = "FINALFILING";
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string TaxNumberType = "TAXNBRTYPE";
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string LegalName = "LEGALNAME";

            /// <summary>
            /// Property for FromVendorNumber 
            /// </summary>
            public const string FromVendorNumber = "FromVen";
            /// <summary>
            /// Property for ToVendorNumber 
            /// </summary>
            public const string ToVendorNumber = "ToVen"; 
            /// <summary>
            /// Property for Form Type 
            /// </summary>
            public const string FormType = "FormType"; 

            #endregion
        }


        /// <summary>
        /// Contains list of Print10991096From Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for FedId 
            /// </summary>
            public const int FedId = 2;
            /// <summary>
            /// Property Indexer for Address1 
            /// </summary>
            public const int Address1 = 3;
            /// <summary>
            /// Property Indexer for Address2 
            /// </summary>
            public const int Address2 = 4;
            /// <summary>
            /// Property Indexer for City 
            /// </summary>
            public const int City = 5;
            /// <summary>
            /// Property Indexer for State 
            /// </summary>
            public const int State = 6;
            /// <summary>
            /// Property Indexer for Zip 
            /// </summary>
            public const int Zip = 7;
            /// <summary>
            /// Property Indexer for Country 
            /// </summary>
            public const int Country = 8;
            /// <summary>
            /// Property Indexer for Contact 
            /// </summary>
            public const int Contact = 9;
            /// <summary>
            /// Property Indexer for Phone 
            /// </summary>
            public const int Phone = 10;
            /// <summary>
            /// Property Indexer for Email 
            /// </summary>
            public const int Email = 11;
            /// <summary>
            /// Property Indexer for Fax 
            /// </summary>
            public const int Fax = 12;
            /// <summary>
            /// Property Indexer for Fax 
            /// </summary>
            public const int FormatPhoneNumber = 13;
            /// <summary>
            /// Property Indexer for FileName 
            /// </summary>
            public const int FileName = 14;
            /// <summary>
            /// Property Indexer for PayerName 
            /// </summary>
            public const int PayerName = 15;
            /// <summary>
            /// Property Indexer for PreaddressedFrom 
            /// </summary>
            public const int PreaddressedForm = 16;
            /// <summary>
            /// Property Indexer for FinalFiling 
            /// </summary>
            public const int FinalFiling = 17;
            /// <summary>
            /// Property Indexer for TaxNumberType 
            /// </summary>
            public const int TaxNumberType = 18;
            /// <summary>
            /// Property Indexer for LegalName 
            /// </summary>
            public const int LegalName = 19;
            /// <summary>
            /// Property for Form Type
            /// </summary>
            public const int FormType = 20;
            #endregion
        }


    }
}
