﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PaymentInquiryReport
    {
        /// <summary>
        /// View Name - Guid
        /// </summary>
        public const string ViewName = "DC1AE95E-F988-48BC-ABB5-ABF81672909F";

        /// <summary>
        /// Payment Inquiry Report Field Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for IsShowMultiCurrency
            /// </summary>
            public const string IsShowMultiCurrency = "SWMULTICURN";

            /// <summary>
            /// Property for FuncationalCurrency
            /// </summary>
            public const string FunctionalCurrency = "FCURNDEC";

            /// <summary>
            /// Property for BankFrom
            /// </summary>
            public const string BankFrom = "IDBANKFROM";

            /// <summary>
            /// Property for BankTo
            /// </summary>
            public const string BankTo = "IDBANKTO";

            /// <summary>
            /// Property for VendorFrom
            /// </summary>
            public const string VendorFrom = "IDVENDFROM";

            /// <summary>
            /// Property for VendorTo
            /// </summary>
            public const string VendorTo = "IDVENDTO";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "SWCHKCLRD";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "TRXTYPETXT";

            /// <summary>
            /// Property for YearFrom
            /// </summary>
            public const string YearFrom = "YEARFROM";

            /// <summary>
            /// Property for YearTo
            /// </summary>
            public const string YearTo = "YEARTO";

            /// <summary>
            /// Property for PeriodFrom
            /// </summary>
            public const string PeriodFrom = "PERIODFROM";

            /// <summary>
            /// Property for PeriodTo
            /// </summary>
            public const string PeriodTo = "PERIODTO";

            /// <summary>
            /// Property for PaymentFrom
            /// </summary>
            public const string PaymentFrom = "DATEREMITFROM";

            /// <summary>
            /// Property for PaymentTo
            /// </summary>
            public const string PaymentTo = "DATEREMITTO";

            /// <summary>
            /// Gets or sets the CheckNumberFrom
            /// </summary>
            public const string CheckNumberFrom = "IDREMITFROM";

            /// <summary>
            /// Gets or sets the CheckNumberTo
            /// </summary>
            public const string CheckNumberTo = "IDREMITTO";

            /// <summary>
            /// Property for PaymentType
            /// </summary>
            public const string PaymentType = "PAYMTYPE";

            #endregion
        }

        /// <summary>
        /// Payment Inquiry Report Index Constants
        /// </summary>
        public class Index
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for IsShowMultiCurrency
            /// </summary>
            public const int IsShowMultiCurrency = 2;

            /// <summary>
            /// Property for FuncationalCurrency
            /// </summary>
            public const int FunctionalCurrency = 3;

            /// <summary>
            /// Property for BankFrom
            /// </summary>
            public const int BankFrom = 4;

            /// <summary>
            /// Property for BankTo
            /// </summary>
            public int BankTo = 5;

            /// <summary>
            /// Property for VendorFrom
            /// </summary>
            public const int VendorFrom = 6;

            /// <summary>
            /// Property for VendorTo
            /// </summary>
            public const int VendorTo = 7;

            /// <summary>
            /// Property for Status
            /// </summary>
            public const int Status = 8;

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const int TransactionType = 9;

            /// <summary>
            /// Property for YearFrom
            /// </summary>
            public const int YearFrom = 10;

            /// <summary>
            /// Property for YearTo
            /// </summary>
            public const int YearTo = 11;

            /// <summary>
            /// Property for PeriodFrom
            /// </summary>
            public const int PeriodFrom = 12;

            /// <summary>
            /// Property for PeriodTo
            /// </summary>
            public const int PeriodTo = 13;

            /// <summary>
            /// Property for PaymentFrom
            /// </summary>
            public const int PaymentFrom = 14;

            /// <summary>
            /// Property for PaymentTo
            /// </summary>
            public const int PaymentTo = 15;

            /// <summary>
            /// Gets or sets the CheckNumberFrom
            /// </summary>
            public const int CheckNumberFrom = 16;

            /// <summary>
            /// Gets or sets the CheckNumberTo
            /// </summary>
            public const int CheckNumberTo = 17;

            /// <summary>
            /// Property for PaymentType
            /// </summary>
            public const int PaymentType = 18;

            #endregion
        }
    }
}
