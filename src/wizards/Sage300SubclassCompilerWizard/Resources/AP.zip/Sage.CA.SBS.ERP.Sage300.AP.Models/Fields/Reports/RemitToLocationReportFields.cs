// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;
#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Contains list of RemitToLocation Report Constants
    /// </summary>
    public partial class RemitToLocationReport
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "8bab35b8-cc87-4aed-86ba-c18307bbdb8b";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>();
            }
        }

        #region Properties
        /// <summary>
        /// Contains list of RemitToLocation Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Fromvend
            /// </summary>
            public const string Fromvend = "FROMVEND";

            /// <summary>
            /// Property for Tovend
            /// </summary>
            public const string Tovend = "TOVEND";

            /// <summary>
            /// Property for Phonefmt
            /// </summary>
            public const string Phonefmt = "PHONEFMT?";

            /// <summary>
            /// Property for Address
            /// </summary>
            public const string Address = "ADDRESS?";

            /// <summary>
            /// Property for Optflds
            /// </summary>
            public const string Optflds = "OPTFLDS?";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of RemitToLocation Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Fromvend
            /// </summary>
            public const int Fromvend = 2;

            /// <summary>
            /// Property Indexer for Tovend
            /// </summary>
            public const int Tovend = 3;

            /// <summary>
            /// Property Indexer for Phonefmt
            /// </summary>
            public const int Phonefmt = 4;

            /// <summary>
            /// Property Indexer for Address
            /// </summary>
            public const int Address = 5;

            /// <summary>
            /// Property Indexer for Optflds
            /// </summary>
            public const int Optflds = 6;
        }
        #endregion
    }
}
