// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;
#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Contains list of BatchStatusReport Constants
    /// </summary>
    public partial class BatchStatusReport
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "76b3b1c9-0877-473b-82af-03295b6add4f";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>();
            }
        }

        #region Properties
        /// <summary>
        /// Contains list of BatchStatusReport Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Frombatch
            /// </summary>
            public const string Frombatch = "FROMBATCH";

            /// <summary>
            /// Property for Tobatch
            /// </summary>
            public const string Tobatch = "TOBATCH";

            /// <summary>
            /// Property for Batchtype
            /// </summary>
            public const string Batchtype = "BATCHTYPE";

            /// <summary>
            /// Property for Batchstatus
            /// </summary>
            public const string Batchstatus = "BATCHSTATUS";

            /// <summary>
            /// Property for Sortby
            /// </summary>
            public const string Sortby = "SORTBY";

            /// <summary>
            /// Property for Query
            /// </summary>
            public const string Query = "QUERY";

            /// <summary>
            /// Property for Fcurndec
            /// </summary>
            public const string Fcurndec = "FCURNDEC";

            /// <summary>
            /// Property for Fromdate
            /// </summary>
            public const string Fromdate = "FROMDATE";

            /// <summary>
            /// Property for Todate
            /// </summary>
            public const string Todate = "TODATE";

            /// <summary>
            /// Property for Entered
            /// </summary>
            public const string Entered = "ENTERED";

            /// <summary>
            /// Property for Imported
            /// </summary>
            public const string Imported = "IMPORTED";

            /// <summary>
            /// Property for Generated
            /// </summary>
            public const string Generated = "GENERATED";

            /// <summary>
            /// Property for Open
            /// </summary>
            public const string Open = "OPEN";

            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "PRINTED";

            /// <summary>
            /// Property for Posted
            /// </summary>
            public const string Posted = "POSTED";

            /// <summary>
            /// Property for Deleted
            /// </summary>
            public const string Deleted = "DELETED";

            /// <summary>
            /// Property for Postprog
            /// </summary>
            public const string Postprog = "POSTPROG";

            /// <summary>
            /// Property for Partpost
            /// </summary>
            public const string Partpost = "PARTPOST";

            /// <summary>
            /// Property for Readytopost
            /// </summary>
            public const string Readytopost = "READYTOPOST";

            /// <summary>
            /// Property for Inclprndbtch
            /// </summary>
            public const string Inclprndbtch = "INCLPRNDBTCH";

            /// <summary>
            /// Property for Recurring
            /// </summary>
            public const string Recurring = "RECURRING";

            /// <summary>
            /// Property for External
            /// </summary>
            public const string External = "EXTERNAL";

            /// <summary>
            /// Property for Retainage
            /// </summary>
            public const string Retainage = "RETAINAGE";

            /// <summary>
            /// Property for Multcurn
            /// </summary>
            public const string Multcurn = "MULTCURN";

            /// <summary>
            /// Property for Swziactive
            /// </summary>
            public const string Swziactive = "SWZIACTIVE";

            /// <summary>
            /// Property for Zimultcurn
            /// </summary>
            public const string Zimultcurn = "ZIMULTCURN";

            /// <summary>
            /// Property for Batchkind
            /// </summary>
            public const string Batchkind = "BATCHKIND";

            /// <summary>
            /// Property for System
            /// </summary>
            public const string System = "SYSTEM";

            /// <summary>
            /// Property for Checkcreate
            /// </summary>
            public const string Checkcreate = "CHECKCREATE";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "STATUS";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of BatchStatusReport Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Frombatch
            /// </summary>
            public const int Frombatch = 2;

            /// <summary>
            /// Property Indexer for Tobatch
            /// </summary>
            public const int Tobatch = 3;

            /// <summary>
            /// Property Indexer for Batchtype
            /// </summary>
            public const int Batchtype = 4;

            /// <summary>
            /// Property Indexer for Batchstatus
            /// </summary>
            public const int Batchstatus = 5;

            /// <summary>
            /// Property Indexer for Sortby
            /// </summary>
            public const int Sortby = 6;

            /// <summary>
            /// Property Indexer for Query
            /// </summary>
            public const int Query = 7;

            /// <summary>
            /// Property Indexer for Fcurndec
            /// </summary>
            public const int Fcurndec = 8;

            /// <summary>
            /// Property Indexer for Fromdate
            /// </summary>
            public const int Fromdate = 9;

            /// <summary>
            /// Property Indexer for Todate
            /// </summary>
            public const int Todate = 10;

            /// <summary>
            /// Property Indexer for Entered
            /// </summary>
            public const int Entered = 11;

            /// <summary>
            /// Property Indexer for Imported
            /// </summary>
            public const int Imported = 12;

            /// <summary>
            /// Property Indexer for Generated
            /// </summary>
            public const int Generated = 13;

            /// <summary>
            /// Property Indexer for Open
            /// </summary>
            public const int Open = 14;

            /// <summary>
            /// Property Indexer for Printed
            /// </summary>
            public const int Printed = 15;

            /// <summary>
            /// Property Indexer for Posted
            /// </summary>
            public const int Posted = 16;

            /// <summary>
            /// Property Indexer for Deleted
            /// </summary>
            public const int Deleted = 17;

            /// <summary>
            /// Property Indexer for Postprog
            /// </summary>
            public const int Postprog = 18;

            /// <summary>
            /// Property Indexer for Partpost
            /// </summary>
            public const int Partpost = 19;

            /// <summary>
            /// Property Indexer for Readytopost
            /// </summary>
            public const int Readytopost = 20;

            /// <summary>
            /// Property Indexer for Inclprndbtch
            /// </summary>
            public const int Inclprndbtch = 21;

            /// <summary>
            /// Property Indexer for Recurring
            /// </summary>
            public const int Recurring = 22;

            /// <summary>
            /// Property Indexer for External
            /// </summary>
            public const int External = 23;

            /// <summary>
            /// Property Indexer for Retainage
            /// </summary>
            public const int Retainage = 24;

            /// <summary>
            /// Property Indexer for Multcurn
            /// </summary>
            public const int Multcurn = 25;

            /// <summary>
            /// Property Indexer for Swziactive
            /// </summary>
            public const int Swziactive = 26;

            /// <summary>
            /// Property Indexer for Zimultcurn
            /// </summary>
            public const int Zimultcurn = 27;

            /// <summary>
            /// Property Indexer for Batchkind
            /// </summary>
            public const int Batchkind = 28;

            /// <summary>
            /// Property Indexer for System
            /// </summary>
            public const int System = 29;

            /// <summary>
            /// Property Indexer for Checkcreate
            /// </summary>
            public const int Checkcreate = 30;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 31;
        }
        #endregion
    }
}
