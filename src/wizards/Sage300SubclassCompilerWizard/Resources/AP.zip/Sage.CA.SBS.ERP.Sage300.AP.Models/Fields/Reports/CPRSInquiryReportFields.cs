// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports

{
    /// <summary>
    /// Contains list of CPRSInquiry Report Fields Constants 
    /// </summary>
    public partial class CPRSInquiryReportFields
    {
        /// <summary>
        /// Entiry Name
        /// </summary>
        public const string EntityName = "AP0111";

        /// <summary>
        /// Contains list of CPRSInquiry Report Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for FromVendorNumber 
            /// </summary>
            public const string FromVendorNumber = "FROMVEND";

            /// <summary>
            /// Property for ToVendorNumber 
            /// </summary> 
            public const string ToVendorNumber = "TOVEND";

            /// <summary>
            /// Property for FromCode 
            /// </summary>
            public const string FromCode = "FROMCODE";

            /// <summary>
            /// Property for ToCode 
            /// </summary>
            public const string ToCode = "TOCODE";

            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string Year = "YEAR";
 
            #endregion
        }


        /// <summary>
        /// Contains list of CPRSInquiry Report Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for FromVendorNumber 
            /// </summary>
            public const int FromVendorNumber =2;

            /// <summary>
            /// Property Indexer for ToVendorNumber 
            /// </summary>
            public const int ToVendorNumber = 3;

            /// <summary>
            /// Property Indexer for FromCode 
            /// </summary> 
            public const int FromCode = 4;

            /// <summary>
            /// Property Indexer for ToCode 
            /// </summary> 
            public const int ToCode = 5;

            /// <summary>
            /// Property Indexer for Year 
            /// </summary>
            public const int Year = 6; 

            #endregion
        }


    }
}
	