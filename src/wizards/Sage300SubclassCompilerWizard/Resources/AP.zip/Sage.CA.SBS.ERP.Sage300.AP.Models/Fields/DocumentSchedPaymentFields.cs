// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of DocumentSchedPayment Constants 
    /// </summary>
    public partial class DocumentSchedPayment
    {
        #region Public Variables

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0026";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of DocumentSched.Payments Fields Constants
        /// </summary>
        public class Fields
        {          
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";

            /// <summary>
            /// Property for DocumentNumber 
            /// </summary>
            public const string DocumentNumber = "IDINVC";

            /// <summary>
            /// Property for PaymentNumber 
            /// </summary>
            public const string PaymentNumber = "CNTPAYM";

            /// <summary>
            /// Property for CheckNumber 
            /// </summary>
            public const string CheckNumber = "IDRMIT";

            /// <summary>
            /// Property for DueDate 
            /// </summary>
            public const string DueDate = "DATEDUE";

            /// <summary>
            /// Property for DiscountDate 
            /// </summary>
            public const string DiscountDate = "DATEDISC";

            /// <summary>
            /// Property for FullyPaid 
            /// </summary>
            public const string FullyPaid = "SWPAID";

            /// <summary>
            /// Property for OriginalAmountFunc 
            /// </summary>
            public const string OriginalAmountFunc = "AMTDUEHC";

            /// <summary>
            /// Property for OriginalDiscountFunc 
            /// </summary>
            public const string OriginalDiscountFunc = "AMTDISCHC";

            /// <summary>
            /// Property for RemainingDiscountFunc 
            /// </summary>
            public const string RemainingDiscountFunc = "AMTDCSRMHC";

            /// <summary>
            /// Property for RemainingAmountFunc 
            /// </summary>
            public const string RemainingAmountFunc = "AMTPYMRMHC";

            /// <summary>
            /// Property for OriginalAmount 
            /// </summary>
            public const string OriginalAmount = "AMTDUETC";

            /// <summary>
            /// Property for OriginalDiscount 
            /// </summary>
            public const string OriginalDiscount = "AMTDISCTC";

            /// <summary>
            /// Property for RemainingDiscount 
            /// </summary>
            public const string RemainingDiscount = "AMTDSCRMTC";

            /// <summary>
            /// Property for RemainingAmount 
            /// </summary>
            public const string RemainingAmount = "AMTPYMRMTC";

            /// <summary>
            /// Property for OrderNumber 
            /// </summary>
            public const string OrderNumber = "IDORDRNBR";

            /// <summary>
            /// Property for PONumber 
            /// </summary>
            public const string PONumber = "IDPONBR";

            /// <summary>
            /// Property for GroupCode 
            /// </summary>
            public const string GroupCode = "IDGRP";

            /// <summary>
            /// Property for PrepayInvoiceNumber 
            /// </summary>
            public const string PrepayInvoiceNumber = "IDPREPAID";

            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "IDTRXTYPE";

            /// <summary>
            /// Property for DocumentType 
            /// </summary>
            public const string DocumentType = "TXTTRXTYPE";

            /// <summary>
            /// Property for DocumentDate 
            /// </summary>
            public const string DocumentDate = "DATEINVC";

            /// <summary>
            /// Property for ActivationDate 
            /// </summary>
            public const string ActivationDate = "DATEACTV";

            /// <summary>
            /// Property for NumberofDaystoPay 
            /// </summary>
            public const string NumberofDaystoPay = "DAYSTOPAY";

            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelated = "SWJOB";

            /// <summary>
            /// Property for PaymentLimit 
            /// </summary>
            public const string PaymentLimit = "AMTPYMLMTC";

            /// <summary>
            /// Property for OriginalDocNo 
            /// </summary>
            public const string OriginalDocNo = "RTGAPPLYTO";
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of DocumentSched.Payments Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 1;

            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 2;

            /// <summary>
            /// Property Indexer for PaymentNumber 
            /// </summary>
            public const int PaymentNumber = 3;

            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int CheckNumber = 4;

            /// <summary>
            /// Property Indexer for DueDate 
            /// </summary>
            public const int DueDate = 5;

            /// <summary>
            /// Property Indexer for DiscountDate 
            /// </summary>
            public const int DiscountDate = 6;

            /// <summary>
            /// Property Indexer for FullyPaid 
            /// </summary>
            public const int FullyPaid = 7;

            /// <summary>
            /// Property Indexer for OriginalAmountFunc 
            /// </summary>
            public const int OriginalAmountFunc = 9;

            /// <summary>
            /// Property Indexer for OriginalDiscountFunc 
            /// </summary>
            public const int OriginalDiscountFunc = 10;

            /// <summary>
            /// Property Indexer for RemainingDiscountFunc 
            /// </summary>
            public const int RemainingDiscountFunc = 11;

            /// <summary>
            /// Property Indexer for RemainingAmountFunc 
            /// </summary>
            public const int RemainingAmountFunc = 12;

            /// <summary>
            /// Property Indexer for OriginalAmount 
            /// </summary>
            public const int OriginalAmount = 13;

            /// <summary>
            /// Property Indexer for OriginalDiscount 
            /// </summary>
            public const int OriginalDiscount = 14;

            /// <summary>
            /// Property Indexer for RemainingDiscount 
            /// </summary>
            public const int RemainingDiscount = 15;

            /// <summary>
            /// Property Indexer for RemainingAmount 
            /// </summary>
            public const int RemainingAmount = 16;

            /// <summary>
            /// Property Indexer for OrderNumber 
            /// </summary>
            public const int OrderNumber = 17;

            /// <summary>
            /// Property Indexer for PONumber 
            /// </summary>
            public const int PONumber = 18;

            /// <summary>
            /// Property Indexer for GroupCode 
            /// </summary>
            public const int GroupCode = 20;

            /// <summary>
            /// Property Indexer for PrepayInvoiceNumber 
            /// </summary>
            public const int PrepayInvoiceNumber = 21;

            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 22;

            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 23;

            /// <summary>
            /// Property Indexer for DocumentDate 
            /// </summary>
            public const int DocumentDate = 24;

            /// <summary>
            /// Property Indexer for ActivationDate 
            /// </summary>
            public const int ActivationDate = 29;

            /// <summary>
            /// Property Indexer for NumberofDaystoPay 
            /// </summary>
            public const int NumberofDaystoPay = 30;

            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 31;

            /// <summary>
            /// Property Indexer for PaymentLimit 
            /// </summary>
            public const int PaymentLimit = 32;

            /// <summary>
            /// Property Indexer for OriginalDocNo 
            /// </summary>
            public const int OriginalDocNo = 33;
        }

        #endregion
    }
}