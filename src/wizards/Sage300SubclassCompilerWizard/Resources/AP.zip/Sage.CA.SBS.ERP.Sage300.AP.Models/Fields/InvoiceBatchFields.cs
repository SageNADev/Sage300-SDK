// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of InvoiceBatch Constants 
    /// </summary>
    public partial class InvoiceBatch
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0020";
        
        #region Fields

        /// <summary>
        /// Contains list of InvoiceBatch Fields Constants
        /// </summary>
        public partial class Fields : BaseFields
        {
            #region Properties

            /// <summary>
            /// Property for ICTRelated 
            /// </summary>
            public const string ICTRelated = "SWICT";


            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of InvoiceBatch Fields Constants
        /// </summary>
        public partial class Index : BaseIndex
        {
            #region Properties


            /// <summary>
            /// Property Indexer for ICTRelated 
            /// </summary>
            public const int ICTRelated = 15;
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 16;

            #endregion
           
        }

        #endregion
    }

}
