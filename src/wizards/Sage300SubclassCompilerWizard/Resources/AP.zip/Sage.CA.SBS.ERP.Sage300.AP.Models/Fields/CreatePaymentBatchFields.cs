﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of CreatePaymentBatch Constants 
    /// </summary>
    public partial class CreatePaymentBatch
    {
        #region Public Constants

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string ViewName = "AP0035";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of CreatePaymentBatch Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for SelectionCriteria 
            /// </summary>
            public const string SelectionCriteria = "IDSELECT";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASMNT";

            /// <summary>
            /// Property for DocumentstoProcess 
            /// </summary>
            public const string DocumentstoProcess = "SWDOCSPROC";

            /// <summary>
            /// Property for SelectDocumentsby 
            /// </summary>
            public const string SelectDocumentsby = "SWSELLBY";

            /// <summary>
            /// Property for DateDue 
            /// </summary>
            public const string DateDue = "DATEDUE";

            /// <summary>
            /// Property for FromDiscountDate 
            /// </summary>
            public const string FromDiscountDate = "DTEDISCFRM";

            /// <summary>
            /// Property for FromGroupCode 
            /// </summary>
            public const string FromGroupCode = "IDGRPFROM";

            /// <summary>
            /// Property for ThruGroupCode 
            /// </summary>
            public const string ThruGroupCode = "IDGRPTHRU";

            /// <summary>
            /// Property for FromVendorNumber 
            /// </summary>
            public const string FromVendorNumber = "IDVENDFROM";

            /// <summary>
            /// Property for ThruVendorNumber 
            /// </summary>
            public const string ThruVendorNumber = "IDVENDTHRU";

            /// <summary>
            /// Property for FromAccountSet 
            /// </summary>
            public const string FromAccountSet = "ACCTSETFR";

            /// <summary>
            /// Property for ThruAccountSet 
            /// </summary>
            public const string ThruAccountSet = "ACCTSETTHR";

            /// <summary>
            /// Property for ExcludeVendor 
            /// </summary>
            public const string ExcludeVendor = "SWVENDEXCL";

            /// <summary>
            /// Property for IdBankAsgn
            /// </summary>
            public const string IdBankAsgn = "IDBANKASGN";

            /// <summary>
            /// Property for VendorCurrencyCode 
            /// </summary>
            public const string VendorCurrencyCode = "CODECURNTC";

            /// <summary>
            /// Property for PaymentBankCode 
            /// </summary>
            public const string PaymentBankCode = "IDBANKPAYM";

            /// <summary>
            /// Property for BankCurrencyCode 
            /// </summary>
            public const string BankCurrencyCode = "CODECURNPY";

            /// <summary>
            /// Property for AmtBankLmt 
            /// </summary>
            public const string AmtBankLmt = "AMTBNKLIMT";

            /// <summary>
            /// Property for MinimumPaymentAmount 
            /// </summary>
            public const string MinimumPaymentAmount = "AMTMINCHK";

            /// <summary>
            /// Property for MaximumPaymentAmount 
            /// </summary>
            public const string MaximumPaymentAmount = "AMTMAXCHK";

            /// <summary>
            /// Property for BankMatch 
            /// </summary>
            public const string BankMatch = "SWBANKMTCH";

            /// <summary>
            /// Property for PaymentDate 
            /// </summary>
            public const string PaymentDate = "DATECHECK";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "DATEINACT";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "SWACTV";

            /// <summary>
            /// Property for VendorRateType 
            /// </summary>
            public const string VendorRateType = "CODERATETC";

            /// <summary>
            /// Property for BankRateType 
            /// </summary>
            public const string BankRateType = "CODERATEBC";

            /// <summary>
            /// Property for VendorExchangeRate 
            /// </summary>
            public const string VendorExchangeRate = "EXCHRATETC";

            /// <summary>
            /// Property for BankExchangeRate 
            /// </summary>
            public const string BankExchangeRate = "EXCHRATEBC";

            /// <summary>
            /// Property for VendorRateDate 
            /// </summary>
            public const string VendorRateDate = "RATEDATETC";

            /// <summary>
            /// Property for BankRateDate 
            /// </summary>
            public const string BankRateDate = "RATEDATEBC";

            /// <summary>
            /// Property for CSVFilename 
            /// </summary>
            public const string CsvFilename = "CSVFILE";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";

            /// <summary>
            /// Property for ThruDiscountDate 
            /// </summary>
            public const string ThruDiscountDate = "DTEDISCTHR";

            /// <summary>
            /// Property for BatchDate 
            /// </summary>
            public const string BatchDate = "DTEBATCH";

            /// <summary>
            /// Property for VendorRateOperator 
            /// </summary>
            public const string VendorRateOperator = "RATEOPTC";

            /// <summary>
            /// Property for BankRateOperator 
            /// </summary>
            public const string BankRateOperator = "RATEOPBC";

            /// <summary>
            /// Property for VendorRateOverridden 
            /// </summary>
            public const string VendorRateOverridden = "SWRATETC";

            /// <summary>
            /// Property for BankRateOverridden 
            /// </summary>
            public const string BankRateOverridden = "SWRATEBC";

            /// <summary>
            /// Property for JobApplyMethod 
            /// </summary>
            public const string JobApplyMethod = "APPLYMETH";

            /// <summary>
            /// Property for GeneratedSelectionCriteria 
            /// </summary>
            public const string GeneratedSelectionCriteria = "IDSELECTED";

            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for FromPaymentCode 
            /// </summary>
            public const string FromPaymentCode = "PMCODEFROM";

            /// <summary>
            /// Property for ThruPaymentCode 
            /// </summary>
            public const string ThruPaymentCode = "PMCODETHRU";

            /// <summary>
            /// Property for OptionalField 
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Length 
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Decimals 
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for FromOptionalFieldValue 
            /// </summary>
            public const string FromOptionalFieldValue = "VALUEFROM";

            /// <summary>
            /// Property for ThruOptionalFieldValue 
            /// </summary>
            public const string ThruOptionalFieldValue = "VALUETHRU";

            /// <summary>
            /// Property for BatchStatus 
            /// </summary>
            public const string BatchStatus = "BATCHSTAT";

            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "BTCHTYPE";

            /// <summary>
            /// Property for BatchSelector 
            /// </summary>
            public const string BatchSelector = "PAYMTYPE";

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of CreatePaymentBatch Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for SelectionCriteria 
            /// </summary>
            public const int SelectionCriteria = 1;

            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 2;

            /// <summary>
            /// Property Indexer for DocumentstoProcess 
            /// </summary>
            public const int DocumentstoProcess = 3;

            /// <summary>
            /// Property Indexer for SelectDocumentsby 
            /// </summary>
            public const int SelectDocumentsby = 4;

            /// <summary>
            /// Property Indexer for DateDue 
            /// </summary>
            public const int DateDue = 5;

            /// <summary>
            /// Property Indexer for FromDiscountDate 
            /// </summary>
            public const int FromDiscountDate = 6;

            /// <summary>
            /// Property Indexer for FromGroupCode 
            /// </summary>
            public const int FromGroupCode = 7;

            /// <summary>
            /// Property Indexer for ThruGroupCode 
            /// </summary>
            public const int ThruGroupCode = 8;

            /// <summary>
            /// Property Indexer for FromVendorNumber 
            /// </summary>
            public const int FromVendorNumber = 9;

            /// <summary>
            /// Property Indexer for ThruVendorNumber 
            /// </summary>
            public const int ThruVendorNumber = 10;

            /// <summary>
            /// Property Indexer for FromAccountSet 
            /// </summary>
            public const int FromAccountSet = 11;

            /// <summary>
            /// Property Indexer for ThruAccountSet 
            /// </summary>
            public const int ThruAccountSet = 12;

            /// <summary>
            /// Property Indexer for ExcludeVendor 
            /// </summary>
            public const int ExcludeVendor = 13;

            /// <summary>
            /// Property Indexer for IdBankAsgn 
            /// </summary>
            public const int IdBankAsgn = 14;

            /// <summary>
            /// Property Indexer for VendorCurrencyCode 
            /// </summary>
            public const int VendorCurrencyCode = 15;

            /// <summary>
            /// Property Indexer for PaymentBankCode 
            /// </summary>
            public const int PaymentBankCode = 16;

            /// <summary>
            /// Property Indexer for BankCurrencyCode 
            /// </summary>
            public const int BankCurrencyCode = 17;

            /// <summary>
            /// Property Indexer for AmtBankLmt
            /// </summary>
            public const int AmtBankLmt = 19;

            /// <summary>
            /// Property Indexer for MinimumPaymentAmount 
            /// </summary>
            public const int MinimumPaymentAmount = 20;

            /// <summary>
            /// Property Indexer for MaximumPaymentAmount 
            /// </summary>
            public const int MaximumPaymentAmount = 21;

            /// <summary>
            /// Property Indexer for BankMatch 
            /// </summary>
            public const int BankMatch = 22;

            /// <summary>
            /// Property Indexer for PaymentDate 
            /// </summary>
            public const int PaymentDate = 23;

            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 24;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 25;

            /// <summary>
            /// Property Indexer for VendorRateType 
            /// </summary>
            public const int VendorRateType = 26;

            /// <summary>
            /// Property Indexer for BankRateType 
            /// </summary>
            public const int BankRateType = 27;

            /// <summary>
            /// Property Indexer for VendorExchangeRate 
            /// </summary>
            public const int VendorExchangeRate = 28;

            /// <summary>
            /// Property Indexer for BankExchangeRate 
            /// </summary>
            public const int BankExchangeRate = 29;

            /// <summary>
            /// Property Indexer for VendorRateDate 
            /// </summary>
            public const int VendorRateDate = 30;

            /// <summary>
            /// Property Indexer for BankRateDate 
            /// </summary>
            public const int BankRateDate = 31;

            /// <summary>
            /// Property Indexer for CSVFilename 
            /// </summary>
            public const int CsvFilename = 32;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 33;

            /// <summary>
            /// Property Indexer for ThruDiscountDate 
            /// </summary>
            public const int ThruDiscountDate = 34;

            /// <summary>
            /// Property Indexer for BatchDate 
            /// </summary>
            public const int BatchDate = 35;

            /// <summary>
            /// Property Indexer for VendorRateOperator 
            /// </summary>
            public const int VendorRateOperator = 36;

            /// <summary>
            /// Property Indexer for BankRateOperator 
            /// </summary>
            public const int BankRateOperator = 37;

            /// <summary>
            /// Property Indexer for VendorRateOverridden 
            /// </summary>
            public const int VendorRateOverridden = 38;

            /// <summary>
            /// Property Indexer for BankRateOverridden 
            /// </summary>
            public const int BankRateOverridden = 39;

            /// <summary>
            /// Property Indexer for JobApplyMethod 
            /// </summary>
            public const int JobApplyMethod = 40;

            /// <summary>
            /// Property Indexer for GeneratedSelectionCriteria 
            /// </summary>
            public const int GeneratedSelectionCriteria = 41;

            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 42;

            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 43;

            /// <summary>
            /// Property Indexer for FromPaymentCode 
            /// </summary>
            public const int FromPaymentCode = 44;

            /// <summary>
            /// Property Indexer for ThruPaymentCode 
            /// </summary>
            public const int ThruPaymentCode = 45;

            /// <summary>
            /// Property Indexer for OptionalField 
            /// </summary>
            public const int OptionalField = 46;

            /// <summary>
            /// Property Indexer for Type 
            /// </summary>
            public const int Type = 47;

            /// <summary>
            /// Property Indexer for Length 
            /// </summary>
            public const int Length = 48;

            /// <summary>
            /// Property Indexer for Decimals 
            /// </summary>
            public const int Decimals = 49;

            /// <summary>
            /// Property Indexer for FromOptionalFieldValue 
            /// </summary>
            public const int FromOptionalFieldValue = 50;

            /// <summary>
            /// Property Indexer for ThruOptionalFieldValue 
            /// </summary>
            public const int ThruOptionalFieldValue = 51;

            #endregion
        }

        #endregion
    }
}