/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of TermsCodes Constants 
    /// </summary>
    public partial class TermCodeHeader
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0012";

        /// <summary>
        /// Contains list of Terms Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties

            /// <summary>
            /// Property for TermsCode 
            /// </summary>
            public const string TermsCode = "TERMSCODE";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "CODEDESC";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "SWACTV";

            /// <summary>
            /// Property for Status string value 
            /// </summary>
            public const string StatusInText = "SWACTV";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "DATEINACTV";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for UsePaymentSchedule 
            /// </summary>
            public const string UsePaymentSchedule = "SWMULTPAYM";

            /// <summary>
            /// Property for UsePaymentScheduleInText 
            /// </summary>
            public const string UsePaymentScheduleInText = "SWMULTPAYM";

            /// <summary>
            /// Property for CalcBaseforDiscountwithTax 
            /// </summary>
            public const string CalcBaseforDiscountwithTax = "CODEVAT";

            /// <summary>
            /// Property for CalcBaseforDiscountwithTaxInText 
            /// </summary>
            public const string CalcBaseforDiscountwithTaxInText = "CODEVAT";

            /// <summary>
            /// Property for MethodofCalcforDiscountDate 
            /// </summary>
            public const string MethodofCalcforDiscountDate = "CODEDISTYP";

            /// <summary>
            /// Property for MethodofCalcforDiscountDateString 
            /// </summary>
            public const string MethodofCalcforDiscountDateString = "CODEDISTYP";

            /// <summary>
            /// Property for DiscountTableStartingDay1 
            /// </summary>
            public const string DiscountTableStartingDay1 = "DISDAYSTR1";

            /// <summary>
            /// Property for DiscountTableStartingDay2 
            /// </summary>
            public const string DiscountTableStartingDay2 = "DISDAYSTR2";

            /// <summary>
            /// Property for DiscountTableStartingDay3 
            /// </summary>
            public const string DiscountTableStartingDay3 = "DISDAYSTR3";

            /// <summary>
            /// Property for DiscountTableStartingDay4 
            /// </summary>
            public const string DiscountTableStartingDay4 = "DISDAYSTR4";
            /// <summary>
            /// Property for DiscountTableEndingDay1 
            /// </summary>
            public const string DiscountTableEndingDay1 = "DISDAYEND1";
            /// <summary>
            /// Property for DiscountTableEndingDay2 
            /// </summary>
            public const string DiscountTableEndingDay2 = "DISDAYEND2";
            /// <summary>
            /// Property for DiscountTableEndingDay3 
            /// </summary>
            public const string DiscountTableEndingDay3 = "DISDAYEND3";
            /// <summary>
            /// Property for DiscountTableEndingDay4 
            /// </summary>
            public const string DiscountTableEndingDay4 = "DISDAYEND4";
            /// <summary>
            /// Property for DiscountTableAddMonths1 
            /// </summary>
            public const string DiscountTableAddMonths1 = "DISMTHADD1";
            /// <summary>
            /// Property for DiscountTableAddMonths2 
            /// </summary>
            public const string DiscountTableAddMonths2 = "DISMTHADD2";
            /// <summary>
            /// Property for DiscountTableAddMonths3 
            /// </summary>
            public const string DiscountTableAddMonths3 = "DISMTHADD3";
            /// <summary>
            /// Property for DiscountTableAddMonths4 
            /// </summary>
            public const string DiscountTableAddMonths4 = "DISMTHADD4";
            /// <summary>
            /// Property for DiscountTableDayofMonth1 
            /// </summary>
            public const string DiscountTableDayofMonth1 = "DISDAYUSE1";
            /// <summary>
            /// Property for DiscountTableDayofMonth2 
            /// </summary>
            public const string DiscountTableDayofMonth2 = "DISDAYUSE2";
            /// <summary>
            /// Property for DiscountTableDayofMonth3 
            /// </summary>
            public const string DiscountTableDayofMonth3 = "DISDAYUSE3";
            /// <summary>
            /// Property for DiscountTableDayofMonth4 
            /// </summary>
            public const string DiscountTableDayofMonth4 = "DISDAYUSE4";
            /// <summary>
            /// Property for MethodofCalcforDueDate 
            /// </summary>
            public const string MethodofCalcforDueDate = "CODEDUETYP";
            /// <summary>
            /// Property for DueTableStartingDay1 
            /// </summary>
            public const string DueTableStartingDay1 = "DUEDAYSTR1";
            /// <summary>
            /// Property for DueTableStartingDay2 
            /// </summary>
            public const string DueTableStartingDay2 = "DUEDAYSTR2";
            /// <summary>
            /// Property for DueTableStartingDay3 
            /// </summary>
            public const string DueTableStartingDay3 = "DUEDAYSTR3";
            /// <summary>
            /// Property for DueTableStartingDay4 
            /// </summary>
            public const string DueTableStartingDay4 = "DUEDAYSTR4";
            /// <summary>
            /// Property for DueTableEndingDay1 
            /// </summary>
            public const string DueTableEndingDay1 = "DUEDAYEND1";
            /// <summary>
            /// Property for DueTableEndingDay2 
            /// </summary>
            public const string DueTableEndingDay2 = "DUEDAYEND2";
            /// <summary>
            /// Property for DueTableEndingDay3 
            /// </summary>
            public const string DueTableEndingDay3 = "DUEDAYEND3";
            /// <summary>
            /// Property for DueTableEndingDay4 
            /// </summary>
            public const string DueTableEndingDay4 = "DUEDAYEND4";
            /// <summary>
            /// Property for DueTableAddMonths1 
            /// </summary>
            public const string DueTableAddMonths1 = "DUEMTHADD1";
            /// <summary>
            /// Property for DueTableAddMonths2 
            /// </summary>
            public const string DueTableAddMonths2 = "DUEMTHADD2";
            /// <summary>
            /// Property for DueTableAddMonths3 
            /// </summary>
            public const string DueTableAddMonths3 = "DUEMTHADD3";
            /// <summary>
            /// Property for DueTableAddMonths4 
            /// </summary>
            public const string DueTableAddMonths4 = "DUEMTHADD4";
            /// <summary>
            /// Property for DueTableDayofMonth1 
            /// </summary>
            public const string DueTableDayofMonth1 = "DUEDAYUSE1";
            /// <summary>
            /// Property for DueTableDayofMonth2 
            /// </summary>
            public const string DueTableDayofMonth2 = "DUEDAYUSE2";
            /// <summary>
            /// Property for DueTableDayofMonth3 
            /// </summary>
            public const string DueTableDayofMonth3 = "DUEDAYUSE3";
            /// <summary>
            /// Property for DueTableDayofMonth4 
            /// </summary>
            public const string DueTableDayofMonth4 = "DUEDAYUSE4";
            /// <summary>
            /// Property for NumberofPayments 
            /// </summary>
            public const string NumberofPayments = "CNTENTERED";
            /// <summary>
            /// Property for TotalPercentageDue 
            /// </summary>
            public const string TotalPercentageDue = "PCTDUETOT";

            #endregion
        }


        /// <summary>
        /// Contains list of Terms Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for TermsCode 
            /// </summary>
            public const int TermsCode = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;
            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 4;
            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 5;
            /// <summary>
            /// Property Indexer for UsePaymentSchedule 
            /// </summary>
            public const int UsePaymentSchedule = 6;
            /// <summary>
            /// Property Indexer for CalcBaseforDiscountwithTax 
            /// </summary>
            public const int CalcBaseforDiscountwithTax = 7;
            /// <summary>
            /// Property Indexer for MethodofCalcforDiscountDate 
            /// </summary>
            public const int MethodofCalcforDiscountDate = 8;
            /// <summary>
            /// Property Indexer for DiscountTableStartingDay1 
            /// </summary>
            public const int DiscountTableStartingDay1 = 9;
            /// <summary>
            /// Property Indexer for DiscountTableStartingDay2 
            /// </summary>
            public const int DiscountTableStartingDay2 = 10;
            /// <summary>
            /// Property Indexer for DiscountTableStartingDay3 
            /// </summary>
            public const int DiscountTableStartingDay3 = 11;
            /// <summary>
            /// Property Indexer for DiscountTableStartingDay4 
            /// </summary>
            public const int DiscountTableStartingDay4 = 12;
            /// <summary>
            /// Property Indexer for DiscountTableEndingDay1 
            /// </summary>
            public const int DiscountTableEndingDay1 = 13;
            /// <summary>
            /// Property Indexer for DiscountTableEndingDay2 
            /// </summary>
            public const int DiscountTableEndingDay2 = 14;
            /// <summary>
            /// Property Indexer for DiscountTableEndingDay3 
            /// </summary>
            public const int DiscountTableEndingDay3 = 15;
            /// <summary>
            /// Property Indexer for DiscountTableEndingDay4 
            /// </summary>
            public const int DiscountTableEndingDay4 = 16;
            /// <summary>
            /// Property Indexer for DiscountTableAddMonths1 
            /// </summary>
            public const int DiscountTableAddMonths1 = 17;
            /// <summary>
            /// Property Indexer for DiscountTableAddMonths2 
            /// </summary>
            public const int DiscountTableAddMonths2 = 18;
            /// <summary>
            /// Property Indexer for DiscountTableAddMonths3 
            /// </summary>
            public const int DiscountTableAddMonths3 = 19;
            /// <summary>
            /// Property Indexer for DiscountTableAddMonths4 
            /// </summary>
            public const int DiscountTableAddMonths4 = 20;
            /// <summary>
            /// Property Indexer for DiscountTableDayofMonth1 
            /// </summary>
            public const int DiscountTableDayofMonth1 = 21;
            /// <summary>
            /// Property Indexer for DiscountTableDayofMonth2 
            /// </summary>
            public const int DiscountTableDayofMonth2 = 22;
            /// <summary>
            /// Property Indexer for DiscountTableDayofMonth3 
            /// </summary>
            public const int DiscountTableDayofMonth3 = 23;
            /// <summary>
            /// Property Indexer for DiscountTableDayofMonth4 
            /// </summary>
            public const int DiscountTableDayofMonth4 = 24;
            /// <summary>
            /// Property Indexer for MethodofCalcforDueDate 
            /// </summary>
            public const int MethodofCalcforDueDate = 25;
            /// <summary>
            /// Property Indexer for DueTableStartingDay1 
            /// </summary>
            public const int DueTableStartingDay1 = 26;
            /// <summary>
            /// Property Indexer for DueTableStartingDay2 
            /// </summary>
            public const int DueTableStartingDay2 = 27;
            /// <summary>
            /// Property Indexer for DueTableStartingDay3 
            /// </summary>
            public const int DueTableStartingDay3 = 28;
            /// <summary>
            /// Property Indexer for DueTableStartingDay4 
            /// </summary>
            public const int DueTableStartingDay4 = 29;
            /// <summary>
            /// Property Indexer for DueTableEndingDay1 
            /// </summary>
            public const int DueTableEndingDay1 = 30;
            /// <summary>
            /// Property Indexer for DueTableEndingDay2 
            /// </summary>
            public const int DueTableEndingDay2 = 31;
            /// <summary>
            /// Property Indexer for DueTableEndingDay3 
            /// </summary>
            public const int DueTableEndingDay3 = 32;
            /// <summary>
            /// Property Indexer for DueTableEndingDay4 
            /// </summary>
            public const int DueTableEndingDay4 = 33;
            /// <summary>
            /// Property Indexer for DueTableAddMonths1 
            /// </summary>
            public const int DueTableAddMonths1 = 34;
            /// <summary>
            /// Property Indexer for DueTableAddMonths2 
            /// </summary>
            public const int DueTableAddMonths2 = 35;
            /// <summary>
            /// Property Indexer for DueTableAddMonths3 
            /// </summary>
            public const int DueTableAddMonths3 = 36;
            /// <summary>
            /// Property Indexer for DueTableAddMonths4 
            /// </summary>
            public const int DueTableAddMonths4 = 37;
            /// <summary>
            /// Property Indexer for DueTableDayofMonth1 
            /// </summary>
            public const int DueTableDayofMonth1 = 38;
            /// <summary>
            /// Property Indexer for DueTableDayofMonth2 
            /// </summary>
            public const int DueTableDayofMonth2 = 39;
            /// <summary>
            /// Property Indexer for DueTableDayofMonth3 
            /// </summary>
            public const int DueTableDayofMonth3 = 40;
            /// <summary>
            /// Property Indexer for DueTableDayofMonth4 
            /// </summary>
            public const int DueTableDayofMonth4 = 41;
            /// <summary>
            /// Property Indexer for NumberofPayments 
            /// </summary>
            public const int NumberofPayments = 42;
            /// <summary>
            /// Property Indexer for TotalPercentageDue 
            /// </summary>
            public const int TotalPercentageDue = 43;

            #endregion
        }
    }
}
