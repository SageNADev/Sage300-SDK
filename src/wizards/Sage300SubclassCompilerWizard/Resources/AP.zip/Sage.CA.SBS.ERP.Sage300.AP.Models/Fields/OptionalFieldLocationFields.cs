// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of OptionalFieldLocations Constants 
    /// </summary>
    public partial class OptionalFieldLocation 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "AP0501";

        /// <summary>
        /// Contains list of OptionalFieldLocations Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for Location 
        /// </summary>
	    public const string Location  = "LOCATION";
	            /// <summary>
        /// Property for NumberofValues 
        /// </summary>
	    public const string NumberofValues  = "VALUES";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of OptionalFieldLocations Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for Location 
        /// </summary>
	    public const int Location  = 1;
	             /// <summary>
        /// Property Indexer for NumberofValues 
        /// </summary>
	    public const int NumberofValues  = 2;
	     
        #endregion
	    }

	
	}
}
	