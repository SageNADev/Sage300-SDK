// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PaymentAdjustmentOptionalFiel Constants 
    /// </summary>
    public partial class PaymentAdjustmentOptionalField
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0406";

        /// <summary>
        /// Contains list of PaymentAdjustmentOptionalFiel Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for BatchType 
        /// </summary>
	    public const string BatchType  = "BTCHTYPE";
	            /// <summary>
        /// Property for BatchNumber 
        /// </summary>
	    public const string BatchNumber  = "CNTBTCH";
	            /// <summary>
        /// Property for EntryNumber 
        /// </summary>
	    public const string EntryNumber  = "CNTENTR";
	            /// <summary>
        /// Property for OptionalField 
        /// </summary>
	    public const string OptionalField  = "OPTFIELD";
	            /// <summary>
        /// Property for Value 
        /// </summary>
	    public const string Value  = "VALUE";
	            /// <summary>
        /// Property for Type 
        /// </summary>
	    public const string Type  = "TYPE";
        public const string TypeString = "TYPE";
            
	            /// <summary>
        /// Property for Length 
        /// </summary>
	    public const string Length  = "LENGTH";
	            /// <summary>
        /// Property for Decimals 
        /// </summary>
	    public const string Decimals  = "DECIMALS";
	            /// <summary>
        /// Property for AllowBlank 
        /// </summary>
	    public const string AllowBlank  = "ALLOWNULL";
	            /// <summary>
        /// Property for Validate 
        /// </summary>
	    public const string Validate  = "VALIDATE";
	            /// <summary>
        /// Property for ValueSet 
        /// </summary>
	    public const string ValueSet  = "SWSET";
        public const string ValueSetString = "SWSET";
	            /// <summary>
        /// Property for TypedValueFieldIndex 
        /// </summary>
	    public const string TypedValueFieldIndex  = "VALINDEX";
	            /// <summary>
        /// Property for TextValue 
        /// </summary>
	    public const string TextValue  = "VALIFTEXT";
	            /// <summary>
        /// Property for AmountValue 
        /// </summary>
	    public const string AmountValue  = "VALIFMONEY";
	            /// <summary>
        /// Property for NumberValue 
        /// </summary>
	    public const string NumberValue  = "VALIFNUM";
	            /// <summary>
        /// Property for IntegerValue 
        /// </summary>
	    public const string IntegerValue  = "VALIFLONG";
	            /// <summary>
        /// Property for YesOrNoValue 
        /// </summary>
	    public const string YesOrNoValue  = "VALIFBOOL";
        public const string YesOrNoValueString = "VALIFBOOL";
	            /// <summary>
        /// Property for DateValue 
        /// </summary>
	    public const string DateValue  = "VALIFDATE";
	            /// <summary>
        /// Property for TimeValue 
        /// </summary>
	    public const string TimeValue  = "VALIFTIME";
	            /// <summary>
        /// Property for OptionalFieldDescription 
        /// </summary>
	    public const string OptionalFieldDescription  = "FDESC";
	            /// <summary>
        /// Property for ValueDescription 
        /// </summary>
	    public const string ValueDescription  = "VDESC";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of PaymentAdjustmentOptionalFiel Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for BatchType 
        /// </summary>
	    public const int BatchType  = 1;
	             /// <summary>
        /// Property Indexer for BatchNumber 
        /// </summary>
	    public const int BatchNumber  = 2;
	             /// <summary>
        /// Property Indexer for EntryNumber 
        /// </summary>
	    public const int EntryNumber  = 3;
	             /// <summary>
        /// Property Indexer for OptionalField 
        /// </summary>
	    public const int OptionalField  = 4;
	             /// <summary>
        /// Property Indexer for Value 
        /// </summary>
	    public const int Value  = 5;
	             /// <summary>
        /// Property Indexer for Type 
        /// </summary>
	    public const int Type  = 6;
	             /// <summary>
        /// Property Indexer for Length 
        /// </summary>
	    public const int Length  = 7;
	             /// <summary>
        /// Property Indexer for Decimals 
        /// </summary>
	    public const int Decimals  = 8;
	             /// <summary>
        /// Property Indexer for AllowBlank 
        /// </summary>
	    public const int AllowBlank  = 9;
	             /// <summary>
        /// Property Indexer for Validate 
        /// </summary>
	    public const int Validate  = 10;
	             /// <summary>
        /// Property Indexer for ValueSet 
        /// </summary>
	    public const int ValueSet  = 11;
	             /// <summary>
        /// Property Indexer for TypedValueFieldIndex 
        /// </summary>
	    public const int TypedValueFieldIndex  = 20;
	             /// <summary>
        /// Property Indexer for TextValue 
        /// </summary>
	    public const int TextValue  = 21;
	             /// <summary>
        /// Property Indexer for AmountValue 
        /// </summary>
	    public const int AmountValue  = 22;
	             /// <summary>
        /// Property Indexer for NumberValue 
        /// </summary>
	    public const int NumberValue  = 23;
	             /// <summary>
        /// Property Indexer for IntegerValue 
        /// </summary>
	    public const int IntegerValue  = 24;
	             /// <summary>
        /// Property Indexer for YesOrNoValue 
        /// </summary>
	    public const int YesOrNoValue  = 25;
	             /// <summary>
        /// Property Indexer for DateValue 
        /// </summary>
	    public const int DateValue  = 26;
	             /// <summary>
        /// Property Indexer for TimeValue 
        /// </summary>
	    public const int TimeValue  = 27;
	             /// <summary>
        /// Property Indexer for OptionalFieldDescription 
        /// </summary>
	    public const int OptionalFieldDescription  = 28;
	             /// <summary>
        /// Property Indexer for ValueDescription 
        /// </summary>
	    public const int ValueDescription  = 29;
	     
        #endregion
	    }

	
	}
}
	