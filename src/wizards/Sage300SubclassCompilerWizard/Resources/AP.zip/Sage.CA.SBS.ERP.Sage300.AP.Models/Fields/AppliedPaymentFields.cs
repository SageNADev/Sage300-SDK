/* Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of AppliedPayments Constants 
    /// </summary>
	public partial class AppliedPayment 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AP0033";

        /// <summary>
        /// Contains list of AppliedPayments Fields Constants
        /// </summary>
	    public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "BATCHTYPE";
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTRMIT";
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "CNTLINE";
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";
            /// <summary>
            /// Property for DocumentNumber 
            /// </summary>
            public const string DocumentNumber = "IDINVC";
            /// <summary>
            /// Property for PaymentNumber 
            /// </summary>
            public const string PaymentNumber = "CNTPAYM";
            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TRXTYPE";
            /// <summary>
            /// Property for PaymentResolution 
            /// </summary>
            public const string PaymentResolution = "PYMTRESL";
            /// <summary>
            /// Property for PaymentAmount 
            /// </summary>
            public const string PaymentAmount = "AMTPAYM";
            /// <summary>
            /// Property for DiscountAmountTaken 
            /// </summary>
            public const string DiscountAmountTaken = "AMTERNDISC";
            /// <summary>
            /// Property for NextAdjSeqNo 
            /// </summary>
            public const string NextAdjSeqNo = "CNTLASTSEQ";
            /// <summary>
            /// Property for AdjustmentsTotal 
            /// </summary>
            public const string AdjustmentsTotal = "AMTADJTOT";
            /// <summary>
            /// Property for GeneratedAdjustmentNumber 
            /// </summary>
            public const string GeneratedAdjustmentNumber = "CNTADJ";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTADJ";
            /// <summary>
            /// Property for Reference 
            /// </summary>
            public const string Reference = "GLREF";
            /// <summary>
            /// Property for GeneratedPPNo 
            /// </summary>
            public const string GeneratedPPNo = "IDPPD";
            /// <summary>
            /// Property for PPMatchingDocNo 
            /// </summary>
            public const string PPMatchingDocNo = "IDDOCMTCH";
            /// <summary>
            /// Property for PPMatchingDocType 
            /// </summary>
            public const string PPMatchingDocType = "CDAPPLYTO";
            /// <summary>
            /// Property for ActivationDate 
            /// </summary>
            public const string ActivationDate = "DATEACTVPP";
            /// <summary>
            /// Property for DocumentAmountDue 
            /// </summary>
            public const string DocumentAmountDue = "OBSPAYMAMT";
            /// <summary>
            /// Property for DiscountAmountAvailable 
            /// </summary>
            public const string DiscountAmountAvailable = "OBSDISCAMT";
            /// <summary>
            /// Property for DocumentNetBalance 
            /// </summary>
            public const string DocumentNetBalance = "OBSNETBAL";
            /// <summary>
            /// Property for PendingPaymentAmount 
            /// </summary>
            public const string PendingPaymentAmount = "PNDPAYTOT";
            /// <summary>
            /// Property for PendingDiscountAmount 
            /// </summary>
            public const string PendingDiscountAmount = "PNDDSCTOT";
            /// <summary>
            /// Property for PendingAdjustmentAmount 
            /// </summary>
            public const string PendingAdjustmentAmount = "PNDADJTOT";
            /// <summary>
            /// Property for AdjDebitAmtVendCurr 
            /// </summary>
            public const string AdjDebitAmtVendCurr = "ADJTOTDBTC";
            /// <summary>
            /// Property for AdjCreditAmtVendCurr 
            /// </summary>
            public const string AdjCreditAmtVendCurr = "ADJTOTCRTC";
            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelated = "SWJOB";
            /// <summary>
            /// Property for JobTotalPaymentAmount 
            /// </summary>
            public const string JobTotalPaymentAmount = "AMTPAYMTOT";
            /// <summary>
            /// Property for JobTotalDiscountAmount 
            /// </summary>
            public const string JobTotalDiscountAmount = "AMTDISCTOT";
            /// <summary>
            /// Property for JobApplyMethod 
            /// </summary>
            public const string JobApplyMethod = "APPLYMETH";
            /// <summary>
            /// Property for RtgDebitAmtVendCurr 
            /// </summary>
            public const string RtgDebitAmtVendCurr = "RTGTOTDBTC";
            /// <summary>
            /// Property for RtgCreditAmtVendCurr 
            /// </summary>
            public const string RtgCreditAmtVendCurr = "RTGTOTCRTC";
            /// <summary>
            /// Property for RetainageAmount 
            /// </summary>
            public const string RetainageAmount = "RTGAMT";
            /// <summary>
            /// Property for RetainageDueDate 
            /// </summary>
            public const string RetainageDueDate = "RTGDATEDUE";
            /// <summary>
            /// Property for RetainageTermsCode 
            /// </summary>
            public const string RetainageTermsCode = "RTGTERMS";
            /// <summary>
            /// Property for RetainageExchangeRate 
            /// </summary>
            public const string RetainageExchangeRate = "SWRTGRATE";
            /// <summary>
            /// Property for ProcessCommand 
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";
            /// <summary>
            /// Property for UnappliedJobPaymentAmount 
            /// </summary>
            public const string UnappliedJobPaymentAmount = "UNAPLPAYM";
            /// <summary>
            /// Property for UnappliedJobDiscountAmount 
            /// </summary>
            public const string UnappliedJobDiscountAmount = "UNAPLDISC";
            /// <summary>
            /// Property for VendorCurrencyCode 
            /// </summary>
            public const string VendorCurrencyCode = "CODECURN";
            /// <summary>
            /// Property for PaymentDate 
            /// </summary>
            public const string PaymentDate = "DATERMIT";
            /// <summary>
            /// Property for DocumentType 
            /// </summary>
            public const string DocumentType = "DOCTYPE";
            /// <summary>
            /// Property for PaymentType 
            /// </summary>
            public const string PaymentType = "RMITTYPE";
            /// <summary>
            /// Property for HasRetainage 
            /// </summary>
            public const string HasRetainage = "SWRTG";
            /// <summary>
            /// Property for RetainageBalance 
            /// </summary>
            public const string RetainageBalance = "RTGBAL";
            /// <summary>
            /// Property for OriginalDocNo 
            /// </summary>
            public const string OriginalDocNo = "RTGAPPLYTO";
            /// <summary>
            /// Property for PayablesAdjustmentTotal 
            /// </summary>
            public const string PayablesAdjustmentTotal = "AMTADJNET";
            /// <summary>
            /// Property for OriginalExchangeRate 
            /// </summary>
            public const string OriginalExchangeRate = "EXCHRATEHC";
            /// <summary>
            /// Property for DocDate 
            /// </summary>
            public const string DocDate = "DATEINVC";
            /// <summary>
            /// Property for FuncPaymentAmount 
            /// </summary>
            public const string FuncPaymentAmount = "AMTPAYMHC";
            /// <summary>
            /// Property for FuncDiscountAmount 
            /// </summary>
            public const string FuncDiscountAmount = "AMTDISCHC";
            /// <summary>
            /// Property for FuncAdjustmentsTotal 
            /// </summary>
            public const string FuncAdjustmentsTotal = "AMTADJHC";
            /// <summary>
            /// Property for FuncRetainageAmount 
            /// </summary>
            public const string FuncRetainageAmount = "RTGAMTHC";
            /// <summary>
            /// Property for DocVersionCreatedIn 
            /// </summary>
            public const string DocVersionCreatedIn = "APVERSION";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHD1TC = "AMTWHD1TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHD2TC = "AMTWHD2TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHD3TC = "AMTWHD3TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHD4TC = "AMTWHD4TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHD5TC = "AMTWHD5TC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHD1HC = "AMTWHD1HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHD2HC = "AMTWHD2HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHD3HC = "AMTWHD3HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHD4HC = "AMTWHD4HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHD5HC = "AMTWHD5HC";

            /// <summary>
            /// Property For Job Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHD1DT = "AMTWHD1DT";

            /// <summary>
            /// Property For Job Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHD2DT = "AMTWHD2DT";

            /// <summary>
            /// Property For Job Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHD3DT = "AMTWHD3DT";

            /// <summary>
            /// Property For Job Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHD4DT = "AMTWHD4DT";

            /// <summary>
            /// Property For Job Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHD5DT = "AMTWHD5DT";

            /// <summary>
            /// Property For Document Tax Authority 1
            /// </summary>
            public const string CodeTax1 = "CODETAX1";

            /// <summary>
            /// Property For Document Tax Authority 2
            /// </summary>
            public const string CodeTax2 = "CODETAX2";

            /// <summary>
            /// Property For Document Tax Authority 3
            /// </summary>
            public const string CodeTax3 = "CODETAX3";

            /// <summary>
            /// Property For Document Tax Authority 4
            /// </summary>
            public const string CodeTax4 = "CODETAX4";

            /// <summary>
            /// Property For Document Tax Authority 5
            /// </summary>
            public const string CodeTax5 = "CODETAX5";

            /// <summary>
            /// Property For Tax Auth 1 Description
            /// </summary>
            public const string TaxAuth1Description = "TXAU1DESC";

            /// <summary>
            /// Property For Tax Auth 2 Description
            /// </summary>
            public const string TaxAuth2Description = "TXAU2DESC";

            /// <summary>
            /// Property For Tax Auth 3 Description
            /// </summary>
            public const string TaxAuth3Description = "TXAU3DESC";

            /// <summary>
            /// Property For Tax Auth 4 Description
            /// </summary>
            public const string TaxAuth4Description = "TXAU4DESC";

            /// <summary>
            /// Property For Tax Auth 5 Description
            /// </summary>
            public const string TaxAuth5Description = "TXAU5DESC";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 1
            /// </summary>
            public const string PndWHD1Tot = "PNDWHD1TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 2
            /// </summary>
            public const string PndWHD2Tot = "PNDWHD2TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 3
            /// </summary>
            public const string PndWHD3Tot = "PNDWHD3TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 4
            /// </summary>
            public const string PndWHD4Tot = "PNDWHD4TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 5
            /// </summary>
            public const string PndWHD5Tot = "PNDWHD5TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Total
            /// </summary>
            public const string PndWHDTot = "PNDWHDTOT";

            /// <summary>
            /// Property For Tax Withheld Amount Total
            /// </summary>
            public const string AmtWHDTot = "AMTWHDTOT";

            #endregion
        }


        /// <summary>
        /// Contains list of AppliedPayments Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 3;
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 4;
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 5;
            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 6;
            /// <summary>
            /// Property Indexer for PaymentNumber 
            /// </summary>
            public const int PaymentNumber = 7;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 8;
            /// <summary>
            /// Property Indexer for PaymentResolution 
            /// </summary>
            public const int PaymentResolution = 9;
            /// <summary>
            /// Property Indexer for PaymentAmount 
            /// </summary>
            public const int PaymentAmount = 10;
            /// <summary>
            /// Property Indexer for DiscountAmountTaken 
            /// </summary>
            public const int DiscountAmountTaken = 11;
            /// <summary>
            /// Property Indexer for NextAdjSeqNo 
            /// </summary>
            public const int NextAdjSeqNo = 12;
            /// <summary>
            /// Property Indexer for AdjustmentsTotal 
            /// </summary>
            public const int AdjustmentsTotal = 13;
            /// <summary>
            /// Property Indexer for GeneratedAdjustmentNumber 
            /// </summary>
            public const int GeneratedAdjustmentNumber = 14;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 15;
            /// <summary>
            /// Property Indexer for Reference 
            /// </summary>
            public const int Reference = 16;
            /// <summary>
            /// Property Indexer for GeneratedPPNo 
            /// </summary>
            public const int GeneratedPPNo = 17;
            /// <summary>
            /// Property Indexer for PPMatchingDocNo 
            /// </summary>
            public const int PPMatchingDocNo = 18;
            /// <summary>
            /// Property Indexer for PPMatchingDocType 
            /// </summary>
            public const int PPMatchingDocType = 19;
            /// <summary>
            /// Property Indexer for ActivationDate 
            /// </summary>
            public const int ActivationDate = 20;
            /// <summary>
            /// Property Indexer for DocumentAmountDue 
            /// </summary>
            public const int DocumentAmountDue = 21;
            /// <summary>
            /// Property Indexer for DiscountAmountAvailable 
            /// </summary>
            public const int DiscountAmountAvailable = 22;
            /// <summary>
            /// Property Indexer for DocumentNetBalance 
            /// </summary>
            public const int DocumentNetBalance = 23;
            /// <summary>
            /// Property Indexer for PendingPaymentAmount 
            /// </summary>
            public const int PendingPaymentAmount = 24;
            /// <summary>
            /// Property Indexer for PendingDiscountAmount 
            /// </summary>
            public const int PendingDiscountAmount = 25;
            /// <summary>
            /// Property Indexer for PendingAdjustmentAmount 
            /// </summary>
            public const int PendingAdjustmentAmount = 26;
            /// <summary>
            /// Property Indexer for AdjDebitAmtVendCurr 
            /// </summary>
            public const int AdjDebitAmtVendCurr = 27;
            /// <summary>
            /// Property Indexer for AdjCreditAmtVendCurr 
            /// </summary>
            public const int AdjCreditAmtVendCurr = 28;
            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 29;
            /// <summary>
            /// Property Indexer for JobTotalPaymentAmount 
            /// </summary>
            public const int JobTotalPaymentAmount = 30;
            /// <summary>
            /// Property Indexer for JobTotalDiscountAmount 
            /// </summary>
            public const int JobTotalDiscountAmount = 31;
            /// <summary>
            /// Property Indexer for JobApplyMethod 
            /// </summary>
            public const int JobApplyMethod = 32;
            /// <summary>
            /// Property Indexer for RtgDebitAmtVendCurr 
            /// </summary>
            public const int RtgDebitAmtVendCurr = 33;
            /// <summary>
            /// Property Indexer for RtgCreditAmtVendCurr 
            /// </summary>
            public const int RtgCreditAmtVendCurr = 34;
            /// <summary>
            /// Property Indexer for RetainageAmount 
            /// </summary>
            public const int RetainageAmount = 35;
            /// <summary>
            /// Property Indexer for RetainageDueDate 
            /// </summary>
            public const int RetainageDueDate = 36;
            /// <summary>
            /// Property Indexer for RetainageTermsCode 
            /// </summary>
            public const int RetainageTermsCode = 37;
            /// <summary>
            /// Property Indexer for RetainageExchangeRate 
            /// </summary>
            public const int RetainageExchangeRate = 38;
            /// <summary>
            /// Property Indexer for ProcessCommand 
            /// </summary>
            public const int ProcessCommand = 39;
            /// <summary>
            /// Property Indexer for UnappliedJobPaymentAmount 
            /// </summary>
            public const int UnappliedJobPaymentAmount = 40;
            /// <summary>
            /// Property Indexer for UnappliedJobDiscountAmount 
            /// </summary>
            public const int UnappliedJobDiscountAmount = 41;
            /// <summary>
            /// Property Indexer for VendorCurrencyCode 
            /// </summary>
            public const int VendorCurrencyCode = 42;
            /// <summary>
            /// Property Indexer for PaymentDate 
            /// </summary>
            public const int PaymentDate = 43;
            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 44;
            /// <summary>
            /// Property Indexer for PaymentType 
            /// </summary>
            public const int PaymentType = 45;
            /// <summary>
            /// Property Indexer for HasRetainage 
            /// </summary>
            public const int HasRetainage = 46;
            /// <summary>
            /// Property Indexer for RetainageBalance 
            /// </summary>
            public const int RetainageBalance = 47;
            /// <summary>
            /// Property Indexer for OriginalDocNo 
            /// </summary>
            public const int OriginalDocNo = 48;
            /// <summary>
            /// Property Indexer for PayablesAdjustmentTotal 
            /// </summary>
            public const int PayablesAdjustmentTotal = 49;
            /// <summary>
            /// Property Indexer for OriginalExchangeRate 
            /// </summary>
            public const int OriginalExchangeRate = 50;
            /// <summary>
            /// Property Indexer for DocDate 
            /// </summary>
            public const int DocDate = 51;
            /// <summary>
            /// Property Indexer for FuncPaymentAmount 
            /// </summary>
            public const int FuncPaymentAmount = 52;
            /// <summary>
            /// Property Indexer for FuncDiscountAmount 
            /// </summary>
            public const int FuncDiscountAmount = 53;
            /// <summary>
            /// Property Indexer for FuncAdjustmentsTotal 
            /// </summary>
            public const int FuncAdjustmentsTotal = 54;
            /// <summary>
            /// Property Indexer for FuncRetainageAmount 
            /// </summary>
            public const int FuncRetainageAmount = 55;
            /// <summary>
            /// Property Indexer for DocVersionCreatedIn 
            /// </summary>
            public const int DocVersionCreatedIn = 56;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHD1TC = 57;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHD2TC = 58;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHD3TC = 59;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHD4TC = 60;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHD5TC = 61;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHD1HC = 62;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHD2HC = 63;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHD3HC = 64;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHD4HC = 65;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHD5HC = 66;

            /// <summary>
            /// Indexer For Job Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHD1DT = 67;

            /// <summary>
            /// Indexer For Job Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHD2DT = 68;

            /// <summary>
            /// Indexer For Job Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHD3DT = 69;

            /// <summary>
            /// Indexer For Job Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHD4DT = 70;

            /// <summary>
            /// Indexer For Job Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHD5DT = 71;

            /// <summary>
            /// Indexer For Document Tax Authority 1
            /// </summary>
            public const int CodeTax1 = 72;

            /// <summary>
            /// Indexer For Document Tax Authority 2
            /// </summary>
            public const int CodeTax2 = 73;

            /// <summary>
            /// Indexer For Document Tax Authority 3
            /// </summary>
            public const int CodeTax3 = 74;

            /// <summary>
            /// Indexer For Document Tax Authority 4
            /// </summary>
            public const int CodeTax4 = 75;

            /// <summary>
            /// Indexer For Document Tax Authority 5
            /// </summary>
            public const int CodeTax5 = 76;

            /// <summary>
            /// Indexer For Tax Auth 1 Description
            /// </summary>
            public const int TaxAuth1Description = 77;

            /// <summary>
            /// Indexer For Tax Auth 2 Description
            /// </summary>
            public const int TaxAuth2Description = 78;

            /// <summary>
            /// Indexer For Tax Auth 3 Description
            /// </summary>
            public const int TaxAuth3Description = 79;

            /// <summary>
            /// Indexer For Tax Auth 4 Description
            /// </summary>
            public const int TaxAuth4Description = 80;

            /// <summary>
            /// Indexer For Tax Auth 5 Description
            /// </summary>
            public const int TaxAuth5Description = 81;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 1
            /// </summary>
            public const int PndWHD1Tot = 82;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 2
            /// </summary>
            public const int PndWHD2Tot = 83;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 3
            /// </summary>
            public const int PndWHD3Tot = 84;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 4
            /// </summary>
            public const int PndWHD4Tot = 85;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 5
            /// </summary>
            public const int PndWHD5Tot = 86;

            /// <summary>
            /// Indexer For Pending Tax Withheld Total
            /// </summary>
            public const int PndWHDTot = 87;

            /// <summary>
            /// Indexer For Tax Withheld Amount Total
            /// </summary>
            public const int AmtWHDTot = 88;
            #endregion
        }

	
	}
}
	