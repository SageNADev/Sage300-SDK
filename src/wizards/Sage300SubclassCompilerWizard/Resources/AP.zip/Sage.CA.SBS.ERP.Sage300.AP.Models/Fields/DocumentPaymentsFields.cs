/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of DocumentPayments Constants 
    /// </summary>
    public partial class DocumentPayment
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0027";

        /// <summary>
        /// Contains list of DocumentPayments Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";
            /// <summary>
            /// Property for DocumentNumber 
            /// </summary>
            public const string DocumentNumber = "IDINVC";
            /// <summary>
            /// Property for PaymentNumber 
            /// </summary>
            public const string PaymentNumber = "CNTPAYMNBR";
            /// <summary>
            /// Property for CheckNumber 
            /// </summary>
            public const string CheckNumber = "IDRMIT";
            /// <summary>
            /// Property for PostingDate 
            /// </summary>
            public const string PostingDate = "DATEBUS";
            /// <summary>
            /// Property for DocumentType 
            /// </summary>
            public const string DocumentType = "TRANSTYPE";
            /// <summary>
            /// Property for DocumentTypeString
            /// </summary>
            public const string DocumentTypeString = "TRANSTYPE";
            /// <summary>
            /// Property for SequenceNo 
            /// </summary>
            public const string SequenceNo = "CNTSEQNCE";
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for BatchDate 
            /// </summary>
            public const string BatchDate = "DATEBTCH";
            /// <summary>
            /// Property for FunctionalPaymentAmount
            /// </summary>
            public const string FunctionalPaymentAmount = "AMTPAYMHC";
            /// <summary>
            /// Property for VendPaymentAmount 
            /// </summary>
            public const string VendorPaymentAmount = "AMTPAYMTC";
            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CODECURN";
            /// <summary>
            /// Property for RateType 
            /// </summary>
            public const string RateType = "IDRATETYPE";
            /// <summary>
            /// Property for ExchangeRate 
            /// </summary>
            public const string ExchangeRate = "RATEEXCHHC";
            /// <summary>
            /// Property for RateOverridden 
            /// </summary>
            public const string RateOverridden = "SWOVRDRATE";
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "IDBANK";
            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TRXTYPE";
            /// <summary>
            /// Property for TransactionTypeString 
            /// </summary>
            public const string TransactionTypeString = "TRXTYPE";
            /// <summary>
            /// Property for ReferenceDocumentNo 
            /// </summary>
            public const string ReferenceDocumentNo = "IDMEMOXREF";
            /// <summary>
            /// Property for RemittingVendorNo 
            /// </summary>
            public const string RemittingVendorNo = "IDRMITVEND";
            /// <summary>
            /// Property for CheckDate 
            /// </summary>
            public const string CheckDate = "DATERMIT";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTITEM";
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string Year = "FISCYR";
            /// <summary>
            /// Property for Period 
            /// </summary>
            public const string Period = "FISCPER";
            /// <summary>
            /// Property for CheckSerialNumber 
            /// </summary>
            public const string CheckSerialNumber = "LONGSERIAL";
            /// <summary>
            /// Property for Num1099OrCPRSCode 
            /// </summary>
            public const string Num1099OrCPRSCode = "CODE1099";
            /// <summary>
            /// Property for Num1099OrCPRSAmount 
            /// </summary>
            public const string Num1099OrCPRSAmount = "AMT1099";
            /// <summary>
            /// Property for RateDate 
            /// </summary>
            public const string RateDate = "RATEDATE";
            /// <summary>
            /// Property for RateOperator 
            /// </summary>
            public const string RateOperator = "RATEOP";

            #endregion
        }


        /// <summary>
        /// Contains list of DocumentPayments Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 1;
            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 2;
            /// <summary>
            /// Property Indexer for PaymentNumber 
            /// </summary>
            public const int PaymentNumber = 3;
            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int CheckNumber = 4;
            /// <summary>
            /// Property Indexer for PostingDate 
            /// </summary>
            public const int PostingDate = 5;
            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 6;
            /// <summary>
            /// Property Indexer for SequenceNo 
            /// </summary>
            public const int SequenceNo = 7;
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 9;
            /// <summary>
            /// Property Indexer for BatchDate 
            /// </summary>
            public const int BatchDate = 10;
            /// <summary>
            /// Property Indexer for FuncPaymentAmount 
            /// </summary>
            public const int FuncPaymentAmount = 11;
            /// <summary>
            /// Property Indexer for VendPaymentAmount 
            /// </summary>
            public const int VendPaymentAmount = 12;
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 13;
            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 14;
            /// <summary>
            /// Property Indexer for ExchangeRate 
            /// </summary>
            public const int ExchangeRate = 15;
            /// <summary>
            /// Property Indexer for RateOverridden 
            /// </summary>
            public const int RateOverridden = 16;
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 17;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 18;
            /// <summary>
            /// Property Indexer for ReferenceDocumentNo 
            /// </summary>
            public const int ReferenceDocumentNo = 19;
            /// <summary>
            /// Property Indexer for RemittingVendorNo 
            /// </summary>
            public const int RemittingVendorNo = 23;
            /// <summary>
            /// Property Indexer for CheckDate 
            /// </summary>
            public const int CheckDate = 24;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 25;
            /// <summary>
            /// Property Indexer for Year 
            /// </summary>
            public const int Year = 27;
            /// <summary>
            /// Property Indexer for Period 
            /// </summary>
            public const int Period = 28;
            /// <summary>
            /// Property Indexer for CheckSerialNumber 
            /// </summary>
            public const int CheckSerialNumber = 29;
            /// <summary>
            /// Property Indexer for Num1099OrCPRSCode 
            /// </summary>
            public const int Num1099OrCPRSCode = 30;
            /// <summary>
            /// Property Indexer for Num1099OrCPRSAmount 
            /// </summary>
            public const int Num1099OrCPRSAmount = 31;
            /// <summary>
            /// Property Indexer for RateDate 
            /// </summary>
            public const int RateDate = 32;
            /// <summary>
            /// Property Indexer for RateOperator 
            /// </summary>
            public const int RateOperator = 33;

            #endregion
        }

        /// <summary>
        /// Contains list of DocumentPayments Keys Constants
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Property for CheckNumber 
            /// </summary>
            public const int CheckNumber = 4;
        }
    }
}
