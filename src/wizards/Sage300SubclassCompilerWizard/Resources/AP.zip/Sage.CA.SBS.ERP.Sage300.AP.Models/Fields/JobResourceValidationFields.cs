// Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of JobResourceValidation Constants
    /// </summary>
    public partial class JobResourceValidation
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AP0202";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"CONTRACT", "ContractCode"},
                    {"PROJECT", "ProjectCode"},
                    {"CATEGORY", "CategoryCode"},
                    {"RESOURCE", "Resource"},
                    {"BILLRATE", "BillingRate"},
                    {"BILLTYPE", "BillingType"},
                    {"IDGLACCT", "WIPAccount"},
                    {"IDITEM", "ARItemNumber"}
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of JobResourceValidation Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ContractCode
            /// </summary>
            public const string ContractCode = "CONTRACT";

            /// <summary>
            /// Property for ProjectCode
            /// </summary>
            public const string ProjectCode = "PROJECT";

            /// <summary>
            /// Property for CategoryCode
            /// </summary>
            public const string CategoryCode = "CATEGORY";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for FormattedContractCode
            /// </summary>
            public const string FormattedContractCode = "FMTCONTNO";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "COSTCLASS";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "IDITEM";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNITMEAS";

            /// <summary>
            /// Property for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CODECURN";

            /// <summary>
            /// Property for WIPAccount
            /// </summary>
            public const string WIPAccount = "IDGLACCT";

            /// <summary>
            /// Property for ContractDescription
            /// </summary>
            public const string ContractDescription = "CONTDESC";

            /// <summary>
            /// Property for ProjectDescription
            /// </summary>
            public const string ProjectDescription = "PROJDESC";

            /// <summary>
            /// Property for CategoryDescription
            /// </summary>
            public const string CategoryDescription = "CATGDESC";

            /// <summary>
            /// Property for ResourceDescription
            /// </summary>
            public const string ResourceDescription = "RESDESC";

            /// <summary>
            /// Property for ContractOpened
            /// </summary>
            public const string ContractOpened = "OPENEDC";

            /// <summary>
            /// Property for ProjectOpened
            /// </summary>
            public const string ProjectOpened = "OPENEDP";

            /// <summary>
            /// Property for SilentMode
            /// </summary>
            public const string SilentMode = "SILENTMODE";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for DocumentType
            /// </summary>
            public const string DocumentType = "DOCTYPE";

            /// <summary>
            /// Property for VendorNumber
            /// </summary>
            public const string VendorNumber = "IDVEND";

            /// <summary>
            /// Property for PercentRetained
            /// </summary>
            public const string PercentRetained = "RTGPERCENT";

            /// <summary>
            /// Property for DaysRetained
            /// </summary>
            public const string DaysRetained = "RTGDAYS";

            /// <summary>
            /// Property for RetainageTermsCode
            /// </summary>
            public const string RetainageTermsCode = "RTGTERMS";

            /// <summary>
            /// Property for RetainageInvoice
            /// </summary>
            public const string RetainageInvoice = "SWRTG";

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTOMER";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "PROJSTYLE";

            /// <summary>
            /// Property for ARInvoiceType
            /// </summary>
            public const string ARInvoiceType = "INVTYPE";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of JobResourceValidation Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ContractCode
            /// </summary>
            public const int ContractCode = 1;

            /// <summary>
            /// Property Indexer for ProjectCode
            /// </summary>
            public const int ProjectCode = 2;

            /// <summary>
            /// Property Indexer for CategoryCode
            /// </summary>
            public const int CategoryCode = 3;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 4;

            /// <summary>
            /// Property Indexer for FormattedContractCode
            /// </summary>
            public const int FormattedContractCode = 5;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 7;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 8;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 9;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 10;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 11;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 12;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 13;

            /// <summary>
            /// Property Indexer for CurrencyCode
            /// </summary>
            public const int CurrencyCode = 14;

            /// <summary>
            /// Property Indexer for WIPAccount
            /// </summary>
            public const int WIPAccount = 15;

            /// <summary>
            /// Property Indexer for ContractDescription
            /// </summary>
            public const int ContractDescription = 16;

            /// <summary>
            /// Property Indexer for ProjectDescription
            /// </summary>
            public const int ProjectDescription = 17;

            /// <summary>
            /// Property Indexer for CategoryDescription
            /// </summary>
            public const int CategoryDescription = 18;

            /// <summary>
            /// Property Indexer for ResourceDescription
            /// </summary>
            public const int ResourceDescription = 19;

            /// <summary>
            /// Property Indexer for ContractOpened
            /// </summary>
            public const int ContractOpened = 20;

            /// <summary>
            /// Property Indexer for ProjectOpened
            /// </summary>
            public const int ProjectOpened = 21;

            /// <summary>
            /// Property Indexer for SilentMode
            /// </summary>
            public const int SilentMode = 22;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 23;

            /// <summary>
            /// Property Indexer for DocumentType
            /// </summary>
            public const int DocumentType = 24;

            /// <summary>
            /// Property Indexer for VendorNumber
            /// </summary>
            public const int VendorNumber = 25;

            /// <summary>
            /// Property Indexer for PercentRetained
            /// </summary>
            public const int PercentRetained = 26;

            /// <summary>
            /// Property Indexer for DaysRetained
            /// </summary>
            public const int DaysRetained = 27;

            /// <summary>
            /// Property Indexer for RetainageTermsCode
            /// </summary>
            public const int RetainageTermsCode = 28;

            /// <summary>
            /// Property Indexer for RetainageInvoice
            /// </summary>
            public const int RetainageInvoice = 29;

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 30;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 31;

            /// <summary>
            /// Property Indexer for ARInvoiceType
            /// </summary>
            public const int ARInvoiceType = 32;

        }

        #endregion

    }
}