// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of OpenDocumentDetails Constants 
    /// </summary>
    public partial class OpenDocumentDetail
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0200";

        /// <summary>
        /// Contains list of OpenDocumentDetails Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "IDVEND";
            /// <summary>
            /// Property for DocumentNumber 
            /// </summary>
            public const string DocumentNumber = "IDINVC";
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "CNTLINE";
            /// <summary>
            /// Property for ContractCode 
            /// </summary>
            public const string ContractCode = "CONTRACT";
            /// <summary>
            /// Property for ProjectCode 
            /// </summary>
            public const string ProjectCode = "PROJECT";
            /// <summary>
            /// Property for CategoryCode 
            /// </summary>
            public const string CategoryCode = "CATEGORY";
            /// <summary>
            /// Property for ProjectOrCategoryResource 
            /// </summary>
            public const string ProjectOrCategoryResource = "RESOURCE";
            /// <summary>
            /// Property for TransactionNumber 
            /// </summary>
            public const string TransactionNumber = "TRANSNBR";
            /// <summary>
            /// Property for CostClass 
            /// </summary>
            public const string CostClass = "COSTCLASS";
            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "IDDIST";
            /// <summary>
            /// Property for GOrLAccount 
            /// </summary>
            public const string GLAccount = "IDGLACCT";
            /// <summary>
            /// Property for BillingType 
            /// </summary>
            public const string BillingType = "BILLTYPE";
            /// <summary>
            /// Property for FunctionalCurrencyInvoiceAmount 
            /// </summary>
            public const string FunctionalCurrencyInvoiceAmount = "AMTINVCHC";
            /// <summary>
            /// Property for FunctionalCurrencyAmountDue 
            /// </summary>
            public const string FunctionalCurrencyAmountDue = "AMTDUEHC";
            /// <summary>
            /// Property for VendorCurrencyInvoiceAmount 
            /// </summary>
            public const string VendorCurrencyInvoiceAmount = "AMTINVCTC";
            /// <summary>
            /// Property for VendorCurrencyAmountDue 
            /// </summary>
            public const string VendorCurrencyAmountDue = "AMTDUETC";
            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "IDITEM";
            /// <summary>
            /// Property for UnitofMeasure 
            /// </summary>
            public const string UnitofMeasure = "UNITMEAS";
            /// <summary>
            /// Property for Quantity 
            /// </summary>
            public const string Quantity = "QTYINVC";
            /// <summary>
            /// Property for Cost 
            /// </summary>
            public const string Cost = "AMTCOST";
            /// <summary>
            /// Property for BillingDate 
            /// </summary>
            public const string BillingDate = "BILLDATE";
            /// <summary>
            /// Property for BillingRate 
            /// </summary>
            public const string BillingRate = "BILLRATE";
            /// <summary>
            /// Property for BillingCurrency 
            /// </summary>
            public const string BillingCurrency = "BILLCURN";
            /// <summary>
            /// Property for Discountable 
            /// </summary>
            public const string Discountable = "SWDISCABL";
            /// <summary>
            /// Property for Status string value 
            /// </summary>
            public const string DiscountableString = "SWDISCABL";
            /// <summary>
            /// Property for DateRetainageDue 
            /// </summary>
            public const string DateRetainageDue = "RTGDATEDUE";
            /// <summary>
            /// Property for FunctionalCurrencyOrigRtngAmt 
            /// </summary>
            public const string FunctionalCurrencyOrigRtngAmt = "RTGOAMTHC";
            /// <summary>
            /// Property for FunctionalCurrencyRetainageAmount 
            /// </summary>
            public const string FunctionalCurrencyRetainageAmount = "RTGAMTHC";
            /// <summary>
            /// Property for VendorCurrencyOrigRtngAmt 
            /// </summary>
            public const string VendorCurrencyOrigRtngAmt = "RTGOAMTTC";
            /// <summary>
            /// Property for VendorCurrencyRetainageAmount 
            /// </summary>
            public const string VendorCurrencyRetainageAmount = "RTGAMTTC";
            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";
            /// <summary>
            /// Property for RetainageDistributionAmount 
            /// </summary>
            public const string RetainageDistributionAmount = "RTGDISTTC";
            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";
            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";
            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";
            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";
            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";
            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded1 = "SWTAXINCL1";
            /// <summary>
            /// Property for TaxIncluded2 
            /// </summary>
            public const string TaxIncluded2 = "SWTAXINCL2";
            /// <summary>
            /// Property for TaxIncluded3 
            /// </summary>
            public const string TaxIncluded3 = "SWTAXINCL3";
            /// <summary>
            /// Property for TaxIncluded4 
            /// </summary>
            public const string TaxIncluded4 = "SWTAXINCL4";
            /// <summary>
            /// Property for TaxIncluded5 
            /// </summary>
            public const string TaxIncluded5 = "SWTAXINCL5";
            /// <summary>
            /// Property for TaxRate1 
            /// </summary>
            public const string TaxRate1 = "TXRATE1";
            /// <summary>
            /// Property for TaxRate2 
            /// </summary>
            public const string TaxRate2 = "TXRATE2";
            /// <summary>
            /// Property for TaxRate3 
            /// </summary>
            public const string TaxRate3 = "TXRATE3";
            /// <summary>
            /// Property for TaxRate4 
            /// </summary>
            public const string TaxRate4 = "TXRATE4";
            /// <summary>
            /// Property for TaxRate5 
            /// </summary>
            public const string TaxRate5 = "TXRATE5";
            /// <summary>
            /// Property for VendorRetainageTaxBase1 
            /// </summary>
            public const string VendorRetainageTaxBase1 = "TXBSERT1TC";
            /// <summary>
            /// Property for VendorRetainageTaxBase2 
            /// </summary>
            public const string VendorRetainageTaxBase2 = "TXBSERT2TC";
            /// <summary>
            /// Property for VendorRetainageTaxBase3 
            /// </summary>
            public const string VendorRetainageTaxBase3 = "TXBSERT3TC";
            /// <summary>
            /// Property for VendorRetainageTaxBase4 
            /// </summary>
            public const string VendorRetainageTaxBase4 = "TXBSERT4TC";
            /// <summary>
            /// Property for VendorRetainageTaxBase5 
            /// </summary>
            public const string VendorRetainageTaxBase5 = "TXBSERT5TC";
            /// <summary>
            /// Property for VendorRetainageTaxAmount1 
            /// </summary>
            public const string VendorRetainageTaxAmount1 = "TXAMTRT1TC";
            /// <summary>
            /// Property for VendorRetainageTaxAmount2 
            /// </summary>
            public const string VendorRetainageTaxAmount2 = "TXAMTRT2TC";
            /// <summary>
            /// Property for VendorRetainageTaxAmount3 
            /// </summary>
            public const string VendorRetainageTaxAmount3 = "TXAMTRT3TC";
            /// <summary>
            /// Property for VendorRetainageTaxAmount4 
            /// </summary>
            public const string VendorRetainageTaxAmount4 = "TXAMTRT4TC";
            /// <summary>
            /// Property for VendorRetainageTaxAmount5 
            /// </summary>
            public const string VendorRetainageTaxAmount5 = "TXAMTRT5TC";
            /// <summary>
            /// Property for FunctionalRetainageTaxAmount1 
            /// </summary>
            public const string FunctionalRetainageTaxAmount1 = "TXAMTRT1HC";
            /// <summary>
            /// Property for FunctionalRetainageTaxAmount2 
            /// </summary>
            public const string FunctionalRetainageTaxAmount2 = "TXAMTRT2HC";
            /// <summary>
            /// Property for FunctionalRetainageTaxAmount3 
            /// </summary>
            public const string FunctionalRetainageTaxAmount3 = "TXAMTRT3HC";
            /// <summary>
            /// Property for FunctionalRetainageTaxAmount4 
            /// </summary>
            public const string FunctionalRetainageTaxAmount4 = "TXAMTRT4HC";
            /// <summary>
            /// Property for FunctionalRetainageTaxAmount5 
            /// </summary>
            public const string FunctionalRetainageTaxAmount5 = "TXAMTRT5HC";
            /// <summary>
            /// Property for FunctionalRetainageTaxAllocated 
            /// </summary>
            public const string FunctionalRetainageTaxAllocated = "TXALLRTHC";
            /// <summary>
            /// Property for VendorRetainageTaxAllocated 
            /// </summary>
            public const string VendorRetainageTaxAllocated = "TXALLRTTC";
            /// <summary>
            /// Property for FunctionalRetainageTaxExpensed 
            /// </summary>
            public const string FunctionalRetainageTaxExpensed = "TXEXPRTHC";
            /// <summary>
            /// Property for VendorRetainageTaxExpensed 
            /// </summary>
            public const string VendorRetainageTaxExpensed = "TXEXPRTTC";
            /// <summary>
            /// Property for AllocatedTaxAccount 
            /// </summary>
            public const string AllocatedTaxAccount = "TXALLACCT";
            /// <summary>
            /// Property for LastAppliedPaymentSeqNo 
            /// </summary>
            public const string LastAppliedPaymentSeqNo = "CNTLASTSEQ";

            #endregion
        }

        /// <summary>
        /// Contains list of OpenDocumentDetails Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 1;
            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 2;
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 3;
            /// <summary>
            /// Property Indexer for ContractCode 
            /// </summary>
            public const int ContractCode = 4;
            /// <summary>
            /// Property Indexer for ProjectCode 
            /// </summary>
            public const int ProjectCode = 5;
            /// <summary>
            /// Property Indexer for CategoryCode 
            /// </summary>
            public const int CategoryCode = 6;
            /// <summary>
            /// Property Indexer for ProjectOrCategoryResource 
            /// </summary>
            public const int ProjectOrCategoryResource = 7;
            /// <summary>
            /// Property Indexer for TransactionNumber 
            /// </summary>
            public const int TransactionNumber = 8;
            /// <summary>
            /// Property Indexer for CostClass 
            /// </summary>
            public const int CostClass = 9;
            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 10;
            /// <summary>
            /// Property Indexer for GOrLAccount 
            /// </summary>
            public const int GLAccount = 11;
            /// <summary>
            /// Property Indexer for BillingType 
            /// </summary>
            public const int BillingType = 12;
            /// <summary>
            /// Property Indexer for FunctionalCurrencyInvoiceAmount 
            /// </summary>
            public const int FunctionalCurrencyInvoiceAmount = 13;
            /// <summary>
            /// Property Indexer for FunctionalCurrencyAmountDue 
            /// </summary>
            public const int FunctionalCurrencyAmountDue = 14;
            /// <summary>
            /// Property Indexer for VendorCurrencyInvoiceAmount 
            /// </summary>
            public const int VendorCurrencyInvoiceAmount = 15;
            /// <summary>
            /// Property Indexer for VendorCurrencyAmountDue 
            /// </summary>
            public const int VendorCurrencyAmountDue = 16;
            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 17;
            /// <summary>
            /// Property Indexer for UnitofMeasure 
            /// </summary>
            public const int UnitofMeasure = 18;
            /// <summary>
            /// Property Indexer for Quantity 
            /// </summary>
            public const int Quantity = 19;
            /// <summary>
            /// Property Indexer for Cost 
            /// </summary>
            public const int Cost = 20;
            /// <summary>
            /// Property Indexer for BillingDate 
            /// </summary>
            public const int BillingDate = 21;
            /// <summary>
            /// Property Indexer for BillingRate 
            /// </summary>
            public const int BillingRate = 22;
            /// <summary>
            /// Property Indexer for BillingCurrency 
            /// </summary>
            public const int BillingCurrency = 23;
            /// <summary>
            /// Property Indexer for Discountable 
            /// </summary>
            public const int Discountable = 24;
            /// <summary>
            /// Property Indexer for DateRetainageDue 
            /// </summary>
            public const int DateRetainageDue = 25;
            /// <summary>
            /// Property Indexer for FunctionalCurrencyOrigRtngAmt 
            /// </summary>
            public const int FunctionalCurrencyOrigRtngAmt = 26;
            /// <summary>
            /// Property Indexer for FunctionalCurrencyRetainageAmount 
            /// </summary>
            public const int FunctionalCurrencyRetainageAmount = 27;
            /// <summary>
            /// Property Indexer for VendorCurrencyOrigRtngAmt 
            /// </summary>
            public const int VendorCurrencyOrigRtngAmt = 28;
            /// <summary>
            /// Property Indexer for VendorCurrencyRetainageAmount 
            /// </summary>
            public const int VendorCurrencyRetainageAmount = 29;
            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 30;
            /// <summary>
            /// Property Indexer for RetainageDistributionAmount 
            /// </summary>
            public const int RetainageDistributionAmount = 31;
            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 32;
            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 33;
            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 34;
            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 35;
            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 36;
            /// <summary>
            /// Property Indexer for TaxIncluded1 
            /// </summary>
            public const int TaxIncluded1 = 37;
            /// <summary>
            /// Property Indexer for TaxIncluded2 
            /// </summary>
            public const int TaxIncluded2 = 38;
            /// <summary>
            /// Property Indexer for TaxIncluded3 
            /// </summary>
            public const int TaxIncluded3 = 39;
            /// <summary>
            /// Property Indexer for TaxIncluded4 
            /// </summary>
            public const int TaxIncluded4 = 40;
            /// <summary>
            /// Property Indexer for TaxIncluded5 
            /// </summary>
            public const int TaxIncluded5 = 41;
            /// <summary>
            /// Property Indexer for TaxRate1 
            /// </summary>
            public const int TaxRate1 = 42;
            /// <summary>
            /// Property Indexer for TaxRate2 
            /// </summary>
            public const int TaxRate2 = 43;
            /// <summary>
            /// Property Indexer for TaxRate3 
            /// </summary>
            public const int TaxRate3 = 44;
            /// <summary>
            /// Property Indexer for TaxRate4 
            /// </summary>
            public const int TaxRate4 = 45;
            /// <summary>
            /// Property Indexer for TaxRate5 
            /// </summary>
            public const int TaxRate5 = 46;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxBase1 
            /// </summary>
            public const int VendorRetainageTaxBase1 = 47;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxBase2 
            /// </summary>
            public const int VendorRetainageTaxBase2 = 48;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxBase3 
            /// </summary>
            public const int VendorRetainageTaxBase3 = 49;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxBase4 
            /// </summary>
            public const int VendorRetainageTaxBase4 = 50;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxBase5 
            /// </summary>
            public const int VendorRetainageTaxBase5 = 51;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxAmount1 
            /// </summary>
            public const int VendorRetainageTaxAmount1 = 52;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxAmount2 
            /// </summary>
            public const int VendorRetainageTaxAmount2 = 53;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxAmount3 
            /// </summary>
            public const int VendorRetainageTaxAmount3 = 54;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxAmount4 
            /// </summary>
            public const int VendorRetainageTaxAmount4 = 55;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxAmount5 
            /// </summary>
            public const int VendorRetainageTaxAmount5 = 56;
            /// <summary>
            /// Property Indexer for FunctionalRetainageTaxAmount1 
            /// </summary>
            public const int FunctionalRetainageTaxAmount1 = 57;
            /// <summary>
            /// Property Indexer for FunctionalRetainageTaxAmount2 
            /// </summary>
            public const int FunctionalRetainageTaxAmount2 = 58;
            /// <summary>
            /// Property Indexer for FunctionalRetainageTaxAmount3 
            /// </summary>
            public const int FunctionalRetainageTaxAmount3 = 59;
            /// <summary>
            /// Property Indexer for FunctionalRetainageTaxAmount4 
            /// </summary>
            public const int FunctionalRetainageTaxAmount4 = 60;
            /// <summary>
            /// Property Indexer for FunctionalRetainageTaxAmount5 
            /// </summary>
            public const int FunctionalRetainageTaxAmount5 = 61;
            /// <summary>
            /// Property Indexer for FunctionalRetainageTaxAllocated 
            /// </summary>
            public const int FunctionalRetainageTaxAllocated = 62;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxAllocated 
            /// </summary>
            public const int VendorRetainageTaxAllocated = 63;
            /// <summary>
            /// Property Indexer for FunctionalRetainageTaxExpensed 
            /// </summary>
            public const int FunctionalRetainageTaxExpensed = 64;
            /// <summary>
            /// Property Indexer for VendorRetainageTaxExpensed 
            /// </summary>
            public const int VendorRetainageTaxExpensed = 65;
            /// <summary>
            /// Property Indexer for AllocatedTaxAccount 
            /// </summary>
            public const int AllocatedTaxAccount = 66;
            /// <summary>
            /// Property Indexer for LastAppliedPaymentSeqNo 
            /// </summary>
            public const int LastAppliedPaymentSeqNo = 67;

            #endregion
        }


    }
}
