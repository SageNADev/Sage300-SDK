﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using System;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.UserPreference
{
    public class VendorActivity
    {
        /// <summary>
        /// Gets or sets the Currency selected
        /// </summary>
        public string SelectedCurrency { get; set; }

        /// <summary>
        /// Gets or sets the AgeByOrderType
        /// </summary>
        public DueDateOrInvoiceDate AgeByOrderType { get; set; }

        /// <summary>
        /// Gets or sets the IncludeTransactionsOnHold
        /// </summary>
        public bool IncludeTransactionsOnHold { get; set; }

        /// <summary>
        /// Gets or sets the IncludePrepayments
        /// </summary>
        public bool IncludePrepayments { get; set; }

        /// <summary>
        /// Gets or sets the SelectedDocumentType
        /// </summary>
        public int SelectedDocumentType { get; set; }

        /// <summary>
        /// Gets or sets the SelectedOrderBy
        /// </summary>
        public int TransactionsSelectedOrderBy { get; set; }

        /// <summary>
        /// Gets or sets the StartingValue
        /// </summary>
        public string TransactionsStartingValue { get; set; }

        /// <summary>
        /// Gets or sets the TransactionsStartingDate
        /// </summary>
        public DateTime? TransactionsStartingDate { get; set; }

        /// <summary>
        /// Gets or sets the SelectedCurrencyType
        /// </summary>
        public FuncOrVendorCurrency SelectedCurrencyType { get; set; }

        /// <summary>
        /// Gets or sets IncludeFullyPaidTransactions
        /// </summary>
        public bool IncludeFullyPaidTransactions { get; set; }

        /// <summary>
        /// Gets or sets IncludePendingAmounts
        /// </summary>
        public bool IncludePendingAmounts { get; set; }

        /// <summary>
        /// Gets or sets SelectedOrderBy
        /// </summary>
        public int SelectedPaymentsOrderBy { get; set; }

        /// <summary>
        /// Gets or sets the StartingValue
        /// </summary>
        public string PaymentsStartingValue { get; set; }

        /// <summary>
        /// Gets or sets the StartingValue
        /// </summary>
        public DateTime? PaymentsStartingDate { get; set; }

        /// <summary>
        /// Gets or sets the SelectedStatus
        /// </summary>
        public int SelectedStatus { get; set; }
    }
}
