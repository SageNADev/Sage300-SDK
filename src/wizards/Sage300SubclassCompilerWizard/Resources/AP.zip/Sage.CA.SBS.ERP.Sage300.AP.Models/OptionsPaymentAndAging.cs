/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for Account Payable Options PaymentAndAging
    /// </summary>
    public partial class OptionsPaymentAndAging : ModelBase
    {

        /// <summary>
        /// Gets or sets OptionsRecordKey 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.OptionsRecordKey, Id = Index.OptionsRecordKey, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string OptionsRecordKey { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets NextPaymentBatchNumber 
        /// </summary>
        [ViewField(Name = Fields.NextPaymentBatchNumber, Id = Index.NextPaymentBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextPaymentBatchNumber { get; set; }
        /// <summary>
        /// Gets or sets NextAdjustmentBatchNumber 
        /// </summary>
        [ViewField(Name = Fields.NextAdjustmentBatchNumber, Id = Index.NextAdjustmentBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextAdjustmentBatchNumber { get; set; }
        
        /// <summary>
        /// Gets or sets DefaultOrderOfOpenDocuments 
        /// </summary>
        [Display(Name = "DefaultOrderOpenDocs", ResourceType = typeof(OptionsResx))]
        public DefaultOrderofOpenDocuments DefaultOrderOfOpenDocuments { get; set; }
        
        /// <summary>
        /// Gets or sets AgingPeriod1 
        /// </summary>
        [ViewField(Name = Fields.AgingPeriod1, Id = Index.AgingPeriod1, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod1 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod2 
        /// </summary>
        [ViewField(Name = Fields.AgingPeriod2, Id = Index.AgingPeriod2, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod3 
        /// </summary>
        [ViewField(Name = Fields.AgingPeriod3, Id = Index.AgingPeriod3, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets AgeCreditNotesDebitNotes 
        /// </summary>
        [Display(Name = "AgeUnapCNDN", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.AgeCreditNotesDebitNotes, Id = Index.AgeCreditNotesDebitNotes, FieldType = EntityFieldType.Int, Size = 2)]
        public AgeCreditNotesDebitNotes AgeCreditNotesDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets DateLastPreregistered 
        /// </summary>
        [ViewField(Name = Fields.DateLastPreregistered, Id = Index.DateLastPreregistered, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastPreregistered { get; set; }

        /// <summary>
        /// Gets or sets TimeLastPreregistered 
        /// </summary>
        [ViewField(Name = Fields.TimeLastPreregistered, Id = Index.TimeLastPreregistered, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime TimeLastPreregistered { get; set; }

        /// <summary>
        /// Gets or sets DateLastDirectCheck 
        /// </summary>
        [ViewField(Name = Fields.DateLastDirectCheck, Id = Index.DateLastDirectCheck, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastDirectCheck { get; set; }

        /// <summary>
        /// Gets or sets TimeLastDirectCheck 
        /// </summary>
        [ViewField(Name = Fields.TimeLastDirectCheck, Id = Index.TimeLastDirectCheck, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime TimeLastDirectCheck { get; set; }

        /// <summary>
        /// Gets or sets DateLastSysCheck 
        /// </summary>
        [ViewField(Name = Fields.DateLastSysCheck, Id = Index.DateLastSysCheck, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastSysCheck { get; set; }

        /// <summary>
        /// Gets or sets TimeLastSysCheck 
        /// </summary>
        [ViewField(Name = Fields.TimeLastSysCheck, Id = Index.TimeLastSysCheck, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime TimeLastSysCheck { get; set; }

        /// <summary>
        /// Gets or sets AllowEditofSystemBatches 
        /// </summary>
        [Display(Name = "AllowEditSystem", ResourceType = typeof(OptionsResx))]
        public AllowedType AllowEditOfSystemBatches { get; set; }

        /// <summary>
        /// Gets or sets DefaultBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultBankCode", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultBankCode, Id = Index.DefaultBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string DefaultBankCode { get; set; }
        
        /// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultPaymentCode", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets NextPrepaymentNumber 
        /// </summary>
        [ViewField(Name = Fields.NextPrepaymentNumber, Id = Index.NextPrepaymentNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextPrepaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets NextPaymentPostingSequence 
        /// </summary>
        [ViewField(Name = Fields.NextPaymentPostingSequence, Id = Index.NextPaymentPostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextPaymentPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets NextAdjustmentPostingSequence 
        /// </summary>
        [ViewField(Name = Fields.NextAdjustmentPostingSequence, Id = Index.NextAdjustmentPostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextAdjustmentPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets AllowAdjustmentsInPaymentBat 
        /// </summary>
        [Display(Name = "AllowAdjInPaymBtch", ResourceType = typeof(OptionsResx))]
        public AllowedType AllowAdjustmentsInPaymentBat { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentPrefix 
        /// </summary>
        [ViewField(Name = Fields.PrepaymentPrefix, Id = Index.PrepaymentPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string PrepaymentPrefix { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentNumberLength 
        /// </summary>
        [ViewField(Name = Fields.PrepaymentNumberLength, Id = Index.PrepaymentNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal PrepaymentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets AgeUnappliedCashPrepayments 
        /// </summary>
        [Display(Name = "AgeUnapPP", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.AgeUnappliedCashPrepayments, Id = Index.AgeUnappliedCashPrepayments, FieldType = EntityFieldType.Int, Size = 2)]
        public AgeCreditNotesDebitNotes AgeUnappliedCashPrepayments { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentPrefix 
        /// </summary>
        [ViewField(Name = Fields.AdjustmentPrefix, Id = Index.AdjustmentPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string AdjustmentPrefix { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentNumberLength 
        /// </summary>
        [ViewField(Name = Fields.AdjustmentNumberLength, Id = Index.AdjustmentNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal AdjustmentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextAdjustmentNumber 
        /// </summary>
        [ViewField(Name = Fields.NextAdjustmentNumber, Id = Index.NextAdjustmentNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextAdjustmentNumber { get; set; }

        /// <summary>
        /// Gets or sets RecurringPayablePrefix 
        /// </summary>
        [ViewField(Name = Fields.RecurringPayablePrefix, Id = Index.RecurringPayablePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RecurringPayablePrefix { get; set; }

        /// <summary>
        /// Gets or sets RecurringPayableNumberLength 
        /// </summary>
        [ViewField(Name = Fields.RecurringPayableNumberLength, Id = Index.RecurringPayableNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RecurringPayableNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextRecurringPayableNumber 
        /// </summary>
        [ViewField(Name = Fields.NextRecurringPayableNumber, Id = Index.NextRecurringPayableNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRecurringPayableNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultTransactionType 
        /// </summary>
        [Display(Name = "DefaultTrxType", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultTransactionType, Id = Index.DefaultTransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultTransactionType DefaultTransactionType { get; set; }

        /// <summary>
        /// Gets or sets PaymentPrefix 
        /// </summary>
        [ViewField(Name = Fields.PaymentPrefix, Id = Index.PaymentPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string PaymentPrefix { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumberLength 
        /// </summary>
        [ViewField(Name = Fields.PaymentNumberLength, Id = Index.PaymentNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal PaymentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextPaymentNumber 
        /// </summary>
        [ViewField(Name = Fields.NextPaymentNumber, Id = Index.NextPaymentNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextPaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets RetainageInvoicePrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageInvoicePrefix, Id = Index.RetainageInvoicePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RetainageInvoicePrefix { get; set; }

        /// <summary>
        /// Gets or sets RetainageInvoiceNumberLength 
        /// </summary>
        [ViewField(Name = Fields.RetainageInvoiceNumberLength, Id = Index.RetainageInvoiceNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RetainageInvoiceNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextRetainageInvoiceNumber 
        /// </summary>
        [ViewField(Name = Fields.NextRetainageInvoiceNumber, Id = Index.NextRetainageInvoiceNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRetainageInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets RetainageCreditNotePrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageCreditNotePrefix, Id = Index.RetainageCreditNotePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RetainageCreditNotePrefix { get; set; }

        /// <summary>
        /// Gets or sets RetainageCreditNoteNoLength 
        /// </summary>
        [ViewField(Name = Fields.RetainageCreditNoteNoLength, Id = Index.RetainageCreditNoteNoLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RetainageCreditNoteNoLength { get; set; }

        /// <summary>
        /// Gets or sets NextRetainageCreditNoteNo 
        /// </summary>
        [ViewField(Name = Fields.NextRetainageCreditNoteNo, Id = Index.NextRetainageCreditNoteNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRetainageCreditNoteNo { get; set; }

        /// <summary>
        /// Gets or sets RetainageDebitNotePrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageDebitNotePrefix, Id = Index.RetainageDebitNotePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RetainageDebitNotePrefix { get; set; }

        /// <summary>
        /// Gets or sets RetainageDebitNoteNoLength 
        /// </summary>
        [ViewField(Name = Fields.RetainageDebitNoteNoLength, Id = Index.RetainageDebitNoteNoLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RetainageDebitNoteNoLength { get; set; }

        /// <summary>
        /// Gets or sets NextRetainageDebitNoteNo 
        /// </summary>
        [ViewField(Name = Fields.NextRetainageDebitNoteNo, Id = Index.NextRetainageDebitNoteNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRetainageDebitNoteNo { get; set; }

        /// <summary>
        /// Gets or sets UseRetainage 
        /// </summary>
        [Display(Name = "RetainageAccounting", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.UseRetainage, Id = Index.UseRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType UseRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageBase 
        /// </summary>
        [Display(Name = "BaseRetainageAmountOn", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.RetainageBase, Id = Index.RetainageBase, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageBase RetainageBase { get; set; }

        /// <summary>
        /// Gets or sets RetainageSchedule 
        /// </summary>
        [Display(Name = "ScheduleToUse", ResourceType = typeof(OptionsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageSchedule, Id = Index.RetainageSchedule, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string RetainageSchedule { get; set; }

        /// <summary>
        /// Gets or sets RetainageScheduleLink 
        /// </summary>
        [ViewField(Name = Fields.RetainageScheduleLink, Id = Index.RetainageScheduleLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RetainageScheduleLink { get; set; }

        /// <summary>
        /// Gets or sets DateRetainageSchedLastRun 
        /// </summary>
        [Display(Name = "LastInvoiced", ResourceType = typeof(OptionsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateRetainageSchedLastRun, Id = Index.DateRetainageSchedLastRun, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateRetainageSchedLastRun { get; set; }

        /// <summary>
        /// Gets or sets DaysRetained 
        /// </summary>
        [Display(Name = "DefaultPeriod", ResourceType = typeof(OptionsResx))]
        [Range(typeof(int), "0", "32767", ErrorMessageResourceName = "Range",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DaysRetained, Id = Index.DaysRetained, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysRetained { get; set; }

        /// <summary>
        /// Gets or sets PercentRetained 
        /// </summary>
        [Display(Name = "DefaultPercentage", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.PercentRetained, Id = Index.PercentRetained, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentRetained { get; set; }

        /// <summary>
        /// Gets or sets DaysBeforeRetainageDue 
        /// </summary>
        [Display(Name = "NoDaysAdvanceCreateDocs", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DaysBeforeRetainageDue, Id = Index.DaysBeforeRetainageDue, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysBeforeRetainageDue { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate 
        /// </summary>
        [Display(Name = "DefaultRetainageExchangeRate", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets ReportRetainageTax 
        /// </summary>
        [Display(Name = "ReportTax", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.ReportRetainageTax, Id = Index.ReportRetainageTax, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportRetainageTax ReportRetainageTax { get; set; }

        /// <summary>
        /// Gets or sets AllowEditOfRemitToInfo 
        /// </summary>
        [Display(Name = "AllowRmitToChange", ResourceType = typeof(OptionsResx))]
        public AllowedType AllowEditOfRemitToInfo { get; set; }

        /// <summary>
        /// Gets or sets CheckForDuplicateChecks 
        /// </summary>
        [Display(Name = "CheckForDuplicateChecks", ResourceType = typeof(OptionsResx))]
        public CheckforDuplicateChecks CheckForDuplicateChecks { get; set; }

        /// <summary>
        /// Gets or sets IncludePendingTransactions 
        /// </summary>

        [Display(Name = "CheckForPendingPayment", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.IncludePendingTransactions, Id = Index.IncludePendingTransactions, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePendingTransactions IncludePendingTransactions { get; set; }

        /// <summary>
        /// Gets or sets DefaultPostingDate 
        /// </summary>
        [Display(Name = "DefaultPostingDate", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultPostingDate, Id = Index.DefaultPostingDate, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultPostingDate DefaultPostingDate { get; set; }

        /// <summary>
        /// Gets or sets SortChecksBy 
        /// </summary>
        [Display(Name = "SortChecksBy", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.SortChecksBy, Id = Index.SortChecksBy, FieldType = EntityFieldType.Int, Size = 2)]
        public SortChecksBy SortChecksBy { get; set; }

        #region"Transactions-Options extended properties for UI"



        /// <summary>
        /// Gets or sets Default Payment Code Description 
        /// </summary>        
        [Display(Name = "PaymentCodeDescription", ResourceType = typeof(OptionsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DefaultPaymentCodeDescription { get; set; }


        /// <summary>
        /// Gets or sets Default Bank Code Description 
        /// </summary>        
        [Display(Name = "BankCodeDesc", ResourceType = typeof(OptionsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DefaultBankCodeDescription { get; set; }

        #endregion
    }
}
