/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class DocumentPayment : ModelBase
    {
        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "VendorNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "DocumentNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "PaymentNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CheckNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Char, Size = 18, Mask = "%-18D")]
        public string CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingDate 
        /// </summary>
        [Required(ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "PostingDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string PostingDate { get; set; }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "DocumentType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentPaymentDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets SequenceNo 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.SequenceNo, Id = Index.SequenceNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal SequenceNo { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string BatchDate { get; set; }

        /// <summary>
        /// Gets or sets FuncPaymentAmount 
        /// </summary>
        [Display(Name = "PaymentAmount", ResourceType = typeof(APCommonResx))]
        public decimal FunctionalPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets VendorPaymentAmount 
        /// </summary>
        [Display(Name = "VendorAmount", ResourceType = typeof(APCommonResx))]
        public decimal VendorPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateOverridden 
        /// </summary>
        [Display(Name = "RateOverridden", ResourceType = typeof(DocumentResx))]
        [ViewField(Name = Fields.RateOverridden, Id = Index.RateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden RateOverridden { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Bank", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentPaymentTransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets ReferenceDocumentNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReferenceDocumentNo, Id = Index.ReferenceDocumentNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ReferenceDocumentNo { get; set; }

        /// <summary>
        /// Gets or sets RemittingVendorNo 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RemittingVendorNo, Id = Index.RemittingVendorNo, FieldType = EntityFieldType.Char, Size = 12)]
        public string RemittingVendorNo { get; set; }

        /// <summary>
        /// Gets or sets CheckDate 
        /// </summary>
        [Display(Name = "CheckDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CheckDate, Id = Index.CheckDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CheckDate { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Display(Name = "EntryNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string Period { get; set; }

        /// <summary>
        /// Gets or sets CheckSerialNumber 
        /// </summary>
        [Display(Name = "CheckSerialNumber", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.CheckSerialNumber, Id = Index.CheckSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long CheckSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Num1099OrCPRSCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Num1099OrCPRSCode, Id = Index.Num1099OrCPRSCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string Num1099OrCPRSCode { get; set; }

        /// <summary>
        /// Gets or sets Num1099OrCPRSAmount 
        /// </summary>
        [ViewField(Name = Fields.Num1099OrCPRSAmount, Id = Index.Num1099OrCPRSAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Num1099OrCPRSAmount { get; set; }

        /// <summary>
        /// Gets or sets RateDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator 
        /// </summary>
        [Display(Name = "RateOperator", ResourceType = typeof(PaymentInquiryResx))]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateOperator { get; set; }

        /// <summary>
        /// Get os set the string value of DocumentType property 
        /// </summary>
        [IgnoreExportImport]
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Get os set the string value of TransactionType property 
        /// </summary>
        [IgnoreExportImport]
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }
    }
}
