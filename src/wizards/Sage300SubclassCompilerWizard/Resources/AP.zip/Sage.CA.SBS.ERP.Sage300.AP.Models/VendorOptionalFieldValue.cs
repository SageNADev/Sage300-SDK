
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Name spaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Partial class for Vendor Optional Field Value.
    /// </summary>
	public partial class VendorOptionalFieldValue : ModelBase
	{
  		/// <summary>
        /// Gets or sets Vendor Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(VendorResx))]
        [Key]
 		[ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
 		public string VendorNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets Optional Field 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(APCommonResx))]
        [Key]
 		[ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
 		public string OptionalField {get; set;}
		 
  		/// <summary>
        /// Gets or sets Value 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Value", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
 		public string Value {get; set;}
		 
  		/// <summary>
        /// Gets or sets Type 
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(APCommonResx))]       
 		[ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
 		public Enums.Type Type {get; set;}
		 
  		/// <summary>
        /// Gets or sets Length 
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(APCommonResx))]        
 		[ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
 		public int Length {get; set;}
		 
  		/// <summary>
        /// Gets or sets Decimals 
        /// </summary>
         [Display(Name = "Decimals", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
 		public int Decimals {get; set;}
		 
  		/// <summary>
        /// Gets or sets Allow Blank 
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
 		public AllowBlank AllowBlank {get; set;}
		 
  		/// <summary>
        /// Gets or sets Validate 
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
 		public TaxIncluded Validate {get; set;}
		 
  		/// <summary>
        /// Gets or sets Value Set 
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(APCommonResx))]        
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank ValueSet { get; set; }
		 
  		/// <summary>
        /// Gets or sets Typed Value Field Index 
        /// </summary>
        [Display(Name = "TypedValueFieldIndex", ResourceType = typeof(VendorGroupResx))]
 		[ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
 		public long TypedValueFieldIndex {get; set;}
		 
  		/// <summary>
        /// Gets or sets TextValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TextValue", ResourceType = typeof(VendorGroupResx))]
 		[ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
 		public string TextValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets Amount Value 
        /// </summary>
        [Display(Name = "AmountValue", ResourceType = typeof(VendorGroupResx))]
 		[ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal AmountValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets Number Value 
        /// </summary>
        [Display(Name = "NumberValue", ResourceType = typeof(VendorGroupResx))]
 		[ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
 		public decimal NumberValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets Integer Value 
        /// </summary>
        [Display(Name = "IntegerValue", ResourceType = typeof(VendorGroupResx))]
 		[ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
 		public long IntegerValue {get; set;}
		 
  		/// <summary>
        /// Gets or sets Yes O rNo Value 
        /// </summary>
         [Display(Name = "YesOrNoValue", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.YesOrNoValue, Id = Index.YesOrNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank YesOrNoValue { get; set; }
		 
  		/// <summary>
        /// Gets or sets Date Value 
        /// </summary>
         [Display(Name = "DateValue", ResourceType = typeof(VendorGroupResx))]
 		[ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
 		public string DateValue {get; set;}
		
		/// <summary>
        /// Gets or sets Time Value 
        /// </summary>
        [Display(Name = "TimeValue", ResourceType = typeof(VendorGroupResx))]
         [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
         public DateTime TimeValue {get; set;}
	 
  		/// <summary>
        /// Gets or sets Optional Field Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
 		public string OptionalFieldDescription {get; set;}
		 
  		/// <summary>
        /// Gets or sets Value Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ValueDescription", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
 		public string ValueDescription {get; set;}

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }
	}
}
