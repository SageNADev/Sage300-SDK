//  Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class PostInvoice
    /// </summary>
    public partial class PostInvoice : ModelBase
    {

        /// <summary>
        /// Gets or sets ProcessAllBatches 
        /// </summary>

        [ViewField(Name = Fields.ProcessAllBatches, Id = Index.ProcessAllBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessAllBatches ProcessAllBatches { get; set; }

        /// <summary>
        /// Gets or sets FromBatch 
        /// </summary>

        [ViewField(Name = Fields.FromBatch, Id = Index.FromBatch, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal FromBatch { get; set; }

        /// <summary>
        /// Gets or sets ToBatch 
        /// </summary>

        [ViewField(Name = Fields.ToBatch, Id = Index.ToBatch, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal ToBatch { get; set; }
    }
}
