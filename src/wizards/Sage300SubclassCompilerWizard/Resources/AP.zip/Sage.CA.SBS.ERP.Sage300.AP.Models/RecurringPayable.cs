// Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for Recurring Payable model
    /// </summary>
    public partial class RecurringPayable : ModelBase
    {
        /// <summary>
        /// This constructor initializes EnumerableResponses/Lists to be empty.
        /// This avoids the problem of serializing null collections.
        /// </summary>
        public RecurringPayable() 
        {
            OptionalFieldDetails = new EnumerableResponse<RecurringPayableOptionalField>();
            RecurringPayableDetail = new EnumerableResponse<RecurringPayableDetail>();
            RecurringPayableDetailValueDetails = new EnumerableResponse<RecurringPayableDetailValue>();
            RemitToLocations = new RemitToInfo();
            // Casts from List to IList.
        }

        /// <summary>
        /// Gets or sets Recurring Payable Code 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecurringPayableCode", ResourceType = typeof(RecurringPayableResx))]
        [Key]
        [ViewField(Name = Fields.RecurringPayableCode, Id = Index.RecurringPayableCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string RecurringPayableCode { get; set; }

        /// <summary>
        /// Gets or sets Vendor Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(RecurringPayableResx))]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }
       
        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or set IsStatusActive for validating the inactive checkbox
        /// </summary> 
        [IgnoreExportImport]
        public bool IsStatusActive
        {
            get { return Status == Status.Inactive; }
            set { Status = value == false ? Status.Active : Status.Inactive; }
        }

        /// <summary>
        /// Gets or sets Status Description for showing status as text instead of numeric
        /// </summary> 
        [Display(Name = "Status", ResourceType = typeof(RecurringPayableResx))]
        public string StatusDescription { 
            get { return EnumUtility.GetStringValue(Status); } 
            set { }
        }

        /// <summary>
        /// Gets or sets Inactive Date 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(RecurringPayableResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? InactiveDate { get; set; }

        /// <summary>
        /// Gets Conversion of Inactive Date into DateTime 
        /// </summary>    
        [IgnoreExportImport]
        public DateTime InactiveDateDesc
        {
            get
            {
                return DateUtil.GetDate(InactiveDate, DateUtil.GetMinDate());
            }
        }

        /// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>
        [Display(Name = "DateLastMaintained", ResourceType = typeof(RecurringPayableResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateLastMaintained { get; set; }

        /// <summary>
        /// Gets Conversion of Date Last Maintained for finder
        /// </summary>
        [IgnoreExportImport]
        public DateTime DateLastMaintainedDesc
        {
            get
            {
                return DateUtil.GetDate(DateLastMaintained, DateUtil.GetNowDate());
            }
        }

        /// <summary>
        /// Gets or sets Effective Date 
        /// </summary>
        [IgnoreExportImport]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EffectiveDate", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.EffectiveDate, Id = Index.EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? EffectiveDate { get; set; }

        /// <summary>
        /// Gets Conversion of Effective Date for finder
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "EffectiveDate", ResourceType = typeof(RecurringPayableResx))]
        public DateTime EffectiveDateDesc
        {
            get
            {
                return DateUtil.GetDate(EffectiveDate, DateUtil.GetMinDate());
            }
        }

        /// <summary>
        /// Gets or sets Expiration Type 
        /// </summary>
        [Display(Name = "ExpirationType", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.ExpirationType, Id = Index.ExpirationType, FieldType = EntityFieldType.Int, Size = 2)]
        public ExpirationType ExpirationType { get; set; }

        /// <summary>
        /// Gets or sets Expiration Type for showing Expiration Type as text instead of numeric
        /// </summary> 
        [IgnoreExportImport]
        public string ExpirationTypeDesc { 
            get { return EnumUtility.GetStringValue(ExpirationType); } 
            set { } 
        }

        /// <summary>
        /// Gets or sets Expiration Date 
        /// </summary>
        [Display(Name = "ExpirationDate", ResourceType = typeof(RecurringPayableResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// Gets Conversion of Effective Date for finder
        /// </summary>
        [Display(Name = "ExpirationDate", ResourceType = typeof(RecurringPayableResx))]
        [IgnoreExportImport]
        public DateTime ExpirationDateDesc
        {
            get
            {
                return DateUtil.GetDate(ExpirationDate, DateUtil.GetMinDate());
            }
        }

        /// <summary>
        /// Gets or sets MaximumNumber of Invoices 
        /// </summary>
        [Display(Name = "MaximumNumberofInvoices", ResourceType = typeof(RecurringPayableResx))]
        [RegularExpression(RegularExpressions.OnlyNumeric)]
        [ViewField(Name = Fields.MaximumNumberofInvoices, Id = Index.MaximumNumberofInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public int MaximumNumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets Maximum Total Invoice Amount 
        /// </summary>
        [Display(Name = "MaximumTotalInvoiceAmount", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.MaximumTotalInvoiceAmount, Id = Index.MaximumTotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaximumTotalInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets Total Invoice Amount
        /// </summary>
        public decimal TotalInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets Total Invoice Count
        /// </summary>
        public int TotalInvoiceCount { get; set; }

        /// <summary>
        /// Gets or sets Last Invoice Date Posted 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastInvoiceDatePosted", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.LastInvoiceDatePosted, Id = Index.LastInvoiceDatePosted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastInvoiceDatePosted { get; set; }

        /// <summary>
        /// Gets Conversion of Last Invoice Date Posted for finder
        /// </summary>
        [Display(Name = "LastInvoiceDatePosted", ResourceType = typeof(RecurringPayableResx))]
        [IgnoreExportImport]
        public DateTime LastInvoiceDatePostedDesc
        {
            get
            {
                return DateUtil.GetDate(LastInvoiceDatePosted, DateUtil.GetMinDate());
            }
        }

        /// <summary>
        /// Gets or sets Last Invoice Amount Posted 
        /// </summary>
        [Display(Name = "LastInvoiceAmountPosted", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.LastInvoiceAmountPosted, Id = Index.LastInvoiceAmountPosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmountPosted { get; set; }

        /// <summary>
        /// Gets or sets Year To Date Number of Invoices 
        /// </summary>
        [Display(Name = "YearToDateNumberofInvoices", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.YearToDateNumberofInvoices, Id = Index.YearToDateNumberofInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public int YearToDateNumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets Year To Date Total Invoice Amount 
        /// </summary>
        [Display(Name = "YearToDateTotalInvoiceAmount", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.YearToDateTotalInvoiceAmount, Id = Index.YearToDateTotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YearToDateTotalInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets Order Number 
        /// </summary>
        [Display(Name = "OrderNumber", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PO Number 
        /// </summary>
        [Display(Name = "PONumber", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PONumber { get; set; }

        /// <summary>
        /// Gets or sets Invoice Description 
        /// </summary>
        [Display(Name = "InvoiceDescription", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceDescription, Id = Index.InvoiceDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceDescription { get; set; }

        /// <summary>
        /// Gets or sets Remit To Location 
        /// </summary>
        [Display(Name = "RemitToLocation", ResourceType = typeof(APCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RemitToLocation, Id = Index.RemitToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RemitToLocation { get; set; }

        /// <summary>
        /// Gets or sets Currency Code 
        /// </summary>
        [Display(Name = "CurrencyCode", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets Rate Type 
        /// </summary>
        [Display(Name = "RateType", ResourceType = typeof(RecurringPayableResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets Terms 
        /// </summary>
        [Display(Name = "Terms", ResourceType = typeof(RecurringPayableResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets Terms Description
        /// </summary>
        public string TermsDesc { get; set; }

        /// <summary>
        /// Gets or sets Distribution Set 
        /// </summary>
        [Display(Name = "DistributionSet", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DistributionSet, Id = Index.DistributionSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionSet { get; set; }

        /// <summary>
        /// Gets or sets Distribution Amount 
        /// </summary>
        [Display(Name = "DistributionAmount", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.DistributionAmount, Id = Index.DistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets Tax Group 
        /// </summary>
        [Display(Name = "TaxGroup", ResourceType = typeof(RecurringPayableResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets Tax Amount Control 
        /// </summary>
        [Display(Name = "TaxAmountControl", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmountControl, Id = Index.TaxAmountControl, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxAmountControl TaxAmountControl { get; set; }

        /// <summary>
        /// Gets or sets Tax Amount Control for showing Tax Amount Control as text instead of numeric
        /// </summary> 
        [Display(Name = "TaxAmountControl", ResourceType = typeof(RecurringPayableResx))]
        public string TaxAmountControlDesc { 
            get { return EnumUtility.GetStringValue(TaxAmountControl); } 
            set { } 
        }

        /// <summary>
        /// Gets or sets Tax Authority 1 
        /// </summary>
        [Display(Name = "TaxAuthority1", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets Tax Authority 2 
        /// </summary>
        [Display(Name = "TaxAuthority2", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets Tax Authority 3 
        /// </summary>
        [Display(Name = "TaxAuthority3", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets Tax Authority 4 
        /// </summary>
        [Display(Name = "TaxAuthority4", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets Tax Authority 5 
        /// </summary>
        [Display(Name = "TaxAuthority5", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets Tax Class 1 
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets Tax Class 2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets Tax Class 3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets Tax Class 4 
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets Tax Class 5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets Tax Inclusive 1 
        /// </summary>
        [Display(Name = "TaxInclusive1", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxInclusive1, Id = Index.TaxInclusive1, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxInclusive1 { get; set; }

        /// <summary>
        /// Gets or sets Tax Inclusive 1  for showing Tax Inclusive 1 Control as text instead of numeric
        /// </summary> 
        [Display(Name = "TaxInclusive1", ResourceType = typeof(RecurringPayableResx))]
        public string TaxInclusive1Desc { get { return EnumUtility.GetStringValue(TaxInclusive1); } set { } }

        /// <summary>
        /// Gets or sets Tax Inclusive 2 
        /// </summary>
        [Display(Name = "TaxInclusive2", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxInclusive2, Id = Index.TaxInclusive2, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxInclusive2 { get; set; }

        /// <summary>
        /// Gets or sets Tax Inclusive 2  for showing Tax Inclusive 1 Control as text instead of numeric
        /// </summary> 
        public string TaxInclusive2Desc { get { return EnumUtility.GetStringValue(TaxInclusive2); } set { } }

        /// <summary>
        /// Gets or sets Tax Inclusive 3 
        /// </summary>
        [Display(Name = "TaxInclusive3", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxInclusive3, Id = Index.TaxInclusive3, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxInclusive3 { get; set; }

        /// <summary>
        /// Gets or sets Tax Inclusive 3  for showing Tax Inclusive 1 Control as text instead of numeric
        /// </summary> 
        [Display(Name = "TaxInclusive3", ResourceType = typeof(RecurringPayableResx))]
        public string TaxInclusive3Desc { get { return EnumUtility.GetStringValue(TaxInclusive3); } set { } }

        /// <summary>
        /// Gets or sets Tax Inclusive 4 
        /// </summary>
         [Display(Name = "TaxInclusive4", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxInclusive4, Id = Index.TaxInclusive4, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxInclusive4 { get; set; }

        /// <summary>
        /// Gets or sets Tax Inclusive 4  for showing Tax Inclusive 1 Control as text instead of numeric
        /// </summary> 
           [Display(Name = "TaxInclusive4", ResourceType = typeof(RecurringPayableResx))]
        public string TaxInclusive4Desc { get { return EnumUtility.GetStringValue(TaxInclusive4); } set { } }

        /// <summary>
        /// Gets or sets Tax Inclusive 5 
        /// </summary>
        [Display(Name = "TaxInclusive5", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxInclusive5, Id = Index.TaxInclusive5, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxInclusive5 { get; set; }

        /// <summary>
        /// Gets or sets Tax Inclusive 5  for showing Tax Inclusive 1 Control as text instead of numeric
        /// </summary> 
         [Display(Name = "TaxInclusive5", ResourceType = typeof(RecurringPayableResx))]
        public string TaxInclusive5Desc { get { return EnumUtility.GetStringValue(TaxInclusive5); } set { } }

        /// <summary>
        /// Gets or sets Tax Amount 1 
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets Tax Amount 2 
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets Tax Amount 3 
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets Tax Amount 4 
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets Tax Amount 5 
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets Distributed Total Before Taxes 
        /// </summary>
        [Display(Name = "DistributedTotalBeforeTaxes", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.DistributedTotalBeforeTaxes, Id = Index.DistributedTotalBeforeTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistributedTotalBeforeTaxes { get; set; }

        /// <summary>
        /// Gets or sets Invoice Subtotal 
        /// </summary>
        [Display(Name = "InvoiceSubtotal", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.InvoiceSubtotal, Id = Index.InvoiceSubtotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceSubtotal { get; set; }

        /// <summary>
        /// Gets or sets Num 1099 Or CPRS Code 
        /// </summary>
        [Display(Name = "_1099CPRSCode", ResourceType = typeof(APCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Num1099OrCprsCode, Id = Index.Num1099OrCprsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Num1099OrCprsCode { get; set; }

        /// <summary>
        /// Gets or sets Num 1099 Or CPRS Amount 
        /// </summary>
        [Display(Name = "_1099CPRSAmount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Num1099OrCprsAmount, Id = Index.Num1099OrCprsAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Num1099OrCprsAmount { get; set; }

        /// <summary>
        /// Gets or sets Last Detail Seq No 
        /// </summary>
        [Display(Name = "LastDetailSeqNo", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.LastDetailSeqNo, Id = Index.LastDetailSeqNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LastDetailSeqNo { get; set; }

        /// <summary>
        /// Gets or sets Schedule 
        /// </summary>
        [Display(Name = "ScheduleCode", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Schedule, Id = Index.Schedule, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Schedule { get; set; }

        /// <summary>
        /// Gets or sets Schedule Link 
        /// </summary>
        [Display(Name = "ScheduleLink", ResourceType = typeof(RecurringPayableResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ScheduleLink, Id = Index.ScheduleLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ScheduleLink { get; set; }

        /// <summary>
        /// Gets or sets Document Total 
        /// </summary>
        [Display(Name = "DocumentTotal", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DocumentTotal, Id = Index.DocumentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentTotal { get; set; }

        /// <summary>
        /// Gets or sets Tax Base 1 
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets Tax Base 2 
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets Tax Base 3 
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets Tax Base 4 
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets Tax Base 5 
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets Invoice Taxable 
        /// </summary>
        [Display(Name = "InvoiceTaxable", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.InvoiceTaxable, Id = Index.InvoiceTaxable, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded InvoiceTaxable { get; set; }

        /// <summary>
        /// Gets or sets Expiration Type for showing Expiration Type as text instead of numeric
        /// </summary> 
        public string InvoiceTaxableDesc { 
            get { return EnumUtility.GetStringValue(InvoiceTaxable); } 
        }

        /// <summary>
        /// Gets or sets Tax Base Control 
        /// </summary>
        [Display(Name = "TaxBaseControl", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBaseControl, Id = Index.TaxBaseControl, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxAmountControl TaxBaseControl { get; set; }

        /// <summary>
        /// Gets or sets Expiration Type for showing Expiration Type as text instead of numeric
        /// </summary> 
        public string TaxBaseControlDesc { get { return EnumUtility.GetStringValue(TaxBaseControl); } set { } }

        /// <summary>
        /// Gets or sets Total Dist Tax inclin Price 
        /// </summary>
        [Display(Name = "TotalDistTaxinclinPrice", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TotalDistTaxinclinPrice, Id = Index.TotalDistTaxinclinPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDistTaxinclinPrice { get; set; }

        /// <summary>
        /// Gets or sets Total Dist Taxexcl from Price 
        /// </summary>
        [Display(Name = "TotalDistTaxexclfromPrice", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TotalDistTaxexclfromPrice, Id = Index.TotalDistTaxexclfromPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDistTaxexclfromPrice { get; set; }

        /// <summary>
        /// Gets or sets Total Tax Amount 
        /// </summary>
        [Display(Name = "TotalTaxAmount", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TotalTaxAmount, Id = Index.TotalTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets EstimatedTaxWithheld Amount1 
        /// </summary>
        [Display(Name = "TaxWithheldAmount1", ResourceType = typeof(InvoiceResx))]
        public decimal TaxWithheldAmount1 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedTaxWithheld Amount2 
        /// </summary>
        [Display(Name = "TaxWithheldAmount2", ResourceType = typeof(InvoiceResx))]
        public decimal TaxWithheldAmount2 { get; set; }
        /// <summary>
        /// Gets or sets EstimatedTaxWithheld Amount3 
        /// </summary>
        [Display(Name = "TaxWithheldAmount3", ResourceType = typeof(InvoiceResx))]
        public decimal TaxWithheldAmount3 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedTaxWithheld Amount4 
        /// </summary>
        [Display(Name = "TaxWithheldAmount4", ResourceType = typeof(InvoiceResx))]
        public decimal TaxWithheldAmount4 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedTaxWithheld Amount5 
        /// </summary>
        [Display(Name = "TaxWithheldAmount5", ResourceType = typeof(InvoiceResx))]
        public decimal TaxWithheldAmount5 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase1
        /// </summary>
        [Display(Name = "CustomerTaxBase1", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase1, Id = Index.CustomerTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase1 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase2
        /// </summary>
        [Display(Name = "CustomerTaxBase2", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase2, Id = Index.CustomerTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase2 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase3
        /// </summary>
        [Display(Name = "CustomerTaxBase3", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase3, Id = Index.CustomerTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase3 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase4
        /// </summary>
        [Display(Name = "CustomerTaxBase4", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase4, Id = Index.CustomerTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase4 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase5
        /// /// </summary>
        [Display(Name = "CustomerTaxBase5", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase5, Id = Index.CustomerTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount1
        /// </summary>
        [Display(Name = "CustomerTaxAmount1", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount1, Id = Index.CustomerTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount1 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTax Amount2
        /// </summary>
        [Display(Name = "CustomerTaxAmount2", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount2, Id = Index.CustomerTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount3
        /// </summary>
        [Display(Name = "CustomerTaxAmount3", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount3, Id = Index.CustomerTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount4
        /// </summary>
        [Display(Name = "CustomerTaxAmount4", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount4, Id = Index.CustomerTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount5
        /// </summary>
        [Display(Name = "CustomerTaxAmount5", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount5, Id = Index.CustomerTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount5 { get; set; }

        /// <summary>
        /// Customer Tax Amount
        /// </summary>
        [Display(Name = "CustomerTaxAmount", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount, Id = Index.CustomerTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets Optional Fields 
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets Process Command 
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandRecurring ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets Expiration Type for showing Expiration Type as text instead of numeric
        /// </summary> 
        public string ProcessCommandDesc { get { return EnumUtility.GetStringValue(ProcessCommand); } set { } }

        /// <summary>
        /// Gets or sets Job Related 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded JobRelated { get; set; }
        
        /// <summary>
        /// Gets or sets JobRelated Description for showing JobRelated as text instead of numeric
        /// </summary> 
        [Display(Name = "JobRelated", ResourceType = typeof(APCommonResx))]
        public string JobRelatedString { get { return EnumUtility.GetStringValue(JobRelated); } set { } }

        /// <summary>
        /// Gets or set IsJobRelated for the job related checkbox
        /// </summary> 
        [IgnoreExportImport]
        public bool IsJobRelated
        {
            get { return JobRelated == TaxIncluded.Yes; }
            set { JobRelated = value == true ? TaxIncluded.Yes : TaxIncluded.No; }
        }

        /// <summary>
        /// Gets or sets Next Scheduled Date 
        /// </summary>
        [Display(Name = "NextScheduledDate", ResourceType = typeof(RecurringPayableResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NextScheduledDate, Id = Index.NextScheduledDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? NextScheduledDate { get; set; }

        /// <summary>
        /// Gets Conversion of Inactive Date into DateTime 
        /// </summary>
        [Display(Name = "NextScheduledDate", ResourceType = typeof(RecurringPayableResx))]
        [IgnoreExportImport]
        public DateTime NextScheduledDateDesc
        {
            get
            {
                return DateUtil.GetDate(NextScheduledDate, DateUtil.GetMinDate());
            }
        }

        /// <summary>
        /// Gets or sets Last Invoice Date Generated 
        /// </summary>
        [Display(Name = "LastInvoiceDateGenerated", ResourceType = typeof(RecurringPayableResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastInvoiceDateGenerated, Id = Index.LastInvoiceDateGenerated, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastInvoiceDateGenerated { get; set; }

        /// <summary>
        /// Gets Conversion of Inactive Date into DateTime 
        /// </summary>
        [Display(Name = "NextScheduledDate", ResourceType = typeof(RecurringPayableResx))]
        [IgnoreExportImport]
        public DateTime LastInvoiceDateGeneratedDesc
        {
            get
            {
                return DateUtil.GetDate(LastInvoiceDateGenerated, DateUtil.GetMinDate());
            }
        }

        /// <summary>
        /// Gets or sets Unposted Number of Invoices 
        /// </summary>
        [Display(Name = "UnpostedNumberofInvoices", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.UnpostedNumberofInvoices, Id = Index.UnpostedNumberofInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public int UnpostedNumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets Unposted Total Invoice Amount 
        /// </summary>
        [Display(Name = "UnpostedTotalInvoiceAmount", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.UnpostedTotalInvoiceAmount, Id = Index.UnpostedTotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnpostedTotalInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets Posted Number of Invoices 
        /// </summary>
        [Display(Name = "PostedNumberofInvoices", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.PostedNumberofInvoices, Id = Index.PostedNumberofInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public int PostedNumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets Posted Total Invoice Amount 
        /// </summary>
        [Display(Name = "PostedTotalInvoiceAmount", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.PostedTotalInvoiceAmount, Id = Index.PostedTotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PostedTotalInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets Last Invoice Number Posted 
        /// </summary>
        [Display(Name = "LastInvoiceNumberPosted", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastInvoiceNumberPosted, Id = Index.LastInvoiceNumberPosted, FieldType = EntityFieldType.Char, Size = 22)]
        public string LastInvoiceNumberPosted { get; set; }

        /// <summary>
        /// Gets or sets Last Batch Number Posted 
        /// </summary>
        [Display(Name = "LastBatchNumberPosted", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.LastBatchNumberPosted, Id = Index.LastBatchNumberPosted, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal LastBatchNumberPosted { get; set; }

        /// <summary>
        /// Gets or sets Last Entry Number Posted 
        /// </summary>
        [Display(Name = "LastEntryNumberPosted", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.LastEntryNumberPosted, Id = Index.LastEntryNumberPosted, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal LastEntryNumberPosted { get; set; }

        /// <summary>
        /// Gets or sets Last Posting SequenceNumber 
        /// </summary>
        [Display(Name = "LastPostingSequenceNumber", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.LastPostingSequenceNumber, Id = Index.LastPostingSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal LastPostingSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets Account Set 
        /// </summary>
        [Display(Name = "AccountSet", ResourceType = typeof(RecurringPayableResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets NewRecurringPayable
        /// </summary>
        [IgnoreExportImport]
        public bool NewRecurringPayable { get; set; }

        /// <summary>
        /// Gets or sets RecurringPayable Detail.
        /// </summary>
       [IgnoreExportImport]
        public EnumerableResponse<RecurringPayableDetail> RecurringPayableDetail { get; set; }

       /// <summary>
       /// Gets or sets RecurringPayable Tax Detail.
       /// </summary>
       [IgnoreExportImport]
        public List<TaxClassGroup> RecurringPayableTaxDetail { get; set; }

        /// <summary>
        /// Gets or sets RecurringPayable Detail.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<RecurringPayableDetailValue> RecurringPayableDetailValueDetails { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDetails
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<RecurringPayableOptionalField> OptionalFieldDetails { get; set; }

        /// <summary>
        /// Gets or sets VendorDetails
        /// </summary>
        [IgnoreExportImport]
        public VendorInfo VendorDetails { get; set; }

         /// <summary>
        /// Gets or sets RemitToLocations
        /// </summary>
        [IgnoreExportImport]
        public RemitToInfo RemitToLocations { get; set; } 
       
        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        [IgnoreExportImport]
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Line Number
        /// </summary>
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or Sets String conversion of LastInvoiceDatePosted
        /// </summary>
        [Display(Name = "LastInvoiceDatePosted", ResourceType = typeof(RecurringPayableResx))]
        [IgnoreExportImport]
        public string LastInvDateString
        {
            get
            {
                return DateUtil.GetShortDate(LastInvoiceDatePosted, string.Empty);
            }
        }

        /// <summary>
        /// Gets or sets Distribution Method
        /// </summary>
        [IgnoreExportImport]
        public DistributionMethod DistributionMethod { get; set; }

        /// <summary>
        /// Gets or Sets TaxGroup
        /// </summary>
        [IgnoreExportImport]
        public TaxGroup TaxGroupData { get; set; }
    }
}
