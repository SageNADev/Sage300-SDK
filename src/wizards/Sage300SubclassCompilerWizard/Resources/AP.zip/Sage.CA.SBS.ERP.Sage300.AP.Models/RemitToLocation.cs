// Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved. 

#region Namespace
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using System.Collections.Generic;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Partial class for Remit-To Location
    /// </summary>
    public partial class RemitToLocation : ModelBase
    {
        /// <summary>
        /// Constructor For Remit-To Location 
        /// </summary>
        public RemitToLocation()
        {
            RemitToLocationOptionalFields = new EnumerableResponse<RemitToLocationOptionalField>();            
        }

        /// <summary>
        /// Gets or sets Vendor Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "VendorNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets Remit-To Location  
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "RemitToLocation", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.RemitToLocationKey, Id = Index.RemitToLocationKey, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RemitToLocationKey { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Status Status { get; set; }

        /// <summary>
        /// Gets or sets Inactive Date 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.InActiveDate, Id = Index.InActiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InActiveDate { get; set; }

        /// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastMaintained", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Activity 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateofLastActivity", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DateOfLastActivity, Id = Index.DateOfLastActivity, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateOfLastActivity { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "RemitToDescription", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Address Line 1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets Address Line 2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets Address Line 3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets Address Line 4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State Or Province 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.StateOrProvince, Id = Index.StateOrProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateOrProvince { get; set; }

        /// <summary>
        /// Gets or sets Zip Or Postal Code 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ZIPPostalCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ZipOrPostalCode, Id = Index.ZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets Contact Name 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets Phone Number 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets Fax Number 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Check Language 
        /// </summary>
        [Display(Name = "CheckLanguage", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CheckLanguage, Id = Index.CheckLanguage, FieldType = EntityFieldType.Char, Size = 3)]
        public string CheckLanguage { get; set; }

        /// <summary>
        /// Gets or sets Primary Remit-to Indicator 
        /// </summary>
        [Display(Name = "PrimaryRemitTo", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PrimaryRemitToIndicator, Id = Index.PrimaryRemitToIndicator, FieldType = EntityFieldType.Int, Size = 2)]
        public PrimaryRemitToIndicator PrimaryRemitToIndicator { get; set; }

        /// <summary>
        /// Gets or sets Email 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets Contacts Phone 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ContactsPhone, Id = Index.ContactsPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsPhone { get; set; }

        /// <summary>
        /// Gets or sets Contacts Fax 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ContactsFax, Id = Index.ContactsFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsFax { get; set; }

        /// <summary>
        /// Gets or sets Contacts Email 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ContactsEmail, Id = Index.ContactsEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactsEmail { get; set; }

        /// <summary>
        /// Gets or sets Optional Fields 
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets Process Command Code 
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(RemitToLocationsResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCodeSelect ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets Suppress Integration 
        /// </summary>
        [Display(Name = "SuppressIntegration", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.SuppressIntegration, Id = Index.SuppressIntegration, FieldType = EntityFieldType.Bool, Size = 2)]
        public BooleanType SuppressIntegration { get; set; }

        /// <summary>
        /// Gets Suppress Integration string value
        /// </summary>
        public string SuppressIntegrationString
        {
            get { return EnumUtility.GetStringValue(SuppressIntegration); }
        }

        /// <summary>
        /// Gets or sets A/P Version 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AorPVersion", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.AorPVersion, Id = Index.AorPVersion, FieldType = EntityFieldType.Char, Size = 3)]
        public string AorPVersion { get; set; }

        /// <summary>
        /// Gets or sets DataBase 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Database", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DataBase, Id = Index.DataBase, FieldType = EntityFieldType.Char, Size = 6)]
        public string DataBase { get; set; }

        /// <summary>
        /// Gets or sets Mode 
        /// </summary>
        [Display(Name = "Mode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Mode, Id = Index.Mode, FieldType = EntityFieldType.Int, Size = 2)]
        public Mode Mode { get; set; }

        /// <summary>
        /// Gets or sets List of AP Remit-To Location Optional Fields values
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<RemitToLocationOptionalField> RemitToLocationOptionalFields { get; set; }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        [IgnoreExportImport]
        public string StatusString
        {
            get
            {
                return EnumUtility.GetStringValue(Status);
            }
        }

        /// <summary>
        /// To get the string of Primary Remit-to Indicator property
        /// </summary>
        [IgnoreExportImport]
        public string PrimaryRemitToIndicatorString
        {
            get
            {
                return EnumUtility.GetStringValue(PrimaryRemitToIndicator);
            }
        }

        /// <summary>
        /// To get the string of Process Command Code property
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandCodeString
        {
            get
            {
                return EnumUtility.GetStringValue(ProcessCommandCode);
            }
        }

        /// <summary>
        /// To get the string of Mode property
        /// </summary>
        [IgnoreExportImport]
        public string ModeString
        {
            get
            {
                return EnumUtility.GetStringValue(Mode);
            }
        }

        /// <summary>
        /// Gets or sets CheckLanguageList
        /// </summary>
        public IEnumerable<CustomSelectList> CheckLanguageList { get; set; }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }

        #region OPtional fields
        /// <summary>
        /// Gets or sets Is New Record
        /// </summary>
        [IgnoreExportImport]
        public bool IsNewRecord { get; set; }
        #endregion

    }
}
