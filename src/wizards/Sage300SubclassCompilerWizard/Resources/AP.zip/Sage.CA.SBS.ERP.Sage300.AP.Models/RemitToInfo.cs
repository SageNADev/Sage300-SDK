﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
#endregion


namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Partial class for Remit-To RemitToInfo
    /// </summary>
    public partial class RemitToInfo : ModelBase
    {

        /// <summary>
        /// Gets or sets Vendor Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "VendorNumber", ResourceType = typeof(APCommonResx))]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets Remit-To Location  
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "RemitToLocation", ResourceType = typeof(APCommonResx))]
        public string RemitToLocationKey { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToDescription", ResourceType = typeof(PaymentEntryResx))]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Address Line 1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(PaymentEntryResx))]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets Address Line 2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(PaymentEntryResx))]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets Address Line 3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof(PaymentEntryResx))]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets Address Line 4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof(PaymentEntryResx))]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(PaymentEntryResx))]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State Or Province 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof(PaymentEntryResx))]
        public string StateOrProv { get; set; }

        /// <summary>
        /// Gets or sets Zip Or Postal Code 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZIPPostalCode", ResourceType = typeof(PaymentEntryResx))]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(PaymentEntryResx))]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets Phone Number 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets Fax Number 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Email 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(CommonResx))]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets Contact Name 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof(CommonResx))]
        public string ContactName { get; set; }


        /// <summary>
        /// Gets or sets Contacts Phone 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        public string ContactsPhone { get; set; }

        /// <summary>
        /// Gets or sets Contacts Fax 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        public string ContactsFax { get; set; }

        /// <summary>
        /// Gets or sets Contacts Email 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(CommonResx))]
        public string ContactsEmail { get; set; }

    }
}