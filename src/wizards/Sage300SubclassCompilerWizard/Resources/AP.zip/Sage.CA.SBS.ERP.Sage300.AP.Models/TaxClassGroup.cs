﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.  */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// custom class for tax class grid in vendor
    /// </summary>
    public class TaxClassGroup : ModelBase
    {
        #region Properties


        /// <summary>
        /// Gets or Sets Recurring Payable Code
        /// </summary>
        public string RecurringPayableCode { get; set; }

        /// <summary>
        /// Gets or Sets Vendor Number
        /// </summary>
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or Sets Vendor Number
        /// </summary>
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or Sets Tax Authority
        /// </summary>
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or Sets Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or Sets Tax Class
        /// </summary>
        public int TaxClass { get; set; }

        /// <summary>
        /// Gets or Sets Registration Number
        /// </summary>
        public string RegistrationNumber { get; set; }

        /// <summary>
        /// Gets or Sets Tax Included
        /// </summary>
        public TaxIncluded TaxIncluded { get; set; }

        /// <summary>
        /// Gets or Sets IsAllowTaxInPrice
        /// </summary>
        public bool IsAllowTaxInPrice { get; set; }

        /// <summary>
        /// Gets or Sets Tax Base
        /// </summary>
        public decimal TaxBase { get; set; }

        /// <summary>
        /// Gets or Sets Tax Amount
        /// </summary>
        public decimal TaxAmount { get; set; }

        /// <summary>
        /// Gets or Sets Vendor Number
        /// </summary>
        public decimal SequenceNumber { get; set; }

        /// <summary>
        /// Check to include tax or not
        /// </summary>
        public string CanIncludeTax { get; set; }

        /// <summary>
        /// Gets or Sets Tax Currency
        /// </summary>
        public string TaxReportingCurrency { get; set; }

        #endregion
    }
}
