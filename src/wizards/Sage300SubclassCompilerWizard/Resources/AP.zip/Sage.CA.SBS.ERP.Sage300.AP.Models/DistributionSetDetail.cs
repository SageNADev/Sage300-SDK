/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class DistributionSetDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets DistributionSet
        /// </summary>
        /// <value>
        /// The distribution set.
        /// </value>
        [Display(Name = "DistributionSet", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DistributionSet, Id = Index.DistributionSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionSet { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        /// <value>
        /// The line number.
        /// </value>
        [Display(Name = "LineNumber", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode
        /// </summary>
        /// <value>
        /// The distribution code.
        /// </value>
        [Display(Name = "DistributionCode", ResourceType = typeof(APCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [Display(Name = "Description", ResourceType = typeof(APCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets GOrLAccount
        /// </summary>
        /// <value>
        /// The gl account.
        /// </value>
        [Display(Name = "GLAccount", ResourceType = typeof(APCommonResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets AccountDescription
        /// </summary>
        /// <value>
        /// The account description.
        /// </value>
        [Display(Name = "AccountDescription", ResourceType = typeof(APCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets Discountable
        /// </summary>
        /// <value>
        /// The discountable.
        /// </value>
        [Display(Name = "Discountable", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Discountable, Id = Index.Discountable, FieldType = EntityFieldType.Int, Size = 2)]
        public Discountable Discountable { get; set; }

        /// <summary>
        /// To get the string value of the Discountable property
        /// </summary>
        /// <value>
        /// The discountable string.
        /// </value>
        public string DiscountableString
        {
            get { return EnumUtility.GetStringValue(Discountable); }
        }

        /// <summary>
        /// Gets or sets Percentage
        /// </summary>
        /// <value>
        /// The percentage.
        /// </value>
        [Display(Name = "Percentage", ResourceType = typeof(DistributionSetsResx))]
        [ViewField(Name = Fields.Percentage, Id = Index.Percentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal Percentage { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        /// <value>
        /// The amount.
        /// </value>
        [Display(Name = "Amount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }
    }
}
