/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */


#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// A/P Options Contains list of properties for Company 
    /// </summary>
    public partial class Options : ModelBase
    {

        /// <summary>
        /// Gets or sets OptionsRecordKey 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.OptionsRecordKey, Id = Index.OptionsRecordKey, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string OptionsRecordKey { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency 
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.Multicurrency, Id = Index.Multicurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public Multicurrency Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets EditImports 
        /// </summary>
        [Display(Name = "AllowEditImported", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.EditImports, Id = Index.EditImports, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType EditImports { get; set; }
        
        /// <summary>
        /// Gets or sets ForceListingOfBatches 
        /// </summary>
        [Display(Name = "ForceBatchListing", ResourceType = typeof(OptionsResx))]
        public Multicurrency ForceListingOfBatches { get; set; }
        
        /// <summary>
        /// Gets or sets EditVendorStatistics 
        /// </summary>
        [Display(Name = "AllowEditOfStatistics", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.EditVendorStatistics, Id = Index.EditVendorStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType EditVendorStatistics { get; set; }

        /// <summary>
        /// Gets or sets IncTaxInVendorStatistics 
        /// </summary>
        [Display(Name = "InclTaxInStatistics", ResourceType = typeof(OptionsResx))]
        public AllowedType IncTaxInVendorStatistics { get; set; }

        /// <summary>
        /// Gets or sets VendorStatisticsYearType 
        /// </summary>
        [Display(Name = "AccumulateBy", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.VendorStatisticsYearType, Id = Index.VendorStatisticsYearType, FieldType = EntityFieldType.Int, Size = 2)]
        public VendorStatisticsYearType VendorStatisticsYearType { get; set; }

        /// <summary>
        /// Gets or sets VendorStatisticsPeriodType 
        /// </summary>
        [Display(Name = "PeriodType", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.VendorStatisticsPeriodType, Id = Index.VendorStatisticsPeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public VendorStatisticsPeriodType VendorStatisticsPeriodType { get; set; }
        
        /// <summary>
        /// Gets or sets DefaultNoDaysToKeepComment 
        /// </summary>
        [Display(Name = "DefaultCommentDays", ResourceType = typeof(OptionsResx))]
        [Range(typeof(decimal), "0", "99999", ErrorMessageResourceName = "Range",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyNumeric)]
        public decimal DefaultNoDaysToKeepComment { get; set; }

        /// <summary>
        /// Gets or sets NextRevaluationPostingSequenc 
        /// </summary>
        [ViewField(Name = Fields.NextRevaluationPostingSequenc, Id = Index.NextRevaluationPostingSequenc, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRevaluationPostingSequenc { get; set; }

        /// <summary>
        /// Gets or sets ContactName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactName", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets TelephoneNumber 
        /// </summary>
        [Display(Name = "PhoneNumber", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.TelephoneNumber, Id = Index.TelephoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string TelephoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber 
        /// </summary>
        [Display(Name = "FaxNumber", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets KeepHistory 
        /// </summary>
        [ViewField(Name = Fields.KeepHistory, Id = Index.KeepHistory, FieldType = EntityFieldType.Int, Size = 2)]
        public int KeepHistory { get; set; }

        /// <summary>
        /// Gets or sets KeepVendorStatistics 
        /// </summary>
        [Display(Name = "KeepStatistics", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.KeepVendorStatistics, Id = Index.KeepVendorStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType KeepVendorStatistics { get; set; }

        /// <summary>
        /// Gets or sets DefaultTaxAmountControl 
        /// </summary>
        [Display(Name = "InvoiceTaxAmountCtrl", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultTaxAmountControl, Id = Index.DefaultTaxAmountControl, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultTaxAmountControl DefaultTaxAmountControl { get; set; }

        /// <summary>
        /// Gets or sets EditExternalBatches 
        /// </summary>
        [Display(Name = "AllowEditExternalBatches", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.EditExternalBatches, Id = Index.EditExternalBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType EditExternalBatches { get; set; }

        /// <summary>
        /// Gets or sets DefaultTaxBaseControl 
        /// </summary>
        [Display(Name = "InvoiceTaxBaseCtrl", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultTaxBaseControl, Id = Index.DefaultTaxBaseControl, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultTaxAmountControl DefaultTaxBaseControl { get; set; }

        /// <summary>
        /// Gets or sets DefaultTaxReportingControl 
        /// </summary>
        [Display(Name = "InvoiceTaxReportingCtrl", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultTaxReportingControl, Id = Index.DefaultTaxReportingControl, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultTaxAmountControl DefaultTaxReportingControl { get; set; }

        /// <summary>
        /// Gets or sets DefaultDetailTaxClass 
        /// </summary>
        [Display(Name = "DefaultDetailTaxClassTo1", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultDetailTaxClass, Id = Index.DefaultDetailTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultDetailTaxClass DefaultDetailTaxClass { get; set; }

        #region CompanyProfile
        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        public CompanyProfile CompanyProfile { get; set; }
        #endregion

        #region "Invoicing-Options"
        /// <summary>
        /// Gets or Sets Invoicing Options
        /// </summary>
        public OptionsInvoicing OptionsInvoicing { get; set; }
        #endregion

        #region "Payment and Aging"
        /// <summary>
        /// Gets or Sets PaymentAndAging Options
        /// </summary>
        public OptionsPaymentAndAging OptionsPaymentAndAging { get; set; }
        #endregion

        #region"Company-Options extended properties for UI"
      
        /// <summary>
        /// Returns is multicurrency
        /// </summary>
        public bool IsMulticurrency
        {
            get { return Multicurrency != Multicurrency.No; }
        }

        #endregion

        #region "non-persisted settings"

        /// <summary>
        /// Should AP PJC Web Integration be included.
        /// </summary>
        /// <remarks><c>true</c> if AP PJC Web Integration is enabled, PJC is
        /// active and installed. It does not matter if there is no license.
        /// </remarks>
        public bool HasPJCWebIntegration { get; set; }

        #endregion
    }
}
