// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for Selection Criteria Header
    /// </summary>
    public partial class SelectionCriteriaHeader : ModelBase
    {

        #region Private Variables 

        /// <summary>
        /// constant variable 
        /// </summary>
        private const char Z = 'Z';

        private const int LenVendorGrp = 6;
        private const int LenVendorNum = 12;
        private const int LenAccountSet = 6;
        private const int LenPaymcode = 12;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor for Selection Criteria Header
        /// </summary>
        public SelectionCriteriaHeader()
        {
            Status = Status.Active;
            DocumentstoProcess = DocumentstoProcess.Processalldocuments;
            ThruGroupCode = CommonUtil.Repeat(Z, LenVendorGrp);
            ThruVendorNumber = CommonUtil.Repeat(Z, LenVendorNum);
            ThruAccountSet = CommonUtil.Repeat(Z, LenAccountSet);
            ThruPaymentCode = CommonUtil.Repeat(Z, LenPaymcode);
            SelectionCriteriaDetails = new EnumerableResponse<SelectionCriteriaDetail>();
            SelectionCriteriaOptFields = new EnumerableResponse<SelectionCriteriaOptionalField>();
        }

        #endregion

        #region Public Properties 

        /// <summary>
        /// Gets or sets Selection Criteria 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SelectionCode", ResourceType = typeof(APCommonResx))]
        [Key]
        [ViewField(Name = Fields.SelectionCriteria, Id = Index.SelectionCriteria, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string SelectionCriteria { get; set; }

        /// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "LastMaintained", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Documents to Process 
        /// </summary>
        [Display(Name = "DocumentstoProcess", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.DocumentstoProcess, Id = Index.DocumentstoProcess, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentstoProcess DocumentstoProcess { get; set; }

        /// <summary>
        /// To get the string of DocumentstoProcess property
        /// </summary>
        public string DocumentstoProcessString
        {
            get { return EnumUtility.GetStringValue(DocumentstoProcess); }
        }

        /// <summary>
        /// Gets or sets SelectDocumentsby 
        /// </summary>
        [Display(Name = "SelectDocumentsby", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.SelectDocumentsby, Id = Index.SelectDocumentsby, FieldType = EntityFieldType.Int, Size = 2)]
        public SelectDocumentsby SelectDocumentsby { get; set; }

        /// <summary>
        /// To get the string of SelectDocumentsby property
        /// </summary>
        public string SelectDocumentsbyString
        {
            get { return EnumUtility.GetStringValue(SelectDocumentsby); }
        }

        /// <summary>
        /// Gets or sets DateDue 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "DueDate", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.DateDue, Id = Index.DateDue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateDue { get; set; }

        /// <summary>
        /// Gets or sets FromDiscountDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "FromDiscountDate", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.FromDiscountDate, Id = Index.FromDiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FromDiscountDate { get; set; }

        /// <summary>
        /// Gets or sets FromGroupCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "FromGroupCode", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.FromGroupCode, Id = Index.FromGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FromGroupCode { get; set; }

        /// <summary>
        /// Gets or sets ThruGroupCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ThruGroupCode", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.ThruGroupCode, Id = Index.ThruGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ThruGroupCode { get; set; }

        /// <summary>
        /// Gets or sets FromVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "FromVendorNumber", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.FromVendorNumber, Id = Index.FromVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string FromVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets ThruVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ThruVendorNumber", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.ThruVendorNumber, Id = Index.ThruVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ThruVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets FromAccountSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "FromAccountSet", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.FromAccountSet, Id = Index.FromAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FromAccountSet { get; set; }

        /// <summary>
        /// Gets or sets ThruAccountSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ThruAccountSet", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.ThruAccountSet, Id = Index.ThruAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ThruAccountSet { get; set; }

        /// <summary>
        /// Gets or sets ExcludeVendor 
        /// </summary>
        [Display(Name = "ExcludeVendor", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.ExcludeVendor, Id = Index.ExcludeVendor, FieldType = EntityFieldType.Int, Size = 2)]
        public ExcludeVendor ExcludeVendor { get; set; }

        /// <summary>
        /// To get the string of ExcludeVendor property
        /// </summary>
        public string ExcludeVendorString
        {
            get { return EnumUtility.GetStringValue(ExcludeVendor); }
        }

        /// <summary>
        /// Gets or sets VendorCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "VendorCurrencyCode", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.VendorCurrencyCode, Id = Index.VendorCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string VendorCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets PaymentBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PaymentBankCode", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.PaymentBankCode, Id = Index.PaymentBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string PaymentBankCode { get; set; }

        /// <summary>
        /// Gets or sets BankCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BankCurrencyCode", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.BankCurrencyCode, Id = Index.BankCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BankCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets MinimumPaymentAmount 
        /// </summary>
        [Display(Name = "MinimumPaymentAmount", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.MinimumPaymentAmount, Id = Index.MinimumPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MinimumPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets MaximumPaymentAmount 
        /// </summary>
        [Display(Name = "MaximumPaymentAmount", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.MaximumPaymentAmount, Id = Index.MaximumPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaximumPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets BankMatch 
        /// </summary>
        [Display(Name = "BankMatch", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.BankMatch, Id = Index.BankMatch, FieldType = EntityFieldType.Int, Size = 2)]
        public BankMatch BankMatch { get; set; }

        /// <summary>
        /// To get the string of BankMatch property
        /// </summary>
        public string BankMatchString
        {
            get { return EnumUtility.GetStringValue(BankMatch); }
        }

        /// <summary>
        /// Discountable Property Switch for UI
        /// </summary>
        public bool BankMatchVal
        {
            get { return BankMatch != BankMatch.Vendorswithanybankcode; }
            set { BankMatch = value ? BankMatch.Vendorswithpaymentbankcodeonly : BankMatch.Vendorswithanybankcode; }
        }

        /// <summary>
        /// Gets or sets PaymentDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "PaymentDate", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.PaymentDate, Id = Index.PaymentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PaymentDate { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "InactiveDate", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets VendorRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "VendorRateType", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.VendorRateType, Id = Index.VendorRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string VendorRateType { get; set; }

        /// <summary>
        /// Gets or sets BankRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BankRateType", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.BankRateType, Id = Index.BankRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BankRateType { get; set; }

        /// <summary>
        /// Gets or sets VendorExchangeRate 
        /// </summary>
        [Display(Name = "VendorExchangeRate", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.VendorExchangeRate, Id = Index.VendorExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal VendorExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets BankExchangeRate 
        /// </summary>
        [Display(Name = "BankExchangeRate", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.BankExchangeRate, Id = Index.BankExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BankExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets VendorRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "VendorRateDate", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.VendorRateDate, Id = Index.VendorRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime VendorRateDate { get; set; }

        /// <summary>
        /// Gets or sets BankRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "BankRateDate", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.BankRateDate, Id = Index.BankRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BankRateDate { get; set; }

        /// <summary>
        /// Gets or sets CSVFilename 
        /// </summary>
        [StringLength(100, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CsvFilename", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.CsvFilename, Id = Index.CsvFilename, FieldType = EntityFieldType.Char, Size = 100)]
        public string CsvFilename { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ThruDiscountDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "ThruDiscountDate", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.ThruDiscountDate, Id = Index.ThruDiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ThruDiscountDate { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "BatchDate", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BatchDate { get; set; }

        /// <summary>
        /// Gets or sets VendorRateOperator 
        /// </summary>
        [Display(Name = "VendorRateOperator", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.VendorRateOperator, Id = Index.VendorRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int VendorRateOperator { get; set; }

        /// <summary>
        /// Gets or sets BankRateOperator 
        /// </summary>
        [Display(Name = "BankRateOperator", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.BankRateOperator, Id = Index.BankRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int BankRateOperator { get; set; }

        /// <summary>
        /// Gets or sets VendorRateOverridden 
        /// </summary>
        [Display(Name = "VendorRateOverridden", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.VendorRateOverridden, Id = Index.VendorRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public int VendorRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets BankRateOverridden 
        /// </summary>
        [Display(Name = "BankRateOverridden", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.BankRateOverridden, Id = Index.BankRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public int BankRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets JobApplyMethod 
        /// </summary>
        [Display(Name = "JobApplyMethod", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.JobApplyMethod, Id = Index.JobApplyMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public JobApplyMethod JobApplyMethod { get; set; }


        /// <summary>
        /// To get the string of JobApplyMethod property
        /// </summary>
        public string JobApplyMethodString
        {
            get { return EnumUtility.GetStringValue(JobApplyMethod); }
        }

        /// <summary>
        /// Gets or sets GeneratedSelectionCriteria 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "GeneratedSelectionCriteria", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.GeneratedSelectionCriteria, Id = Index.GeneratedSelectionCriteria, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GeneratedSelectionCriteria { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCodeSelect ProcessCommandCode { get; set; }

        /// <summary>
        /// To get the string of ProcessCommandCode property
        /// </summary>
        public string ProcessCommandCodeString
        {
            get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        /// <summary>
        /// Gets or sets FromPaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "FromPaymentCode", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.FromPaymentCode, Id = Index.FromPaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string FromPaymentCode { get; set; }

        /// <summary>
        /// Gets or sets ThruPaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ThruPaymentCode", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.ThruPaymentCode, Id = Index.ThruPaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string ThruPaymentCode { get; set; }

        /// <summary>
        /// Gets or sets OptionalField 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Type Type { get; set; }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets or sets Length 
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals 
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof (APCommonResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets FromOptionalFieldValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "FromOptionalFieldValue", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.FromOptionalFieldValue, Id = Index.FromOptionalFieldValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string FromOptionalFieldValue { get; set; }

        /// <summary>
        /// Gets or sets ThruOptionalFieldValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ThruOptionalFieldValue", ResourceType = typeof (PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.ThruOptionalFieldValue, Id = Index.ThruOptionalFieldValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string ThruOptionalFieldValue { get; set; }

        /// <summary>
        /// Gets or Sets Select3 
        /// </summary>
        public OptionalFieldDescription Select3 { get; set; }

        /// <summary>
        /// Gets or sets List of AP Selection Criteria Details
        /// </summary>
        /// <value>The Selection Criteria Details</value>
        /// [IgnoreExportImport]
        public EnumerableResponse<SelectionCriteriaDetail> SelectionCriteriaDetails { get; set; }

        /// <summary>
        /// Gets or sets PaymentAdjustmentOptionalField
        /// </summary>
        ///[IgnoreExportImport]
        public EnumerableResponse<SelectionCriteriaOptionalField> SelectionCriteriaOptFields { get; set; }

        /// <summary>
        /// Gets or sets Is New Record
        /// </summary>
        public bool IsNewRecord { get; set; }


        /// <summary>
        /// Optional field Tab loaded flag
        /// </summary>
        public bool IsOptinalFieldLoaded { get; set; }


        /// <summary>
        /// Gets or sets pay from bank Description 
        /// </summary>
        public string PayFromBankDesc { get; set; }


        /// <summary>
        /// Gets or sets Last Updated Rate Type
        /// </summary>
        public LastUpdatedRateType LastUpdatedRateType { get; set; }

        #endregion
    }
}
