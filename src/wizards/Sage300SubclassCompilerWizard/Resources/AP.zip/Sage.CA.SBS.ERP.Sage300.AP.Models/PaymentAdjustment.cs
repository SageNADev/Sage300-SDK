/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.Runtime.Serialization;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class PaymentAdjustment : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public PaymentAdjustment()
        {
            PaymentTransType = PaymentTransType.Payment;
            PaymentLanguage = PaymentLanguage.ENG;
            MiscellaneousPayments = new EnumerableResponse<MiscellaneousPayment>();
            AppliedPayments = new EnumerableResponse<AppliedPayment>();
            AppliedPaymentsDetail = new AppliedPayment();
            PaymentAdjustmentOptionalFields = new EnumerableResponse<PaymentAdjustmentOptionalField>();
            AdvanceCredits = new EnumerableResponse<AdvanceCredit>();
            Documents = new EnumerableResponse<CreateOpenDocumentList>();
            DocumentPayments = new EnumerableResponse<DocumentPayment>();
            AdjustmentGLDistributions = new EnumerableResponse<AdjustmentGLDistribution>();

        }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchType", ResourceType = typeof(PaymentEntryResx))]
        [Key]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(PaymentEntryResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "EntryNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber 
        /// </summary>
        [StringLength(18, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Char, Size = 18, Mask = "%-18D")]
        public string CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentDateOrAdjustmentDate 
        /// </summary>        
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentDate", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentDateOrAdjustmentDate, Id = Index.PaymentDateOrAdjustmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PaymentDateOrAdjustmentDate { get; set; }

        /// <summary>
        /// Gets or sets EntryDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryDescription", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.EntryDescription, Id = Index.EntryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string EntryDescription { get; set; }

        /// <summary>
        /// Gets or sets VendorOrPayeeName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorOrPayeeName", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorOrPayeeName, Id = Index.VendorOrPayeeName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorOrPayeeName { get; set; }

        /// <summary>
        /// Gets or sets CheckAmountinBankCurr 
        /// </summary>
        [Display(Name = "CheckAmountinBankCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CheckAmountinBankCurr, Id = Index.CheckAmountinBankCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CheckAmountinBankCurr { get; set; }

        /// <summary>
        /// Gets or sets CheckAmountinVendorCurr 
        /// </summary>
        [Display(Name = "CheckAmountinVendorCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CheckAmountinVendorCurr, Id = Index.CheckAmountinVendorCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CheckAmountinVendorCurr { get; set; }

        /// <summary>
        /// Gets or sets VendorExchangeRate 
        /// </summary>
        [Display(Name = "VendorExchangeRate", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorExchangeRate, Id = Index.VendorExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal VendorExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets VendorRateOverridden 
        /// </summary>
        [Display(Name = "VendorRateOverridden", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRateOverridden, Id = Index.VendorRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited VendorRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets NumberofPaymentsEntered 
        /// </summary>
        [Display(Name = "NumberofPaymentsEntered", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.NumberofPaymentsEntered, Id = Index.NumberofPaymentsEntered, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofPaymentsEntered { get; set; }

        /// <summary>
        /// Gets or sets TotalPrepayVendorCurr 
        /// </summary>
        [Display(Name = "TotalPrepayVendorCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TotalPrepayVendorCurr, Id = Index.TotalPrepayVendorCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalPrepayVendorCurr { get; set; }

        /// <summary>
        /// Gets or sets TotalDiscountVendorCurr 
        /// </summary>
        [Display(Name = "TotalDiscountVendorCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TotalDiscountVendorCurr, Id = Index.TotalDiscountVendorCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDiscountVendorCurr { get; set; }

        /// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorCurrencyCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorCurrencyCode, Id = Index.VendorCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string VendorCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets BankRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankRateType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BankRateType, Id = Index.BankRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BankRateType { get; set; }

        /// <summary>
        /// Gets or sets BankExchangeRate 
        /// </summary>
        [Display(Name = "BankExchangeRate", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BankExchangeRate, Id = Index.BankExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BankExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets BankRateOverridden 
        /// </summary>
        [Display(Name = "BankRateOverridden", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BankRateOverridden, Id = Index.BankRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited BankRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets PaymentTransType 
        /// </summary>
        [Display(Name = "PaymentTransType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentTransType, Id = Index.PaymentTransType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentTransType PaymentTransType { get; set; }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentBatchDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets LastLineNumber 
        /// </summary>
        [Display(Name = "LastLineNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.LastLineNumber, Id = Index.LastLineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LastLineNumber { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets VendorRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorRateDate", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRateDate, Id = Index.VendorRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime VendorRateDate { get; set; }

        /// <summary>
        /// Gets or sets VendorRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorRateType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRateType, Id = Index.VendorRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string VendorRateType { get; set; }

        /// <summary>
        /// Gets or sets TotalPaymentAdjVendorCurr 
        /// </summary>
        [Display(Name = "TotalPaymentAdjVendorCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TotalPaymentAdjVendorCurr, Id = Index.TotalPaymentAdjVendorCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalPaymentAdjVendorCurr { get; set; }

        /// <summary>
        /// Gets or sets BankRateDate 
        /// </summary>
        //[ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankRateDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BankRateDate, Id = Index.BankRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BankRateDate { get; set; }

        /// <summary>
        /// Gets or sets TotalReapplyRemainingVendorC 
        /// </summary>
        [Display(Name = "TotalReapplyRemainingVendorC", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TotalReapplyRemainingVendorC, Id = Index.TotalReapplyRemainingVendorC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalReapplyRemainingVendorC { get; set; }

        /// <summary>
        /// Gets or sets AdjDebitAmtFuncCurr 
        /// </summary>
        [Display(Name = "AdjDebitAmtFuncCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AdjDebitAmtFuncCurr, Id = Index.AdjDebitAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjDebitAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets CheckAmountFuncCurr 
        /// </summary>
        [Display(Name = "CheckAmountFuncCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CheckAmountFuncCurr, Id = Index.CheckAmountFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CheckAmountFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentEdited 
        /// </summary>
        [Display(Name = "PaymentEdited", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentEdited, Id = Index.PaymentEdited, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentEdited PaymentEdited { get; set; }

        /// <summary>
        /// Gets or sets CheckPrintRequired 
        /// </summary>
        [Display(Name = "CheckPrintRequired", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CheckPrintRequired, Id = Index.CheckPrintRequired, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited CheckPrintRequired { get; set; }

        /// <summary>
        /// Gets or sets VendorRemitToLocation 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorRemitToLocation", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRemitToLocation, Id = Index.VendorRemitToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string VendorRemitToLocation { get; set; }

        /// <summary>
        /// Gets or sets EntryReference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryReference", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.EntryReference, Id = Index.EntryReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string EntryReference { get; set; }

        /// <summary>
        /// Gets or sets AdjCreditAmtFuncCurr 
        /// </summary>
        [Display(Name = "AdjCreditAmtFuncCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AdjCreditAmtFuncCurr, Id = Index.AdjCreditAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjCreditAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets TotalAdjAmtFuncCurr 
        /// </summary>
        [Display(Name = "TotalAdjAmtFuncCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TotalAdjAmtFuncCurr, Id = Index.TotalAdjAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdjAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets CheckSequenceNo 
        /// </summary>
        [Display(Name = "CheckSequenceNo", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CheckSequenceNo, Id = Index.CheckSequenceNo, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long CheckSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets CheckPrintedStatus 
        /// </summary>
        [Display(Name = "CheckPrintedStatus", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CheckPrintedStatus, Id = Index.CheckPrintedStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentRegisterPrintstatus CheckPrintedStatus { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "State", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.State, Id = Index.State, FieldType = EntityFieldType.Char, Size = 30)]
        public string State { get; set; }

        /// <summary>
        /// Gets or sets ZipOrPostalCode 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZIPPostalCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ZipOrPostalCode, Id = Index.ZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets PaymentLanguage 
        /// </summary>
        [Display(Name = "PaymentLanguage", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentLanguage, Id = Index.PaymentLanguage, FieldType = EntityFieldType.Char, Size = 3)]
        public PaymentLanguage PaymentLanguage { get; set; }

        /// <summary>
        /// Gets or sets BankRateOperator 
        /// </summary>
        [Display(Name = "BankRateOperator", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BankRateOperator, Id = Index.BankRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public BankRateOperator BankRateOperator { get; set; }

        /// <summary>
        /// Gets or sets VendorRateOperator 
        /// </summary>
        [Display(Name = "VendorRateOperator", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRateOperator, Id = Index.VendorRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public BankRateOperator VendorRateOperator { get; set; }

        /// <summary>
        /// Gets or sets AdjDebitAmtVendorCurr 
        /// </summary>
        [Display(Name = "AdjDebitAmtVendorCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AdjDebitAmtVendorCurr, Id = Index.AdjDebitAmtVendorCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjDebitAmtVendorCurr { get; set; }

        /// <summary>
        /// Gets or sets AdjCreditAmtVendorCurr 
        /// </summary>
        [Display(Name = "AdjCreditAmtVendorCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AdjCreditAmtVendorCurr, Id = Index.AdjCreditAmtVendorCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjCreditAmtVendorCurr { get; set; }

        /// <summary>
        /// Gets or sets PrepayActivationDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PrepayActivationDate", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PrepayActivationDate, Id = Index.PrepayActivationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PrepayActivationDate { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited JobRelated { get; set; }

        /// <summary>
        /// Gets or sets JobApplyMethod 
        /// </summary>
        [Display(Name = "JobApplyMethod", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.JobApplyMethod, Id = Index.JobApplyMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public JobApplyMethod JobApplyMethod { get; set; }

        /// <summary>
        /// Gets or sets ErrorBatch 
        /// </summary>
        [Display(Name = "ErrorBatch", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ErrorBatch, Id = Index.ErrorBatch, FieldType = EntityFieldType.Long, Size = 4)]
        public long ErrorBatch { get; set; }

        /// <summary>
        /// Gets or sets ErrorEntry 
        /// </summary>
        [Display(Name = "ErrorEntry", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ErrorEntry, Id = Index.ErrorEntry, FieldType = EntityFieldType.Long, Size = 4)]
        public long ErrorEntry { get; set; }

        /// <summary>
        /// Gets or sets MatchingDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MatchingDocumentNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.MatchingDocumentNumber, Id = Index.MatchingDocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string MatchingDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [Display(Name = "OptionalField", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentAdjProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets BankCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCurrencyCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BankCurrencyCode, Id = Index.BankCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BankCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets PaymentType 
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets CashAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CashAccount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CashAccount, Id = Index.CashAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CashAccount { get; set; }

        [IgnoreExportImport]
        public string CashAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets DrillDownApplicationSource 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DrillDownApplicationSource", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DrillDownApplicationSource, Id = Index.DrillDownApplicationSource, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string DrillDownApplicationSource { get; set; }

        /// <summary>
        /// Gets or sets DrillDownType 
        /// </summary>
        [Display(Name = "DrillDownType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DrillDownType, Id = Index.DrillDownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrillDownType { get; set; }

        /// <summary>
        /// Gets or sets DrillDownLinkNumber 
        /// </summary>
        [Display(Name = "DrillDownLinkNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DrillDownLinkNumber, Id = Index.DrillDownLinkNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrillDownLinkNumber { get; set; }

        /// <summary>
        /// Gets or sets Num1099OrCPRSCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "_1099Code", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Num1099OrCPRSCode, Id = Index.Num1099OrCPRSCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Num1099OrCPRSCode { get; set; }

        /// <summary>
        /// Gets or sets Num1099OrCPRSAmount 
        /// </summary>
        [Display(Name = "_1099Amount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Num1099OrCPRSAmount, Id = Index.Num1099OrCPRSAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Num1099OrCPRSAmount { get; set; }

        /// <summary>
        /// Gets or sets CalculateTaxAmountControl 
        /// </summary>
        [Display(Name = "CalculateTaxAmountControl", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CalculateTaxAmountControl, Id = Index.CalculateTaxAmountControl, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateTaxAmountControl CalculateTaxAmountControl { get; set; }

        /// <summary>
        /// Gets or sets CalculateTaxBaseControl 
        /// </summary>
        [Display(Name = "CalculateTaxBaseControl", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CalculateTaxBaseControl, Id = Index.CalculateTaxBaseControl, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateTaxAmountControl CalculateTaxBaseControl { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxStateVersion 
        /// </summary>
        [Display(Name = "TaxStateVersion", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxStateVersion, Id = Index.TaxStateVersion, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxStateVersion { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1 
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2 
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3 
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4 
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5 
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1 
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2 
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3 
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4 
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5 
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1 
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2 
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3 
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4 
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5 
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal 
        /// </summary>
        [Display(Name = "TotalTax", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets DistAmountNetofTaxes 
        /// </summary>
        [Display(Name = "DistAmountNetofTaxes", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DistAmountNetofTaxes, Id = Index.DistAmountNetofTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistAmountNetofTaxes { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedTotal 
        /// </summary>
        [Display(Name = "TaxAllocatedTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedTotal, Id = Index.TaxAllocatedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxExpensedTotal 
        /// </summary>
        [Display(Name = "TaxExpensedTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxExpensedTotal, Id = Index.TaxExpensedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpensedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableTotal 
        /// </summary>
        [Display(Name = "TaxRecoverableTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableTotal, Id = Index.TaxRecoverableTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrencyCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCalculateMethod 
        /// </summary>
        [Display(Name = "TaxReportingCalculateMethod", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingCalculateMethod, Id = Index.TaxReportingCalculateMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateTaxAmountControl TaxReportingCalculateMethod { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchangeRate 
        /// </summary>
        [Display(Name = "TaxReportingExchangeRate", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingExchangeRate, Id = Index.TaxReportingExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateDate", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperator 
        /// </summary>
        [Display(Name = "TaxReportingRateOperator", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOperator, Id = Index.TaxReportingRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public BankRateOperator TaxReportingRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOverride 
        /// </summary>
        [Display(Name = "TaxReportingRateOverride", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOverride, Id = Index.TaxReportingRateOverride, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited TaxReportingRateOverride { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1 
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2 
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3 
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4 
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5 
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotal 
        /// </summary>
        [Display(Name = "TaxReportingTotal", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TaxReportingTotal, Id = Index.TaxReportingTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedTotal 
        /// </summary>
        [Display(Name = "TaxReportingAllocatedTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedTotal, Id = Index.TaxReportingAllocatedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedTotal 
        /// </summary>
        [Display(Name = "TaxReportingExpensedTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedTotal, Id = Index.TaxReportingExpensedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableTotal 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableTotal, Id = Index.TaxReportingRecoverableTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableTotal { get; set; }

        /// <summary>
        /// Gets or sets TotalPrepayFuncCurr 
        /// </summary>
        [Display(Name = "TotalPrepayFuncCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TotalPrepayFuncCurr, Id = Index.TotalPrepayFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalPrepayFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets TotalDiscountFuncCurr 
        /// </summary>
        [Display(Name = "TotalDiscountFuncCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TotalDiscountFuncCurr, Id = Index.TotalDiscountFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDiscountFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets TotalReapplyRemainingFuncCu 
        /// </summary>
        [Display(Name = "TotalReapplyRemainingFuncCu", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TotalReapplyRemainingFuncCu, Id = Index.TotalReapplyRemainingFuncCu, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalReapplyRemainingFuncCu { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase1 
        /// </summary>
        [Display(Name = "FuncTaxBase1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase1, Id = Index.FuncTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase2 
        /// </summary>
        [Display(Name = "FuncTaxBase2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase2, Id = Index.FuncTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase3 
        /// </summary>
        [Display(Name = "FuncTaxBase3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase3, Id = Index.FuncTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase4 
        /// </summary>
        [Display(Name = "FuncTaxBase4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase4, Id = Index.FuncTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase5 
        /// </summary>
        [Display(Name = "FuncTaxBase5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase5, Id = Index.FuncTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount1 
        /// </summary>
        [Display(Name = "FuncTaxAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount1, Id = Index.FuncTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount2 
        /// </summary>
        [Display(Name = "FuncTaxAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount2, Id = Index.FuncTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount3 
        /// </summary>
        [Display(Name = "FuncTaxAmount3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount3, Id = Index.FuncTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount4 
        /// </summary>
        [Display(Name = "FuncTaxAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount4, Id = Index.FuncTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount5 
        /// </summary>
        [Display(Name = "FuncTaxAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount5, Id = Index.FuncTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxTotal 
        /// </summary>
        [Display(Name = "FuncTaxTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxTotal, Id = Index.FuncTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncDistAmountNetofTaxes 
        /// </summary>
        [Display(Name = "FuncDistAmountNetofTaxes", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncDistAmountNetofTaxes, Id = Index.FuncDistAmountNetofTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDistAmountNetofTaxes { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedTotal 
        /// </summary>
        [Display(Name = "FuncTaxAllocatedTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedTotal, Id = Index.FuncTaxAllocatedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpensedTotal 
        /// </summary>
        [Display(Name = "FuncTaxExpensedTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpensedTotal, Id = Index.FuncTaxExpensedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpensedTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableTotal 
        /// </summary>
        [Display(Name = "FuncTaxRecoverableTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableTotal, Id = Index.FuncTaxRecoverableTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableTotal { get; set; }

        /// <summary>
        /// Gets or sets AOrPVersionCreatedIn 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "APVersionCreatedIn", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AOrPVersionCreatedIn, Id = Index.AOrPVersionCreatedIn, FieldType = EntityFieldType.Char, Size = 3)]
        public string AOrPVersionCreatedIn { get; set; }

        /// <summary>
        /// Gets or sets NumberofAdvanceCreditClaims 
        /// </summary>
        [Display(Name = "NumberofAdvanceCreditClaims", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.NumberofAdvanceCreditClaims, Id = Index.NumberofAdvanceCreditClaims, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofAdvanceCreditClaims { get; set; }

        /// <summary>
        /// Gets or sets TotalAdvanceCreditClaim 
        /// </summary>
        [Display(Name = "TotalAdvanceCreditClaim", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TotalAdvanceCreditClaim, Id = Index.TotalAdvanceCreditClaim, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdvanceCreditClaim { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalAdvanceCreditClaim 
        /// </summary>
        [Display(Name = "FuncTotalAdvanceCreditClaim", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncTotalAdvanceCreditClaim, Id = Index.FuncTotalAdvanceCreditClaim, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalAdvanceCreditClaim { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate 
        /// </summary>        
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PostingDate { get; set; }

        /// <summary>
        /// Gets or sets AccountSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHT1TC, Id = Index.AmtWHT1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHT2TC, Id = Index.AmtWHT2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHT3TC, Id = Index.AmtWHT3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHT4TC, Id = Index.AmtWHT4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHT5TC, Id = Index.AmtWHT5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Base 1
        /// </summary>
        [ViewField(Name = Fields.AmtCXBS1TC, Id = Index.AmtCXBS1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXBS1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Base 2
        /// </summary>
        [ViewField(Name = Fields.AmtCXBS2TC, Id = Index.AmtCXBS2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXBS2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Base 3
        /// </summary>
        [ViewField(Name = Fields.AmtCXBS3TC, Id = Index.AmtCXBS3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXBS3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Base 4
        /// </summary>
        [ViewField(Name = Fields.AmtCXBS4TC, Id = Index.AmtCXBS4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXBS4TC { get; set; } = 0;
        /// <summary>
        /// Gets or sets Reverse Charges Base 5
        /// </summary>
        [ViewField(Name = Fields.AmtCXBS5TC, Id = Index.AmtCXBS5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXBS5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtCXTX1TC, Id = Index.AmtCXTX1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXTX1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtCXTX2TC, Id = Index.AmtCXTX2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXTX2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtCXTX3TC, Id = Index.AmtCXTX3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXTX3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtCXTX4TC, Id = Index.AmtCXTX4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXTX4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Reverse Charges Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtCXTX5TC, Id = Index.AmtCXTX5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtCXTX5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Misc Payment Document Total
        /// </summary>
        [ViewField(Name = Fields.AmtTGROSDST, Id = Index.AmtTGROSDST, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtTGROSDST { get; set; } = 0;


        /// <summary>
        /// Gets or sets MiscellaneousPayments
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<MiscellaneousPayment> MiscellaneousPayments { get; set; }

        /// <summary>
        /// Gets or sets AppliedPayments
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<AppliedPayment> AppliedPayments { get; set; }

        ///// <summary>
        ///// Gets or sets AppliedPayments
        ///// </summary>
        //[IgnoreExportImport]
        //public AppliedPayment AppliedPayment { get; set; }


        /// <summary>
        /// Gets or sets PaymentAdjustmentOptionalField
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<PaymentAdjustmentOptionalField> PaymentAdjustmentOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets AdvanceCredit
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<AdvanceCredit> AdvanceCredits { get; set; }

        /// <summary>
        /// Gets or sets CreateOpenDocumentList
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CreateOpenDocumentList> Documents { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentGLDistributionList
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<AdjustmentGLDistribution> AdjustmentGLDistributions { get; set; }

        /// <summary>
        /// Gets or sets DocumentPayment
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<DocumentPayment> DocumentPayments { get; set; }

        /// <summary>
        /// Applied Adjustment Detail
        /// </summary>
        [IgnoreExportImport]
        public AppliedPayment AppliedPaymentsDetail { get; set; }

        /// <summary>
        /// checks if batch date is valid
        /// </summary>
        public bool BatchDateValid { get; set; }

        #region Enum String Value
        /// <summary>
        /// To get the string of PaymentTransType property
        /// </summary>
        [IgnoreExportImport]
        public string PaymentTransTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(PaymentTransType);
            }
        }

        /// <summary>
        /// To get the string of DocumentType property
        /// </summary>
        [IgnoreExportImport]
        public string DocumentTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(DocumentType);
            }
        }

        /// <summary>
        /// To get the string of PaymentEdited property
        /// </summary>
        [IgnoreExportImport]
        public string PaymentEditedString
        {
            get
            {
                return EnumUtility.GetStringValue(PaymentEdited);
            }
        }

        /// <summary>
        /// To get the string of CheckPrintRequired property
        /// </summary>
        [IgnoreExportImport]
        public string CheckPrintRequiredString
        {
            get
            {
                return EnumUtility.GetStringValue(CheckPrintRequired);
            }
        }

        /// <summary>
        /// To get the string of CheckPrintedStatus property
        /// </summary>
        [IgnoreExportImport]
        public string CheckPrintedStatusString
        {
            get
            {
                return EnumUtility.GetStringValue(CheckPrintedStatus);
            }
        }

        /// <summary>
        /// To get the string of PaymentLanguage property
        /// </summary>
        [IgnoreExportImport]
        public string PaymentLanguageString
        {
            get
            {
                return EnumUtility.GetStringValue(PaymentLanguage);
            }
        }

        /// <summary>
        /// To get the string of BankRateOperator property
        /// </summary>
        [IgnoreExportImport]
        public string BankRateOperatorString
        {
            get
            {
                return EnumUtility.GetStringValue(BankRateOperator);
            }
        }

        /// <summary>
        /// To get the string of VendorRateOperator property
        /// </summary>
        [IgnoreExportImport]
        public string VendorRateOperatorString
        {
            get
            {
                return EnumUtility.GetStringValue(VendorRateOperator);
            }
        }

        /// <summary>
        /// To get the string of JobApplyMethod property
        /// </summary>
        [IgnoreExportImport]
        public string JobApplyMethodString
        {
            get
            {
                return EnumUtility.GetStringValue(JobApplyMethod);
            }
        }

        /// <summary>
        /// To get the string of JobRelated property
        /// </summary>
        [IgnoreExportImport]
        public string JobRelatedString
        {
            get
            {
                return EnumUtility.GetStringValue(JobRelated);
            }
        }

        /// <summary>
        /// To get the string of ProcessCommandCode property
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandCodeString
        {

            get
            {
                return EnumUtility.GetStringValue(ProcessCommandCode);
            }
        }

        /// <summary>
        /// To get the string of PaymentType property
        /// </summary>
        [IgnoreExportImport]
        public string PaymentTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(PaymentType);
            }
        }

        /// <summary>
        /// To get the string of CalculateTaxAmountControl property
        /// </summary>
        [IgnoreExportImport]
        public string CalculateTaxAmountControlString
        {
            get
            {
                return EnumUtility.GetStringValue(CalculateTaxAmountControl);
            }
        }

        /// <summary>
        /// To get the string of CalculateTaxBaseControl property
        /// </summary>
        [IgnoreExportImport]
        public string CalculateTaxBaseControlString
        {
            get
            {
                return EnumUtility.GetStringValue(CalculateTaxBaseControl);
            }
        }

        /// <summary>
        /// To get the string of TaxIncluded1 property
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncluded1String
        {
            get
            {
                return EnumUtility.GetStringValue(TaxIncluded1);
            }
        }

        /// <summary>
        /// To get the string of TaxIncluded2 property
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncluded2String
        {
            get
            {
                return EnumUtility.GetStringValue(TaxIncluded2);
            }
        }
        /// <summary>
        /// To get the string of TaxIncluded3 property
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncluded3String
        {
            get
            {
                return EnumUtility.GetStringValue(TaxIncluded3);
            }
        }
        /// <summary>
        /// To get the string of TaxIncluded4 property
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncluded4String
        {
            get
            {
                return EnumUtility.GetStringValue(TaxIncluded4);
            }
        }
        /// <summary>
        /// To get the string of TaxIncluded5 property
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncluded5String
        {
            get
            {
                return EnumUtility.GetStringValue(TaxIncluded5);
            }
        }
        /// <summary>
        /// To get the string of TaxReportingCalculateMethod property
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingCalculateMethodString
        {
            get
            {
                return EnumUtility.GetStringValue(TaxReportingCalculateMethod);
            }
        }

        /// <summary>
        /// To get the string of TaxReportingRateOperator property
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingRateOperatorString
        {
            get
            {
                return EnumUtility.GetStringValue(TaxReportingRateOperator);
            }
        }

        /// <summary>
        /// To get the string of TaxReportingRateOverride property
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingRateOverrideString
        {
            get
            {
                return EnumUtility.GetStringValue(TaxReportingRateOverride);
            }
        }

        /// <summary>
        /// To get the string of BankRateOverridden property
        /// </summary>
        [IgnoreExportImport]
        public string BankRateOverriddenString
        {
            get
            {
                return EnumUtility.GetStringValue(BankRateOverridden);
            }
        }

        /// <summary>
        /// To get the string of VendorRateOverridden property
        /// </summary>
        [IgnoreExportImport]
        public string VendorRateOverriddenString
        {
            get
            {
                return EnumUtility.GetStringValue(VendorRateOverridden);
            }
        }
        #endregion

        /// <summary>
        /// To get the onhold property
        /// </summary>
        [IgnoreExportImport]
        public bool OnHold { get; set; }
    }
}
