// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class Integrity Checker
    /// </summary>
    public partial class IntegrityChecker : ModelBase
    {
        /// <summary>
        /// Gets or sets RecordID 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.RecordID, Id = Index.RecordID, FieldType = EntityFieldType.Int, Size = 2)]
        public int RecordID { get; set; }

        /// <summary>
        /// Gets or sets CheckOrphans 
        /// </summary>
        [Display(Name = "CheckforOrphanRecords", ResourceType = typeof(IntegrityCheckerResx))]
        [ViewField(Name = Fields.CheckOrphans, Id = Index.CheckOrphans, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckOrphans { get; set; }

        /// <summary>
        /// Gets or sets FixOrphans 
        /// </summary>
        [Display(Name = "DeleteOrphanRecords", ResourceType = typeof(IntegrityCheckerResx))]
        [ViewField(Name = Fields.FixOrphans, Id = Index.FixOrphans, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FixOrphans { get; set; }

        /// <summary>
        /// Gets or sets CheckSetupTables 
        /// </summary>
        [Display(Name = "SetupTables", ResourceType = typeof(IntegrityCheckerResx))]
        [ViewField(Name = Fields.CheckSetupTables, Id = Index.CheckSetupTables, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckSetupTables { get; set; }

        /// <summary>
        /// Gets or sets FixSetupTables 
        /// </summary>
        [ViewField(Name = Fields.FixSetupTables, Id = Index.FixSetupTables, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FixSetupTables { get; set; }

        /// <summary>
        /// Gets or sets CheckOpenBatches 
        /// </summary>
        [Display(Name = "OpenandReadytoPostBatches", ResourceType = typeof(IntegrityCheckerResx))]
        [ViewField(Name = Fields.CheckOpenBatches, Id = Index.CheckOpenBatches, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckOpenBatches { get; set; }

        /// <summary>
        /// Gets or sets FixOpenBatches 
        /// </summary>
        [ViewField(Name = Fields.FixOpenBatches, Id = Index.FixOpenBatches, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FixOpenBatches { get; set; }

        /// <summary>
        /// Gets or sets CheckVendorDocuments 
        /// </summary>
        [Display(Name = "VendorDocuments", ResourceType = typeof(IntegrityCheckerResx))]
        [ViewField(Name = Fields.CheckVendorDocuments, Id = Index.CheckVendorDocuments, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckVendorDocuments { get; set; }

        /// <summary>
        /// Gets or sets FixVendorDocuments 
        /// </summary>
        [ViewField(Name = Fields.FixVendorDocuments, Id = Index.FixVendorDocuments, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FixVendorDocuments { get; set; }

        /// <summary>
        /// Gets or sets FromVendor 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromVendor, Id = Index.FromVendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string FromVendor { get; set; }

        /// <summary>
        /// Gets or sets ToVendor 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToVendor, Id = Index.ToVendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ToVendor { get; set; }

        /// <summary>
        /// Gets or sets CheckPostingJournal 
        /// </summary>
        [Display(Name = "PostingJournals", ResourceType = typeof(IntegrityCheckerResx))]
        [ViewField(Name = Fields.CheckPostingJournal, Id = Index.CheckPostingJournal, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckPostingJournal { get; set; }

        /// <summary>
        /// Gets or sets FixPostingJournal 
        /// </summary>
        [ViewField(Name = Fields.FixPostingJournal, Id = Index.FixPostingJournal, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FixPostingJournal { get; set; }
    }
}
