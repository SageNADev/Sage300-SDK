/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for Account Payable Options Invoicing
    /// </summary>
    public partial class OptionsInvoicing : ModelBase
    {

        /// <summary>
        /// Gets or sets OptionsRecordKey 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.OptionsRecordKey, Id = Index.OptionsRecordKey, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string OptionsRecordKey { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets NextInvoiceBatchNumber 
        /// </summary>
        [ViewField(Name = Fields.NextInvoiceBatchNumber, Id = Index.NextInvoiceBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextInvoiceBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets Use1099OrCPRSReporting 
        /// </summary>        
        [Display(Name = "Use1099CPRSReporting", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.Use1099OrCPRSReporting, Id = Index.Use1099OrCPRSReporting, FieldType = EntityFieldType.Int, Size = 2)]
        public Use1099OrCPRSReporting Use1099OrCPRSReporting { get; set; }

        /// <summary>
        /// Gets or sets NextInvoicePostingSeqNumber 
        /// </summary>
        [ViewField(Name = Fields.NextInvoicePostingSeqNumber, Id = Index.NextInvoicePostingSeqNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextInvoicePostingSeqNumber { get; set; }
        
        /// <summary>
        /// Gets or sets Edit1099OrCPRSAmounts 
        /// </summary>
        [Display(Name = "AllowEditof1099CPRSAmounts", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.Edit1099OrCPRSAmounts, Id = Index.Edit1099OrCPRSAmounts, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType Edit1099OrCPRSAmounts { get; set; }

        /// <summary>
        /// Gets or sets Copy1099OrCPRSAmountfromTotal 
        /// </summary>
        [Display(Name = "Default1099FromDocTot", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.Copy1099OrCPRSAmountfromTotal, Id = Index.Copy1099OrCPRSAmountfromTotal, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType Copy1099OrCPRSAmountfromTotal { get; set; }

        /// <summary>
        /// Gets or sets DefaultPostingDate 
        /// </summary>
        [Display(Name = "DefaultPostingDate", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultPostingDate, Id = Index.DefaultPostingDate, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultPostingDate DefaultPostingDate { get; set; } 
    }
}
