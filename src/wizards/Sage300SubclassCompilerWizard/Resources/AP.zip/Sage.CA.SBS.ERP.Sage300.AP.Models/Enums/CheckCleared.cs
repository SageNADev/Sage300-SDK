
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for CheckCleared 
    /// </summary>
    public enum CheckCleared
    {
        /// <summary>
        /// Returns Enumerated value for All
        /// </summary>
        [EnumValue("All", typeof(CommonResx))]
        All = -1,

        /// <summary>
        /// Gets or sets Outstanding 
        /// </summary>	
        [EnumValue("Outstanding", typeof(PaymentInquiryResx))]
        Outstanding = 0,

        /// <summary>
        /// Gets or sets Cleared 
        /// </summary>	
        [EnumValue("Cleared", typeof(PaymentInquiryResx))]
        Cleared = 1,

        /// <summary>
        /// Gets or sets Reversed 
        /// </summary>	
        [EnumValue("Reversed", typeof(PaymentInquiryResx))]
        Reversed = 2
    }
}
