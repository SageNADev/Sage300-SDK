 
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for OrderBy 
    /// </summary>
	public enum OrderBy 
	{
			/// <summary>
		/// Gets or sets DocumentNumber 
		/// </summary>	
        [EnumValue("DocumentNumber", typeof(APCommonResx))]
        DocumentNumber = 1,
		/// <summary>
		/// Gets or sets PONumber 
		/// </summary>	
        [EnumValue("PONumber", typeof(APCommonResx))]
        PONumber = 2,
		/// <summary>
		/// Gets or sets DueDate 
		/// </summary>	
        [EnumValue("DueDate", typeof(APCommonResx))]
        DueDate = 3,
		/// <summary>
		/// Gets or sets OrderNumber 
		/// </summary>	
        [EnumValue("OrderNumber", typeof(APCommonResx))]
        OrderNumber = 4,
		/// <summary>
		/// Gets or sets DocumentDate 
		/// </summary>	
        [EnumValue("DocumentDate", typeof(APCommonResx))]
        DocumentDate = 5,
		/// <summary>
		/// Gets or sets CurrentBalance 
		/// </summary>	
        [EnumValue("CurrentBalance", typeof(APCommonResx))]
        CurrentBalance = 6,
		/// <summary>
		/// Gets or sets OriginalDocNo 
		/// </summary>	
        [EnumValue("OriginalDocNo", typeof(APCommonResx))]
        OriginalDocNo = 7,
	}
}
