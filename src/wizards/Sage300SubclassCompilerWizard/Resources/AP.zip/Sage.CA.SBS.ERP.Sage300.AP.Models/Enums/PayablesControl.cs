 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for PayablesControl 
    /// </summary>
	public enum PayablesControl 
	{
		/// <summary>
		/// Gets or sets NotApplicable 
		/// </summary>	
        [EnumValue("NotApplicable", typeof(EnumerationsResx))]
        NotApplicable = 99,
	}
}
