/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for Documents to Process 
    /// </summary>
	public enum DocumentstoProcess 
	{
		/// <summary>
		/// Gets or sets Process all documents 
		/// </summary>	
        [EnumValue("DocumentstoProcess_Processalldocuments", typeof(EnumerationsResx))] 
        Processalldocuments = 0,

		/// <summary>
		/// Gets or sets Process forced documents only 
		/// </summary>	
        [EnumValue("DocumentstoProcess_Processforceddocumentsonly", typeof(PaymentSelectionCodesResx))] 
        Processforceddocumentsonly = 1,
	}
}
