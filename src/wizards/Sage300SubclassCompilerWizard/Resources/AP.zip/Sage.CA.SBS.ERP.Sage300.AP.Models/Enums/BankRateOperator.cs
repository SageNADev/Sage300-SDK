
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for BankRateOperator 
    /// </summary>
	public enum BankRateOperator 
	{
        /// <summary>
		/// Gets or sets Multiply 
		/// </summary>	
        [EnumValue("Multiply", typeof(EnumerationsResx))]
        Multiply = 1,
		/// <summary>
		/// Gets or sets Divide 
		/// </summary>	
        [EnumValue("Divide", typeof(EnumerationsResx))]
        Divide = 2,
	}
}
