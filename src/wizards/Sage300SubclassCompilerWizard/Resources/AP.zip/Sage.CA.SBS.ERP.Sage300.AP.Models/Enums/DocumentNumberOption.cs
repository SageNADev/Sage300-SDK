/* Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved. */
/* Portions co-modified with Claude Code */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum DocumentNumberOption for APRIB DOCNUMOP field
    /// </summary>
    public enum DocumentNumberOption
    {
        /// <summary>
        /// Use generated document number
        /// </summary>
        GeneratedDocumentNumber = 1,

        /// <summary>
        /// Use original document number with prefix
        /// </summary>
        OriginalDocumentNumberWithPrefix = 2,

        /// <summary>
        /// Use entered document number
        /// </summary>
        EnteredDocumentNumber = 3,
    }
}
