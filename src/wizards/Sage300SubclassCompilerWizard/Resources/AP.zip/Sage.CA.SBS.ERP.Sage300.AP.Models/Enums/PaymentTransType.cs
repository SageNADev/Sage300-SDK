
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for PaymentTransType 
    /// </summary>
    public enum PaymentTransType
    {
        /// <summary>
        /// Gets or sets Payment 
        /// </summary>
        [EnumValue("Payment", typeof(APCommonResx))]
        Payment = 1,
        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>	
        [EnumValue("Prepayment", typeof(APCommonResx))]
        Prepayment = 2,
        /// <summary>
        /// Gets or sets ApplyDocument 
        /// </summary>	
        [EnumValue("ApplyDocument", typeof(APCommonResx))]
        ApplyDocument = 3,
        /// <summary>
        /// Gets or sets MiscPayment 
        /// </summary>	
        [EnumValue("MiscPayment", typeof(APCommonResx))]
        MiscPayment = 4,
        /// <summary>
        /// Gets or sets Adjustment 
        /// </summary>	
        [EnumValue("Adjustment", typeof(APCommonResx))]
        Adjustment = 5,
    }
}
