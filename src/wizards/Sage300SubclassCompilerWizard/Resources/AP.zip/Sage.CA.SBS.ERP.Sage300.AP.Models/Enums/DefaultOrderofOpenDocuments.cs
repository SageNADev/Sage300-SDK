// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Default Order of Open Documents 
    /// </summary>
    public enum DefaultOrderofOpenDocuments
    {
        /// <summary>
        /// Gets or sets Document Number 
        /// </summary>	
        [EnumValue("DocumentNumber", typeof(APCommonResx), 0)]
        DocumentNumber = 1,

        /// <summary>
        /// Gets or sets PO Number 
        /// </summary>	
        [EnumValue("PONumber", typeof(APCommonResx), 1)]
        PONumber = 2,

        /// <summary>
        /// Gets or sets Due Date 
        /// </summary>	
        [EnumValue("DueDate", typeof(APCommonResx), 2)]
        DueDate = 3,

        /// <summary>
        /// Gets or sets Order Number 
        /// </summary>	
        [EnumValue("OrderNumber", typeof(APCommonResx), 3)]
        OrderNumber = 4,

        /// <summary>
        /// Gets or sets Document Date 
        /// </summary>	
        [EnumValue("DocumentDate", typeof(APCommonResx), 4)]
        DocumentDate = 5,

        /// <summary>
        /// Gets or sets Current Balance 
        /// </summary>	
        [EnumValue("CurrentBalance", typeof(APCommonResx), 5)]
        CurrentBalance = 6,

        /// <summary>
        /// Gets or sets Original Doc. No. 
        /// </summary>	
        [EnumValue("DefaultOrderofOpenDocuments_OriginalDocNo", typeof(EnumerationsResx), 6)]
        OriginalDocNo = 7,
    }
}
