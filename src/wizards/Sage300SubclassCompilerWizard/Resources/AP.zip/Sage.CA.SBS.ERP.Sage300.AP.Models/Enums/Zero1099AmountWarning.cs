
// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Name Spaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enumeration for Duplicate Amount Code 
    /// </summary>
    public enum VendorGroupDuplicateAmountCode
    {
        /// <summary>
        /// Value for None 
        /// </summary>        
        [EnumValue("None", typeof(CommonResx))]
        None = 0,

        /// <summary>
        /// Value for Warning 
        /// </summary>	
        [EnumValue("Warning", typeof(CommonResx))]
        Warning = 1,

        /// <summary>
        /// Value for Error 
        /// </summary>	
        [EnumValue("Error", typeof(CommonResx))]
        Error = 2,
    }
}
