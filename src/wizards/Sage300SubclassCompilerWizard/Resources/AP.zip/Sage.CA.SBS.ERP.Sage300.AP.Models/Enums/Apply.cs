﻿using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Payment Entry Header Detail Apply 
    /// </summary>
    public enum Apply
    {
        /// <summary>
        /// Yes
        /// </summary>
        [EnumValue("Yes", typeof(EnumerationsResx))]
        Yes = 'Y',
        /// <summary>
        /// No
        /// </summary>
        [EnumValue("No", typeof(EnumerationsResx))]
        No = 'N',

        /// <summary>
        /// Pending
        /// </summary>
        [EnumValue("Pending", typeof(PaymentEntryResx))]
        Pending = 'X'
       }
}
