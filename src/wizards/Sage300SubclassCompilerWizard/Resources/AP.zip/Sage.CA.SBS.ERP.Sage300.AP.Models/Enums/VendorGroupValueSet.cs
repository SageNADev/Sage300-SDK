
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enumeration for Value Set 
    /// </summary>
    public enum VendorGroupValueSet 
	{
	    /// <summary>
		/// Value for No 
		/// </summary>	
        No = 0,

		/// <summary>
        /// Value for Yes 
		/// </summary>	
        Yes = 1,

		/// <summary>
        /// Value for NotApplicable 
		/// </summary>	
        NotApplicable = 99,
	}
}
