// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for DesiredStatus 
    /// </summary>
    public enum DesiredStatus
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        None = 99,
        /// <summary>
        /// Gets or sets Normal 
        /// </summary>	
        Normal = 0,
        /// <summary>
        /// Gets or sets Hold 
        /// </summary>	
        Hold = 1,
        /// <summary>
        /// Gets or sets Force 
        /// </summary>	
        Force = 2,
    }
}
