// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for RequestType 
    /// </summary>
    public enum ControlPaymentRequestType
    {
        /// <summary>
        /// Gets or sets SpecificVendor 
        /// </summary>	
        SpecificVendor = 1,

        /// <summary>
        /// Gets or sets VendorRange 
        /// </summary>	
        VendorRange = 2,
    }
}
