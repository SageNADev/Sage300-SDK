/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for Payment Batch Status 
    /// </summary>
    public enum PaymentBatchStatus 
	{
        /// <summary>
        /// Gets or sets Open 
        /// </summary>	
        [EnumValue("Open", typeof(EnumerationsResx))]
        Open = 1,

        /// <summary>
		/// Gets or sets Posted 
		/// </summary>	
        [EnumValue("Posted", typeof(APCommonResx))]
        Posted = 3,
		
        /// <summary>
		/// Gets or sets Deleted 
		/// </summary>
        [EnumValue("Deleted", typeof(APCommonResx))]	
        Deleted = 4,

		/// <summary>
		/// Gets or sets PostInProgress 
		/// </summary>	
        [EnumValue("PostInProgress", typeof(APCommonResx))]
        PostInProgress = 5,

		/// <summary>
		/// Gets or sets ReadyToPost 
		/// </summary>	
        [EnumValue("ReadyToPost", typeof(APCommonResx))]
        ReadyToPost = 7,

		/// <summary>
		/// Gets or sets CheckCreationInProgress 
		/// </summary>	
        [EnumValue("CheckCreationInProgress", typeof(EnumerationsResx))]
        CheckCreationInProgress = 8,
	}
}
