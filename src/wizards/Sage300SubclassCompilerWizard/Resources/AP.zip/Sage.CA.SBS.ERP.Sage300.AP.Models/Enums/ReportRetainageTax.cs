// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Report Retainage Tax 
    /// </summary>
    public enum ReportRetainageTax
    {
        /// <summary>
        /// Gets or sets AtTimeofOriginalDocument 
        /// </summary>	
        [EnumValue("ReportRetainageTax_AtTimeofOriginalDocument", typeof(EnumerationsResx), 0)]
        AtTimeofOriginalDocument = 0,

        /// <summary>
        /// Gets or sets AsPerTaxAuthority 
        /// </summary>	
        [EnumValue("ReportRetainageTax_AsPerTaxAuthority", typeof(EnumerationsResx), 1)]
        AsPerTaxAuthority = 1,
    }
}
