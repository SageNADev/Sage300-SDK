/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

#region Namespaces
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for 1099/CPRS Category 
    /// </summary>
    public enum Category
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>
        None = 0,

        /// <summary>
        /// Gets or sets Rents 
        /// </summary>
        Rents = 1010,

        /// <summary>
        /// Gets or sets Royalties 
        /// </summary>
        Royalties = 1020,

        /// <summary>
        /// Gets or sets Other Income 
        /// </summary>
        OtherIncome = 1030,

        /// <summary>
        /// Gets or sets Federal Income Tax Withheld 
        /// </summary>
        FederalIncomeTWH = 1040,

        /// <summary>
        /// Gets or sets Fishing Boat Proceeds
        /// </summary>
        FishingBoatProceed = 1050,

        /// <summary>
        /// Gets or sets Medical and Health Care Payments
        /// </summary>
        MedicalHealthCarePayments = 1060,

        /// <summary>
        /// Gets or sets Direct Sales for Resale 
        /// </summary>
        DirectSalesForResale = 1070,

        /// <summary>
        /// Gets or sets Substitute in Lieu of Interest
        /// </summary>
        SubstituteInLieuOfInterest = 1080,

        /// <summary>
        /// Gets or sets Crop Insurance Proceeds
        /// </summary>
        CropInsuranceProceeds = 1090,

        /// <summary>
        /// Gets or sets Gross Proceeds Paid to an Attomey
        /// </summary>
        GrossProceedsPaidToAnAttomey = 1100,

        /// <summary>
        /// Gets or sets Section 409A Deferrals
        /// </summary>
        Section409ADeferrals = 1120,

        /// <summary>
        /// Gets or sets Excess Golden Parachute Payments
        /// </summary>
        ExcessGoldenParachutePayments = 1130,

        /// <summary>
        /// Gets or sets Nonqualified Deferred Compensation
        /// </summary>
        NonqualifiedDeferredCompensation = 1140,

        /// <summary>
        /// Gets or sets State Tax Withheld
        /// </summary>
        StateWHT = 1150,

        /// <summary>
        /// Gets or sets Fish Purchased for Resale
        /// </summary>
        FishPurchasedForResale = 1160,

        /// <summary>
        /// Gets or sets Nonemployee Compensation
        /// </summary>
        NonemployeeCompensation = 2010,
    }
}
