﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum PostBatchTypeSwitch
    /// </summary>
    public enum PostBatchTypeSwitch
    {
        /// <summary>
        /// Invoice Type batch
        /// </summary>
        Invoice = 1,

        /// <summary>
        /// Payment  Type batch
        /// </summary>
        Payment = 2,

        /// <summary>
        /// Adjustment Type batch
        /// </summary>
        Adjustment = 3
    }
}