/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Job Apply Method 
    /// </summary>
    public enum JobApplyMethod
    {
        /// <summary>
        /// Gets or sets Prorate by Amount 
        /// </summary>	
        [EnumValue("ProratebyAmount", typeof(EnumerationsResx))]
        ProratebyAmount = 0,

        /// <summary>
        /// Gets or sets Top Down
        /// </summary>	
        [EnumValue("TopDown", typeof(EnumerationsResx))]
        TopDown = 1
    }
}