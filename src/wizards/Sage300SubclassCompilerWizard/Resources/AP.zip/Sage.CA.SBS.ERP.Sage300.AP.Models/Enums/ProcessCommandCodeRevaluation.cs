// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
	/// Enum for ProcessCommandCode
	/// </summary>
    public enum ProcessCommandCodeRevaluation
	{
		/// <summary>
		/// Gets or sets InsertOptionalFields
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		//[EnumValue("Generated", typeof(CommonResx))]
		InsertOptionalFields = 0
	}
}
