/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Value Set 
    /// </summary>
    public enum ValueSet
    {
        /// <summary>
        /// Gets or sets No 
        /// </summary>	
        No = 0,

        /// <summary>
        /// Gets or sets Yes 
        /// </summary>	
        Yes = 1,

        /// <summary>
        /// Gets or sets Not Applicable 
        /// </summary>	
        NotApplicable = 99,
    }
}
