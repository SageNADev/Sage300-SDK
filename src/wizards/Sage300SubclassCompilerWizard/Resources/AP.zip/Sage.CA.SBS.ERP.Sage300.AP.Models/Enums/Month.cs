// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum Month
    /// </summary>
    public enum Month
    {
        /// <summary>
        /// The january
        /// </summary>
        [EnumValue("Month_January", typeof (ClearHistoryResx))] January = 1,

        /// <summary>
        /// The february
        /// </summary>
        [EnumValue("Month_February", typeof (ClearHistoryResx))] February = 2,

        /// <summary>
        /// The march
        /// </summary>
        [EnumValue("Month_March", typeof (ClearHistoryResx))] March = 3,

        /// <summary>
        /// The april
        /// </summary>
        [EnumValue("Month_April", typeof (ClearHistoryResx))] April = 4,

        /// <summary>
        /// The may
        /// </summary>
        [EnumValue("Month_May", typeof (ClearHistoryResx))] May = 5,

        /// <summary>
        /// The june
        /// </summary>
        [EnumValue("Month_June", typeof (ClearHistoryResx))] June = 6,

        /// <summary>
        /// The july
        /// </summary>
        [EnumValue("Month_July", typeof (ClearHistoryResx))] July = 7,

        /// <summary>
        /// The august
        /// </summary>
        [EnumValue("Month_August", typeof (ClearHistoryResx))] August = 8,

        /// <summary>
        /// The september
        /// </summary>
        [EnumValue("Month_September", typeof (ClearHistoryResx))] September = 9,

        /// <summary>
        /// The october
        /// </summary>
        [EnumValue("Month_October", typeof (ClearHistoryResx))] October = 10,

        /// <summary>
        /// The november
        /// </summary>
        [EnumValue("Month_November", typeof (ClearHistoryResx))] November = 11,

        /// <summary>
        /// The december
        /// </summary>
        [EnumValue("Month_December", typeof (ClearHistoryResx))] December = 12,
    }
}