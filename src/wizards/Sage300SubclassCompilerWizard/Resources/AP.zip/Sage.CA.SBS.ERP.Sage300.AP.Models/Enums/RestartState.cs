// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for RestartState 
    /// </summary>
    public enum RestartState
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        None = 0,

        /// <summary>
        /// Gets or sets GenerateBankCheckRegister 
        /// </summary>	
        GenerateBankCheckRegister = 1,

        /// <summary>
        /// Gets or sets PrintCheck 
        /// </summary>	
        PrintCheck = 2,

        /// <summary>
        /// When the Print Check screen is open and we have to execute the Update after it
        /// </summary>
        IntermediateState = 99,

        /// <summary>
        /// Gets or sets UpdateStatus 
        /// </summary>	
        UpdateStatus = 3,
    }
}
