/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for CalcBaseforDiscountwithTax 
    /// </summary>
	public enum CalcBaseforDiscountwithTax 
	{
        /// <summary>
        /// Gets or sets Included 
        /// </summary>	
        [EnumValue("Included", typeof(EnumerationsResx))]
        Included = 1,

        /// <summary>
        /// Gets or sets Excluded 
        /// </summary>	
        [EnumValue("Excluded", typeof(EnumerationsResx))]
        Excluded = 2,
	}
}
