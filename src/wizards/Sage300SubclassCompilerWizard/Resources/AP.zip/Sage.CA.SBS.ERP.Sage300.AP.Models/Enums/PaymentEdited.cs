
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for PaymentEdited 
    /// </summary>
	public enum PaymentEdited 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>	
        [EnumValue("No", typeof(EnumerationsResx))]	
        No = 0,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
        [EnumValue("Yes", typeof(EnumerationsResx))]	
        Yes = 1,
		/// <summary>
		/// Gets or sets Deleted 
		/// </summary>	
        [EnumValue("Deleted", typeof(CommonResx))]	
        Deleted = 2,
	}
}
