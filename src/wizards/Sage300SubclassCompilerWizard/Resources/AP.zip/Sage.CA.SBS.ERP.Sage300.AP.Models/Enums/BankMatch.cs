/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for Bank Match 
    /// </summary>
	public enum BankMatch 
	{
	    /// <summary>
		/// Gets or sets Vendors with any bank code 
		/// </summary>	
        [EnumValue("Vendorswithanybankcode", typeof(PaymentSelectionCodesResx))]
        Vendorswithanybankcode = 0,

		/// <summary>
		/// Gets or sets Vendors with payment bank code only 
		/// </summary>	
        [EnumValue("Vendorswithpaymentbankcodeonly", typeof(PaymentSelectionCodesResx))]
        Vendorswithpaymentbankcodeonly = 1,
	}
}
