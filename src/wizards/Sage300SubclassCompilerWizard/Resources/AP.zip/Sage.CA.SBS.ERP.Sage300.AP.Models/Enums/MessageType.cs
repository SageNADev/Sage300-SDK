// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for MessageType 
    /// </summary>
    public enum MessageType
    {
        /// <summary>
        /// Gets or sets InvoiceEmail 
        /// </summary>	
        [EnumValue("InvoiceEmail", typeof (EnumerationsResx))] InvoiceEmail = 0,

        /// <summary>
        /// Gets or sets StatementEmail 
        /// </summary>	
        [EnumValue("StatementEmail", typeof (EnumerationsResx))] StatementEmail = 1,

        /// <summary>
        /// Gets or sets LetterEmail 
        /// </summary>	
        [EnumValue("LetterEmail", typeof (EnumerationsResx))] LetterEmail = 2,

        /// <summary>
        /// Gets or sets ReceiptEmail 
        /// </summary>	
        [EnumValue("ReceiptEmail", typeof (EnumerationsResx))] ReceiptEmail = 6,
    }
}
