/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Location 
    /// </summary>
    public enum Location
    {
        /// <summary>
        /// Gets or sets VendorsandVendorGroups 
        /// </summary>	
        [EnumValue("VendorsandVendorGroups", typeof(OptionalFieldsResx))]
        VendorsandVendorGroups = 0,
        /// <summary>
        /// Gets or sets RemitToLocations 
        /// </summary>	
        [EnumValue("RemitToLocations", typeof(OptionalFieldsResx))]
        RemitToLocations = 1,
        /// <summary>
        /// Gets or sets Invoices 
        /// </summary>	
        [EnumValue("Invoices", typeof(OptionalFieldsResx))]
        Invoices = 2,
        /// <summary>
        /// Gets or sets InvoiceDetails 
        /// </summary>	
        [EnumValue("InvoiceDetails", typeof(OptionalFieldsResx))]
        InvoiceDetails = 3,
        /// <summary>
        /// Gets or sets Payments 
        /// </summary>	
        [EnumValue("Payments", typeof(OptionalFieldsResx))]
        Payments = 4,
        /// <summary>
        /// Gets or sets Adjustments 
        /// </summary>	
        [EnumValue("Adjustments", typeof(OptionalFieldsResx))]
        Adjustments = 5,
        /// <summary>
        /// Gets or sets Revaluation 
        /// </summary>	
        [EnumValue("Revaluation", typeof(OptionalFieldsResx))]
        Revaluation = 6,
    }
}
