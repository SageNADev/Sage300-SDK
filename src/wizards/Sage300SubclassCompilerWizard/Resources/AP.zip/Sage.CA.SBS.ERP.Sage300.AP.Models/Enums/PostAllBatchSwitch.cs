﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum PostAllBatchesSwitch
    /// </summary>
    public enum PostAllBatchSwitch
    {
        /// <summary>
        /// Postall batches
        /// </summary>
        PostallBatches = 0,

        /// <summary>
        /// Postby batch range
        /// </summary>
        PostbyBatchRange = 1
    }
}