 
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for CalculateTaxAmountControl 
    /// </summary>
	public enum CalculateTaxAmountControl 
	{
			/// <summary>
		/// Gets or sets Enter 
		/// </summary>
       [EnumValue("Enter", typeof(PaymentEntryResx))]
        Enter = 0,
		/// <summary>
		/// Gets or sets Calculate 
		/// </summary>
        [EnumValue("Calculate", typeof(PaymentEntryResx))]
        Calculate = 1,
		/// <summary>
		/// Gets or sets Distribute 
		/// </summary>	
         [EnumValue("Distribute", typeof(PaymentEntryResx))]
        Distribute = 2,
	}
}
