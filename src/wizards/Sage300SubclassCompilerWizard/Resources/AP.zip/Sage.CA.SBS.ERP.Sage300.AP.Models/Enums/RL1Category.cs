/* Copyright (c) 1994-2026 Sage Software, Inc.  All rights reserved. */
// Portions edited by AI:
//  Defined the three RL-1 category values used by the Vendor RL1Category field.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Defines the RL-1 category for a vendor.
    /// </summary>
    public enum RL1Category
    {
        /// <summary>
        /// RL-1 is not applicable.
        /// </summary>
        [EnumValue("RL1NotApplicable", typeof(VendorResx))]
        NotApplicable = 0,

        /// <summary>
        /// Trucking services.
        /// </summary>
        [EnumValue("RL1TruckingServices", typeof(VendorResx))]
        TruckingServices = 1,

        /// <summary>
        /// Building services.
        /// </summary>
        [EnumValue("RL1BuildingServices", typeof(VendorResx))]
        BuildingServices = 2
    }
}
