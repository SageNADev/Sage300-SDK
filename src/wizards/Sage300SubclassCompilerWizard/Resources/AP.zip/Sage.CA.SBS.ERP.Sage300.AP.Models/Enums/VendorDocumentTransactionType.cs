/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType 
    /// </summary>
    public enum VendorDocumentTransactionType
    {
        /// <summary>
        /// Gets or sets InvoiceSummaryEntered 
        /// </summary>	
        InvoiceSummaryEntered = 12,
        /// <summary>
        /// Gets or sets InvoiceRecurringCharge 
        /// </summary>	
        InvoiceRecurringCharge = 13,
        /// <summary>
        /// Gets or sets DebitNoteSummaryEntered 
        /// </summary>	
        DebitNoteSummaryEntered = 22,
        /// <summary>
        /// Gets or sets CreditNoteSummaryEntered 
        /// </summary>	
        CreditNoteSummaryEntered = 32,
        /// <summary>
        /// Gets or sets InterestCharge 
        /// </summary>	
        InterestCharge = 40,
        /// <summary>
        /// Gets or sets PrepaymentPosted 
        /// </summary>	
        PrepaymentPosted = 50,
        /// <summary>
        /// Gets or sets PaymentPosted 
        /// </summary>	
        PaymentPosted = 51,
    }
}
