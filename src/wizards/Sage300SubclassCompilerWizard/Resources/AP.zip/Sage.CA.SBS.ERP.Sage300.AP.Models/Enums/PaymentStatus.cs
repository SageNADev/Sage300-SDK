// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for PaymentStatus 
    /// </summary>
    public enum PaymentStatus
    {
        /// <summary>
        /// Gets or sets Normal 
        /// </summary>	
        [EnumValue("Normal", typeof(ControlPaymentResx))]
        Normal = 0,
        /// <summary>
        /// Gets or sets OnHold 
        /// </summary>	
        [EnumValue("OnHold", typeof(APCommonResx))]
        OnHold = 1,
        /// <summary>
        /// Gets or sets Forced 
        /// </summary>	
        [EnumValue("Forced", typeof(ControlPaymentResx))]
        Forced = 2
    }
}
