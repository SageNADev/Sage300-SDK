// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for CodeType 
    /// </summary>
	public enum CodeType 
	{
			/// <summary>
		/// Gets or sets Purchase 
		/// </summary>	
        [EnumValue("Purchase", typeof(DistributionSetsResx))]
        Purchase = 1
	}
}
