// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for DefaultPostingDate 
    /// </summary>
    public enum DefaultPostingDate
    {
        /// <summary>
        /// Gets or sets Document Date 
        /// </summary>	
        [EnumValue("DocumentDate", typeof(APCommonResx), 0)]
        DocumentDate = 0,

        /// <summary>
        /// Gets or sets Batch Date 
        /// </summary>	

        [EnumValue("BatchDate", typeof(APCommonResx), 1)]
        BatchDate = 1,

        /// <summary>
        /// Gets or sets Session Date 
        /// </summary>	

        [EnumValue("DefaultPostingDate_SessionDate", typeof(EnumerationsResx), 2)]
        SessionDate = 2,
    }
}
