/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for DocumentType 
    /// </summary>
    public enum PostedPaymentTransactionType
    {
        ///// <summary>
        ///// Gets or sets UnappliedCash 
        ///// </summary>	
        //UnappliedCash = 5,

        /// <summary>
        /// Gets or sets All
        /// </summary>
        [EnumValue("All", typeof(CommonResx))]
        All = -1,

        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>	
        [EnumValue("Prepayment", typeof(APCommonResx))]
        Prepayment = 10,

        /// <summary>
        /// Gets or sets Payment 
        /// </summary>	
        [EnumValue("Payment", typeof(APCommonResx))]
        Payment = 11
    }
}
