/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enumeration for Type 
    /// </summary>
    public enum Type
    {
        /// <summary>
        /// Gets or sets Text 
        /// </summary>	
        [EnumValue("Text", typeof(OptionalFieldsResx))]
        Text = 1,

        /// <summary>
        /// Gets or sets Amount 
        /// </summary>	
        [EnumValue("Amount", typeof(OptionalFieldsResx))]
        Amount = 100,

        /// <summary>
        /// Gets or sets Number 
        /// </summary>
        [EnumValue("Number", typeof(OptionalFieldsResx))]	
        Number = 6,

        /// <summary>
        /// Gets or sets Integer 
        /// </summary>	
        [EnumValue("Integer", typeof(OptionalFieldsResx))]	
        Integer = 8,

        /// <summary>
        /// Gets or sets YesOrNo 
        /// </summary>
        [EnumValue("YesOrNo", typeof(OptionalFieldsResx))]	
        YesOrNo = 9,

        /// <summary>
        /// Gets or sets Date 
        /// </summary>	
        [EnumValue("Date", typeof(OptionalFieldsResx))]	
        Date = 3,

        /// <summary>
        /// Gets or sets Time 
        /// </summary>
        [EnumValue("Time", typeof(OptionalFieldsResx))]		
        Time = 4,
    }
}
