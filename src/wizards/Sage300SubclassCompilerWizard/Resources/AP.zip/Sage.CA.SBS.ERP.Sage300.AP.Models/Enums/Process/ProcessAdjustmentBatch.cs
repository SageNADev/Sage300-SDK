// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessAdjustmentBatch 
    /// </summary>
    public enum ProcessAdjustmentBatch
    {
        /// <summary>
        /// Gets or sets DoNotPostAdjustmentBatches 
        /// </summary>	
        DoNotPostAdjustmentBatches = 0,

        /// <summary>
        /// Gets or sets PostAdjustmentBatches 
        /// </summary>	
        PostAdjustmentBatches = 1,
    }
}
