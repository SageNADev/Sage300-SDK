/* Copyright (c) 1994-2025 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for TransmitterAccountType
    /// </summary>
	public enum TransmitterAccountType
    {

        /// <summary>
        /// Gets or sets BN9
        /// </summary>	
        [EnumValue("AccountType_BN9", typeof(T5018CPRSElectronicFilingResx))]
        BN9 = 1,

        /// <summary>
        /// Gets or sets BN15
        /// </summary>	
        [EnumValue("AccountType_BN15", typeof(T5018CPRSElectronicFilingResx))]
        BN15 = 2,

        /// <summary>
        /// Gets or sets TRUST
        /// </summary>	
        [EnumValue("AccountType_TRUST", typeof(T5018CPRSElectronicFilingResx))]
        TRUST = 3,

        /// <summary>
        /// Gets or sets NR4
        /// </summary>	
        [EnumValue("AccountType_NR4", typeof(T5018CPRSElectronicFilingResx))]
        NR4 = 4,


    }
}
