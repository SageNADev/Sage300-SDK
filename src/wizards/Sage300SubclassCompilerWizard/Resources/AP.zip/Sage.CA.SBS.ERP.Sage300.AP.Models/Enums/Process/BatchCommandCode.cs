 
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
	/// <summary>
    /// Enum for CommandCode 
    /// </summary>
	public enum BatchCommandCode 
	{
			/// <summary>
		/// Gets or sets InvoiceBatches 
		/// </summary>	
        InvoiceBatches = 20,
		/// <summary>
		/// Gets or sets PaymentBatches 
		/// </summary>	
        PaymentBatches = 30,
		/// <summary>
		/// Gets or sets AdjustmentBatches 
		/// </summary>	
        AdjustmentBatches = 40,
		/// <summary>
		/// Gets or sets InvoicePostingJournal 
		/// </summary>	
        InvoicePostingJournal = 50,
		/// <summary>
		/// Gets or sets PaymentPostingJournal 
		/// </summary>	
        PaymentPostingJournal = 60,
		/// <summary>
		/// Gets or sets AdjustmentPostingJournal 
		/// </summary>	
        AdjustmentPostingJournal = 70,
		/// <summary>
		/// Gets or sets RevaluationPostingJournal 
		/// </summary>	
        RevaluationPostingJournal = 80,
	}
}
