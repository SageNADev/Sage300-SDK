// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessPaymentBatch 
    /// </summary>
    public enum ProcessPaymentBatch
    {
        /// <summary>
        /// Gets or sets DoNotPostPaymentBatches 
        /// </summary>	
        DoNotPostPaymentBatches = 0,

        /// <summary>
        /// Gets or sets PostPaymentBatches 
        /// </summary>	
        PostPaymentBatches = 1,
    }
}
