/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for TransmitterLanguage 
    /// </summary>
	public enum TransmitterLanguage 
	{
	
		/// <summary>
		/// Gets or sets English 
		/// </summary>	
        [EnumValue("Language_Eng", typeof(EnumerationsResx))]
        English = 1,

		/// <summary>
		/// Gets or sets French 
		/// </summary>	
        [EnumValue("Language_French", typeof(EnumerationsResx))]
        French = 2,

	}
}
