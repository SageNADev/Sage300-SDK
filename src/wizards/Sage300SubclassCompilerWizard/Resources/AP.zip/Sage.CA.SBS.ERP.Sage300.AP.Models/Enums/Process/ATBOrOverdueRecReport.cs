/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process

{
	/// <summary>
    /// Enum for ATBOrOverdueRecReport 
    /// </summary>
	public enum ATBOrOverdueRecReport 
	{
			/// <summary>
		/// Gets or sets AgedPayables 
		/// </summary>	
        AgedPayables = 0,
		/// <summary>
		/// Gets or sets OverduePayables 
		/// </summary>	
        OverduePayables = 1,
		/// <summary>
		/// Gets or sets AgedCashRequirements 
		/// </summary>	
        AgedCashRequirements = 2,
	}
}
