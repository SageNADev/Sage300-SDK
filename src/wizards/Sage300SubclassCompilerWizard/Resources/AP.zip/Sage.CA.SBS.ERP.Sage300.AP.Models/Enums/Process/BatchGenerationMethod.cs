// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
    /// <summary>
    /// Enum for BatchGenerationMethod 
    /// </summary>
    public enum BatchGenerationMethod
    {
        /// <summary>
        /// Gets or sets Default 
        /// </summary>	
        [EnumValue("BatchGenerationMethod_Default", typeof (EnumerationsResx))] Default = 0,

        /// <summary>
        /// Gets or sets CreateaNewBatch 
        /// </summary>	
        [EnumValue("BatchGenerationMethod_CreateaNewBatch", typeof (EnumerationsResx))] CreateaNewBatch = 1,

        /// <summary>
        /// Gets or sets AddtoanExistingBatch 
        /// </summary>	
        [EnumValue("BatchGenerationMethod_AddtoanExistingBatch", typeof (EnumerationsResx))] AddtoanExistingBatch = 2,
    }
}
