// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessInvoiceBatch 
    /// </summary>
    public enum ProcessInvoiceBatch
    {
        /// <summary>
        /// Gets or sets DoNotPostInvoiceBatches 
        /// </summary>	
        DoNotPostInvoiceBatches = 0,

        /// <summary>
        /// Gets or sets PostInvoiceBatches 
        /// </summary>	
        PostInvoiceBatches = 1,
    }
}
