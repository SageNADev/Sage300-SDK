/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Process;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for ReportType 
    /// </summary>
	public enum ReportType 
	{
	
		/// <summary>
		/// Gets or sets Original 
		/// </summary>	
        [EnumValue("Original", typeof(T5018CPRSElectronicFilingResx))]
        Original = 1,

		/// <summary>
		/// Gets or sets Amended 
		/// </summary>	
        [EnumValue("Amended", typeof(T5018CPRSElectronicFilingResx))]
        Amended = 2,

        /// <summary>
        /// Gets or sets Cancelled 
        /// </summary>	
        [EnumValue("Cancelled", typeof(T5018CPRSElectronicFilingResx))]
        Cancelled = 3,

	}
}
