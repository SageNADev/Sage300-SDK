// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
	/// <summary>
	/// Enum for ClearType
	/// </summary>
	public enum ClearType
	{
		/// <summary>
		/// Gets or sets ClearFullyPaidDocuments
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		ClearFullyPaidDocuments = 0,

		/// <summary>
		/// Gets or sets ClearPrintedPostingJournals
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		ClearPrintedPostingJournals = 1,

		/// <summary>
		/// Gets or sets ClearPostingErrors
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		ClearPostingErrors = 2
	}
}
