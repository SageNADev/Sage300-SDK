// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
    /// <summary>
    /// Enum for DistributionMethod 
    /// </summary>
    public enum DistributionMethod
    {
        /// <summary>
        /// Gets or sets SpreadEvenly 
        /// </summary>	
        [EnumValue("SpreadEvenly", typeof(DistributionSetsResx))]
        SpreadEvenly = 1,
        /// <summary>
        /// Gets or sets FixedPercentage 
        /// </summary>	
        [EnumValue("FixedPercentage", typeof(DistributionSetsResx))]
        FixedPercentage = 2,
        /// <summary>
        /// Gets or sets Manual 
        /// </summary>
        [EnumValue("Manual", typeof(DistributionSetsResx))]
        Manual = 3,
        /// <summary>
        /// Gets or sets FixedAmount 
        /// </summary>	
        [EnumValue("FixedAmount", typeof(DistributionSetsResx))]
        FixedAmount = 4,
    }
}
