// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessRevalueBatch 
    /// </summary>
    public enum ProcessRevalueBatch
    {
        /// <summary>
        /// Gets or sets DoNotPostRevaluationBatches 
        /// </summary>	
        DoNotPostRevaluationBatches = 0,

        /// <summary>
        /// Gets or sets PostRevaluationBatches 
        /// </summary>	
        PostRevaluationBatches = 1,
    }
}
