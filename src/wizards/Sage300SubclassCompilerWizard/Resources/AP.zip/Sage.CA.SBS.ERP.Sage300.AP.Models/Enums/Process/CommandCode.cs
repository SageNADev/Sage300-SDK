// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
	/// <summary>
    /// Enum for CommandCode 
    /// </summary>
	public enum CommandCode 
	{
		/// <summary>
		/// Gets or sets CalculateReportable 
		/// </summary>	
        CalculateReportable = 0,

		/// <summary>
		/// Gets or sets GenerateCSVFile 
		/// </summary>	
        GenerateCSVFile = 1,

	}
}
