﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
    /// <summary>
    /// Enum for Select Documents By
    /// </summary>
    public enum SelectDocumentsBy
    {
        /// <summary>
        /// Gets or sets Vendor Number
        /// </summary>
        [EnumValue("VendorNumber", typeof(APCommonResx))]
        VendorNumber = 0,

        /// <summary>
        /// Gets or sets Document Number
        /// </summary>
        [EnumValue("DocumentNumber", typeof(APCommonResx))]
        DocumentNumber = 1,

        /// <summary>
        /// Gets or sets Vendor Group
        /// </summary>
        [EnumValue("VendorGroup", typeof(APCommonResx))]
        VendorGroup = 2
    }
}
