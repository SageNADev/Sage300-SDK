// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
    /// <summary>
    /// Enum for Processswitches 
    /// </summary>
    public enum Processswitches
    {
        /// <summary>
        /// Gets or sets InsertJournalEntryOptionalFields 
        /// </summary>	
        InsertJournalEntryOptionalFields = 0,

        /// <summary>
        /// Gets or sets RefreshJournalHeaderFields 
        /// </summary>	
        RefreshJournalHeaderFields = 3,

        /// <summary>
        /// Gets or sets RefreshSourceLedgerFieldinJournalHeader 
        /// </summary>	
        RefreshSourceLedgerFieldinJournalHeader = 4,
    }
}
