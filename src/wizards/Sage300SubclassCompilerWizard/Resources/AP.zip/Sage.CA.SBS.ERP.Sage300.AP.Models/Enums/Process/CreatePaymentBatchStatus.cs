﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
    /// <summary>
    /// Enum for CreatePaymentBatchStatus 
    /// </summary>
    public enum CreatePaymentBatchStatus
    {
        /// <summary>
        /// Generate
        /// </summary>
        Generate = 0,

        /// <summary>
        /// Register
        /// </summary>
        Register = 1,

    }
}
