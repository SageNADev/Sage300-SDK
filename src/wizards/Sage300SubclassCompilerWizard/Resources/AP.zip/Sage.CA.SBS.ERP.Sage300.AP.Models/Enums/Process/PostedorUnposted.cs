 
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
	/// <summary>
    /// Enum for PostedorUnposted 
    /// </summary>
	public enum PostedorUnposted 
	{
			/// <summary>
		/// Gets or sets PrintUnpostedBatches 
		/// </summary>	
        PrintUnpostedBatches = 0,
		/// <summary>
		/// Gets or sets PrintPostedBatches 
		/// </summary>	
        PrintPostedBatches = 1,
	}
}
