// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
    /// <summary>
    /// Enum for DateGenerationMethod 
    /// </summary>
    public enum DateGenerationMethod
    {
        /// <summary>
        /// Gets or sets RunDate 
        /// </summary>	
        RunDate = 0,

        /// <summary>
        /// Gets or sets NextScheduleDate 
        /// </summary>	
        NextScheduleDate = 1,

        /// <summary>
        /// Gets or sets SpecificDate 
        /// </summary>	
        SpecificDate = 2,
    }
}
