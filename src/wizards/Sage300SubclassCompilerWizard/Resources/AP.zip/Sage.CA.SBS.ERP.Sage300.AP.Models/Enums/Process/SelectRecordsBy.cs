// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process
{
	/// <summary>
	/// Enum for SelectRecordsBy
	/// </summary>
	public enum SelectRecordsBy
	{
		/// <summary>
		/// Gets or sets RecurringPayableCode
		/// </summary>
        [EnumValue("SelectRecordsBy_RecurringPayableCode", typeof(EnumerationsResx))]
		RecurringPayableCode = 0,

		/// <summary>
		/// Gets or sets VendorNumber
		/// </summary>
        [EnumValue("SelectRecordsBy_VendorNumber", typeof(EnumerationsResx))]
		VendorNumber = 1,

		/// <summary>
		/// Gets or sets VendorGroup
		/// </summary>
        [EnumValue("SelectRecordsBy_VendorGroup", typeof(EnumerationsResx))]
		VendorGroup = 2,

		/// <summary>
		/// Gets or sets ScheduleLink
		/// </summary>
        [EnumValue("SelectRecordsBy_ScheduleLink", typeof(EnumerationsResx))]
		ScheduleLink = 3,

		/// <summary>
		/// Gets or sets SpecificRecurringChargeCode
        /// </summary>
        [EnumValue("SelectRecordsBy_SpecificRecurringChargeCode", typeof(EnumerationsResx))]
		SpecificRecurringChargeCode = 4
	}

   /// <summary>
   /// Enum for SelectRecordsBy. This is a subset of the above list and is only used to display the dropdown list on the UI
   /// </summary>
   public enum SelectRecordsByDropDownList
   {
      /// <summary>
      /// Gets or sets RecurringPayableCode
      /// </summary>
      [EnumValue("SelectRecordsBy_RecurringPayableCode", typeof(EnumerationsResx))]
      RecurringPayableCode = 0,

      /// <summary>
      /// Gets or sets VendorNumber
      /// </summary>
      [EnumValue("SelectRecordsBy_VendorNumber", typeof(EnumerationsResx))]
      VendorNumber = 1,

      /// <summary>
      /// Gets or sets VendorGroup
      /// </summary>
      [EnumValue("SelectRecordsBy_VendorGroup", typeof(EnumerationsResx))]
      VendorGroup = 2,
   }

}
