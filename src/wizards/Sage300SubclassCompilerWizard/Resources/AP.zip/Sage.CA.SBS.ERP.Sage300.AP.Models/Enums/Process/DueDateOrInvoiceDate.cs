 
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for DueDateOrInvoiceDate 
    /// </summary>
	public enum DueDateOrInvoiceDate 
	{
			/// <summary>
		/// Gets or sets DueDate 
		/// </summary>	
        DueDate = 0,
		/// <summary>
		/// Gets or sets DocumentDate 
		/// </summary>	
        DocumentDate = 1,
	}
}
