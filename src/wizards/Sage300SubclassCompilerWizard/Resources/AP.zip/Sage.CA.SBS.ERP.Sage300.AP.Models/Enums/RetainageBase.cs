// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Retainage Base 
    /// </summary>
    public enum RetainageBase
    {
        /// <summary>
        /// Gets or sets DocumentTotalAfterTaxes 
        /// </summary>	
        [EnumValue("RetainageBase_DocumentTotalAfterTaxes", typeof(EnumerationsResx), 0)]
        DocumentTotalAfterTaxes = 0,

        /// <summary>
        /// Gets or sets DocumentTotalBeforeTaxes 
        /// </summary>	
        [EnumValue("RetainageBase_DocumentTotalBeforeTaxes", typeof(EnumerationsResx), 1)]
        DocumentTotalBeforeTaxes = 1,
    }
}
