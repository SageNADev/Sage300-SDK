/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
 
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for Payment Batch Transaction Type 
    /// </summary>
    public enum PaymentBatchTransactionType 
	{
			/// <summary>
		/// Gets or sets PaymentPosted 
		/// </summary>	
        PaymentPosted = 51,

        /// <summary>
		/// Gets or sets PrepaymentPosted 
		/// </summary>	
        PrepaymentPosted = 57,

        /// <summary>
		/// Gets or sets AdjustmentPosted 
		/// </summary>	
        AdjustmentPosted = 81,
	}
}
