 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for Use1099OrCPRSReporting 
    /// </summary>
	public enum Use1099OrCPRSReporting 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>	
         [EnumValue("No", typeof(CommonResx))]
        No = 0,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
      [EnumValue("Yes", typeof(CommonResx))]
        Yes = 1,
	}
}
