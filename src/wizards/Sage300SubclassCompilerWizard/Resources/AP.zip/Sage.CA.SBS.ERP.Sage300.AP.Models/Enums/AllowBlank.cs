using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using EnumerationsResx = Sage.CA.SBS.ERP.Sage300.AP.Resources.EnumerationsResx;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for AllowBlank 
    /// </summary>
	public enum AllowBlank 
	{
        /// <summary>
        /// The no
        /// </summary>
        [EnumValue("No", typeof(CommonResx))]
        No = 0,

        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("Yes", typeof(CommonResx))]
        Yes = 1,
	}
}
