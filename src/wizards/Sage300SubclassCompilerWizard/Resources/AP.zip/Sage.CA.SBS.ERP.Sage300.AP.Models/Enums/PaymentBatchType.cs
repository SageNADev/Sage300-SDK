/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for Payment Batch Type 
    /// </summary>
    public enum PaymentBatchType 
	{
        /// <summary>
		/// Gets or sets Entered 
		/// </summary>	
        [EnumValue("Entered", typeof(APCommonResx))]
        Entered = 1,

        /// <summary>
		/// Gets or sets Imported 
		/// </summary>	
        [EnumValue("Imported", typeof(APCommonResx))]
        Imported = 2,

        /// <summary>
		/// Gets or sets Generated 
		/// </summary>	
        [EnumValue("Generated", typeof(APCommonResx))]
        Generated = 3,

        /// <summary>
		/// Gets or sets System 
		/// </summary>	
        [EnumValue("System", typeof(APCommonResx))]
        System = 4,

        /// <summary>
		/// Gets or sets External 
		/// </summary>	
        [EnumValue("External", typeof(APCommonResx))]
        External = 5,
	}
}
