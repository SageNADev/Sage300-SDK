/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.  */

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for Print Separate Checks 
    /// </summary>
	public enum PrintSeparateChecks 
	{
		/// <summary>
		/// Gets or sets Do Not Print Separate Checks 
		/// </summary>	
        [EnumValue("DoNotPrintSeparateChecks", typeof(EnumerationsResx))]
        DoNotPrintSeparateChecks = 0,

		/// <summary>
		/// Gets or sets Print Separate Checks 
		/// </summary>	
        [EnumValue("PrintSeparateChecks", typeof(EnumerationsResx))]
        PrintSeparateChecks = 1,
	}
}
