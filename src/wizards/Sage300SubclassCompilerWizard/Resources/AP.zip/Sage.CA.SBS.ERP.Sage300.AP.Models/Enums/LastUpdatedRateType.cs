﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Last Updated Rate Type
    /// </summary>
    public enum LastUpdatedRateType
    {
        /// <summary>
        /// Bank Rate Type
        /// </summary>
        BankRateType = 0,

        /// <summary>
        /// Vendor Rate Type
        /// </summary>
        VendorRateType = 1
    }
}
