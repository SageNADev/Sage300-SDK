
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Name Spaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enumeration for Process Command Code 
    /// </summary>
    public enum VendorGroupsProcessCommandCode
	{
        /// <summary>
        /// Value for Insert Optional Fields 
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(VendorGroupResx))]
        InsertOptionalFields = 0,
	}
}
