/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports

{
	/// <summary>
    /// Enum for ATB Or Over due Rec Report 
    /// </summary>
	public enum ATBOrOverdueRecReport 
	{
        /// <summary>
        /// Gets or sets FutureRetainage 
        /// </summary>	
        [EnumValue("FutureRetainage", typeof(AgeRetainageResx))]
        FutureRetainage = 0,
        /// <summary>
        /// Gets or sets Retainage 
        /// </summary>	
        [EnumValue("Retainage", typeof(AgeRetainageResx))]
        Retainage = 1,
        /// <summary>
        /// Gets or sets OverdueRetainage 
        /// </summary>	
        [EnumValue("OverdueRetainage", typeof(AgeRetainageResx))]
        OverdueRetainage = 2,

	}
}
