﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Report Format Type 1. Detail 2. Summary types
    /// </summary>
    public enum VendorGroupReportType
    {
        /// <summary>
        /// VendorGroupList
        /// </summary>
        [EnumValue("GroupList", typeof(VendorGroupReportResx))]
        VendorGroupList = 0,

        /// <summary>
        /// VendorGroupStatistics
        /// </summary>
        [EnumValue("VendorGroupStatistics", typeof(APCommonResx))]
        VendorGroupStatistics = 1
    }
}
