﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{

    /// <summary>
    /// Aged Payable Reports Types
    /// </summary>
    public enum AgedPayableReportTypes
    {
        /// <summary>
        /// Gets or sets ATB By Due Date
        /// </summary>	
        [EnumValue("AgedPayablesbyDueDate", typeof(AgedPayableReportResx))]
        ATBByDueDate = 1,

        /// <summary>
        /// Gets or sets ATB By Document Date 
        /// </summary>	
        [EnumValue("AgedPayablesbyDocumentDate", typeof(AgedPayableReportResx))]
        ATBByDocDate = 2,

        /// <summary>
        /// Gets or sets Overdue By Due Date 
        /// </summary>	
        [EnumValue("OverduePayablesbyDueDate", typeof(AgedPayableReportResx))]
        ORByDueDate = 3,

        /// <summary>
        ///  Gets or sets Overdue By Document Date 
        /// </summary>
        [EnumValue("OverduePayablesbyDocumentDate", typeof(AgedPayableReportResx))]
        ORByDocDate
        


    }
}
