﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Currency Type
    /// </summary>
    public enum CurrencyType
    {
        /// <summary>
        /// Functional Currency
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(CommonResx))]
        FunctionalCurrency = 0,

        /// <summary>
        ///  Source Currency
        /// </summary>
        [EnumValue("SourceCurrency", typeof(APCommonResx))]
        SourceCurrency = 1
    }
}

