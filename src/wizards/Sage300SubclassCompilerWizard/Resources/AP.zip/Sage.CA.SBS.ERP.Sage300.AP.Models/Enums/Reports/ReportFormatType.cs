﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Report Format Type 1. Detail 2. Summary types
    /// </summary>
    public enum ReportFormatType
    {
        /// <summary>
        /// Detail
        /// </summary>
        [EnumValue("Detail", typeof(APCommonResx))]
        Detail = 0,

        /// <summary>
        /// Summary
        /// </summary>
        [EnumValue("Summary", typeof(APCommonResx))]
        Summary = 1
    }
}
