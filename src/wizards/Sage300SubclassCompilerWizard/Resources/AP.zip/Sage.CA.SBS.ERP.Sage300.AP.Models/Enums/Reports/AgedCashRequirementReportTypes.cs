﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{

    /// <summary>
    /// Aged Payable Reports Types
    /// </summary>
    public enum AgedCashRequirementReportTypes
    {
        /// <summary>
        /// Gets or sets ATB By Due Date
        /// </summary>	
        [EnumValue("RptAgedPayablesbyDueDate", typeof(AgedPayableReportResx))]
        ATBByDueDate = 1,

        /// <summary>
        /// Gets or sets ATB By Document Date 
        /// </summary>	
        [EnumValue("RptAgedPayablesbyDocumentDate", typeof(AgedPayableReportResx))]
        ATBByDocDate = 2,

        /// <summary>
        /// Gets or sets Overdue By Due Date 
        /// </summary>	
        [EnumValue("RptOverduePayablesbyDocumentDate", typeof(AgedPayableReportResx))]
        ORByDueDate = 3,

        /// <summary>
        ///  Gets or sets Overdue By Document Date 
        /// </summary>
        [EnumValue("RptOverduePayablesbyDueDate", typeof(AgedPayableReportResx))]
        ORByDocDate
        


    }
}
