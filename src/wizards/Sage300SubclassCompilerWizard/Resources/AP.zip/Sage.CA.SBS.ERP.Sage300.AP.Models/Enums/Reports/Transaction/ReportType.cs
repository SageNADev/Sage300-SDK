﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports.Transaction
{
    /// <summary>
    /// Enum for Report Type
    /// </summary>
    public enum ReportType
    {
        /// <summary>
        /// Invoice
        /// </summary>
        [EnumValue("Invoice1", typeof(APCommonResx))]
        Invoice=1,
       
        /// <summary>
        /// Payment
        /// </summary>
        [EnumValue("Payment", typeof(APCommonResx))]
        Payment=2,

        /// <summary>
        /// Adjustment
        /// </summary>
        [EnumValue("Adjustment", typeof(APCommonResx))]
        Adjustment=3,
    }
}
