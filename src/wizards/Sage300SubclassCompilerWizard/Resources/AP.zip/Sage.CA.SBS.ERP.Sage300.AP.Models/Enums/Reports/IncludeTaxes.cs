
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
	/// <summary>
    /// Enum for Include Taxes 
    /// </summary>
	public enum IncludeTaxes 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>	
        No = 0,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
        Yes = 1,
	}
}
