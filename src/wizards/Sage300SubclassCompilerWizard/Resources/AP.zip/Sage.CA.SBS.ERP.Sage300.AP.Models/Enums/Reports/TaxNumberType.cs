/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
	/// <summary>
    /// Enum for Tax Number Type
    /// </summary>
    public enum TaxNumberType
	{
		/// <summary>
        /// Gets or sets Employer Id Number 
		/// </summary>	
        [EnumValue("EIN", typeof(Print10991096FormsResx))]
        EmployerIdNumber = 1,
		/// <summary>
        /// Gets or sets Social Security Number 
		/// </summary>	
        [EnumValue("SSN", typeof(Print10991096FormsResx))]
        SocialSecurityNumber = 2,
	}
}
