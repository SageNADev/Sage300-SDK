
#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
	/// <summary>
    /// Enum for Func Or Vend or Currency 
    /// </summary>
	public enum FuncOrVendorCurrency 
	{
			/// <summary>
		/// Gets or sets VendorCurrency 
		/// </summary>	
        [EnumValue("VendorCurrency", typeof(APCommonResx))]
        VendorCurrency = 0,
		/// <summary>
		/// Gets or sets FunctionalCurrency 
		/// </summary>	
        [EnumValue("FunctionalCurrency", typeof(APCommonResx))]
        FunctionalCurrency = 1,
	}
}
