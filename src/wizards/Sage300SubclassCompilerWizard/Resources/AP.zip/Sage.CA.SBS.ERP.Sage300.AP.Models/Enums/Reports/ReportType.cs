﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
    /// <summary>
    /// Enum ReportType
    /// </summary>
    public  enum ReportType
    {
        /// <summary>
        /// Gets or sets Vendors
        /// </summary>
        [EnumValue("ReportType_Vendors", typeof(VendorReportResx))]
        Vendors = 0,

        /// <summary>
        /// Gets or sets Vendor Activity Statistics
        /// </summary>
        [EnumValue("ReportType_VendorActivityStatistics", typeof(VendorReportResx))]
        VendorActivityStatistics = 1,

        /// <summary>
        /// Gets or sets Vendor Period Statistics
        /// </summary>
        [EnumValue("ReportType_VendorPeriodStatistics", typeof(VendorReportResx))]
        VendorPeriodStatistics = 2,
    }
}
