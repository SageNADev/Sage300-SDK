﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Letter And Label Report Delivery Method
    /// </summary>
    public enum ReportDeliveryMethod
    {
        /// <summary>
        /// Gets or sets PrintDestination
        /// </summary>	
        [EnumValue("PrintDestination", typeof(APCommonResx))]
        PrintDestination,

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [EnumValue("Vendor", typeof(APCommonResx))]
        Vendor
    }
}
