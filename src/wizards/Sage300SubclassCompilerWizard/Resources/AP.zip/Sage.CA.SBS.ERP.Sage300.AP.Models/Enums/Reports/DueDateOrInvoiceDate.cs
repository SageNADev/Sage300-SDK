/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
	/// <summary>
    /// Enum for Due Date Or Invoice Date 
    /// </summary>
	public enum DueDateOrInvoiceDate 
	{
			/// <summary>
		/// Gets or sets DueDate 
		/// </summary>	
        [EnumValue("DueDate", typeof(APCommonResx))]
        DueDate = 0,
		/// <summary>
		/// Gets or sets Document Date 
		/// </summary>	
        [EnumValue("DocumentDate", typeof(APCommonResx))]
        DocumentDate = 1,
	}
}
