﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
    /// <summary>
    /// Enum for SelectJournal
    /// </summary>
    public enum SelectJournal
    {
        #region Enum for SelectJournal

        /// <summary>
        /// The Invoice
        /// </summary>
        [EnumValue("Invoice1", typeof(APCommonResx))]
        Invoice = 0,

        /// <summary>
        /// The Payment
        /// </summary>
        [EnumValue("Payment", typeof(APCommonResx))]
        Payment = 1,

        /// <summary>
        /// The Adjustment
        /// </summary>
        [EnumValue("Adjustment", typeof(APCommonResx))]
        Adjustment = 2,

        /// <summary>
        /// The Revaluation
        /// </summary>
        [EnumValue("Revaluation", typeof(APCommonResx))]
        Revaluation = 3,

        /// <summary>
        /// The ProvisionalRevaluation
        /// </summary>
        [EnumValue("ProvisionalRevaluation", typeof(APCommonResx))]
        ProvisionalRevaluation = 4,

        #endregion
    }
}