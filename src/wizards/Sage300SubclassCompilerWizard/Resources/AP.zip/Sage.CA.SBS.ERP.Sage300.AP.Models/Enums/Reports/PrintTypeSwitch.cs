﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
    /// <summary>
    /// Print Type enum
    /// </summary>
    public enum PrintTypeSwitch
    {
        /// <summary>
        /// The Letter Type
        /// </summary>
        [EnumValue("Letter", typeof(LetterAndLabelResx))]
        Letter,

        /// <summary>
        /// The Label Type
        /// </summary>
        [EnumValue("Label", typeof(LetterAndLabelResx))]
        Label
    }
}
