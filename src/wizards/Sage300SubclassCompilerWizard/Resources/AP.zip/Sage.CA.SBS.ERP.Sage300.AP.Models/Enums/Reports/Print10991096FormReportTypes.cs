﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
    public enum Print10991096FormReportTypes
    {
        /// <summary>
        /// Gets or sets Report 1099
        /// </summary>	
        [EnumValue("_1099", typeof(Print10991096FormsResx))]
        Print1099 = 0,

        /// <summary>
        /// Gets or sets Report 1096
        /// </summary>	
        [EnumValue("_1096", typeof(Print10991096FormsResx))]
        Print1096 = 1,


    }
}
