﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports.Transaction
{
    /// <summary>
    /// Enum for Report Type of Vendor Transaction
    /// </summary>
    public enum VendorTransactionReportType
    {
        /// <summary>
        /// Vendor Transaction By Document Date
        /// </summary>
        [EnumValue("VendorTransactionsbyDocumentDate", typeof(VendorTransactionsReportResx))]
        ByDocumentDate = 0,

        /// <summary>
        /// Vendor Transaction By Document Date
        /// </summary>
        [EnumValue("VendorTransactionsbyDocumentNumber", typeof(VendorTransactionsReportResx))]
        ByDocumentNumber = 1, 

        /// <summary>
        /// Vendor Transaction By Fiscal Year And Period
        /// </summary>
        [EnumValue("VendorTransactionsbyFiscalYearandPeriod", typeof(VendorTransactionsReportResx))]
        ByFiscalYearAndPeriod = 2,
    }
}
