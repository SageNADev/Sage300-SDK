/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
	/// <summary>
    /// Enum for Include Payments On Hold 
    /// </summary>
	public enum IncludePaymentsOnHold 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>	
        No = 0,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
        Yes = 1,
	}
}
