﻿/* Copyright (c) 2020-2022 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
    public enum Print1099FormTypes
    {
        /// <summary>
        /// Gets or sets Report 1099
        /// </summary>	
        [EnumValue("_1099Misc", typeof(Print10991096FormsResx))]
        _1099Misc = 101,

        /// <summary>
        /// Gets or sets Report 1099
        /// </summary>	
        [EnumValue("_1099Nec", typeof(Print10991096FormsResx))]
        _1099Nec = 102,

        /// <summary>
        /// Gets or sets Report 1099
        /// </summary>	
        [EnumValue("_1099Int", typeof(Print10991096FormsResx))]
        _1099Int = 103,

        /// <summary>
        /// Gets or sets Report 1099
        /// </summary>	
        [EnumValue("TINVerification", typeof(Print10991096FormsResx))]
        TINVER = 104,
    }
}
