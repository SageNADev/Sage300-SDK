﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
    /// <summary>
    /// Enum PrintAmountsIn
    /// </summary>
    public enum PrintAmountsIn
    {
        /// <summary>
        /// Gets or sets Vendor Currency
        /// </summary>
        [EnumValue("VendorCurrency", typeof(APCommonResx))] 
        VendorCurrency = 0,

        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(APCommonResx))]
        FunctionalCurrency = 1,
    }
}
