/* Copyright (c) 1994-2025 The Sage Group plc or its licensors.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
	/// <summary>
    /// Enum for Command Code 
    /// </summary>
	public enum CommandCode 
	{
			/// <summary>
		/// Gets or sets Setup 
		/// </summary>	
        Setup = 1,
		/// <summary>
		/// Gets or sets Generate Sorted WorkFile 
		/// </summary>	
        GenerateSortedWorkFile = 51,
		/// <summary>
		/// Gets or sets Generate Unsorted WorkFile 
		/// </summary>	
        GenerateUnsortedWorkFile = 52,
		/// <summary>
		/// Clean up after <see cref="StatelessGenerateUnsortedWorkFile"/>
		/// </summary>
        StatelessCleanWorkFile = 53,
        /// <summary>
        /// Stateless equivalent of <see cref="GenerateUnsortedWorkFile"/>
        /// </summary>
        /// <seealso cref="StatelessCleanWorkFile"/>
        StatelessGenerateUnsortedWorkFile = 54,
		/// <summary>
		/// Gets or sets Single Age Calculation 
		/// </summary>	
        SingleAgeCalculation = 61,
		/// <summary>
		/// Gets or sets Bucket Total Calculation 
		/// </summary>	
        BucketTotalCalculation = 71,
	}
}
