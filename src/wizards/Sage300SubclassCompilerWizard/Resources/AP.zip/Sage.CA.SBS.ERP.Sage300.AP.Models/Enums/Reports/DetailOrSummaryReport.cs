
#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
    /// <summary>
    /// Enum for DetailOrSummaryReport 
    /// </summary>
    public enum DetailOrSummaryReport
    {
        /// <summary>
        /// Gets or sets Summary 
        /// </summary>    
       [EnumValue("Summary", typeof(APCommonResx))]
        Summary = 0,
        /// <summary>
        /// Gets or sets DetailbyDocument 
        /// </summary>       
        [EnumValue("DetailByDocumentNumber", typeof(APCommonResx))]
        DetailbyDocument = 1,
        /// <summary>
        /// Gets or sets DetailbyDate 
        /// </summary>       
        [EnumValue("DetailByDocumentDate", typeof(APCommonResx))]
        DetailbyDate = 2,
        /// <summary>
        /// Gets or sets DetailbyRetainageDueDate 
        /// </summary>       
       [EnumValue("DetailbyRetainageDueDate", typeof(AgeRetainageResx))]
        DetailbyRetainageDueDate = 3,
    }
}
