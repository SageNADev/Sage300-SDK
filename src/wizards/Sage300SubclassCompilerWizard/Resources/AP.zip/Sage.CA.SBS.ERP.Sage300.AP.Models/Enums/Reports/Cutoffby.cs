/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Cutoffby 
    /// </summary>
    public enum Cutoffby
    {
        /// <summary>
        /// Gets or sets Doc Date 
        /// </summary>	
        [EnumValue("DocumentDate", typeof(APCommonResx))]
        DocDate = 0,

        /// <summary>
        /// Gets or sets Posting Date 
        /// </summary>	
        [EnumValue("PostingDate", typeof(APCommonResx))]
        PostingDate = 1,

        /// <summary>
        /// Gets or sets Year Or Period 
        /// </summary>	
        [EnumValue("YearPeriod", typeof(APCommonResx))]
        YearOrPeriod = 2,
    }
}
