﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports
{
    /// <summary>
    /// enum for PostingJournalSortBy
    /// </summary>
    public enum PostingJournalSortBy
    {
        #region Enum for PostingJournalSortBy

        /// <summary>
        /// The BatchEntryNo
        /// </summary>
        [EnumValue("BatchEntryNo", typeof(PostingJournalResx))]
        BatchEntryNo = 0,

        /// <summary>
        /// The VendorNumber
        /// </summary>
        [EnumValue("VendorNumber", typeof(APCommonResx))]
        VendorNumber = 1,

        /// <summary>
        /// The DocumentDate
        /// </summary>
        [EnumValue("DocumentDate", typeof(APCommonResx))]
        DocumentDate = 2,

        /// <summary>
        /// The DocumentNumber
        /// </summary>
        [EnumValue("DocumentNumber", typeof(APCommonResx))]
        DocumentNumber = 3

        #endregion
    }
}