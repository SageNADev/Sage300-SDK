﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// SortBy Type enum
    /// </summary>
    public enum SortByType
    {
        /// <summary>
        /// Account No
        /// </summary>
        [EnumValue("AccountNo", typeof(GLTransactionsReportResx))]
        AccountNo = 0,
        /// <summary>
        /// Year/Period
        /// </summary>
        [EnumValue("YearPeriod", typeof(APCommonResx))]
        YearOrPeriod = 1,
        /// <summary>
        /// Batch/Entry No
        /// </summary>
        [EnumValue("BatchEntryNo", typeof(GLTransactionsReportResx))]
        BatchOrEntryNo = 2
    }
}
