 
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for DocumentType 
    /// </summary>
	public enum PEDocumentType 
	{
	    /// <summary>
		/// Gets or sets All 
		/// </summary>	
        [EnumValue("All", typeof(APCommonResx))]
        All = 0,
        /// <summary>
        /// Gets or sets Invoice
        /// </summary>
        [EnumValue("Invoice1", typeof(APCommonResx))]
        Invoice = 1,
		/// <summary>
        /// Gets or sets DebitNote 
		/// </summary>	
        [EnumValue("DebitNote", typeof(APCommonResx))]
        DebitNote = 2,
		/// <summary>
        /// Gets or sets CreditNote 
		/// </summary>	
        [EnumValue("CreditNote", typeof(APCommonResx))]
        CreditNote = 3,
		/// <summary>
        /// Gets or sets Interest 
		/// </summary>	
        [EnumValue("Interest", typeof(APCommonResx))]
        Interest = 4,
		/// <summary>
		/// Gets or sets Prepayment 
		/// </summary>	
        [EnumValue("Prepayment", typeof(APCommonResx))]
        Prepayment = 10,		
	}
}
