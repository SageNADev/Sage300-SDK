// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Name Spaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enumeration for Vendor Statistics Period Type 
    /// </summary>
    public enum VendorStatisticsPeriodType
    {
        /// <summary>
        /// Value for Weekly 
        /// </summary>	
        [EnumValue("StatisticsPeriod_Weekly", typeof(EnumerationsResx), 1)]
        Weekly = 1,

        /// <summary>
        /// Value for Seven days 
        /// </summary>
        [EnumValue("StatisticsPeriod_Sevendays", typeof(EnumerationsResx), 2)]
        Sevendays = 2,

        /// <summary>
        /// Value for Biweekly 
        /// </summary>	
        [EnumValue("StatisticsPeriod_Biweekly", typeof(EnumerationsResx), 3)]
        Biweekly = 3,

        /// <summary>
        /// Value for Four weeks 
        /// </summary>	
        [EnumValue("StatisticsPeriod_Fourweeks", typeof(EnumerationsResx), 4)]
        Fourweeks = 4,

        /// <summary>
        /// Value for Monthly 
        /// </summary>
        [EnumValue("StatisticsPeriod_Monthly", typeof(EnumerationsResx), 5)]
        Monthly = 5,

        /// <summary>
        /// Value for Bimonthly 
        /// </summary>
        [EnumValue("StatisticsPeriod_Bimonthly", typeof(EnumerationsResx), 6)]
        Bimonthly = 6,

        /// <summary>
        /// Value for Quarterly 
        /// </summary>	
        [EnumValue("StatisticsPeriod_Quarterly", typeof(EnumerationsResx), 7)]
        Quarterly = 7,

        /// <summary>
        /// Value for Semiannually 
        /// </summary>	
        [EnumValue("StatisticsPeriod_Semiannually", typeof(EnumerationsResx), 8)]
        Semiannually = 8,

        /// <summary>
        /// Value for FiscalPeriod 
        /// </summary>	
        [EnumValue("StatisticsPeriod_FiscalPeriod", typeof(EnumerationsResx), 9)]
        FiscalPeriod = 9,
    }
}
