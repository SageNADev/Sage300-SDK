/* Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved. */
/* Portions co-modified with Claude Code */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum HeaderDescriptionOption for APRIB HDRDESCOP field
    /// </summary>
    public enum HeaderDescriptionOption
    {
        /// <summary>
        /// The original description
        /// </summary>
        OriginalDescription = 1,

        /// <summary>
        /// The original with prefix description
        /// </summary>
        OriginalWithPrefix = 2,

        /// <summary>
        /// The new description
        /// </summary>
        NewDescription = 3,
    }
}
