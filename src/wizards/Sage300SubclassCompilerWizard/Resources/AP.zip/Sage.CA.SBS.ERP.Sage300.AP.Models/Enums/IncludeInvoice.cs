// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for IncludeInvoice
    /// </summary>
    public enum IncludeInvoice
    {
        /// <summary>
        /// Gets or sets DoNotInclude 
        /// </summary>	
        DoNotInclude = 0,

        /// <summary>
        /// Gets or sets Include 
        /// </summary>	
        Include = 1,
    }
}
