 
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for CommandCodes
    /// </summary>
	public enum CommandCodes 
	{
		/// <summary>
		/// Gets or sets CalculateReportable 
		/// </summary>	
        CalculateReportable = 0,
		/// <summary>
		/// Gets or sets GenerateCSVFile 
		/// </summary>	
        GenerateCSVFile = 1,
		/// <summary>
		/// Gets or sets GenerateAatrixFile 
		/// </summary>
		GenerateAatrixFile = 2,
		/// <summary>
		/// Gets or sets GenerateSecuredAUFForWeb 
		/// </summary>
		GenerateSecuredAUFForWeb = 3,
	}
}
