
// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enumeration for TaxType 
    /// </summary>
    public enum TaxType
    {
        /// <summary>
        /// Gets or sets Unknown 
        /// </summary>	
        [EnumValue("Unknown", typeof(APCommonResx))]
        Unknown = 0,

        /// <summary>
        /// Gets or sets Social Security Number 
        /// </summary>	
        [EnumValue("SocialSecurityNumber", typeof(APCommonResx))]
        SocialSecurityNumber = 1,

        /// <summary>
        /// Gets or sets Employer ID Number 
        /// </summary>	
        [EnumValue("EmployerIDNumber", typeof(APCommonResx))]
        EmployerIDNumber = 2,

        /// <summary>
        /// Gets or sets GST Registration Number 
        /// </summary>	
        [EnumValue("GSTRegistrationNumber", typeof(APCommonResx))]
        GSTRegistrationNumber = 3,

        /// <summary>
        /// Gets or sets Business Number 
        /// </summary>	
        [EnumValue("BusinessNumber", typeof(APCommonResx))]
        BusinessNumber = 4,

        /// <summary>
        /// Gets or sets Social Insurance Number 
        /// </summary>	
        [EnumValue("SocialInsuranceNumber", typeof(APCommonResx))]
        SocialInsuranceNumber = 5,
    }
}
