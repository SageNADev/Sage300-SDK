/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Payment Reister Print status
    /// </summary>
    public enum PaymentRegisterPrintstatus
    {
        /// <summary>
        /// Gets or sets Notprinted 
        /// </summary>	
        [EnumValue("NotPrinted", typeof(EnumerationsResx))]
        Notprinted = 0,

        /// <summary>
        /// Gets or sets Printed 
        /// </summary>	
        [EnumValue("Printed", typeof(APCommonResx))]
        Printed = 1,
    }
}
