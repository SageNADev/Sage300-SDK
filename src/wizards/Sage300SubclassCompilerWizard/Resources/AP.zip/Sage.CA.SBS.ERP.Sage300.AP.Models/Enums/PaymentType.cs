/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for PaymentType 
    /// </summary>
    public enum PaymentType
    {
        /// <summary>
        /// Gets or sets Cash 
        /// </summary>	
        [EnumValue("Cash", typeof(PaymentCodesResx))]
        Cash = 1,

        /// <summary>
        /// Gets or sets Check 
        /// </summary>	
        [EnumValue("Check", typeof(PaymentCodesResx))]
        Check = 2,

        /// <summary>
        /// Gets or sets CreditCard 
        /// </summary>	
        [EnumValue("CreditCard", typeof(PaymentCodesResx))]
        CreditCard = 3,

        /// <summary>
        /// Gets or sets Other 
        /// </summary>	
        [EnumValue("Other", typeof(PaymentCodesResx))]
        Other = 4
    }
}
