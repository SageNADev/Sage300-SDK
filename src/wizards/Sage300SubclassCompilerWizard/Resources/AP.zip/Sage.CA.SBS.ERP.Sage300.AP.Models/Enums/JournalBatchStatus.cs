﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum JournalBatchStatus
    /// </summary>
    public enum JournalBatchStatus
    {
        /// <summary>
        /// The open
        /// </summary>
        [EnumValue("JournalBatchStatus_Open", typeof (EnumerationsResx))] Open = 1,

        /// <summary>
        /// The deleted
        /// </summary>
        [EnumValue("JournalBatchStatus_Deleted", typeof (EnumerationsResx))] Deleted = 3,

        /// <summary>
        /// The posted
        /// </summary>
        [EnumValue("JournalBatchStatus_Posted", typeof (EnumerationsResx))] Posted = 4,

        /// <summary>
        /// The prov posted
        /// </summary>
        [EnumValue("JournalBatchStatus_ProvPosted", typeof (EnumerationsResx))] ProvPosted = 6,

        /// <summary>
        /// The post in progress
        /// </summary>
        [EnumValue("JournalBatchStatus_PostInProgress", typeof (EnumerationsResx))] PostInProgress = 8,

        /// <summary>
        /// The ready to post
        /// </summary>
        [EnumValue("JournalBatchStatus_ReadyToPost", typeof (EnumerationsResx))] ReadyToPost = 9,

        /// <summary>
        /// The prov post in progress
        /// </summary>
        [EnumValue("JournalBatchStatus_ProvPostInProgress", typeof (EnumerationsResx))] ProvPostInProgress = 65,
    }
}