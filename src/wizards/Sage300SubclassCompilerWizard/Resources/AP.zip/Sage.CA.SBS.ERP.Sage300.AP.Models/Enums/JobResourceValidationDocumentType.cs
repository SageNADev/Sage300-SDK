// Copyright (c) 2019-2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for DocumentType
    /// </summary>
    public enum JobResourceValidationDocumentType
    {
        /// <summary>
        /// Invoice Document
        /// </summary>
        Invoice = 1,

		/// <summary>
		/// Debit Note Document
		/// </summary>
		DebitNote = 2,

		/// <summary>
		/// Credit Note Document
		/// </summary>
		CreditNote = 3,

        /// <summary>
        /// Interest Document
        /// </summary>
        Interest = 4,

        /// <summary>
        /// Payment Document
        /// </summary>
        Payment = 5,

        /// <summary>
        /// Prepayment Document
        /// </summary>
        Prepayment = 6,

        /// <summary>
        /// Apply Document Document
        /// </summary>
        ApplyDocument = 7,

		/// <summary>
		/// Miscellaneous Payment Document
		/// </summary>
		MiscPayment = 8,

        /// <summary>
        /// Adjustment Document
        /// </summary>
        Adjustment = 9,
    }
}
