
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for DocumentType 
    /// </summary>
    public enum DocumentPaymentDocumentType
    {
        /// <summary>
        /// Gets or sets DebitNoteAppliedTo 
        /// </summary>	
        [EnumValue("DebitNoteAppliedTo", typeof(EnumerationsResx))]
        DebitNoteAppliedTo = 6,

        /// <summary>
        /// Gets or sets AppliedDebitNote 
        /// </summary>	
        [EnumValue("AppliedDebitNote", typeof(EnumerationsResx))]
        AppliedDebitNote = 7,

        /// <summary>
        /// Gets or sets CreditNoteAppliedTo 
        /// </summary>	
        [EnumValue("CreditNoteAppliedTo", typeof(EnumerationsResx))]
        CreditNoteAppliedTo = 8,

        /// <summary>
        /// Gets or sets AppliedCreditNote 
        /// </summary>	
        [EnumValue("AppliedCreditNote", typeof(EnumerationsResx))]
        AppliedCreditNote = 9,

        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>	
        [EnumValue("Prepayment", typeof(APCommonResx))]
        Prepayment = 10,

        /// <summary>
        /// Gets or sets Payment 
        /// </summary>	
        [EnumValue("Payment", typeof(APCommonResx))]
        Payment = 11,

        /// <summary>
        /// Gets or sets Discount 
        /// </summary>
        [EnumValue("Discount", typeof(APCommonResx))]
        Discount = 12,

        /// <summary>
        /// Gets or sets Adjustment 
        /// </summary>	
        [EnumValue("Adjustment", typeof(APCommonResx))]
        Adjustment = 14,

        /// <summary>
        /// Gets or sets ExchangeGainOrLoss 
        /// </summary>
        [EnumValue("ExchangeGainOrLoss", typeof(PaymentInquiryResx))]
        ExchangeGainOrLoss = 16,

        /// <summary>
        /// Gets or sets Rounding 
        /// </summary>	
        [EnumValue("Rounding", typeof(APCommonResx))]
        Rounding = 17,

        /// <summary>
        /// Gets or sets Retainage 
        /// </summary>	
        [EnumValue("Retainage", typeof(APCommonResx))]
        Retainage = 18,

        /// <summary>
        /// Gets or sets Retainage 
        /// </summary>	
        [EnumValue("TaxWithheld", typeof(Common.Resources.TaxesResx))]
        TaxWithheld = 19
    }
}
