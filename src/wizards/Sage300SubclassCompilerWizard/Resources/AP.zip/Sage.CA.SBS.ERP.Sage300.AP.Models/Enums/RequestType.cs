 
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for RequestType 
    /// </summary>
	public enum RequestType 
	{
			/// <summary>
		/// Gets or sets CreatePaymentRegister 
		/// </summary>	
        CreatePaymentRegister = 1,
		/// <summary>
		/// Gets or sets CreateBatch 
		/// </summary>	
        CreateBatch = 2,
		/// <summary>
		/// Gets or sets DeletePaymentRegister 
		/// </summary>	
        DeletePaymentRegister = 3,
		/// <summary>
		/// Gets or sets CreateSystemSelectionCriteria 
		/// </summary>	
        CreateSystemSelectionCriteria = 4,
	}
}
