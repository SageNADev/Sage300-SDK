
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Name Spaces 

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enumeration for Tax Reporting Type 
    /// </summary>
    public enum VendorGroupTaxReportingType 
	{		
        /// <summary>
        /// Value for None 
        /// </summary>
        [EnumValue("None", typeof(CommonResx))]
        None = 0,

        /// <summary>
        /// Value for Num1099 
        /// </summary>	
        [EnumValue("Num1099", typeof(APCommonResx))]
        Num1099 = 1,

        /// <summary>
        /// Value for CPRS 
        /// </summary>	
        [EnumValue("CPRS", typeof(APCommonResx))]
        CPRS = 2,
	}
}
