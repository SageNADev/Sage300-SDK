// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for DefaultDetailTaxClass 
    /// </summary>
    public enum DefaultDetailTaxClass
    {
        /// <summary>
        /// Gets or sets DefaulttoVendorTaxClass 
        /// </summary>	
        DefaulttoVendorTaxClass = 0,

        /// <summary>
        /// Gets or sets Defaultto1 
        /// </summary>	
        Defaultto1 = 1,
    }
}
