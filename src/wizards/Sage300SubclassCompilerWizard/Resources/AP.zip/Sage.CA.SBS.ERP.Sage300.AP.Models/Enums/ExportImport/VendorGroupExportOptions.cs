﻿
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.ExportImport
{
    public enum VendorGroupExportOptions
    {
        [EnumValue("GroupInformation", typeof(VendorGroupResx))]
          GroupInformation =1,
         [EnumValue("Statistics", typeof(APCommonResx))]
        Statistics =2
    }
}
