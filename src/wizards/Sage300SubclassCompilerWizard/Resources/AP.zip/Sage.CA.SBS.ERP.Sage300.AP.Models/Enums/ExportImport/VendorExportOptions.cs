﻿
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.ExportImport
{
    public enum VendorExportOptions
    {
       [EnumValue("Vendor", typeof(VendorResx))]
       Vendor =1,

       [EnumValue("Statistics", typeof(VendorResx))]
       Statistics =2,

       [EnumValue("Comments", typeof(VendorResx))]
       Comments = 3,
    }
}
