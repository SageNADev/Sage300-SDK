/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for DuplicateAmountCode 
    /// </summary>
	public enum DuplicateAmountCode 
	{
		/// <summary>
		/// Gets or sets None 
		/// </summary>	
        [EnumValue("None", typeof(EnumerationsResx))]
        None = 0,

		/// <summary>
		/// Gets or sets Warning 
		/// </summary>	
        [EnumValue("Warning", typeof(EnumerationsResx))]
        Warning = 1,

        /// <summary>
		/// Gets or sets Error 
		/// </summary>	
        [EnumValue("Error", typeof(EnumerationsResx))]
        Error = 2,
	}
}
