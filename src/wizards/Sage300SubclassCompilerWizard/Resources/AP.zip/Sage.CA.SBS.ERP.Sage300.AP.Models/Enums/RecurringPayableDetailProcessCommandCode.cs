﻿//  Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Process Command Codes for AP Recurring Payables detail grid
    /// </summary>
    public enum RecurringPayableDetailProcessCommandCode
    {
        /// <summary>
        /// Insert Optional Fields command code
        /// </summary>	
        InsertOptionalFields = 0
    }
}
