﻿
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Name spaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enumeration for Zero 1099 Amount Warning 
    /// </summary>
    public enum Zero1099AmountWarning
    {
        /// <summary>
        /// value for None 
        /// </summary>	
        [EnumValue("None", typeof(APCommonResx))]
        None = 0,

        /// <summary>
        /// Value for Warning 
        /// </summary>	
        [EnumValue("Warning", typeof(CommonResx))]
        Warning = 1,
    }
}
