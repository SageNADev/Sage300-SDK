/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for MethodofCalcforDiscountDate 
    /// </summary>
    public enum MethodofCalcforDiscountDate
    {
        /// <summary>
        /// Gets or sets DaysFromInvoiceDate 
        /// </summary>	
        [EnumValue("DaysFromInvoiceDate", typeof (EnumerationsResx))] DaysFromInvoiceDate = 1,

        /// <summary>
        /// Gets or sets EndofNextMonth 
        /// </summary>	
        [EnumValue("EndofNextMonth", typeof (EnumerationsResx))] EndofNextMonth = 2,

        /// <summary>
        /// Gets or sets DayofNextMonth 
        /// </summary>	
        [EnumValue("DayofNextMonth", typeof (EnumerationsResx))] DayofNextMonth = 3,

        /// <summary>
        /// Gets or sets DaysfromDayofNextMonth 
        /// </summary>	
        [EnumValue("DaysFromDayofNextMonth", typeof (EnumerationsResx))] DaysfromDayofNextMonth = 4,

        /// <summary>
        /// Gets or sets DiscDateTable 
        /// </summary>	
        [EnumValue("DiscountDateTable", typeof (EnumerationsResx))] DiscDateTable = 5,

    }
}
