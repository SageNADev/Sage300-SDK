// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Request 
    /// </summary>
    public enum Request
    {
        /// <summary>
        /// Gets or sets SingleCheckProcess 
        /// </summary>	
        SingleCheckProcess = 1,

        /// <summary>
        /// Gets or sets BatchProcess 
        /// </summary>	
        BatchProcess = 2,

        /// <summary>
        /// Gets or sets UpdateStatus 
        /// </summary>	
        UpdateStatus = 3,

        /// <summary>
        /// Gets or sets SetBatchNumber 
        /// </summary>	
        SetBatchNumber = 4,
    }
}
