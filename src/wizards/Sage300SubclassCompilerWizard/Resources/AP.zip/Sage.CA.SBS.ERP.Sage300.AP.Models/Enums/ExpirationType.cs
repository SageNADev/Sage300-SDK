// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for Expiration Type 
    /// </summary>
	public enum ExpirationType 
	{
		/// <summary>
        /// Gets or sets No Expiration 
        /// </summary>
        [EnumValue("NoExpiration", typeof(RecurringPayableResx))]
        NoExpiration = 0,

        /// <summary>
        /// Gets or sets Specific Date 
        /// </summary>	
        [EnumValue("SpecificDate", typeof(RecurringPayableResx))]
        SpecificDate = 1,

        /// <summary>
        /// Gets or sets Maximum Amount 
        /// </summary>	
        [EnumValue("MaximumAmount", typeof(RecurringPayableResx))]
        MaximumAmount = 2,

        /// <summary>
        /// Gets or sets Number of Invoices 
        /// </summary>	
        [EnumValue("NumberofInvoices", typeof(RecurringPayableResx))]
        NumberofInvoices = 3,
	}
}
