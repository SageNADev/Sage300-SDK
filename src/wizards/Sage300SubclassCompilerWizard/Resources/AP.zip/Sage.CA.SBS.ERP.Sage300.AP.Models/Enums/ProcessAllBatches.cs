// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for ProcessAllBatches 
    /// </summary>
    public enum ProcessAllBatches
    {
        /// <summary>
        /// Gets or sets Donotpostallbatches 
        /// </summary>	
        Donotpostallbatches = 0,

        /// <summary>
        /// Gets or sets Postallbatches 
        /// </summary>	
        Postallbatches = 1,
    }
}
