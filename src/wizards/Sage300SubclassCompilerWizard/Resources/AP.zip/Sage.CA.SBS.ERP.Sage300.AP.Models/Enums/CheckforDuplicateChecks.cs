// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for CheckforDuplicateChecks 
    /// </summary>
    public enum CheckforDuplicateChecks
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof(CommonResx), 0)]
        None = 0,

        /// <summary>
        /// Gets or sets Warning 
        /// </summary>	
        [EnumValue("Warning", typeof(CommonResx), 1)]
        Warning = 1,

        /// <summary>
        /// Gets or sets Error 
        /// </summary>	
        [EnumValue("Error", typeof(CommonResx), 2)]
        Error = 2,
    }
}
