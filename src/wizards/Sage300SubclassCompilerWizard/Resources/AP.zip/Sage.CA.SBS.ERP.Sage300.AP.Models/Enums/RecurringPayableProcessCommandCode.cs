﻿//  Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Process Command Codes for AP Recurring Payables screen
    /// </summary>
    public enum RecurringPayableProcessCommandCode
    {
        /// <summary>
        /// Insert Optional Fields command code
        /// </summary>	
        InsertOptionalFields = 3,

        /// <summary>
        /// Create Distributions command code
        /// </summary>	
        CreateDistributions = 0,

        /// <summary>
        /// Generate Vendor command code
        /// </summary>	
        GenerateVendorDistribution = 6
    }
}
