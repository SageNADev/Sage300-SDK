 
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for ProcessType 
    /// </summary>
	public enum ProcessType 
	{
			/// <summary>
		/// Gets or sets Select 
		/// </summary>	
        Select = 1,
	}
}
