﻿
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enumeration for Vendor Currency Type
    /// </summary>
    public enum VendorCurrencyType
    {
        /// <summary>
        ///  Vendor 
        /// </summary>
        [EnumValue("Vendor", typeof(APCommonResx))]
        Vendor = 0,

        /// <summary>
        /// Functional 
        /// </summary>
        [EnumValue("Functional", typeof(APCommonResx))]
        Functional = 1
    }
}
