﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommandCode 
    /// </summary>
    public enum PaymentAdjProcessCommandCode
    {
        InsertOptionalFields = 0,
        CalculateTaxes = 1,
        DistributeTaxes = 2,
        DeriveTaxReportingExchangeRate = 3,
        VoidCheck = 4,
        GenerateVendorDistribution = 5
    }
}
