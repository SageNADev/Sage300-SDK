// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enumeration for DeliveryMethod 
    /// </summary>
    public enum DeliveryMethod
    {
        /// <summary>
        /// Gets or sets Mail 
        /// </summary>	
        [EnumValue("Mail", typeof(Common.Resources.EnumerationsResx))]
        Mail = 0,

        /// <summary>
        /// Gets or sets Email 
        /// </summary>	
        [EnumValue("DeliveryMethod_Email", typeof(APCommonResx))]
        Email = 2,

        /// <summary>
        /// Gets or sets ContactsEmail 
        /// </summary>	
        [EnumValue("DeliveryMethod_ContactsEmail", typeof(APCommonResx))]
        ContactsEmail = 4,

        /// <summary>
        /// Gets or sets ContactList
        /// </summary>	
        [EnumValue("DeliveryMethod_ContactList", typeof(APCommonResx))]
        ContactList = 5
    }
}
