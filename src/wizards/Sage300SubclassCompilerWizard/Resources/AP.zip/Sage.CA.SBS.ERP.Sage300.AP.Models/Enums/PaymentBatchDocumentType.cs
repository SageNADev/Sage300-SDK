/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;


namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for Payment Batch List DocumentType 
    /// </summary>
    public enum PaymentBatchDocumentType 
	{
        /// <summary>
		/// Gets or sets None 
		/// </summary>	
        [EnumValue("None", typeof(APCommonResx))]
        None = 1,

        /// <summary>
		/// Gets or sets DocumentNumber 
		/// </summary>	
        [EnumValue("DocumentNumber", typeof(APCommonResx))]
        DocumentNumber = 2,

        /// <summary>
		/// Gets or sets PONumber 
		/// </summary>	
        [EnumValue("PONumber", typeof(APCommonResx))]
        PONumber = 3,

        /// <summary>
		/// Gets or sets OrderNumber 
		/// </summary>	
        [EnumValue("OrderNumber", typeof(APCommonResx))]
        OrderNumber = 4,

        /// <summary>
		/// Gets or sets Prepayment 
		/// </summary>
        [EnumValue("Prepayment", typeof(APCommonResx))]	
        Prepayment = 5,

        /// <summary>
		/// Gets or sets CreditNote 
		/// </summary>	
        [EnumValue("CreditNote", typeof(APCommonResx))]
        CreditNote = 7,
	}
}
