﻿//geetha changes start----------------------------------------------------------

/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using RecurringPayableResx = Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms.RecurringPayableResx;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum InvoiceDateType
    {
        /// <summary>
        /// Gets or sets NextScheduled 
        /// </summary>	
        [EnumValue("NextScheduled", typeof(RecurringPayableResx))] 
        NextScheduled = 0,

        /// <summary>
        /// Gets or sets Other 
        /// </summary>	
        [EnumValue("Other", typeof(RecurringPayableResx))] 
        Other = 1,
    }
}

//geetha changes end----------------------------------------------------------
