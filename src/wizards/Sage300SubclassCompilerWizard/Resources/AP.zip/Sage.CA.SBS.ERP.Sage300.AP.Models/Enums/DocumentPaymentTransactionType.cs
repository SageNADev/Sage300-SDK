/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType 
    /// </summary>
    public enum DocumentPaymentTransactionType
    {
        /// <summary>
        /// Gets or sets DebitNoteAppliedTo 
        /// </summary>
        [EnumValue("DebitNoteAppliedTo", typeof(AP.Resources.EnumerationsResx))]
        DebitNoteAppliedTo = 41,

        /// <summary>
        /// Gets or sets AppliedDebitNote 
        /// </summary>
        [EnumValue("AppliedDebitNote", typeof(AP.Resources.EnumerationsResx))]
        AppliedDebitNote = 42,

        /// <summary>
        /// Gets or sets CreditNoteAppliedTo 
        /// </summary>
        [EnumValue("CreditNoteAppliedTo", typeof(AP.Resources.EnumerationsResx))]
        CreditNoteAppliedTo = 43,

        /// <summary>
        /// Gets or sets AppliedCreditNote 
        /// </summary>
        [EnumValue("AppliedCreditNote", typeof(AP.Resources.EnumerationsResx))]
        AppliedCreditNote = 44,

        /// <summary>
        /// Gets or sets PrepaymentApplied 
        /// </summary>
        [EnumValue("PrepaymentApplied", typeof(PaymentInquiryResx))]
        PrepaymentApplied = 58,

        /// <summary>
        /// Gets or sets PrepaymentReversed 
        /// </summary>
        [EnumValue("DocumentType_PrepaymentReversed", typeof(AP.Resources.EnumerationsResx))]
        PrepaymentReversed = 59,

        /// <summary>
        /// Gets or sets PaymentPosted 
        /// </summary>
        [EnumValue("PaymentPosted", typeof(PaymentInquiryResx))]
        PaymentPosted = 51,

        /// <summary>
        /// Gets or sets PaymentApplied 
        /// </summary>
        [EnumValue("PaymentApplied", typeof(AP.Resources.EnumerationsResx))]
        PaymentApplied = 52,

        /// <summary>
        /// Gets or sets PaymentReversed 
        /// </summary>
        [EnumValue("PaymentReversed", typeof(PaymentInquiryResx))]
        PaymentReversed = 53,

        /// <summary>
        /// Gets or sets DiscountPosted 
        /// </summary>
        [EnumValue("DiscountPosted", typeof(PaymentInquiryResx))]
        DiscountPosted = 61,

        /// <summary>
        /// Gets or sets DiscountReversed 
        /// </summary>
        [EnumValue("DiscountReversed", typeof(PaymentInquiryResx))]
        DiscountReversed = 63,

        /// <summary>
        /// Gets or sets AdjustmentPosted 
        /// </summary>
        [EnumValue("AdjustmentPosted", typeof(PaymentInquiryResx))]
        AdjustmentPosted = 81,

        /// <summary>
        /// Gets or sets AdjustmentReversed 
        /// </summary>
        [EnumValue("AdjustmentReversed", typeof(PaymentInquiryResx))]
        AdjustmentReversed = 83,

        /// <summary>
        /// Gets or sets ExchangeGainOrLossPosted 
        /// </summary>
        [EnumValue("ExchangeGainOrLossPosted", typeof(PaymentInquiryResx))]
        ExchangeGainOrLossPosted = 65,

        /// <summary>
        /// Gets or sets ExchangeGainOrLossReversed 
        /// </summary>
        [EnumValue("ExchangeGainOrLossReversed", typeof(PaymentInquiryResx))]
        ExchangeGainOrLossReversed = 67,

        /// <summary>
        /// Gets or sets RoundingPosted 
        /// </summary>
        [EnumValue("RoundingPosted", typeof(PaymentInquiryResx))]
        RoundingPosted = 91,

        /// <summary>
        /// Gets or sets RoundingReversed 
        /// </summary>
        [EnumValue("RoundingReversed", typeof(PaymentInquiryResx))]
        RoundingReversed = 93,

        /// <summary>
        /// Gets or sets UnrealizedExchangeGainOrLoss 
        /// </summary>
        [EnumValue("UnrealizedExchangeGainOrLoss", typeof(AP.Resources.EnumerationsResx))]
        UnrealizedExchangeGainOrLoss = 69,

        /// <summary>
        /// Gets or sets RetainageInvoiced 
        /// </summary>
        [EnumValue("RetainageInvoice", typeof(AP.Resources.APCommonResx))]
        RetainageInvoiced = 100,

        /// <summary>
        /// Gets or sets RetainageAdjusted 
        /// </summary>
        [EnumValue("RetainageAdjusted", typeof(PaymentInquiryResx))]
        RetainageAdjusted = 101,

        /// <summary>
        /// Gets or sets RetainageRevalued 
        /// </summary>
        RetainageRevalued = 102,

        /// <summary>
        /// Gets or sets RetainageExchangeGainOrLoss 
        /// </summary>
        RetainageExchangeGainOrLoss = 103,

        /// <summary>
        /// Gets or sets RetainageRounding 
        /// </summary>
        [EnumValue("RetainageRounding", typeof(AP.Resources.EnumerationsResx))]
        RetainageRounding = 104,

        /// <summary>
        /// Gets or sets PaymentInvoiceReversed 
        /// </summary>
        [EnumValue("PaymentInvoiceReversed", typeof(PaymentInquiryResx))]
        PaymentInvoiceReversed = 94,

        /// <summary>
        /// Gets or sets PaymentPosted 
        /// </summary>
        [EnumValue("TaxWithheldPosted", typeof(PaymentInquiryResx))]
        TaxWithheldPosted = 105,

        /// <summary>
        /// Gets or sets PaymentPosted 
        /// </summary>
        [EnumValue("TaxWithheldReversed", typeof(PaymentInquiryResx))]
        TaxWithheldReversed = 106
    }
}
