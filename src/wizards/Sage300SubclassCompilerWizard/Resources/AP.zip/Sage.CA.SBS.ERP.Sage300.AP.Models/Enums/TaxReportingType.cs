// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enumeration for Tax Reporting Type 
    /// </summary>
    public enum TaxReportingType
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof(APCommonResx))]
        None = 0,

        /// <summary>
        /// Gets or sets Num1099 
        /// </summary>	
        [EnumValue("Num1099", typeof(APCommonResx))]
        Num1099 = 1,

        /// <summary>
        /// Gets or sets CPRS 
        /// </summary>	
        [EnumValue("CPRS", typeof(APCommonResx))]
        CPRS = 2,
    }
}
