// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Default Transaction Type 
    /// </summary>
    public enum DefaultTransactionType
    {
        /// <summary>
        /// Gets or sets Payment 
        /// </summary>	
        [EnumValue("Payment", typeof(APCommonResx), 0)]
        Payment = 1,

        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>	
        [EnumValue("Prepayment", typeof(APCommonResx), 1)]
        Prepayment = 2,

        /// <summary>
        /// Gets or sets Apply Document 
        /// </summary>	
        [EnumValue("ApplyDocument", typeof(APCommonResx), 2)]
        ApplyDocument = 3,

        /// <summary>
        /// Gets or sets Miscellaneous Payment 
        /// </summary>	
        [EnumValue("MiscPayment", typeof(APCommonResx), 3)]
        MiscPayment = 4,
    }
}
