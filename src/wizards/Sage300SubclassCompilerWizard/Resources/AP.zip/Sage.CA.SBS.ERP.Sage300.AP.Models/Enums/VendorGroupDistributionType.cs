
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Name Spaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enumeration for Distribution Type 
    /// </summary>
    public enum VendorGroupDistributionType
    {
        /// <summary>
        /// Value for Distribution Set 
        /// </summary>
        [EnumValue("DistributionSet", typeof(APCommonResx))]
        DistributionSet = 0,

        /// <summary>
        /// Value for Distribution Code 
        /// </summary>	
        [EnumValue("DistributionCode", typeof(APCommonResx))]
        DistributionCode = 1,

        /// <summary>
        /// Value for GL Account 
        /// </summary>	
        [EnumValue("GLAccount", typeof(APCommonResx))]
        GLAccount = 2,

        /// <summary>
        /// Value for None 
        /// </summary>	
        [EnumValue("None", typeof(CommonResx))]
        None = 3
    }
}
