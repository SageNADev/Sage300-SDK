
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for OnHold 
    /// </summary>
	public enum OnHold 
	{
			/// <summary>
		/// Gets or sets NotOnHold 
		/// </summary>	
        [EnumValue("NotOnHold", typeof(EnumerationsResx))] 
        NotOnHold = 0,
		/// <summary>
		/// Gets or sets OnHold 
		/// </summary>	
        [EnumValue("OnHold", typeof(EnumerationsResx))] 
        OnHold = 1,
	}
}
