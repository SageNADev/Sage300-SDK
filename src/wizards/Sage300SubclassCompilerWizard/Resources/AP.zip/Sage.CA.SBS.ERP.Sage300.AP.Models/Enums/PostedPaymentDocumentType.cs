/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for DocumentType 
    /// </summary>
    
    public enum PostedPaymentDocumentType
    {
        /// <summary>
        /// Gets or sets UnappliedCash 
        /// </summary>	
        [EnumValue("UnappliedCash", typeof(APCommonResx))]
        UnappliedCash = 5,

        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>	
        [EnumValue("Prepayment", typeof(APCommonResx))]
        Prepayment = 10,

        /// <summary>
        /// Gets or sets Payment 
        /// </summary>	
        [EnumValue("Payment", typeof(APCommonResx))]
        Payment = 11
    }
}
