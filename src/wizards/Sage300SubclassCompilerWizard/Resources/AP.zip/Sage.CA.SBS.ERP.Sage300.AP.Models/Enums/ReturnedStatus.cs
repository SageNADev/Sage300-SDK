// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    ///<summary>
    /// Enum for ReturnedStatus 
    /// </summary>
    public enum ReturnedStatus
    {
        /// <summary>
        /// Gets or sets Successful 
        /// </summary>	
        Successful = 0,

        /// <summary>
        /// Gets or sets Aborted 
        /// </summary>	
        Aborted = 1,

        /// <summary>
        /// Gets or sets Suspended 
        /// </summary>	
        Suspended = 2,

        /// <summary>
        /// Gets or sets the Default value for Print Check
        /// </summary>
        None = 99,
    }
}
