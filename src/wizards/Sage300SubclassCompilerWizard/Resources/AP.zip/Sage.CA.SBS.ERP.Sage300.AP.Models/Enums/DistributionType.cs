// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enumeration for DistributionType 
    /// </summary>
    public enum DistributionType
    {
        /// <summary>
        /// Gets or sets Distribution Set 
        /// </summary>	
        [EnumValue("DistributionSet", typeof(APCommonResx))]
        DistributionSet = 0,

        /// <summary>
        /// Gets or sets Distribution Code 
        /// </summary>	
        [EnumValue("DistributionCode", typeof(APCommonResx))]
        DistributionCode = 1,

        /// <summary>
        /// Gets or sets GL Account 
        /// </summary>	
        [EnumValue("GLAccount", typeof(APCommonResx))]
        GLAccount = 2,

        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof(APCommonResx))]
        None = 3,
    }
}
