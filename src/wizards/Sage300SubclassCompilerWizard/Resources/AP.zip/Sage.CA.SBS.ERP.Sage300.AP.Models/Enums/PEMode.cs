 
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for Mode 
    /// </summary>
    public enum PEMode 
	{
			/// <summary>
		/// Gets or sets Select 
		/// </summary>	
        Select = 0,
		/// <summary>
		/// Gets or sets Direct 
		/// </summary>	
        Direct = 1,
	}
}
