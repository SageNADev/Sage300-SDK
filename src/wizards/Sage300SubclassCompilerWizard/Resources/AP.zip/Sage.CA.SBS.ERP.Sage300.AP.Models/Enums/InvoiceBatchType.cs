﻿//geetha changes start----------------------------------------------------------

/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using RecurringPayableResx = Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms.RecurringPayableResx;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for InvoiceBatchType 
    /// </summary>
    public enum InvoiceBatchType
    {

        /// <summary>
        /// Gets or sets CreateaNewBatch 
        /// </summary>	
        [EnumValue("CreateaNewBatch", typeof(RecurringPayableResx))]
        CreateaNewBatch = 0,

        /// <summary>
        /// Gets or sets AddToAnExistingBatch 
        /// </summary>	
        [EnumValue("AddToAnExistingBatch", typeof(RecurringPayableResx))]
        AddToAnExistingBatch = 1,
    }
}

//geetha changes end----------------------------------------------------------

