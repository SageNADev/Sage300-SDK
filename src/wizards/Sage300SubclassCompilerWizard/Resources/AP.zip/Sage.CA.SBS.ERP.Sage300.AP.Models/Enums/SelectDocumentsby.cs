/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Select Documents by 
    /// </summary>
    public enum SelectDocumentsby
    {
        /// <summary>
        /// Gets or sets Due Date 
        /// </summary>	
        [EnumValue("SelectDocumentsby_DueDate", typeof(EnumerationsResx))]
        DueDate = 0,

        /// <summary>
        /// Gets or sets Discount Date 
        /// </summary>	
        [EnumValue("SelectDocumentsby_DiscountDate", typeof(EnumerationsResx))]
        DiscountDate = 1,

        /// <summary>
        /// Gets or sets Due Date or Discount Date 
        /// </summary>	
        [EnumValue("SelectDocumentsby_DueDateorDiscountDate", typeof(EnumerationsResx))]
        DueDateorDiscountDate = 2
    }
}