﻿
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommandCode 
    /// </summary>
    public enum ProcessCommandRecurring
    {

        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>	
        [EnumValue("CreateDistributions", typeof(RecurringPayableResx))]
        CreateDistributions = 0,

        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>	
        [EnumValue("CalculateTaxes", typeof(RecurringPayableResx))]
        CalculateTaxes = 1,

        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>	
        [EnumValue("DistributeTaxes", typeof(RecurringPayableResx))]
        DistributeTaxes = 2,

        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>	
        [EnumValue("InsertOptionalFields", typeof(RecurringPayableResx))]
        InsertOptionalFields = 3,

        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>	
        [EnumValue("GenerateVendorDistribution", typeof(RecurringPayableResx))]
        GenerateVendorDistribution = 6,
    }
}
