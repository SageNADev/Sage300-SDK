 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for CommissionsPaid 
    /// </summary>
    public enum CommissionsPaid
    {
        /// <summary>
        /// Gets or sets No 
        /// </summary>	
        No = 0,

        /// <summary>
        /// Gets or sets Yes 
        /// </summary>	
        Yes = 1,
    }
}
