// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Sort Checks By 
    /// </summary>
    public enum SortChecksBy
    {
        /// <summary>
        /// Gets or sets Transaction Entry Number 
        /// </summary>	
        [EnumValue("SortChecksBy_TransactionEntryNumber", typeof(EnumerationsResx), 0)]
        TransactionEntryNumber = 0,

        /// <summary>
        /// Gets or sets Vendor Number 
        /// </summary>	
        [EnumValue("VendorNumber", typeof(APCommonResx), 1)]
        VendorNumber = 1,

        /// <summary>
        /// Gets or sets Payee Name 
        /// </summary>	
        [EnumValue("SortChecksBy_PayeeName", typeof(EnumerationsResx), 2)]
        PayeeName = 2,

        /// <summary>
        /// Gets or sets Payee Country 
        /// </summary>	
        [EnumValue("SortChecksBy_PayeeCountry", typeof(EnumerationsResx), 3)]
        PayeeCountry = 3,

        /// <summary>
        /// Gets or sets Payee ZIP/Postal Code 
        /// </summary>	
        [EnumValue("SortChecksBy_PayeeZipOrPostalCode", typeof(EnumerationsResx), 4)]
        PayeeZipOrPostalCode = 4,
    }
}
