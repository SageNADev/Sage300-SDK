 
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
	/// <summary>
    /// Enum for CheckPrintedStatus 
    /// </summary>
	public enum CheckPrintedStatus 
	{
			/// <summary>
		/// Gets or sets Notprinted 
		/// </summary>	
        Notprinted = 0,
		/// <summary>
		/// Gets or sets Printed 
		/// </summary>	
        Printed = 1,
	}
}
