// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using EnumerationsResx = Sage.CA.SBS.ERP.Sage300.AP.Resources.EnumerationsResx;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Enums
{
    /// <summary>
    /// Enum for Include Pending Transactions 
    /// </summary>
    public enum IncludePendingTransactions
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof(CommonResx), 0)]
        None = 0,

        /// <summary>
        /// Gets or sets Payments 
        /// </summary>	
        [EnumValue("Payment", typeof(APCommonResx), 1)]
        Payments = 1,

        /// <summary>
        /// Gets or sets Payments and Adjustments 
        /// </summary>	
        [EnumValue("IncludePendingTransactions_PaymentsandAdjustments", typeof(EnumerationsResx), 2)]
        PaymentsandAdjustments = 2,

        /// <summary>
        /// Gets or sets All Transactions 
        /// </summary>	
        [EnumValue("AllTransactions", typeof(EnumerationsResx), 3)]
        AllTransactions = 3,
    }
}
