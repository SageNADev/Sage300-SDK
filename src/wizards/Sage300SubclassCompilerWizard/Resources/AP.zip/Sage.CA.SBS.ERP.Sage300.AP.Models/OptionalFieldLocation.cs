// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    ///  Header model class for AP OptionalField
    /// </summary>
    public partial class OptionalFieldLocation : ModelBase
    {
        /// <summary>
        ///  Constructor for OptionalFieldLocation
        /// </summary>
        public OptionalFieldLocation()
        {
            OptionalFieldDetails = new EnumerableResponse<OptionalFieldDetail>();
        }

        /// <summary>
        /// Gets or sets Location 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "Location", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Location Location { get; set; }

        /// <summary>
        /// Gets or sets NumberofValues 
        /// </summary>
        [Display(Name = "NumberofValues", ResourceType = typeof (OptionalFieldsResx))]
        [ViewField(Name = Fields.NumberofValues, Id = Index.NumberofValues, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofValues { get; set; }

        /// <summary>
        /// Optional Field details list
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<OptionalFieldDetail> OptionalFieldDetails { get; set; }
    }
}
