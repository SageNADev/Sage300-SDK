// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using System;
using System.ComponentModel.DataAnnotations;
using Type = Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Type;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class CreatePaymentBatch
    /// </summary>
    public partial class CreatePaymentBatch : ModelBase
    {

        #region Constant

        /// <summary>
        /// The constant z small
        /// </summary>
        private const char Z = 'Z';

        /// <summary>
        /// Vendor Group Length
        /// </summary>
        private const int LenVendorGrp = 6;

        /// <summary>
        /// Vendor Group Length
        /// </summary>
        private const int LenVendorNum = 12;

        /// <summary>
        /// Account Set Length
        /// </summary>
        private const int LenAccountSet = 6;

        /// <summary>
        /// Payment Code Length
        /// </summary>
        private const int LenPaymentCode = 12;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor CreatePaymentBatch
        /// </summary>
        public CreatePaymentBatch()
        {
            CreatePaymentBatchOptionalField = new EnumerableResponse<CreatePaymentBatchOptionalField>();
            CreatePaymentBatchDetail = new EnumerableResponse<CreatePaymentBatchDetail>();
            ThruGroupCode = CommonUtil.Repeat(Z, LenVendorGrp);
            ThruVendorNumber = CommonUtil.Repeat(Z, LenVendorNum);
            ThruAccountSet = CommonUtil.Repeat(Z, LenAccountSet);
            ThruPaymentCode = CommonUtil.Repeat(Z, LenPaymentCode);
            IsNewRecord = false;
        }

        #endregion

        /// <summary>
        /// Gets or sets SelectionCriteria 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectionCode", ResourceType = typeof(APCommonResx))]
        [Key]
        [ViewField(Name = Fields.SelectionCriteria, Id = Index.SelectionCriteria, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string SelectionCriteria { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets DocumentstoProcess 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DocumentstoProcess, Id = Index.DocumentstoProcess, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentstoProcess DocumentstoProcess { get; set; }

        /// <summary>
        /// Gets or sets SelectDocumentsby 
        /// </summary>
        [Display(Name = "SelectDocumentsby", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.SelectDocumentsby, Id = Index.SelectDocumentsby, FieldType = EntityFieldType.Int, Size = 2)]
        public SelectDocumentsby SelectDocumentsby { get; set; }

        /// <summary>
        /// Gets or sets DateDue 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DueOnOrBefore", ResourceType = typeof(CreatePaymentBatchResx))]
        [ViewField(Name = Fields.DateDue, Id = Index.DateDue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateDue { get; set; }

        /// <summary>
        /// Gets or sets FromDiscountDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DiscountsAvailableFrom", ResourceType = typeof(CreatePaymentBatchResx))]
        //  [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromDiscountDate, Id = Index.FromDiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? FromDiscountDate { get; set; }

        /// <summary>
        /// Gets or sets FromGroupCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromGroupCode, Id = Index.FromGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FromGroupCode { get; set; }

        /// <summary>
        /// Gets or sets ThruGroupCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ThruGroupCode, Id = Index.ThruGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ThruGroupCode { get; set; }

        /// <summary>
        /// Gets or sets FromVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromVendorNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.FromVendorNumber, Id = Index.FromVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string FromVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets ThruVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToVendorNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ThruVendorNumber, Id = Index.ThruVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ThruVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets FromAccountSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromAccountSet", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.FromAccountSet, Id = Index.FromAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FromAccountSet { get; set; }

        /// <summary>
        /// Gets or sets ThruAccountSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToAccountSet", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ThruAccountSet, Id = Index.ThruAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ThruAccountSet { get; set; }

        /// <summary>
        /// Gets or sets IdBankAsgn 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IdBankAsgn, Id = Index.IdBankAsgn, FieldType = EntityFieldType.Char, Size = 8)]
        public string IdBankAsgn { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorCurrencyCode, Id = Index.VendorCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string VendorCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets PaymentBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentBankCode, Id = Index.PaymentBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string PaymentBankCode { get; set; }

        /// <summary>
        /// Gets or sets BankCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankCurrencyCode, Id = Index.BankCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BankCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets AmtBankLmt 
        /// </summary>
        [ViewField(Name = Fields.AmtBankLmt, Id = Index.AmtBankLmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtBankLmt { get; set; }

        /// <summary>
        /// Gets or sets MinimumPaymentAmount 
        /// </summary>
        [ViewField(Name = Fields.MinimumPaymentAmount, Id = Index.MinimumPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MinimumPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets MaximumPaymentAmount 
        /// </summary>
        [ViewField(Name = Fields.MaximumPaymentAmount, Id = Index.MaximumPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaximumPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets BankMatch 
        /// </summary>
        [ViewField(Name = Fields.BankMatch, Id = Index.BankMatch, FieldType = EntityFieldType.Int, Size = 2)]
        public BankMatch BankMatch { get; set; }

        //TOD: To be moved to view model
        /// <summary>
        /// Discountable Property for UI
        /// </summary>
        public bool BankMatchVal
        {
            get { return BankMatch != BankMatch.Vendorswithanybankcode; }
            set { BankMatch = value ? BankMatch.Vendorswithpaymentbankcodeonly : BankMatch.Vendorswithanybankcode; }
        }

        /// <summary>
        /// Gets or sets PaymentDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PaymentDate, Id = Index.PaymentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PaymentDate { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets VendorRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorRateType, Id = Index.VendorRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string VendorRateType { get; set; }

        /// <summary>
        /// Gets or sets BankRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankRateType, Id = Index.BankRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BankRateType { get; set; }

        /// <summary>
        /// Gets or sets VendorExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.VendorExchangeRate, Id = Index.VendorExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal VendorExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets BankExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.BankExchangeRate, Id = Index.BankExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BankExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets VendorRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorRateDate, Id = Index.VendorRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime VendorRateDate { get; set; }

        /// <summary>
        /// Gets or sets BankRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankRateDate, Id = Index.BankRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BankRateDate { get; set; }

        /// <summary>
        /// Gets or sets CSVFilename 
        /// </summary>
        [ViewField(Name = Fields.CsvFilename, Id = Index.CsvFilename, FieldType = EntityFieldType.Char, Size = 100)]
        public string CsvFilename { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ThruDiscountDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DiscountsAvailableTo", ResourceType = typeof(CreatePaymentBatchResx))]

        [ViewField(Name = Fields.ThruDiscountDate, Id = Index.ThruDiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ThruDiscountDate { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BatchDate { get; set; }

        /// <summary>
        /// Gets or sets VendorRateOperator 
        /// </summary>
        [ViewField(Name = Fields.VendorRateOperator, Id = Index.VendorRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int VendorRateOperator { get; set; }

        /// <summary>
        /// Gets or sets BankRateOperator 
        /// </summary>
        [ViewField(Name = Fields.BankRateOperator, Id = Index.BankRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int BankRateOperator { get; set; }

        /// <summary>
        /// Gets or sets VendorRateOverridden 
        /// </summary>
        [ViewField(Name = Fields.VendorRateOverridden, Id = Index.VendorRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public int VendorRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets BankRateOverridden 
        /// </summary>
        [ViewField(Name = Fields.BankRateOverridden, Id = Index.BankRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public int BankRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets JobApplyMethod 
        /// </summary>
        [ViewField(Name = Fields.JobApplyMethod, Id = Index.JobApplyMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public JobApplyMethod JobApplyMethod { get; set; }

        /// <summary>
        /// Gets or sets GeneratedSelectionCriteria 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GeneratedSelectionCriteria, Id = Index.GeneratedSelectionCriteria, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GeneratedSelectionCriteria { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCodeSelect ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets FromPaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromPaymentCode, Id = Index.FromPaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string FromPaymentCode { get; set; }

        /// <summary>
        /// Gets or sets ThruPaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ThruPaymentCode, Id = Index.ThruPaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string ThruPaymentCode { get; set; }

        /// <summary>
        /// Gets or sets OptionalField 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length 
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals 
        /// </summary>
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets FromOptionalFieldValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromOptionalFieldValue, Id = Index.FromOptionalFieldValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string FromOptionalFieldValue { get; set; }

        /// <summary>
        /// Gets or sets ThruOptionalFieldValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ThruOptionalFieldValue, Id = Index.ThruOptionalFieldValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string ThruOptionalFieldValue { get; set; }

        /// <summary>
        /// To get the string value of the Status property
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets List of CreatePaymentBatch Detail
        /// </summary>
        /// <value>The recurring entries.</value>
        public EnumerableResponse<CreatePaymentBatchDetail> CreatePaymentBatchDetail { get; set; }

        /// <summary>
        ///  Gets or sets List of CreatePaymentBatch OptionalField Detail
        /// </summary>
        public EnumerableResponse<CreatePaymentBatchOptionalField> CreatePaymentBatchOptionalField { get; set; }

        /// <summary>
        /// Gets or sets  GenerateSystemBatch entries
        /// </summary>
        public GenerateSystemBatch GenerateSystemBatch { get; set; }

        /// <summary>
        /// Gets or sets Payment Adjustment Batch 
        /// </summary>
        public PaymentAdjustmentBatch PaymentAdjustmentBatch { get; set; }

        /// <summary>
        /// Gets or sets RequestType 
        /// </summary>
        public RequestType RequestType { get; set; }

        /// <summary>
        /// Gets or sets BatchStatus 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        public PaymentBatchStatus BatchStatus { get; set; }

        /// <summary>
        /// Gets or sets ExcludeVendor 
        /// </summary>
        //[Display(Name = "DueDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ExcludeVendor, Id = Index.ExcludeVendor, FieldType = EntityFieldType.Int, Size = 2)]
        public ExcludeVendor ExcludeVendor { get; set; }

        /// <summary>
        /// Gets or sets ExcludeVendor 
        /// </summary>
        public bool IsVisible { get; set; }

        /// <summary>
        /// Gets or Sets Select3 
        /// </summary>
        public OptionalFieldDescription Select3 { get; set; }

        /// <summary>
        /// Gets or Sets CreatePaymentBatchStatus 
        /// </summary>
        public CreatePaymentBatchStatus CreatePaymentBatchStatus { get; set; }

        #region UI Properties

        /// <summary>
        /// Gets or sets Is New Record
        /// </summary>
        public bool IsNewRecord { get; set; }

        /// <summary>
        ///  Gets or sets CheckWithHeld
        /// </summary>
        public bool CheckWithHeld { get; set; }


        #endregion
    }
}
