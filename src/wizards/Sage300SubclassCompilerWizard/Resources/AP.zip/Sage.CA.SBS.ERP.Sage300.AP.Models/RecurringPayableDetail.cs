// Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for Recurring Payable Detail model.
    /// </summary>
    public partial class RecurringPayableDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(RecurringPayableResx))]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets RecurringPayableCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecurringPayableCode", ResourceType = typeof(RecurringPayableResx))]
        [Key]
        [ViewField(Name = Fields.RecurringPayableCode, Id = Index.RecurringPayableCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string RecurringPayableCode { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(APCommonResx))]
        [Key]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [Display(Name = "DistCode", ResourceType = typeof(APCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets DistributionDescription 
        /// </summary>
        [Display(Name = "DistributionDescription", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DistributionDescription, Id = Index.DistributionDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DistributionDescription { get; set; }

        /// <summary>
        /// Gets or sets GLAccount 
        /// </summary>
        [Display(Name = "GLAccount", ResourceType = typeof(APCommonResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets GLAccountDescription 
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string GLAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxInclusive1 
        /// </summary>
        [Display(Name = "TaxInclusive1", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxInclusive1, Id = Index.TaxInclusive1, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxInclusive TaxInclusive1 { get; set; }

        /// <summary>
        /// Gets or sets TaxInclusive2 
        /// </summary>
        [Display(Name = "TaxInclusive2", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxInclusive2, Id = Index.TaxInclusive2, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxInclusive TaxInclusive2 { get; set; }

        /// <summary>
        /// Gets or sets TaxInclusive3 
        /// </summary>
        [Display(Name = "TaxInclusive3", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxInclusive3, Id = Index.TaxInclusive3, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxInclusive TaxInclusive3 { get; set; }

        /// <summary>
        /// Gets or sets TaxInclusive4 
        /// </summary>
        [Display(Name = "TaxInclusive4", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxInclusive4, Id = Index.TaxInclusive4, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxInclusive TaxInclusive4 { get; set; }

        /// <summary>
        /// Gets or sets TaxInclusive5 
        /// </summary>
        [Display(Name = "TaxInclusive5", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxInclusive5, Id = Index.TaxInclusive5, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxInclusive TaxInclusive5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1 
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2 
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3 
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4 
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5 
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets DistributedAmount 
        /// </summary>
        [Display(Name = "DistributedAmount", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.DistributedAmount, Id = Index.DistributedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistributedAmount { get; set; }

        /// <summary>
        /// Gets or sets DistributedAmountBeforeTaxes 
        /// </summary>
        [Display(Name = "DistributedAmountBeforeTaxes", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.DistributedAmountBeforeTaxes, Id = Index.DistributedAmountBeforeTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistributedAmountBeforeTaxes { get; set; }

        /// <summary>
        /// Gets or sets DistTaxincludedinPrice 
        /// </summary>
        [Display(Name = "DistTaxincludedinPrice", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.DistTaxincludedinPrice, Id = Index.DistTaxincludedinPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistTaxincludedinPrice { get; set; }

        /// <summary>
        /// Gets or sets DistTaxexcludedfromPrice 
        /// </summary>
        [Display(Name = "DistTaxexcludedfromPrice", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.DistTaxexcludedfromPrice, Id = Index.DistTaxexcludedfromPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistTaxexcludedfromPrice { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountTotal 
        /// </summary>
        [Display(Name = "TaxAmountTotal", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxAmountTotal, Id = Index.TaxAmountTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1 
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2 
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3 
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4 
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5 
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }
        /// <summary>
        /// Gets or sets EstimatedTaxWithheld Amount1 
        /// </summary>
        [Display(Name = "TaxWithheldAmount1", ResourceType = typeof(InvoiceResx))]
        public decimal TaxWithheldAmount1 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedTaxWithheld Amount2 
        /// </summary>
        [Display(Name = "TaxWithheldAmount2", ResourceType = typeof(InvoiceResx))]
        public decimal TaxWithheldAmount2 { get; set; }
        /// <summary>
        /// Gets or sets EstimatedTaxWithheld Amount3 
        /// </summary>
        [Display(Name = "TaxWithheldAmount3", ResourceType = typeof(InvoiceResx))]
        public decimal TaxWithheldAmount3 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedTaxWithheld Amount4 
        /// </summary>
        [Display(Name = "TaxWithheldAmount4", ResourceType = typeof(InvoiceResx))]
        public decimal TaxWithheldAmount4 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedTaxWithheld Amount5 
        /// </summary>
        [Display(Name = "TaxWithheldAmount5", ResourceType = typeof(InvoiceResx))]
        public decimal TaxWithheldAmount5 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase1
        /// </summary>
        [Display(Name = "CustomerTaxBase1", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase1, Id = Index.CustomerTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase1 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase2
        /// </summary>
        [Display(Name = "CustomerTaxBase2", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase2, Id = Index.CustomerTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase2 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase3
        /// </summary>
        [Display(Name = "CustomerTaxBase3", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase3, Id = Index.CustomerTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase3 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase4
        /// </summary>
        [Display(Name = "CustomerTaxBase4", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase4, Id = Index.CustomerTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase4 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase5
        /// /// </summary>
        [Display(Name = "CustomerTaxBase5", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase5, Id = Index.CustomerTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount1
        /// </summary>
        [Display(Name = "CustomerTaxAmount1", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount1, Id = Index.CustomerTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount1 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTax Amount2
        /// </summary>
        [Display(Name = "CustomerTaxAmount2", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount2, Id = Index.CustomerTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount3
        /// </summary>
        [Display(Name = "CustomerTaxAmount3", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount3, Id = Index.CustomerTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount4
        /// </summary>
        [Display(Name = "CustomerTaxAmount4", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount4, Id = Index.CustomerTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount5
        /// </summary>
        [Display(Name = "CustomerTaxAmount5", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount5, Id = Index.CustomerTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount5 { get; set; }

        /// <summary>
        /// Customer Tax Amount
        /// </summary>
        [Display(Name = "CustomerTaxAmount", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount, Id = Index.CustomerTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount { get; set; }
        /// <summary>
        /// Gets or sets Discountable 
        /// </summary>
        [ViewField(Name = Fields.Discountable, Id = Index.Discountable, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxInclusive Discountable { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets Optional Field String
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(RecurringPayableResx))]
        public string OptionalFieldString { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(RecurringPayableResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public RecurringPayableDetailProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets Comment 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets ContractCode 
        /// </summary>
        [Display(Name = "Contract", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode 
        /// </summary>
        [Display(Name = "Project", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode 
        /// </summary>
        [Display(Name = "Category", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectOrCategoryResource 
        /// </summary>
        [Display(Name = "ProjectOrCategoryResource", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProjectOrCategoryResource, Id = Index.ProjectOrCategoryResource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string ProjectOrCategoryResource { get; set; }

        /// <summary>
        /// Gets or sets CostClass 
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public Common.Models.Enums.InvoiceEntry.CostClass CostClass { get; set; }

        /// <summary>
        /// To Get the Enum string of Cost Class
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(APCommonResx))]
        public string CostClassString { get; set; }

        /// <summary>
        /// Gets or sets BillingType 
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [Display(Name = "ItemNumber", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitofMeasure 
        /// </summary>
        [Display(Name = "UnitofMeasure", ResourceType = typeof(RecurringPayableResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnitofMeasure, Id = Index.UnitofMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitofMeasure { get; set; }

        /// <summary>
        /// Gets or sets Quantity 
        /// </summary>
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets Cost 
        /// </summary>
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets Billing Rate 
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets Billing Currency 
        /// </summary>
        [Display(Name = "BillingCurrency", ResourceType = typeof(APCommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BillingCurrency { get; set; }

        #region UserEntered

        /// <summary>
        /// Gets or Sets Attributes
        /// </summary>
        [IgnoreExportImport]
        public IDictionary<string, object> Attributes { get; set; }

        /// <summary>
        /// Gets or sets Sequence Number
        /// </summary>
        [IgnoreExportImport]
        public int? SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets Detail Tax Group
        /// </summary>
        public List<TaxClassGroup> DetailTaxGroup { get; set; }

        /// <summary>
        /// Invoice sub total
        /// </summary>
        public decimal InvoiceSubTotal { get; set; }

        /// <summary>
        /// Excluded Taxes
        /// </summary>
        public decimal ExcludedTaxes { get; set; }

        /// <summary>
        /// Document Total
        /// </summary>
        public decimal DocumentTotal { get; set; }

        /// <summary>
        /// The list of values for the <see cref="BillingType"/> enumeration
        /// </summary>
        public IEnumerable<CustomSelectList> BillingTypeList { get; set; }

        /// <summary>
        /// Gets or sets UnformattedContractCode
        /// </summary>
        [IgnoreExportImport]
        public string UnformattedContractCode { get; set; }

        /// <summary>
        /// Gets or sets editable state for PJC columns
        /// </summary>
        [IgnoreExportImport]
        public Dictionary<string, bool> PMDisableDictionary { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this detail line's project style is standard.
        /// </summary>
        [IgnoreExportImport]
        public bool IsProjectStyleStandard { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this detail line's project style is basic.
        /// </summary>
        [IgnoreExportImport]
        public bool IsProjectStyleBasic { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this detail line's project type is time and material.
        /// </summary>
        [IgnoreExportImport]
        public bool IsProjectTimeMaterial { get; set; }
        #endregion
    }
}
