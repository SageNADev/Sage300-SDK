// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
	public partial class GenerateSystemBatch : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets RequestType 
        /// </summary>
        
 		[ViewField(Name = Fields.RequestType, Id = Index.RequestType, FieldType = EntityFieldType.Int, Size = 2)]
 		public RequestType RequestType {get; set;}
		 
  		/// <summary>
        /// Gets or sets FileName 
        /// </summary>
      
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.FileName, Id = Index.FileName, FieldType = EntityFieldType.Char, Size = 255)]
 		public string FileName {get; set;}
		
		/// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		 [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime BatchDate {get; set;}
	 
  		/// <summary>
        /// Gets or sets SelectionCriteria 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.SelectionCriteria, Id = Index.SelectionCriteria, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string SelectionCriteria {get; set;}
		   
    }
}
