/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */
#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Model for Payment Adjustment Batch
    /// </summary>
    public partial class PaymentAdjustmentBatch : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public PaymentAdjustmentBatch()
        {
            PaymentAdjustment = new PaymentAdjustment();
            PostPaymentandAdjustment = new PostPaymentAdjustment();
        }

        #region System Generated

        /// <summary>
        /// Gets or sets BatchSelector 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.BatchSelector, Id = Index.BatchSelector, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchSelector { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BatchNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BatchDate { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDescription", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets NumberofEntries 
        /// </summary>
        [Display(Name = "NumOfEntries", ResourceType = typeof(APCommonResx))]
        public decimal NumberOfEntries { get; set; }

        /// <summary>
        /// Gets or sets BatchTotal 
        /// </summary>
        [Display(Name = "TotalAmount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BatchTotal, Id = Index.BatchTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BatchTotal { get; set; }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Display(Name = "BatchType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentBatchType BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchStatus 
        /// </summary>
        [Display(Name = "BatchStatus", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BatchStatus, Id = Index.BatchStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentBatchStatus BatchStatus { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Bank", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }


        /// <summary>
        /// Gets or sets BankCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BankCurrencyCode, Id = Index.BankCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BankCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets BankRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankRateDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BankRateDate, Id = Index.BankRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BankRateDate { get; set; }

        /// <summary>
        /// Gets or sets LastEntryNumber 
        /// </summary>
        [Display(Name = "LastEntryNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.LastEntryNumber, Id = Index.LastEntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal LastEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets BankRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankRateType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BankRateType, Id = Index.BankRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BankRateType { get; set; }

        /// <summary>
        /// Gets or sets BankExchangeRate 
        /// </summary>
        [Display(Name = "BankExchangeRate", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BankExchangeRate, Id = Index.BankExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BankExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets FuncBatchTotal 
        /// </summary>
        [ViewField(Name = Fields.FuncBatchTotal, Id = Index.FuncBatchTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBatchTotal { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNo 
        /// </summary>
        [Display(Name = "PostingSequence", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PostingSequenceNo, Id = Index.PostingSequenceNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets NumberofErrors 
        /// </summary>
        [Display(Name = "NumOfErrors", ResourceType = typeof(APCommonResx))]
        public decimal NumberOfErrors { get; set; }

        /// <summary>
        /// Gets or sets DateLastEdited 
        /// </summary>
        [Display(Name = "LastEdited", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DateLastEdited, Id = Index.DateLastEdited, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastEdited { get; set; }


        /// <summary>
        /// Gets or sets BatchEdited 
        /// </summary>
        [ViewField(Name = Fields.BatchEdited, Id = Index.BatchEdited, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited BatchEdited { get; set; }

        /// <summary>
        /// Gets or sets PaymentRegisterPrintstatus 
        /// </summary>
        public PaymentRegisterPrintstatus PaymentRegisterPrintStatus { get; set; }

        /// <summary>
        /// Gets or sets NumberofPrintedChecks 
        /// </summary>
        [Display(Name = "NumOfChecksPrinted", ResourceType = typeof(APCommonResx))]
        public decimal NumberOfPrintedChecks { get; set; }

        /// <summary>
        /// Gets or sets NumberofReapplies 
        /// </summary>
        [Display(Name = "NumberOfReapplies", ResourceType = typeof(PaymentEntryResx))]
        public decimal NumberOfReapplies { get; set; }

        /// <summary>
        /// Gets or sets BatchPrintedFlag 
        /// </summary>
        [Display(Name = "BatchPrinted", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BatchPrintedFlag, Id = Index.BatchPrintedFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited BatchPrintedFlag { get; set; }

        /// <summary>
        /// Gets or sets BankRateOperator  
        /// </summary>
        [Display(Name = "BankRateOperator", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BankRateOperator, Id = Index.BankRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int BankRateOperator { get; set; }

        /// <summary>
        /// Gets or sets BankRateOverridden 
        /// </summary>
        [Display(Name = "BankRateOverridden", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BankRateOverridden, Id = Index.BankRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited BankRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentAdjBatchProcessCmdCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets PaymentAdjustment
        /// </summary>
        public PaymentAdjustment PaymentAdjustment { get; set; }

        /// <summary>
        /// Gets or sets PostPaymentAdjustment
        /// </summary>
        public PostPaymentAdjustment PostPaymentandAdjustment { get; set; }

        #endregion

        #region User Entered

        /// <summary>
        /// Gets or sets ReadytoPost
        /// </summary>
        /// <value>The readyto post.</value>
        [Display(Name = "ReadyToPost", ResourceType = typeof(APCommonResx))]
        public Printed ReadyToPost { get; set; }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string.</value>
        [Display(Name = "Type", ResourceType = typeof(APCommonResx))]
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(BatchType); }
        }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        /// <value>The status string.</value>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(BatchStatus); }
        }

        /// <summary>
        /// To convert batchdate string to datetime value
        /// </summary>
        [Display(Name = "BatchDate", ResourceType = typeof(APCommonResx))]
        public DateTime BatchDateTime
        {
            get { return DateUtil.GetDate(BatchDate, DateUtil.GetNowDate()); }
        }

        /// <summary>
        /// To convert datelastedited string to datetime value
        /// </summary>
        [Display(Name = "LastEdited", ResourceType = typeof(APCommonResx))]
        public DateTime LastEditedDateValue
        {
            get { return DateUtil.GetDate(DateLastEdited, DateUtil.GetNowDate()); }
        }

        /// <summary>
        /// To convert bank rate date string to datetime value
        /// </summary>
        public DateTime BankRateDateTimeValue
        {
            get { return BankRateDate; }
        }

        /// <summary>
        /// To convert enum value of process command code to corressponding string
        /// </summary>
        public string ProcessCommandCodeString
        {
            get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        /// <summary>
        /// To convert enum value of payment register print status to corressponding string
        /// </summary>
        public string PaymentRegisterPrintStatusString
        {
            get { return EnumUtility.GetStringValue(PaymentRegisterPrintStatus); }
        }

        /// <summary>
        /// To get the string of BatchPrintedFlag property
        /// </summary>
        /// <value>The type string</value>
        public string TypePrinted
        {
            get { return EnumUtility.GetStringValue(BatchPrintedFlag); }
        }

        /// <summary>
        /// To get the string of BankRateOverridden property
        /// </summary>
        /// <value>The type string</value>
        public string TypeBankRateOverridden
        {
            get { return EnumUtility.GetStringValue(BankRateOverridden); }
        }

        /// <summary>
        /// To get the string of BatchEdited property
        /// </summary>
        /// <value>The type string</value>
        public string TypeBatchEdited
        {
            get { return EnumUtility.GetStringValue(BatchEdited); }
        }

        /// <summary>
        /// Can Adjust Inquire
        /// </summary>
        public bool CanAdjustInquire { get; set; }

        /// <summary>
        /// Can Print Checks
        /// </summary>
        public bool CanPrintChecks { get; set; }

        /// <summary>
        /// Transaction OptionalFields
        /// </summary>
        public bool IsTransactionOptionalFields { get; set; }

        /// <summary>
        /// Get- GL module Active
        /// </summary>
        /// <value>Boolean</value>
        public bool IsGlActive { get; set; }

        /// <summary>
        /// Get- YP module Active
        /// </summary>
        /// <value>Boolean</value>
        public bool IsYpActive { get; set; }

        /// <summary>
        /// Get- PM module Active
        /// </summary>
        /// <value>Boolean</value>
        public bool IsPMActive { get; set; }

        /// <summary>
        /// Get- IC module Active
        /// </summary>
        /// <value>Boolean</value>
        public bool IsICActive { get; set; }

        /// <summary>
        /// Get- PO module Active
        /// </summary>
        /// <value>Boolean</value>
        public bool IsPOActive { get; set; }

        #endregion

        // newly added
        #region Security

        /// <summary>
        /// Gets the type of loacked 
        /// </summary>
        /// <value>The session warn days.</value>
        public string HandleLockedFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        [IgnoreExportImport]
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        [IgnoreExportImport]
        public short SessionWarnDays { get; set; }

        /// <summary>
        /// Get- Optional Field License detail
        /// </summary>
        /// <value>Boolean</value>
        [IgnoreExportImport]
        public bool HaveOptFldLicense { get; set; }

        #endregion
    }
}
