/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for Invoice Detail
    /// </summary>
    public partial class InvoiceDetail : BaseInvoiceDetail
    {
        /// <summary>
        /// Gets or sets ContractCode 
        /// </summary>
        [Display(Name = "ContractCode", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode)]
        public override string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode 
        /// </summary>
        [Display(Name = "ProjectCode", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode)]
        public override string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode 
        /// </summary>
        [Display(Name = "CategoryCode", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode)]
        public override string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectOrCategoryResource 
        /// </summary>
        [Display(Name = "ProjectOrCategoryResource", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.ProjectOrCategoryResource, Id = Index.ProjectOrCategoryResource)]
        public override string ProjectOrCategoryResource { get; set; }

        /// <summary>
        /// Gets or sets BillingType 
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public override BillingType BillingType { get; set; }

    }
}
