/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class OpenDocumentOptionalField : ModelBase
    {

        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalField 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Value 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public OpenDocumentOptionalFieldsType Type { get; set; }

        /// <summary>
        /// Gets or sets Length 
        /// </summary>
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals 
        /// </summary>
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank 
        /// </summary>
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public RateOverridden AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate 
        /// </summary>
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public RateOverridden Validate { get; set; }

        /// <summary>
        /// Gets or sets TypedValueFieldIndex 
        /// </summary>
        [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets TextValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string TextValue { get; set; }

        /// <summary>
        /// Gets or sets AmountValue 
        /// </summary>
        [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountValue { get; set; }

        /// <summary>
        /// Gets or sets NumberValue 
        /// </summary>
        [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NumberValue { get; set; }

        /// <summary>
        /// Gets or sets IntegerValue 
        /// </summary>
        [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long IntegerValue { get; set; }

        /// <summary>
        /// Gets or sets YesOrNoValue 
        /// </summary>
        [ViewField(Name = Fields.YesOrNoValue, Id = Index.YesOrNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public RateOverridden YesOrNoValue { get; set; }

        /// <summary>
        /// Gets or sets DateValue 
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateValue { get; set; }

        /// <summary>
        /// Gets or sets TimeValue 
        /// </summary>
        [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan TimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }
    }
}
