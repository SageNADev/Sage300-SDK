/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

using System;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class AppliedPayment : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public AppliedPayment()
        {
            AdjustmentGLDistributions = new EnumerableResponse<AdjustmentGLDistribution>();
        }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "BatchType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "BatchNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "EntryNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "LineNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber 
        /// </summary>
        [Display(Name = "PaymentNumber", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentBatchTransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets PaymentResolution 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PaymentResolution", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentResolution, Id = Index.PaymentResolution, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PaymentResolution { get; set; }

        /// <summary>
        /// Gets or sets PaymentAmount 
        /// </summary>
        [Display(Name = "AppliedAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentAmount, Id = Index.PaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmountTaken 
        /// </summary>
        [Display(Name = "DiscountAmountTaken", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DiscountAmountTaken, Id = Index.DiscountAmountTaken, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmountTaken { get; set; }

        /// <summary>
        /// Gets or sets NextAdjSeqNo 
        /// </summary>
        [Display(Name = "NextAdjSeqNo", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.NextAdjSeqNo, Id = Index.NextAdjSeqNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NextAdjSeqNo { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentsTotal 
        /// </summary>
        [Display(Name = "AdjustmentsTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AdjustmentsTotal, Id = Index.AdjustmentsTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustmentsTotal { get; set; }

        /// <summary>
        /// Gets or sets GeneratedAdjustmentNumber 
        /// </summary>
        [Display(Name = "GeneratedAdjustmentNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.GeneratedAdjustmentNumber, Id = Index.GeneratedAdjustmentNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal GeneratedAdjustmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets GeneratedPPNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "GeneratedPPNo", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.GeneratedPPNo, Id = Index.GeneratedPPNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string GeneratedPPNo { get; set; }

        /// <summary>
        /// Gets or sets PPMatchingDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PPMatchingDocNo", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PPMatchingDocNo, Id = Index.PPMatchingDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PPMatchingDocNo { get; set; }

        /// <summary>
        /// Gets or sets PPMatchingDocType 
        /// </summary>
        [Display(Name = "PPMatchingDocType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PPMatchingDocType, Id = Index.PPMatchingDocType, FieldType = EntityFieldType.Int, Size = 2)]
        public PPMatchingDocType PPMatchingDocType { get; set; }

        /// <summary>
        /// Gets or sets ActivationDate 
        /// </summary>    
        [Display(Name = "ActivationDate", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ActivationDate, Id = Index.ActivationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ActivationDate { get; set; }

        /// <summary>
        /// Gets or sets DocumentAmountDue 
        /// </summary>
        [Display(Name = "DocumentAmountDue", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DocumentAmountDue, Id = Index.DocumentAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentAmountDue { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmountAvailable 
        /// </summary>
        [Display(Name = "DiscountAmountAvailable", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DiscountAmountAvailable, Id = Index.DiscountAmountAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmountAvailable { get; set; }

        /// <summary>
        /// Gets or sets DocumentNetBalance 
        /// </summary>
        [Display(Name = "DocumentNetBalance", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DocumentNetBalance, Id = Index.DocumentNetBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentNetBalance { get; set; }

        /// <summary>
        /// Gets or sets PendingPaymentAmount 
        /// </summary>
        [Display(Name = "PendingPaymentAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PendingPaymentAmount, Id = Index.PendingPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingDiscountAmount 
        /// </summary>
        [Display(Name = "PendingDiscountAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PendingDiscountAmount, Id = Index.PendingDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingAdjustmentAmount 
        /// </summary>
        [Display(Name = "PendingAdjustmentAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PendingAdjustmentAmount, Id = Index.PendingAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets AdjDebitAmtVendCurr 
        /// </summary>
        [Display(Name = "AdjDebitAmtVendCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AdjDebitAmtVendCurr, Id = Index.AdjDebitAmtVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjDebitAmtVendCurr { get; set; }

        /// <summary>
        /// Gets or sets AdjCreditAmtVendCurr 
        /// </summary>
        [Display(Name = "AdjCreditAmtVendCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AdjCreditAmtVendCurr, Id = Index.AdjCreditAmtVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjCreditAmtVendCurr { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited JobRelated { get; set; }

        /// <summary>
        /// Gets or sets JobTotalPaymentAmount 
        /// </summary>
        [Display(Name = "JobTotalPaymentAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.JobTotalPaymentAmount, Id = Index.JobTotalPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal JobTotalPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets JobTotalDiscountAmount 
        /// </summary>
        [Display(Name = "JobTotalDiscountAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.JobTotalDiscountAmount, Id = Index.JobTotalDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal JobTotalDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets JobApplyMethod 
        /// </summary>
        [Display(Name = "JobApplyMethod", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.JobApplyMethod, Id = Index.JobApplyMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public JobApplyMethod JobApplyMethod { get; set; }

        /// <summary>
        /// Gets or sets RtgDebitAmtVendCurr 
        /// </summary>
        [Display(Name = "RtgDebitAmtVendCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.RtgDebitAmtVendCurr, Id = Index.RtgDebitAmtVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgDebitAmtVendCurr { get; set; }

        /// <summary>
        /// Gets or sets RtgCreditAmtVendCurr 
        /// </summary>
        [Display(Name = "RtgCreditAmtVendCurr", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.RtgCreditAmtVendCurr, Id = Index.RtgCreditAmtVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgCreditAmtVendCurr { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount 
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDate 
        /// </summary>
        [Display(Name = "RetainageDueDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.RetainageDueDate, Id = Index.RetainageDueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RetainageDueDate { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "RetainageTermsCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate 
        /// </summary>
        [Display(Name = "RetainageExchangeRate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand 
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets UnappliedJobPaymentAmount 
        /// </summary>
        [Display(Name = "UnappliedJobPaymentAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.UnappliedJobPaymentAmount, Id = Index.UnappliedJobPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnappliedJobPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets UnappliedJobDiscountAmount 
        /// </summary>
        [Display(Name = "UnappliedJobDiscountAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.UnappliedJobDiscountAmount, Id = Index.UnappliedJobDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnappliedJobDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "VendorCurrencyCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorCurrencyCode, Id = Index.VendorCurrencyCode, FieldType = EntityFieldType.Char, Size = 3)]
        public string VendorCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets PaymentDate 
        /// </summary>    
        [Display(Name = "PaymentDate", ResourceType = typeof(PaymentEntryResx))]    
        [ViewField(Name = Fields.PaymentDate, Id = Index.PaymentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PaymentDate { get; set; }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets PaymentType 
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentTransType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage 
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageBalance 
        /// </summary>
        [Display(Name = "RetainageBalance", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.RetainageBalance, Id = Index.RetainageBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageBalance { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OriginalDocNo", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }

        /// <summary>
        /// Gets or sets PayablesAdjustmentTotal 
        /// </summary>
        [Display(Name = "PayablesAdjustmentTotal", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.PayablesAdjustmentTotal, Id = Index.PayablesAdjustmentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PayablesAdjustmentTotal { get; set; }

        /// <summary>
        /// Gets or sets OriginalExchangeRate 
        /// </summary>
        [Display(Name = "OriginalExchangeRate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.OriginalExchangeRate, Id = Index.OriginalExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal OriginalExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets DocDate 
        /// </summary>
        [Display(Name = "DocDate", ResourceType = typeof(PaymentEntryResx))]        
        [ViewField(Name = Fields.DocDate, Id = Index.DocDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocDate { get; set; }

        /// <summary>
        /// Gets or sets FuncPaymentAmount 
        /// </summary>
        [Display(Name = "FuncPaymentAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncPaymentAmount, Id = Index.FuncPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncDiscountAmount 
        /// </summary>
        [Display(Name = "FuncDiscountAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncDiscountAmount, Id = Index.FuncDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncAdjustmentsTotal 
        /// </summary>
        [Display(Name = "FuncAdjustmentsTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncAdjustmentsTotal, Id = Index.FuncAdjustmentsTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAdjustmentsTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncRetainageAmount 
        /// </summary>
        [Display(Name = "FuncRetainageAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FuncRetainageAmount, Id = Index.FuncRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets DocVersionCreatedIn 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DocVersionCreatedIn", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DocVersionCreatedIn, Id = Index.DocVersionCreatedIn, FieldType = EntityFieldType.Char, Size = 3)]
        public string DocVersionCreatedIn { get; set; }

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1TC, Id = Index.AmtWHD1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2TC, Id = Index.AmtWHD2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3TC, Id = Index.AmtWHD3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4TC, Id = Index.AmtWHD4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5TC, Id = Index.AmtWHD5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1HC, Id = Index.AmtWHD1HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2HC, Id = Index.AmtWHD2HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3HC, Id = Index.AmtWHD3HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4HC, Id = Index.AmtWHD4HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5HC, Id = Index.AmtWHD5HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Job Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1DT, Id = Index.AmtWHD1DT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1DT { get; set; } = 0;

        /// <summary>
        /// Gets or sets Job Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2DT, Id = Index.AmtWHD2DT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2DT { get; set; } = 0;

        /// <summary>
        /// Gets or sets Job Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3DT, Id = Index.AmtWHD3DT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3DT { get; set; } = 0;

        /// <summary>
        /// Gets or sets Job Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4DT, Id = Index.AmtWHD4DT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4DT { get; set; } = 0;

        /// <summary>
        /// Gets or sets Job Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5DT, Id = Index.AmtWHD5DT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5DT { get; set; } = 0;

        /// <summary>
        /// Gets or sets Document Tax Authority 1
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax1, Id = Index.CodeTax1, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax1 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 2
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax2, Id = Index.CodeTax2, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax2 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 3
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax3, Id = Index.CodeTax3, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax3 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 4
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax4, Id = Index.CodeTax4, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax4 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 5
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax5, Id = Index.CodeTax5, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax5 { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 1 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth1Description, Id = Index.TaxAuth1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth1Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 2 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth2Description, Id = Index.TaxAuth2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth2Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 3 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth3Description, Id = Index.TaxAuth3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth3Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 4 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth4Description, Id = Index.TaxAuth4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth4Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 5 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth5Description, Id = Index.TaxAuth5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth5Description { get; set; }

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.PndWHD1Tot, Id = Index.PndWHD1Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD1Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.PndWHD2Tot, Id = Index.PndWHD2Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD2Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.PndWHD3Tot, Id = Index.PndWHD3Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD3Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.PndWHD4Tot, Id = Index.PndWHD4Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD4Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.PndWHD5Tot, Id = Index.PndWHD5Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD5Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Total
        /// </summary>
        [ViewField(Name = Fields.PndWHDTot, Id = Index.PndWHDTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Tax Withheld Amount Total
        /// </summary>
        [ViewField(Name = Fields.AmtWHDTot, Id = Index.AmtWHDTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets AdjustmentGLDistributionList
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<AdjustmentGLDistribution> AdjustmentGLDistributions { get; set; }

        /// <summary>
        /// Gets the string value of DocumentType
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(PaymentEntryResx))]
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Gets the string value of JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(PaymentEntryResx))]
        [IgnoreExportImport]
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets or sets SequenceNo
        /// </summary>
        [IgnoreExportImport]
        public decimal SequenceNo { get; set; }

        /// <summary>
        /// Gets or sets IsValidDocument
        /// </summary>
        [IgnoreExportImport]
        public bool IsValidDocument { get; set; }

        /// <summary>
        /// Gets or sets ObljCount  for grid 
        /// </summary>      
        public decimal ObljCount { get; set; }

        /// <summary>
        /// Gets or sets Calculated Document Balance  for document 
        /// </summary>      
        public decimal DocumentBalanceCalculated { get; set; }

    }
}
