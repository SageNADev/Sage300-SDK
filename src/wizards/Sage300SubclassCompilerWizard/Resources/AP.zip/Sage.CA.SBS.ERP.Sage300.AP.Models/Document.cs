// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class Document
    /// </summary>
    public partial class Document : ModelBase
    {
        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber 
        /// </summary>
        [StringLength(18, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Char, Size = 18, Mask = "%-18D")]
        public string CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PONumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PONumber { get; set; }

        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DueDate { get; set; }

        /// <summary>
        /// Gets or sets RemitToLocation 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RemitToLocation, Id = Index.RemitToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RemitToLocation { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BatchDate { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets GroupCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets DocDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DocDescription, Id = Index.DocDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DocDescription { get; set; }

        /// <summary>
        /// Gets or sets DocDate 
        /// </summary>
        [ViewField(Name = Fields.DocDate, Id = Index.DocDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceasofDate 
        /// </summary>
        [ViewField(Name = Fields.InvoiceasofDate, Id = Index.InvoiceasofDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoiceasofDate { get; set; }

        /// <summary>
        /// Gets or sets Terms 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets DiscountDate 
        /// </summary>
        [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateOverridden 
        /// </summary>
        [ViewField(Name = Fields.RateOverridden, Id = Index.RateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden RateOverridden { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyInvoiceAmount 
        /// </summary>
        [ViewField(Name = Fields.FuncCurrencyInvoiceAmount, Id = Index.FuncCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyAmountDue 
        /// </summary>
        [ViewField(Name = Fields.FuncCurrencyAmountDue, Id = Index.FuncCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyTaxableAmount 
        /// </summary>
        [ViewField(Name = Fields.FuncCurrencyTaxableAmount, Id = Index.FuncCurrencyTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyNonTaxableAmt 
        /// </summary>
        [ViewField(Name = Fields.FuncCurrencyNonTaxableAmt, Id = Index.FuncCurrencyNonTaxableAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyNonTaxableAmt { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyTaxAmount 
        /// </summary>
        [ViewField(Name = Fields.FuncCurrencyTaxAmount, Id = Index.FuncCurrencyTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyDiscountAmount 
        /// </summary>
        [ViewField(Name = Fields.FuncCurrencyDiscountAmount, Id = Index.FuncCurrencyDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets VendCurrencyInvoiceAmount 
        /// </summary>
        [ViewField(Name = Fields.VendCurrencyInvoiceAmount, Id = Index.VendCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets VendCurrencyAmountDue 
        /// </summary>
        [ViewField(Name = Fields.VendCurrencyAmountDue, Id = Index.VendCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets VendCurrencyTaxableAmount 
        /// </summary>
        [ViewField(Name = Fields.VendCurrencyTaxableAmount, Id = Index.VendCurrencyTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendCurrencyTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets VendCurrencyNonTaxableAmt 
        /// </summary>
        [ViewField(Name = Fields.VendCurrencyNonTaxableAmt, Id = Index.VendCurrencyNonTaxableAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendCurrencyNonTaxableAmt { get; set; }

        /// <summary>
        /// Gets or sets VendCurrencyTaxAmount 
        /// </summary>
        [ViewField(Name = Fields.VendCurrencyTaxAmount, Id = Index.VendCurrencyTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendCurrencyTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets VendCurrencyDiscountAmount 
        /// </summary>
        [ViewField(Name = Fields.VendCurrencyDiscountAmount, Id = Index.VendCurrencyDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendCurrencyDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FullyPaid 
        /// </summary>
        [ViewField(Name = Fields.FullyPaid, Id = Index.FullyPaid, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden FullyPaid { get; set; }

        /// <summary>
        /// Gets or sets LastActivityDate 
        /// </summary>
        [ViewField(Name = Fields.LastActivityDate, Id = Index.LastActivityDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastActivityDate { get; set; }

        /// <summary>
        /// Gets or sets LastStatementDate 
        /// </summary>
        [ViewField(Name = Fields.LastStatementDate, Id = Index.LastStatementDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastStatementDate { get; set; }

        /// <summary>
        /// Gets or sets NumberofScheduledPayments 
        /// </summary>

        [ViewField(Name = Fields.NumberofScheduledPayments, Id = Index.NumberofScheduledPayments, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofScheduledPayments { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumberonLastStatement 
        /// </summary>
        [ViewField(Name = Fields.PaymentNumberonLastStatement, Id = Index.PaymentNumberonLastStatement, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumberonLastStatement { get; set; }

        /// <summary>
        /// Gets or sets LastAppliedPaymentSeqNo 
        /// </summary>
        [ViewField(Name = Fields.LastAppliedPaymentSeqNo, Id = Index.LastAppliedPaymentSeqNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LastAppliedPaymentSeqNo { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountControl 
        /// </summary>
        [ViewField(Name = Fields.TaxAmountControl, Id = Index.TaxAmountControl, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxAmountControl TaxAmountControl { get; set; }

        /// <summary>
        /// Gets or sets TaxAuth1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuth1, Id = Index.TaxAuth1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuth1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuth2 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuth2, Id = Index.TaxAuth2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuth2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuth3 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuth3, Id = Index.TaxAuth3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuth3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuth4 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuth4, Id = Index.TaxAuth4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuth4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuth5 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuth5, Id = Index.TaxAuth5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuth5 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount1 
        /// </summary>
        [ViewField(Name = Fields.FuncBaseAmount1, Id = Index.FuncBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount2 
        /// </summary>
        [ViewField(Name = Fields.FuncBaseAmount2, Id = Index.FuncBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount3 
        /// </summary>
        [ViewField(Name = Fields.FuncBaseAmount3, Id = Index.FuncBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount4 
        /// </summary>
        [ViewField(Name = Fields.FuncBaseAmount4, Id = Index.FuncBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount5 
        /// </summary>
        [ViewField(Name = Fields.FuncBaseAmount5, Id = Index.FuncBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount1 
        /// </summary>
        [ViewField(Name = Fields.FuncTaxAmount1, Id = Index.FuncTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount2 
        /// </summary>
        [ViewField(Name = Fields.FuncTaxAmount2, Id = Index.FuncTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount3 
        /// </summary>
        [ViewField(Name = Fields.FuncTaxAmount3, Id = Index.FuncTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount4 
        /// </summary>
        [ViewField(Name = Fields.FuncTaxAmount4, Id = Index.FuncTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount5 
        /// </summary>
        [ViewField(Name = Fields.FuncTaxAmount5, Id = Index.FuncTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets VendBaseAmount1 
        /// </summary>
        [ViewField(Name = Fields.VendBaseAmount1, Id = Index.VendBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets VendBaseAmount2 
        /// </summary>
        [ViewField(Name = Fields.VendBaseAmount2, Id = Index.VendBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets VendBaseAmount3 
        /// </summary>
        [ViewField(Name = Fields.VendBaseAmount3, Id = Index.VendBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets VendBaseAmount4 
        /// </summary>
        [ViewField(Name = Fields.VendBaseAmount4, Id = Index.VendBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets VendBaseAmount5 
        /// </summary>
        [ViewField(Name = Fields.VendBaseAmount5, Id = Index.VendBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets VendTaxAmount1 
        /// </summary>
        [ViewField(Name = Fields.VendTaxAmount1, Id = Index.VendTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets VendTaxAmount2 
        /// </summary>
        [ViewField(Name = Fields.VendTaxAmount2, Id = Index.VendTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets VendTaxAmount3 
        /// </summary>
        [ViewField(Name = Fields.VendTaxAmount3, Id = Index.VendTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets VendTaxAmount4 
        /// </summary>
        [ViewField(Name = Fields.VendTaxAmount4, Id = Index.VendTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets VendTaxAmount5 
        /// </summary>
        [ViewField(Name = Fields.VendTaxAmount5, Id = Index.VendTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets PrepayInvoiceNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepayInvoiceNumber, Id = Index.PrepayInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PrepayInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingDate 
        /// </summary>
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets Num1099OrCPRSCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Num1099OrCPRSCode, Id = Index.Num1099OrCPRSCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Num1099OrCPRSCode { get; set; }

        /// <summary>
        /// Gets or sets Num1099OrCPRSOriginalAmount 
        /// </summary>
        [ViewField(Name = Fields.Num1099OrCPRSOriginalAmount, Id = Index.Num1099OrCPRSOriginalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Num1099OrCPRSOriginalAmount { get; set; }

        /// <summary>
        /// Gets or sets Num1099OrCPRSRemainingAmount 
        /// </summary>
        [ViewField(Name = Fields.Num1099OrCPRSRemainingAmount, Id = Index.Num1099OrCPRSRemainingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Num1099OrCPRSRemainingAmount { get; set; }

        /// <summary>
        /// Gets or sets RateDate 
        /// </summary>
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator 
        /// </summary>
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateOperator { get; set; }

        /// <summary>
        /// Gets or sets LastActivityYearOrPeriod 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastActivityYearOrPeriod, Id = Index.LastActivityYearOrPeriod, FieldType = EntityFieldType.Char, Size = 6)]
        public string LastActivityYearOrPeriod { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets CheckSerialNumber 
        /// </summary>
        [ViewField(Name = Fields.CheckSerialNumber, Id = Index.CheckSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long CheckSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNo 
        /// </summary>
        [ViewField(Name = Fields.PostingSequenceNo, Id = Index.PostingSequenceNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden JobRelated { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage 
        /// </summary>
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageOutstanding 
        /// </summary>
        [ViewField(Name = Fields.RetainageOutstanding, Id = Index.RetainageOutstanding, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden RetainageOutstanding { get; set; }

        /// <summary>
        /// Gets or sets DateRetainageDue 
        /// </summary>
        [ViewField(Name = Fields.DateRetainageDue, Id = Index.DateRetainageDue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateRetainageDue { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrOrigRtngAmt 
        /// </summary>
        [ViewField(Name = Fields.FuncCurrOrigRtngAmt, Id = Index.FuncCurrOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrRetainageAmount 
        /// </summary>
        [ViewField(Name = Fields.FuncCurrRetainageAmount, Id = Index.FuncCurrRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets VendCurrOrigRtngAmt 
        /// </summary>
        [ViewField(Name = Fields.VendCurrOrigRtngAmt, Id = Index.VendCurrOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendCurrOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets VendCurrRetainageAmount 
        /// </summary>
        [ViewField(Name = Fields.VendCurrRetainageAmount, Id = Index.VendCurrRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendCurrRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets PaymentStatus 
        /// </summary>
        [ViewField(Name = Fields.PaymentStatus, Id = Index.PaymentStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentStatus PaymentStatus { get; set; }

        /// <summary>
        /// Gets or sets DatePaymentStatusChanged 
        /// </summary>
        [ViewField(Name = Fields.DatePaymentStatusChanged, Id = Index.DatePaymentStatusChanged, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DatePaymentStatusChanged { get; set; }

        /// <summary>
        /// Gets or sets AOrPVersionCreatedIn 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AOrPVersionCreatedIn, Id = Index.AOrPVersionCreatedIn, FieldType = EntityFieldType.Char, Size = 3)]
        public string AOrPVersionCreatedIn { get; set; }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets NumberofOBLJDetails 
        /// </summary>
        [ViewField(Name = Fields.NumberofOBLJDetails, Id = Index.NumberofOBLJDetails, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofOBLJDetails { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3)]
        public string TaxReportingCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.TaxReportingExchangeRate, Id = Index.TaxReportingExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2)]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate 
        /// </summary>
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperator 
        /// </summary>
        [ViewField(Name = Fields.TaxReportingRateOperator, Id = Index.TaxReportingRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOverride 
        /// </summary>
        [ViewField(Name = Fields.TaxReportingRateOverride, Id = Index.TaxReportingRateOverride, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxReportingRateOverride { get; set; }

        /// <summary>
        /// Gets or sets ReportRetainageTax 
        /// </summary>
        [ViewField(Name = Fields.ReportRetainageTax, Id = Index.ReportRetainageTax, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReportRetainageTax { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxStateVersion 
        /// </summary>
        [ViewField(Name = Fields.TaxStateVersion, Id = Index.TaxStateVersion, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxStateVersion { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseCalculateMethod 
        /// </summary>
        [ViewField(Name = Fields.TaxBaseCalculateMethod, Id = Index.TaxBaseCalculateMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxBaseCalculateMethod { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCalculateMethod 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingCalculateMethod, Id = Index.TaxReportingCalculateMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingCalculateMethod { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1 
        /// </summary>
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2 
        /// </summary>
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3 
        /// </summary>
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4 
        /// </summary>
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5 
        /// </summary>
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1 
        /// </summary>
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2 
        /// </summary>
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3 
        /// </summary>
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4 
        /// </summary>
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5 
        /// </summary>
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1 
        /// </summary>
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2 
        /// </summary>
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3 
        /// </summary>
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4 
        /// </summary>
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5 
        /// </summary>
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets EarliestBackdatedActivityDate 
        /// </summary>
        [ViewField(Name = Fields.EarliestBackdatedActivityDate, Id = Index.EarliestBackdatedActivityDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime EarliestBackdatedActivityDate { get; set; }

        /// <summary>
        /// Gets or sets LastRevaluationDate 
        /// </summary>
        [ViewField(Name = Fields.LastRevaluationDate, Id = Index.LastRevaluationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastRevaluationDate { get; set; }

        /// <summary>
        /// Gets or sets OrigExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.OrigExchangeRate, Id = Index.OrigExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal OrigExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets OrigRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrigRateType, Id = Index.OrigRateType, FieldType = EntityFieldType.Char, Size = 2)]
        public string OrigRateType { get; set; }

        /// <summary>
        /// Gets or sets OrigRateDate 
        /// </summary>
        [ViewField(Name = Fields.OrigRateDate, Id = Index.OrigRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrigRateDate { get; set; }

        /// <summary>
        /// Gets or sets OrigRateOperator 
        /// </summary>
        [ViewField(Name = Fields.OrigRateOperator, Id = Index.OrigRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrigRateOperator { get; set; }

        /// <summary>
        /// Gets or sets OrigRateOverrideFlag 
        /// </summary>
        [ViewField(Name = Fields.OrigRateOverrideFlag, Id = Index.OrigRateOverrideFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden OrigRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets AccountSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets DatePaid 
        /// </summary>
        [ViewField(Name = Fields.DatePaid, Id = Index.DatePaid, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DatePaid { get; set; }

        /// <summary>
        /// Gets or sets MiscPaymentFlag 
        /// </summary>
        [ViewField(Name = Fields.MiscPaymentFlag, Id = Index.MiscPaymentFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public int MiscPaymentFlag { get; set; }

        #region Properties for finder

        /// <summary>
        /// Transaction Type String
        /// </summary>
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        /// <summary>
        /// Document Type String
        /// </summary>
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Fully Paid String
        /// </summary>
        public string FullyPaidString
        {
            get { return EnumUtility.GetStringValue(FullyPaid); }
        }

        /// <summary>
        /// Rate Overridden String
        /// </summary>
        public string RateOverriddenString
        {
            get { return EnumUtility.GetStringValue(RateOverridden); }
        }

        /// <summary>
        /// Tax Amount Control String
        /// </summary>
        public string TaxAmountControlString
        {
            get { return EnumUtility.GetStringValue(TaxAmountControl); }
        }

        /// <summary>
        /// Job Related String
        /// </summary>
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Has Retainage String
        /// </summary>
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Retainage Outstanding String
        /// </summary>
        public string RetainageOutstandingString
        {
            get { return EnumUtility.GetStringValue(RetainageOutstanding); }
        }

        /// <summary>
        /// Retainage Exchange Rate String
        /// </summary>
        public string RetainageExchangeRateString
        {
            get { return EnumUtility.GetStringValue(RetainageExchangeRate); }
        }

        /// <summary>
        /// Payment Status String
        /// </summary>
        public string PaymentStatusString
        {
            get { return EnumUtility.GetStringValue(PaymentStatus); }
        }

        /// <summary>
        /// Tax Reporting Rate Override String
        /// </summary>
        public string TaxReportingRateOverrideString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOverride); }
        }

        /// <summary>
        /// Tax Included1 String
        /// </summary>
        public string TaxIncluded1String
        {
            get { return EnumUtility.GetStringValue(TaxIncluded1); }
        }

        /// <summary>
        /// Tax Included2 String
        /// </summary>
        public string TaxIncluded2String
        {
            get { return EnumUtility.GetStringValue(TaxIncluded2); }
        }

        /// <summary>
        /// Tax Included3 String
        /// </summary>
        public string TaxIncluded3String
        {
            get { return EnumUtility.GetStringValue(TaxIncluded3); }
        }

        /// <summary>
        /// Tax Included4 String
        /// </summary>
        public string TaxIncluded4String
        {
            get { return EnumUtility.GetStringValue(TaxIncluded4); }
        }

        /// <summary>
        /// Tax Included5 String
        /// </summary>
        public string TaxIncluded5String
        {
            get { return EnumUtility.GetStringValue(TaxIncluded5); }
        }

        /// <summary>
        /// Orig. Rate Override Flag String
        /// </summary>
        public string OrigRateOverrideFlagString
        {
            get { return EnumUtility.GetStringValue(OrigRateOverrideFlag); }
        }

        #endregion
    }
}
