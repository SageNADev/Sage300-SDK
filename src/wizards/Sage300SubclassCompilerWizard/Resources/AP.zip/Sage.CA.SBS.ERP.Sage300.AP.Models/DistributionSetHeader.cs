/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class DistributionSetHeader : ModelBase
    {
        /// <summary>
        /// Gets or sets DistributionSet
        /// </summary>
        /// <value>
        /// The distribution set.
        /// </value>
        [Display(Name = "DistributionSet", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DistributionSet, Id = Index.DistributionSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionSet { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [Display(Name = "Description", ResourceType = typeof(APCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate
        /// </summary>
        /// <value>
        /// The inactive date.
        /// </value>
        [Display(Name = "InactiveDate", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained
        /// </summary>
        /// <value>
        /// The date last maintained.
        /// </value>
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets CodeType
        /// </summary>
        /// <value>
        /// The type of the code.
        /// </value>
        [Display(Name = "CodeType", ResourceType = typeof(DistributionSetsResx))]
        [ViewField(Name = Fields.CodeType, Id = Index.CodeType, FieldType = EntityFieldType.Int, Size = 2)]
        public CodeType CodeType { get; set; }

        /// <summary>
        /// Gets or sets DistributionMethod
        /// </summary>
        /// <value>
        /// The distribution method.
        /// </value>
        [Display(Name = "DistributionMethod", ResourceType = typeof(DistributionSetsResx))]
        [ViewField(Name = Fields.DistributionMethod, Id = Index.DistributionMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public DistributionMethod DistributionMethod { get; set; }

        /// <summary>
        /// Gets or sets DistributionsEntered
        /// </summary>
        /// <value>
        /// The distributions entered.
        /// </value>
        [Display(Name = "DistributionsEntered", ResourceType = typeof(DistributionSetsResx))]
        [ViewField(Name = Fields.DistributionsEntered, Id = Index.DistributionsEntered, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal DistributionsEntered { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        /// <value>
        /// The currency.
        /// </value>
        [Display(Name = "Currency", ResourceType = typeof(DistributionSetsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets the distribution set details.
        /// </summary>
        /// <value>
        /// The distribution set details.
        /// </value>
        public EnumerableResponse<DistributionSetDetail> DistributionSetDetails { get; set; }

        /// <summary>
        /// Gets the status string.
        /// </summary>
        /// <value>
        /// The status string.
        /// </value>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }


        /// <summary>
        /// Gets the code type string.
        /// </summary>
        /// <value>
        /// The code type string.
        /// </value>
        public string CodeTypeString
        {
            get { return EnumUtility.GetStringValue(CodeType); }
        }

        /// <summary>
        /// Gets distribution method string value
        /// </summary>
        /// <value>
        /// The distribution method string.
        /// </value>
        public string DistributionMethodString
        {
            get { return EnumUtility.GetStringValue(DistributionMethod); }
        }
    }
}
