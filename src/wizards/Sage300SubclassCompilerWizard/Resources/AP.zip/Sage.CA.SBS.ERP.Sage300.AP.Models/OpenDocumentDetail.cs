/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class OpenDocumentDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(PaymentEntryResx))]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(PaymentEntryResx))]
        [Key]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(APCommonResx))]
        [Key]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ContractCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractCode", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectOrCategoryResource 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectOrCategoryResource", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ProjectOrCategoryResource, Id = Index.ProjectOrCategoryResource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string ProjectOrCategoryResource { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber 
        /// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets CostClass 
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets GOrLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLAccount", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets BillingType 
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyInvoiceAmount 
        /// </summary>
        [Display(Name = "FunctionalCurrencyencyInvoiceAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalCurrencyInvoiceAmount, Id = Index.FunctionalCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyAmountDue 
        /// </summary>
        [Display(Name = "FunctionalCurrencyencyAmountDue", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalCurrencyAmountDue, Id = Index.FunctionalCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyInvoiceAmount 
        /// </summary>
        [Display(Name = "VendorCurrencyencyInvoiceAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorCurrencyInvoiceAmount, Id = Index.VendorCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyAmountDue 
        /// </summary>
        [Display(Name = "VendorCurrencyencyAmountDue", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorCurrencyAmountDue, Id = Index.VendorCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitofMeasure 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.UnitofMeasure, Id = Index.UnitofMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitofMeasure { get; set; }

        /// <summary>
        /// Gets or sets Quantity 
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets Cost 
        /// </summary>
        [Display(Name = "Cost", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets BillingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingDate, Id = Index.BillingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BillingDate { get; set; }

        /// <summary>
        /// Gets or sets BillingRate 
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets Discountable 
        /// </summary>
        [Display(Name = "Discountable", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Discountable, Id = Index.Discountable, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden Discountable { get; set; }
        /// <summary>
        /// Gets status string value
        /// </summary>
        public string DiscountableString
        {
            get { return EnumUtility.GetStringValue(Discountable); }
        }

        /// <summary>
        /// Gets or sets DateRetainageDue 
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateRetainageDue", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DateRetainageDue, Id = Index.DateRetainageDue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateRetainageDue { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyOrigRtngAmt 
        /// </summary>
        [Display(Name = "FunctionalCurrencyOrigRtngAmt", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalCurrencyOrigRtngAmt, Id = Index.FunctionalCurrencyOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyRetainageAmount 
        /// </summary>
        [Display(Name = "FunctionalCurrencyRetainageAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalCurrencyRetainageAmount, Id = Index.FunctionalCurrencyRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyOrigRtngAmt 
        /// </summary>
        [Display(Name = "VendorCurrencyOrigRtngAmt", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorCurrencyOrigRtngAmt, Id = Index.VendorCurrencyOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyRetainageAmount 
        /// </summary>
        [Display(Name = "VendorCurrencyRetainageAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorCurrencyRetainageAmount, Id = Index.VendorCurrencyRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorCurrencyRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets RetainageDistributionAmount 
        /// </summary>
        [Display(Name = "RetainageDistributionAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.RetainageDistributionAmount, Id = Index.RetainageDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1 
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2 
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3 
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4 
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5 
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1 
        /// </summary>
        [Display(Name = "TaxRate1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2 
        /// </summary>
        [Display(Name = "TaxRate2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3 
        /// </summary>
        [Display(Name = "TaxRate3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4 
        /// </summary>
        [Display(Name = "TaxRate4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5 
        /// </summary>
        [Display(Name = "TaxRate5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxBase1 
        /// </summary>
        [Display(Name = "VendorRetainageTaxBase1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxBase1, Id = Index.VendorRetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxBase2 
        /// </summary>
        [Display(Name = "VendorRetainageTaxBase2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxBase2, Id = Index.VendorRetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxBase3 
        /// </summary>
        [Display(Name = "VendorRetainageTaxBase3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxBase3, Id = Index.VendorRetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxBase4 
        /// </summary>
        [Display(Name = "VendorRetainageTaxBase4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxBase4, Id = Index.VendorRetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxBase5 
        /// </summary>
        [Display(Name = "VendorRetainageTaxBase5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxBase5, Id = Index.VendorRetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxAmount1 
        /// </summary>
        [Display(Name = "VendorRetainageTaxAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxAmount1, Id = Index.VendorRetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxAmount2 
        /// </summary>
        [Display(Name = "VendorRetainageTaxAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxAmount2, Id = Index.VendorRetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxAmount3 
        /// </summary>
        [Display(Name = "VendorRetainageTaxAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxAmount3, Id = Index.VendorRetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxAmount4 
        /// </summary>
        [Display(Name = "VendorRetainageTaxAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxAmount4, Id = Index.VendorRetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxAmount5 
        /// </summary>
        [Display(Name = "VendorRetainageTaxAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxAmount5, Id = Index.VendorRetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRetainageTaxAmount1 
        /// </summary>
        [Display(Name = "FunctionalRetainageTaxAmount1", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalRetainageTaxAmount1, Id = Index.FunctionalRetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRetainageTaxAmount2 
        /// </summary>
        [Display(Name = "FunctionalRetainageTaxAmount2", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalRetainageTaxAmount2, Id = Index.FunctionalRetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRetainageTaxAmount3 
        /// </summary>
        [Display(Name = "FunctionalRetainageTaxAmount3", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalRetainageTaxAmount3, Id = Index.FunctionalRetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRetainageTaxAmount4 
        /// </summary>
        [Display(Name = "FunctionalRetainageTaxAmount4", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalRetainageTaxAmount4, Id = Index.FunctionalRetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRetainageTaxAmount5 
        /// </summary>
        [Display(Name = "FunctionalRetainageTaxAmount5", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalRetainageTaxAmount5, Id = Index.FunctionalRetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRetainageTaxAllocated 
        /// </summary>
        [Display(Name = "FunctionalRetainageTaxAllocated", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalRetainageTaxAllocated, Id = Index.FunctionalRetainageTaxAllocated, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAllocated { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxAllocated 
        /// </summary>
        [Display(Name = "VendorRetainageTaxAllocated", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxAllocated, Id = Index.VendorRetainageTaxAllocated, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxAllocated { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRetainageTaxExpensed 
        /// </summary>
        [Display(Name = "FunctionalRetainageTaxExpensed", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.FunctionalRetainageTaxExpensed, Id = Index.FunctionalRetainageTaxExpensed, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxExpensed { get; set; }

        /// <summary>
        /// Gets or sets VendorRetainageTaxExpensed 
        /// </summary>
        [Display(Name = "VendorRetainageTaxExpensed", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.VendorRetainageTaxExpensed, Id = Index.VendorRetainageTaxExpensed, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VendorRetainageTaxExpensed { get; set; }

        /// <summary>
        /// Gets or sets AllocatedTaxAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocatedTaxAccount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AllocatedTaxAccount, Id = Index.AllocatedTaxAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AllocatedTaxAccount { get; set; }

        /// <summary>
        /// Gets or sets LastAppliedPaymentSeqNo 
        /// </summary>
        [Display(Name = "LastAppliedPaymentSeqNo", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.LastAppliedPaymentSeqNo, Id = Index.LastAppliedPaymentSeqNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long LastAppliedPaymentSeqNo { get; set; }

        /// <summary>
        /// Gets or sets Account Description
        /// </summary>
        public string AccountDescription { get; set; }

        /// <summary>
        /// To get the string of Billing Type property for finder purpose
        /// </summary>
        /// <value>The Billing type string</value>
        [IgnoreExportImport]
        public string BillingTypeString
        {
            get {
                return BillingType == BillingType.None ? string.Empty : EnumUtility.GetStringValue(BillingType);
            }
        }

        /// <summary>
        /// To get the string of Cost Class property for finder purpose
        /// </summary>
        /// <value>The Cost Class string</value>
        [IgnoreExportImport]
        public string CostClassString
        {
            get {
                return CostClass == Enums.CostClass.None ? string.Empty : EnumUtility.GetStringValue(CostClass);
            }
        }
    }
}
