
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Name spaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Partial class for vendor comment.
    /// </summary>
	public partial class VendorComment : ModelBase
	{
	    /// <summary>
        /// Gets or sets Vendor Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(VendorResx))]
        [Key]
 		[ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
 		public string VendorNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets Date Entered 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateEntered", ResourceType = typeof(APCommonResx))]
        [Key]
 		[ViewField(Name = Fields.DateEntered, Id = Index.DateEntered, FieldType = EntityFieldType.Date, Size = 5)]
 		public string DateEntered {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comment Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CommentNumber", ResourceType = typeof(VendorResx))]        
		[ViewField(Name = Fields.CommentNumber, Id = Index.CommentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
		public decimal CommentNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets Expiration Date 
        /// </summary>
        [Display(Name = "ExpirationDate", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
 		public string ExpirationDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets Follow up Date 
        /// </summary>
        [Display(Name = "FollowupDate", ResourceType = typeof(VendorResx))]
 		[ViewField(Name = Fields.FollowupDate, Id = Index.FollowupDate, FieldType = EntityFieldType.Date, Size = 5)]
 		public string FollowupDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 
        /// </summary>
        [StringLength(2500, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(VendorResx))]
 		public string Comments {get; set;}
        
        /// <summary>
        /// Gets or sets Comment. This is used only in Export / Import.
        /// </summary>
        [Display(Name = "Comments", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 2500)]
        public string Comment { get; set; }

  		/// <summary>
        /// Gets or sets Reverse Count 
        /// </summary>
        [Display(Name = "ReverseCount", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.ReverseCount, Id = Index.ReverseCount, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal ReverseCount {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 1of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments1Of10", ResourceType = typeof(VendorResx))]
 		public string Comments1Of10 {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 2of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments2Of10", ResourceType = typeof(VendorResx))]
 		public string Comments2Of10 {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 3of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments3Of10", ResourceType = typeof(VendorResx))]
 		public string Comments3Of10 {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 4of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments4Of10", ResourceType = typeof(VendorResx))]
        public string Comments4Of10 {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 5of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments5Of10", ResourceType = typeof(VendorResx))]
        public string Comments5Of10 {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 6of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments6Of10", ResourceType = typeof(VendorResx))]
        public string Comments6Of10 {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 7of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments7Of10", ResourceType = typeof(VendorResx))]
        public string Comments7Of10 {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 8of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments8Of10", ResourceType = typeof(VendorResx))]
        public string Comments8Of10 {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 9of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments9Of10", ResourceType = typeof(VendorResx))]
        public string Comments9Of10 {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 10of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments10Of10", ResourceType = typeof(VendorResx))]
        public string Comments10Of10 {get; set;}

        /// <summary>
        /// Gets or Sets Serial Number
        /// </summary>
        public long SerialNumber { get; set; }
	}
}
