// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// CreateOpenDocumentList
    /// </summary>
    public partial class CreateOpenDocumentList : ModelBase
    {
        /// <summary>
        /// Gets or sets PaymentType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentType", ResourceType = typeof(APCommonResx))]
        [Key]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PaymentType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(APCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(APCommonResx))]
        [Key]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(APCommonResx))]
        [Key]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberofPaymentsScheduled 
        /// </summary>

        [Display(Name = "NumberofPaymentsScheduled", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.NumberofPaymentsScheduled, Id = Index.NumberofPaymentsScheduled, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofPaymentsScheduled { get; set; }

        /// <summary>
        /// Gets or sets ProcessType 
        /// </summary>

        [ViewField(Name = Fields.ProcessType, Id = Index.ProcessType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessType ProcessType { get; set; }

        /// <summary>
        /// Gets or sets ShowType 
        /// </summary>

        [ViewField(Name = Fields.ShowType, Id = Index.ShowType, FieldType = EntityFieldType.Int, Size = 2)]
        public ShowType ShowType { get; set; }

        /// <summary>
        /// Gets or sets OrderBy 
        /// </summary>
        [Display(Name = "OrderBy", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.OrderBy, Id = Index.OrderBy, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.OrderBy OrderBy { get; set; }

        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Display(Name = "VendorNumber", ResourceType = typeof(APCommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber 
        /// </summary> 
        [Display(Name = "InvoiceNumber", ResourceType = typeof(APCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber 
        /// </summary>
        [Display(Name = "CheckNumber", ResourceType = typeof(APCommonResx))]
        [StringLength(18, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Char, Size = 18, Mask = "%-18D")]
        public string CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets PONumber 
        /// </summary>
        [Display(Name = "PONumber", ResourceType = typeof(APCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PONumber { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber 
        /// </summary>
        [Display(Name = "OrderNumber", ResourceType = typeof(APCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>

        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PEDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>
        [Display(Name = "DueDate", ResourceType = typeof(APCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DueDate { get; set; }

        /// <summary>
        /// Gets or sets DiscountDate 
        /// </summary>
        [Display(Name = "DiscountDate", ResourceType = typeof(APCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDate 
        /// </summary>
        [Display(Name = "InvoiceDate", ResourceType = typeof(PaymentEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceDate, Id = Index.InvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets PaymentScheduleAmountDue 
        /// </summary>
        [Display(Name = "PaymentScheduleAmountDue", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentScheduleAmountDue, Id = Index.PaymentScheduleAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentScheduleAmountDue { get; set; }

        /// <summary>
        /// Gets or sets PaymentScheduleAmountNet 
        /// </summary>
        [Display(Name = "PaymentScheduleAmountNet", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentScheduleAmountNet, Id = Index.PaymentScheduleAmountNet, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentScheduleAmountNet { get; set; }

        /// <summary>
        /// Gets or sets PaymentScheduleAmountDisc 
        /// </summary>
        [Display(Name = "PaymentScheduleAmountDisc", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentScheduleAmountDisc, Id = Index.PaymentScheduleAmountDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentScheduleAmountDisc { get; set; }

        /// <summary>
        /// Gets or sets PaymentAmount 
        /// </summary>
        [Display(Name = "PaymentAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentAmount, Id = Index.PaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmountTaken 
        /// </summary>
        [Display(Name = "DiscountAmountTaken", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.DiscountAmountTaken, Id = Index.DiscountAmountTaken, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmountTaken { get; set; }

        /// <summary>
        /// Gets or sets Apply 
        /// </summary>
        [Display(Name = "DiscountAmountTaken", ResourceType = typeof(PaymentEntryResx))]
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Apply, Id = Index.Apply, FieldType = EntityFieldType.Char, Size = 1)]
        public string Apply { get; set; }

        /// <summary>
        /// Gets or sets Mode 
        /// </summary>        
        [ViewField(Name = Fields.Mode, Id = Index.Mode, FieldType = EntityFieldType.Int, Size = 2)]
        public PEMode Mode { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>

        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentAmount 
        /// </summary>
        [Display(Name = "AdjustmentAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.AdjustmentAmount, Id = Index.AdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets StartingDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartingDocumentNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.StartingDocumentNumber, Id = Index.StartingDocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string StartingDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets StartingDate 
        /// </summary>
        [Display(Name = "StartingDate", ResourceType = typeof(PaymentEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartingDate, Id = Index.StartingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? StartingDate { get; set; }

        /// <summary>
        /// Gets or sets StartingAmount 
        /// </summary>
        [Display(Name = "StartingAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.StartingAmount, Id = Index.StartingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StartingAmount { get; set; }

        /// <summary>
        /// Gets or sets RemitAmount 
        /// </summary>
        [Display(Name = "RemitAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.RemitAmount, Id = Index.RemitAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemitAmount { get; set; }

        /// <summary>
        /// Gets or sets PaymentSchedDiscountAvail 
        /// </summary>
        [Display(Name = "PaymentSchedDiscountAvail", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PaymentSchedDiscountAvail, Id = Index.PaymentSchedDiscountAvail, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentSchedDiscountAvail { get; set; }

        /// <summary>
        /// Gets or sets TCPLineNumber 
        /// </summary>
        [Display(Name = "TCPLineNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.TCPLineNumber, Id = Index.TCPLineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal TCPLineNumber { get; set; }

        /// <summary>
        /// Gets or sets StartingVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartingVendorNumber", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.StartingVendorNumber, Id = Index.StartingVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string StartingVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets OriginalApply 
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalApply", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.OriginalApply, Id = Index.OriginalApply, FieldType = EntityFieldType.Char, Size = 1)]
        public string OriginalApply { get; set; }

        /// <summary>
        /// Gets or sets PendingPaymentAmount 
        /// </summary>
        [Display(Name = "PendingPaymentAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PendingPaymentAmount, Id = Index.PendingPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingDiscountAmount 
        /// </summary>
        [Display(Name = "PendingDiscountAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PendingDiscountAmount, Id = Index.PendingDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingAdjustmentAmount 
        /// </summary>
        [Display(Name = "PendingAdjustmentAmount", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PendingAdjustmentAmount, Id = Index.PendingAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingBalance 
        /// </summary>
        [Display(Name = "PendingBalance", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.PendingBalance, Id = Index.PendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingBalance { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocumentTotal 
        /// </summary>
        [Display(Name = "OriginalDocumentTotal", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.OriginalDocumentTotal, Id = Index.OriginalDocumentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalDocumentTotal { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>

        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited JobRelated { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalDocNo", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }

        /// <summary>
        /// Gets or sets OnHold 
        /// </summary>

        [ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchEdited OnHold { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1TC, Id = Index.AmtWHD1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2TC, Id = Index.AmtWHD2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3TC, Id = Index.AmtWHD3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4TC, Id = Index.AmtWHD4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5TC, Id = Index.AmtWHD5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Tax Withheld Amount Total
        /// </summary>
        [ViewField(Name = Fields.AmtWHDTot, Id = Index.AmtWHDTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.PndWHD1Tot, Id = Index.PndWHD1Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD1Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.PndWHD2Tot, Id = Index.PndWHD2Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD2Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.PndWHD3Tot, Id = Index.PndWHD3Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD3Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.PndWHD4Tot, Id = Index.PndWHD4Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD4Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.PndWHD5Tot, Id = Index.PndWHD5Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD5Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Total
        /// </summary>
        [ViewField(Name = Fields.PndWHDTot, Id = Index.PndWHDTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Document Tax Authority 1
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax1, Id = Index.CodeTax1, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax1 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 2
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax2, Id = Index.CodeTax2, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax2 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 3
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax3, Id = Index.CodeTax3, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax3 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 4
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax4, Id = Index.CodeTax4, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax4 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 5
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax5, Id = Index.CodeTax5, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax5 { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 1 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth1Description, Id = Index.TaxAuth1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth1Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 2 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth2Description, Id = Index.TaxAuth2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth2Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 3 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth3Description, Id = Index.TaxAuth3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth3Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 4 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth4Description, Id = Index.TaxAuth4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth4Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 5 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth5Description, Id = Index.TaxAuth5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth5Description { get; set; }


        /// <summary>
        /// Gets the string value of Document Type
        /// </summary>
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Gets the string value of Job Related
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "JobRelated", ResourceType = typeof(PaymentEntryResx))]
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets readonly JobApplyMethod 
        /// </summary>
        [Display(Name = "JobApplyMethod", ResourceType = typeof(PaymentEntryResx))]
        [ViewField(Name = Fields.JobApplyMethod, Id = Index.JobApplyMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public JobApplyMethod JobApplyMethod { get; set; }

    }
}
