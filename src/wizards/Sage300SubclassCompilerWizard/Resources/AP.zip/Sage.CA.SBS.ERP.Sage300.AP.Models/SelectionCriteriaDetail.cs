// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for Selection Criteria Detail
    /// </summary>
    public partial class SelectionCriteriaDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Selection Criteria 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "SelectionCriteria", ResourceType = typeof(PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.SelectionCriteria, Id = Index.SelectionCriteria, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string SelectionCriteria { get; set; }

        /// <summary>
        /// Gets or sets Exclude Vendor Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "ExcludeVendorNumber", ResourceType = typeof(PaymentSelectionCodesResx))]
        [ViewField(Name = Fields.ExcludeVendorNumber, Id = Index.ExcludeVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ExcludeVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets Unique key for grid rows
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Vendor Name 
        /// </summary>
        public string VendorName { get; set; }

    }
}
