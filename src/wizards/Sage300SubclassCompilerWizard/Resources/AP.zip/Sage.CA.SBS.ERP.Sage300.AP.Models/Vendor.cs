
/* Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Partial class for Vendor.
    /// </summary>
    public partial class Vendor : ModelBase
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public Vendor()
        {
            VendorComments = new EnumerableResponse<VendorComment>();
            VendorOptionalFieldValues = new EnumerableResponse<VendorOptionalFieldValue>();
            VendorContactForms = new EnumerableResponse<VendorContactForm>();
            Statistics = new VendorStatistics();
        }

        /// <summary>
        /// Gets or sets Vendor Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(VendorResx))]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets Short Name 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShortName", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.ShortName, Id = Index.ShortName, FieldType = EntityFieldType.Char, Size = 10)]
        public string ShortName { get; set; }

        /// <summary>
        /// Gets or sets Group Code 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GroupCode", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets Inactive Date 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets Last Maintained Date.
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastMaintainedDate, Id = Index.LastMaintainedDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastMaintainedDate { get; set; }

        /// <summary>
        /// Gets or sets OnHold 
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold OnHold { get; set; }

        /// <summary>
        /// Gets or sets Start Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartDate", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets Participant ID 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ParticipantId", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.ParticipantID, Id = Index.ParticipantID, FieldType = EntityFieldType.Char, Size = 12)]
        public string ParticipantID { get; set; }

        /// <summary>
        /// Gets or sets Vendor Name 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets Address Line1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets Address Line2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets Address Line3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets Address Line4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State Or Province
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.StateOrProvince, Id = Index.StateOrProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateOrProvince { get; set; }

        /// <summary>
        /// Gets or sets Zip Or Postal Code 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ZipOrPostalCode, Id = Index.ZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets Contact Name 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactName", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets Phone Number 
        /// </summary>
        [Display(Name = "PhoneNumber", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets Fax Number 
        /// </summary>
        [Display(Name = "FaxNumber", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Primary Remit To Location 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PrimaryRemitToLocation", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.PrimaryRemitToLocation, Id = Index.PrimaryRemitToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PrimaryRemitToLocation { get; set; }

        /// <summary>
        /// Gets or sets Account Set 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets Currency Code 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets Rate Type 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets Bank Code 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets Print Separate Checks 
        /// </summary>
        [Display(Name = "PrintSeparateChecks", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.PrintSeparateChecks, Id = Index.PrintSeparateChecks, FieldType = EntityFieldType.Int, Size = 2)]
        public PrintSeparateChecks PrintSeparateChecks { get; set; }

        /// <summary>
        /// Gets or sets Distribution Set 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionSet", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DistributionSet, Id = Index.DistributionSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionSet { get; set; }

        /// <summary>
        /// Gets or sets Distribution Code 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets GL Account 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLAccount", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets Terms 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Terms", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets Duplicate Invoice Code 
        /// </summary>
        [Display(Name = "DuplicateInvoiceCode", ResourceType = typeof(VendorResx))]
        public int DuplicateInvoiceCode { get; set; }

        /// <summary>
        /// Gets or sets Duplicate Amount Code 
        /// </summary>
        [Display(Name = "DuplicateAmountCode", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.DuplicateAmountCode, Id = Index.DuplicateAmountCode, FieldType = EntityFieldType.Int, Size = 2)]
        public DuplicateAmountCode DuplicateAmountCode { get; set; }

        /// <summary>
        /// Gets Duplicate Amount Code String
        /// </summary>
        [IgnoreExportImport]
        public string DuplicateAmountCodeString
        {
            get
            {
                return EnumUtility.GetStringValue(DuplicateAmountCode);
            }
        }

        /// <summary>
        /// Gets or sets Duplicate Date Code 
        /// </summary>
        [Display(Name = "DuplicateDateCode", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.DuplicateDateCode, Id = Index.DuplicateDateCode, FieldType = EntityFieldType.Int, Size = 2)]
        public DuplicateAmountCode DuplicateDateCode { get; set; }

        /// <summary>
        /// Gets Duplicate Date Code String
        /// </summary>
        [IgnoreExportImport]
        public string DuplicateDateCodeString
        {
            get
            {
                return EnumUtility.GetStringValue(DuplicateDateCode);
            }
        }

        /// <summary>
        /// Gets or sets Tax Group 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets Tax Class Code1 
        /// </summary>
        [Display(Name = "TaxClassCode1", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxClassCode1, Id = Index.TaxClassCode1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode1 { get; set; }

        /// <summary>
        /// Gets or sets Tax Class Code2 
        /// </summary>
        [Display(Name = "TaxClassCode2", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxClassCode2, Id = Index.TaxClassCode2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode2 { get; set; }

        /// <summary>
        /// Gets or sets Tax Class Code3 
        /// </summary>
        [Display(Name = "TaxClassCode3", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxClassCode3, Id = Index.TaxClassCode3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode3 { get; set; }

        /// <summary>
        /// Gets or sets Tax Class Code4 
        /// </summary>
        [Display(Name = "TaxClassCode4", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxClassCode4, Id = Index.TaxClassCode4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode4 { get; set; }

        /// <summary>
        /// Gets or sets Tax Class Code5 
        /// </summary>
        [Display(Name = "TaxClassCode5", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxClassCode5, Id = Index.TaxClassCode5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode5 { get; set; }

        /// <summary>
        /// Gets or sets Tax Reporting Type 
        /// </summary>
        [Display(Name = "TaxReportingType", ResourceType = typeof(VendorGroupResx))]
        [ViewField(Name = Fields.TaxReportingType, Id = Index.TaxReportingType, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxReportingType TaxReportingType { get; set; }

        /// <summary>
        /// Gets Tax Reporting Type String
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(TaxReportingType);
            }
        }

        /// <summary>
        /// Gets or sets Subject To WithHold 
        /// </summary>
        [Display(Name = "SubjectToWithHold", ResourceType = typeof(VendorResx))]
        public int SubjectToWithHold { get; set; }

        /// <summary>
        /// Gets or sets CPRS Tax Number 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CprsTaxNumber", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.CprsTaxNumber, Id = Index.CprsTaxNumber, FieldType = EntityFieldType.Char, Size = 20)]
        public string CprsTaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Tax Type 
        /// </summary>
        [Display(Name = "TaxType", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.TaxType, Id = Index.TaxType, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxType TaxType { get; set; }

        /// <summary>
        /// Gets Tax Type String
        /// </summary>
        [IgnoreExportImport]
        public string TaxTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(TaxType);
            }
        }

        /// <summary>
        /// Gets or sets Tax Note 2
        /// </summary>
        [Display(Name = "TaxNote2Sw", ResourceType = typeof(VendorResx))]
        public int TaxNote2Sw { get; set; }

        /// <summary>
        /// Gets or sets CPRS Code 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CPRSCode", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.CprsCode, Id = Index.CprsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CprsCode { get; set; }

        /// <summary>
        /// Gets or sets Credit Limit 
        /// </summary>
        [Display(Name = "CreditLimit", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.CreditLimit, Id = Index.CreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditLimit { get; set; }

        /// <summary>
        /// Gets or sets Balance Due in Vendor Currency 
        /// </summary>
        [Display(Name = "BalanceDueinVendorCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.BalanceDueinVendorCurrency, Id = Index.BalanceDueinVendorCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceDueinVendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets Balance Due in Functional Currency 
        /// </summary>
        [Display(Name = "BalanceDueinFunctionCurrency", ResourceType = typeof(VendorResx))]
        public decimal BalanceDueinFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Prepaid Invoice Vendor Currency
        /// </summary>
        [Display(Name = "TotalPrepaidInvoiceVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TotalPrepaidInvoiceVendCurrency, Id = Index.TotalPrepaidInvoiceVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalPrepaidInvoiceVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Prepaid Invoice Functional Currency 
        /// </summary>
        [Display(Name = "TotalPrepaidInvoiceFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TotalPrepaidInvoiceFunctionCurrency, Id = Index.TotalPrepaidInvoiceFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalPrepaidInvoiceFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Revaluation 
        /// </summary>
        [Display(Name = "DateofLastRevaluation", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofLastRevaluation, Id = Index.DateofLastRevaluation, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastRevaluation { get; set; }

        /// <summary>
        /// Gets or sets Last Revaluation Balance 
        /// </summary>
        [Display(Name = "LastRevaluationBalance", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastRevaluationBalance, Id = Index.LastRevaluationBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRevaluationBalance { get; set; }

        /// <summary>
        /// Gets or sets Number of Open Invoices 
        /// </summary>
        [Display(Name = "NumberofOpenInvoices", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.NumberofOpenInvoices, Id = Index.NumberofOpenInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofOpenInvoices { get; set; }

        /// <summary>
        /// Gets or sets Number of Prepaid Invoices 
        /// </summary>
        [Display(Name = "NumberofPrepaidInvoices", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.NumberofPrepaidInvoices, Id = Index.NumberofPrepaidInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPrepaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets Number of Paid Invoices 
        /// </summary>
        [Display(Name = "NumberofPaidInvoices", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.NumberofPaidInvoices, Id = Index.NumberofPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets Number of Days to Pay 
        /// </summary>
        [Display(Name = "NumberofDaystoPay", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.NumberofDaystoPay, Id = Index.NumberofDaystoPay, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets Date of Largest Invoice 
        /// </summary>
        [Display(Name = "DateofLargestInvoice", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofLargestInvoice, Id = Index.DateofLargestInvoice, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLargestInvoice { get; set; }

        /// <summary>
        /// Gets or sets Date of Highest Balance 
        /// </summary>
        [Display(Name = "DateofHighestBalance", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofHighestBalance, Id = Index.DateofHighestBalance, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofHighestBalance { get; set; }

        /// <summary>
        /// Gets or sets Date of Largest Invoice Last Year 
        /// </summary>
        [Display(Name = "DateofLargestInvoiceLastYr", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofLargestInvoiceLastYr, Id = Index.DateofLargestInvoiceLastYr, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLargestInvoiceLastYr { get; set; }

        /// <summary>
        /// Gets or sets Date of Highest Balance Last Year 
        /// </summary>
        [Display(Name = "DateofHighestBalanceLastYr", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofHighestBalanceLastYr, Id = Index.DateofHighestBalanceLastYr, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofHighestBalanceLastYr { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Activity 
        /// </summary>
        [Display(Name = "DateofLastActivity", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofLastActivity, Id = Index.DateofLastActivity, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastActivity { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Invoice 
        /// </summary>
        [Display(Name = "DateofLastInvoice", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofLastInvoice, Id = Index.DateofLastInvoice, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastInvoice { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Credit Note 
        /// </summary>
        [Display(Name = "DateofLastCreditNote", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofLastCreditNote, Id = Index.DateofLastCreditNote, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastCreditNote { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Debit Note 
        /// </summary>
        [Display(Name = "DateofLastDebitNote", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofLastDebitNote, Id = Index.DateofLastDebitNote, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastDebitNote { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Payment 
        /// </summary>
        [Display(Name = "DateofLastPayment", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofLastPayment, Id = Index.DateofLastPayment, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastPayment { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Discount 
        /// </summary>
        [Display(Name = "DateofLastDiscount", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofLastDiscount, Id = Index.DateofLastDiscount, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastDiscount { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Adjustment 
        /// </summary>
        [Display(Name = "DateofLastAdjustment", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DateofLastAdjustment, Id = Index.DateofLastAdjustment, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastAdjustment { get; set; }

        /// <summary>
        /// Gets or sets Number of Largest Invoice 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NumberofLargestInvoice", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.NumberofLargestInvoice, Id = Index.NumberofLargestInvoice, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string NumberofLargestInvoice { get; set; }

        /// <summary>
        /// Gets or sets Number of Largest Invoice Last Year
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NumberofLargestInvoiceLastY", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.NumberofLargestInvoiceLastY, Id = Index.NumberofLargestInvoiceLastY, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string NumberofLargestInvoiceLastY { get; set; }

        /// <summary>
        /// Gets or sets Largest Invoice Vend Currency
        /// </summary>
        [Display(Name = "LargestInvoiceVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LargestInvoiceVendCurrency, Id = Index.LargestInvoiceVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvoiceVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets Highest Balance Vend Currency 
        /// </summary>
        [Display(Name = "HighestBalanceVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.HighestBalanceVendCurrency, Id = Index.HighestBalanceVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighestBalanceVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets Amount Without Currency 
        /// </summary>
        [Display(Name = "AmountWithoutCurrency", ResourceType = typeof(VendorResx))]
        public decimal AmountWithoutCurrency { get; set; }

        /// <summary>
        /// Gets or sets Largest Invest Last Year Vendor Currency
        /// </summary>
        [Display(Name = "LargestInvLastYrVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LargestInvLastYrVendCurrency, Id = Index.LargestInvLastYrVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvLastYrVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets High Balance Last Year Vendor Currency.
        /// </summary>
        [Display(Name = "HighBalLastYrVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.HighBalLastYrVendCurrency, Id = Index.HighBalLastYrVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighBalLastYrVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets Amount with. 
        /// </summary>
        [IgnoreExportImport]
        public decimal Amountwithlytc { get; set; }

        /// <summary>
        /// Gets or sets Last Invoice Amount Vendor Currency
        /// </summary>
        [Display(Name = "LastInvoiceAmtVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastInvoiceAmtVendCurrency, Id = Index.LastInvoiceAmtVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmtVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets Last Credit Note Amount Vendor Currency 
        /// </summary>
        [Display(Name = "LastCrNoteAmtVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastCrNoteAmtVendCurrency, Id = Index.LastCrNoteAmtVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastCrNoteAmtVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets Last Dr Note Amount Vendor Currency. 
        /// </summary>
        [Display(Name = "LastDrNoteAmtVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastDrNoteAmtVendCurrency, Id = Index.LastDrNoteAmtVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDrNoteAmtVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets Last Payment Vendor Currency. 
        /// </summary>
        [Display(Name = "LastPaymentVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastPaymentVendCurrency, Id = Index.LastPaymentVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastPaymentVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets Last Discount Amount Vendor Currency
        /// </summary>
        [Display(Name = "LastDiscountAmtVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastDiscountAmtVendCurrency, Id = Index.LastDiscountAmtVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDiscountAmtVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets LastAdjustment Amount Vendor Currency.
        /// </summary>
        [Display(Name = "LastAdjAmtVendCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastAdjAmtVendCurrency, Id = Index.LastAdjAmtVendCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastAdjAmtVendCurrency { get; set; }

        /// <summary>
        /// Gets or sets Largest Invoice Function Currency
        /// </summary>
        [Display(Name = "LargestInvoiceFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LargestInvoiceFunctionCurrency, Id = Index.LargestInvoiceFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvoiceFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Highest Balance Function Currency
        /// </summary>
        [Display(Name = "HighestBalanceFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.HighestBalanceFunctionCurrency, Id = Index.HighestBalanceFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighestBalanceFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Amount With Currency 
        /// </summary>
        [Display(Name = "AmountWithCurrency", ResourceType = typeof(VendorResx))]
        public decimal AmountWithCurrency { get; set; }

        /// <summary>
        /// Gets or sets Largest Invest Last Year Function Currency. 
        /// </summary>
        [Display(Name = "LargestInvestLastYearFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LargestInvestLastYearFunctionCurrency, Id = Index.LargestInvestLastYearFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvestLastYearFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets High Balance Last Year Function Currency.
        /// </summary>
        [Display(Name = "HighBalLastYearFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.HighBalLastYearFunctionCurrency, Id = Index.HighBalLastYearFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighBalLastYearFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Amount with lyhc. 
        /// </summary>
        [IgnoreExportImport]
        public decimal Amountwithlyhc { get; set; }

        /// <summary>
        /// Gets or sets Last Invoice Amount Function Currency.
        /// </summary>
        [Display(Name = "LastInvoiceAmtFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastInvoiceAmtFunctionCurrency, Id = Index.LastInvoiceAmtFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmtFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Last Credit Note Amount Function Currency 
        /// </summary>
        [Display(Name = "LastCrNoteAmtFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastCrNoteAmtFunctionCurrency, Id = Index.LastCrNoteAmtFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastCrNoteAmtFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Last Dr Note Amount Function Currency 
        /// </summary>
        [Display(Name = "LastDrNoteAmtFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastDrNoteAmtFunctionCurrency, Id = Index.LastDrNoteAmtFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDrNoteAmtFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Last Payment Function Currency
        /// </summary>
        [Display(Name = "LastPaymentFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastPaymentFunctionCurrency, Id = Index.LastPaymentFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastPaymentFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Last Discount Amount Function Currency.
        /// </summary>
        [Display(Name = "LastDiscountAmtFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastDiscountAmtFunctionCurrency, Id = Index.LastDiscountAmtFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDiscountAmtFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Last Adjustment Amount Function Currency 
        /// </summary>
        [Display(Name = "LastAdjAmtFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastAdjAmtFunctionCurrency, Id = Index.LastAdjAmtFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastAdjAmtFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Payment Code 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentCode", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets Tax Registration Code1 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRegistrationCode1", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxRegistrationCode1, Id = Index.TaxRegistrationCode1, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationCode1 { get; set; }

        /// <summary>
        /// Gets or sets Tax Registration Code2 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRegistrationCode2", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxRegistrationCode2, Id = Index.TaxRegistrationCode2, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationCode2 { get; set; }

        /// <summary>
        /// Gets or sets Tax Registration Code3 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRegistrationCode3", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxRegistrationCode3, Id = Index.TaxRegistrationCode3, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationCode3 { get; set; }

        /// <summary>
        /// Gets or sets Tax Registration Code4 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRegistrationCode4", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxRegistrationCode4, Id = Index.TaxRegistrationCode4, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationCode4 { get; set; }

        /// <summary>
        /// Gets or sets Tax Registration Code5 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRegistrationCode5", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxRegistrationCode5, Id = Index.TaxRegistrationCode5, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationCode5 { get; set; }

        /// <summary>
        /// Gets or sets Distribution Type 
        /// </summary>
        [Display(Name = "DistributionType", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DistributionType, Id = Index.DistributionType, FieldType = EntityFieldType.Int, Size = 2)]
        public DistributionType DistributionType { get; set; }

        /// <summary>
        /// Gets Distribution Type String
        /// </summary>
        [IgnoreExportImport]
        public string DistributionTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(DistributionType);
            }
        }

        /// <summary>
        /// Gets or sets Check Language 
        /// </summary>
        [Display(Name = "CheckLanguage", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.CheckLanguage, Id = Index.CheckLanguage, FieldType = EntityFieldType.Char, Size = 3)]
        public CheckLanguage CheckLanguage { get; set; }

        /// <summary>
        /// Gets Check Language String
        /// </summary>
        [IgnoreExportImport]
        public string CheckLanguageString
        {
            get
            {
                return EnumUtility.GetStringValue(CheckLanguage);
            }
        }

        /// <summary>
        /// Gets or sets Average Days to Pay 
        /// </summary>
        [Display(Name = "AverageDaystoPay", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.AverageDaystoPay, Id = Index.AverageDaystoPay, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 1)]
        public decimal AverageDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets Average Payment 
        /// </summary>
        [Display(Name = "AveragePayment", ResourceType = typeof(VendorResx))]
        public decimal AveragePayment { get; set; }

        /// <summary>
        /// Gets or sets Total Invoices Paid Function Currency
        /// </summary>
        [Display(Name = "TotalInvoicesPaidFunctionCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TotalInvoicesPaidFunctionCurrency, Id = Index.TotalInvoicesPaidFunctionCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInvoicesPaidFunctionCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Invoices Paid Vendor Currency.
        /// </summary>
        [Display(Name = "TotalInvoicesPaidVendorCurrency", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TotalInvoicesPaidVendorCurrency, Id = Index.TotalInvoicesPaidVendorCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInvoicesPaidVendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Number of Payments 
        /// </summary>
        [Display(Name = "TotalNumberofPayments", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TotalNumberofPayments, Id = Index.TotalNumberofPayments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal TotalNumberofPayments { get; set; }

        /// <summary>
        /// Gets or sets Tax Included1 
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets Tax Included2 
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets Tax Included3 
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets Tax Included4 
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets Tax Included5 
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets Tax Included1 String
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncluded1String
        {
            get
            {
                return EnumUtility.GetStringValue(TaxIncluded1);
            }
        }

        /// <summary>
        /// Gets Tax Included2 String
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncluded2String
        {
            get
            {
                return EnumUtility.GetStringValue(TaxIncluded2);
            }
        }

        /// <summary>
        /// Gets Tax Included3 String
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncluded3String
        {
            get
            {
                return EnumUtility.GetStringValue(TaxIncluded3);
            }
        }

        /// <summary>
        /// Gets Tax Included4 String
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncluded4String
        {
            get
            {
                return EnumUtility.GetStringValue(TaxIncluded4);
            }
        }

        /// <summary>
        /// Gets Tax Included5 String
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncluded5String
        {
            get
            {
                return EnumUtility.GetStringValue(TaxIncluded5);
            }
        }

        /// <summary>
        /// Gets or sets Contacts Email 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactsEmail", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.ContactsEmail, Id = Index.ContactsEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactsEmail { get; set; }

        /// <summary>
        /// Gets or sets Email 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets WebSite 
        /// </summary>
        [StringLength(100, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WebSite", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.WebSite, Id = Index.WebSite, FieldType = EntityFieldType.Char, Size = 100)]
        public string WebSite { get; set; }

        /// <summary>
        /// Gets or sets Contacts Phone 
        /// </summary>
        [Display(Name = "ContactsPhone", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.ContactsPhone, Id = Index.ContactsPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsPhone { get; set; }

        /// <summary>
        /// Gets or sets Contacts Fax 
        /// </summary>
        [Display(Name = "ContactsFax", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.ContactsFax, Id = Index.ContactsFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsFax { get; set; }

        /// <summary>
        /// Gets or sets Delivery Method 
        /// </summary>
        [Display(Name = "DeliveryMethod", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.DeliveryMethod, Id = Index.DeliveryMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public DeliveryMethod DeliveryMethod { get; set; }

        /// <summary>
        /// Gets Delivery Method String
        /// </summary>
        [IgnoreExportImport]
        public string DeliveryMethodString
        {
            get
            {
                return EnumUtility.GetStringValue(DeliveryMethod);
            }
        }

        /// <summary>
        /// Gets or sets Percent Retained 
        /// </summary>
        [Display(Name = "PercentRetained", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.PercentRetained, Id = Index.PercentRetained, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentRetained { get; set; }

        /// <summary>
        /// Gets or sets Days Retained 
        /// </summary>
        [Display(Name = "DaysRetained", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.DaysRetained, Id = Index.DaysRetained, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysRetained { get; set; }

        /// <summary>
        /// Gets or sets Retain age Terms Code 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageTermsCode", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets Amount Retained Vendor Currency 
        /// </summary>
        [Display(Name = "AmountRetainedVendCurr", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.AmountRetainedVendCurr, Id = Index.AmountRetainedVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountRetainedVendCurr { get; set; }

        /// <summary>
        /// Gets or sets Amount Retained Function Currency 
        /// </summary>
        [Display(Name = "AmountRetainedFuncCurr", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.AmountRetainedFuncCurr, Id = Index.AmountRetainedFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountRetainedFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Process Command Code 
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCodeSelect ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets Process Command Code String
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandCodeString
        {
            get
            {
                return EnumUtility.GetStringValue(ProcessCommandCode);
            }
        }

        /// <summary>
        /// Gets or sets NextClientUniqueID 
        /// </summary>
        [Display(Name = "NextClientUniqueID", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.NextClientUniqueID, Id = Index.NextClientUniqueID, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextClientUniqueID { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields count
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(VendorResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets LegalName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorLegalName", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.VendorLegalName, Id = Index.VendorLegalName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorLegalName { get; set; }

        /// <summary>
        /// Gets or sets LegalName. This is used only for Export / Import.
        /// </summary>
        [Display(Name = "VendorLegalName", ResourceType = typeof(VendorResx))]
        [IgnoreExportImport]
        public string LegalName { get; set; }

        /// <summary>
        /// Gets or sets Zero1099AmountWarning 
        /// </summary>
        [Display(Name = "Zero1099AmountWarning", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.Zero1099AmountWarning, Id = Index.Zero1099AmountWarning, FieldType = EntityFieldType.Int, Size = 2)]
        public Zero1099AmountWarning Zero1099AmountWarning { get; set; }

        /// <summary>
        /// Gets Zero 1099 Amount Warning String
        /// </summary>
        [IgnoreExportImport]
        public string Zero1099AmountWarningString
        {
            get
            {
                return EnumUtility.GetStringValue(Zero1099AmountWarning);
            }
        }

        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets Suppress Integration 
        /// </summary>
        [Display(Name = "SuppressIntegration", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.SuppressIntegration, Id = Index.SuppressIntegration, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SuppressIntegration { get; set; }

        /// <summary>
        /// Gets or sets AP Version 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApVersion", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.ApVersion, Id = Index.ApVersion, FieldType = EntityFieldType.Char, Size = 3)]
        public string ApVersion { get; set; }

        /// <summary>
        /// Gets or sets Database 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Database", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.Database, Id = Index.Database, FieldType = EntityFieldType.Char, Size = 6)]
        public string Database { get; set; }

        /// <summary>
        /// Gets or sets Mode 
        /// </summary>
        [Display(Name = "Mode", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.Mode, Id = Index.Mode, FieldType = EntityFieldType.Int, Size = 2)]
        public Mode Mode { get; set; }


        /// <summary>
        /// Gets or sets Business Registration Number 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BusinessRegistrationNumber", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.BusinessRegistrationNumber, Id = Index.BusinessRegistrationNumber, FieldType = EntityFieldType.Char, Size = 30)]
        public string BusinessRegistrationNumber { get; set; }

        /// <summary>
        /// Gets or sets First Name
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FirstName", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.FirstName, Id = Index.FirstName, FieldType = EntityFieldType.Char, Size = 15)]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets LastName
        /// </summary>
        [StringLength(25, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastName", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.LastName, Id = Index.LastName, FieldType = EntityFieldType.Char, Size = 25)]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets FATCA
        /// </summary>
        [Display(Name = "FATCA", ResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FATCA, Id = Index.FATCA, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FATCA { get; set; }

        /// <summary>
        /// Gets or sets Second TIN Notice
        /// </summary>
        [Display(Name = "SecondTINNotice", ResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SecondTINNotice, Id = Index.SecondTINNotice, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SecondTINNotice { get; set; }

        /// <summary>
        /// Gets or sets Tax Withholding State
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxWithholdingState", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.TaxWithholdingState, Id = Index.TaxWithholdingState, FieldType = EntityFieldType.Char, Size = 2)]
        public string TaxWithholdingState { get; set; }

        /// <summary>
        /// Gets Mode String
        /// </summary>
        [IgnoreExportImport]
        public string ModeString
        {
            get
            {
                return EnumUtility.GetStringValue(Mode);
            }
        }

        /// <summary>
        /// Gets or sets List of AP Vendor Optional Fields values
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<VendorOptionalFieldValue> VendorOptionalFieldValues { get; set; }
        /// <summary>
        /// Gets or sets List of AP Contact Forms
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<VendorContactForm> VendorContactForms { get; set; }

        /// <summary>
        /// Gets or sets List of AP Vendor Comments
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<VendorComment> VendorComments { get; set; }


        /// <summary>
        /// Gets or sets List of Vendor Statistics
        /// </summary>
        [IgnoreExportImport]
        public VendorStatistics Statistics { get; set; }

        /// <summary>
        /// Gets or sets SessionDate
        /// </summary>
        [Display(Name = "SessionDate", ResourceType = typeof(CommonResx))]
        [IgnoreExportImport]
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets the Comments Expiration Date
        /// </summary>
        [IgnoreExportImport]
        public DateTime CommentsExpirationDate
        {
            get
            {
                return SessionDate.AddDays(Convert.ToDouble(NoDaysToKeepComment));

            }
        }

        /// <summary>
        /// Gets or sets NoDaysToKeepComment
        /// </summary>
        [IgnoreExportImport]
        public decimal NoDaysToKeepComment { get; set; }

        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        [Display(Name = "CompanyProfile", ResourceType = typeof(VendorResx))]
        [IgnoreExportImport]
        public CompanyProfile CompanyProfile { get; set; }

        #region User Entered

        /// <summary>
        /// Gets Status string.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        public string StatusString
        {
            get
            {
                return EnumUtility.GetStringValue(Status);
            }
        }

        /// <summary>
        /// Gets On Hold string.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OnHold", ResourceType = typeof(VendorResx))]
        public string OnHoldString
        {
            get
            {
                return EnumUtility.GetStringValue(OnHold);
            }
        }

        /// <summary>
        /// Gets OnHold Boolean value.
        /// </summary>
        [IgnoreExportImport]
        public bool OnHoldBool
        {
            get
            {
                return OnHold == OnHold.OnHold;
            }
        }

        /// <summary>
        /// Gets Inactive As Of
        /// </summary>
        [IgnoreExportImport]
        public bool InActiveAsOf
        {
            get
            {
                if (Status != Status.Active)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Gets Print Separate Checks Boolean Value.
        /// </summary>
        [IgnoreExportImport]
        public bool PrintSeparateChecksBool
        {
            get
            {
                return PrintSeparateChecks == PrintSeparateChecks.PrintSeparateChecks;
            }
        }

        /// <summary>
        /// Gets Print Separate Checks String Value.
        /// </summary>
        [Display(Name = "PrintSeparateChecks", ResourceType = typeof(VendorResx))]
        public string PrintSeparateChecksString
        {
            get
            {
                return EnumUtility.GetStringValue(PrintSeparateChecks);
            }
        }

        /// <summary>
        /// Fiscal Period Start  year
        /// </summary>
        public string StartYear { get; set; }

        /// <summary>
        /// Fiscal Period End year
        /// </summary>
        public string EndYear { get; set; }

        /// <summary>
        /// Fiscal Year
        /// </summary>
        [Display(Name = "FiscalYear", ResourceType = typeof(APCommonResx))]
        public DateTime FiscalYear { get; set; }

        /// <summary>
        /// Fiscal Period
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(APCommonResx))]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets suppress Integration String
        /// </summary>
        [Display(Name = "SuppressIntegration", ResourceType = typeof(VendorResx))]
        [IgnoreExportImport]
        public string SuppressIntegrationString
        {
            get
            {
                if (SuppressIntegration == false)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
            }
        }

        /// <summary>
        /// Gets the DateTime Value of String LastMaintainedDate
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(VendorResx))]
        [IgnoreExportImport]
        public string LastMaintainedDateString
        {
            get
            {
                return DateUtil.GetShortDate(LastMaintainedDate, string.Empty);
            }
        }

        /// <summary>
        /// Gets the DateTime Value of String InactiveDate
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(VendorResx))]
        [IgnoreExportImport]
        public string InactiveDateString
        {
            get
            {
                return (Status != Status.Active) ? DateUtil.GetShortDate(InactiveDate, string.Empty) : string.Empty;
            }
        }

        /// <summary>
        /// Checks Vendor in new or exist
        /// </summary>
        [IgnoreExportImport]
        public bool IsNewRecord { get; set; }


        /// <summary>
        /// Checks Optional fields tab loaded or not
        /// </summary> 
        [IgnoreExportImport]
        public bool IsOptinalFieldLoaded { get; set; }

        /// <summary>
        /// Gets or Sets IsMultiCurrency
        /// </summary>
        [IgnoreExportImport]
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets IsStatisticsDirty
        /// </summary>
        public bool IsStatisticsDirty { get; set; }

        /// <summary>
        /// Gets or sets DeliveryMethodList
        /// </summary>
        public IEnumerable<CustomSelectList> DeliveryMethodList { get; set; }

        #endregion
    }
}
