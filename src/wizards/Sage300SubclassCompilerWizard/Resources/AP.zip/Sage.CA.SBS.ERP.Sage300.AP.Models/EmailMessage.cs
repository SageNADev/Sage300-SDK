// /* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class EmailMessage : ModelBase
    {
        /// <summary>
        /// Gets or sets MessageType 
        /// </summary> 
        [Display(Name = "MessageType", ResourceType = typeof(EmailMessageResx))]
        [Key]
        [ViewField(Name = Fields.MessageType, Id = Index.MessageType, FieldType = EntityFieldType.Int, Size = 2)]
        public MessageType MessageType { get; set; }

        /// <summary>
        /// Gets or sets MessageType Description for showing Message Type as text instead of numeric
        /// </summary> 
        public string MessageTypeDescription
        {
            get { return EnumUtility.GetStringValue(MessageType); }
            set { }
        }

        /// <summary>
        /// Gets or sets MessageID 
        /// </summary>   
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "MessageID", ResourceType = typeof (EmailMessageResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.MessageID, Id = Index.MessageID, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string MessageID { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (EmailMessageResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>  
        [Display(Name = "Status", ResourceType = typeof(EmailMessageResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or set IsStatusActive is for validating the inactive checkbox
        /// </summary> 
        public bool IsStatusActive
        {
            get { return Status == Status.Inactive; }
            set { Status = value == false ? Status.Active : Status.Inactive; }
        }

        /// <summary>
        /// Gets or sets Status Description for showing status as text instead of numeric
        /// </summary> 
        public string StatusDescription { get { return EnumUtility.GetStringValue(Status); } set { } }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary> 
        [Display(Name = "InactiveDate", ResourceType = typeof (EmailMessageResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string InactiveDate { get; set; }

        /// <summary>
        /// Gets Conversion of InactiveDate into DateTime 
        /// </summary>
        [IgnoreExportImport]
        public DateTime InactiveDateTime
        {
            get
            {
                return DateUtil.GetDate(InactiveDate, DateUtil.GetMinDate());
            }

        }
        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "DateLastMaintained", ResourceType = typeof (EmailMessageResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets Conversion of InactiveDate into DateTime 
        /// </summary>
        [IgnoreExportImport]
        public DateTime DateTimeLastMaintained
        {
            get
            {
                return DateUtil.GetDate(DateLastMaintained, DateUtil.GetNowDate());
            }

        }
        /// <summary>
        /// Gets or sets EmailSubject 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "EmailSubject", ResourceType = typeof (EmailMessageResx))]
        [ViewField(Name = Fields.EmailSubject, Id = Index.EmailSubject, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailSubject { get; set; }

        /// <summary>
        /// Gets or sets EmailBody1 
        /// </summary>
         [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBody1, Id = Index.EmailBody1, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBody1 { get; set; }

        /// <summary>
         /// Gets or sets EmailBody2 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBody2, Id = Index.EmailBody2, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBody2 { get; set; }

        /// <summary>
        /// Gets or sets EmailBody3 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBody3, Id = Index.EmailBody3, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBody3 { get; set; }

        /// <summary>
        /// Gets or sets EmailBody4 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBody4, Id = Index.EmailBody4, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBody4 { get; set; }

        /// <summary>
        /// Gets or sets EmailBody4 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBody5, Id = Index.EmailBody5, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBody5 { get; set; }

        /// <summary>
        /// Gets or sets EmailBody6 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBody6, Id = Index.EmailBody6, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBody6 { get; set; }

        /// <summary>
        /// Gets or sets EmailBody7 
        /// </summary> 
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBody7, Id = Index.EmailBody7, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBody7 { get; set; }

        /// <summary>
        /// Gets or sets EmailBody8 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBody8, Id = Index.EmailBody8, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBody8 { get; set; }

        /// <summary>
        /// Gets or sets EmailBody9 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBody9, Id = Index.EmailBody9, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBody9 { get; set; }

        /// <summary>
        /// Gets or sets EmailBody10 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBody10, Id = Index.EmailBody10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBody10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBody 
        /// </summary> 
        [StringLength(2500, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmailBody", ResourceType = typeof(EmailMessageResx))]
        [ViewField(Name = Fields.EmailBody, Id = Index.EmailBody, FieldType = EntityFieldType.Char, Size = 2500)]
        public string EmailBody { get; set; }
    }
}
