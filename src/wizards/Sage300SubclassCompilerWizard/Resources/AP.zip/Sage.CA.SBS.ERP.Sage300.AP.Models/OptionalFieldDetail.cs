// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Entity for Optional Field
    /// </summary>
    public partial class OptionalFieldDetail : ModelBase
    {

        /// <summary>
        /// Gets or sets Location 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Location", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Location Location { get; set; }

        /// <summary>
        /// Gets or sets OptionalField 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "OptionalField", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets DefaultValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultValue, Id = Index.DefaultValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultValue { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public OptionalFieldType Type { get; set; }

        /// <summary>
        /// Gets or sets Length 
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals 
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank 
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate 
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank Validate { get; set; }

        /// <summary>
        /// Gets or sets AutoInsert 
        /// </summary>
        [Display(Name = "AutoInsert", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AutoInsert, Id = Index.AutoInsert, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank AutoInsert { get; set; }

        /// <summary>
        /// Gets or sets Payable Control 
        /// </summary>
        [Display(Name = "PayablesControl", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.PayablesControl, Id = Index.PayablesControl, FieldType = EntityFieldType.Int, Size = 2)]
        public bool PayablesControl { get; set; }

        /// <summary>
        /// Gets or sets Retainage 
        /// </summary>
        [Display(Name = "Retainage", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Retainage, Id = Index.Retainage, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Retainage { get; set; }

        /// <summary>
        /// Gets or sets PurchaseDiscount 
        /// </summary>
        [Display(Name = "PurchaseDiscount", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.PurchaseDiscount, Id = Index.PurchaseDiscount, FieldType = EntityFieldType.Int, Size = 2)]
        public bool PurchaseDiscount { get; set; }

        /// <summary>
        /// Gets or sets RecoverableTax 
        /// </summary>
        [Display(Name = "RecoverableTax", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.RecoverableTax, Id = Index.RecoverableTax, FieldType = EntityFieldType.Int, Size = 2)]
        public bool RecoverableTax { get; set; }

        /// <summary>
        /// Gets or sets ExpenseTax 
        /// </summary>
        [Display(Name = "ExpenseTax", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ExpenseTax, Id = Index.ExpenseTax, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ExpenseTax { get; set; }

        /// <summary>
        /// Gets or sets ExchangeGain 
        /// </summary>
        [Display(Name = "ExchangeGain", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ExchangeGain, Id = Index.ExchangeGain, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets ExchangeLoss 
        /// </summary>
        [Display(Name = "ExchangeLoss", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.ExchangeLoss, Id = Index.ExchangeLoss, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeGain 
        /// </summary>
        [Display(Name = "UnrealizedExchangeGain", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.UnrealizedExchangeGain, Id = Index.UnrealizedExchangeGain, FieldType = EntityFieldType.Int, Size = 2)]
        public bool UnrealizedExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeLoss 
        /// </summary>
        [Display(Name = "UnrealizedExchangeLoss", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.UnrealizedExchangeLoss, Id = Index.UnrealizedExchangeLoss, FieldType = EntityFieldType.Int, Size = 2)]
        public bool UnrealizedExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets Rounding 
        /// </summary>
        [Display(Name = "Rounding", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Rounding, Id = Index.Rounding, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Rounding { get; set; }

        /// <summary>
        /// Gets or sets Distribution 
        /// </summary>
        [Display(Name = "Distribution", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Distribution, Id = Index.Distribution, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Distribution { get; set; }

        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>
        [Display(Name = "Prepayment", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Prepayment, Id = Index.Prepayment, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Prepayment { get; set; }

        /// <summary>
        /// Gets or sets MiscellaneousPayment 
        /// </summary>
        [Display(Name = "MiscellaneousPayment", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.MiscellaneousPayment, Id = Index.MiscellaneousPayment, FieldType = EntityFieldType.Int, Size = 2)]
        public bool MiscellaneousPayment { get; set; }

        /// <summary>
        /// Gets or sets Bank 
        /// </summary>
        [Display(Name = "Bank", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Bank, Id = Index.Bank, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Bank { get; set; }

        /// <summary>
        /// Gets or sets Adjustment 
        /// </summary>
        [Display(Name = "Adjustment", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Adjustment, Id = Index.Adjustment, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Adjustment { get; set; }

        /// <summary>
        /// Gets or sets ExternalCostTransactions 
        /// </summary>
        [Display(Name = "ExternalCostTransactions", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ExternalCostTransactions, Id = Index.ExternalCostTransactions, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ExternalCostTransactions { get; set; }

        /// <summary>
        /// Gets or sets Required 
        /// </summary>
        [Display(Name = "Required", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Required, Id = Index.Required, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank Required { get; set; }

        /// <summary>
        /// Gets or sets ValueSet 
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank ValueSet { get; set; }

        /// <summary>
        /// Gets or sets TypedDefaultValueFieldIndex 
        /// </summary>
        [Display(Name = "TypedDefaultValueFieldIndex", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TypedDefaultValueFieldIndex, Id = Index.TypedDefaultValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedDefaultValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets DefaultTextValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultTextValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTextValue, Id = Index.DefaultTextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultTextValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultAmountValue 
        /// </summary>
        [Display(Name = "DefaultAmountValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultAmountValue, Id = Index.DefaultAmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DefaultAmountValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultNumberValue 
        /// </summary>
        [Display(Name = "DefaultNumberValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultNumberValue, Id = Index.DefaultNumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DefaultNumberValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultIntegerValue 
        /// </summary>
        [Display(Name = "DefaultIntegerValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultIntegerValue, Id = Index.DefaultIntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long DefaultIntegerValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultYesOrNoValue 
        /// </summary>
        [Display(Name = "DefaultYesOrNoValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultYesOrNoValue, Id = Index.DefaultYesOrNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank DefaultYesOrNoValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultDateValue 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultDateValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultDateValue, Id = Index.DefaultDateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DefaultDateValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultTimeValue 
        /// </summary>
        [Display(Name = "DefaultTimeValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTimeValue, Id = Index.DefaultTimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime DefaultTimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultValueDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValueDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultValueDescription, Id = Index.DefaultValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultValueDescription { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number.</value>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFieldsValue DefaultOptionField { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public CS.Models.OptionalFields DefaultOptionFieldValue { get; set; }


        /// <summary>
        /// Get or set for MultiCurrency
        /// </summary>
        [IgnoreExportImport]
        public bool IsMultiCurrrency { get; set; }

        /// <summary>
        /// Get or set for MultiCurrency
        /// </summary>
        [IgnoreExportImport]
        public bool RetainageAccount { get; set; }
    }
}
