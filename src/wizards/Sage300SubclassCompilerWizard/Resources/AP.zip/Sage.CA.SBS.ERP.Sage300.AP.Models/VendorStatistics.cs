/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Name spaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Partial class for Vendor Statistics
    /// </summary>
	public partial class VendorStatistics : ModelBase
	{
  		/// <summary>
        /// Gets or sets Vendor Number 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(VendorResx))]
        [Key]
 		[ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
 		public string VendorNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof(CommonResx))]
        [Key]
 		[ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
 		public string Year {get; set;}
		 
  		/// <summary>
        /// Gets or sets Period 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(CommonResx))]
        [Key]
 		[ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
 		public string Period {get; set;}
		 
  		/// <summary>
        /// Gets or sets Number of Invoices 
        /// </summary>
        [Display(Name = "NumberofInvoices", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.NumberofInvoices, Id = Index.NumberofInvoices, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberofInvoices {get; set;}
		 
  		/// <summary>
        /// Gets or sets Number of Credit Notes 
        /// </summary>
        [Display(Name = "NumberofCreditNotes", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.NumberofCreditNotes, Id = Index.NumberofCreditNotes, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberofCreditNotes {get; set;}
		 
  		/// <summary>
        /// Gets or sets Number of Debit Notes 
        /// </summary>
        [Display(Name = "NumberofDebitNotes", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.NumberofDebitNotes, Id = Index.NumberofDebitNotes, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberofDebitNotes {get; set;}
		 
  		/// <summary>
        /// Gets or sets Number of Payments 
        /// </summary>
        [Display(Name = "NumberofPayments", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.NumberofPayments, Id = Index.NumberofPayments, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberofPayments {get; set;}
		 
  		/// <summary>
        /// Gets or sets Number of Discounts 
        /// </summary>
        [Display(Name = "NumberofDiscounts", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.NumberofDiscounts, Id = Index.NumberofDiscounts, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberofDiscounts {get; set;}
		 
  		/// <summary>
        /// Gets or sets Number o fDiscounts Lost 
        /// </summary>
        [Display(Name = "NumberofDiscountsLost", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.NumberofDiscountsLost, Id = Index.NumberofDiscountsLost, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberofDiscountsLost {get; set;}
		 
  		/// <summary>
        /// Gets or sets Number of Adjustments 
        /// </summary>
        [Display(Name = "NumberofAdjustments", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.NumberofAdjustments, Id = Index.NumberofAdjustments, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberofAdjustments {get; set;}
		 
  		/// <summary>
        /// Gets or sets Number o fPaid Invoices 
        /// </summary>
        [Display(Name = "NumberofPaidInvoices", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.NumberofPaidInvoices, Id = Index.NumberofPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberofPaidInvoices {get; set;}
		 
  		/// <summary>
        /// Gets or sets Number of Days to Pay 
        /// </summary>
        [Display(Name = "NumberofDaystoPay", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.NumberofDaystoPay, Id = Index.NumberofDaystoPay, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberofDaystoPay {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Invoices in Function Currency 
        /// </summary>
        [Display(Name = "TotalInvoicesinFuncCurrency", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalInvoicesinFuncCurrency, Id = Index.TotalInvoicesinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInvoicesinFuncCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Credits in Function Currency 
        /// </summary>
        [Display(Name = "TotalCreditsinFuncCurrency", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalCreditsinFuncCurrency, Id = Index.TotalCreditsinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalCreditsinFuncCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Debits in Function Currency 
        /// </summary>
        [Display(Name = "TotalDebitsinFuncCurrency", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalDebitsinFuncCurrency, Id = Index.TotalDebitsinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDebitsinFuncCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Payments in Function Currency 
        /// </summary>
        [Display(Name = "TotalPaymentsinFuncCurrency", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalPaymentsinFuncCurrency, Id = Index.TotalPaymentsinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalPaymentsinFuncCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Discounts in Function Currency
        /// </summary>
        [Display(Name = "TotalDiscountsinFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalDiscountsinFuncCurr, Id = Index.TotalDiscountsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDiscountsinFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Discounts Lost Function Currency
        /// </summary>
        [Display(Name = "TotalDiscountsLostFuncCur", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalDiscountsLostFuncCur, Id = Index.TotalDiscountsLostFuncCur, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDiscountsLostFuncCur {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Adjustments in Function Currency
        /// </summary>
        [Display(Name = "TotalAdjustmentsinFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalAdjustmentsinFuncCurr, Id = Index.TotalAdjustmentsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalAdjustmentsinFuncCurr {get; set;}
  
  		/// <summary>
        /// Gets or sets Amount purchased
        /// </summary>
        public decimal Amtpurhc { get; set; }
		 
  		/// <summary>
        /// Gets or sets Total Invoices Purchased in Function Currency 
        /// </summary>
        [Display(Name = "TotalInvoicesPdinFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalInvoicesPdinFuncCurr, Id = Index.TotalInvoicesPdinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInvoicesPdinFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Invoices in Vendor Currency
        /// </summary>
        [Display(Name = "TotalInvoicesinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalInvoicesinVendCurr, Id = Index.TotalInvoicesinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInvoicesinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Credits in Vendor Currency
        /// </summary>
        [Display(Name = "TotalCreditsinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalCreditsinVendCurr, Id = Index.TotalCreditsinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalCreditsinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDebitsinVendCurr 
        /// </summary>
        [Display(Name = "TotalDebitsinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalDebitsinVendCurr, Id = Index.TotalDebitsinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDebitsinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Payments in Vendor Currency
        /// </summary>
        [Display(Name = "TotalPaymentsinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalPaymentsinVendCurr, Id = Index.TotalPaymentsinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalPaymentsinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Discounts in Vendor Currency
        /// </summary>
        [Display(Name = "TotalDiscountsinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalDiscountsinVendCurr, Id = Index.TotalDiscountsinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDiscountsinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Discounts Lost in Vendor Currency
        /// </summary>
        [Display(Name = "TotalDiscountsLostinVendCu", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalDiscountsLostinVendCu, Id = Index.TotalDiscountsLostinVendCu, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDiscountsLostinVendCu {get; set;}
		 
  		/// <summary>
        /// Gets or sets Total Adjustments in Vendor Currency
        /// </summary>
        [Display(Name = "TotalAdjustmentsinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalAdjustmentsinVendCurr, Id = Index.TotalAdjustmentsinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalAdjustmentsinVendCurr {get; set;}
  
  		/// <summary>
        /// Gets or sets Amtpurtc 
        /// </summary>
        public decimal Amtpurtc { get; set; }
		 
  		/// <summary>
        /// Gets or sets Total Invoices Paid in Vendor Currency 
        /// </summary>
        [Display(Name = "TotalInvoicesPdinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.TotalInvoicesPdinVendCurr, Id = Index.TotalInvoicesPdinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInvoicesPdinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Revaluation Balance in Vendor Currency 
        /// </summary>
        [Display(Name = "RevaluationBalinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.RevaluationBalinVendCurr, Id = Index.RevaluationBalinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal RevaluationBalinVendCurr {get; set;}
 
  		/// <summary>
        /// Gets or sets Cntpur 
        /// </summary>
        public decimal Cntpur { get; set; }
		 
  		/// <summary>
        /// Gets or sets Average Days to Pay 
        /// </summary>
        [Display(Name = "AverageDaystoPay", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.AverageDaystoPay, Id = Index.AverageDaystoPay, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 1)]
 		public decimal AverageDaystoPay {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Number of Invoices 
        /// </summary>
        [Display(Name = "YTDNumberofInvoices", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDNumberofInvoices, Id = Index.YTDNumberofInvoices, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberofInvoices {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Number of Credit Notes 
        /// </summary>
        [Display(Name = "YTDNumberofCreditNotes", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDNumberofCreditNotes, Id = Index.YTDNumberofCreditNotes, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberofCreditNotes {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Number of Debit Notes 
        /// </summary>
        [Display(Name = "YTDNumberofDebitNotes", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDNumberofDebitNotes, Id = Index.YTDNumberofDebitNotes, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberofDebitNotes {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Number of Payments 
        /// </summary>
        [Display(Name = "YTDNumberofPayments", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDNumberofPayments, Id = Index.YTDNumberofPayments, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberofPayments {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year ToDate Number of Discounts 
        /// </summary>
        [Display(Name = "YTDNumberofDiscounts", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDNumberofDiscounts, Id = Index.YTDNumberofDiscounts, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberofDiscounts {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Number of Discounts Lost 
        /// </summary>
        [Display(Name = "YTDNumberofDiscountsLost", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDNumberofDiscountsLost, Id = Index.YTDNumberofDiscountsLost, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberofDiscountsLost {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Number of Adjustments 
        /// </summary>
        [Display(Name = "YTDNumberofAdjustments", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDNumberofAdjustments, Id = Index.YTDNumberofAdjustments, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberofAdjustments {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Number of Paid Invoices 
        /// </summary>
        [Display(Name = "YTDNumberofPaidInvoices", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDNumberofPaidInvoices, Id = Index.YTDNumberofPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberofPaidInvoices {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Number of Days to Pay 
        /// </summary>
        [Display(Name = "YTDNumberofDaystoPay", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDNumberofDaystoPay, Id = Index.YTDNumberofDaystoPay, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberofDaystoPay {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Invoices in Function Currency
        /// </summary>
        [Display(Name = "YTDInvoicesinFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDInvoicesinFuncCurr, Id = Index.YTDInvoicesinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDInvoicesinFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Credits in Function Currency.
        /// </summary>
        [Display(Name = "YTDCreditsinFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDCreditsinFuncCurr, Id = Index.YTDCreditsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDCreditsinFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Debits i nFunction Currency
        /// </summary>
        [Display(Name = "YTDDebitsinFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDDebitsinFuncCurr, Id = Index.YTDDebitsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDDebitsinFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Payments in Function Currency
        /// </summary>
        [Display(Name = "YTDPaymentsinFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDPaymentsinFuncCurr, Id = Index.YTDPaymentsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDPaymentsinFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Discounts in Function Currency
        /// </summary>
        [Display(Name = "YTDDiscountsinFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDDiscountsinFuncCurr, Id = Index.YTDDiscountsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDDiscountsinFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Discounts Lost Function Currency
        /// </summary>
        [Display(Name = "YTDDiscountsLostFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDDiscountsLostFuncCurr, Id = Index.YTDDiscountsLostFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDDiscountsLostFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Adjustments in Function Currency
        /// </summary>
        [Display(Name = "YTDAdjustmentsinFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDAdjustmentsinFuncCurr, Id = Index.YTDAdjustmentsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDAdjustmentsinFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Invoices Paid in Function Currency
        /// </summary>
        [Display(Name = "YTDInvoicesPdinFuncCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDInvoicesPdinFuncCurr, Id = Index.YTDInvoicesPdinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDInvoicesPdinFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Invoices in Vendor Currency
        /// </summary>
        [Display(Name = "YTDInvoicesinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDInvoicesinVendCurr, Id = Index.YTDInvoicesinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDInvoicesinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Credits in Vendor Currency
        /// </summary>
        [Display(Name = "YTDCreditsinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDCreditsinVendCurr, Id = Index.YTDCreditsinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDCreditsinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Debits in Vendor Currency 
        /// </summary>
        [Display(Name = "YTDDebitsinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDDebitsinVendCurr, Id = Index.YTDDebitsinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDDebitsinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Payments in Vendor Currency
        /// </summary>
        [Display(Name = "YTDPaymentsinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDPaymentsinVendCurr, Id = Index.YTDPaymentsinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDPaymentsinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Discounts in Vendor Currency
        /// </summary>
        [Display(Name = "YTDDiscountsinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDDiscountsinVendCurr, Id = Index.YTDDiscountsinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDDiscountsinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Discounts Lost in Vendor Currency
        /// </summary>
        [Display(Name = "YTDDiscountsLostinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDDiscountsLostinVendCurr, Id = Index.YTDDiscountsLostinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDDiscountsLostinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Adjustments in Vendor Currency
        /// </summary>
        [Display(Name = "YTDAdjustmentsinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDAdjustmentsinVendCurr, Id = Index.YTDAdjustmentsinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDAdjustmentsinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Invoices Paid in Vendor Currency
        /// </summary>
        [Display(Name = "YTDInvoicesPdinVendCurr", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDInvoicesPdinVendCurr, Id = Index.YTDInvoicesPdinVendCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDInvoicesPdinVendCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year To Date Average Days to Pay 
        /// </summary>
        [Display(Name = "YTDAverageDaysToPay", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.YTDAverageDaystoPay, Id = Index.YTDAverageDaystoPay, FieldType = EntityFieldType.Decimal, Size = 6, Precision = 1)]
 		public decimal YTDAverageDaystoPay {get; set;}
		 
  		/// <summary>
        /// Gets or sets EnableYear To Date Calculations 
        /// </summary>
        [Display(Name = "EnableYTDCalculations", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.EnableYTDCalculations, Id = Index.EnableYTDCalculations, FieldType = EntityFieldType.Int, Size = 2)]
 		public TaxIncluded EnableYTDCalculations {get; set;}
	}
}
