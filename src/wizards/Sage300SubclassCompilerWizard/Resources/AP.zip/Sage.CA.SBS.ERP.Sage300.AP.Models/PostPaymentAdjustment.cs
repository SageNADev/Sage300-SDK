// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class PostPaymentAdjustment
    /// </summary>
    public partial class PostPaymentAdjustment : ModelBase
    {

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2)]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets Post All Batches 
        /// </summary>
        [ViewField(Name = Fields.PostAllBatches, Id = Index.PostAllBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public PostAllBatches PostAllBatches { get; set; }

        /// <summary>
        /// Gets or sets Post Batch From 
        /// </summary>
        [ViewField(Name = Fields.PostBatchFrom, Id = Index.PostBatchFrom, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostBatchFrom { get; set; }

        /// <summary>
        /// Gets or sets Post Batch To 
        /// </summary>
        [ViewField(Name = Fields.PostBatchTo, Id = Index.PostBatchTo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostBatchTo { get; set; }
    }
}
