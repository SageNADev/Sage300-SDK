// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
 
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// class for CPRSAmount
    /// </summary>
	public partial class CPRSAmount : ModelBase
	{	 
  		/// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(APCommonResx))]
        [Key]
 		[ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
 		public string VendorNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets Code 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Code", ResourceType = typeof(APCommonResx))]
        [Key]
 		[ViewField(Name = Fields.Code, Id = Index.Code, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string Code {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof(CommonResx))]
        [Key]
 		[ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
 		public string Year {get; set;}
		 
  		/// <summary>
        /// Gets or sets Month 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Month", ResourceType = typeof(APCommonResx))]
        [Key]
 		[ViewField(Name = Fields.Month, Id = Index.Month, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
 		public string Month {get; set;}
		
		/// <summary>
        /// Gets or sets LastPaymentDate 
        /// </summary> 
        [Display(Name = "LastPaymentDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.LastPaymentDate, Id = Index.LastPaymentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastPaymentDate {get; set;}
	 
  		/// <summary>
        /// Gets or sets NumberofPayments 
        /// </summary>
        [Display(Name = "NumberofPayments", ResourceType = typeof(TermCodeResx))]
 		[ViewField(Name = Fields.NumberofPayments, Id = Index.NumberofPayments, FieldType = EntityFieldType.Decimal, Size = 4)]
 		public decimal NumberofPayments {get; set;}
		 
  		/// <summary>
        /// Gets or sets PaymentAmount 
        /// </summary>
        [Display(Name = "PaymentAmount", ResourceType = typeof(APCommonResx))]
 		[ViewField(Name = Fields.PaymentAmount, Id = Index.PaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal PaymentAmount {get; set;}

        #region Custom Properties

        /// <summary>
        /// Gets or sets the VendorCurrency
        /// </summary>
        public string VendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets the CurrencyCode
        /// </summary>
        public string CurrencyCode { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The SerialNumber.</value>
        public long SerialNumber { get; set; } 
       
        #endregion

    }
}
