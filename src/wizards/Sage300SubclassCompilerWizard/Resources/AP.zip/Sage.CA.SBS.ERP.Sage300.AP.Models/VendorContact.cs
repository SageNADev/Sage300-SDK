// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Status = Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Status;

#endregion Namespace

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Contains list of properties for Vendor
    /// </summary>
    public partial class VendorContact : ModelBase
    {
        /// <summary>
        /// Gets or sets VendorNumber
        /// </summary>
        [Display(Name = "VendorNumber", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets ContactCode
        /// </summary>
        [Display(Name = "ContactCode", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.ContactCode, Id = Index.ContactCode, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ContactCode { get; set; }

        /// <summary>
        /// Gets or sets ContactName
        /// </summary>
        [Display(Name = "ContactName", ResourceType = typeof(APCommonResx))]
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 255)]
        public string ContactName { get; set; }


        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [Display(Name = "Email", ResourceType = typeof(CommonResx))]
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 255)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets ContactStatus
        /// </summary>
        [Display(Name = "ContactStatus", ResourceType = typeof(APCommonResx))]
	    [GridColumn]
        [ViewField(Name = Fields.ContactStatus, Id = Index.ContactStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public AP.Models.Enums.Status ContactStatus { get; set; }

        /// <summary>
        /// Gets or sets ConsentsToEmail
        /// </summary>
        [Display(Name = "ConsentsToEmail", ResourceType = typeof(APCommonResx))]
	    [GridColumn]
        [ViewField(Name = Fields.ConsentsToEmail, Id = Index.ConsentsToEmail, FieldType = EntityFieldType.Int, Size = 2)]
        public int ConsentsToEmail { get; set; }

        /// <summary>
        /// Gets or sets EmailSeparator
        /// </summary>
        [Display(Name = "EmailSeparator", ResourceType = typeof(CommonResx))]
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[ViewField(Name = Fields.EmailSeparator, Id = Index.EmailSeparator, FieldType = EntityFieldType.Char, Size = 1)]
        public string EmailSeparator { get; set; }


        #region Properties for finder
        #endregion Properties for finder
    }

}
