/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{

    public partial class PrintCheck : ModelBase
    {
        /// <summary>
        /// Gets or sets Request 
        /// </summary>
        [ViewField(Name = Fields.Request, Id = Index.Request, FieldType = EntityFieldType.Int, Size = 2)]
        public Request Request { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets ReturnedStatus 
        /// </summary>
        [ViewField(Name = Fields.ReturnedStatus, Id = Index.ReturnedStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public ReturnedStatus ReturnedStatus { get; set; }

        /// <summary>
        /// Gets or sets RestartState 
        /// </summary>
        [ViewField(Name = Fields.RestartState, Id = Index.RestartState, FieldType = EntityFieldType.Int, Size = 2)]
        public RestartState RestartState { get; set; }

        /// <summary>
        /// Gets or sets Bank 
        /// </summary>
        [ViewField(Name = Fields.Bank, Id = Index.Bank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Bank { get; set; }

        /// <summary>
        /// Gets or sets DecimalsinBankCurrency 
        /// </summary>
        [ViewField(Name = Fields.DecimalsinBankCurrency, Id = Index.DecimalsinBankCurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public int DecimalsinBankCurrency { get; set; }

        /// <summary>
        /// Gets or sets Message 
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the Source Application
        /// </summary>
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets the Report File
        /// </summary>
        public string ReportFile { get; set; }

        /// <summary>
        /// Gets or sets the start Serial Number
        /// </summary>
        public long StartSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets the end Serial Number
        /// </summary>
        public long EndSerialNumber { get; set; }
    }
}
