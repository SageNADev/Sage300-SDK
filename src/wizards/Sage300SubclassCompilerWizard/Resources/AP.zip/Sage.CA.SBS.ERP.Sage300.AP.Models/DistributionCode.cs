/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using System;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Distribution Code Class Properties
    /// </summary>
    public partial class DistributionCode : ModelBase
    {

        /// <summary>
        /// Constructor for Distribution code
        /// </summary>
        public DistributionCode()
        {
            Status = Status.Active;
            DiscountableVal = true;
        }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(DistributionCodesResx))]
        [Key]
        [ViewField(Name = Fields.DistributionCodeKey, Id = Index.DistributionCodeKey, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCodeKey { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCodeDes", ResourceType = typeof(DistributionCodesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets GLAccount 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GenLedgerAcct", ResourceType = typeof(DistributionCodesResx))]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets GLAccountDescription 
        /// </summary>
        [Display(Name = "GenLedgerAcctDesc", ResourceType = typeof(DistributionCodesResx))]
        public string GLAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets Discountable 
        /// </summary>
        [Display(Name = "Discountable", ResourceType = typeof(APCommonResx))]
        [ViewField(Name = Fields.Discountable, Id = Index.Discountable, FieldType = EntityFieldType.Int, Size = 2)]
        public Discountable Discountable { get; set; }


        #region UI Properties

        /// <summary>
        /// Discountable Property Switch for UI
        /// </summary>
        public bool DiscountableVal
        {
            get { return Discountable != Discountable.No; }
            set
            {
                Discountable = value
                    ? Discountable.Yes
                    : Discountable.No;
            }
        }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        public string StatusString
        {
            get
            {
                return EnumUtility.GetStringValue(Status);
            }
        }

        /// <summary>
        /// To get the string of Discountable property
        /// </summary>
        public string DiscountableString
        {
            get { return EnumUtility.GetStringValue(Discountable); }
        }
        #endregion
    }
}
