/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class CompanyOptions : ModelBase
    {

        /// <summary>
        /// Gets or sets OptionsRecordKey 
        /// </summary>
        [Required(ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.OptionsRecordKey, Id = Index.OptionsRecordKey, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string OptionsRecordKey { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency 
        /// </summary>

        [ViewField(Name = Fields.Multicurrency, Id = Index.Multicurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public Multicurrency Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets EditImports 
        /// </summary>

        [ViewField(Name = Fields.EditImports, Id = Index.EditImports, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden EditImports { get; set; }

        /// <summary>
        /// Gets or sets ForceListingofBatches 
        /// </summary>

        [ViewField(Name = Fields.ForceListingofBatches, Id = Index.ForceListingofBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden ForceListingofBatches { get; set; }


        //TODO: The naming convention of this property has to be relooked

        /// <summary>
        /// Gets or sets CNTARCVDAY 
        /// </summary>

        [ViewField(Name = Fields.CNTARCVDAY, Id = Index.CNTARCVDAY, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal CNTARCVDAY { get; set; }

        /// <summary>
        /// Gets or sets EditVendorStatistics 
        /// </summary>

        [ViewField(Name = Fields.EditVendorStatistics, Id = Index.EditVendorStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden EditVendorStatistics { get; set; }

        /// <summary>
        /// Gets or sets IncTaxinVendorStatistics 
        /// </summary>

        [ViewField(Name = Fields.IncTaxinVendorStatistics, Id = Index.IncTaxinVendorStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden IncTaxinVendorStatistics { get; set; }

        /// <summary>
        /// Gets or sets VendorStatisticsYearType 
        /// </summary>

        [ViewField(Name = Fields.VendorStatisticsYearType, Id = Index.VendorStatisticsYearType, FieldType = EntityFieldType.Int, Size = 2)]
        public VendorStatisticsYearType VendorStatisticsYearType { get; set; }

        /// <summary>
        /// Gets or sets VendorStatisticsPeriodType 
        /// </summary>

        [ViewField(Name = Fields.VendorStatisticsPeriodType, Id = Index.VendorStatisticsPeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public VendorStatisticsPeriodType VendorStatisticsPeriodType { get; set; }


        //TODO: The naming convention of this property has to be relooked

        /// <summary>
        /// Gets or sets SWBNKVNDR 
        /// </summary>

        [ViewField(Name = Fields.SWBNKVNDR, Id = Index.SWBNKVNDR, FieldType = EntityFieldType.Int, Size = 2)]
        public int SWBNKVNDR { get; set; }

        /// <summary>
        /// Gets or sets DefaultNoDaystoKeepComment 
        /// </summary>

        [ViewField(Name = Fields.DefaultNoDaystoKeepComment, Id = Index.DefaultNoDaystoKeepComment, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal DefaultNoDaystoKeepComment { get; set; }

        /// <summary>
        /// Gets or sets NextRevaluationPostingSequenc 
        /// </summary>

        [ViewField(Name = Fields.NextRevaluationPostingSequenc, Id = Index.NextRevaluationPostingSequenc, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRevaluationPostingSequenc { get; set; }

        /// <summary>
        /// Gets or sets ContactName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets TelephoneNumber 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TelephoneNumber, Id = Index.TelephoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string TelephoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets KeepHistory 
        /// </summary>

        [ViewField(Name = Fields.KeepHistory, Id = Index.KeepHistory, FieldType = EntityFieldType.Int, Size = 2)]
        public int KeepHistory { get; set; }

        /// <summary>
        /// Gets or sets KeepVendorStatistics 
        /// </summary>

        [ViewField(Name = Fields.KeepVendorStatistics, Id = Index.KeepVendorStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden KeepVendorStatistics { get; set; }

        /// <summary>
        /// Gets or sets DefaultTaxAmountControl 
        /// </summary>

        [ViewField(Name = Fields.DefaultTaxAmountControl, Id = Index.DefaultTaxAmountControl, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateTaxAmountControl DefaultTaxAmountControl { get; set; }

        /// <summary>
        /// Gets or sets EditExternalBatches 
        /// </summary>

        [ViewField(Name = Fields.EditExternalBatches, Id = Index.EditExternalBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden EditExternalBatches { get; set; }

        /// <summary>
        /// Gets or sets DefaultTaxBaseControl 
        /// </summary>

        [ViewField(Name = Fields.DefaultTaxBaseControl, Id = Index.DefaultTaxBaseControl, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateTaxAmountControl DefaultTaxBaseControl { get; set; }

        /// <summary>
        /// Gets or sets DefaultTaxReportingControl 
        /// </summary>

        [ViewField(Name = Fields.DefaultTaxReportingControl, Id = Index.DefaultTaxReportingControl, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateTaxAmountControl DefaultTaxReportingControl { get; set; }

        /// <summary>
        /// Gets or sets DefaultDetailTaxClass 
        /// </summary>

        [ViewField(Name = Fields.DefaultDetailTaxClass, Id = Index.DefaultDetailTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultDetailTaxClass DefaultDetailTaxClass { get; set; }
    }
}
