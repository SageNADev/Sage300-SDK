// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    public partial class Terms : ModelBase
    {

        /// <summary>
        /// Gets or sets TermsCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Status Status { get; set; }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        /// <value>The status string.</value>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets UsePaymentSchedule 
        /// </summary>
        [ViewField(Name = Fields.UsePaymentSchedule, Id = Index.UsePaymentSchedule, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType UsePaymentSchedule { get; set; }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        /// <value>The status string.</value>
        [Display(Name = "Status", ResourceType = typeof(APCommonResx))]
        public string UsePaymentScheduleString
        {
            get { return EnumUtility.GetStringValue(UsePaymentSchedule); }
        }

        /// <summary>
        /// Gets or sets CalcBaseforDiscountwithTax 
        /// </summary>

        [ViewField(Name = Fields.CalcBaseforDiscountwithTax, Id = Index.CalcBaseforDiscountwithTax, FieldType = EntityFieldType.Int, Size = 2)]
        public CalcBaseforDiscountwithTax CalcBaseforDiscountwithTax { get; set; }

        /// <summary>
        /// Gets or sets MethodofCalcforDiscountDate 
        /// </summary>

        [ViewField(Name = Fields.MethodofCalcforDiscountDate, Id = Index.MethodofCalcforDiscountDate, FieldType = EntityFieldType.Int, Size = 2)]
        public MethodofCalcforDiscountDate MethodofCalcforDiscountDate { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay1 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableStartingDay1, Id = Index.DiscountTableStartingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay2 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableStartingDay2, Id = Index.DiscountTableStartingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay3 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableStartingDay3, Id = Index.DiscountTableStartingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay4 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableStartingDay4, Id = Index.DiscountTableStartingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay1 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableEndingDay1, Id = Index.DiscountTableEndingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay2 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableEndingDay2, Id = Index.DiscountTableEndingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay3 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableEndingDay3, Id = Index.DiscountTableEndingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay4 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableEndingDay4, Id = Index.DiscountTableEndingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableAddMonths1 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableAddMonths1, Id = Index.DiscountTableAddMonths1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableAddMonths1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableAddMonths2 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableAddMonths2, Id = Index.DiscountTableAddMonths2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableAddMonths2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableAddMonths3 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableAddMonths3, Id = Index.DiscountTableAddMonths3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableAddMonths3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableAddMonths4 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableAddMonths4, Id = Index.DiscountTableAddMonths4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableAddMonths4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth1 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableDayofMonth1, Id = Index.DiscountTableDayofMonth1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth2 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableDayofMonth2, Id = Index.DiscountTableDayofMonth2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth3 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableDayofMonth3, Id = Index.DiscountTableDayofMonth3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth4 
        /// </summary>

        [ViewField(Name = Fields.DiscountTableDayofMonth4, Id = Index.DiscountTableDayofMonth4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth4 { get; set; }

        /// <summary>
        /// Gets or sets MethodofCalcforDueDate 
        /// </summary>

        [ViewField(Name = Fields.MethodofCalcforDueDate, Id = Index.MethodofCalcforDueDate, FieldType = EntityFieldType.Int, Size = 2)]
        public MethodofCalcforDueDate MethodofCalcforDueDate { get; set; }

        /// <summary>
        /// Gets or sets DueTableStartingDay1 
        /// </summary>

        [ViewField(Name = Fields.DueTableStartingDay1, Id = Index.DueTableStartingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableStartingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DueTableStartingDay2 
        /// </summary>

        [ViewField(Name = Fields.DueTableStartingDay2, Id = Index.DueTableStartingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableStartingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DueTableStartingDay3 
        /// </summary>

        [ViewField(Name = Fields.DueTableStartingDay3, Id = Index.DueTableStartingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableStartingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DueTableStartingDay4 
        /// </summary>

        [ViewField(Name = Fields.DueTableStartingDay4, Id = Index.DueTableStartingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableStartingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DueTableEndingDay1 
        /// </summary>

        [ViewField(Name = Fields.DueTableEndingDay1, Id = Index.DueTableEndingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableEndingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DueTableEndingDay2 
        /// </summary>

        [ViewField(Name = Fields.DueTableEndingDay2, Id = Index.DueTableEndingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableEndingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DueTableEndingDay3 
        /// </summary>

        [ViewField(Name = Fields.DueTableEndingDay3, Id = Index.DueTableEndingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableEndingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DueTableEndingDay4 
        /// </summary>

        [ViewField(Name = Fields.DueTableEndingDay4, Id = Index.DueTableEndingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableEndingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DueTableAddMonths1 
        /// </summary>

        [ViewField(Name = Fields.DueTableAddMonths1, Id = Index.DueTableAddMonths1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableAddMonths1 { get; set; }

        /// <summary>
        /// Gets or sets DueTableAddMonths2 
        /// </summary>

        [ViewField(Name = Fields.DueTableAddMonths2, Id = Index.DueTableAddMonths2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableAddMonths2 { get; set; }

        /// <summary>
        /// Gets or sets DueTableAddMonths3 
        /// </summary>

        [ViewField(Name = Fields.DueTableAddMonths3, Id = Index.DueTableAddMonths3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableAddMonths3 { get; set; }

        /// <summary>
        /// Gets or sets DueTableAddMonths4 
        /// </summary>

        [ViewField(Name = Fields.DueTableAddMonths4, Id = Index.DueTableAddMonths4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableAddMonths4 { get; set; }

        /// <summary>
        /// Gets or sets DueTableDayofMonth1 
        /// </summary>

        [ViewField(Name = Fields.DueTableDayofMonth1, Id = Index.DueTableDayofMonth1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableDayofMonth1 { get; set; }

        /// <summary>
        /// Gets or sets DueTableDayofMonth2 
        /// </summary>

        [ViewField(Name = Fields.DueTableDayofMonth2, Id = Index.DueTableDayofMonth2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableDayofMonth2 { get; set; }

        /// <summary>
        /// Gets or sets DueTableDayofMonth3 
        /// </summary>

        [ViewField(Name = Fields.DueTableDayofMonth3, Id = Index.DueTableDayofMonth3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableDayofMonth3 { get; set; }

        /// <summary>
        /// Gets or sets DueTableDayofMonth4 
        /// </summary>

        [ViewField(Name = Fields.DueTableDayofMonth4, Id = Index.DueTableDayofMonth4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueTableDayofMonth4 { get; set; }

        /// <summary>
        /// Gets or sets NumberofPayments 
        /// </summary>

        [ViewField(Name = Fields.NumberofPayments, Id = Index.NumberofPayments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPayments { get; set; }

        /// <summary>
        /// Gets or sets TotalPercentageDue 
        /// </summary>

        [ViewField(Name = Fields.TotalPercentageDue, Id = Index.TotalPercentageDue, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TotalPercentageDue { get; set; }
    }
}
