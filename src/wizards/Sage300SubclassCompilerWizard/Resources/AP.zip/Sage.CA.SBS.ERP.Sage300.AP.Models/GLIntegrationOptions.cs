// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.GLIntegration;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for G/L Integration Options
    /// </summary>
    public partial class GLIntegrationOptions : BaseGLIntegrationOptions
    {
        /// <summary>
        /// Gets or sets Last Payment Posting Sequence to G/L 
        /// </summary>
        [Display(Name = "PaymentPostingSequence", ResourceType = typeof(GLIntegrationResx))]
        [ViewField(Name = Fields.LastPaymentPostingSeqToGL, Id = Index.LastPaymentPostingSeqToGL, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal LastPaymentPostingSeqToGL { get; set; }

        /// <summary>
        /// Gets or sets GL Source Code Payment 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(GLIntegrationResx))]
        [Display(Name = "Payment", ResourceType = typeof(GLIntegrationResx))]
        [ViewField(Name = Fields.GLSrcCodePayment, Id = Index.GLSrcCodePayment, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string GLSrcCodePayment { get; set; }

    }
}
