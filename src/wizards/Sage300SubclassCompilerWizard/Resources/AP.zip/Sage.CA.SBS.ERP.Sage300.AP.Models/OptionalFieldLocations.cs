/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Optional Field Locations Class
    /// </summary>
	public partial class OptionalFieldLocations : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets Location 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))][Key]
 		[ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
 		public Location Location {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofValues 
        /// </summary>
        
 		[ViewField(Name = Fields.NumberofValues, Id = Index.NumberofValues, FieldType = EntityFieldType.Long, Size = 4)]
 		public long NumberofValues {get; set;}
		    }
}
