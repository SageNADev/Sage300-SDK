﻿/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

#region namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Customization.Validators;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Model Class for Batch Listing Report
    /// </summary>
    public partial class BatchListing : ReportBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or sets Functional Currency Decimal
        /// </summary>
        public decimal FunctionalCurrDecimal { get; set; }

        /// <summary>
        /// Gets or sets From Batch Number
        /// </summary>
        public string FromBatch { get; set; }

        /// <summary>
        /// Gets or sets To Batch Number
        /// </summary>
        public string ToBatch { get; set; }

        /// <summary>
        /// Gets or sets From Date
        /// </summary>
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime FromDate { get; set; }

        /// <summary>
        /// Gets or sets To Date
        /// </summary>
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Gets or sets BatchTypeSwitch
        /// </summary>
        public PostBatchTypeSwitch BatchTypeSwitch { get; set; }

        /// <summary>
        /// Gets or sets Query
        /// </summary>
        public DateTime Query { get; set; }

        /// <summary>
        /// Gets or sets Batch Type
        /// </summary>
        [ValidateListForSelection]
        [Display(Name = "BatchType", ResourceType = typeof(APCommonResx))]
        public List<MultiSelect> BatchType { get; set; }

        /// <summary>
        /// Gets or sets Batch Status
        /// </summary>
        [ValidateListForSelection]
        [Display(Name = "BatchStatus", ResourceType = typeof(APCommonResx))]
        public List<MultiSelect> BatchStatus { get; set; }

        /// <summary>
        /// Gets or sets Schedule
        /// </summary>
        [Display(Name = "ShowSchedules", ResourceType = typeof(BatchListingResx))]
        public bool Schedule { get; set; }

        /// <summary>
        /// Gets or sets Include Printed
        /// </summary>
        [Display(Name = "ReprintPrevPrintedBatch", ResourceType = typeof(BatchListingResx))]
        public bool IncludePrinted { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrency
        /// </summary>
        public string MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Show Tax Details
        /// </summary>
        [Display(Name = "ShowTaxDetails", ResourceType = typeof(BatchListingResx))]
        public bool TaxDetail { get; set; }

        /// <summary>
        /// Gets or sets Show Job
        /// </summary>
        [Display(Name = "ShowJobDetails", ResourceType = typeof(BatchListingResx))]
        public bool ShowJob { get; set; }

        /// <summary>
        /// Gets or sets Switch PM Active
        /// </summary>
        public string SwitchPmActive { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Show Comments
        /// </summary>
        [Display(Name = "ShowComments", ResourceType = typeof(BatchListingResx))]
        public bool ShowCmts { get; set; }

        /// <summary>
        /// Gets or sets Show Optional Fields
        /// </summary>
        [Display(Name = "ShowOptionalFields", ResourceType = typeof(BatchListingResx))]
        public bool OptionalField { get; set; }

        /// <summary>
        /// Gets or sets ZI MultiCurrency
        /// </summary>
        public bool ZiMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Switch Retainage
        /// </summary>
        public bool SwitchRetainage { get; set; }

        /// <summary>
        /// Gets or sets Show Retainage Details
        /// </summary>
        [Display(Name = "ShowRetainageDetails", ResourceType = typeof(BatchListingResx))]
        public bool RetainageDetail { get; set; }

        /// <summary>
        /// Gets or sets Home Currency
        /// </summary>
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets Source
        /// </summary>
        public string Source { get; set; }

        /// <summary>
        /// Gets or sets Discount
        /// </summary>
        public string Discount { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        public string Amount { get; set; }

        /// <summary>
        /// Gets or sets Allow Adjustments In PaymentBatch
        /// </summary>
        public bool AllowAdjustmentsInPaymentBat { get; set; }

        /// <summary>
        /// Gets or sets Bank
        /// </summary>
        public string Bank { get; set; }

        /// <summary>
        /// Gets or sets Is MultiCurrency Visible
        /// </summary>
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Show Adjustment Details
        /// </summary>
        [Display(Name = "ShowAdjustmentDetails", ResourceType = typeof(BatchListingResx))]
        public bool ShowAdjDetails { get; set; }

        /// <summary>
        /// Gets or sets Credit
        /// </summary>
        public string Credit { get; set; }

        /// <summary>
        /// Gets or sets Debit
        /// </summary>
        public string Debit { get; set; }

        /// <summary>
        /// Check Invoice button enabled
        /// </summary>
        public bool IsInvoiceEnabled { get; set; }

        /// <summary>
        /// Check Payment button enabled
        /// </summary>
        public bool IsPaymentEnabled { get; set; }

        /// <summary>
        /// Check Adjustment button enabled
        /// </summary>
        public bool IsAdjustmentEnabled { get; set; }

        /// <summary>
        /// Gets or sets Switch PM Active
        /// </summary>
        public bool IsPmActive { get; set; }

        /// <summary>
        /// Gets or sets Switch Gl Active
        /// </summary>
        public bool IsGLActive { get; set; }

        /// <summary>
        /// Gets or sets Switch ZI Active
        /// </summary>
        public bool IsZiActive { get; set; }

        /// <summary>
        /// Gets or sets Use Retainage
        /// </summary>
        public bool UseRetainage { get; set; }

        /// <summary>
        /// Gets or sets Show RC Wht flag
        /// </summary>
        public string ShowRcWht { get; set; }

        #endregion
    }
}
