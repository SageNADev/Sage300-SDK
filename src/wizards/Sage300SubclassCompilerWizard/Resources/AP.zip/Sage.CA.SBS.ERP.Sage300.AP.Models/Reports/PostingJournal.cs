// Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Partial class for PostingJournal
    /// </summary>
    public partial class PostingJournal : ReportBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or sets SelectJournal
        /// </summary>
        public SelectJournal SelectJournal { get; set; }

        /// <summary>
        /// Gets or Sets PostingJournalSortBy
        ///  </summary>
        public PostingJournalSortBy PostingJournalSortBy { get; set; }

        /// <summary>
        /// Gets or sets FromSequence
        /// </summary>
        [Display(Name = "FromPostingSequence", ResourceType = typeof(PostingJournalResx))]
        public decimal FromSequence { get; set; }

        /// <summary>
        /// Gets or sets ToSequence
        /// </summary>
        [Display(Name = "ToPostingSequence", ResourceType = typeof(PostingJournalResx))]
        public decimal ToSequence { get; set; }

        /// <summary>
        /// Gets or sets Reprint
        /// </summary>
        [Display(Name = "Reprint", ResourceType = typeof(CommonResx))]
        public bool Reprint { get; set; }

        /// <summary>
        /// Gets or sets ShowJobDetails
        /// </summary>
        [Display(Name = "IncludeJob", ResourceType = typeof(CommonResx))]
        public bool ShowJobDetails { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "IncludeOptionalFields", ResourceType = typeof(CommonResx))]
        public bool OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets SortBy
        /// </summary>
        public string SortBy { get; set; }

        /// <summary>
        /// Gets or sets SwitchGlRefDescription
        /// </summary>
        [Display(Name = "IncludeGLDetailReference", ResourceType = typeof(PostingJournalResx))]
        public bool SwitchGlRefDescription { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrency
        /// </summary>
        public bool MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrency
        /// </summary>
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrencyDecimal
        /// </summary>
        public string HomeCurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets SwitchPmActive
        /// </summary>
        public bool SwitchPmActive { get; set; }

        /// <summary>
        /// Gets or sets Level1Name
        /// </summary>
        public string Level1Name { get; set; }

        /// <summary>
        /// Gets or sets Level2Name
        /// </summary>
        public string Level2Name { get; set; }

        /// <summary>
        /// Gets or sets Level3Name
        /// </summary>
        public string Level3Name { get; set; }

        /// <summary>
        /// Gets or sets SwitchGlActive
        /// </summary>
        public bool SwitchGlActive { get; set; }

        /// <summary>
        /// Gets or sets SwitchRtg
        /// </summary>
        public bool SwitchRtg { get; set; }

        /// <summary>
        /// Gets or sets SwitchZiActive
        /// </summary>
        public bool SwitchZiActive { get; set; }

        /// <summary>
        /// Gets or sets ZiMultiCurrency
        /// </summary>
        public string ZiMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets ZiDetails
        /// </summary>
        public string ZiDetails { get; set; }

        /// <summary>
        /// Gets or sets HasObLicense
        /// </summary>
        public bool HasObLicense { get; set; }

        /// <summary>
        /// Check Invoice button Disabled
        /// </summary>
        public bool IsInvoiceDisabled { get; set; }

        /// <summary>
        /// Check Payment button Disabled
        /// </summary>
        public bool IsPaymentDisabled { get; set; }

        /// <summary>
        /// Check Adjustment button Disabled
        /// </summary>
        public bool IsAdjustmentDisabled { get; set; }

        /// <summary>
        /// Check Revaluation button Disabled
        /// </summary>
        public bool IsRevaluationDisabled { get; set; }

        #endregion
    }
}
