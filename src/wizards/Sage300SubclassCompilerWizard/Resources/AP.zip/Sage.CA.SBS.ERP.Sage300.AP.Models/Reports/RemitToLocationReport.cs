// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Partial class for RemitToLocation report
    /// </summary>
    public partial class RemitToLocationReport : ReportBase
    {
        public RemitToLocationReport()
        {
            Address = true;
            Tovend = "ZZZZZZZZZZZZ";
        }

        /// <summary>
        /// Gets or sets Fromvend
        /// </summary>
        [Display(Name = "FromVendor", ResourceType = typeof(APCommonResx))]
        public string Fromvend { get; set; }

        /// <summary>
        /// Gets or sets Tovend
        /// </summary>
        [Display(Name = "ToVendor", ResourceType = typeof(APCommonResx))]
        public string Tovend { get; set; }

        /// <summary>
        /// Gets or sets Phonefmt
        /// </summary>
        public bool Phonefmt { get; set; }

        /// <summary>
        /// Gets or sets Address
        /// </summary>
        [Display(Name = "Address", ResourceType = typeof(APCommonResx))]
        public bool Address { get; set; }

        /// <summary>
        /// Gets or sets Optflds
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        public bool Optflds { get; set; }
    }
}