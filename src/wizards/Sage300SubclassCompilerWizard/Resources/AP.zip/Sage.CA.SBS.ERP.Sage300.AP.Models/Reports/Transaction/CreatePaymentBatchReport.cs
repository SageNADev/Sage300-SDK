﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.Transaction
{
    /// <summary>
    /// Model CreatePayment Batch Report
    /// </summary>
    public partial class CreatePaymentBatchReport : ReportBase
    {
        /// <summary>
        /// Gets or sets FunctionalCurrencyDescription 
        /// </summary>
        public string FunctionalCurrDesc { get; set; }


        /// <summary>
        /// Gets or sets FromAccountSet 
        /// </summary>
        public string FromAccountSet { get; set; }

        /// <summary>
        /// Gets or sets ThruAccountSet 
        /// </summary>
        public string ThruAccountSet { get; set; }

        /// <summary>
        /// Gets or sets CSVFilename 
        /// </summary>
        public string CsvFilename { get; set; }

        /// <summary>
        /// Gets or sets FromVendorNumber 
        /// </summary>
        public string FromVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets ThruVendorNumber 
        /// </summary>
        public string ThruVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets FromDiscountDate 
        /// </summary>
        public DateTime? FromDiscountDate { get; set; }

        /// <summary>
        /// Gets or sets FromGroupCode 
        /// </summary>
        public string FromGroupCode { get; set; }

        /// <summary>
        /// Gets or sets ThruGroupCode 
        /// </summary>
        public string ThruGroupCode { get; set; }

        /// <summary>
        /// Gets or sets PaymentBankCode 
        /// </summary>
        public string PaymentBankCode { get; set; }

        /// <summary>
        /// Gets or sets MinimumPaymentAmount 
        /// </summary>
        public string MinimumPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets MaximumPaymentAmount 
        /// </summary>
        public string MaximumPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets PaymentDate 
        /// </summary>
        public DateTime PaymentDate { get; set; }

        /// <summary>
        /// Gets or sets ThruDiscountDate 
        /// </summary>
        public DateTime? ThruDiscountDate { get; set; }

        /// <summary>
        /// Gets or sets SelectDocument 
        /// </summary>
        public string SelectDocument { get; set; }

        /// <summary>
        /// Gets or sets DateDue 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? DateDue { get; set; }

        /// <summary>
        /// Gets or sets JobApplyMethod 
        /// </summary>
        public JobApplyMethod JobApplyMethod { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        public string OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets FromPaymentCode 
        /// </summary>
        public string FromPaymentCode { get; set; }

        /// <summary>
        /// Gets or sets ThruPaymentCode 
        /// </summary>
        public string ThruPaymentCode { get; set; }

        /// <summary>
        /// Gets or sets OptionalField 
        /// </summary>
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets FromOptionalFieldValue 
        /// </summary>
        public string FromOptionalFieldValue { get; set; }

        /// <summary>
        /// Gets or sets ThruOptionalFieldValue 
        /// </summary>
        public string ThruOptionalFieldValue { get; set; }

        /// <summary>
        /// Gets or sets PaymentWithHeld 
        /// </summary>
        public string PaymentWithHeld { get; set; }

        /// <summary>
        /// Gets or sets ExcludeVendor 
        /// </summary>
        public ExcludeVendor ExcludeVendorType { get; set; }

        /// <summary>
        /// Gets or sets BankCurrencyCode 
        /// </summary>
        public string BankCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets BankCurrencyDec 
        /// </summary>
        public string BankCurrencyDec { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrency 
        /// </summary>
        public string VendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrencyDec 
        /// </summary>
        public string VendorCurrencyDec { get; set; }

        /// <summary>
        /// Gets or sets BankExchangeRate 
        /// </summary>
        public string BankExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets VendorExchangeRate 
        /// </summary>
        public string VendorExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets SelectDocumentsBy 
        /// </summary>
        public SelectDocumentsby SelectDocumentsBy { get; set; }

        /// <summary>
        /// Gets or sets DocumentsToProcess 
        /// </summary>
        public DocumentstoProcess? DocumentsToProcess { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrency 
        /// </summary>
        public string MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets BankMatch 
        /// </summary>
        public BankMatch BankMatch { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        public DateTime BatchDate { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrency 
        /// </summary>
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets IsMulticurrency 
        /// </summary>
        public bool IsMulticurrency { get; set; }

        /// <summary>
        /// Gets or Sets HasOptionalFieldLicence
        /// </summary>
        public bool HasOptionalFieldLicence { get; set; }

        /// <summary>
        /// To get VendorOptionalField 
        /// </summary>
        public IEnumerable<OptionalFieldDescription> VendorOptionalField { get; set; }

        /// <summary>
        /// Gets or sets FromOptional 
        /// </summary>
        public string FromOptional { get; set; }

        /// <summary>
        /// Gets or sets ToOptional 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToOptional { get; set; }

        /// <summary>
        /// Gets or Sets Select3 
        /// </summary>
        public OptionalFieldDescription Select3 { get; set; }

        /// <summary>
        /// Gets or sets Range3From 
        /// </summary>
        public string VendorBankCode { get; set; }

        /// <summary>
        /// Gets or sets Range3To 
        /// </summary>
        public string ExcludeVendor { get; set; }
    }
}