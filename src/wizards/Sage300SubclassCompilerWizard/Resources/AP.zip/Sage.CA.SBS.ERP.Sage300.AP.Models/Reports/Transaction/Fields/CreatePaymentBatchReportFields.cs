﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.Transaction
{
    /// <summary>
    /// Class Create PaymentBatch Report
    /// </summary>
    public partial class CreatePaymentBatchReport
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "965AB109-9493-43C6-996F-8E2AE6659F2D";

        /// <summary>
        /// Contains list of CreatePaymentBatch Report Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for FunctionalCurrDesc
            /// </summary>
            public const string FunctionalCurrDesc = "FCURNDEC";

            /// <summary>
            /// Property for CSVFilename 
            /// </summary>
            public const string CsvFilename = "FILENAME";

            /// <summary>
            /// Property for FromAccountSet 
            /// </summary>
            public const string FromAccountSet = "FROMACCT";

            /// <summary>
            /// Property for ThruAccountSet 
            /// </summary>
            public const string ThruAccountSet = "TOACCT";

            /// <summary>
            /// Property for FromVendorNumber 
            /// </summary>
            public const string FromVendorNumber = "FROMVEN";

            /// <summary>
            /// Property for ThruVendorNumber 
            /// </summary>
            public const string ThruVendorNumber = "TOVEN";

            /// <summary>
            /// Property for FromGroupCode 
            /// </summary>
            public const string FromGroupCode = "FROMGRP";

            /// <summary>
            /// Property for ThruGroupCode 
            /// </summary>
            public const string ThruGroupCode = "TOGRP";

            /// <summary>
            /// Property for AmtBankLmt 
            /// </summary>
            public const string MaximumPaymentAmount = "FROMAMT";

            /// <summary>
            /// Property for MinimumPaymentAmount 
            /// </summary>
            public const string MinimumPaymentAmount = "TOAMT";
            /// <summary>
            /// Property for PaymentBankCode 
            /// </summary>
            public const string PaymentBankCode = "BANKCODE";

            /// <summary>
            /// Property for PaymentDate 
            /// </summary>
            public const string PaymentDate = "CHECKDATE";

            /// <summary>
            /// Property for SelectDocumentsBy 
            /// </summary>
            public const string SelectDocumentsBy = "RUNTYPE";

            /// <summary>
            /// Property for DateDue 
            /// </summary>
            public const string DateDue = "BEFDATE";

            /// <summary>
            /// Property for FromDiscountDate 
            /// </summary>
            public const string FromDiscountDate = "FRDISCDATE";

            /// <summary>
            /// Property for ThruDiscountDate 
            /// </summary>
            public const string ThruDiscountDate = "TODISCDATE";

            /// <summary>
            /// Property for SelectDocument 
            /// </summary>
            public const string SelectDocument = "SELECTED?";

            /// <summary>
            /// Property for PaymentWithHeld 
            /// </summary>
            public const string PaymentWithHeld = "PAYWTHD?";

            /// <summary>
            /// Property for MultiCurrency
            /// </summary>
            public const string MultiCurrency = "MULTCURN?";

            /// <summary>
            /// Property for VendorBankCode 
            /// </summary>
            public const string VendorBankCode = "VENBKCD?";

            /// <summary>
            /// Property for ExcludeVendor 
            /// </summary>
            public const string ExcludeVendor = "EXCLVEN?";

            /// <summary>
            /// Property for BankCurrencyCode 
            /// </summary>
            public const string BankCurrencyCode = "BANKCURN";

            /// <summary>
            /// Property for BankCurrencyDec
            /// </summary>
            public const string BankCurrencyDec = "BCURNDEC";

            /// <summary>
            /// Property for VendorCurrency
            /// </summary>
            public const string VendorCurrency = "VENCURN";

            /// <summary>
            /// Property for VendorCurrencyDec
            /// </summary>
            public const string VendorCurrencyDec = "VCURNDEC";

            /// <summary>
            /// Property for HomeCurrency
            /// </summary>
            public const string HomeCurrency = "HOMECURN";



            /// <summary>
            /// Property for BankExchangeRate 
            /// </summary>
            public const string BankExchangeRate = "BKRATE";

            /// <summary>
            /// Property for VendorExchangeRate 
            /// </summary>
            public const string VendorExchangeRate = "VENDRATE";

            /// <summary>
            /// Property for JobApplyMethod 
            /// </summary>
            public const string JobApplyMethod = "APPLYMETH";

            /// <summary>
            /// Property for FromPaymentCode 
            /// </summary>
            public const string FromPaymentCode = "PMCODEFROM";

            /// <summary>
            /// Property for ThruPaymentCode 
            /// </summary>
            public const string ThruPaymentCode = "PMCODETHRU";

            /// <summary>
            /// Property for OptionalField 
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for FromOptionalFieldValue 
            /// </summary>
            public const string FromOptionalFieldValue = "VALUEFROM";

            /// <summary>
            /// Property for ThruOptionalFieldValue 
            /// </summary>
            public const string ThruOptionalFieldValue = "VALUETHRU";

            /// <summary>
            /// Property for BatchDate 
            /// </summary>
            public const string BatchDate = "BATCHDATE";

            /// <summary>
            /// Property for BankRate 
            /// </summary>
            public const string BankRate = "BKRATE";

            /// <summary>
            /// Property for VendorRate 
            /// </summary>
            public const string VendorRate = "VENDRATE";

            #endregion
        }
    }
}