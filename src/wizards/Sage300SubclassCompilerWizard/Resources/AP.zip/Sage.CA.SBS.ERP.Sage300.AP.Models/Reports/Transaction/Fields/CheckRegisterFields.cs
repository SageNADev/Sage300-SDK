/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.Transaction
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CheckRegister Constants 
    /// </summary>
    public partial class CheckRegister
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AP0058";

        /// <summary>
        /// Contains list of CheckRegister Field Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Field property for From Posting Sequence
            /// </summary>
            public const string FromPostingSequence = "FROMSEQ";

            /// <summary>
            /// Field property for To Posting Sequence
            /// </summary>
            public const string ToPostingSequence = "TOSEQ";

            /// <summary>
            /// Field property for IsPrintGlSummary
            /// </summary>
            public const string IsPrintGlSummary = "SWPRINTGLSUMMARY";

            /// <summary>
            /// Field property for IsMulticurrency
            /// </summary>
            public const string IsMulticurrency = "SWMULTICURN";

            /// <summary>
            /// Field property for Functional Currency Decimals
            /// </summary>
            public const string FunctionalCurrencyDecimals = "FCURNDEC";

            /// <summary>
            /// Field property for IsGLActive
            /// </summary>
            public const string IsGLActive = "SWGLACTIVE";

            #endregion
        }

        /// <summary>
        /// Contains list of Check Register Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for From Posting Sequence
            /// </summary>
            public const string FromPostingSequence = "2";

            /// <summary>
            /// Property Indexer for To Posting Sequence
            /// </summary>
            public const string ToPostingSequence = "3";

            /// <summary>
            /// Property Indexer for IsPrintGlSummary
            /// </summary>
            public const string IsPrintGlSummary = "4";

            /// <summary>
            /// Property Indexer for IsMulticurrency
            /// </summary>
            public const string IsMulticurrency = "5";

            /// <summary>
            /// Property Indexer for Functional Currency Decimals
            /// </summary>
            public const string FunctionalCurrencyDecimals = "6";

            /// <summary>
            /// Property Indexer for IsGLActive
            /// </summary>
            public const string IsGLActive = "7";

            #endregion
        }
    }
}