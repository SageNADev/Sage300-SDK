﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.Transaction
{
    /// <summary>
    /// partial class Posting Error
    /// </summary>
    public partial class PostingError
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "";

        /// <summary>
        /// Contains list of CheckRegister Field Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Field property for From Posting Sequence
            /// </summary>
            public const string FromPostingSequence = "FROMSEQ";

            /// <summary>
            /// Field property for To Posting Sequence
            /// </summary>
            public const string ToPostingSequence = "TOSEQ";

            /// <summary>
            /// Report Type
            /// </summary>
            public const string ReportType = "RPTTYPE";

            /// <summary>
            /// Error Type
            /// </summary>
            public const string ErrorType = "ERRTYPE";

            #endregion
        }

    }
}
