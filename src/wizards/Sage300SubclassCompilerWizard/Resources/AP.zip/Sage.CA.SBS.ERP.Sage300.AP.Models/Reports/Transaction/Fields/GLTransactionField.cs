﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.Transaction
{
    /// <summary>
    /// GL Transaction fields constant value
    /// </summary>
    public partial class GLTransaction
    {
        /// <summary>
        /// The Entity name
        /// </summary>
        public const string EntityName = "C99C037A-155D-473C-8529-37E0C5BDFE99";

        /// <summary>
        /// Contains list of GLTransactionsField Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            
            /// <summary>
            /// Field property for Batch type invoice
            /// </summary>
            public const string BatchTypeInvoice = "SWINVOICE";

            /// <summary>
            /// Field property for From Invoice Sequence
            /// </summary>
            public const string FromInvoiceSequence = "FROMINVOICESEQ";

            /// <summary>
            /// Field property for To Invoice Sequence
            /// </summary>
            public const string ToInvoiceSequence = "TOINVOICESEQ";

            /// <summary>
            /// Field property for Batch Type Payment
            /// </summary>
            public const string BatchTypePayment = "SWPAYMENT";

            /// <summary>
            /// Field property for From Payment Sequence
            /// </summary>
            public const string FromPaymentSequence = "FROMPAYMENTSEQ";

            /// <summary>
            /// Field property for To Payment Sequence
            /// </summary>
            public const string ToPaymentSequence = "TOPAYMENTSEQ";

            /// <summary>
            /// Field property for Batch Type Adjustment
            /// </summary>
            public const string BatchTypeAdjustment = "SWADJUSTMENT";

            /// <summary>
            /// Field property for From Adjustment Sequence
            /// </summary>
            public const string FromAdjustmentSequence = "FROMADJUSTMENTSEQ";

            /// <summary>
            /// Field property for To Adjustment Sequence
            /// </summary>
            public const string ToAdjustmentSequence = "TOADJUSTMENTSEQ";

            /// <summary>
            /// Field property for Batch Type Revaluation
            /// </summary>
            public const string BatchTypeRevaluation = "SWREVALUATION";

            /// <summary>
            /// Field property for From Revaluation Sequence
            /// </summary>
            public const string FromRevaluationSequence = "FROMREVALUATIONSEQ";

            /// <summary>
            /// Field property for To Revaluation Sequence
            /// </summary>
            public const string ToRevaluationSequence = "TOREVALUATIONSEQ";

            /// <summary>
            /// Field property for Functional Currency Decimal
            /// </summary>
            public const string FunctionalCurrencyDecimal = "FCURNDEC";

            /// <summary>
            /// Field property for Source Currency
            /// </summary>
            public const string SourceCurrency = "SWSRCCURN";
            
            /// <summary>
            /// Field property for is multicurrency
            /// </summary>
            public const string IsMulticurrency = "SWMULTICURN";

            /// <summary>
            /// Field property for Active
            /// </summary>
            public const string IsGLActive = "SWGLACTIVE";

            #endregion Properties
        }
    }
}
