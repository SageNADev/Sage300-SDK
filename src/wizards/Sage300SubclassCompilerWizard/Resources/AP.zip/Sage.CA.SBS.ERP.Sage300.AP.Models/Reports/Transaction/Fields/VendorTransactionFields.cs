﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.Transaction
{
    /// <summary>
    /// Contains list of Vendor Transaction report constants.
    /// </summary>
    public partial class VendorTransaction
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "C3E5F66B-6BB0-4ED6-9B41-E27EB0605DE3";

        /// <summary>
        /// Vendor Transaction Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for SessionDate
            /// </summary>
            public const string SessionDate = "SESSDATE";

            /// <summary>
            /// Property for Multicurrency
            /// </summary>
            public const string Multicurrency = "MCURCUST?";

            /// <summary>
            /// Property for FunctionalCurrencyDecimals
            /// </summary>
            public const string FunctionalCurrencyDecimals = "FCURNDEC";

            /// <summary>
            /// Property for TransTypeInvoice
            /// </summary>
            public const string TransTypeInvoice = "INVOICE?";

            /// <summary>
            /// Property for TransTypeDebit
            /// </summary>
            public const string TransTypeDebit = "DEBIT?";

            /// <summary>
            /// Property for TransTypeCredit
            /// </summary>
            public const string TransTypeCredit = "CREDIT?";

            /// <summary>
            /// Property for TransTypeInterest
            /// </summary>
            public const string TransTypeInterest = "INTEREST?";

            /// <summary>
            /// Property for TransTypePrepayment
            /// </summary>
            public const string TransTypePrepayment = "PREPAY?";

            /// <summary>
            /// Property for TransTypePayment
            /// </summary>
            public const string TransTypePayment = "PAYMENT?";

            /// <summary>
            /// Property for Format
            /// </summary>
            public const string Format = "FORMAT";

            /// <summary>
            /// Property for AmountType
            /// </summary>
            public const string AmountType = "AMTTYPE";

            /// <summary>
            /// Property for From1
            /// </summary>
            public const string From1 = "FROM1";

            /// <summary>
            /// Property for To1
            /// </summary>
            public const string To1 = "TO1";

            /// <summary>
            /// Property for From2
            /// </summary>
            public const string From2 = "FROM2";

            /// <summary>
            /// Property for To2
            /// </summary>
            public const string To2 = "TO2";

            /// <summary>
            /// Property for From3
            /// </summary>
            public const string From3 = "FROM3";

            /// <summary>
            /// Property for To3
            /// </summary>
            public const string To3 = "TO3";

            /// <summary>
            /// Property for From4
            /// </summary>
            public const string From4 = "FROM4";

            /// <summary>
            /// Property for To4
            /// </summary>
            public const string To4 = "TO4";

            /// <summary>
            /// Property for Select1 
            /// </summary>
            public const string Select1 = "SELECT1";

            /// <summary>
            /// Property for Select2 
            /// </summary>
            public const string Select2 = "SELECT2";

            /// <summary>
            /// Property for Select3 
            /// </summary>
            public const string Select3 = "SELECT3";

            /// <summary>
            /// Property for Select4 
            /// </summary>
            public const string Select4 = "SELECT4";

            /// <summary>
            /// Property for Sort1 
            /// </summary>
            public const string Sort1 = "SORT1";

            /// <summary>
            /// Property for Sort2 
            /// </summary>
            public const string Sort2 = "SORT2";

            /// <summary>
            /// Property for Sort3 
            /// </summary>
            public const string Sort3 = "SORT3";

            /// <summary>
            /// Property for Sort4 
            /// </summary>
            public const string Sort4 = "SORT4";

            /// <summary>
            /// Property for SortBy 
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// Property for FromDocumentDate
            /// </summary>
            public const string FromDocumentDate = "FMDOCDATE";

            /// <summary>
            /// Property for ToDocumentDate
            /// </summary>
            public const string ToDocumentDate = "TODOCDATE";

            /// <summary>
            /// Property for ToYear
            /// </summary>
            public const string ToYear = "TOYEAR";

            /// <summary>
            /// Property for ToPeriod
            /// </summary>
            public const string ToPeriod = "TOPERIOD";

            /// <summary>
            /// Property for ShowDetail
            /// </summary>
            public const string ShowDetail = "DETAIL?";

            /// <summary>
            /// Property for IncludeZeroBalanceVendors
            /// </summary>
            public const string IncludeZeroBalanceVendors = "ZEROBAL?";

            /// <summary>
            /// Property for IncludeTotalsByTransType
            /// </summary>
            public const string IncludeTotalsByTransType = "TYPETOTAL?";

            /// <summary>
            /// Property for PhoneFormat
            /// </summary>
            public const string PhoneFormat = "PHNFMT?";

            /// <summary>
            /// Property for IncludeContact
            /// </summary>
            public const string IncludeContact = "CONTACT?";

            /// <summary>
            /// Property for IncludeSpaceForComments
            /// </summary>
            public const string IncludeSpaceForComments = "COMMENT?";

            /// <summary>
            /// Property for Type1 
            /// </summary>
            public const string Type1 = "TYPE1";

            /// <summary>
            /// Property for Type2 
            /// </summary>
            public const string Type2 = "TYPE2";

            /// <summary>
            /// Property for Type3 
            /// </summary>
            public const string Type3 = "TYPE3";

            /// <summary>
            /// Property for Type4 
            /// </summary>
            public const string Type4 = "TYPE4";

            /// <summary>
            /// Property for FromYear 
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for FromPeriod 
            /// </summary>
            public const string FromPeriod = "FROMPERIOD";

            /// <summary>
            /// Property for SelectSequence 
            /// </summary>
            public const string SelectSequence = "SELSEQ";

            /// <summary>
            /// Property for Group1Total 
            /// </summary>
            public const string Group1Total = "GRP1TOTAL?";

            /// <summary>
            /// Property for Group2Total 
            /// </summary>
            public const string Group2Total = "GRP2TOTAL?";

            /// <summary>
            /// Property for Group3Total 
            /// </summary>
            public const string Group3Total = "GRP3TOTAL?";

            /// <summary>
            /// Property for Group4Total 
            /// </summary>
            public const string Group4Total = "GRP4TOTAL?";

            /// <summary>
            /// Property for ShowFullyPaid 
            /// </summary>
            public const string ShowFullyPaid = "FULLYPAID?";            

            /// <summary>
            /// Property for SortByTransactionType 
            /// </summary>
            public const string SortByTransactionType = "SORTBYTRANSTYPE?";

            /// <summary>
            /// Property for UseDocNum 
            /// </summary>
            public const string UseDocNum = "USE1099?";

            /// <summary>
            /// Property for Group1Title 
            /// </summary>
            public const string Group1Title = "GRP1TITLE?";
            /// <summary>
            /// 
            /// Property for Group2Title 
            /// </summary>
            public const string Group2Title = "GRP2TITLE?";

            /// <summary>
            /// Property for Group3Title 
            /// </summary>
            public const string Group3Title = "GRP3TITLE?";

            /// <summary>
            /// Property for Group4Title 
            /// </summary>
            public const string Group4Title = "GRP4TITLE?";

            #endregion
        }
    }
}
