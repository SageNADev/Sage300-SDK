﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.Transaction
{
    /// <summary>
    /// Class CheckRegister
    /// </summary>
    public partial class CheckRegister : ReportBase
    {
        /// <summary>
        /// gets or sets FromPostingSequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromPostingSequence", ResourceType = typeof(CheckRegisterResx))]
        public string FromPostingSequence { get; set; }

        /// <summary>
        /// gets or sets ToPostingSequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToPostingSequence", ResourceType = typeof(CheckRegisterResx))]
        public string ToPostingSequence { get; set; }

        /// <summary>
        /// gets or sets PrintGLSummary
        /// </summary>
        [Display(Name = "PrintGLSummary", ResourceType = typeof(CheckRegisterResx))]
        public bool IsPrintGlSummary { get; set; }

        /// <summary>
        /// gets or sets Multicurrency
        /// </summary>
        public bool IsMulticurrency { get; set; }

        /// <summary>
        /// gets or sets Functional currency decimals
        /// </summary>
        public decimal FunctionalCurrencyDecimals { get; set; }

        /// <summary>
        /// gets or sets IsGLActive
        /// </summary>
        public bool IsGLActive { get; set; }

        /// <summary>
        /// Gets or sets PrintGLSummary 
        /// </summary>
        public int PrintGLSummary { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrency
        /// </summary>
        public int MultiCurrency { get; set; }

    }
}