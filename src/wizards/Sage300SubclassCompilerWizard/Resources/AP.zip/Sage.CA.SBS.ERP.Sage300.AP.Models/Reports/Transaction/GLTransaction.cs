﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.Transaction
{
    /// <summary>
    /// GL Transaction 
    /// </summary>
    public partial class GLTransaction : ReportBase
    {

        /// <summary>
        /// Gets or sets Batch Type Invoice
        /// </summary>
        [Display(Name = "Invoice1", ResourceType = typeof(APCommonResx))]
        public bool BatchTypeInvoice { get; set; }

        /// <summary>
        ///  Gets or sets From Invoice Sequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromInvoiceSequence { get; set; }

        /// <summary>
        ///  Gets or sets To Invoice Sequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToInvoiceSequence { get; set; }

        /// <summary>
        ///  Gets or sets Batch Type Payment
        /// </summary>
        [Display(Name = "Payment", ResourceType = typeof(APCommonResx))]
        public bool BatchTypePayment { get; set; }

        /// <summary>
        ///  Gets or sets From Payment Sequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromPaymentSequence { get; set; }

        /// <summary>
        ///  Gets or sets To Payment Sequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToPaymentSequence { get; set; }

        /// <summary> 
        ///  Gets or sets Batch Type Adjustment
        /// </summary>
        [Display(Name = "Adjustment", ResourceType = typeof(APCommonResx))]
        public bool BatchTypeAdjustment { get; set; }

        /// <summary>
        ///  Gets or sets From Adjustment Sequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromAdjustmentSequence { get; set; }

        /// <summary>
        ///  Gets or sets To Adjustment Sequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToAdjustmentSequence { get; set; }

        /// <summary>
        ///  Gets or sets Batch Type Revaluation
        /// </summary>
        [Display(Name = "Revaluation", ResourceType = typeof(APCommonResx))]
        public bool BatchTypeRevaluation { get; set; }

        /// <summary>
        ///  Gets or sets From Revaluation Sequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromRevaluationSequence { get; set; }

        /// <summary>
        /// Gets or sets Posting sequence Revaluation
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToRevaluationSequence { get; set; }

        /// <summary>
        /// Gets or sets Currency 
        /// </summary>
        public CurrencyType Currency { get; set; }

        /// <summary>
        /// Gets or sets ReportFormat
        /// </summary>
        public ReportFormatType ReportFormat { get; set; }

        /// <summary>
        /// Gets or sets SortBy
        /// </summary>
        public SortByType SortBy { get; set; }

        /// <summary>
        /// Gets or sets functional currency decimal
        /// </summary>
        public decimal FunctionalCurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets value for the Multicurrency
        /// </summary>
        public bool IsMulticurrency { get; set; }

        /// <summary>
        /// Gets or sets IsGLActive
        /// </summary>
        public bool IsGLActive { get; set; }

        /// <summary>
        /// Gets or sets RevaluationCheck 
        /// </summary>
        public bool RevaluationCheck { get; set; }

        /// <summary>
        /// Gets or sets PaymentCheck 
        /// </summary>
        public bool PaymentCheck { get; set; }

        /// <summary>
        /// Gets or sets InvoiceCheck 
        /// </summary>
        public bool InvoiceCheck { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentCheck 
        /// </summary>
        public bool AdjustmentCheck { get; set; }

        /// <summary>
        /// Gets and sets module level MultiCurrency
        /// </summary>
        public bool ModuleLevelMultiCurrency { get; set; }

    }

}
