﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports.Transaction;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Customization.Validators;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.Transaction
{
    /// <summary>
    /// Vendor Transaction model class
    /// </summary>
    public partial class VendorTransaction: ReportBase
    {
        /// <summary>
        /// Gets or sets ReportType
        /// </summary>
        [Display(Name = "ReportType", ResourceType = typeof(APCommonResx))]
        public  VendorTransactionReportType ReportType { get; set; }

        /// <summary>
        /// Gets or sets the FromDocumentDate
        /// </summary>
        [Display(Name = "DocumentDate", ResourceType = typeof(APCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromDocumentDate { get; set; }

        /// <summary>
        /// Gets or sets the ToDocumentDate
        /// </summary>
        [Display(Name = "DocumentDate", ResourceType = typeof(APCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ToDocumentDate { get; set; }

        /// <summary>
        /// Gets or sets FromYear
        /// </summary>
        [Display(Name = "YearPeriod", ResourceType = typeof(APCommonResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets FromPeriod
        /// </summary>
        [Display(Name = "YearPeriod", ResourceType = typeof(APCommonResx))]
        [ValidateFiscalPeriod(ModuleName.AP, ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets ToYear
        /// </summary>
        [Display(Name = "YearPeriod", ResourceType = typeof(APCommonResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or sets ToPeriod
        /// </summary>
        [Display(Name = "YearPeriod", ResourceType = typeof(APCommonResx))]
        [ValidateFiscalPeriod(ModuleName.AP, ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToPeriod { get; set; }

        /// <summary>
        /// Gets or sets Select1
        /// </summary>
        public string Select1 { get; set; }

        /// <summary>
        /// Gets or sets Select2
        /// </summary>
        public string Select2 { get; set; }

        /// <summary>
        /// Gets or sets Select3
        /// </summary>
        public string Select3 { get; set; }

        /// <summary>
        /// Gets or sets Select4
        /// </summary>
        public string Select4 { get; set; }

        /// <summary>
        /// Gets or sets Sort1
        /// </summary>
        public string Sort1 { get; set; }

        /// <summary>
        /// Gets or sets Sort2
        /// </summary>
        public string Sort2 { get; set; }

        /// <summary>
        /// Gets or sets Sort3
        /// </summary>
        public string Sort3 { get; set; }

        /// <summary>
        /// Gets or sets Sort4
        /// </summary>
        public string Sort4 { get; set; }

        /// <summary>
        /// Gets or sets Type1
        /// </summary>
        public string Type1 { get; set; }

        /// <summary>
        /// Gets or sets Type2
        /// </summary>
        public string Type2 { get; set; }

        /// <summary>
        /// Gets or sets Type3
        /// </summary>
        public string Type3 { get; set; }

        /// <summary>
        /// Gets or sets Type4
        /// </summary>
        public string Type4 { get; set; }

        /// <summary>
        /// Gets or sets From1
        /// </summary>
        public string From1 { get; set; }

        /// <summary>
        /// Gets or sets From2
        /// </summary>
        public string From2 { get; set; }

        /// <summary>
        /// Gets or sets From3
        /// </summary>
        public string From3 { get; set; }

        /// <summary>
        /// Gets or sets From4
        /// </summary>
        public string From4 { get; set; }

        /// <summary>
        /// Gets or sets To1
        /// </summary>
        public string To1 { get; set; }

        /// <summary>
        /// Gets or sets To2
        /// </summary>
        public string To2 { get; set; }

        /// <summary>
        /// Gets or sets To3
        /// </summary>
        public string To3 { get; set; }

        /// <summary>
        /// Gets or sets To4
        /// </summary>
        public string To4 { get; set; }

        /// <summary>
        /// Gets or sets Group1Title 
        /// </summary>
        public bool Group1Title { get; set; }

        /// <summary>
        /// Gets or sets Group2Title
        /// </summary>
        public bool Group2Title { get; set; }

        /// <summary>
        /// Gets or sets Group3Title 
        /// </summary>
        public bool Group3Title { get; set; }

        /// <summary>
        /// Gets or sets Group4Title 
        /// </summary>
        public bool Group4Title { get; set; }

        /// <summary>
        /// Gets or sets Group1Total 
        /// </summary>
        public bool Group1Total { get; set; }

        /// <summary>
        /// Gets or sets Group2Total
        /// </summary>
        public bool Group2Total { get; set; }

        /// <summary>
        /// Gets or sets Group3Total
        /// </summary>
        public bool Group3Total { get; set; }

        /// <summary>
        /// Gets or sets Group4Total
        /// </summary>
        public bool Group4Total { get; set; }

        /// <summary>
        /// Gets or sets IncludeContact
        /// </summary>
        [Display(Name = "ContactPhoneCredit", ResourceType = typeof(APCommonResx))]
        public bool IncludeContact { get; set; }

        /// <summary>
        /// Gets or sets IncludeSpaceForComments
        /// </summary>
        [Display(Name = "SpaceForComments", ResourceType = typeof(APCommonResx))]
        public bool IncludeSpaceForComments { get; set; }

        /// <summary>
        /// Gets or sets IncludeZeroBalanceVendors
        /// </summary>
        [Display(Name = "VendorsZeroBalance", ResourceType = typeof(APCommonResx))]
        public bool IncludeZeroBalanceVendors { get; set; }

        /// <summary>
        /// Gets or sets IncludeTotalsByTransType
        /// </summary>
        [Display(Name = "TotalsByTransType", ResourceType = typeof(VendorTransactionsReportResx))]
        public bool IncludeTotalsByTransType { get; set; }

        /// <summary>
        /// Gets or sets SortByTransactionType
        /// </summary>
        [Display(Name = "SortTransByType", ResourceType = typeof(APCommonResx))]
        public bool SortByTransactionType { get; set; }

        /// <summary>
        /// Gets or sets ShowFullyPaid
        /// </summary>
        [Display(Name = "FullyPaidTransaction", ResourceType = typeof(APCommonResx))]
        public bool ShowFullyPaid { get; set; }

        /// <summary>
        /// Gets or sets ShowDetail
        /// </summary>
        [Display(Name = "AppliedDetails", ResourceType = typeof(APCommonResx))]
        public bool ShowDetail { get; set; }

        /// <summary>
        /// Gets or sets TransactionTypes 
        /// </summary>
        [ValidateListForSelection]
        [Display(Name = "TransactionType", ResourceType = typeof(APCommonResx))]
        public List<MultiSelect> TransactionTypes { get; set; }

        /// <summary>
        /// Gets or sets CurrencyType 
        /// </summary>
        [Display(Name = "PrintAmountsIn", ResourceType = typeof(APCommonResx))]
        public FuncOrVendorCurrency CurrencyType { get; set; }

        /// <summary>
        /// Gets or sets SelectSequence
        /// </summary>
        public string SelectSequence { get; set; }

        /// <summary>
        /// Gets or sets SequenceNumber 
        /// </summary>
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets UseDocNum
        /// </summary>
        public bool UseDocNum { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrency
        /// </summary>
        public bool MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrency
        /// </summary>
        public decimal HomeCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets PhoneFormat
        /// </summary>
        public bool PhoneFormat { get; set; }

        /// <summary>
        /// Gets or sets SessionDate
        /// </summary>
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets HasOptFieldLicense
        /// </summary>
        public bool HasOptFieldLicense { get; set; }

        /// <summary>
        /// Gets or sets SortIndex1
        /// </summary>
        public string SortIndex1 { get; set; }

        /// <summary>
        /// Gets or sets SortIndex2
        /// </summary>
        public string SortIndex2 { get; set; }

        /// <summary>
        /// Gets or sets SortIndex3
        /// </summary>
        public string SortIndex3 { get; set; }

        /// <summary>
        /// Gets or sets SortIndex4
        /// </summary>
        public string SortIndex4 { get; set; }

        /// <summary>
        /// Gets or sets optionalFieldDesc1
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc1 { get; set; }

        /// <summary>
        /// Gets or sets optionalFieldDesc2
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc2 { get; set; }

        /// <summary>
        /// Gets or sets optionalFieldDesc3
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc3 { get; set; }

        /// <summary>
        /// Gets or sets optionalFieldDesc4
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc4 { get; set; }

        /// <summary>
        /// Gets or sets Range1IndexValue 
        /// </summary>
        public int Range1IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range2IndexValue 
        /// </summary>
        public int Range2IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range3IndexValue 
        /// </summary>
        public int Range3IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range4IndexValue 
        /// </summary>
        public int Range4IndexValue { get; set; }

        /// <summary>
        /// Gets or sets FieldName1 
        /// </summary>
        public string FieldName1 { get; set; }

        /// <summary>
        /// Gets or sets FieldName2 
        /// </summary>
        public string FieldName2 { get; set; }

        /// <summary>
        /// Gets or sets FieldName3 
        /// </summary>
        public string FieldName3 { get; set; }

        /// <summary>
        /// Gets or sets FieldName4 
        /// </summary>
        public string FieldName4 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex1 
        /// </summary>
        public int SortFieldIndex1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex2 
        /// </summary>
        public int SortFieldIndex2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex3 
        /// </summary>
        public int SortFieldIndex3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex4 
        /// </summary>
        public int SortFieldIndex4 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName1 
        /// </summary>
        public string SortFieldName1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName2 
        /// </summary>
        public string SortFieldName2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName3 
        /// </summary>
        public string SortFieldName3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName4 
        /// </summary>
        public string SortFieldName4 { get; set; }
    }
}
