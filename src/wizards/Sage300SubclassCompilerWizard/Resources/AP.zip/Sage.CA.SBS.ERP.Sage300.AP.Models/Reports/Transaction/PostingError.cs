﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports.Transaction;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.Transaction
{
    /// <summary>
    /// Posting Errors model
    /// </summary>
    public partial class PostingError : ReportBase
    {
        /// <summary>
        /// gets or sets From Posting Sequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromPostingSequence", ResourceType = typeof(APCommonResx))]
        public string FromPostingSequence { get; set; }

        /// <summary>
        /// gets or sets To Posting Sequence
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToPostingSequence", ResourceType = typeof(APCommonResx))]
        public string ToPostingSequence { get; set; }

        /// <summary>
        /// gets or sets Error Type
        /// </summary>
        public string ErrorType { get; set; }

        /// <summary>
        /// gets or sets Report Type
        /// </summary>
        public ReportType ReportType { get; set; }

        /// <summary>
        /// gets or sets Adjustment Post Sequence
        /// </summary>
        public string AdjustmentPostSeq { get; set; }

        /// <summary>
        /// gets or sets Payment Post Sequence
        /// </summary>
        public string PaymentPostSeq { get; set; }

        /// <summary>
        /// Invoice Post Sequence
        /// </summary>
        public string InvoicePostSeq { get; set; }

        /// <summary>
        /// Security Invoice
        /// </summary>
        public bool SecurityInvoice { get; set; }
        /// <summary>
        /// Security Payment
        /// </summary>
        public bool SecurityPayment { get; set; }
        /// <summary>
        /// Security Adjustment
        /// </summary>
        public bool SecurityAdjustment { get; set; }
    }
}
