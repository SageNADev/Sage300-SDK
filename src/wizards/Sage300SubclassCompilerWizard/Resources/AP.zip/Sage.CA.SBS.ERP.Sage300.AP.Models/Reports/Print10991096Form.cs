// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    public partial class Print10991096Form : ReportBase
    {
        /// <summary>
        /// Get or set the Report Type
        /// </summary>
        [Display(Name = "Form", ResourceType = typeof(APCommonResx))]
        public Print10991096FormReportTypes ReportTypes { get; set; } = Print10991096FormReportTypes.Print1099;

        /// <summary>
        /// Gets or sets Tax Number 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxNumber", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceType = typeof(Print10991096FormsResx), ErrorMessageResourceName = "TaxNumberErrorMessage")]
        public string FedId { get; set; }

        /// <summary>
        /// Gets or sets Address1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address", ResourceType = typeof(APCommonResx))]
        public string Address1 { get; set; }

        /// <summary>
        /// Gets or sets Address2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(Print10991096FormsResx))]
        public string Address2 { get; set; }

        /// <summary>
        /// Gets or sets City 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(APCommonResx))]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProv", ResourceType = typeof(APCommonResx))]
        public string State { get; set; }

        /// <summary>
        /// Gets or sets Zip 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof(APCommonResx))]
        public string Zip { get; set; }

        /// <summary>
        /// Gets or sets Country 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(APCommonResx))]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets Contact 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(APCommonResx))]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets Phone 
        /// </summary>        
        [Display(Name = "Phone", ResourceType = typeof(Print10991096FormsResx))]
        public string Phone { get; set; }


        /// <summary>
        /// Gets or sets Email 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(APCommonResx))]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets Title 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Title", ResourceType = typeof(Print10991096FormsResx))]
        public string Title { get; set; }


        /// <summary>
        /// Gets or sets TransferAgent 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransferAgent", ResourceType = typeof(Print10991096FormsResx))]
        public string TransferAgent { get; set; }

        /// <summary>
        /// Gets or sets Fax 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(APCommonResx))]
        public string Fax { get; set; }

        /// <summary>
        /// Gets or sets Format Phone Number 
        /// </summary>        
        public bool FormatPhoneNumber { get; set; }


        /// <summary>
        /// Gets or sets Payer Name 
        /// </summary>        
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof(APCommonResx))]
        public string PayerName { get; set; }


        /// <summary>
        /// Gets or sets Pre-Addressed From 
        /// </summary>        
        [Display(Name = "PreaddressedForm", ResourceType = typeof(Print10991096FormsResx))]
        public bool PreaddressedForm { get; set; }

        /// <summary>
        /// Gets or sets Final Filing 
        /// </summary>        
        [Display(Name = "FinalFiling", ResourceType = typeof(Print10991096FormsResx))]
        public bool FinalFiling { get; set; }


        /// <summary>
        /// Gets or sets Tax Number Type 
        /// </summary>        
        [Display(Name = "TaxNumberType", ResourceType = typeof(Print10991096FormsResx))]
        public TaxNumberType TaxNumberType { get; set; }


        /// <summary>
        /// Gets or sets Legal Name 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LegalName", ResourceType = typeof(APCommonResx))]
        public string LegalName { get; set; }

        /// <summary>
        /// Gets or sets File Name 
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets the Tax Year
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxYear", ResourceType = typeof(Print10991096FormsResx))]
        [Range(1, 9999, ErrorMessageResourceType = typeof(Print10991096FormsResx), ErrorMessageResourceName = "TaxYearErrorMessage")]
        [Required(ErrorMessageResourceType = typeof(Print10991096FormsResx), ErrorMessageResourceName = "TaxYearErrorMessage")]
        public string TaxYear { get; set; }

        /// <summary>
        /// Gets or sets From Vendor Number 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromVendorNumber", ResourceType = typeof(APCommonResx))]
        public string FromVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets To Vendor Number 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        public string ToVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets Report Name
        /// </summary>
        public string ReportName { get; set; }

        /// <summary>
        /// Gets or set Report File Name
        /// </summary>
        [Display(Name = "UseForm", ResourceType = typeof(Print10991096FormsResx))]
        public string ReportFileName { get; set; }

        /// <summary>
        /// Gets or sets Foreign Entity 
        /// </summary>
        [Display(Name = "ForeignEntity", ResourceType = typeof(Print10991096FormsResx))]
        public bool ForeignEntity { get; set; }

        [Display(Name = "FormType", ResourceType = typeof(Print10991096FormsResx))]
        public Print1099FormTypes FormType { get; set; } = Print1099FormTypes._1099Misc;

        #region CompanyProfile
        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        public CompanyProfile CompanyProfile { get; set; }
        #endregion
    }
}
