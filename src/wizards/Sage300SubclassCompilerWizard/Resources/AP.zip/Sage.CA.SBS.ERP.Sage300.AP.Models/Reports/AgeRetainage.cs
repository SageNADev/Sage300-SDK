/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    public partial class AgeRetainage : ReportBase
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="AgeRetainage"/> class.
        /// </summary>
        public AgeRetainage()
        {
            Cutoffby = Cutoffby.DocDate;
            FuncOrVendorCurrency = FuncOrVendorCurrency.VendorCurrency;
            ATBOrOverdueRecReport = ATBOrOverdueRecReport.FutureRetainage;
            DetailOrSummaryReport = DetailOrSummaryReport.DetailbyDate;
        }

        #endregion

        #region properties

        /// <summary>
        /// Gets or sets RunDate 
        /// </summary>
        [Display(Name = "RunDate", ResourceType = typeof(AgeRetainageResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
             )]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime RunDate { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDateCutoffDate 
        /// </summary>
        [Display(Name = "RetainageDueDateCutoffDate", ResourceType = typeof(AgeRetainageResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
             )]
        public DateTime? RetainageDueDateCutoffDate { get; set; }

        /// <summary>
        /// Gets or sets Cutoffby 
        /// </summary>
        [Display(Name = "Cutoffby", ResourceType = typeof(AgeRetainageResx))]
        public Cutoffby Cutoffby { get; set; }

        /// <summary>
        /// Gets or sets Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Period { get; set; }

        /// <summary>
        /// Gets or sets FuncOrVendorCurrency 
        /// </summary>
        [Display(Name = "FuncOrVendorCurrency", ResourceType = typeof(AgeRetainageResx))]
        public FuncOrVendorCurrency FuncOrVendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets ATBOrOverdueRecReport 
        /// </summary>
        [Display(Name = "ATBOrOverdueRecReport", ResourceType = typeof(AgeRetainageResx))]
        public ATBOrOverdueRecReport ATBOrOverdueRecReport { get; set; }

        /// <summary>
        /// Gets or sets DetailOrSummaryReport 
        /// </summary>
        [Display(Name = "DetailOrSummaryReport", ResourceType = typeof(AgeRetainageResx))]
        public DetailOrSummaryReport DetailOrSummaryReport { get; set; }

        /// <summary>
        /// Gets or sets Current 
        /// </summary>
        [Display(Name = "Current", ResourceType = typeof(APCommonResx))]
        public decimal Period1 { get; set; }

        /// <summary>
        /// Gets or sets FirstPeriod 
        /// </summary>
        [Display(Name = "_1st", ResourceType = typeof(APCommonResx))]
        public decimal Period2 { get; set; }

        /// <summary>
        /// Gets or sets SecondPeriod 
        /// </summary>
        [Display(Name = "_2nd", ResourceType = typeof(APCommonResx))]
        public decimal Period3 { get; set; }

        /// <summary>
        /// Gets or sets ThirdPeriod 
        /// </summary>
        [Display(Name = "_3rd", ResourceType = typeof(APCommonResx))]
        public decimal Period4 { get; set; }

        /// <summary>
        /// Gets or sets Select1 
        /// </summary>
        public string Select1 { get; set; }

        /// <summary>
        /// Gets or sets Range1From 
        /// </summary>
        public string Range1From { get; set; }

        /// <summary>
        /// Gets or sets Range1To 
        /// </summary>
        public string Range1To { get; set; }

        /// <summary>
        /// Gets or sets Range1IndexValue 
        /// </summary>
        public int Range1IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Select2 
        /// </summary>
        public string Select2 { get; set; }

        /// <summary>
        /// Gets or sets Range2From 
        /// </summary>
        public string Range2From { get; set; }

        /// <summary>
        /// Gets or sets Range2To 
        /// </summary>
        public string Range2To { get; set; }

        /// <summary>
        /// Gets or sets Range2IndexValue 
        /// </summary>
        public int Range2IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Select3 
        /// </summary>
        public string Select3 { get; set; }

        /// <summary>
        /// Gets or sets Range3From 
        /// </summary>
        public string Range3From { get; set; }

        /// <summary>
        /// Gets or sets Range3To 
        /// </summary>
        public string Range3To { get; set; }

        /// <summary>
        /// Gets or sets Range3IndexValue 
        /// </summary>
        public int Range3IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Select4 
        /// </summary>
        public string Select4 { get; set; }

        /// <summary>
        /// Gets or sets Range4From 
        /// </summary>
        public string Range4From { get; set; }

        /// <summary>
        /// Gets or sets Range4To 
        /// </summary>
        public string Range4To { get; set; }

        /// <summary>
        /// Gets or sets Range4IndexValue 
        /// </summary>
        public int Range4IndexValue { get; set; }

        /// <summary>
        /// Gets or sets SequenceNumber 
        /// </summary>
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets Sort1 
        /// </summary>
        public string Sortorder { get; set; }

        /// <summary>
        /// Gets or sets Sort1 
        /// </summary>
        public string Sort1 { get; set; }

        /// <summary>
        /// Gets or sets Sort2 
        /// </summary>
        public string Sort2 { get; set; }

        /// <summary>
        /// Gets or sets Sort3 
        /// </summary>
        public string Sort3 { get; set; }

        /// <summary>
        /// Gets or sets Sort4 
        /// </summary>
        public string Sort4 { get; set; }

        /// <summary>
        /// Gets or sets IncludeTaxes 
        /// </summary>
        [Display(Name = "IncludeTaxes", ResourceType = typeof(AgeRetainageResx))]
        public bool IncludeTaxes { get; set; }

        /// <summary>
        /// Gets or sets Grp1Title
        /// </summary>
        public bool Grp1Title { get; set; }

        /// <summary>
        /// Gets or sets Grp2Title
        /// </summary>
        public bool Grp2Title { get; set; }

        /// <summary>
        /// Gets or sets Grp1Title
        /// </summary>
        public bool Grp3Title { get; set; }

        /// <summary>
        /// Gets or sets Grp1Title
        /// </summary>
        public bool Grp4Title { get; set; }

        /// <summary>
        /// Gets or sets Grp1Total
        /// </summary>
        public bool Grp1Total { get; set; }

        /// <summary>
        /// Gets or sets Grp2Total
        /// </summary>
        public bool Grp2Total { get; set; }

        /// <summary>
        /// Gets or sets Grp3Total
        /// </summary>
        public bool Grp3Total { get; set; }

        /// <summary>
        /// Gets or sets Grp4Total
        /// </summary>
        public bool Grp4Total { get; set; }

        /// <summary>
        /// Get or sets Amount type
        /// </summary>
        public string AmountType { get; set; }

        /// <summary>
        /// Gets or sets Report Title
        /// </summary>
        public string ReportTitle { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency
        /// </summary>
        public bool MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrency
        /// </summary>
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc1
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc1 { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc2
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc2 { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc3
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc3 { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc4
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc4 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex1
        /// </summary>
        public string SortIndex1 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex2
        /// </summary>
        public string SortIndex2 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex3
        /// </summary>
        public string SortIndex3 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex4
        /// </summary>
        public string SortIndex4 { get; set; }

        /// <summary>
        /// Gets or sets AppLevelMultiCurrency 
        /// </summary>
        public bool AppLevelMultiCurrency { get; set; }

        #endregion
    }
}
