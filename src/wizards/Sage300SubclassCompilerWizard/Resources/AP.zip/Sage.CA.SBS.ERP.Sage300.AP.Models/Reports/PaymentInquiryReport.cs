﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using System;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    public partial class PaymentInquiryReport : ReportBase
    {
        /// <summary>
        /// Gets or sets the property of IsShowMultiCurrency
        /// </summary>
        public bool IsShowMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets the property of FunctionalCurrency
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets the property of BankFrom
        /// </summary>
        public string BankFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of BankTo
        /// </summary>
        public string BankTo { get; set; }

        /// <summary>
        /// Gets or sets the property of VendorFrom
        /// </summary>
        public string VendorFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of VendorTo
        /// </summary>
        public string VendorTo { get; set; }

        /// <summary>
        /// Gets or sets the property of Status
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// Gets or sets the property of TransactionType
        /// </summary>
        public int TransactionType { get; set; }

        /// <summary>
        /// Gets or sets the property of PaymentType
        /// </summary>
        public int PaymentType { get; set; }

        /// <summary>
        /// Gets or sets the property of PaymentFrom
        /// </summary>
        public DateTime? PaymentFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of PaymentTo
        /// </summary>
        public DateTime? PaymentTo { get; set; }

        /// <summary>
        /// Gets or sets the YearFrom
        /// </summary>
        public int YearFrom { get; set; }

        /// <summary>
        /// Gets or sets the YearTo
        /// </summary>
        public int YearTo { get; set; }

        /// <summary>
        /// Gets or sets the property of PeriodFrom
        /// </summary>
        public int PeriodFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of PeriodTo
        /// </summary>
        public int PeriodTo { get; set; }

        /// <summary>
        /// Gets or sets the CheckNumberFrom
        /// </summary>
        public string CheckNumberFrom { get; set; }

        /// <summary>
        /// Gets or sets the CheckNumberTo
        /// </summary>
        public string CheckNumberTo { get; set; }
    }
}
