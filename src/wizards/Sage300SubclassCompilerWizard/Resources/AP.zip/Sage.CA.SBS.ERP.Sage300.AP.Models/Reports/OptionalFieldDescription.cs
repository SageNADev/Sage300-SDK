﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Class for Optional Fields Description
    /// </summary>
    public class OptionalFieldDescription
    { 
        /// <summary>
        /// Get or set Indexing
        /// </summary>
        public int Index { get; set; }

        /// <summary>
        /// Get or set Field Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Get or set the Root View ID
        /// </summary>
        public string RotoID{get; set; }
        /// <summary>
        /// for Key
        /// </summary>
        public int Key { get; set; }

        /// <summary>
        /// If it is Primary
        /// </summary>
        public bool Primary { get; set; }

        /// <summary>
        /// Type of the Field
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Minimum Length
        /// </summary>
        public string MinLength { get; set; }

        /// <summary>
        /// Get or set the Options field
        /// </summary>
        public string OptField {get; set; }
        /// <summary>
        /// Get or set the Options Field Length
        /// </summary>
        public int OptionsLength { get; set; }
        /// <summary>
        /// Maximum length
        /// </summary>
        public string MaxLength { get; set; }

        /// <summary>
        /// Get or set the Field Index
        /// </summary>
        public string FieldIndex { get; set; }

        /// <summary>
        /// If the value is used for sorting
        /// </summary>
        public bool Sort { get; set; }

        /// <summary>
        /// If the value is Required
        /// </summary>
        public bool Required { get; set; }

        /// <summary>
        /// Get or Set the Filter value 
        /// </summary>
        public string Filter { get; set; }

        /// <summary>
        /// Get or set Optional Decimal Value
        /// </summary>
        public int OptionsDecimal { get; set; }

        /// <summary>
        /// Get or set the Type Index value
        /// </summary>
        public string TypeIndex { get; set; }

        /// <summary>
        /// Get or set the Default Value
        /// </summary>
        public string DefaultValue { get; set; }
    }
}
