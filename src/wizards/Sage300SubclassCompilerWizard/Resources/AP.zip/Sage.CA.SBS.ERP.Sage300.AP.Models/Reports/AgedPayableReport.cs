﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// This class is used to generate the report for Aged Payables
    /// </summary>
    public partial class AgedPayableReport : ReportBase
    {
        #region Model properties
        /// <summary>
        /// Get or set the Report Type
        /// </summary>
        [Display(Name = "ReportType", ResourceType = typeof(APCommonResx))]
        public AgedPayableReportTypes ReportTypes { get; set; }

        /// <summary>
        /// Gets or set FromYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromYearPeriod", ResourceType = typeof(APCommonResx))]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or set FromPeriod 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromPeriod { get; set; }

        /// <summary>
        /// Get or set CutoffPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CutoffPeriod { get; set; }

        /// <summary>
        /// get or set Cutoffyear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Cutoffyear { get; set; }

        /// <summary>
        /// get or set AgeSequence
        /// </summary>
        public string AgeSequence { get; set; }

        /// <summary>
        /// get or set FiscalYear
        /// </summary>
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or set Cutoffby 
        /// </summary>
        [Display(Name = "CutoffBy", ResourceType = typeof(APCommonResx))]
        public Cutoffby Cutoffby { get; set; }

        /// <summary>
        /// Get or set PrintTransactionIn
        /// </summary>
        [Display(Name = "PrintTransactionsIn", ResourceType = typeof(APCommonResx))]
        public DetailOrSummaryReport PrintTransactionIn { get; set; }

        /// <summary>
        /// get or set FuncOrVendorCurrency
        /// </summary>
        [Display(Name = "PrintAmountsIn", ResourceType = typeof(APCommonResx))]
        public FuncOrVendorCurrency FunctionalOrVendorCurrency { get; set; }

        /// <summary>
        /// Get or set the FromDate
        /// </summary>
        [Display(Name = "FromDate", ResourceType = typeof(APCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Get or set AgeasofDate
        /// </summary>
        [Display(Name = "AgeAsOf", ResourceType = typeof(APCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime AgeasofDate { get; set; }

        /// <summary>
        /// get or set Period1
        /// </summary>
        public decimal Period1 { get; set; }

        /// <summary>
        /// get or set Period2
        /// </summary>
        public decimal Period2 { get; set; }

        /// <summary>
        /// get or set Period3
        /// </summary>
        public decimal Period3 { get; set; }

        /// <summary>
        /// get or set Period4
        /// </summary>
        public decimal Period4 { get; set; }

        /// <summary>
        /// Gets or sets the currency types.
        /// </summary>
        /// <value>The currency types.</value>
        public string CurrencyTypes { get; set; }

        /// <summary>
        /// Gets or sets the Fuctional Currency.
        /// </summary>
        /// <value>The currency types.</value>
        public string FuctionalCurrency { get; set; }

        /// <summary>
        /// Gets or set Include Invoice 
        /// </summary>
        [Display(Name = "Invoice1", ResourceType = typeof(APCommonResx))]
        public bool IncludeInvoice { get; set; }

        /// <summary>
        /// Gets or set IncludeDebitNote 
        /// </summary>
        [Display(Name = "DebitNote", ResourceType = typeof(APCommonResx))]
        public bool IncludeDebitNote { get; set; }

        /// <summary>
        /// Gets or set IncludeCreditNote 
        /// </summary>
        [Display(Name = "CreditNote", ResourceType = typeof(APCommonResx))]
        public bool IncludeCreditNote { get; set; }

        /// <summary>
        /// Gets or set IncludeInterest 
        /// </summary>
        [Display(Name = "Interest", ResourceType = typeof(APCommonResx))]
        public bool IncludeInterest { get; set; }

        /// <summary>
        /// Gets or set IncludePayment 
        /// </summary>
        [Display(Name = "Payment", ResourceType = typeof(APCommonResx))]
        public bool IncludePayment { get; set; }

        /// <summary>
        /// Gets or set IncludeFullyPaidTransactions 
        /// </summary>
        [Display(Name = "FullyPaidTransaction", ResourceType = typeof(APCommonResx))]
        public bool IncludeFullyPaidTransactions { get; set; }

        /// <summary>
        /// Gets or set IncludeAdjustment 
        /// </summary>
        [Display(Name = "Adjustment", ResourceType = typeof(APCommonResx))]
        public bool IncludeAdjustment { get; set; }

        /// <summary>
        /// Gets or set IncludePaymentsOnHold 
        /// </summary>
        [Display(Name = "VendorTransOnHold", ResourceType = typeof(APCommonResx))]
        public bool IncludePaymentsOnHold { get; set; }

        /// <summary>
        /// Gets or set IncludeZeroBalances 
        /// </summary>
        [Display(Name = "VendorsZeroBalance", ResourceType = typeof(APCommonResx))]
        public bool IncludeZeroBalances { get; set; }

        /// <summary>
        /// Gets or set IncludeContact 
        /// </summary>
        [Display(Name = "ContactPhoneCredit", ResourceType = typeof(APCommonResx))]
        public bool IncludeContact { get; set; }

        /// <summary>
        /// Gets or set IncludeContact 
        /// </summary>
        [Display(Name = "SpaceForComments", ResourceType = typeof(APCommonResx))]
        public bool SpaceForComments { get; set; }

        /// <summary>
        /// Gets or set IncludePrepayment 
        /// </summary>
        [Display(Name = "Prepayment", ResourceType = typeof(APCommonResx))]
        public bool IncludePrePayment { get; set; }

        /// <summary>
        /// Gets or set IncludeAppliedDetails 
        /// </summary>
        [Display(Name = "AppliedDetails", ResourceType = typeof(APCommonResx))]
        public bool IncludeAppliedDetails { get; set; }

        /// <summary>
        /// Gets or set ShowAgedRetainage 
        /// </summary>
        [Display(Name = "AgedRetainage", ResourceType = typeof(APCommonResx))]
        public bool AgedRetainage { get; set; }

        /// <summary>
        /// Gets or set CutoffDate 
        /// </summary>
        [Display(Name = "CutoffDate", ResourceType = typeof(APCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
          )]
        public DateTime? CutoffDate { get; set; }

        /// <summary>
        /// get or set multicurrencuy
        /// </summary>
        public bool Multicurrency { get; set; }

        /// <summary>
        /// Gets or set GroupTitle1 
        /// </summary>
        public bool GroupTitle1 { get; set; }

        /// <summary>
        /// Gets or set GroupTitle2
        /// </summary>
        public bool GroupTitle2 { get; set; }

        /// <summary>
        /// Gets or set GroupTitle1 
        /// </summary>
        public bool GroupTitle3 { get; set; }

        /// <summary>
        /// Gets or set GroupTitle4 
        /// </summary>
        public bool GroupTitle4 { get; set; }

        /// <summary>
        /// Gets or set GroupTotal1 
        /// </summary>
        public bool GroupTotal1 { get; set; }

        /// <summary>
        /// Gets or set GroupTotal2
        /// </summary>
        public bool GroupTotal2 { get; set; }

        /// <summary>
        /// Gets or set GroupTotal3
        /// </summary>
        public bool GroupTotal3 { get; set; }

        /// <summary>
        /// Gets or set GroupTotal4
        /// </summary>
        public bool GroupTotal4 { get; set; }

        /// <summary>
        /// Gets or set Select1
        /// </summary>
        public string Select1 { get; set; }

        /// <summary>
        /// Gets or set Select2
        /// </summary>
        public string Select2 { get; set; }

        /// <summary>
        /// Gets or set Select3
        /// </summary>
        public string Select3 { get; set; }

        /// <summary>
        /// Gets or set Select4
        /// </summary>
        public string Select4 { get; set; }

        /// <summary>
        /// Gets or sets Range1IndexValue 
        /// </summary>
        public int Range1IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range2IndexValue 
        /// </summary>
        public int Range2IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range3IndexValue 
        /// </summary>
        public int Range3IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range4IndexValue 
        /// </summary>
        public int Range4IndexValue { get; set; }

        /// <summary>
        /// Gets or sets FieldName1 
        /// </summary>
        public string FieldName1 { get; set; }

        /// <summary>
        /// Gets or sets FieldName2 
        /// </summary>
        public string FieldName2 { get; set; }

        /// <summary>
        /// Gets or sets FieldName3 
        /// </summary>
        public string FieldName3 { get; set; }

        /// <summary>
        /// Gets or sets FieldName4 
        /// </summary>
        public string FieldName4 { get; set; }

        /// <summary>
        /// Gets or set From1
        /// </summary>
        public string Range1From { get; set; }

        /// <summary>
        /// Gets or set From2
        /// </summary>
        public string Range2From { get; set; }

        /// <summary>
        /// Gets or set From3
        /// </summary>
        public string Range3From { get; set; }

        /// <summary>
        /// Gets or set From4
        /// </summary>
        public string Range4From { get; set; }

        /// <summary>
        /// Gets or set To1
        /// </summary>
        public string Range1To { get; set; }

        /// <summary>
        /// Gets or set To2
        /// </summary>
        public string Range2To { get; set; }

        /// <summary>
        /// Gets or set To3
        /// </summary>
        public string Range3To { get; set; }

        /// <summary>
        /// Gets or set To4
        /// </summary>
        public string Range4To { get; set; }

        /// <summary>
        /// get or set Sort1
        /// </summary>
        public string Sort1 { get; set; }

        /// <summary>
        /// get or set Sort2
        /// </summary>
        public string Sort2 { get; set; }

        /// <summary>
        /// get or set Sort3
        /// </summary>
        public string Sort3 { get; set; }

        /// <summary>
        /// get or set Sort4
        /// </summary>
        public string Sort4 { get; set; }

        /// <summary>
        /// get or set PhoneFormat
        /// </summary>
        public bool PhoneFormat { get; set; }

        /// <summary>
        /// get or set the Amount Type
        /// </summary>
        public string AmountType { get; set; }

        /// <summary>
        /// get or set the Report Title
        /// </summary>
        public string ReportTitle { get; set; }

        /// <summary>
        /// get or set Type1
        /// </summary>
        public string Type1 { get; set; }

        /// <summary>
        /// get or set Type2
        /// </summary>
        public string Type2 { get; set; }

        /// <summary>
        /// get or set Type3
        /// </summary>
        public string Type3 { get; set; }

        /// <summary>
        /// get or set Type4
        /// </summary>
        public string Type4 { get; set; }

        /// <summary>
        /// get or set Sort By Transaction Type
        /// </summary>
        [Display(Name = "SortTransByType", ResourceType = typeof(APCommonResx))]
        public bool SortByTransactionType { get; set; }

        /// <summary>
        /// get or set HasRetainage
        /// </summary>
        public bool HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets DueDateOrInvoiceDate 
        /// </summary>
        public DueDateOrInvoiceDate DueDateOrInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets ATBOrOverdueRecurringReport 
        /// </summary>
        public Enums.Process.ATBOrOverdueRecReport ATBOrOverdueRecReport { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex1 
        /// </summary>
        public int SortFieldIndex1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex2 
        /// </summary>
        public int SortFieldIndex2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex3 
        /// </summary>
        public int SortFieldIndex3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex4 
        /// </summary>
        public int SortFieldIndex4 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName1 
        /// </summary>
        public string SortFieldName1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName2 
        /// </summary>
        public string SortFieldName2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName3 
        /// </summary>
        public string SortFieldName3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName4 
        /// </summary>
        public string SortFieldName4 { get; set; }

        /// <summary>
        /// Gets or sets AgingSequenceNumber 
        /// </summary>
        public long AgingSequenceNumber { get; set; }

        /// <summary>
        /// Get or sets UseRetainage
        /// </summary>
        public bool UseRetainage { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc1
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc1 { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc2
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc2 { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc3
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc3 { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc4
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc4 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex1
        /// </summary>
        public string SortIndex1 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex2
        /// </summary>
        public string SortIndex2 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex3
        /// </summary>
        public string SortIndex3 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex4
        /// </summary>
        public string SortIndex4 { get; set; }

        #endregion
    }
}