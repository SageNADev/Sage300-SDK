﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Class for Letter and Label Report model.
    /// </summary>
    public partial class LetterAndLabelReport : ReportBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets Process Sequence Number
        /// </summary>
        public string ProcessSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets Company ZipCode
        /// </summary>
        public string ZipCode { get; set; }

        /// <summary>
        /// Gets or sets Company Address1
        /// </summary>
        public string Address1 { get; set; }

        /// <summary>
        /// Gets or sets Company Address2
        /// </summary>
        public string Address2 { get; set; }

        /// <summary>
        /// Gets or sets Company Address3
        /// </summary>
        public string Address3 { get; set; }

        /// <summary>
        /// Gets or sets Company Address4
        /// </summary>
        public string Address4 { get; set; }

        /// <summary>
        /// Gets or sets Company City
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Gets or sets Company Country
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets Session Date
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RunDate", ResourceType = typeof(APCommonResx))]
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets print mode
        /// </summary>
        public PrintTypeSwitch PrintMode { get; set; }

        /// <summary>
        /// Get or sets delivery method
        /// </summary>
        public ReportDeliveryMethod DeliveryMethod { get; set; }

        /// <summary>
        /// Get or set email message id
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MessageID", ResourceType = typeof(APCommonResx))]
        public string EmailMessageId { get; set; }

        /// <summary>
        /// Get or set file name
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Get or set selection criteria
        /// </summary>
        public string SelectionCriteria { get; set; }

        /// <summary>
        /// Get or set to email address
        /// </summary>
        public string EmailSendTo { get; set; }

        /// <summary>
        /// Get or set email subject
        /// </summary>
        public string EmailSubject { get; set; }

        /// <summary>
        /// Get or set email body message
        /// </summary>
        public string EmailMessageBody { get; set; }

        /// <summary>
        /// Gets or sets vendor from
        /// </summary>
        public string VendorFrom { get; set; }

        /// <summary>
        /// Gets or sets vendor to
        /// </summary>
        public string VendorTo { get; set; }

        /// <summary>
        /// Gets or Sets select vendor by 1 for user preference 
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc1 { get; set; }

        /// <summary>
        /// Gets or Sets select vendor by 2 for user preference 
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc2 { get; set; }

        /// <summary>
        /// Gets or Sets select vendor by 3 for user preference 
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc3 { get; set; }

        /// <summary>
        /// Gets or Sets select vendor by 4 for user preference 
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc4 { get; set; }

        /// <summary>
        /// Gets or Sets Sort Index 1 for user preference 
        /// </summary>
        public string SortFieldIndex1 { get; set; }

        /// <summary>
        /// Gets or Sets Sort Index 2 for user preference 
        /// </summary>
        public string SortFieldIndex2 { get; set; }

        /// <summary>
        /// Gets or Sets Sort Index 3 for user preference 
        /// </summary>
        public string SortFieldIndex3 { get; set; }

        /// <summary>
        /// Gets or Sets Sort Index 4 for user preference 
        /// </summary>
        public string SortFieldIndex4 { get; set; }

        /// <summary>
        /// Gets or sets Range1From  for user preference 
        /// </summary>
        public string Range1From { get; set; }

        /// <summary>
        /// Gets or sets Range1To for user preference 
        /// </summary>
        public string Range1To { get; set; }

        /// <summary>
        /// Gets or sets Range2From for user preference 
        /// </summary>
        public string Range2From { get; set; }

        /// <summary>
        /// Gets or sets Range2To for user preference 
        /// </summary>
        public string Range2To { get; set; }

        /// <summary>
        /// Gets or sets Range3From for user preference 
        /// </summary>
        public string Range3From { get; set; }

        /// <summary>
        /// Gets or sets Range3To for user preference 
        /// </summary>
        public string Range3To { get; set; }

        /// <summary>
        /// Gets or sets Range4From for user preference 
        /// </summary>
        public string Range4From { get; set; }

        /// <summary>
        /// Gets or sets Range4To for user preference 
        /// </summary>
        public string Range4To { get; set; }

        /// <summary>
        /// Gets or sets IncludeZeroBalances for user preference 
        /// </summary>
        [Display(Name = "IncludeVendorsWithZeroBalance", ResourceType = typeof(APCommonResx))]
        public bool IncludeZeroBalances { get; set; }


        #endregion
    }
}
