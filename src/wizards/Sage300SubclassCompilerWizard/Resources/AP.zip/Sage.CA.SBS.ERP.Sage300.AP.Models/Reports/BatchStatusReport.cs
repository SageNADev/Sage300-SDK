// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Partial class for BatchStatusReport
    /// </summary>
    public partial class BatchStatusReport : ReportBase
    {
        /// <summary>
        /// BatchStatusReport Constructor
        /// </summary>
        public BatchStatusReport()
        {
            BatchTypeSwitch = PostBatchTypeSwitch.Invoice;
            Frombatch = "1";
            Tobatch = "999999999";
            Entered = true;
            Imported = true;
            Generated = true;
            Recurring = true;
            External = true;
            Retainage = true;
            System = true;
            Open = true;
            Deleted = true;
            Readytopost = true;
            Posted = true;
            Postprog = true;
            Checkcreate = true;
        }

        /// <summary>
        /// Gets or sets BatchTypeSwitch
        /// </summary>
        public PostBatchTypeSwitch BatchTypeSwitch { get; set; }

        /// <summary>
        /// Gets or sets Frombatch
        /// </summary>
        public string Frombatch { get; set; }

        /// <summary>
        /// Gets or sets Tobatch
        /// </summary>
        public string Tobatch { get; set; }

        /// <summary>
        /// Gets or sets Batchtype
        /// </summary>
        public string Batchtype { get; set; }

        /// <summary>
        /// Gets or sets Batchstatus
        /// </summary>
        public string Batchstatus { get; set; }

        /// <summary>
        /// Gets or sets Sortby
        /// </summary>
        public string Sortby { get; set; }

        /// <summary>
        /// Gets or sets Query
        /// </summary>
        public string Query { get; set; }

        /// <summary>
        /// Gets or sets Fcurndec
        /// </summary>
        public decimal Fcurndec { get; set; }

        /// <summary>
        /// Gets or sets Fromdate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromDate", ResourceType = typeof(APCommonResx))]
        public DateTime? Fromdate { get; set; }

        /// <summary>
        /// Gets or sets Todate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        public DateTime? Todate { get; set; }

        /// <summary>
        /// Gets or sets Entered
        /// </summary>
        [Display(Name = "Entered", ResourceType = typeof(APCommonResx))]
        public bool Entered { get; set; }

        /// <summary>
        /// Gets or sets Imported
        /// </summary>
        [Display(Name = "Imported", ResourceType = typeof(APCommonResx))]
        public bool Imported { get; set; }

        /// <summary>
        /// Gets or sets Generated
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(APCommonResx))]
        public bool Generated { get; set; }

        /// <summary>
        /// Gets or sets Open
        /// </summary>
        [Display(Name = "Open", ResourceType = typeof(Resources.EnumerationsResx))]
        public bool Open { get; set; }

        /// <summary>
        /// Gets or sets Printed
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        public bool Printed { get; set; }

        /// <summary>
        /// Gets or sets Posted
        /// </summary>
        [Display(Name = "Posted", ResourceType = typeof(APCommonResx))]
        public bool Posted { get; set; }

        /// <summary>
        /// Gets or sets Deleted
        /// </summary>
        [Display(Name = "Deleted", ResourceType = typeof(APCommonResx))]
        public bool Deleted { get; set; }

        /// <summary>
        /// Gets or sets Postprog
        /// </summary>
        [Display(Name = "PostInProgress", ResourceType = typeof(APCommonResx))]
        public bool Postprog { get; set; }

        /// <summary>
        /// Gets or sets Partpost
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        public bool Partpost { get; set; }

        /// <summary>
        /// Gets or sets Readytopost
        /// </summary>
        [Display(Name = "ReadyToPost", ResourceType = typeof(APCommonResx))]
        public bool Readytopost { get; set; }

        /// <summary>
        /// Gets or sets Inclprndbtch
        /// </summary>
        public bool Inclprndbtch { get; set; }

        /// <summary>
        /// Gets or sets Recurring
        /// </summary>
        [Display(Name = "Recurring", ResourceType = typeof(APCommonResx))]
        public bool Recurring { get; set; }

        /// <summary>
        /// Gets or sets External
        /// </summary>
        [Display(Name = "External", ResourceType = typeof(APCommonResx))]
        public bool External { get; set; }

        /// <summary>
        /// Gets or sets Retainage
        /// </summary>
        [Display(Name = "Retainage", ResourceType = typeof(APCommonResx))]
        public bool Retainage { get; set; }

        /// <summary>
        /// Gets or sets Multcurn
        /// </summary>
        public bool Multcurn { get; set; }

        /// <summary>
        /// Gets or sets Swziactive
        /// </summary>
        public bool Swziactive { get; set; }

        /// <summary>
        /// Gets or sets Zimultcurn
        /// </summary>
        public string Zimultcurn { get; set; }

        /// <summary>
        /// Gets or sets Batchkind
        /// </summary>
        public string Batchkind { get; set; }

        /// <summary>
        /// Gets or sets System
        /// </summary>
        [Display(Name = "System", ResourceType = typeof(APCommonResx))]
        public bool System { get; set; }

        /// <summary>
        /// Gets or sets Checkcreate
        /// </summary>
        [Display(Name = "CheckCreationInProgress", ResourceType = typeof(Resources.EnumerationsResx))]
        public bool Checkcreate { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        public string Status { get; set; }

        /// <summary>
        /// Check Invoice button enabled
        /// </summary>
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public bool IsInvoiceEnabled { get; set; }

        /// <summary>
        /// Check Payment button enabled
        /// </summary>
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public bool IsPaymentEnabled { get; set; }

        /// <summary>
        /// Check Adjustment button enabled
        /// </summary>
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public bool IsAdjustmentEnabled { get; set; }

        /// <summary>
        /// Check Is RatainAge in AP-Options
        /// </summary>
        public bool IsRetainage { get; set; }
    }
}