﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// This class is used to generate the report for Aged Cash Requirement
    /// </summary>
    public partial class AgedCashRequirementReport : ReportBase
    {
        #region Model properties

        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>
        [Display(Name = "AgeBy", ResourceType = typeof(APCommonResx))]
        public DueDateOrInvoiceDate AgedByTypes { get; set; }

        /// <summary>
        /// Gets or sets FromYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets FromPeriod 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromPeriod { get; set; }

        /// <summary>
        /// get or set FiscalYear
        /// </summary>
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets Cutoffby 
        /// </summary>
        [Display(Name = "CutoffBy", ResourceType = typeof(APCommonResx))]
        public Cutoffby Cutoffby { get; set; }

        /// <summary>
        /// Get or sets PrintTransactionIn
        /// </summary>
        [Display(Name = "PrintTransactionsIn", ResourceType = typeof(APCommonResx))]
        public DetailOrSummaryReport PrintTransactionIn { get; set; }

        /// <summary>
        /// Get or sets the FromDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromDate", ResourceType = typeof(APCommonResx))]
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Get or set AgeasofDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AgeAsOf", ResourceType = typeof(APCommonResx))]
        public DateTime AgeasofDate { get; set; }

        /// <summary>
        /// get or set Period1
        /// </summary>
        [Display(Name = "Current", ResourceType = typeof(APCommonResx))]
        public decimal Period1 { get; set; }

        /// <summary>
        /// get or set Period2
        /// </summary>
        [Display(Name = "_1st", ResourceType = typeof(APCommonResx))]
        public decimal Period2 { get; set; }

        /// <summary>
        /// get or set Period3
        /// </summary>
        [Display(Name = "_2nd", ResourceType = typeof(APCommonResx))]
        public decimal Period3 { get; set; }

        /// <summary>
        /// get or set Period4
        /// </summary>
        [Display(Name = "_3rd", ResourceType = typeof(APCommonResx))]
        public decimal Period4 { get; set; }

        /// <summary>
        /// get or set Period4
        /// </summary>
        public decimal Over { get; set; }

        /// <summary>
        /// get or set Type1
        /// </summary>
        public string Type1 { get; set; }

        /// <summary>
        /// get or set Type2
        /// </summary>
        public string Type2 { get; set; }

        /// <summary>
        /// get or set Type3
        /// </summary>
        public string Type3 { get; set; }

        /// <summary>
        /// get or set Type4
        /// </summary>
        public string Type4 { get; set; }

        /// <summary>
        /// get or set PhoneFormat
        /// </summary>
        public bool PhoneFormat { get; set; }

        /// <summary>
        /// Gets or sets the currency types.
        /// </summary>
        /// <value>The currency types.</value>
        public string CurrencyTypes { get; set; }

        /// <summary>
        /// Gets or sets the Fuctional Currency.
        /// </summary>
        /// <value>The currency types.</value>
        public string FuctionalCurrency { get; set; }

        /// <summary>
        /// get or set the Amount Type
        /// </summary>
        public string AmountType { get; set; }

        /// <summary>
        /// Gets or sets Include Invoice 
        /// </summary>
        [Display(Name = "Invoice1", ResourceType = typeof(APCommonResx))]
        public bool IncludeInvoice { get; set; }

        /// <summary>
        /// Gets or sets IncludeDebitNote 
        /// </summary>
        [Display(Name = "DebitNote", ResourceType = typeof(APCommonResx))]
        public bool IncludeDebitNote { get; set; }

        /// <summary>
        /// Gets or sets IncludeCreditNote 
        /// </summary>
        [Display(Name = "CreditNote", ResourceType = typeof(APCommonResx))]
        public bool IncludeCreditNote { get; set; }

        /// <summary>
        /// Gets or sets IncludeInterest 
        /// </summary>
        [Display(Name = "Interest", ResourceType = typeof(APCommonResx))]
        public bool IncludeInterest { get; set; }

        /// <summary>
        /// Gets or sets IncludePayment 
        /// </summary>
        [Display(Name = "Payment", ResourceType = typeof(APCommonResx))]
        public bool IncludePayment { get; set; }

        /// <summary>
        /// Gets or sets IncludeFullyPaidTransactions 
        /// </summary>
        [Display(Name = "FullyPaidTransaction", ResourceType = typeof(APCommonResx))]
        public bool IncludeFullyPaidTransactions { get; set; }

        /// <summary>
        /// Gets or sets IncludeAdjustment 
        /// </summary>
        [Display(Name = "Adjustment", ResourceType = typeof(APCommonResx))]
        public bool IncludeAdjustment { get; set; }

        /// <summary>
        /// Gets or sets IncludePaymentsOnHold 
        /// </summary>
        [Display(Name = "VendorTransOnHold", ResourceType = typeof(APCommonResx))]
        public bool IncludePaymentsOnHold { get; set; }


        /// <summary>
        /// Gets or sets IncludeContact 
        /// </summary>
        [Display(Name = "ContactPhoneCredit", ResourceType = typeof(APCommonResx))]
        public bool IncludeContact { get; set; }

        /// <summary>
        /// Gets or sets IncludeContact 
        /// </summary>
        [Display(Name = "SpaceForComments", ResourceType = typeof(APCommonResx))]
        public bool SpaceForComments { get; set; }

        /// <summary>
        /// Gets or sets IncludePrepayment 
        /// </summary>
        [Display(Name = "Prepayment", ResourceType = typeof(APCommonResx))]
        public bool IncludePrePayment { get; set; }

        /// <summary>
        /// Gets or sets IncludeAppliedDetails 
        /// </summary>
        [Display(Name = "AppliedDetails", ResourceType = typeof(APCommonResx))]
        public bool IncludeAppliedDetails { get; set; }

        /// <summary>
        /// Gets or sets ShowAgedRetainage 
        /// </summary>
        [Display(Name = "AgedRetainage", ResourceType = typeof(APCommonResx))]
        public bool AgedRetainage { get; set; }

        /// <summary>
        /// Gets or sets CutoffDate 
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CutoffDate", ResourceType = typeof(APCommonResx))]
        public DateTime? CutoffDate { get; set; }

        /// <summary>
        /// Gets or sets TakeallAvailableDiscounts 
        /// </summary>
        [Display(Name = "AllAvailableDiscounts", ResourceType = typeof(APCommonReportResx))]
        public bool TakeallAvailableDiscounts { get; set; }


        /// <summary>
        /// Gets or sets GroupTitle1 
        /// </summary>
        public bool GroupTitle1 { get; set; }

        /// <summary>
        /// Gets or sets GroupTitle2
        /// </summary>
        public bool GroupTitle2 { get; set; }

        /// <summary>
        /// Gets or sets GroupTitle1 
        /// </summary>
        public bool GroupTitle3 { get; set; }

        /// <summary>
        /// Gets or sets GroupTitle4 
        /// </summary>
        public bool GroupTitle4 { get; set; }

        /// <summary>
        /// Gets or sets GroupTotal1 
        /// </summary>
        public bool GroupTotal1 { get; set; }

        /// <summary>
        /// Gets or sets GroupTotal2
        /// </summary>
        public bool GroupTotal2 { get; set; }

        /// <summary>
        /// Gets or sets GroupTotal3
        /// </summary>
        public bool GroupTotal3 { get; set; }

        /// <summary>
        /// Gets or sets GroupTotal4
        /// </summary>
        public bool GroupTotal4 { get; set; }

        /// <summary>
        /// get or set Sort By Transaction Type
        /// </summary>
        [Display(Name = "SortTransByType", ResourceType = typeof(APCommonResx))]
        public bool SortByTransactionType { get; set; }

        /// <summary>
        /// get or set HasRetainage
        /// </summary>
        public bool HasRetainage { get; set; }
        /// <summary>
        /// Gets or set Select1
        /// </summary>
        public string Select1 { get; set; }

        /// <summary>
        /// Gets or set Select2
        /// </summary>
        public string Select2 { get; set; }

        /// <summary>
        /// Gets or set Select3
        /// </summary>
        public string Select3 { get; set; }

        /// <summary>
        /// Gets or set Select4
        /// </summary>
        public string Select4 { get; set; }

        /// <summary>
        /// Gets or set From1
        /// </summary>
        public string From1 { get; set; }

        /// <summary>
        /// Gets or set From2
        /// </summary>
        public string From2 { get; set; }

        /// <summary>
        /// Gets or set From3
        /// </summary>
        public string From3 { get; set; }

        /// <summary>
        /// Gets or set From4
        /// </summary>
        public string From4 { get; set; }
        /// <summary>
        /// Gets or set To1
        /// </summary>
        public string To1 { get; set; }

        /// <summary>
        /// Gets or set To2
        /// </summary>
        public string To2 { get; set; }

        /// <summary>
        /// Gets or set To3
        /// </summary>
        public string To3 { get; set; }

        /// <summary>
        /// Gets or set To4
        /// </summary>
        public string To4 { get; set; }

        /// <summary>
        /// get or set multicurrencuy
        /// </summary>
        public bool Multicurrency { get; set; }

        /// <summary>
        /// get or set FuncOrVendorCurrency
        /// </summary>
        [Display(Name = "PrintAmountsIn", ResourceType = typeof(APCommonResx))]
        public FuncOrVendorCurrency FunctionalOrVendorCurrency { get; set; }

        /// <summary>
        /// get or set Sort1
        /// </summary>
        public string Sort1 { get; set; }

        /// <summary>
        /// get or set Sort2
        /// </summary>
        public string Sort2 { get; set; }

        /// <summary>
        /// get or set Sort3
        /// </summary>
        public string Sort3 { get; set; }

        /// <summary>
        /// get or set Sort4
        /// </summary>
        public string Sort4 { get; set; }

        /// <summary>
        /// Get or set CutoffPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CutoffPeriod { get; set; }

        /// <summary>
        /// get or set Cutoffyear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Cutoffyear { get; set; }

        /// <summary>
        /// get or set AgeSequence
        /// </summary>
        public string AgeSequence { get; set; }

        /// <summary>
        /// get or set Avaliable Discount
        /// </summary>
        public bool IncludeDiscount { get; set; }

        /// <summary>
        /// Gets or sets Range1IndexValue 
        /// </summary>
        public int Range1IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range2IndexValue 
        /// </summary>
        public int Range2IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range3IndexValue 
        /// </summary>
        public int Range3IndexValue { get; set; }

        /// <summary>
        /// Gets or sets Range4IndexValue 
        /// </summary>
        public int Range4IndexValue { get; set; }

        /// <summary>
        /// Gets or sets FieldName1 
        /// </summary>
        public string FieldName1 { get; set; }

        /// <summary>
        /// Gets or sets FieldName2 
        /// </summary>
        public string FieldName2 { get; set; }

        /// <summary>
        /// Gets or sets FieldName3 
        /// </summary>
        public string FieldName3 { get; set; }

        /// <summary>
        /// Gets or sets FieldName4 
        /// </summary>
        public string FieldName4 { get; set; }

        /// <summary>
        /// Gets or set From1
        /// </summary>
        public string Range1From { get; set; }

        /// <summary>
        /// Gets or set From2
        /// </summary>
        public string Range2From { get; set; }

        /// <summary>
        /// Gets or set From3
        /// </summary>
        public string Range3From { get; set; }

        /// <summary>
        /// Gets or set From4
        /// </summary>
        public string Range4From { get; set; }

        /// <summary>
        /// Gets or set To1
        /// </summary>
        public string Range1To { get; set; }

        /// <summary>
        /// Gets or set To2
        /// </summary>
        public string Range2To { get; set; }

        /// <summary>
        /// Gets or set To3
        /// </summary>
        public string Range3To { get; set; }

        /// <summary>
        /// Gets or set To4
        /// </summary>
        public string Range4To { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex1 
        /// </summary>
        public int SortFieldIndex1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex2 
        /// </summary>
        public int SortFieldIndex2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex3 
        /// </summary>
        public int SortFieldIndex3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldIndex4 
        /// </summary>
        public int SortFieldIndex4 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName1 
        /// </summary>
        public string SortFieldName1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName2 
        /// </summary>
        public string SortFieldName2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName3 
        /// </summary>
        public string SortFieldName3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldName4 
        /// </summary>
        public string SortFieldName4 { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc1
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc1 { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc2
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc2 { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc3
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc3 { get; set; }

        /// <summary>
        /// Gets or Sets optionalFieldDesc4
        /// </summary>
        public OptionalFieldDescription OptionalFieldDesc4 { get; set; }

        /// <summary>
        /// Get or sets for Aged Retainage
        /// </summary>
        public bool UseRetainage { get; set; }

        /// <summary>
        /// Gets or sets ATBOrOverdueRecurringReport 
        /// </summary>
        public Enums.Process.ATBOrOverdueRecReport ATBOrOverdueRecReport { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex1
        /// </summary>
        public string SortIndex1 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex2
        /// </summary>
        public string SortIndex2 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex3
        /// </summary>
        public string SortIndex3 { get; set; }

        /// <summary>
        /// Gets or Sets SortIndex4
        /// </summary>
        public string SortIndex4 { get; set; }

        #endregion
    }
}
