﻿/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Class for VendorReport
    /// </summary>
    public partial class VendorReport : ReportBase
    {
        #region Public properties

        /// <summary>
        /// Gets or Sets Address
        /// </summary>
        [Display(Name = "Address", ResourceType = typeof(APCommonResx))]
        public bool Address { get; set; }

        /// <summary>
        /// Gets or Sets Profile
        /// </summary>
        [Display(Name = "Profile", ResourceType = typeof(APCommonResx))]
        public bool Profile { get; set; }

        /// <summary>
        /// Gets or Sets Comments
        /// </summary>
        [Display(Name = "Comments", ResourceType = typeof(APCommonResx))]
        public bool Comments { get; set; }

        /// <summary>
        /// Gets or Sets FromCmtDt
        /// </summary>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromCmtDt { get; set; }

        /// <summary>
        /// Gets or Sets ToCmtDt
        /// </summary>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ToCmtDt { get; set; }

        /// <summary>
        /// Gets or Sets OptFlds
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        public bool OptFlds { get; set; }

        /// <summary>
        /// Gets or Sets PhoneFmt
        /// </summary>
        public bool PhoneFmt { get; set; }

        /// <summary>
        /// Gets or Sets Select1
        /// </summary>
        public OptionalFieldDescription Select1 { get; set; }

        /// <summary>
        /// Gets or Sets From1
        /// </summary>
        public string From1 { get; set; }

        /// <summary>
        /// Gets or Sets To1
        /// </summary>
        public string To1 { get; set; }

        /// <summary>
        /// Gets or Sets Select2
        /// </summary>
        public OptionalFieldDescription Select2 { get; set; }

        /// <summary>
        /// Gets or Sets From2
        /// </summary>
        public string From2 { get; set; }

        /// <summary>
        /// Gets or Sets To2
        /// </summary>
        public string To2 { get; set; }

        /// <summary>
        /// Gets or Sets Select3 
        /// </summary>
        public OptionalFieldDescription Select3 { get; set; }

        /// <summary>
        /// Gets or Sets From3
        /// </summary>
        public string From3 { get; set; }

        /// <summary>
        /// Gets or Sets To3
        /// </summary>
        public string To3 { get; set; }

        /// <summary>
        /// Gets or Sets Select4
        /// </summary>
        public OptionalFieldDescription Select4 { get; set; }

        /// <summary>
        /// Gets or Sets From4
        /// </summary>
        public string From4 { get; set; }

        /// <summary>
        /// Gets or Sets To4
        /// </summary>
        public string To4 { get; set; }

        /// <summary>
        /// Gets or Sets SortBy
        /// </summary>
        public string SortBy { get; set; }

        /// <summary>
        /// Gets or Sets Sort1
        /// </summary>
        public OptionalFieldDescription Sort1 { get; set; }

        /// <summary>
        /// Gets or Sets Sort2
        /// </summary>
        public OptionalFieldDescription Sort2 { get; set; }

        /// <summary>
        /// Gets or Sets Sort3
        /// </summary>
        public OptionalFieldDescription Sort3 { get; set; }

        /// <summary>
        /// Gets or Sets Sort4
        /// </summary>
        public OptionalFieldDescription Sort4 { get; set; }

        /// <summary>
        /// Gets or Sets Type1
        /// </summary>
        public string Type1 { get; set; }

        /// <summary>
        /// Gets or Sets Type2
        /// </summary>
        public string Type2 { get; set; }

        /// <summary>
        /// Gets or Sets Type3
        /// </summary>
        public string Type3 { get; set; }

        /// <summary>
        /// Gets or Sets Type4
        /// </summary>
        public string Type4 { get; set; }

        /// <summary>
        /// Gets or Sets SelSeq
        /// </summary>
        public string SelSeq { get; set; }

        /// <summary>
        /// Gets or Sets Recurring
        /// </summary>
        [Display(Name = "RecurringPayables", ResourceType = typeof(VendorReportResx))]
        public bool Recurring { get; set; }

        /// <summary>
        /// Gets or Sets MaskTaxNum
        /// </summary>
        [Display(Name = "ShowTaxNumbers", ResourceType = typeof(VendorReportResx))]
        public bool MaskTaxNum { get; set; }

        /// <summary>
        /// Gets or Sets CanModifyTaxNumber
        /// </summary>
        public bool CanModifyTaxNumber { get; set; }

        /// <summary>
        /// Gets or Sets McurCust
        /// </summary>
        public string McurCust { get; set; }

        /// <summary>
        /// Gets or Sets FcurnDec
        /// </summary>
        public string FcurnDec { get; set; }

        /// <summary>
        /// Gets or Sets MultCurn
        /// </summary>
        public string MultCurn { get; set; }

        /// <summary>
        /// Gets or Sets Counts
        /// </summary>
        public string Counts { get; set; }

        /// <summary>
        /// Gets or Sets CountCst
        /// </summary>
        public string CountCst { get; set; }

        /// <summary>
        /// Gets or Sets FromYear
        /// </summary>
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or Sets ToYear
        /// </summary>
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or Sets FromPerd
        /// </summary>
        public string FromPerd { get; set; }

        /// <summary>
        /// Gets or Sets ToPerd
        /// </summary>
        public string ToPerd { get; set; }

        /// <summary>
        /// Gets or Sets Type
        /// </summary>
        [Display(Name = "ReportType", ResourceType = typeof(APCommonResx))]
        public ReportType RptType { get; set; }

        /// <summary>
        /// Gets or Sets Amounts In 
        /// </summary>
        [Display(Name = "PrintAmountsIn", ResourceType = typeof(APCommonResx))]
        public PrintAmountsIn AmountsIn { get; set; }

        /// <summary>
        /// Gets or Sets ActivateMulticurrency
        /// </summary>
        public bool ActivateMulticurrency { get; set; }

        /// <summary>
        /// Gets or Sets OptFldsVisible
        /// </summary>
        public bool OptFldsVisible { get; set; }

        /// <summary>
        /// Gets or Sets NumberOfDoc
        /// </summary>
        [Display(Name = "NumberofDocuments", ResourceType = typeof(VendorReportResx))]
        public bool NumberOfDoc { get; set; }

        /// <summary>
        /// Gets or sets MaxFromPerd
        /// </summary>
        public int MaxFromPerd { get; set; }

        /// <summary>
        /// Gets or sets MaxToPerd
        /// </summary>
        public int MaxToPerd { get; set; }

        /// <summary>
        /// Gets or sets MinFromPerd
        /// </summary>
        public int MinFromPerd { get; set; }

        /// <summary>
        /// Gets or sets MinToPerd
        /// </summary>
        public int MinToPerd { get; set; }

        /// <summary>
        /// Gets or Sets Select1Val
        /// </summary>
        public string Select1Val { get; set; }

        /// <summary>
        /// Gets or Sets Select2Val
        /// </summary>
        public string Select2Val { get; set; }

        /// <summary>
        /// Gets or Sets Select3Val
        /// </summary>
        public string Select3Val { get; set; }

        /// <summary>
        /// Gets or Sets Select4Val
        /// </summary>
        public string Select4Val { get; set; }

        /// <summary>
        /// Gets or Sets 
        /// </summary>
        public string Sort1Val { get; set; }

        /// <summary>
        /// Gets or Sets Sort2Val
        /// </summary>
        public string Sort2Val { get; set; }

        /// <summary>
        /// Gets or Sets Sort3Val
        /// </summary>
        public string Sort3Val { get; set; }

        /// <summary>
        /// Gets or Sets Sort4Val
        /// </summary>
        public string Sort4Val { get; set; }

        #endregion
    }
}
