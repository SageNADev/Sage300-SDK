﻿/* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.ElectronicFiling
{
    public class CategoryRec
    {
        /// <summary>
        /// Gets or sets Index property
        /// </summary>
        public int Index { get; set; }

        /// <summary>
        /// Gets or sets Category property
        /// </summary>
        public Category Category { get; set; }

        /// <summary>
        /// Gets or sets MinAmount property
        /// </summary>
        public double MinAmount { get; set; }

        /// <summary>
        /// Gets or sets Reached property
        /// </summary>
        public bool Reached { get; set; }

        /// <summary>
        /// Parametrized constructor to initialize CategoryRec
        /// </summary>
        public CategoryRec()
        {
            MinAmount = -1;
            Reached = false;
        }
    }
}
