﻿// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. 
// When a web service is required for this repository, they will need to be moved

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using System.Collections.Generic;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.ElectronicFiling
{
    /// <summary>
    /// File Layout class
    /// </summary>
    public static class FileLayout
    {
        ///// <summary>
        ///// The constant for Rents Postion
        ///// </summary>
        //public const int RentsPosition = 1;

        ///// <summary>
        ///// The constant for Royalties Position
        ///// </summary>
        //public const int RoyaltiesPosition = 2;

        ///// <summary>
        ///// The constant for Other Income Position
        ///// </summary>
        //public const int OtherIncomePosition = 3;

        ///// <summary>
        ///// The constant for Fed IncomeTax Withheld Position
        ///// </summary>
        //public const int FedIncomeTaxWithheldPosition = 4;

        ///// <summary>
        ///// The constant for Fishing Boat Proceeds Position
        ///// </summary>
        //public const int FishingBoatProceedsPosition = 5;

        ///// <summary>
        ///// The constant for Medical And Health Care Position
        ///// </summary>
        //public const int MedicalAndHealthCarePosition = 6;

        ///// <summary>
        ///// The constant for Non Employee Compensation Position
        ///// </summary>
        //public const int NonEmployeeCompensationPosition = 7;

        ///// <summary>
        ///// The constant for Substitute Payments Position
        ///// </summary>
        //public const int SubstitutePaymentsPosition = 8;

        ///// <summary>
        ///// The constant for Foreign Tax Paid Position
        ///// </summary>
        //public const int ForeignTaxPaidPosition = 9;

        ///// <summary>
        ///// The constant for Crop Insurance Position
        ///// </summary>
        //public const int CropInsurancePosition = 10;

        ///// <summary>
        ///// The constant for Golden Parachute Position
        ///// </summary>
        //public const int GoldenParachutePosition = 11;

        ///// <summary>
        ///// The constant for Attorney Fees Position
        ///// </summary>
        //public const int AttorneyFeesPosition = 12;

        ///// <summary>
        ///// The constant for Section409A Deferrals Position
        ///// </summary>
        //public const int Section409ADeferralsPosition = 13;

        ///// <summary>
        ///// The constant for Section409A Income Position
        ///// </summary>
        //public const int Section409AIncomePosition = 14;

        ///// <summary>
        ///// The constant for Direct Sales Position
        ///// </summary>
        //public const int DirectSalesPosition = 15;

        /// <summary>
        /// The constant for Amount Buckets Number
        /// </summary>
        public const int AmountBucketsNumber = 16;

        /// <summary>
        /// The constant for File Name 1099
        /// </summary>
        public const string FileName1099 = "IRSTAX";

        /// <summary>
        /// The constant for Csv Detail
        /// </summary>
        public const int CsvMiscDetail = 0;

        /// <summary>
        /// The constant for Csv Summary
        /// </summary>
        public const int CsvMiscSummary = 1;

        /// <summary>
        /// The constant for Csv Detail
        /// </summary>
        public const int CsvNECDetail = 2;

        /// <summary>
        /// The constant for Csv Summary
        /// </summary>
        public const int CsvNECSmmary = 3;

        /// <summary>
        /// The ForeignPlace class
        /// Following field may be used in place of Location, State, PostalCode fields
        /// in "T", "A" and "B" records
        /// </summary>
        public class ForeignPlace
        {
            /// <summary>
            /// Gets the Foreign Location property object
            /// </summary>
            public PropertyValue ForeignLocation { get; private set; }

            /// <summary>
            /// Default constructor to initialize
            /// </summary>
            public ForeignPlace()
            {
                ForeignLocation = new PropertyValue { Length = 51 };
            }
        }

        /// <summary>
        /// The Record class
        /// </summary>
        public abstract class Record { }

        /// <summary>
        /// The RecordT class
        /// </summary>
        public class RecordT : Record
        {
            public PropertyValue RecordType { get; private set; }
            public PropertyValue PaymentYear { get; private set; }
            public PropertyValue PriorYearFlag { get; private set; }
            public PropertyValue TransmitterTin { get; private set; }
            public PropertyValue ControlCode { get; private set; }
            public PropertyValue BlankFirst { get; private set; }
            public PropertyValue TestFileFlag { get; private set; }
            public PropertyValue ForeignEntityFlag { get; private set; }
            public PropertyValue TransmitterName1 { get; private set; }
            public PropertyValue TransmitterName2 { get; private set; }
            public PropertyValue CompanyName1 { get; private set; }
            public PropertyValue CompanyName2 { get; private set; }
            public PropertyValue MailingAddress { get; private set; }
            public PropertyValue MailingLocation { get; private set; }
            public PropertyValue MailingState { get; private set; }
            public PropertyValue MailingPostCode { get; private set; }
            public PropertyValue BlankSecond { get; private set; }
            public PropertyValue PayeeCount { get; private set; }
            public PropertyValue ContactName { get; private set; }
            public PropertyValue ContactPhoneExtension { get; private set; }
            public PropertyValue ContactEmailAddress { get; private set; }
            public PropertyValue BlankThird { get; private set; }
            public PropertyValue SequenceNumber { get; private set; }
            public PropertyValue BlankFourth { get; private set; }
            public PropertyValue VendorFlag { get; private set; }
            public PropertyValue VendorName { get; private set; }
            public PropertyValue VendorAddress { get; private set; }
            public PropertyValue VendorCity { get; private set; }
            public PropertyValue VendorState { get; private set; }
            public PropertyValue VendorZipCode { get; private set; }
            public PropertyValue VendorContactName { get; private set; }
            public PropertyValue VendorContactPhone { get; private set; }
            public PropertyValue BlankSixth { get; private set; }
            public PropertyValue VendorForeignFlag { get; private set; }
            public PropertyValue BlankFifth { get; private set; }
            public PropertyValue EndLineCharacters { get; private set; }

            /// <summary>
            /// A default constructor
            /// </summary>
            public RecordT()
            {
                RecordType = new PropertyValue { Length = 1 };
                PaymentYear = new PropertyValue { Length = 4 };
                PriorYearFlag = new PropertyValue { Length = 1 };
                TransmitterTin = new PropertyValue { Length = 9 };
                ControlCode = new PropertyValue { Length = 5 };
                BlankFirst = new PropertyValue { Length = 7 };
                TestFileFlag = new PropertyValue { Length = 1 };
                ForeignEntityFlag = new PropertyValue { Length = 1 };
                TransmitterName1 = new PropertyValue { Length = 40 };
                TransmitterName2 = new PropertyValue { Length = 40 };
                CompanyName1 = new PropertyValue { Length = 40 };
                CompanyName2 = new PropertyValue { Length = 40 };
                MailingAddress = new PropertyValue { Length = 40 };
                MailingLocation = new PropertyValue { Length = 40 };
                MailingState = new PropertyValue { Length = 2 };
                MailingPostCode = new PropertyValue { Length = 9 };
                BlankSecond = new PropertyValue { Length = 15 };
                PayeeCount = new PropertyValue { Length = 8 };
                ContactName = new PropertyValue { Length = 40 };
                ContactPhoneExtension = new PropertyValue { Length = 15 };
                ContactEmailAddress = new PropertyValue { Length = 50 };
                BlankThird = new PropertyValue { Length = 91 };
                SequenceNumber = new PropertyValue { Length = 8 };
                BlankFourth = new PropertyValue { Length = 10 };
                VendorFlag = new PropertyValue { Length = 1 };
                VendorName = new PropertyValue { Length = 40 };
                VendorAddress = new PropertyValue { Length = 40 };
                VendorCity = new PropertyValue { Length = 40 };
                VendorState = new PropertyValue { Length = 2 };
                VendorZipCode = new PropertyValue { Length = 9 };
                VendorContactName = new PropertyValue { Length = 40 };
                VendorContactPhone = new PropertyValue { Length = 15 };
                BlankSixth = new PropertyValue { Length = 35 };
                VendorForeignFlag = new PropertyValue { Length = 1 };
                BlankFifth = new PropertyValue { Length = 8 };
                EndLineCharacters = new PropertyValue { Length = 2 };
            }
        }

        /// <summary>
        /// The RecordA class
        /// </summary>
        public class RecordA : Record
        {
            public PropertyValue RecordType { get; private set; }
            public PropertyValue PaymentYear { get; private set; }
            public PropertyValue FederalStateFilingFlag { get; private set; }
            public PropertyValue BlankFirst { get; private set; }
            public PropertyValue PayerTin { get; private set; }
            public PropertyValue NameControl { get; private set; }
            public PropertyValue FinalFilingFlag { get; private set; }
            public PropertyValue ReturnTypeCode { get; private set; }
            public PropertyValue AmountIdCodes { get; private set; }
            public PropertyValue BlankSecond { get; private set; }
            public PropertyValue ForeignEntityFlag { get; private set; }
            public PropertyValue PayerName1 { get; private set; }
            public PropertyValue PayerName2 { get; private set; }
            public PropertyValue TransferAgentFlag { get; private set; }
            public PropertyValue ShippingAddress { get; private set; }
            public PropertyValue ShippingLocation { get; private set; }
            public PropertyValue ShippingState { get; private set; }
            public PropertyValue ShippingPostalCode { get; private set; }
            public PropertyValue PayerPhoneExtension { get; private set; }
            public PropertyValue BlankFourth { get; private set; }
            public PropertyValue SequenceNumber { get; private set; }
            public PropertyValue BlankFifth { get; private set; }
            public PropertyValue EndLineCharacters { get; private set; }

            /// <summary>
            /// A default constructor
            /// </summary>
            public RecordA()
            {
                RecordType = new PropertyValue { Length = 1 };
                PaymentYear = new PropertyValue { Length = 4 };
                FederalStateFilingFlag = new PropertyValue { Length = 1 };
                BlankFirst = new PropertyValue { Length = 5 };
                PayerTin = new PropertyValue { Length = 9 };
                NameControl = new PropertyValue { Length = 4 };
                FinalFilingFlag = new PropertyValue { Length = 1 };
                ReturnTypeCode = new PropertyValue { Length = 2 };
                AmountIdCodes = new PropertyValue { Length = 16 };
                BlankSecond = new PropertyValue { Length = 8 };
                ForeignEntityFlag = new PropertyValue { Length = 1 };
                PayerName1 = new PropertyValue { Length = 40 };
                PayerName2 = new PropertyValue { Length = 40 };
                TransferAgentFlag = new PropertyValue { Length = 1 };
                ShippingAddress = new PropertyValue { Length = 40 };
                ShippingLocation = new PropertyValue { Length = 40 };
                ShippingState = new PropertyValue { Length = 2 };
                ShippingPostalCode = new PropertyValue { Length = 9 };
                PayerPhoneExtension = new PropertyValue { Length = 15 };
                BlankFourth = new PropertyValue { Length = 260 };
                SequenceNumber = new PropertyValue { Length = 8 };
                BlankFifth = new PropertyValue { Length = 241 };
                EndLineCharacters = new PropertyValue { Length = 2 };
            }
        }

        /// <summary>
        /// The RecordB class
        /// </summary>
        public class RecordB_Common : Record
        {
            public PropertyValue RecordType { get; private set; }
            public PropertyValue PaymentYear { get; private set; }
            public PropertyValue CorrectionCode { get; private set; }
            public PropertyValue NameControl { get; private set; }
            public PropertyValue TypeofPayeeTin { get; private set; }
            public PropertyValue PayeeTin { get; private set; }
            public PropertyValue PayeeAccountNumber { get; private set; }
            public PropertyValue PayerOfficeCode { get; private set; }
            public PropertyValue BlankFirst { get; private set; }
            public PropertyValue[] PaymentAmount { get; private set; }
            public PropertyValue ForeignCountryFlag { get; private set; }
            public PropertyValue PayeeName1 { get; private set; }
            public PropertyValue PayeeName2 { get; private set; }
            public PropertyValue BlankSecond { get; private set; }
            public PropertyValue PayeeAddress { get; private set; }
            public PropertyValue BlankThird { get; private set; }
            public PropertyValue PayeeLocation { get; private set; }
            public PropertyValue PayeeState { get; private set; }
            public PropertyValue PayeePostalCode { get; private set; }
            public PropertyValue BlankFourth { get; private set; }
            public PropertyValue SequenceNumber { get; private set; }
            public PropertyValue BlankFifth { get; private set; }

            /// <summary>
            /// A default constructor
            /// </summary>
            public RecordB_Common()
            {
                RecordType = new PropertyValue { Length = 1 };
                PaymentYear = new PropertyValue { Length = 4 };
                CorrectionCode = new PropertyValue { Length = 1 };
                NameControl = new PropertyValue { Length = 4 };
                TypeofPayeeTin = new PropertyValue { Length = 1 };
                PayeeTin = new PropertyValue { Length = 9 };
                PayeeAccountNumber = new PropertyValue { Length = 20 };
                PayerOfficeCode = new PropertyValue { Length = 4 };
                BlankFirst = new PropertyValue { Length = 10 };
                PaymentAmount = new PropertyValue[AmountBucketsNumber];
                ForeignCountryFlag = new PropertyValue { Length = 1 };
                PayeeName1 = new PropertyValue { Length = 40 };
                PayeeName2 = new PropertyValue { Length = 40 };
                BlankSecond = new PropertyValue { Length = 40 };
                PayeeAddress = new PropertyValue { Length = 40 };
                BlankThird = new PropertyValue { Length = 40 };
                PayeeLocation = new PropertyValue { Length = 40 };
                PayeeState = new PropertyValue { Length = 2 };
                PayeePostalCode = new PropertyValue { Length = 9 };
                BlankFourth = new PropertyValue { Length = 1 };
                SequenceNumber = new PropertyValue { Length = 8 };
                BlankFifth = new PropertyValue { Length = 36 };
            }
        }

        /// <summary>
        /// The RecordB class
        /// </summary>
        public class RecordB_MISC : RecordB_Common
        {
            public PropertyValue SecondTinNoteFlag { get; private set; }
            public PropertyValue BlankMisc1 { get; private set; }
            public PropertyValue DirectSalesFlag { get; private set; }
            public PropertyValue BlankMisc2 { get; private set; }
            public PropertyValue StateLocalData { get; private set; }
            public PropertyValue StateTaxWithHeld { get; private set; }
            public PropertyValue LocalTaxWithHeld { get; private set; }
            public PropertyValue CombFedStateCode { get; private set; }
            public PropertyValue EndLineCharacters { get; private set; }

            /// <summary>
            /// A default constructor
            /// </summary>
            public RecordB_MISC() : base()
            {
                SecondTinNoteFlag = new PropertyValue { Length = 1 };
                BlankMisc1 = new PropertyValue { Length = 2 };
                DirectSalesFlag = new PropertyValue { Length = 1 };
                BlankMisc2 = new PropertyValue { Length = 115 };
                StateLocalData = new PropertyValue { Length = 60 };
                StateTaxWithHeld = new PropertyValue { Length = 12 };
                LocalTaxWithHeld = new PropertyValue { Length = 12 };
                CombFedStateCode = new PropertyValue { Length = 2 };
                EndLineCharacters = new PropertyValue { Length = 2 };
            }
        }

        /// <summary>
        /// The RecordB class
        /// </summary>
        public class RecordB_NEC : RecordB_Common
        {
            public PropertyValue SecondTinNoteFlag { get; private set; }
            public PropertyValue BlankNEC1 { get; private set; }
            public PropertyValue DirectSalesFlag { get; private set; }
            public PropertyValue BlankNEC2 { get; private set; }

            /// <summary>
            /// A default constructor
            /// </summary>
            public RecordB_NEC() : base()
            {
                SecondTinNoteFlag = new PropertyValue { Length = 1 };
                BlankNEC1 = new PropertyValue { Length = 2 };
                DirectSalesFlag = new PropertyValue { Length = 1 };
                BlankNEC2 = new PropertyValue { Length = 203 };
            }
        }
        
        /// <summary>
        /// The RecordC class
        /// </summary>
        public class RecordC : Record
        {
            public PropertyValue RecordType { get; private set; }
            public PropertyValue PayeeCount { get; private set; }
            public PropertyValue BlankFirst { get; private set; }
            public PropertyValue[] ControlTotal { get; private set; }
            public PropertyValue BlankSecond { get; private set; }
            public PropertyValue SequenceNumber { get; private set; }
            public PropertyValue BlankThird { get; private set; }
            public PropertyValue EndLineCharacters { get; private set; }

            /// <summary>
            /// A default constructor
            /// </summary>
            public RecordC()
            {
                RecordType = new PropertyValue { Length = 1 };
                PayeeCount = new PropertyValue { Length = 8 };
                BlankFirst = new PropertyValue { Length = 6 };

                ControlTotal = new PropertyValue[AmountBucketsNumber];
                BlankSecond = new PropertyValue { Length = 196 };
                SequenceNumber = new PropertyValue { Length = 8 };
                BlankThird = new PropertyValue { Length = 241 };
                EndLineCharacters = new PropertyValue { Length = 2 };
            }
        }

        /// <summary>
        /// The RecordF class
        /// Record K [combined federal/state info] currently not used/supported
        /// </summary>
        public class RecordF : Record
        {
            public PropertyValue RecordType { get; private set; }
            public PropertyValue RecordACount { get; private set; }
            public PropertyValue ZeroFirst { get; private set; }
            public PropertyValue BlankFirst { get; private set; }
            public PropertyValue TotalNumberOfPayees { get; private set; }
            public PropertyValue BlankSecond { get; private set; }
            public PropertyValue SequenceNumber { get; private set; }
            public PropertyValue BlankThird { get; private set; }
            public PropertyValue EndLineCharacters { get; private set; }

            /// <summary>
            /// A default constructor
            /// </summary>
            public RecordF()
            {
                RecordType = new PropertyValue { Length = 1 };
                RecordACount = new PropertyValue { Length = 8 };
                ZeroFirst = new PropertyValue { Length = 21 };
                BlankFirst = new PropertyValue { Length = 19 };
                TotalNumberOfPayees = new PropertyValue { Length = 8 };
                BlankSecond = new PropertyValue { Length = 442 };
                SequenceNumber = new PropertyValue { Length = 8 };
                BlankThird = new PropertyValue { Length = 241 };
                EndLineCharacters = new PropertyValue { Length = 2 };
            }
        }

        /// <summary>
        /// The RecordCsv class
        /// </summary>
        public class RecordCsv
        {
            public const int TypeofPayeeTin = 1;
            public const int PayeeTin = 9;
            public const int PayeeAccountNumber = 20;
            public double[] PaymentAmount = new double[AmountBucketsNumber];
            public const int ForeignCountryFlag = 1;
            public const int PayeeName = 80;
            public const int PayeeAddress = 40;
            public const int PayeeLocation = 40;
            public const int PayeeState = 2;
            public const int PayeePostalCode = 9;
            public const int DirectSalesFlag = 1;

            /// <summary>
            /// A default constructor
            /// </summary>
            /// <param name="paymentAmount">An array of PaymentAmount</param>
            public RecordCsv(double[] paymentAmount)
            {
                PaymentAmount = paymentAmount;
            }
        }

        /// <summary>
        /// The PropertyValue class
        /// </summary>
        public class PropertyValue
        {
            /// <summary>
            /// Gets or sets property Value
            /// </summary>
            public string Value { get; set; }

            /// <summary>
            /// Gets or sets property Length
            /// </summary>
            public int Length { get; set; }
        }

        //  search the arrays "gStateCodes", "gStateNames", etc. above for a match
        public static string GetStateCode(string state)
        {
            string[] stateCodes = {"AL", "AK", "AS", "AZ", "AR", "CA", "CO", "CT", "DE", "DC",
                        "FM", "FL", "GA", "GU", "HI", "ID", "IL", "IA", "IN", "KS", "KY",
                        "LA", "ME", "MH", "MD", "MA", "MI", "MN", "MS", "MO", "MT",
                        "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "MP", "OH",
                        "OK", "OR", "PA", "PR", "RI", "SC", "SD", "TN", "TX",
                        "UT", "VT", "VA", "VI", "WA", "WV", "WI", "WY", "AE", "AP",
                        "AA"};

            string[] stateNames = {"Alabama", "Alaska", "American Samoa", "Arizona", "Arkansas",
                        "California", "Colorado", "Connecticut", "Delaware",
                        "District Of Columbia", "Federated States of Micronesia", "Florida", "Georgia", "Guam", "Hawaii",
                        "Idaho", "Illinois", "Iowa", "Indiana",
                        "Kansas", "Kentucky", "Louisiana", "Maine", "Marshall Islands",
                        "Maryland", "Massachusetts", "Michigan", "Minnesota",
                        "Mississippi", "Missouri", "Montana", "Nebraska",
                        "Nevada", "New Hampshire", "New Jersey", "New Mexico",
                        "New York", "North Carolina", "North Dakota", "No. Mariana Islands", "Ohio",
                        "Oklahoma", "Oregon", "Pennsylvania", "Puerto Rico",
                        "Rhode Island", "South Carolina", "South Dakota", "Tennessee",
                        "Texas", "Utah", "Vermont", "(U.S.) Virgin Islands", "Virginia",
                        "Washington", "West Virginia", "Wisconsin", "Wyoming",
                        "Armed Forces Europe", "Armed Forces Pacific", "Armed Forces Americas"};

            string[] stateNameVars = {"Alabama", "Alaska", "American Samoa", "Arizona", "Arkansas",
                           "California", "Colorado", "Connecticut", "Delaware",
                           "Dist. Of Columbia", "Federated States of Micronesia", "Florida", "Georgia", "Guam", "Hawaii",
                           "Idaho", "Illinois", "Iowa", "Indiana",
                           "Kansas", "Kentucky", "Louisiana", "Maine", "Marshall Is.",
                           "Maryland", "Massachusetts", "Michigan", "Minnesota",
                           "Mississippi", "Missouri", "Montana", "Nebraska",
                           "Nevada", "New Hampshire", "New Jersey", "New Mexico",
                           "New York", "N. Carolina", "N. Dakota", "No. Mariana Is.", "Ohio",
                           "Oklahoma", "Oregon", "Pennsylvania", "Puerto Rico",
                           "Rhode Is.", "S. Carolina", "S. Dakota", "Tennessee",
                           "Texas", "Utah", "Vermont", "Virgin Islands", "Virginia",
                           "Washington", "W. Virginia", "Wisconsin", "Wyoming",
                           "Armed Forces Eur.", "Armed Forces Pac.", "Armed Forces Amer."};

            string[] stateNameAbbrivations = {"Ala.", "Alaska", "American Samoa", "Ariz.", "Ark.",
                            "Calif.", "Col.", "Conn.", "Del.",
                            "Dist. Of Col.", "Federated States of Micronesia", "Flor.", "Geo.", "Guam", "Hawaii",
                            "Ida.", "Ill.", "Iowa", "Ind.",
                            "Kan.", "Kent.", "Louisiana", "Maine", "Marshall Is.",
                            "Mary.", "Mass.", "Mich.", "Minn.",
                            "Miss.", "Missouri", "Mont.", "Neb.",
                            "Nev.", "New Hamp.", "New Jersey", "New Mex.",
                            "New York", "N. Car.", "N. Dak.", "No. Mariana Is.", "Ohio",
                            "Okla.", "Ore.", "Penn.", "Puerto Rico",
                            "Rhode Is.", "S. Car.", "S. Dak.", "Tenn.",
                            "Tex.", "Utah", "Vert.", "Virgin Is.", "Virg.",
                            "Wash.", "W. Virg.", "Wisc.", "Wyo.",
                            "A. F. Europe", "A. F. Pacific", "A. F. Americas"};

            // This is commented even in VB and hence written and commented here too.
            //string[] buzzWords = {"Mr", "Ms", "Miss", "Mrs", "Dr", "Sr", "Jr", "M", "Mme", "Mlle",
            //                  "Monsieur", "Madame", "Senor", "Senora", "Sra", "Senorita", "the","a", "of"};

            var returnValue = -1;
            var input = state.Trim();
            if (input.Length == 0)
            {
                return string.Empty;
            }
            if (input.Length == 2)
            {
                //  a proper code?
                for (var index = 0; index < stateCodes.Length; index++)
                {
                    if (input != stateCodes[index]) continue;
                    returnValue = index;
                    break;
                }
            }
            else
            {
                //  try each type in turn
                for (var index = 0; index < stateNames.Length; index++)
                {
                    if (input != stateNames[index]) continue;
                    returnValue = index;
                    break;
                }
                if (returnValue < 0)
                {
                    for (var index = 0; index < stateNameVars.Length; index++)
                    {
                        if (input != stateNameVars[index]) continue;
                        returnValue = index;
                        break;
                    }
                }

                if (returnValue >= 0) return (returnValue >= 0) ? stateCodes[returnValue] : "";

                for (var index = 0; index < stateNameAbbrivations.Length; index++)
                {
                    if (input != stateNameAbbrivations[index]) continue;
                    returnValue = index;
                    break;
                }
            }
            return (returnValue >= 0) ? stateCodes[returnValue] : "";
        }

        public class AmountType
        {
            /// <summary>
            /// Gets or sets the Amount Code as defined by the IRS for 1099 forms
            /// </summary>
            public string Code { get; set; }

            /// <summary>
            /// Gets or sets the Category (Amount Type) corresponding to the Code
            /// </summary>
            public Category Category { get; set; }

            /// <summary>
            /// Constructor
            /// </summary> 
            public AmountType(string Code, Category Category)
            {
                this.Code = Code;
                this.Category = Category;
            }
        }

        public static readonly List<AmountType> AmountTypes_1099MISC = new List<AmountType>()
        {
            new AmountType("1", Category.Rents),
            new AmountType("2", Category.Royalties),
            new AmountType("3", Category.OtherIncome),
            new AmountType("4", Category.FederalIncomeTWH),
            new AmountType("5", Category.FishingBoatProceed),
            new AmountType("6", Category.MedicalHealthCarePayments),
            new AmountType("8", Category.SubstituteInLieuOfInterest),
            new AmountType("A", Category.CropInsuranceProceeds),
            new AmountType("B", Category.ExcessGoldenParachutePayments),
            new AmountType("C", Category.GrossProceedsPaidToAnAttomey),
            new AmountType("D", Category.Section409ADeferrals),
            new AmountType("E", Category.NonqualifiedDeferredCompensation),
            new AmountType("F", Category.FishPurchasedForResale),
            new AmountType("G", Category.NonemployeeCompensation),
        };

        public static readonly List<AmountType> AmountTypes_1099NEC = new List<AmountType>()
        {
            new AmountType("1", Category.NonemployeeCompensation),
            new AmountType("4", Category.FederalIncomeTWH),
        };

        /// <summary>
        /// Returns the Category associated with a pre-2020 1099 class ID code
        /// </summary>
        public static Category Map2019AndPriorClxCodeToCategory (string clxCode)
        {
            switch (clxCode)
            {
                case "1":
                    return Category.Rents;
                case "2":
                    return Category.Royalties;
                case "3":
                    return Category.OtherIncome;
                case "4":
                    return Category.FederalIncomeTWH;
                case "5":
                    return Category.FishingBoatProceed;
                case "6":
                    return Category.MedicalHealthCarePayments;
                case "7":
                    return Category.NonemployeeCompensation;
                case "8":
                    return Category.SubstituteInLieuOfInterest;
                case "9":
                    return Category.DirectSalesForResale;
                case "10":
                    return Category.CropInsuranceProceeds;
                case "13":
                    return Category.ExcessGoldenParachutePayments;
                case "14":
                    return Category.GrossProceedsPaidToAnAttomey;
                case "15A":
                    return Category.Section409ADeferrals;
                case "15B":
                    return Category.NonqualifiedDeferredCompensation;
                case "16":
                    return Category.StateWHT;
                default:
                    return Category.None;
            }
        }

        public static int IndexFromAmountType(AmountType amountType)
        {
            var codeChar = char.ToUpper(amountType.Code[0]);
            if (char.IsDigit(codeChar))
            {
                return int.Parse(codeChar.ToString()) - 1;
            }
            else if (codeChar >= 'A' && codeChar <= 'Z')
            {
                return 9 + codeChar - 'A';
            }
            return -1;
        }

        /// <summary>
        /// Returns whether NEC should be reported as part of the 1099 Misc form for a given year
        /// </summary>
        public static bool ReportNECinMiscForYear(int year)
        {
            return (year < 2020); // in 2020, IRS extracted the NEC box from the 1099-MISC form into it's own 1099-NEC form
        }

        /// <summary>
        /// Returns whether NEC should be reported as part of the 1099 Misc form for a given year
        /// </summary>
        public static bool ReportFishPurchasedForResaleinMiscForYear(int year)
        {
            return (year > 2020); // in 2021, IRS created a new category called Fish Purchased for Resale
        }

        public static int IndexFromCategory(ElectronicFilingReport model, Category category)
        {
            return model.CategoryRecords.TryGetValue(category, out CategoryRec categoryRecord) ? categoryRecord.Index : -1;
        }

        /// <summary>
        /// Returns the associated category for a given APCCS code
        /// </summary>
        public static Category CodeToCategory (ElectronicFilingReport model, string code)
        {
            model.CodeToCategoryMap.TryGetValue(code, out Category result); // result defaults to Category.None if key does not exist
            return result;
        }
    }
}
