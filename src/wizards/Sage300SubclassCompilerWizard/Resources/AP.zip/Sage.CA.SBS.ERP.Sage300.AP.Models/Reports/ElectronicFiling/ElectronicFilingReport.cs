﻿// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. 

#region Usings

using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.ElectronicFiling
{
    /// <summary>
    /// The ElectronicFilingReport class 
    /// </summary>
    public partial class ElectronicFilingReport : ReportBase
    {
        /// <summary>
        /// Gets or sets PaymentYear 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentYear", ResourceType = typeof(ElectronicFilingResx))]
        public int PaymentYear { get; set; }

        /// <summary>
        /// Gets or sets OutputFile 
        /// </summary>
        public string OutputFile { get; set; }

        /// <summary>
        /// Gets or sets FromVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromVendorNumber", ResourceType = typeof(APCommonResx))]
        public string FromVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets ToVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToVendorNumber", ResourceType = typeof(APCommonResx))]
        public string ToVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets TransmitterTaxNumber 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxNumber", ResourceType = typeof(APCommonResx))]
        public string TransmitterTaxNumber { get; set; }

        /// <summary>
        /// Gets or sets ControlCode
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ControlCodeTCC", ResourceType = typeof(ElectronicFilingResx))]
        public string ControlCode { get; set; }

        /// <summary>
        /// Gets or sets TransmitterForeignEntity
        /// </summary>
        public bool TransmitterForeignEntity { get; set; }

        /// <summary>
        /// Gets or sets TestFile
        /// </summary>
        public bool TestFile { get; set; }

        /// <summary>
        /// Gets or sets TransmitterNameLine1 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NameLine1", ResourceType = typeof(ElectronicFilingResx))]
        public string TransmitterNameLine1 { get; set; }

        /// <summary>
        /// Gets or sets TransmitterLine2 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NameLine2", ResourceType = typeof(ElectronicFilingResx))]
        public string TransmitterNameLine2 { get; set; }

        /// <summary>
        /// Gets or sets TransmitterCompany 
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Company", ResourceType = typeof(ElectronicFilingResx))]
        public string TransmitterCompany { get; set; }

        /// <summary>
        /// Gets or sets TransmitterStreet 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddrStreet", ResourceType = typeof(ElectronicFilingResx))]
        public string TransmitterStreet { get; set; }

        /// <summary>
        /// Gets or sets TransmitterCity 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(APCommonResx))]
        public string TransmitterCity { get; set; }

        /// <summary>
        /// Gets or sets TransmitterStateOrProvince 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProv", ResourceType = typeof(APCommonResx))]
        public string TransmitterStateOrProvince { get; set; }

        /// <summary>
        /// Gets or sets TransmitterZipOrPostalCode 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof(APCommonResx))]
        public string TransmitterZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets TransmitterContactName 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(APCommonResx))]
        public string TransmitterContactName { get; set; }

        /// <summary>
        /// Gets or sets TransmitterPhoneNumber 
        /// </summary>
        [StringLength(34, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        public string TransmitterPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets TransmitterEmail 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmailAddress", ResourceType = typeof(ElectronicFilingResx))]
        public string TransmitterEmail { get; set; }

        /// <summary>
        /// Gets or sets TransmitterCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(APCommonResx))]
        public string TransmitterCountry { get; set; }

        /// <summary>
        /// Gets or sets PayerTaxNumber 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxNumber", ResourceType = typeof(APCommonResx))]
        public string PayerTaxNumber { get; set; }

        /// <summary>
        /// Gets or sets PayerNameControl
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NameControl", ResourceType = typeof(ElectronicFilingResx))]
        public string PayerNameControl { get; set; }

        /// <summary>
        /// Gets or sets PayerForeignEntity
        /// </summary>
        public bool PayerForeignEntity { get; set; }

        /// <summary>
        /// Gets or sets PayerTransferAgent
        /// </summary>
        public bool PayerTransferAgent { get; set; }

        /// <summary>
        /// Gets or sets PayerFinalFiling
        /// </summary>
        public bool PayerFinalFiling { get; set; }

        /// <summary>
        /// Gets or sets PayerNameLine1 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NameLine1", ResourceType = typeof(ElectronicFilingResx))]
        public string PayerNameLine1 { get; set; }

        /// <summary>
        /// Gets or sets PayerNameLine2 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NameLine2", ResourceType = typeof(ElectronicFilingResx))]
        public string PayerNameLine2 { get; set; }

        /// <summary>
        /// Gets or sets PayerAgent 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Agent", ResourceType = typeof(ElectronicFilingResx))]
        public string PayerAgent { get; set; }

        /// <summary>
        /// Gets or sets PayerStreet 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddrStreet", ResourceType = typeof(ElectronicFilingResx))]
        public string PayerStreet { get; set; }

        /// <summary>
        /// Gets or sets PayerCity 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(APCommonResx))]
        public string PayerCity { get; set; }

        /// <summary>
        /// Gets or sets PayerStateOrProvince 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProv", ResourceType = typeof(APCommonResx))]
        public string PayerStateOrProvince { get; set; }

        /// <summary>
        /// Gets or sets PayerZipOrPostalCode 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof(APCommonResx))]
        public string PayerZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets PayerPhoneNumber 
        /// </summary>
        [StringLength(34, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        public string PayerPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets PayerOfficeBranch 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OfficeBranch", ResourceType = typeof(ElectronicFilingResx))]
        public string PayerOfficeBranch { get; set; }

        /// <summary>
        /// Gets or sets PayerCountry 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(APCommonResx))]
        public string PayerCountry { get; set; }

        /// <summary>
        /// Gets or sets PayeeCount 
        /// </summary>
        public long PayeeCount { get; set; }

        /// <summary>
        /// Gets or sets NumOfRecordB 
        /// </summary>
        public long NumOfRecordB { get; set; }

        /// <summary>
        /// Gets or sets Vendors
        /// </summary>
        public List<VendorDetail> Vendors { get; set; }

        /// <summary>
        /// Gets or Sets CategoryRecords
        /// </summary>
        public Dictionary<string, Category> CodeToCategoryMap { get; set; }

        /// <summary>
        /// Gets or Sets CategoryRecords
        /// </summary>
        public Dictionary<Category, CategoryRec> CategoryRecords { get; set; }

        /// <summary>
        /// Gets or Sets NumCategories
        /// </summary>
        public int NumCategories { get; set; }

        /// <summary>
        /// Gets or sets BoxCodes
        /// </summary>
        public string MiscBoxCodes { get; set; }

        /// <summary>
        /// Gets or sets BoxCodes
        /// </summary>
        public string NecBoxCodes { get; set; }

        /// <summary>
        /// Gets or Sets IsFormatPhoneNo
        /// To check the status of FormatPhone number in Company screen
        /// If FormatPhoneNo yes then it should come in formatted way, else Unformatted
        /// </summary>
        public bool IsFormatPhoneNo { get; set; }

        /// <summary>
        /// Gets or Sets Apply1099ElectronicFilingProcess
        /// To check status of 1099 Electronic Filing in AP-option screen
        /// If Status is true then it should open page or else display error message
        /// </summary>
        public bool Apply1099ElectronicFilingProcess { get; set; }

        #region Constructors

        /// <summary>
        /// Default Constructor
        /// </summary>
        public ElectronicFilingReport()
        {
            Vendors = new List<VendorDetail>();
        }

        #endregion

    }
}
