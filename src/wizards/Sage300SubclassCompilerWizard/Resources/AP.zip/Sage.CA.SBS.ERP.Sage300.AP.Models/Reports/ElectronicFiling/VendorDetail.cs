﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports.ElectronicFiling
{
    /// <summary>
    /// The VendorDetail class
    /// </summary>
    public class VendorDetail
    {
        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        public Vendor Vendor { get; set; }

        /// <summary>
        /// Gets or sets Total
        /// </summary>
        public double[] Total { get; set; }
    }
}
