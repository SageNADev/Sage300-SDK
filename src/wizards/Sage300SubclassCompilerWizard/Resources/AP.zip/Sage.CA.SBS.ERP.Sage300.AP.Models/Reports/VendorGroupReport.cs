// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.AP.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Partial class for VendorGroupReport
    /// </summary>
    public partial class VendorGroupReport : ReportBase
    {
        /// <summary>
        /// Gets or sets Fromgrp
        /// </summary>
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public string Fromgrp { get; set; }

        /// <summary>
        /// Gets or sets Togrp
        /// </summary>
        public string Togrp { get; set; }

        /// <summary>
        /// Gets or sets Fcurndec
        /// </summary>
        public decimal Fcurndec { get; set; }

        /// <summary>
        /// Gets or sets Phonefmt
        /// </summary>
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public string Phonefmt { get; set; }

        /// <summary>
        /// Gets or sets Profile
        /// </summary>
        [Display(Name = "Profile", ResourceType = typeof(APCommonResx))]
        public bool Profile { get; set; }

        /// <summary>
        /// Gets or sets Members
        /// </summary>
        [Display(Name = "GroupMember", ResourceType = typeof(VendorGroupReportResx))]
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public bool Members { get; set; }

        /// <summary>
        /// Gets or sets Optflds
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public bool Optflds { get; set; }

        /// <summary>
        /// Gets or sets Fromyear
        /// </summary>
        public string Fromyear { get; set; }

        /// <summary>
        /// Gets or sets Toyear
        /// </summary>
        public string Toyear { get; set; }

        /// <summary>
        /// Gets or sets Fromperd
        /// </summary>
        public string Fromperd { get; set; }

        /// <summary>
        /// Gets or sets Toperd
        /// </summary>
        public string Toperd { get; set; }

        /// <summary>
        /// Gets or sets Counts
        /// </summary>
        [Display(Name = "IncludeCounts", ResourceType = typeof(VendorGroupReportResx))]
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public bool Counts { get; set; }

        /// <summary>
        /// Gets or Sets ReportType
        /// </summary>
        [Display(Name = "ReportType", ResourceType = typeof(APCommonResx))]
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public VendorGroupReportType ReportType { get; set; }

        /// <summary>
        /// Gets or sets MaxFromPerd
        /// </summary>
        public int MaxFromPerd { get; set; }

        /// <summary>
        /// Gets or sets MaxToPerd
        /// </summary>
        public int MaxToPerd { get; set; }

        /// <summary>
        /// Gets or sets MinFromPerd
        /// </summary>
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public int MinFromPerd { get; set; }

        /// <summary>
        /// Gets or sets MinToPerd
        /// </summary>
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public int MinToPerd { get; set; }
    }
}