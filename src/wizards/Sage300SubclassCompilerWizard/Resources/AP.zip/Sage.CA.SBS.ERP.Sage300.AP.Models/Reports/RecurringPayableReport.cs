// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Partial class for Recurring Payable Report
    /// </summary>
    public partial class RecurringPayableReport : ReportBase
    {
        /// <summary>
        /// Gets or sets Homecurn
        /// </summary>
        public string Homecurn { get; set; }

        /// <summary>
        /// Gets or sets Fromcode
        /// </summary>
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public string Fromcode { get; set; }

        /// <summary>
        /// Gets or sets Tocode
        /// </summary>
        public string Tocode { get; set; }

        /// <summary>
        /// Gets or sets Fromvend
        /// </summary>
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public string Fromvend { get; set; }

        /// <summary>
        /// Gets or sets Tovend
        /// </summary>
        public string Tovend { get; set; }

        /// <summary>
        /// Gets or sets Schedule
        /// </summary>
        public bool Schedule { get; set; }

        /// <summary>
        /// Gets or sets Optflds
        /// </summary>
        public bool Optflds { get; set; }

        /// <summary>
        /// Gets or sets Swmulticurn
        /// </summary>
        public string Swmulticurn { get; set; }

        /// <summary>
        /// Gets or sets Swglactive
        /// </summary>
        public string Swglactive { get; set; }

        /// <summary>
        /// Gets or sets Swpmactive
        /// </summary>
        public string Swpmactive { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        public string Category { get; set; }
    }
}