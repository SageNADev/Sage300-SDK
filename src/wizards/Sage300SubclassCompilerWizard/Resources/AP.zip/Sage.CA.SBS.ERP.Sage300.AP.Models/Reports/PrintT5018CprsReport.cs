/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// PrintT5018CprsReport class
    /// </summary>
    public partial class PrintT5018CprsReport : ReportBase
    {
        /// <summary>
        /// Gets or sets FromVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromVen {get; set;}

		/// <summary>
        /// Gets or sets ToVendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToVen {get; set;}

		/// <summary>
        /// Gets or sets TaxReportingType 
        /// </summary>
        public TaxReportingType TaxReportingType {get; set;}

		/// <summary>
        /// Gets or sets FromCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CodeFrom {get; set;}

		/// <summary>
        /// Gets or sets ToCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CodeTo {get; set;}

		/// <summary>
        /// Gets or sets Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Year {get; set;}

		/// <summary>
        /// Gets or sets the Business number
        /// </summary>
        public string FedId {get; set;}

  		/// <summary>
        /// Gets or sets CommandCode 
        /// </summary>
        public CommandCode CommandCode {get; set;}
		
        /// <summary>
        /// Gets or sets FileName 
        /// </summary>
        public string FileName {get; set;}
		   
    }

}