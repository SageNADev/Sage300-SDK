﻿
namespace Sage.CA.SBS.ERP.Sage300.AP.Models.Reports
{
    /// <summary>
    /// Class used for dropdown
    /// </summary>
    public class AgedRetainageDropDown
    {
        #region Model properties

        /// <summary>
        /// Id for Aged Retainage
        /// </summary>
        public int Value { get; set; }

        /// <summary>
        /// Description
        /// </summary>
        public string Description { get; set; }

        #endregion
    }
}