// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Reference
using Sage.CA.SBS.ERP.Sage300.AP.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AP.Models
{
    /// <summary>
    /// Class for SelectedVendor.
    /// </summary>
    public partial class SelectedVendor : ModelBase
    {

        /// <summary>
        /// Gets or sets SequenceNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets RecordNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.RecordNumber, Id = Index.RecordNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long RecordNumber { get; set; }

        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets DeliveryMethod 
        /// </summary>

        [ViewField(Name = Fields.DeliveryMethod, Id = Index.DeliveryMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public DeliveryMethod DeliveryMethod { get; set; }

        /// <summary>
        /// Gets or sets SortFieldValue1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldValue1, Id = Index.SortFieldValue1, FieldType = EntityFieldType.Char, Size = 60)]
        public string SortFieldValue1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldValue2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldValue2, Id = Index.SortFieldValue2, FieldType = EntityFieldType.Char, Size = 60)]
        public string SortFieldValue2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldValue3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldValue3, Id = Index.SortFieldValue3, FieldType = EntityFieldType.Char, Size = 60)]
        public string SortFieldValue3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldValue4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SortFieldValue4, Id = Index.SortFieldValue4, FieldType = EntityFieldType.Char, Size = 60)]
        public string SortFieldValue4 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldType1 
        /// </summary>

        [ViewField(Name = Fields.SortFieldType1, Id = Index.SortFieldType1, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldType1 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldType2 
        /// </summary>

        [ViewField(Name = Fields.SortFieldType2, Id = Index.SortFieldType2, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldType2 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldType3 
        /// </summary>

        [ViewField(Name = Fields.SortFieldType3, Id = Index.SortFieldType3, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldType3 { get; set; }

        /// <summary>
        /// Gets or sets SortFieldType4 
        /// </summary>

        [ViewField(Name = Fields.SortFieldType4, Id = Index.SortFieldType4, FieldType = EntityFieldType.Int, Size = 2)]
        public int SortFieldType4 { get; set; }
    }
}
