﻿/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

#region Imports
#endregion

namespace Sage.CA.SBS.ERP.Sage300.TW.Models
{
    /// <summary>
    /// This class is used as a simple container for building the grid drop down lists
    /// for the TW Configuration page.
    /// </summary>
    public class TaxClassSimplified
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public TaxClassSimplified()
        {
        }
        #endregion

        #region Public Properties
        /// <summary>
        /// The Tax Class Identifier
        /// </summary>
        public int Value { get; set; }

        /// <summary>
        /// The Tax Class description
        /// </summary>
        public string Text { get; set; }
        #endregion
    }
}
