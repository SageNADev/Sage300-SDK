﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TW.Models.Enums;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.TW.Models
{
    public partial class TWBoxAmount : ModelBase
    {
        /// <summary>
        /// Gets or sets FromFiscalYear
        /// </summary>
        [Key]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets FromFiscalPeriod
        /// </summary>
        public int FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets ToFiscalYear
        /// </summary>
        [Key]
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or sets ToFiscalPeriod
        /// </summary>
        [Key]
        public int ToPeriod { get; set; }

        /// <summary>
        /// Gets or sets BoxNumber
        /// </summary>
        [Key]
        public BoxNumber BoxNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailLineNumber
        /// </summary>
        [Key]
        public decimal DetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets FromGLOrTX
        /// </summary>
        public FromType From { get; set; }

        /// <summary>
        /// Gets or sets GLAccountNumber
        /// </summary>
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority
        /// </summary>
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets CustomerVendorTaxClass
        /// </summary>
        public int BuyerTaxClass { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClass
        /// </summary>
        public int ItemTaxClass { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        public decimal Amount { get; set; }
    }
}
