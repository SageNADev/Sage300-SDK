/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TW.Models
{

    /// <summary>
    /// Class Fiscal year from/to paramters
    /// </summary>
    public class BASParams
    {
        /// <summary>
        /// From fiscal year
        /// </summary>
        public string FromYear { get; set; }
        /// <summary>
        /// From fiscal period
        /// </summary>
        public int FromPeriod { get; set; }
        /// <summary>
        /// To fiscal year
        /// </summary>
        public string ToYear { get; set; }
        /// <summary>
        /// To fical period
        /// </summary>
        public int ToPeriod { get; set; }

    }

    /// <summary>
    /// Class Australia GST Configuration Header.
    /// </summary>
    public partial class TwGBas : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of Australia GST Configuration Header
        /// </summary>
        public TwGBas()
        {
            Items = new List<TWBoxAmount>();
        }

        /// <summary>
        /// Gets or sets From Fiscal Year 
        /// </summary>
        [Key]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets From Fiscal Period 
        /// </summary>
        [Key]
        public int FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets To Fiscal Year
        /// </summary>
        [Key]
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or sets To Fiscal Period 
        /// </summary>
        [Key]
        public int ToPeriod { get; set; }

        /// <summary>
        /// Gets or sets Calculated G1 
        /// </summary>
        public decimal CalG1 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G1
        /// </summary>
        public decimal PMG1 { get; set; }

        /// <summary>
        /// Gets or sets Calculated G2 
        /// </summary>
        public decimal CalG2 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G2
        /// </summary>
        public decimal PMG2 { get; set; }

        /// <summary>
        /// Gets or sets Calculated G3
        /// </summary>
        public decimal CalG3 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G3
        /// </summary>
        public decimal PMG3 { get; set; }

        /// <summary>
        /// Gets or sets Calculated G4
        /// </summary>
        public decimal CalG4 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G4
        /// </summary>
        public decimal PMG4 { get; set; }

        /// <summary>
        /// Gets or sets Calculated G7
        /// </summary>
        public decimal CalG7 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G7
        /// </summary>
        public decimal PMG7 { get; set; }

        /// <summary>
        /// Gets or sets Calculated G10
        /// </summary>
        public decimal CalG10 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G10
        /// </summary>
        public decimal PMG10 { get; set; }

        /// <summary>
        /// Gets or sets Calculated G11 
        /// </summary>
        public decimal CalG11 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G11
        /// </summary>
        public decimal PMG11 { get; set; }

        /// <summary>
        /// Gets or sets Calculated G13
        /// </summary>
        public decimal CalG13 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G13
        /// </summary>
        public decimal PMG13 { get; set; }

        /// <summary>
        /// Gets or sets Calculated G14
        /// </summary>
        public decimal CalG14 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G14
        /// </summary>
        public decimal PMG14 { get; set; }

        /// <summary>
        /// Gets or sets Calculated G15
        /// </summary>
        public decimal CalG15 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G15
        /// </summary>
        public decimal PMG15 { get; set; }

        /// <summary>
        /// Gets or sets Calculated G18
        /// </summary>
        public decimal CalG18 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus G18
        /// </summary>
        public decimal PMG18 { get; set; }

        /// <summary>
        /// Gets or sets Calculated W1 
        /// </summary>
        public decimal CalW1 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus W1
        /// </summary>
        public decimal PMW1 { get; set; }

        /// <summary>
        /// Gets or sets Calculated W2
        /// </summary>
        public decimal CalW2 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus W2
        /// </summary>
        public decimal PMW2 { get; set; }

        /// <summary>
        /// Gets or sets Calculated W4
        /// </summary>
        public decimal CalW4 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus W4
        /// </summary>
        public decimal PMW4 { get; set; }

        /// <summary>
        /// Gets or sets Calculated W3
        /// </summary>
        public decimal CalW3 { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus W3
        /// </summary>
        public decimal PMW3 { get; set; }

        /// <summary>
        /// Gets or sets Calculated 5B
        /// </summary>
        public decimal Cal5B { get; set; }

        /// <summary>
        /// Gets or sets Plus OR Minus 5B
        /// </summary>
        public decimal PM5B { get; set; }

        /// <summary>
        /// Gets or sets Calculated 7
        /// </summary>
        public decimal Cal7 { get; set; }

        /// <summary>
        /// Gets or sets TPlus OR Minus 7
        /// </summary>
        public decimal PM7 { get; set; }

        /// <summary>
        /// Gets or sets Total T7
        /// </summary>
        public decimal TotT7 { get; set; }

        /// <summary>
        /// Gets or sets Total T8
        /// </summary>
        public decimal TotT8 { get; set; }

        /// <summary>
        /// Gets or sets Total T9
        /// </summary>
        public decimal TotT9 { get; set; }

        /// <summary>
        /// Gets or sets T4 Reason code for variation
        /// </summary>
        public string ReasonT4 { get; set; }

        /// <summary>
        /// Gets or sets JSON Audit File Name
        /// </summary>
        public string JsonFile { get; set; }

        /// <summary>
        /// Gets or sets Total G1
        /// </summary>
        public decimal TotG1 { get; set; }

        /// <summary>
        /// Gets or sets Total G2
        /// </summary>
        public decimal TotG2 { get; set; }

        /// <summary>
        /// Gets or sets Total G3
        /// </summary>
        public decimal TotG3 { get; set; }

        /// <summary>
        /// Gets or sets Total G4
        /// </summary>
        public decimal TotG4 { get; set; }

        /// <summary>
        /// Gets or sets Total G7
        /// </summary>
        public decimal TotG7 { get; set; }

        /// <summary>
        /// Gets or sets Total G10
        /// </summary>
        public decimal TotG10 { get; set; }

        /// <summary>
        /// Gets or sets Total G11
        /// </summary>
        public decimal TotG11 { get; set; }

        /// <summary>
        /// Gets or sets Total G13
        /// </summary>
        public decimal TotG13 { get; set; }

        /// <summary>
        /// Gets or sets Total G14
        /// </summary>
        public decimal TotG14 { get; set; }

        /// <summary>
        /// Gets or sets JTotal G15
        /// </summary>
        public decimal TotG15 { get; set; }

        /// <summary>
        /// Gets or sets Total G18
        /// </summary>
        public decimal TotG18 { get; set; }

        /// <summary>
        /// Gets or sets Total W1
        /// </summary>
        public decimal TotW1 { get; set; }

        /// <summary>
        /// Gets or sets Total W2
        /// </summary>
        public decimal TotW2 { get; set; }

        /// <summary>
        /// Gets or sets Total W4
        /// </summary>
        public decimal TotW4 { get; set; }

        /// <summary>
        /// Gets or sets Total W3
        /// </summary>
        public decimal TotW3 { get; set; }

        /// <summary>
        /// Gets or sets Total 5B
        /// </summary>
        public decimal Tot5B { get; set; }

        /// <summary>
        /// Gets or sets Total 7
        /// </summary>
        public decimal Tot7 { get; set; }

        /// <summary>
        /// Gets or sets Total G5
        /// </summary>
        public decimal TotG5 { get; set; }

        /// <summary>
        /// Gets or sets Total G6
        /// </summary>
        public decimal TotG6 { get; set; }

        /// <summary>
        /// Gets or sets Total G8
        /// </summary>
        public decimal TotG8 { get; set; }

        /// <summary>
        /// Gets or sets Total G9
        /// </summary>
        public decimal TotG9 { get; set; }

        /// <summary>
        /// Gets or sets Total G12
        /// </summary>
        public decimal TotG12 { get; set; }

        /// <summary>
        /// Gets or sets Total G16
        /// </summary>
        public decimal TotG16 { get; set; }

        /// <summary>
        /// Gets or sets Total G17
        /// </summary>
        public decimal TotG17 { get; set; }

        /// <summary>
        /// Gets or sets Total G19
        /// </summary>
        public decimal TotG19 { get; set; }

        /// <summary>
        /// Gets or sets Total G20
        /// </summary>
        public decimal TotG20 { get; set; }

        /// <summary>
        /// Gets or sets Total W5
        /// </summary>
        public decimal TotW5 { get; set; }

        /// <summary>
        /// Gets or sets Total 1A
        /// </summary>
        public decimal Tot1A { get; set; }

        /// <summary>
        /// Gets or sets Total 1B
        /// </summary>
        public decimal Tot1B { get; set; }

        /// <summary>
        /// Gets or sets Total 4
        /// </summary>
        public decimal Tot4 { get; set; }

        /// <summary>
        /// Gets or sets Total 5A
        /// </summary>
        public decimal Tot5A { get; set; }

        /// <summary>
        /// Gets or sets Total 8A
        /// </summary>
        public decimal Tot8A { get; set; }

        /// <summary>
        /// Gets or sets Total 8B
        /// </summary>
        public decimal Tot8B { get; set; }

        /// <summary>
        /// Gets or sets Is 8A Moe than 8B 
        /// </summary>
        public bool AGTB { get; set; }

        /// <summary>
        /// Gets or sets Total 9
        /// </summary>
        public decimal Tot9 { get; set; }

        /// <summary>
        /// Get or set details items for grid
        /// </summary>
        public List<TWBoxAmount> Items { get; set; }
    }
}