﻿// /* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TW.Resources;

namespace Sage.CA.SBS.ERP.Sage300.TW.Models.Enums
{
    /// <summary>
    /// Enum Transaction Type
    /// </summary>
    public enum TransactionType
    {
        /// <summary>
        /// For Sales
        /// </summary>
        [EnumValue("Sales", typeof(EnumerationsResx))]
        Sales = 1,

        /// <summary>
        /// For Purchase
        /// </summary>
        [EnumValue("Purchase", typeof(EnumerationsResx))]
        Purchase = 2,

        /// <summary>
        /// For Purchase
        /// </summary>
        [EnumValue("NotApplicable", typeof(EnumerationsResx))]
        NotApplicable = 3
    }
}