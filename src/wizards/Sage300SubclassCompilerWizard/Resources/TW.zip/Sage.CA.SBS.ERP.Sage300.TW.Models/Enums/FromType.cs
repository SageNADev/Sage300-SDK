﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TW.Resources;

namespace Sage.CA.SBS.ERP.Sage300.TW.Models.Enums
{
    public enum FromType
    {
        /// <summary>
        /// Gets or sets GeneralLedger
        /// </summary>
        [EnumValue("GeneralLedger", typeof(EnumerationsResx))]
        GeneralLedger = 1,

        /// <summary>
        /// Gets or sets TaxServices
        /// </summary>
        [EnumValue("TaxServices", typeof(EnumerationsResx))]
        TaxServices = 2

    }
}
