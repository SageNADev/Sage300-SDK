﻿// /* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TW.Resources;

namespace Sage.CA.SBS.ERP.Sage300.TW.Models.Enums
{
    /// <summary>
    /// Enum Transaction Type
    /// </summary>
    public enum BoxNumber
    {
        /// <summary>
        /// For Total Sales
        /// </summary>
        [EnumValue("TotalSales", typeof(EnumerationsResx))]
        G1 = 1,

        /// <summary>
        /// For Export Sales
        /// </summary>
        [EnumValue("ExportSales", typeof(EnumerationsResx))]
        G2 = 2,

        /// <summary>
        /// For Other GST-Free Sales
        /// </summary>
        [EnumValue("OtherGSTFreeSales", typeof(EnumerationsResx))]
        G3 = 3,
        
        /// <summary>
        /// For Input Taxed Sales
        /// </summary>
        [EnumValue("InputTaxedSales", typeof(EnumerationsResx))]
        G4 = 4,
        
        /// <summary>
        /// For Sales Adjustments
        /// </summary>
        [EnumValue("SalesAdjustments", typeof(EnumerationsResx))]
        G7 = 5,
        
        /// <summary>
        /// For Capital Purchases
        /// </summary>
        [EnumValue("CapitalPurchases", typeof(EnumerationsResx))]
        G10 = 6,
        
        /// <summary>
        /// For Non-Capital Purchases
        /// </summary>
        [EnumValue("NonCapitalPurchases", typeof(EnumerationsResx))]
        G11 = 7,
        
        /// <summary>
        /// For Purchases for Making Input Taxes Sales
        /// </summary>
        [EnumValue("PurchaseForMakingInputTaxesSales", typeof(EnumerationsResx))]
        G13 = 8,
        
        /// <summary>
        /// For GST-Free Purchases
        /// </summary>
        [EnumValue("GSTFreePurchases", typeof(EnumerationsResx))]
        G14 = 9,
        
        /// <summary>
        /// For Estimated Purchases for Private Use
        /// </summary>
        [EnumValue("EstimatedPurchasesForPrivateUse", typeof(EnumerationsResx))]
        G15 = 10,
        
        /// <summary>
        /// For Purchase Adjustments
        /// </summary>
        [EnumValue("PurchaseAdjustments", typeof(EnumerationsResx))]
        G18 = 11,
        
        /// <summary>
        /// For Total salary, wages and other payments
        /// </summary>
        [EnumValue("TotalSalaryWagesPayments", typeof(EnumerationsResx))]
        W1 = 16,
        
        /// <summary>
        /// For Amount withheld from payments shown at W1
        /// </summary>
        [EnumValue("AmountWithheldFromPayments", typeof(EnumerationsResx))]
        W2 = 17,
        
        /// <summary>
        /// For Amount withheld where no ABN is quoted
        /// </summary>
        [EnumValue("AmountWithheldWhereNoABN", typeof(EnumerationsResx))]
        W4 = 18,
        
        /// <summary>
        /// For Other amounts withheld
        /// </summary>
        [EnumValue("OtherAmountsWithheld", typeof(EnumerationsResx))]
        W3 = 19,
        
        /// <summary>
        /// For Credit from PAYG Income Tax Instalment Variation
        /// </summary>
        [EnumValue("CreditFromPAYGIncome", typeof(EnumerationsResx))]
        _5B = 20, 
        /// <summary>
        /// For Deferred Company/Fund Instalment
        /// </summary>
        [EnumValue("DeferredCompanyInstalment", typeof(EnumerationsResx))]
        _7 = 21 
    }
}