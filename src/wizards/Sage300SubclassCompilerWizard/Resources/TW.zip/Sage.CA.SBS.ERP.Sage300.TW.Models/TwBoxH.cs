/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.TW.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TW.Models
{
    /// <summary>
    /// Class Australia GST Configuration Header.
    /// </summary>
    public partial class TwBoxH : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of Australia GST Configuration Header
        /// </summary>
        public TwBoxH()
        {
            Items = new List<TwBoxD>();
        }

        /// <summary>
        /// Gets or sets Box Number
        /// </summary>
        [Key]
        public BoxNumber Box { get; set; }

        /// <summary>
        /// Gets or sets Number Detail
        /// </summary>
        public int NumDetail { get; set; }

        /// <summary>
        /// Gets or sets Transaction Type 
        /// </summary>
        public TransactionType TType { get; set; }

        /// <summary>
        /// Gets or sets list of details 
        /// </summary>
        public List<TwBoxD> Items { get; set; } 

    }
}