﻿namespace Sage.CA.SBS.ERP.Sage300.TW.Models
{
    public partial class TwGBas
    {
        /// <summary>
        /// Contains list of Australia GST Configuration Header Index Constants
        /// </summary>
        public class Index
        {
            #region Indexes

            /// <summary>
            /// Index for From Fiscal Year 
            /// </summary>
            public const int FromYear = 1;

            /// <summary>
            /// Index for From Fiscal Period 
            /// </summary>
            public const int FromPeriod = 2;

            /// <summary>
            /// Index for To Fiscal Year
            /// </summary>
            public const int ToYear = 3;

            /// <summary>
            /// Index for To Fiscal Period 
            /// </summary>
            public const int ToPeriod = 4;

            /// <summary>
            /// Index for Calculated G1 
            /// </summary>
            public const int CalG1 = 5;

            /// <summary>
            /// Index for Plus OR Minus G1
            /// </summary>
            public const int PMG1 = 6;

            /// <summary>
            /// Index for Calculated G2 
            /// </summary>
            public const int CalG2 = 7;

            /// <summary>
            /// Index for Plus OR Minus G2
            /// </summary>
            public const int PMG2 = 8;

            /// <summary>
            /// Index for Calculated G3
            /// </summary>
            public const int CalG3 = 9;

            /// <summary>
            /// Index for Plus OR Minus G3
            /// </summary>
            public const int PMG3 = 10;

            /// <summary>
            /// Index for Calculated G4
            /// </summary>
            public const int CalG4 = 11;

            /// <summary>
            /// Index for Plus OR Minus G4
            /// </summary>
            public const int PMG4 = 12;

            /// <summary>
            /// Index for Calculated G7
            /// </summary>
            public const int CalG7 = 13;

            /// <summary>
            /// Index for Plus OR Minus G7
            /// </summary>
            public const int PMG7 = 14;

            /// <summary>
            /// Index for Calculated G10
            /// </summary>
            public const int CalG10 = 15;

            /// <summary>
            /// Index for Plus OR Minus G10
            /// </summary>
            public const int PMG10 = 16;

            /// <summary>
            /// Index for Calculated G11 
            /// </summary>
            public const int CalG11 = 17;

            /// <summary>
            /// Index for Plus OR Minus G11
            /// </summary>
            public const int PMG11 = 18;

            /// <summary>
            /// Index for Calculated G13
            /// </summary>
            public const int CalG13 = 19;

            /// <summary>
            /// Index for Plus OR Minus G13
            /// </summary>
            public const int PMG13 = 20;

            /// <summary>
            /// Index for Calculated G14
            /// </summary>
            public const int CalG14 = 21;

            /// <summary>
            /// Index for Plus OR Minus G14
            /// </summary>
            public const int PMG14 = 22;

            /// <summary>
            /// Index for Calculated G15
            /// </summary>
            public const int CalG15 = 23;

            /// <summary>
            /// Index for Plus OR Minus G15
            /// </summary>
            public const int PMG15 = 24;

            /// <summary>
            /// Index for Calculated G18
            /// </summary>
            public const int CalG18 = 25;

            /// <summary>
            /// Index for Plus OR Minus G18
            /// </summary>
            public const int PMG18 = 26;

            /// <summary>
            /// Index for Calculated W1 
            /// </summary>
            public const int CalW1 = 27;

            /// <summary>
            /// Index for Plus OR Minus W1
            /// </summary>
            public const int PMW1 = 28;

            /// <summary>
            /// Index for Calculated W2
            /// </summary>
            public const int CalW2 = 29;

            /// <summary>
            /// Index for Plus OR Minus W2
            /// </summary>
            public const int PMW2 = 30;

            /// <summary>
            /// Index for Calculated W4
            /// </summary>
            public const int CalW4 = 31;

            /// <summary>
            /// Index for Plus OR Minus W4
            /// </summary>
            public const int PMW4 = 32;

            /// <summary>
            /// Index for Calculated W3
            /// </summary>
            public const int CalW3 = 33;

            /// <summary>
            /// Index for Plus OR Minus W3
            /// </summary>
            public const int PMW3 = 34;

            /// <summary>
            /// Index for Calculated 5B
            /// </summary>
            public const int Cal5B = 35;

            /// <summary>
            /// Index for Plus OR Minus 5B
            /// </summary>
            public const int PM5B = 36;

            /// <summary>
            /// Index for Calculated 7
            /// </summary>
            public const int Cal7 = 37;

            /// <summary>
            /// Index for TPlus OR Minus 7
            /// </summary>
            public const int PM7 = 38;

            /// <summary>
            /// Index for Total T7
            /// </summary>
            public const int TotT7 = 39;

            /// <summary>
            /// Index for Total T8
            /// </summary>
            public const int TotT8 = 40;

            /// <summary>
            /// Index for Total T9
            /// </summary>
            public const int TotT9 = 41;

            /// <summary>
            /// Index for T4 Reason code for variation
            /// </summary>
            public const int ReasonT4 = 42;

            /// <summary>
            /// Index for JSON Audit File Name
            /// </summary>
            public const int JsonFile = 43;

            /// <summary>
            /// Index for Total G1
            /// </summary>
            public const int TotG1 = 75;

            /// <summary>
            /// Index for Total G2
            /// </summary>
            public const int TotG2 = 76;

            /// <summary>
            /// Index for Total G3
            /// </summary>
            public const int TotG3 = 77;

            /// <summary>
            /// Index for Total G4
            /// </summary>
            public const int TotG4 = 78;

            /// <summary>
            /// Index for Total G7
            /// </summary>
            public const int TotG7 = 79;

            /// <summary>
            /// Index for Total G10
            /// </summary>
            public const int TotG10 = 80;

            /// <summary>
            /// Index for Total G11
            /// </summary>
            public const int TotG11 = 81;

            /// <summary>
            /// Index for Total G13
            /// </summary>
            public const int TotG13 = 82;

            /// <summary>
            /// Index for Total G14
            /// </summary>
            public const int TotG14 = 83;

            /// <summary>
            /// Index for JTotal G15
            /// </summary>
            public const int TotG15 = 84;

            /// <summary>
            /// Index for Total G18
            /// </summary>
            public const int TotG18 = 85;

            /// <summary>
            /// Index for Total W1
            /// </summary>
            public const int TotW1 = 86;

            /// <summary>
            /// Index for Total W2
            /// </summary>
            public const int TotW2 = 87;

            /// <summary>
            /// Index for Total W4
            /// </summary>
            public const int TotW4 = 88;

            /// <summary>
            /// Index for Total W3
            /// </summary>
            public const int TotW3 = 89;

            /// <summary>
            /// Index for Total 5B
            /// </summary>
            public const int Tot5B = 90;

            /// <summary>
            /// Index for Total 7
            /// </summary>
            public const int Tot7 = 91;

            /// <summary>
            /// Index for Total G5
            /// </summary>
            public const int TotG5 = 92;

            /// <summary>
            /// Index for Total G6
            /// </summary>
            public const int TotG6 = 93;

            /// <summary>
            /// Index for Total G8
            /// </summary>
            public const int TotG8 = 94;

            /// <summary>
            /// Index for Total G9
            /// </summary>
            public const int TotG9 = 95;

            /// <summary>
            /// Index for Total G12
            /// </summary>
            public const int TotG12 = 96;

            /// <summary>
            /// Index for Total G16
            /// </summary>
            public const int TotG16 = 97;

            /// <summary>
            /// Index for Total G17
            /// </summary>
            public const int TotG17 = 98;

            /// <summary>
            /// Index for Total G19
            /// </summary>
            public const int TotG19 = 99;

            /// <summary>
            /// Index for Total G20
            /// </summary>
            public const int TotG20 = 100;

            /// <summary>
            /// Index for Total W5
            /// </summary>
            public const int TotW5 = 101;

            /// <summary>
            /// Index for Total 1A
            /// </summary>
            public const int Tot1A = 102;

            /// <summary>
            /// Index for Total 1B
            /// </summary>
            public const int Tot1B = 103;

            /// <summary>
            /// Index for Total 4
            /// </summary>
            public const int Tot4 = 104;

            /// <summary>
            /// Index for Total 5A
            /// </summary>
            public const int Tot5A = 105;

            /// <summary>
            /// Index for Total 8A
            /// </summary>
            public const int Tot8A = 106;

            /// <summary>
            /// Index for Total 8B
            /// </summary>
            public const int Tot8B = 107;

            /// <summary>
            /// Index for Is 8A Moe than 8B 
            /// </summary>
            public const int AGTB = 108;

            /// <summary>
            /// Index for Total 9
            /// </summary>
            public const int Tot9 = 109;

            #endregion
        }
    }
}
