﻿// Assembly-specific information. The common information is in the ModuleAssemblyInfo.cs

// /* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("Sage.CA.SBS.ERP.Sage300.TW.Models")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.

[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("84d736be-ad46-49b9-a863-ad6e14c13982")]
