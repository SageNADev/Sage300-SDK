﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.TW.Models
{
    public partial class TWBoxAmount
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "TW0580";

         #region Properties

        /// <summary>
        /// Contains list of BASWorksheetDetailAmount Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for FromFiscalYear
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for FromFiscalPeriod
            /// </summary>
            public const string FromPeriod = "FROMPERIOD";

            /// <summary>
            /// Property for ToFiscalYear
            /// </summary>
            public const string ToYear = "TOYEAR";

            /// <summary>
            /// Property for ToFiscalPeriod
            /// </summary>
            public const string ToPeriod = "TOPERIOD";

            /// <summary>
            /// Property for BoxNumber
            /// </summary>
            public const string BoxNumber = "BOX";

            /// <summary>
            /// Property for DetailLineNumber
            /// </summary>
            public const string DetailLineNumber = "DETWILNUM";

            /// <summary>
            /// Property for FromGLOrTX
            /// </summary>
            public const string FromType = "FROM";

            /// <summary>
            /// Property for GLAccountNumber
            /// </summary>
            public const string GLAccountNumber = "GLACCT";

            /// <summary>
            /// Property for TaxAuthority
            /// </summary>
            public const string TaxAuthority = "TWXAUTH";

            /// <summary>
            /// Property for CustomerVendorTaxClass
            /// </summary>
            public const string CustomerVendorTaxClass = "BUYERCLASS";

            /// <summary>
            /// Property for ItemTaxClass
            /// </summary>
            public const string ItemTaxClass = "ITEMCLASS";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "AMOUNT";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of BASWorksheetDetailAmount Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for FromFiscalYear
            /// </summary>
            public const int FromFiscalYear = 1;

            /// <summary>
            /// Property Indexer for FromFiscalPeriod
            /// </summary>
            public const int FromFiscalPeriod = 2;

            /// <summary>
            /// Property Indexer for ToFiscalYear
            /// </summary>
            public const int ToFiscalYear = 3;

            /// <summary>
            /// Property Indexer for ToFiscalPeriod
            /// </summary>
            public const int ToFiscalPeriod = 4;

            /// <summary>
            /// Property Indexer for BoxNumber
            /// </summary>
            public const int BoxNumber = 5;

            /// <summary>
            /// Property Indexer for DetailLineNumber
            /// </summary>
            public const int DetailLineNumber = 6;

            /// <summary>
            /// Property Indexer for FromGLOrTX
            /// </summary>
            public const int FromGLOrTX = 7;

            /// <summary>
            /// Property Indexer for GLAccountNumber
            /// </summary>
            public const int GLAccountNumber = 8;

            /// <summary>
            /// Property Indexer for TaxAuthority
            /// </summary>
            public const int TaxAuthority = 9;

            /// <summary>
            /// Property Indexer for CustomerVendorTaxClass
            /// </summary>
            public const int BuyerTaxClass = 10;

            /// <summary>
            /// Property Indexer for ItemTaxClass
            /// </summary>
            public const int ItemTaxClass = 11;

            /// <summary>
            /// Property Indexer for Amount
            /// </summary>
            public const int Amount = 12;

        }

        #endregion
    }
}
