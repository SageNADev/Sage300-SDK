/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TW.Models
{
    /// <summary>
    /// Contains list of Australia GST Business Activity Statement Header Constants 
    /// </summary>
    public partial class TwGBas
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "TW0400";

        /// <summary>
        /// Contains list of Australia GST Business Activity Statement Header Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for From Fiscal Year 
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for From Fiscal Period 
            /// </summary>
            public const string FromPeriod = "FROMPERIOD";

            /// <summary>
            /// Property for To Fiscal Year
            /// </summary>
            public const string ToYear = "TOYEAR";

            /// <summary>
            /// Property for To Fiscal Period 
            /// </summary>
            public const string ToPeriod = "TOPERIOD";

            /// <summary>
            /// Property for Calculated G1 
            /// </summary>
            public const string CalG1 = "CALG1";

            /// <summary>
            /// Property for Plus OR Minus G1
            /// </summary>
            public const string PMG1 = "PMG1";

            /// <summary>
            /// Property for Calculated G2 
            /// </summary>
            public const string CalG2 = "CALG2";

            /// <summary>
            /// Property for Plus OR Minus G2
            /// </summary>
            public const string PMG2 = "PMG2";

            /// <summary>
            /// Property for Calculated G3
            /// </summary>
            public const string CalG3 = "CALG3";

            /// <summary>
            /// Property for Plus OR Minus G3
            /// </summary>
            public const string PMG3 = "PMG3";

            /// <summary>
            /// Property for Calculated G4
            /// </summary>
            public const string CalG4 = "CALG4";

            /// <summary>
            /// Property for Plus OR Minus G4
            /// </summary>
            public const string PMG4 = "PMG4";

            /// <summary>
            /// Property for Calculated G7
            /// </summary>
            public const string CalG7 = "CALG7";

            /// <summary>
            /// Property for Plus OR Minus G7
            /// </summary>
            public const string PMG7 = "PMG7";

            /// <summary>
            /// Property for Calculated G10
            /// </summary>
            public const string CalG10 = "CALG10";

            /// <summary>
            /// Property for Plus OR Minus G10
            /// </summary>
            public const string PMG10 = "PMG10";

            /// <summary>
            /// Property for Calculated G11 
            /// </summary>
            public const string CalG11 = "CALG11";

            /// <summary>
            /// Property for Plus OR Minus G11
            /// </summary>
            public const string PMG11 = "PMG11";

            /// <summary>
            /// Property for Calculated G13
            /// </summary>
            public const string CalG13 = "CALG13";

            /// <summary>
            /// Property for Plus OR Minus G13
            /// </summary>
            public const string PMG13 = "PMG13";

            /// <summary>
            /// Property for Calculated G14
            /// </summary>
            public const string CalG14 = "CALG14";

            /// <summary>
            /// Property for Plus OR Minus G14
            /// </summary>
            public const string PMG14 = "PMG14";

            /// <summary>
            /// Property for Calculated G15
            /// </summary>
            public const string CalG15 = "CALG15";

            /// <summary>
            /// Property for Plus OR Minus G15
            /// </summary>
            public const string PMG15 = "PMG15";

            /// <summary>
            /// Property for Calculated G18
            /// </summary>
            public const string CalG18 = "CALG18";

            /// <summary>
            /// Property for Plus OR Minus G18
            /// </summary>
            public const string PMG18 = "PMG18";

            /// <summary>
            /// Property for Calculated W1 
            /// </summary>
            public const string CalW1 = "CALW1";

            /// <summary>
            /// Property for Plus OR Minus W1
            /// </summary>
            public const string PMW1 = "PMW1";

            /// <summary>
            /// Property for Calculated W2
            /// </summary>
            public const string CalW2 = "CALW2";

            /// <summary>
            /// Property for Plus OR Minus W2
            /// </summary>
            public const string PMW2 = "PMW2";

            /// <summary>
            /// Property for Calculated W4
            /// </summary>
            public const string CalW4 = "CALW4";

            /// <summary>
            /// Property for Plus OR Minus W4
            /// </summary>
            public const string PMW4 = "PMW4";

            /// <summary>
            /// Property for Calculated W3
            /// </summary>
            public const string CalW3 = "CALW3";

            /// <summary>
            /// Property for Plus OR Minus W3
            /// </summary>
            public const string PMW3 = "PMW3";

            /// <summary>
            /// Property for Calculated 5B
            /// </summary>
            public const string Cal5B = "CAL5B";

            /// <summary>
            /// Property for Plus OR Minus 5B
            /// </summary>
            public const string PM5B = "PM5B";

            /// <summary>
            /// Property for Calculated 7
            /// </summary>
            public const string Cal7 = "CAL7";

            /// <summary>
            /// Property for TPlus OR Minus 7
            /// </summary>
            public const string PM7 = "PM7";

            /// <summary>
            /// Property for Total T7
            /// </summary>
            public const string TotT7 = "TOTT7";

            /// <summary>
            /// Property for Total T8
            /// </summary>
            public const string TotT8 = "TOTT8";

            /// <summary>
            /// Property for Total T9
            /// </summary>
            public const string TotT9 = "TOTT9";

            /// <summary>
            /// Property for T4 Reason code for variation
            /// </summary>
            public const string ReasonT4 = "REASONT4";

            /// <summary>
            /// Property for JSON Audit File Name
            /// </summary>
            public const string JsonFile = "JSONFILE";

            /// <summary>
            /// Property for Total G1
            /// </summary>
            public const string TotG1 = "TOTG1";

            /// <summary>
            /// Property for Total G2
            /// </summary>
            public const string TotG2 = "TOTG2";

            /// <summary>
            /// Property for Total G3
            /// </summary>
            public const string TotG3 = "TOTG3";

            /// <summary>
            /// Property for Total G4
            /// </summary>
            public const string TotG4 = "TOTG4";

            /// <summary>
            /// Property for Total G7
            /// </summary>
            public const string TotG7 = "TOTG7";

            /// <summary>
            /// Property for Total G10
            /// </summary>
            public const string TotG10 = "TOTG10";

            /// <summary>
            /// Property for Total G11
            /// </summary>
            public const string TotG11 = "TOTG11";

            /// <summary>
            /// Property for Total G13
            /// </summary>
            public const string TotG13 = "TOTG13";

            /// <summary>
            /// Property for Total G14
            /// </summary>
            public const string TotG14 = "TOTG14";

            /// <summary>
            /// Property for JTotal G15
            /// </summary>
            public const string TotG15 = "TOTG15";

            /// <summary>
            /// Property for Total G18
            /// </summary>
            public const string TotG18 = "TOTG18";

            /// <summary>
            /// Property for Total W1
            /// </summary>
            public const string TotW1 = "TOTW1";

            /// <summary>
            /// Property for Total W2
            /// </summary>
            public const string TotW2 = "TOTW2";

            /// <summary>
            /// Property for Total W4
            /// </summary>
            public const string TotW4 = "TOTW4";

            /// <summary>
            /// Property for Total W3
            /// </summary>
            public const string TotW3 = "TOTW3";

            /// <summary>
            /// Property for Total 5B
            /// </summary>
            public const string Tot5B = "TOT5B";

            /// <summary>
            /// Property for Total 7
            /// </summary>
            public const string Tot7 = "TOT7";

            /// <summary>
            /// Property for Total G5
            /// </summary>
            public const string TotG5 = "TOTG5";

            /// <summary>
            /// Property for Total G6
            /// </summary>
            public const string TotG6 = "TOTG6";

            /// <summary>
            /// Property for Total G8
            /// </summary>
            public const string TotG8 = "TOTG8";

            /// <summary>
            /// Property for Total G9
            /// </summary>
            public const string TotG9 = "TOTG9";

            /// <summary>
            /// Property for Total G12
            /// </summary>
            public const string TotG12 = "TOTG12";

            /// <summary>
            /// Property for Total G16
            /// </summary>
            public const string TotG16 = "TOTG16";

            /// <summary>
            /// Property for Total G17
            /// </summary>
            public const string TotG17 = "TOTG17";

            /// <summary>
            /// Property for Total G19
            /// </summary>
            public const string TotG19 = "TOTG19";

            /// <summary>
            /// Property for Total G20
            /// </summary>
            public const string TotG20 = "TOTG20";

            /// <summary>
            /// Property for Total W5
            /// </summary>
            public const string TotW5 = "TOTW5";

            /// <summary>
            /// Property for Total 1A
            /// </summary>
            public const string Tot1A = "TOT1A";

            /// <summary>
            /// Property for Total 1B
            /// </summary>
            public const string Tot1B = "TOT1B";

            /// <summary>
            /// Property for Total 4
            /// </summary>
            public const string Tot4 = "TOT4";

            /// <summary>
            /// Property for Total 5A
            /// </summary>
            public const string Tot5A = "TOT5A";

            /// <summary>
            /// Property for Total 8A
            /// </summary>
            public const string Tot8A = "TOT8A";

            /// <summary>
            /// Property for Total 8B
            /// </summary>
            public const string Tot8B = "TOT8B";

            /// <summary>
            /// Property for Is 8A Moe than 8B 
            /// </summary>
            public const string AGTB = "AGTB";

            /// <summary>
            /// Property for Total 9
            /// </summary>
            public const string Tot9 = "TOT9";

            #endregion
        }

        
    }
}