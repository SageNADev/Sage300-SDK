/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TW.Models
{
    /// <summary>
    /// Contains list of Australia GST Configuration Header Constants 
    /// </summary>
    public partial class TwBoxH
    {
        public static class Constants
        {
            /// <summary>
            /// View Name
            /// </summary>
            public const string EntityName = "TW0300";
        }

        /// <summary>
        /// Contains list of Australia GST Configuration Header Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Box Number 
            /// </summary>
            public const string Box = "BOX";

            /// <summary>
            /// Property for Number Of Details
            /// </summary>
            public const string NumDetail = "NUMDETWIL";

            /// <summary>
            /// Property for Transaction Type 
            /// </summary>
            public const string TType = "TTYPE";

            #endregion
        }

        /// <summary>
        /// Contains list of Australia GST Configuration Header Index Constants
        /// </summary>
        public class Index
        {
            #region Indexes

            /// <summary>
            /// Index for Box Number 
            /// </summary>
            public const int Box = 1;

            /// <summary>
            /// Property for Number Of Details
            /// </summary>
            public const int NumDetail = 2;

            /// <summary>
            /// Index for Transaction Type 
            /// </summary>
            public const int TType = 20;

            #endregion
        }
    }
}