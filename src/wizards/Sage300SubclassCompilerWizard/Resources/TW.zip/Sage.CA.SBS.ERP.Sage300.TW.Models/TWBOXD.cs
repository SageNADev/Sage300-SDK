﻿/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

#region Imports
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TW.Models.Enums;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.TW.Models
{
    public partial class TwBoxD : ModelBase
    {
        public static class Constants
        {
            /// <summary>
            /// View Name
            /// </summary>
            public const string EntityName = "TW0200";
        }

        /// <summary>
        /// Gets or sets BoxNumber
        /// </summary>
        [Key]
        public int BoxNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailLineNumber
        /// </summary>
        [Key]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets FromGLOrTX
        /// </summary>
        public FromType From { get; set; }

        /// <summary>
        /// Gets or sets GLAccountNumber
        /// </summary>
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority
        /// </summary>
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets CustomerVendorTaxClass
        /// </summary>
        public int BuyerTaxClass { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClass
        /// </summary>
        public int ItemTaxClass { get; set; }
    }
}
