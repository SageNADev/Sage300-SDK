﻿using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;

namespace Sage.CA.SBS.ERP.Sage300.TW.Models
{
    public class TwGBasReport : ReportBase
    {
        public const string ReportGuid = "1ddeb9ad-8246-4f8e-8e4c-915be3879488";

        public TwGBasReport()
        {
        }
        public string FromYear { get; set; }
        public int FromPeriod { get; set; }
        public string ToYear { get; set; }
        public int ToPeriod { get; set; }
        public decimal TotT7 { get; set; }
        public decimal TotT8 { get; set; }
        public decimal TotT9 { get; set; }
        public string ReasonT4 { get; set; }
        public string JsonFile { get; set; }
        public decimal TotG1 { get; set; }
        public decimal TotG2 { get; set; }
        public decimal TotG3 { get; set; }
        public decimal TotG4 { get; set; }
        public decimal TotG7 { get; set; }
        public decimal TotG10 { get; set; }
        public decimal TotG11 { get; set; }
        public decimal TotG13 { get; set; }
        public decimal TotG14 { get; set; }
        public decimal TotG15 { get; set; }
        public decimal TotG18 { get; set; }
        public decimal TotW1 { get; set; }
        public decimal TotW2 { get; set; }
        public decimal TotW4 { get; set; }
        public decimal TotW3 { get; set; }
        public decimal Tot5B { get; set; }
        public decimal Tot7 { get; set; }
        public decimal TotG5 { get; set; }
        public decimal TotG6 { get; set; }
        public decimal TotG8 { get; set; }
        public decimal TotG9 { get; set; }
        public decimal TotG12 { get; set; }
        public decimal TotG16 { get; set; }
        public decimal TotG17 { get; set; }
        public decimal TotG19 { get; set; }
        public decimal TotG20 { get; set; }
        public decimal TotW5 { get; set; }
        public decimal Tot1A { get; set; }
        public decimal Tot1B { get; set; }
        public decimal Tot4 { get; set; }
        public decimal Tot5A { get; set; }
        public decimal Tot8A { get; set; }
        public decimal Tot8B { get; set; }
        public bool AGTB { get; set; }
        public decimal Tot9 { get; set; }
    }
}
