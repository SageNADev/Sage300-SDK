﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    ///  Contains list of properties for Data Integrity
    /// </summary>
    public partial class DataIntegrityReport : ReportBase
    {
        /// <summary>
        /// Gets or sets the log file path
        /// </summary>
        public string ErrorLogFile { get; set; }
    }
}