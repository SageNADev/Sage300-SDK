﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    public partial class CustomPackage : ModelBase
    {
        public CustomPackage()
        {
            CustomScreens = new List<CustomScreen>();
            AssignCompanys = new List<string>();
        }
        /// <summary>
        /// Get or set PackageID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string PackageId { get; set; }

        /// <summary>
        /// Get or set pakage version
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(18, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Version { get; set; }

        /// <summary>
        /// Get or set vendor name
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Vendor { get; set; }

        /// <summary>
        /// Get or set pakage description
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Description { get; set; }
        
        /// <summary>
        /// Get or set package list screens 
        /// </summary>
        public IList<CustomScreen> CustomScreens { get; set; }
        
        /// <summary>
        /// Get or set package assign companys
        /// </summary>
        public IList<string> AssignCompanys { get; set; }
    }
}
