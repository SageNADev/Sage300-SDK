﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;


namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    public partial class CustomAssign : ModelBase
    {
        /// <summary>
        /// Get or set packageID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string PackageId { get; set; }


        /// <summary>
        /// Get or set screenID
        /// </summary>
        [Key]
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ScreenId { get; set; }

        /// <summary>
        /// Get or set company Id
        /// </summary>
        [Key]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CompanyId { get; set; }
        
        /// <summary>
        /// Get or set Company Name
        /// </summary>
        public string Company { get; set; }

        /// <summary>
        /// Get or set screen priority
        /// </summary>
        public int Priority { get; set; }

        /// <summary>
        /// Get or set screen status
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// Get or set Screen Module
        /// </summary>
        public string Module { get; set; }

    }
}
