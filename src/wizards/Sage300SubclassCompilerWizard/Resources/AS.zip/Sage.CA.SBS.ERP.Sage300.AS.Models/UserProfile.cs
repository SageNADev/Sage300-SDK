// Copyright © 2019 Sage Software, Inc

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;

using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Partial class for UserProfile
    /// </summary>
    public partial class UserProfile : ModelBase
    {
        /// <summary>
        /// Gets or sets UserID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof (UserProfileResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [GridInfo(1, typeof(UserProfileResx), "UserID", editorType: GridEditorEnum.Finder, FinderName = "user", FinderPostbackNotRequired = true, Style = "w150")]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets CompanyID - note that the client side does not need to set
        /// this property.  The underlying logic will always use the company ID of
        /// the currently logged in user.  We only need this property in place so that
        /// we can create the filter for the business repository.
        /// </summary>
        [Key]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompanyID", ResourceType = typeof (UserProfileResx))]
        [ViewField(Name = Fields.CompanyID, Id = Index.CompanyID, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CompanyID { get; set; }

        /// <summary>
        /// Gets or sets ProfileID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProfileID", ResourceType = typeof (UserProfileResx))]
        [ViewField(Name = Fields.ProfileID, Id = Index.ProfileID, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-20N")]
        public string ProfileID { get; set; }

        /// <summary>
        /// Gets the user name associated with the user ID
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserName", ResourceType = typeof(UserProfileResx))]
        [GridInfo(2, typeof(UserProfileResx), "UserName", Style = "")]
        public string UserName  { get; set; }
      
    }
}
