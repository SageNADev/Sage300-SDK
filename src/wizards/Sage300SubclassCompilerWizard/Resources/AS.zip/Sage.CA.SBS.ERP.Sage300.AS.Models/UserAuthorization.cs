// /* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AS.Resources;
using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
	/// <summary>
	/// User Authorization Model
	/// </summary>
	public partial class UserAuthorization : ModelBase
	{
		/// <summary>
		/// Default Constructor
		/// </summary>
		public UserAuthorization()
		{
			OperationMode = OperationMode.None;
		}

		/// <summary>
		/// Gets or sets UserID
		/// </summary>
		/// <value>The user identifier.</value>
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
		[StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
		[Display(Name = "UserID", ResourceType = typeof (UserAuthorizationsResx))]
		[RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric",
			ErrorMessageResourceType = typeof (AnnotationsResx))]
		[Key]
		[ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
		public string UserID { get; set; }

		/// <summary>
		/// Gets or sets CompanyID
		/// </summary>
		/// <value>The company identifier.</value>
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
		[StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
		[Display(Name = "CompanyId", ResourceType = typeof(ASCommonResx))]
		[Key]
		[ViewField(Name = Fields.CompanyID, Id = Index.CompanyID, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string CompanyID { get; set; }

		/// <summary>
		/// Gets or sets ProgramID
		/// </summary>
		/// <value>The program identifier.</value>
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
		[StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
		[Display(Name = "ProgramId", ResourceType = typeof(SecurityGroupsResx))]
		[Key]
		[ViewField(Name = Fields.ProgramID, Id = Index.ProgramID, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string ProgramID { get; set; }

		/// <summary>
		/// Gets or sets GroupID
		/// </summary>
		/// <value>The group identifier.</value>
		[StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
		[Display(Name = "GridASAUTHColIDCap", ResourceType = typeof(UserAuthorizationsResx))]
		[RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric",
			ErrorMessageResourceType = typeof (AnnotationsResx))]
		[ViewField(Name = Fields.GroupID, Id = Index.GroupID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
		public string GroupID { get; set; }

		/// <summary>
		/// Group Description
		/// </summary>
		[Display(Name = "GridASAUTHColDescCap", ResourceType = typeof(UserAuthorizationsResx))]
		public string GroupDescription { get; set; }

		/// <summary>
		/// Gets or sets the operation mode.
		/// </summary>
		/// <value>The operation mode.</value>
		public OperationMode OperationMode { get; set; }

		/// <summary>
		/// Program Name
		/// </summary>
		[Display(Name = "GridASAUTHColAppCap", ResourceType = typeof(UserAuthorizationsResx))]
		public string ProgramName { get; set; }

		/// <summary>
		/// Program Version
		/// </summary>
		public string ProgramVersion { get; set; }

		/// <summary>
		/// Gets or sets the whether Security Group exists
		/// </summary>
		public bool SecurityGroupExists { get; set; }
	}
}
