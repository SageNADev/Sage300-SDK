﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AS.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models.Enums
{
    /// <summary>
    /// Enum AccountStatusEnum
    /// </summary>
    public enum AccountStatus
    {
        /// <summary>
        /// The active
        /// </summary> CommonResx
        [EnumValue("Active", typeof(CommonResx))]
        Active = 0,

        /// <summary>
        /// The inactive
        /// </summary>
        [EnumValue("Inactive", typeof(CommonResx))]
        Inactive = 1,
    }
}