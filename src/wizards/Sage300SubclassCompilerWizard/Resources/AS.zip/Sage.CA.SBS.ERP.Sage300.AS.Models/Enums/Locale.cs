﻿/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

#region Imports
using Sage.CA.SBS.ERP.Sage300.AS.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models.Enums
{
    /// <summary>
    /// Enum Locale
    /// </summary>
    public enum Locale
    {
        /// <summary>
        /// English [en]
        /// </summary>
        [Description("ENG|en")]
        English = 0,

        /// <summary>
        /// English (United States) [en-US]
        /// </summary>
        [Description("ENG|en-US")]
        EnglishUnitedStates = 1, 

        /// <summary>
        /// English (Canada) [en-CA]
        /// </summary>
        [Description("ENG|en-CA")]
        EnglishCanada = 2, 

        /// <summary>
        /// English (Australia) [en-AU]
        /// </summary>
        [Description("ENG|en-AU")]
        EnglishAustralia = 3, 

        /// <summary>
        /// English (South Africa) [en-ZA]
        /// </summary>
        [Description("ENG|en-ZA")]
        EnglishSouthAfrica = 4, 

        /// <summary>
        /// Chinese Simplified (China) [zh-CN]
        /// </summary>
        [Description("CHN|zh-CN")]
        ChineseSimplifiedChina = 5, 

        /// <summary>
        /// Chinese Simplified (Singapore) [zh-SG]
        /// </summary>
        [Description("CHN|zh-SG")]
        ChineseSimplifiedSingapore = 6,

        /// <summary>
        /// Chinese Simplified (Hong Kong) [zh-HK]
        /// </summary>
        [Description("CHT|zh-HK")]
        ChineseTraditionalHongKong = 7, 

        /// <summary>
        /// Chinese Traditional (Taiwan) [zh-TW]
        /// </summary>
        [Description("CHT|zh-TW")]
        ChineseTraditionalTaiwan = 8, 

        /// <summary>
        /// Spanish [es]
        /// </summary>
        [Description("ESN|es")]
        Spanish = 9, 

        /// <summary>
        /// Spanish (Spain) [es-ES]
        /// </summary>
        [Description("ESN|es-ES")]
        SpanishSpain = 10, 

        /// <summary>
        /// French (Canada) [fr-CA]
        /// </summary>
        [Description("FRA|fr-CA")]
        FrenchCanada = 11, 
    }
}
