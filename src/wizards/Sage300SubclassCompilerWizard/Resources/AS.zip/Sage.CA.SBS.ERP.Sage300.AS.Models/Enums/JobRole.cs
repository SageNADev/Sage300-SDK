﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Imports
using Sage.CA.SBS.ERP.Sage300.AS.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models.Enums
{
    /// <summary>
    /// Enum JobRole
    /// </summary>
    public enum JobRole
    {
        /// <summary>
        /// The selectyourjobrole
        /// </summary>
        [EnumValue("Role_Selectyourjobrole", typeof(EnumerationsResx))]
        Selectyourjobrole = 0,

        /// <summary>
        /// The owner or partner or principal or gm
        /// </summary>
        [EnumValue("Role_OwnerOrPartnerOrPrincipalOrGM", typeof(EnumerationsResx))]
        OwnerOrPartnerOrPrincipalOrGM = 1,

        /// <summary>
        /// The president or ceo
        /// </summary>
        [EnumValue("Role_PresidentOrCEO", typeof(EnumerationsResx))]
        PresidentOrCEO = 2,

        /// <summary>
        /// The cfo or v pof finance
        /// </summary>
        [EnumValue("Role_CFOOrVPofFinance", typeof(EnumerationsResx))]
        CFOOrVPofFinance = 3,

        /// <summary>
        /// The director or senior manager
        /// </summary>
        [EnumValue("Role_DirectorOrSeniorManager", typeof(EnumerationsResx))]
        DirectorOrSeniorManager = 4,

        /// <summary>
        /// The accounting manager or controller
        /// </summary>
        [EnumValue("Role_AccountingManagerOrController", typeof(EnumerationsResx))]
        AccountingManagerOrController = 5,

        /// <summary>
        /// The accountant or bookkeeper or clerk
        /// </summary>
        [EnumValue("Role_AccountantOrBookkeeperOrClerk", typeof(EnumerationsResx))]
        AccountantOrBookkeeperOrClerk = 6,

        /// <summary>
        /// The admin assistant or office manager
        /// </summary>
        [EnumValue("Role_AdminAssistantOrOfficeManager", typeof(EnumerationsResx))]
        AdminAssistantOrOfficeManager = 7,

        /// <summary>
        /// The operations or warehouse associate
        /// </summary>
        [EnumValue("Role_OperationsOrWarehouseAssociate", typeof(EnumerationsResx))]
        OperationsOrWarehouseAssociate = 8,

        /// <summary>
        /// The salesperson
        /// </summary>
        [EnumValue("Role_Salesperson", typeof(EnumerationsResx))]
        Salesperson = 9,

        /// <summary>
        /// The marketing analyst
        /// </summary>
        [EnumValue("Role_MarketingAnalyst", typeof(EnumerationsResx))]
        MarketingAnalyst = 10,

        /// <summary>
        /// The customer service associate
        /// </summary>
        [EnumValue("Role_CustomerServiceAssociate", typeof(EnumerationsResx))]
        CustomerServiceAssociate = 11,

        /// <summary>
        /// The consultant
        /// </summary>
        [EnumValue("Role_Consultant", typeof(EnumerationsResx))]
        Consultant = 12,

        /// <summary>
        /// The hr or payroll administrator
        /// </summary>
        [EnumValue("Role_HROrPayrollAdministrator", typeof(EnumerationsResx))]
        HROrPayrollAdministrator = 13,

        /// <summary>
        /// It analyst
        /// </summary>
        [EnumValue("Role_ITAnalyst", typeof(EnumerationsResx))]
        ITAnalyst = 14,

        /// <summary>
        /// The other
        /// </summary>
        [EnumValue("Role_Other", typeof(EnumerationsResx))]
        Other = 15,
    }
}