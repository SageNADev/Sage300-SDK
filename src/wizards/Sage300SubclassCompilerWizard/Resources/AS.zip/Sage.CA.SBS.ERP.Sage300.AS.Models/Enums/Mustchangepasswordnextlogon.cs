﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models.Enums
{
    /// <summary>
    /// Enum MustChangePasswordNextLogon
    /// </summary>
    public enum MustChangePasswordNextLogon
    {
        /// <summary>
        /// The no
        /// </summary> Yes
        [EnumValue("No", typeof(CommonResx))]
        No = 0,

        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("Yes", typeof(CommonResx))]
        Yes = 1,
    }
}