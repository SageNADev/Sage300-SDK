﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AS.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models.Enums
{
    /// <summary>
    /// Enum AuthenticationMethod
    /// </summary>
    public enum AuthenticationMethod
    {
        /// <summary>
        /// The sage300 erp
        /// </summary>
        [EnumValue("AuthenticationMethod_Sage300ERP", typeof(EnumerationsResx))]
        Sage300ERP = 1,

        /// <summary>
        /// The windows
        /// </summary>
        [EnumValue("AuthenticationMethod_Windows", typeof(EnumerationsResx))]
        Windows = 2,

        /// <summary>
        /// The both
        /// </summary>
        [EnumValue("AuthenticationMethod_Both", typeof(EnumerationsResx))]
        Both = 3,
    }
}