﻿/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

#region Imports
using Sage.CA.SBS.ERP.Sage300.AS.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models.Enums
{
    /// <summary>
    /// Enum Language
    /// </summary>
    public enum Language
    {
        /// <summary>
        /// English
        /// </summary>
        [EnumValue("Language_English", typeof(EnumerationsResx))]
        English = 0,

        /// <summary>
        /// English (United States)
        /// </summary>
        [EnumValue("Language_EnglishUnitedStates", typeof(EnumerationsResx))]
        EnglishUnitedStates = 1,

        /// <summary>
        /// English (Canada)
        /// </summary>
        [EnumValue("Language_EnglishCanada", typeof(EnumerationsResx))]
        EnglishCanada= 2,

        /// <summary>
        /// English (Australia)
        /// </summary>
        [EnumValue("Language_EnglishAustralia", typeof(EnumerationsResx))]
        EnglishAustralia = 3,

        /// <summary>
        /// English (South Africa)
        /// </summary>
        [EnumValue("Language_EnglishSouthAfrica", typeof(EnumerationsResx))]
        EnglishSouthAfrica = 4,

        /// <summary>
        /// Chinese Simplified (China)
        /// </summary>
        [EnumValue("Language_ChineseSimplifiedChina", typeof(EnumerationsResx))]
        ChineseSimplifiedChina = 5,

        /// <summary>
        /// Chinese Simplified (Singapore)
        /// </summary>
        [EnumValue("Language_ChineseSimplifiedSingapore", typeof(EnumerationsResx))]
        ChineseSimplifiedSingapore = 6,

        /// <summary>
        /// Chinese Simplified (Hong Kong)
        /// </summary>
        [EnumValue("Language_ChineseTraditionalHongKong", typeof(EnumerationsResx))]
        ChineseTraditionalHongKong = 7,

        /// <summary>
        /// Chinese Traditional (Taiwan)
        /// </summary>
        [EnumValue("Language_ChineseTraditionalTaiwan", typeof(EnumerationsResx))]
        ChineseTraditionalTaiwan = 8,

        /// <summary>
        /// Spanish
        /// </summary>
        [EnumValue("Language_Spanish", typeof(EnumerationsResx))]
        Spanish = 9,

        /// <summary>
        /// Spanish (Spain)
        /// </summary>
        [EnumValue("Language_SpanishSpain", typeof(EnumerationsResx))]
        SpanishSpain= 10,

        /// <summary>
        /// French (Canada)
        /// </summary>
        [EnumValue("Language_FrenchCanada", typeof(EnumerationsResx))]
        FrenchCanada = 11,
    }
}
