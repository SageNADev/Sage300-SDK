﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AS.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models.Enums
{
    /// <summary>
    /// Enum AccountType
    /// </summary>
    public enum AccountType
    {
        /// <summary>
        /// The user
        /// </summary>
        [EnumValue("AccountType_User", typeof(EnumerationsResx))]
        User = 0,

        /// <summary>
        /// The timecard
        /// </summary>
        [EnumValue("AccountType_Timecard", typeof(EnumerationsResx))]
        Timecard = 2,
    }
}