// Copyright © 2016 Sage Software, Inc

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Customization;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Partial class for UICustomization
    /// </summary>
    public partial class UICustomization : ModelBase
    {
        /// <summary>
        /// Gets or sets ScreenID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ScreenID", ResourceType = typeof (UICustomizationResx))]
        [ViewField(Name = Fields.ScreenID, Id = Index.ScreenID, FieldType = EntityFieldType.Char, Size = 36, Mask = "%-36N")]
        public string ScreenID { get; set; }

        /// <summary>
        /// Gets or sets CustomizationID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomizationID", ResourceType = typeof (UICustomizationResx))]
        [ViewField(Name = Fields.CustomizationID, Id = Index.CustomizationID, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-20N")]
        public string CustomizationID { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (UICustomizationResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 255)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets DataSize
        /// </summary>
        [Display(Name = "DataSize", ResourceType = typeof (UICustomizationResx))]
        [ViewField(Name = Fields.DataSize, Id = Index.DataSize, FieldType = EntityFieldType.Long, Size = 4)]
        public long DataSize { get; set; }

        /// <summary>
        /// Gets or sets NumberOfParts
        /// </summary>
        [Display(Name = "NumberOfParts", ResourceType = typeof (UICustomizationResx))]
        [ViewField(Name = Fields.NumberOfParts, Id = Index.NumberOfParts, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfParts { get; set; }

        /// <summary>
        /// Gets or sets UI Profiles
        /// </summary>
        [Display(Name = "UIProfiles", ResourceType = typeof(CommonResx))]
        public List<string> UIProfiles { get; set; }

        [Display(Name = "CustomizationDetail", ResourceType = typeof(UICustomizationResx))]
        public List<Control> CustomizationDetail { get; set; }
        #region UI Strings


        #endregion
    }
}
