/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

#region Imports
using Sage.CA.SBS.ERP.Sage300.AS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using ASResources = Sage.CA.SBS.ERP.Sage300.AS.Resources;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Class Users.
    /// </summary>
    public partial class User : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the User
        /// </summary>
        public User()
        {
            UserAuthorizations = new EnumerableResponse<UserAuthorization>
            {
                Items = new List<UserAuthorization>(),
                TotalResultsCount = 0
            };
            TotalActiveApplication = 0;
        }
        
        /// <summary>
        /// Gets or sets UserID
        /// </summary>
        /// <value>The user identifier.</value>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof(UserAuthorizationsResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets UserName
        /// </summary>
        /// <value>The name of the user.</value>
        [Display(Name = "UserName", ResourceType = typeof(UsersResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.UserName, Id = Index.UserName, FieldType = EntityFieldType.Char, Size = 60)]
        public string UserName { get; set; }

        /// <summary>
        /// Gets or sets Password
        /// </summary>
        /// <value>The password.</value>
        [Display(Name = "Password", ResourceType = typeof(ASResources.ASCommonResx))]
        [ViewField(Name = Fields.Password, Id = Index.Password, FieldType = EntityFieldType.Byte, Size = 64, Mask = "%-64c")]
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets the PasswordVerify field
        /// </summary>
        [Display(Name = "Verify", ResourceType = typeof(ASResources.ASCommonResx))]
        [Compare("Password", ErrorMessageResourceName = "PasswordsDoNotMatch", ErrorMessageResourceType = typeof(ASResources.ASCommonResx))]
        public string PasswordVerify { get; set; }

        /// <summary>
        /// Gets or sets AccountType
        /// </summary>
        /// <value>The type of the account.</value>
        [Display(Name = "AccountType", ResourceType = typeof(UsersResx))]
        [ViewField(Name = Fields.AccountType, Id = Index.AccountType, FieldType = EntityFieldType.Int, Size = 2)]
        public AccountType AccountType { get; set; }

        /// <summary>
        /// Gets or sets Account Status
        /// </summary>
        /// <value>The account status.</value>
        [ViewField(Name = Fields.AccountStatus, Id = Index.AccountStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public AccountStatus AccountStatus { get; set; }

        /// <summary>
        /// Gets or sets LanguageCode
        /// </summary>
        /// <value>The language code.</value>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.LanguageCode, Id = Index.LanguageCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3A")]
        public string LanguageCode { get; set; }

        /// <summary>
        /// Gets or sets Language
        /// </summary>
        /// <value>The language.</value>
        [Display(Name = "Language", ResourceType = typeof(UsersResx))]
        [ViewField(Name = Fields.Language, Id = Index.Language, FieldType = EntityFieldType.Int, Size = 2)]
        public int Language { get; set; }

        /// <summary>
        /// Gets or sets LocaleId
        /// </summary>
        [ViewField(Name = Fields.LocaleId, Id = Index.LocaleId, FieldType = EntityFieldType.Char, Size = 50)]
        public string LocaleId { get; set; }

        /// <summary>
        /// Gets or sets Locale
        /// </summary>
        [Display(Name = "Language", ResourceType = typeof(UsersResx))]
        [ViewField(Name = Fields.Locale, Id = Index.Locale, FieldType = EntityFieldType.Int, Size = 2)]
        public int Locale { get; set; }

        /// <summary>
        /// Gets or sets ReserveLanPakLicense
        /// </summary>
        /// <value>The ReserveLanPakLicense.</value>
        [Display(Name = "ReserveLanPakLicense", ResourceType = typeof(UsersResx))]
        public bool ReserveLanPakLicense { get; set; }


        /// <summary>
        /// Gets or sets MustChangePasswordNextLogon
        /// </summary>
        /// <value>The MustChangePasswordNextLogon.</value>
        [Display(Name = "MustChangePasswordNextLogon", ResourceType = typeof(UsersResx))]
        public bool MustChangePasswordNextLogon { get; set; }

        /// <summary>
        /// Gets or sets UserCannotChangePassword
        /// </summary>
        /// <value>The UserCannotChangePassword.</value>
        [Display(Name = "UserCannotChangePassword", ResourceType = typeof(UsersResx))]
        public bool UserCannotChangePassword { get; set; }

        /// <summary>
        /// Gets or sets PasswordNeverExpires
        /// </summary>
        /// <value>The PasswordNeverExpires.</value>
        [Display(Name = "PasswordNeverExpires", ResourceType = typeof(UsersResx))]
        public bool PasswordNeverExpires { get; set; }

        /// <summary>
        /// Gets or sets AccountIsDisabled
        /// </summary>
        /// <value>The AccountIsDisabled.</value>
        [Display(Name = "AccountIsDisabled", ResourceType = typeof(UsersResx))]
        public bool AccountIsDisabled { get; set; }

        /// <summary>
        /// Gets or sets AccountIsLockedOut
        /// </summary>
        /// <value>The AccountIsLockedOut.</value>
        [Display(Name = "AccountIsLockedOut", ResourceType = typeof(UsersResx))]
        public bool AccountIsLockedOut { get; set; }

        /// <summary>
        /// Gets or sets AccountIsRestricted
        /// </summary>
        /// <value>The AccountIsRestricted.</value>
        [Display(Name = "AccountIsRestricted", ResourceType = typeof(UsersResx))]
        public bool AccountIsRestricted { get; set; }

        /// <summary>
        /// Gets or sets Monday
        /// </summary>
        /// <value>The monday.</value>
        [Display(Name = "Weekday_Monday", ResourceType = typeof(ASResources.EnumerationsResx))]
        [ViewField(Name = Fields.Monday, Id = Index.Monday, FieldType = EntityFieldType.Long, Size = 4)]
        public bool Monday { get; set; }

        /// <summary>
        /// Gets or sets Tuesday
        /// </summary>
        /// <value>The tuesday.</value>
        [Display(Name = "Weekday_Tuesday", ResourceType = typeof(ASResources.EnumerationsResx))]
        [ViewField(Name = Fields.Tuesday, Id = Index.Tuesday, FieldType = EntityFieldType.Long, Size = 4)]
        public bool Tuesday { get; set; }

        /// <summary>
        /// Gets or sets Wednesday
        /// </summary>
        /// <value>The wednesday.</value>
        [Display(Name = "Weekday_Wednesday", ResourceType = typeof(ASResources.EnumerationsResx))]
        [ViewField(Name = Fields.Wednesday, Id = Index.Wednesday, FieldType = EntityFieldType.Long, Size = 4)]
        public bool Wednesday { get; set; }

        /// <summary>
        /// Gets or sets Thursday
        /// </summary>
        /// <value>The thursday.</value>
        [Display(Name = "Weekday_Thursday", ResourceType = typeof(ASResources.EnumerationsResx))]
        [ViewField(Name = Fields.Thursday, Id = Index.Thursday, FieldType = EntityFieldType.Long, Size = 4)]
        public bool Thursday { get; set; }

        /// <summary>
        /// Gets or sets Friday
        /// </summary>
        /// <value>The friday.</value>
        [Display(Name = "Weekday_Friday", ResourceType = typeof(ASResources.EnumerationsResx))]
        [ViewField(Name = Fields.Friday, Id = Index.Friday, FieldType = EntityFieldType.Long, Size = 4)]
        public bool Friday { get; set; }

        /// <summary>
        /// Gets or sets Saturday
        /// </summary>
        /// <value>The saturday.</value>
        [Display(Name = "Weekday_Saturday", ResourceType = typeof(ASResources.EnumerationsResx))]
        [ViewField(Name = Fields.Saturday, Id = Index.Saturday, FieldType = EntityFieldType.Long, Size = 4)]
        public bool Saturday { get; set; }

        /// <summary>
        /// Gets or sets Sunday
        /// </summary>
        /// <value>The sunday.</value>
        [Display(Name = "Weekday_Sunday", ResourceType = typeof(ASResources.EnumerationsResx))]
        [ViewField(Name = Fields.Sunday, Id = Index.Sunday, FieldType = EntityFieldType.Long, Size = 4)]
        public bool Sunday { get; set; }

        /// <summary>
        /// Gets or sets Time Begin
        /// </summary>
        /// <value>The Time Begin.</value>
        public DateTime TimeBegin { get; set; }

        /// <summary>
        /// Gets the time part from the Time begin Property
        /// </summary>
        public TimeSpan TimeBeginTimeSpan
        {
            get
            {
                TimeSpan ts = TimeBegin.TimeOfDay;
                return ts;
            }
        }

        /// <summary>
        /// Gets or sets TimeEnd
        /// </summary>
        /// <value>The TimeEnd.</value>
        public DateTime TimeEnd { get; set; }

        /// <summary>
        /// Gets the time part from the Time end Property
        /// </summary>
        public TimeSpan TimeEndTimeSpan
        {
            get
            {
                TimeSpan ts = TimeEnd.TimeOfDay;
                return ts;
            }
        }

        /// <summary>
        /// Gets or sets AuthenticationMethod
        /// </summary>
        /// <value>The authentication method.</value>
        [Display(Name = "AuthenticationMethod", ResourceType = typeof(UsersResx))]
        [ViewField(Name = Fields.AuthenticationMethod, Id = Index.AuthenticationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public AuthenticationMethod AuthenticationMethod { get; set; }

        /// <summary>
        /// Gets or sets WindowsDomain
        /// </summary>
        /// <value>The windows domain.</value>
        [Display(Name = "WindowsDomain", ResourceType = typeof(UsersResx))]
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.WindowsDomain, Id = Index.WindowsDomain, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15C")]
        public string WindowsDomain { get; set; }

        /// <summary>
        /// Gets or sets WindowsUserName
        /// </summary>
        /// <value>The name of the windows user.</value>
        [Display(Name = "WindowsUserName", ResourceType = typeof(UsersResx))]
        [StringLength(256, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.WindowsUserName, Id = Index.WindowsUserName, FieldType = EntityFieldType.Char, Size = 256, Mask = "%-256C")]
        public string WindowsUserName { get; set; }

        /// <summary>
        /// Gets or sets Phone
        /// </summary>
        /// <value>The phone.</value>
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Phone, Id = Index.Phone, FieldType = EntityFieldType.Char, Size = 30, Mask = "%-30c")]
        public string Phone { get; set; }

        /// <summary>
        /// Gets or sets Email1
        /// </summary>
        /// <value>The email1.</value>
        [Display(Name = "Email1", ResourceType = typeof(UsersResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Email1, Id = Index.Email1, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email1 { get; set; }

        /// <summary>
        /// Gets or sets Email2
        /// </summary>
        /// <value>The email2.</value>
        [Display(Name = "Email2", ResourceType = typeof(UsersResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Email2, Id = Index.Email2, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email2 { get; set; }

        /// <summary>
        /// Gets or sets JobRole
        /// </summary>
        /// <value>The job role.</value>
        [Display(Name = "JobRole", ResourceType = typeof(UsersResx))]
        [ViewField(Name = Fields.JobRole, Id = Index.JobRole, FieldType = EntityFieldType.Int, Size = 2)]
        public JobRole JobRole { get; set; }

        ///// <summary>
        ///// Gets or sets Job Role String
        ///// </summary>
        ///// <value>The type of the account.</value>
        public string JobRoleString
        {
            get { return EnumUtility.GetStringValue(JobRole); }
        }

        /// <summary>
        /// Gets or sets UserReceivesEmailFromSage
        /// </summary>
        /// <value>The UserReceivesEmailFromSage sage.</value>
        [Display(Name = "UserReceivesEmailFromSage", ResourceType = typeof(UsersResx))]
        public bool UserReceivesEmailFromSage { get; set; }

        /// <summary>
        /// List User Authorizations
        /// </summary>
        public EnumerableResponse<UserAuthorization> UserAuthorizations { get; set; }

        /// <summary>
        /// Total Active applications
        /// </summary>
        public int TotalActiveApplication { get; set; }

        /// <summary>
        /// Gets or sets whether user exists
        /// </summary>
        public bool Exists { get; set; }

        /// <summary>
        /// Gets or sets the Serial Number
        /// </summary>
        public int SerialNumber { get; set; }

        /// <summary>
        /// Office 365 Integration Account (Email Address)
        /// </summary>
        [Display(Name = "EmailAccount", ResourceType = typeof(UsersResx))]
        [ViewField(Name = Fields.O365UserName, Id = Index.O365UserName, FieldType = EntityFieldType.Char, Size = 50)]
        public string O365UserName { get; set; }
    }
}
