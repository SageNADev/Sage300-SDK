// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Application Security Resources Model
    /// </summary>
    public partial class ApplicationSecurityResources : ModelBase
    {
        /// <summary>
        /// Gets or sets ProgramID 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ProgramID, Id = Index.ProgramID, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ProgramID { get; set; }

        /// <summary>
        /// Gets or sets ProgramVersion 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ProgramVersion, Id = Index.ProgramVersion, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ProgramVersion { get; set; }

        /// <summary>
        /// Gets or sets ResourceID 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ResourceID, Id = Index.ResourceID, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10N")]
        public string ResourceID { get; set; }

        /// <summary>
        /// Gets or sets ResourceDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "LblAccessCap", ResourceType = typeof (SecurityGroupsResx))]
        [ViewField(Name = Fields.ResourceDescription, Id = Index.ResourceDescription, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-30N")]
        public string ResourceDescription { get; set; }
    }
}
