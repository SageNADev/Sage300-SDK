﻿/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

#region Imports
using Sage.CA.SBS.ERP.Sage300.AS.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models.Reports
{
    public partial class UserAuthorizationReport : ReportBase
    {
        #region Public Properties

        /// <summary>
        /// Gets or Sets FromUser
        /// </summary>
        [Display(Name = "FromUser", ResourceType = typeof(UserAuthorizationReportResx))]
        public string FromUser { get; set; }

        /// <summary>
        /// Gets or Sets ToUser
        /// </summary>
        [Display(Name = "ToUser", ResourceType = typeof(UserAuthorizationReportResx))]
        public string ToUser { get; set; }

        /// <summary>
        /// Gets or Sets Security Authorizations checkbox value
        /// </summary>
        [Display(Name = "SecurityAuthorizations", ResourceType = typeof(UserAuthorizationReportResx))]
        public bool SecurityAuthorizations { get; set; }

        /// <summary>
        /// Gets or Sets UI Profile Customizations checkbox value
        /// </summary>
        [Display(Name = "UIProfileCustomizations", ResourceType = typeof(UserAuthorizationReportResx))]
        public bool UIProfileCustomizations { get; set; }

        #endregion
    }
}
