// Copyright © 2016 Sage Software, Inc

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Partial class for WorkProfile
    /// </summary>
    public partial class WorkProfile : ModelBase
    {
        public WorkProfile()
        {
            UserList = new EnumerableResponse<UserProfile>();
            ReportList = new EnumerableResponse<ReportProfile>();
            CustomList = new EnumerableResponse<UICustomizationProfile>();
        }
        
        /// <summary>
        /// Gets or sets ProfileID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProfileID", ResourceType = typeof (WorkProfileResx))]
        [ViewField(Name = Fields.ProfileID, Id = Index.ProfileID, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-20N")]
        public string ProfileID { get; set; }

        /// <summary>
        /// Gets or sets ProfileDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProfileDescription", ResourceType = typeof (WorkProfileResx))]
        [ViewField(Name = Fields.ProfileDescription, Id = Index.ProfileDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ProfileDescription { get; set; }

        /// <summary>
        /// Gets or sets User Items for the profile - note that this list only contains one
        /// page of items (depending on which page the client-side asks for)
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<UserProfile> UserList { get; set; }

        /// <summary>
        /// Gets or sets Report Items for the profile - note that this list only contains one
        /// page of items (depending on which page the client-side asks for)
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReportProfile> ReportList { get; set; }

        /// <summary>
        /// Gets or sets UI Customization Items for the profile - note that this list only contains one
        /// page of items (depending on which page the client-side asks for)
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<UICustomizationProfile> CustomList { get; set; }
    }
}
