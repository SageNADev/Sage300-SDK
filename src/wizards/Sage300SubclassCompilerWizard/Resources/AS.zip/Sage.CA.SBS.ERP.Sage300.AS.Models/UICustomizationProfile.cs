// Copyright © 2016 Sage Software, Inc

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AS.Resources;
using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Partial class for UICustomizationProfile
    /// </summary>
    public partial class UICustomizationProfile : ModelBase
    {
        /// <summary>
        /// Gets or sets ProfileID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProfileID", ResourceType = typeof (UICustomizationProfileResx))]
        [ViewField(Name = Fields.ProfileID, Id = Index.ProfileID, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-20N")]
        public string ProfileID { get; set; }

        /// <summary>
        /// Gets or sets CompanyID - note that the client side does not need to set
        /// this property.  The underlying logic will always use the company ID of
        /// the currently logged in user.  We only need this property in place so that
        /// we can create the filter for the business repository.
        /// </summary>
        [Key]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompanyID", ResourceType = typeof(UICustomizationProfileResx))]
        [ViewField(Name = Fields.CompanyID, Id = Index.CompanyID, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CompanyID { get; set; }

        /// <summary>
        /// Gets or sets ScreenID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ScreenID", ResourceType = typeof (UICustomizationProfileResx))]
        [ViewField(Name = Fields.ScreenID, Id = Index.ScreenID, FieldType = EntityFieldType.Char, Size = 36, Mask = "%-36N")]
        public string ScreenID { get; set; }

        /// <summary>
        /// Gets or sets ScreenName
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ScreenName", ResourceType = typeof(UICustomizationProfileResx))]
        [GridInfo(1, typeof(UICustomizationProfileResx), "ScreenName", Style = "w150")]
        public string ScreenName { get; set; }

        /// <summary>
        /// Gets or sets CustomizationID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomizationID", ResourceType = typeof (UICustomizationProfileResx))]
        [GridInfo(2, typeof(UICustomizationProfileResx), "CustomizationID", Style = "w200")]
        [ViewField(Name = Fields.CustomizationID, Id = Index.CustomizationID, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-20N")]
        public string CustomizationID { get; set; }

        /// <summary>
        /// Gets the Customization Description associated with the Customization ID
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomizationDescription", ResourceType = typeof(UICustomizationProfileResx))]
        [GridInfo(3, typeof(UICustomizationProfileResx), "CustomizationDescription", Style = "")]
        public string CustomizationDescription { get; set; }

        #region UI Strings

        #endregion
    }
}
