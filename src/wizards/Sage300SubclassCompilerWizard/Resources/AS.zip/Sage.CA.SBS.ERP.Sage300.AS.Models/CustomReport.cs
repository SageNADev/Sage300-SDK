// Copyright © 2016 Sage Software, Inc

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Partial class for CustomReport
    /// </summary>
    public partial class CustomReport : ModelBase
    {
        /// <summary>
        /// Gets or sets ReportGUID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReportGUID", ResourceType = typeof (ASCustomReportResx))]
        [ViewField(Name = Fields.ReportGUID, Id = Index.ReportGUID, FieldType = EntityFieldType.Char, Size = 36)]
        public string ReportGUID { get; set; }

        /// <summary>
        /// Gets or sets ReportFilename
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReportFilename", ResourceType = typeof (ASCustomReportResx))]
        [ViewField(Name = Fields.ReportFilename, Id = Index.ReportFilename, FieldType = EntityFieldType.Char, Size = 255)]
        public string ReportFilename { get; set; }

        /// <summary>
        /// Gets or sets ReportTitle
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReportTitle", ResourceType = typeof (ASCustomReportResx))]
        [ViewField(Name = Fields.ReportTitle, Id = Index.ReportTitle, FieldType = EntityFieldType.Char, Size = 255)]
        public string ReportTitle { get; set; }

        #region UI Strings

        #endregion
    }
}
