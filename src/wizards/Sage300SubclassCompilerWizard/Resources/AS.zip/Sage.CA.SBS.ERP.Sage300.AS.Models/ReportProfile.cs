// Copyright © 2016 Sage Software, Inc

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.AS.Resources;
using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Partial class for ReportProfile
    /// </summary>
    public partial class ReportProfile : ModelBase
    {
        /// <summary>
        /// Gets or sets ProfileID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProfileID", ResourceType = typeof(ASCommonResx))]
        [ViewField(Name = Fields.ProfileID, Id = Index.ProfileID, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-20N")]
        public string ProfileID { get; set; }

        /// <summary>
        /// Gets or sets CompanyID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompanyId", ResourceType = typeof(ASCommonResx))]
        [ViewField(Name = Fields.CompanyID, Id = Index.CompanyID, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CompanyID { get; set; }

        /// <summary>
        /// Gets or sets ReportGUID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReportGUID", ResourceType = typeof(ASCommonResx))]
        [ViewField(Name = Fields.ReportGUID, Id = Index.ReportGUID, FieldType = EntityFieldType.Char, Size = 36)]
        public string ReportGUID { get; set; }

        /// <summary>
        /// Gets or sets ReportFilename
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReportFilename", ResourceType = typeof(ASCommonResx))]
        [GridInfo(2, typeof(ASCustomReportResx), "ReportFilename", Style = "")]
        [ViewField(Name = Fields.ReportFilename, Id = Index.ReportFilename, FieldType = EntityFieldType.Char, Size = 255)]
        public string ReportFilename { get; set; }

        /// <summary>
        /// Gets or sets ReportTitle
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReportTitle", ResourceType = typeof(ASCustomReportResx))]
        [GridInfo(1, typeof(ASCustomReportResx), "ReportTitle", Style = "")]
        [ViewField(Name = Fields.ReportTitle, Id = Index.ReportTitle, FieldType = EntityFieldType.Char, Size = 255)]
        public string ReportTitle { get; set; }

        /// <summary>
        /// Gets or sets FilterByUser
        /// </summary>
        [Display(Name = "FilterByUser", ResourceType = typeof(ReportProfileResx))]
        [ViewField(Name = Fields.FilterByUser, Id = Index.FilterByUser, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FilterByUser { get; set; }
        
        #region UI Strings

        #endregion
    }
}
