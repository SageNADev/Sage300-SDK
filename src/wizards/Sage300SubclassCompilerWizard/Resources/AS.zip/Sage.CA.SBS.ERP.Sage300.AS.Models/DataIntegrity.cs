// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Class Data Integrity
    /// </summary>
    public partial class DataIntegrity : ModelBase
    {
        #region Constructor

        /// <summary>
        /// Data Integrity Constructor
        /// </summary>
        public DataIntegrity()
        {
            ActiveApplications = new List<DataIntegrity>();
            SelectedApplications = new List<DataIntegrity>();
        }

        #endregion

        /// <summary>
        /// Gets or sets ProgramID 
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProgramID, Id = Index.ProgramID, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ProgramID { get; set; }

        /// <summary>
        /// Gets or sets ProgramVersion 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProgramVersion, Id = Index.ProgramVersion, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ProgramVersion { get; set; }

        /// <summary>
        /// Gets or sets ProgramName 
        /// </summary>
        [StringLength(100, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProgramName, Id = Index.ProgramName, FieldType = EntityFieldType.Char, Size = 100)]
        public string ProgramName { get; set; }

        /// <summary>
        /// Gets or sets FixMinorErrors 
        /// </summary>
        [ViewField(Name = Fields.FixMinorErrors, Id = Index.FixMinorErrors, FieldType = EntityFieldType.Bool, Size = 2)]
        public long FixMinorErrors { get; set; }

        /// <summary>
        /// Gets or sets ErrorLevel 
        /// </summary>
        [ViewField(Name = Fields.ErrorLevel, Id = Index.ErrorLevel, FieldType = EntityFieldType.Int, Size = 2)]
        public int ErrorLevel { get; set; }

        /// <summary>
        /// Gets or sets ErrorLogFile 
        /// </summary>
        [StringLength(260, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ErrorLogFile, Id = Index.ErrorLogFile, FieldType = EntityFieldType.Char, Size = 260)]
        public string ErrorLogFile { get; set; }

        /// <summary>
        /// Gets or sets IsFixMinorIssuesCheck 
        /// </summary>
         [Display(Name = "LblFixMinorErrors", ResourceType = typeof(DataIntegrityResx))]
        public bool IsFixMinorIssuesCheck { get; set; }

        /// <summary>
        /// Gets or sets Application Name Without Version
        /// </summary>
        public string AppVersion { get; set; }

        /// <summary>
        /// Gets or sets selected active applications
        /// </summary>
        public IEnumerable<DataIntegrity> SelectedApplications { get; set; }

        /// <summary>
        /// Gets or sets active applications
        /// </summary>
        public IEnumerable<DataIntegrity> ActiveApplications { get; set; }

        /// <summary>
        /// Gets or sets option URL
        /// </summary>
        public string OptionURL { get; set; }
    }
}
