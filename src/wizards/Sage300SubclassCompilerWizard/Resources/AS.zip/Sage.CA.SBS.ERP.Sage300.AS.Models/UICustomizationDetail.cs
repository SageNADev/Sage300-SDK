// Copyright © 2016 Sage Software, Inc

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Partial class for UICustomizationDetail
    /// </summary>
    public partial class UICustomizationDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets ScreenID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ScreenID", ResourceType = typeof (UICustomizationDetailResx))]
        public string ScreenID { get; set; }

        /// <summary>
        /// Gets or sets CustomizationID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomizationID", ResourceType = typeof (UICustomizationDetailResx))]
        public string CustomizationID { get; set; }

        /// <summary>
        /// Gets or sets PartNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PartNumber", ResourceType = typeof (UICustomizationDetailResx))]
        public long PartNumber { get; set; }

        /// <summary>
        /// Gets or sets BlobData
        /// </summary>
        [Display(Name = "BlobData", ResourceType = typeof (UICustomizationDetailResx))]
        public byte[] BlobData { get; set; }

        #region UI Strings

        #endregion
    }
}