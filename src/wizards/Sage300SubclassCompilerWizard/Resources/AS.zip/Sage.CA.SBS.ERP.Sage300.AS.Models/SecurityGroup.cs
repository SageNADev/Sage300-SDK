// /* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Security Groups Model
    /// </summary>
    public partial class SecurityGroup : ModelBase
    {
        /// <summary>
        /// Gets or sets Program Id 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ProgramId", ResourceType = typeof (SecurityGroupsResx))]
        [ViewField(Name = Fields.ProgramId, Id = Index.ProgramId, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ProgramId { get; set; }

        /// <summary>
        /// Gets or sets Program Version 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ProgramVersion", ResourceType = typeof (SecurityGroupsResx))]
        [ViewField(Name = Fields.ProgramVersion, Id = Index.ProgramVersion, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ProgramVersion { get; set; }

        /// <summary>
        /// Gets or sets Group Id 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SecurityGroupID", ResourceType = typeof (SecurityGroupsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceType = typeof (AnnotationsResx),
            ErrorMessageResourceName = "AlphaNumeric")]
        [ViewField(Name = Fields.GroupId, Id = Index.GroupId, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string GroupId { get; set; }

        /// <summary>
        /// Gets or sets Resource Id 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ResourceId", ResourceType = typeof (SecurityGroupsResx))]
        [ViewField(Name = Fields.ResourceId, Id = Index.ResourceId, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10N")]
        public string ResourceId { get; set; }

        /// <summary>
        /// Gets or sets Group Description 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SecurityGroupDesc", ResourceType = typeof (SecurityGroupsResx))]
        [ViewField(Name = Fields.GroupDescription, Id = Index.GroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string GroupDescription { get; set; }

        /// <summary>
        /// Gets or Sets Application Security Resources
        /// </summary>
        public EnumerableResponse<ApplicationSecurityResources> ApplicationSecurityResources { get; set; }

        /// <summary>
        /// To get Active Application list
        /// </summary>
        public List<ActiveApplication> ActiveApplications { get; set; }
    }
}
