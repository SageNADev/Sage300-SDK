/* Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Partial class for CustomizationDirctories
    /// </summary>
    public partial class CustomizationDirctories : ModelBase
    {
        /// <summary>
        /// Gets or sets User ID
        /// </summary>
        [Key]
        [ViewField(Name = Fields.UserId, Id = Index.UserId, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8C")]
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets Company Id
        /// </summary>
        [Key]
        [ViewField(Name = Fields.OrgId, Id = Index.OrgId, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string OrgId { get; set; }

        /// <summary>
        /// Gets or sets ProfileID
        /// </summary>
        [ViewField(Name = Fields.CustDir, Id = Index.CustDir, FieldType = EntityFieldType.Char, Size = 260)]
        public string CustDir { get; set; }
      
    }
}
