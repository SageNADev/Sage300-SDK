/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    public partial class RestartRecord : ModelBase
    {
        /// <summary>
        /// Gets or sets DatabaseID 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "DatabaseID", ResourceType = typeof (RestartMaintenanceResx))]
        [ViewField(Name = Fields.DatabaseID, Id = Index.DatabaseID, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DatabaseID { get; set; }

        /// <summary>
        /// Gets or sets ProgramName 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))
        ]
        [StringLength(8, ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "ProgramName", ResourceType = typeof (RestartMaintenanceResx))]
        [ViewField(Name = Fields.ProgramName, Id = Index.ProgramName, FieldType = EntityFieldType.Char, Size = 8)]
        public string ProgramName { get; set; }

        /// <summary>
        /// Gets or sets RestartNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "RestartNumber", ResourceType = typeof (RestartMaintenanceResx))]
        [ViewField(Name = Fields.RestartNumber, Id = Index.RestartNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int RestartNumber { get; set; }

        /// <summary>
        /// Gets or sets UserID 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof (RestartMaintenanceResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets Date 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Date", ResourceType = typeof (RestartMaintenanceResx))]
        [ViewField(Name = Fields.Date, Id = Index.Date, FieldType = EntityFieldType.Date, Size = 5)]
        public string Date { get; set; }

        /// <summary>
        /// Gets or sets Time 
        /// </summary>
        //[ValidateDateFormat(ErrorMessage = "*")]
        [Display(Name = "Time", ResourceType = typeof (RestartMaintenanceResx))]
        [ViewField(Name = Fields.Time, Id = Index.Time, FieldType = EntityFieldType.Time, Size = 5)]
        public string Time { get; set; }

        /// <summary>
        /// Gets or sets MessageLength 
        /// </summary>
        [ViewField(Name = Fields.MessageLength, Id = Index.MessageLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int MessageLength { get; set; }

        /// <summary>
        /// Gets or sets DataLength 
        /// </summary>
        [ViewField(Name = Fields.DataLength, Id = Index.DataLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int DataLength { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Byte, Size = 20)]
        public byte Reference { get; set; }

        /// <summary>
        /// Gets or sets Message 
        /// </summary>
        [StringLength(1024, ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Message", ResourceType = typeof (RestartMaintenanceResx))]
        [ViewField(Name = Fields.Message, Id = Index.Message, FieldType = EntityFieldType.Char, Size = 1024)]
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets Data 
        /// </summary>
        [ViewField(Name = Fields.Data, Id = Index.Data, FieldType = EntityFieldType.Byte, Size = 1024)]
        public byte Data { get; set; }
    }
}
