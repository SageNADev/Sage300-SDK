﻿/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models.Enums.ExportImport
{
    public enum UserExportOptions
    {
        [EnumValue("User", typeof(UsersResx))]
        User = 1,
    }
}
