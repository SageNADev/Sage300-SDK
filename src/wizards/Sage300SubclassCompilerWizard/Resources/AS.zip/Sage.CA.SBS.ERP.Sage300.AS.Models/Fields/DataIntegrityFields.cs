﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of Data Integrity SuperView Constants 
    /// </summary>
    public partial class DataIntegrity
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AS0023";

        /// <summary>
        /// Contains list of Data Integrity SuperView Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for ProgramID 
            /// </summary>
            public const string ProgramID = "PGMID";

            /// <summary>
            /// Property for ProgramVersion 
            /// </summary>
            public const string ProgramVersion = "PGMVER";

            /// <summary>
            /// Property for ProgramName 
            /// </summary>
            public const string ProgramName = "PGMNAME";

            /// <summary>
            /// Property for FixMinorErrors 
            /// </summary>
            public const string FixMinorErrors = "FIXFLAG";

            /// <summary>
            /// Property for ErrorLevel 
            /// </summary>
            public const string ErrorLevel = "ERRORLEV";

            /// <summary>
            /// Property for ErrorLogFile 
            /// </summary>
            public const string ErrorLogFile = "ERRORFILE";

            #endregion
        }

        /// <summary>
        /// Contains list of Data Integrity SuperView Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for ProgramID 
            /// </summary>
            public const int ProgramID = 0;

            /// <summary>
            /// Property Indexer for ProgramVersion 
            /// </summary>
            public const int ProgramVersion = 1;

            /// <summary>
            /// Property Indexer for ProgramName 
            /// </summary>
            public const int ProgramName = 2;

            /// <summary>
            /// Property Indexer for FixMinorErrors 
            /// </summary>
            public const int FixMinorErrors = 3;

            /// <summary>
            /// Property Indexer for ErrorLevel 
            /// </summary>
            public const int ErrorLevel = 4;

            /// <summary>
            /// Property Indexer for ErrorLogFile 
            /// </summary>
            public const int ErrorLogFile = 5;

            #endregion
        }
    }
}