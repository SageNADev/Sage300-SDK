// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AS.Models 
{
    /// <summary>
    /// Contains list of RestartRecord Constants 
    /// </summary>
    public partial class RestartRecord
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AS0021";

        /// <summary>
        /// Contains list of RestartRecord Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for DatabaseID 
            /// </summary>
            public const string DatabaseID = "ORGID";

            /// <summary>
            /// Property for ProgramName 
            /// </summary>
            public const string ProgramName = "PGMNAME";

            /// <summary>
            /// Property for RestartNumber 
            /// </summary>
            public const string RestartNumber = "PCSNUM";

            /// <summary>
            /// Property for UserID 
            /// </summary>
            public const string UserID = "USERID";

            /// <summary>
            /// Property for Date 
            /// </summary>
            public const string Date = "DATE";

            /// <summary>
            /// Property for Time 
            /// </summary>
            public const string Time = "TIME";

            /// <summary>
            /// Property for MessageLength 
            /// </summary>
            public const string MessageLength = "MSGLEN";

            /// <summary>
            /// Property for DataLength 
            /// </summary>
            public const string DataLength = "DATALEN";

            /// <summary>
            /// Property for Reference 
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for Message 
            /// </summary>
            public const string Message = "MESSAGE";

            /// <summary>
            /// Property for Data 
            /// </summary>
            public const string Data = "DATA";

            #endregion
        }

        /// <summary>
        /// Contains list of RestartRecord Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for DatabaseID 
            /// </summary>
            public const int DatabaseID = 0;

            /// <summary>
            /// Property Indexer for ProgramName 
            /// </summary>
            public const int ProgramName = 1;

            /// <summary>
            /// Property Indexer for RestartNumber 
            /// </summary>
            public const int RestartNumber = 2;

            /// <summary>
            /// Property Indexer for UserID 
            /// </summary>
            public const int UserID = 3;

            /// <summary>
            /// Property Indexer for Date 
            /// </summary>
            public const int Date = 4;

            /// <summary>
            /// Property Indexer for Time 
            /// </summary>
            public const int Time = 5;

            /// <summary>
            /// Property Indexer for MessageLength 
            /// </summary>
            public const int MessageLength = 6;

            /// <summary>
            /// Property Indexer for DataLength 
            /// </summary>
            public const int DataLength = 7;

            /// <summary>
            /// Property Indexer for Reference 
            /// </summary>
            public const int Reference = 8;

            /// <summary>
            /// Property Indexer for Message 
            /// </summary>
            public const int Message = 9;

            /// <summary>
            /// Property Indexer for Data 
            /// </summary>
            public const int Data = 10;

            #endregion
        }
    }
}