// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of ApplicationSecurityResources Constants 
    /// </summary>
    public partial class ApplicationSecurityResources
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AS0022";

        /// <summary>
        /// Contains list of ApplicationSecurityResources Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for ProgramID 
            /// </summary>
            public const string ProgramID = "PGMID";

            /// <summary>
            /// Property for ProgramVersion 
            /// </summary>
            public const string ProgramVersion = "PGMVER";

            /// <summary>
            /// Property for ResourceID 
            /// </summary>
            public const string ResourceID = "RSCID";

            /// <summary>
            /// Property for ResourceDescription 
            /// </summary>
            public const string ResourceDescription = "RSCDESC";

            #endregion
        }

        /// <summary>
        /// Contains list of ApplicationSecurityResources Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for ProgramID 
            /// </summary>
            public const int ProgramID = 0;

            /// <summary>
            /// Property Indexer for ProgramVersion 
            /// </summary>
            public const int ProgramVersion = 1;

            /// <summary>
            /// Property Indexer for ResourceID 
            /// </summary>
            public const int ResourceID = 2;

            /// <summary>
            /// Property Indexer for ResourceDescription 
            /// </summary>
            public const int ResourceDescription = 3;

            #endregion
        }
    }
}