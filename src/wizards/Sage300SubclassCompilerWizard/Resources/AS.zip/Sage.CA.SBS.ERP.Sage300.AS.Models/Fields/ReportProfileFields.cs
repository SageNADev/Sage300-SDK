// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of ReportProfile Constants
    /// </summary>
    public partial class ReportProfile
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AS0050";


        #region Properties

        /// <summary>
        /// Contains list of ReportProfile Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ProfileID
            /// </summary>
            public const string ProfileID = "PROFILEID";

            /// <summary>
            /// Property for CompanyID
            /// </summary>
            public const string CompanyID = "COMPANYID";

            /// <summary>
            /// Property for ReportGUID
            /// </summary>
            public const string ReportGUID = "REPORTID";

            /// <summary>
            /// Property for ReportFilename
            /// </summary>
            public const string ReportFilename = "REPORTNAME";

            /// <summary>
            /// Property for ReportTitle
            /// </summary>
            public const string ReportTitle = "REPORTITLE";
            
            /// <summary>
            /// Property for FilterByUser
            /// </summary>
            public const string FilterByUser = "BYUSER";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of ReportProfile Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ProfileID
            /// </summary>
            public const int ProfileID = 1;

            /// <summary>
            /// Property Indexer for CompanyID
            /// </summary>
            public const int CompanyID = 2;

            /// <summary>
            /// Property Indexer for ReportGUID
            /// </summary>
            public const int ReportGUID = 3;

            /// <summary>
            /// Property Indexer for ReportFilename
            /// </summary>
            public const int ReportFilename = 20;

            /// <summary>
            /// Property Indexer for ReportTitle
            /// </summary>
            public const int ReportTitle = 21;

            /// <summary>
            /// Property Indexer for FilterByUser
            /// </summary>
            public const int FilterByUser = 22;

        }

        #endregion

    }
}