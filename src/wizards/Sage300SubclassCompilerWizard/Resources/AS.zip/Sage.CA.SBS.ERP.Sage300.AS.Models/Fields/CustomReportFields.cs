// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of CustomReport Constants
    /// </summary>
    public partial class CustomReport
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AS0040";


        #region Properties

        /// <summary>
        /// Contains list of CustomReport Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReportGUID
            /// </summary>
            public const string ReportGUID = "REPORTID";

            /// <summary>
            /// Property for ReportFilename
            /// </summary>
            public const string ReportFilename = "REPORTNAME";

            /// <summary>
            /// Property for ReportTitle
            /// </summary>
            public const string ReportTitle = "REPORTITLE";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of CustomReport Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReportGUID
            /// </summary>
            public const int ReportGUID = 1;

            /// <summary>
            /// Property Indexer for ReportFilename
            /// </summary>
            public const int ReportFilename = 2;

            /// <summary>
            /// Property Indexer for ReportTitle
            /// </summary>
            public const int ReportTitle = 3;


        }

        #endregion

    }
}