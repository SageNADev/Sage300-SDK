// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of SecurityGroup Constants 
    /// </summary>
    public partial class SecurityGroup
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AS0001";

        /// <summary>
        /// Contains list of SecurityGroups Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for ProgramId 
            /// </summary>
            public const string ProgramId = "PGMID";

            /// <summary>
            /// Property for ProgramVersion 
            /// </summary>
            public const string ProgramVersion = "PGMVER";

            /// <summary>
            /// Property for GroupId 
            /// </summary>
            public const string GroupId = "PROFILEID";

            /// <summary>
            /// Property for ResourceId 
            /// </summary>
            public const string ResourceId = "RESOURCEID";

            /// <summary>
            /// Property for GroupDescription 
            /// </summary>
            public const string GroupDescription = "PROFDESC";

            #endregion
        }

        /// <summary>
        /// Contains list of SecurityGroup Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for ProgramId 
            /// </summary>
            public const int ProgramId = 1;

            /// <summary>
            /// Property Indexer for ProgramVersion 
            /// </summary>
            public const int ProgramVersion = 2;

            /// <summary>
            /// Property Indexer for GroupId
            /// </summary>
            public const int GroupId = 3;

            /// <summary>
            /// Property Indexer for ResourceId 
            /// </summary>
            public const int ResourceId = 4;

            /// <summary>
            /// Property Indexer for GroupDescription 
            /// </summary>
            public const int GroupDescription = 5;

            #endregion
        }
    }
}