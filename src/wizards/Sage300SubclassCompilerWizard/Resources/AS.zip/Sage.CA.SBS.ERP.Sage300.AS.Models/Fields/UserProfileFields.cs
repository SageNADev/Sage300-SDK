// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of UserProfile Constants
    /// </summary>
    public partial class UserProfile
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AS0007";


        #region Properties

        /// <summary>
        /// Contains list of UserProfile Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for UserID
            /// </summary>
            public const string UserID = "USERID";

            /// <summary>
            /// Property for CompanyID
            /// </summary>
            public const string CompanyID = "COMPANYID";

            /// <summary>
            /// Property for ProfileID
            /// </summary>
            public const string ProfileID = "PROFILEID";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of UserProfile Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for UserID
            /// </summary>
            public const int UserID = 1;

            /// <summary>
            /// Property Indexer for CompanyID
            /// </summary>
            public const int CompanyID = 2;

            /// <summary>
            /// Property Indexer for ProfileID
            /// </summary>
            public const int ProfileID = 3;


        }

        #endregion

    }
}