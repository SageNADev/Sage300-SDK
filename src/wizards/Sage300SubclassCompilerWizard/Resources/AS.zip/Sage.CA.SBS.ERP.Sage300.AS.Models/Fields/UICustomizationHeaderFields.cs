// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of UICustomization Constants
    /// </summary>
    public partial class UICustomization
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AS0051";


        #region Properties

        /// <summary>
        /// Contains list of UICustomization Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ScreenID
            /// </summary>
            public const string ScreenID = "SCREENID";

            /// <summary>
            /// Property for CustomizationID
            /// </summary>
            public const string CustomizationID = "CUSTID";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESCRIPT";

            /// <summary>
            /// Property for DataSize
            /// </summary>
            public const string DataSize = "DATASIZE";

            /// <summary>
            /// Property for NumberOfParts
            /// </summary>
            public const string NumberOfParts = "NUMOFPARTS";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of UICustomization Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ScreenID
            /// </summary>
            public const int ScreenID = 1;

            /// <summary>
            /// Property Indexer for CustomizationID
            /// </summary>
            public const int CustomizationID = 2;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 3;

            /// <summary>
            /// Property Indexer for DataSize
            /// </summary>
            public const int DataSize = 4;

            /// <summary>
            /// Property Indexer for NumberOfParts
            /// </summary>
            public const int NumberOfParts = 5;


        }

        #endregion

    }
}