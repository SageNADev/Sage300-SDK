// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of UICustomizationDetail Constants
    /// </summary>
    public partial class UICustomizationDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AS0052";

        public const int Blobdatasize = 3800;


        #region Properties

        /// <summary>
        /// Contains list of UICustomizationDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ScreenID
            /// </summary>
            public const string ScreenID = "SCREENID";

            /// <summary>
            /// Property for CustomizationID
            /// </summary>
            public const string CustomizationID = "CUSTID";

            /// <summary>
            /// Property for PartNumber
            /// </summary>
            public const string PartNumber = "PARTNUM";

            /// <summary>
            /// Property for BlobData
            /// </summary>
            public const string BlobData = "BLOBDAT";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of UICustomizationDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ScreenID
            /// </summary>
            public const int ScreenID = 1;

            /// <summary>
            /// Property Indexer for CustomizationID
            /// </summary>
            public const int CustomizationID = 2;

            /// <summary>
            /// Property Indexer for PartNumber
            /// </summary>
            public const int PartNumber = 3;

            /// <summary>
            /// Property Indexer for BlobData
            /// </summary>
            public const int BlobData = 4;


        }

        #endregion

    }
}