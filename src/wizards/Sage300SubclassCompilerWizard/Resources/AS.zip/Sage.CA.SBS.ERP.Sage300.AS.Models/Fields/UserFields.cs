/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of Users Constants 
    /// </summary>
    public partial class User
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AS0003";

        /// <summary>
        /// Contains list of Users Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for UserID 
            /// </summary>
            public const string UserID = "USERID";

            /// <summary>
            /// Property for UserName 
            /// </summary>
            public const string UserName = "USERNAME";

            /// <summary>
            /// Property for Password 
            /// </summary>
            public const string Password = "PASSWORD";

            /// <summary>
            /// Property for AccountType 
            /// </summary>
            public const string AccountType = "ACCTTYPE";

            /// <summary>
            /// Property for AccountStatus 
            /// </summary>
            public const string AccountStatus = "ACCTSTATUS";

            /// <summary>
            /// Property for LanguageCode 
            /// </summary>
            public const string LanguageCode = "LANGUAGE";

            /// <summary>
            /// Property for Language 
            /// </summary>
            public const string Language = "LANGLIST";

            /// <summary>
            /// Property for ReserveLP
            /// </summary>
            public const string ReserveLanPak = "RESERVELP";

            /// <summary>
            /// Property for Mustchangepasswordnextlogon 
            /// </summary>
            public const string Mustchangepasswordnextlogon = "CHNGEPASS";

            /// <summary>
            /// Property for Usercannotchangepassword 
            /// </summary>
            public const string Usercannotchangepassword = "NOCHNGPASS";

            /// <summary>
            /// Property for Passwordneverexpires 
            /// </summary>
            public const string Passwordneverexpires = "PASSNOEXP";

            /// <summary>
            /// Property for Accountisdisabled 
            /// </summary>
            public const string Accountisdisabled = "DISABLED";

            /// <summary>
            /// Property for Accountislockedout 
            /// </summary>
            public const string Accountislockedout = "LOCKEDOUT";

            /// <summary>
            /// Property for Accountisrestricted 
            /// </summary>
            public const string Accountisrestricted = "RESTRICTED";

            /// <summary>
            /// Property for Monday 
            /// </summary>
            public const string Monday = "OKMONDAY";

            /// <summary>
            /// Property for Tuesday 
            /// </summary>
            public const string Tuesday = "OKTUESDAY";

            /// <summary>
            /// Property for Wednesday 
            /// </summary>
            public const string Wednesday = "OKWEDNESDY";

            /// <summary>
            /// Property for Thursday 
            /// </summary>
            public const string Thursday = "OKTHURSDAY";

            /// <summary>
            /// Property for Friday 
            /// </summary>
            public const string Friday = "OKFRIDAY";

            /// <summary>
            /// Property for Saturday 
            /// </summary>
            public const string Saturday = "OKSATURDAY";

            /// <summary>
            /// Property for Sunday 
            /// </summary>
            public const string Sunday = "OKSUNDAY";

            /// <summary>
            /// Property for Timebegin 
            /// </summary>
            public const string Timebegin = "TIMEBEGIN";

            /// <summary>
            /// Property for Timeend 
            /// </summary>
            public const string Timeend = "TIMEEND";

            /// <summary>
            /// Property for AuthenticationMethod 
            /// </summary>
            public const string AuthenticationMethod = "AUTHMETH";

            /// <summary>
            /// Property for WindowsDomain 
            /// </summary>
            public const string WindowsDomain = "WINDOMAIN";

            /// <summary>
            /// Property for WindowsUserName 
            /// </summary>
            public const string WindowsUserName = "WINUSER";

            /// <summary>
            /// Property for Phone 
            /// </summary>
            public const string Phone = "PHONE";

            /// <summary>
            /// Property for Email1 
            /// </summary>
            public const string Email1 = "EMAIL1";

            /// <summary>
            /// Property for Email2 
            /// </summary>
            public const string Email2 = "EMAIL2";

            /// <summary>
            /// Property for JobRole 
            /// </summary>
            public const string JobRole = "ROLE";

            /// <summary>
            /// Property for UserreceivesemailfromSage 
            /// </summary>
            public const string UserreceivesemailfromSage = "OPTIN";

            /// <summary>
            /// Property for O365UserName
            /// </summary>
            public const string O365UserName = "O365USRNAM";

            /// <summary>
            /// Property for LocaleID
            /// </summary>
            public const string LocaleId = "LOCALEID";

            /// <summary>
            /// Property for Locale
            /// </summary>
            public const string Locale = "LOCALELIST";

            #endregion
        }

        /// <summary>
        /// Contains list of Users Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for UserID 
            /// </summary>
            public const int UserID = 0;

            /// <summary>
            /// Property Indexer for UserName 
            /// </summary>
            public const int UserName = 1;

            /// <summary>
            /// Property Indexer for Password 
            /// </summary>
            public const int Password = 2;

            /// <summary>
            /// Property Indexer for AccountType 
            /// </summary>
            public const int AccountType = 3;

            /// <summary>
            /// Property Indexer for AccountStatus 
            /// </summary>
            public const int AccountStatus = 4;

            /// <summary>
            /// Property Indexer for LanguageCode 
            /// </summary>
            public const int LanguageCode = 5;

            /// <summary>
            /// Property Indexer for Language 
            /// </summary>
            public const int Language = 6;

            /// <summary>
            /// Property Indexer for Mustchangepasswordnextlogon 
            /// </summary>
            public const int Mustchangepasswordnextlogon = 7;

            /// <summary>
            /// Property Indexer for Usercannotchangepassword 
            /// </summary>
            public const int Usercannotchangepassword = 8;

            /// <summary>
            /// Property Indexer for Passwordneverexpires 
            /// </summary>
            public const int Passwordneverexpires = 9;

            /// <summary>
            /// Property Indexer for Accountisdisabled 
            /// </summary>
            public const int Accountisdisabled = 10;

            /// <summary>
            /// Property Indexer for Accountislockedout 
            /// </summary>
            public const int Accountislockedout = 11;

            /// <summary>
            /// Property Indexer for Accountisrestricted 
            /// </summary>
            public const int Accountisrestricted = 12;

            /// <summary>
            /// Property Indexer for Monday 
            /// </summary>
            public const int Monday = 13;

            /// <summary>
            /// Property Indexer for Tuesday 
            /// </summary>
            public const int Tuesday = 14;

            /// <summary>
            /// Property Indexer for Wednesday 
            /// </summary>
            public const int Wednesday = 15;

            /// <summary>
            /// Property Indexer for Thursday 
            /// </summary>
            public const int Thursday = 16;

            /// <summary>
            /// Property Indexer for Friday 
            /// </summary>
            public const int Friday = 17;

            /// <summary>
            /// Property Indexer for Saturday 
            /// </summary>
            public const int Saturday = 18;

            /// <summary>
            /// Property Indexer for Sunday 
            /// </summary>
            public const int Sunday = 19;

            /// <summary>
            /// Property Indexer for Timebegin 
            /// </summary>
            public const int Timebegin = 20;

            /// <summary>
            /// Property Indexer for Timeend 
            /// </summary>
            public const int Timeend = 21;

            /// <summary>
            /// Property Indexer for AuthenticationMethod 
            /// </summary>
            public const int AuthenticationMethod = 22;

            /// <summary>
            /// Property Indexer for WindowsDomain 
            /// </summary>
            public const int WindowsDomain = 23;

            /// <summary>
            /// Property Indexer for WindowsUserName 
            /// </summary>
            public const int WindowsUserName = 24;

            /// <summary>
            /// Property Indexer for Phone 
            /// </summary>
            public const int Phone = 25;

            /// <summary>
            /// Property Indexer for Email1 
            /// </summary>
            public const int Email1 = 26;

            /// <summary>
            /// Property Indexer for Email2 
            /// </summary>
            public const int Email2 = 27;

            /// <summary>
            /// Property Indexer for JobRole 
            /// </summary>
            public const int JobRole = 28;

            /// <summary>
            /// Property Indexer for UserreceivesemailfromSage 
            /// </summary>
            public const int UserreceivesemailfromSage = 29;

            /// <summary>
            /// Property Indexer for LocaleId
            /// </summary>
            public const int LocaleId = 30;

            /// <summary>
            /// Property Indexer for LocaleList
            /// </summary>
            public const int Locale = 31;

            /// <summary>
            /// Property Indexer for O365UserName
            /// </summary>
            public const int O365UserName = 32;

            /// <summary>
            /// Property Indexer for ReserveLanPak
            /// </summary>
            public const int ReserveLanPak = 33;

            #endregion
        }
    }
}