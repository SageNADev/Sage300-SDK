// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of UICustomizationProfile Constants
    /// </summary>
    public partial class UICustomizationProfile
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AS0053";


        #region Properties

        /// <summary>
        /// Contains list of UICustomizationProfile Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ProfileID
            /// </summary>
            public const string ProfileID = "PROFILEID";

            /// <summary>
            /// Property for CompanyID
            /// </summary>
            public const string CompanyID = "COMPANYID";

            /// <summary>
            /// Property for ScreenID
            /// </summary>
            public const string ScreenID = "SCREENID";

            /// <summary>
            /// Property for CustomizationID
            /// </summary>
            public const string CustomizationID = "CUSTID";
        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of UICustomizationProfile Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ProfileID
            /// </summary>
            public const int ProfileID = 1;

            /// <summary>
            /// Property Indexer for CompanyID
            /// </summary>
            public const int CompanyID = 2;

            /// <summary>
            /// Property Indexer for ScreenID
            /// </summary>
            public const int ScreenID = 3;

            /// <summary>
            /// Property Indexer for CustomizationID
            /// </summary>
            public const int CustomizationID = 4;
        }

        #endregion

    }
}