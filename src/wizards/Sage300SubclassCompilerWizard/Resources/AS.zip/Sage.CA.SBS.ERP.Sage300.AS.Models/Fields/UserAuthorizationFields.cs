// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of UserAuthorizations Constants 
    /// </summary>
    public partial class UserAuthorization
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AS0002";

        /// <summary>
        /// Contains list of UserAuthorizations Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for UserID 
            /// </summary>
            public const string UserID = "USERID";

            /// <summary>
            /// Property for CompanyID 
            /// </summary>
            public const string CompanyID = "COMPANYID";

            /// <summary>
            /// Property for ProgramID 
            /// </summary>
            public const string ProgramID = "PGMID";

            /// <summary>
            /// Property for GroupID 
            /// </summary>
            public const string GroupID = "PROFILEID";

            #endregion
        }

        /// <summary>
        /// Contains list of UserAuthorizations Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for UserID 
            /// </summary>
            public const int UserID = 1;

            /// <summary>
            /// Property Indexer for CompanyID 
            /// </summary>
            public const int CompanyID = 2;

            /// <summary>
            /// Property Indexer for ProgramID 
            /// </summary>
            public const int ProgramID = 3;

            /// <summary>
            /// Property Indexer for GroupID 
            /// </summary>
            public const int GroupID = 4;

            #endregion
        }
    }
}