﻿/* Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// This class performs A4WCUST - Customization Directories
    /// </summary>
    public partial class CustomizationDirctories
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AS0004";


        #region Properties Fields
        /// <summary>
        /// Contains list of A4WCUST - Customization Directories Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// User ID
            /// </summary>
            public const string UserId = "USERID";

            /// <summary>
            /// Company ID
            /// </summary>
            public const string OrgId = "ORGID";

            /// <summary>
            /// Customization Directory
            /// </summary>
            public const string CustDir = "CUSTDIR";
        }
        #endregion

        #region Properties Indexes
        /// <summary>
        /// Contains list of A4WCUST - Customization Directories Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for User Id
            /// </summary>
            public const int UserId = 0;

            /// <summary>
            /// Property Indexer for Company Id
            /// </summary>
            public const int OrgId = 1;

            /// <summary>
            /// Property Indexer for Customization Directory
            /// </summary>
            public const int CustDir = 2;
        }
        #endregion
    }
}
