// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of WorkProfile Constants
    /// </summary>
    public partial class WorkProfile
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AS0005";


        #region Properties

        /// <summary>
        /// Contains list of WorkProfile Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ProfileID
            /// </summary>
            public const string ProfileID = "PROFILEID";

            /// <summary>
            /// Property for ProfileDescription
            /// </summary>
            public const string ProfileDescription = "PROFDESC";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of WorkProfile Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ProfileID
            /// </summary>
            public const int ProfileID = 1;

            /// <summary>
            /// Property Indexer for ProfileDescription
            /// </summary>
            public const int ProfileDescription = 2;


        }

        #endregion

    }
}