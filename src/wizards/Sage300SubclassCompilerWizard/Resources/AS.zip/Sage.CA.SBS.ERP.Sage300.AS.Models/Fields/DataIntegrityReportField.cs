﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of Data Integrity SuperView Constants 
    /// </summary>
    public partial class DataIntegrityReport
    {
        /// <summary>
        /// View Name - New Guid
        /// </summary>
        public const string ViewName = "A51F8AC6-AC6D-4D59-9D89-A0F8C7B10425";

        /// <summary>
        /// Contains list of DataIntegritySuperView Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for ErrorLogFile 
            /// </summary>
            public const string LogFile = "LOGFILE";

            #endregion
        }
    }
}