﻿/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

#region Imports
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models.Reports
{
    /// <summary>
    /// Contains User Authorization Report Constants
    /// </summary>
    public partial class UserAuthorizationReport
    {
        /// <summary>
        /// Unique Name
        /// </summary>
        public const string ViewName = "b4cfc600-9dc5-4b0b-9b7f-66b80eb7cc6c";

        /// <summary>
        /// User Authorization Report Field Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note: These field names should be the same as the names of the properties defined in other partial class

            /// <summary>
            /// Property for FromUser
            /// </summary>
            public const string FromUser = "FROMUSER";

            /// <summary>
            /// Property for ToUser
            /// </summary>
            public const string ToUser = "TOUSER";

            /// <summary>
            /// Property for Security Authorization
            /// </summary>
            public const string AuthDetail = "AUTHDETAIL?";

            /// <summary>
            /// Property for HasProfile
            /// </summary>
            public const string HasProfile = "HASPROFILE?";

            /// <summary>
            /// Property for UIProfile
            /// </summary>
            public const string UIProfile = "UIPROFILE?";

            #endregion
        }
    }
}
