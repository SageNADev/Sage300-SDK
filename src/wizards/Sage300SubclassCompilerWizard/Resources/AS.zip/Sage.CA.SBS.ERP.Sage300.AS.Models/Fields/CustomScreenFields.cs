﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Contains list of CustomScreen Constants
    /// </summary>
    public partial class CustomScreen
    {

            #region Properties

            /// <summary>
            /// Contains list of CustomScreen Field Constants
            /// </summary>
            public class Fields
            {
                /// <summary>
                /// Property for Package ID
                /// </summary>
                public const string PACKAGEID = "ID";

                /// <summary>
                /// Property for Pakage Description
                /// </summary>
                public const string DESCRIPTION = "DESC";

                /// <summary>
                /// Property for Pakage Version
                /// </summary>
                public const string VERSION = "VERSION";

                /// <summary>
                /// Property for Pakage Vendor
                /// </summary>
                public const string VENDOR = "VENDOR";

                /// <summary>
                /// Property for Screen Id
                /// </summary>
                public const string SCREENID = "SCRNID";
                                /// <summary>
                /// Property for Screen Name
                /// </summary>
                public const string SCREENNAME = "NAME";
                                /// <summary>
                /// Property for Company Id
                /// </summary>
                public const string COMPANYID = "CMPID";
                                /// <summary>
                /// Property for Screen Priority
                /// </summary>
                public const string PRIORITY = "PRIORITY";
                                /// <summary>
                /// Property for Screen Status
                /// </summary>
                public const string STATUS = "STATUS";

            }
            #endregion

        }
}
