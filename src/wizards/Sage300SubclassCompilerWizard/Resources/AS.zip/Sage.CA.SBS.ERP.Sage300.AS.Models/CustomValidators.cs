﻿/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

#region Imports
using Sage.CA.SBS.ERP.Sage300.AS.Resources;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    ///// <summary>
    ///// Custom compare validator for passwords
    ///// </summary>
    //public class ComparePasswordsValidator : ValidationAttribute 
    //{
    //    public string PasswordPropertyName { get; private set; }

    //    /// <summary>
    //    /// Constructor
    //    /// </summary>
    //    /// <param name="passwordPropertyName">The name of the property that we'll be checking to determine whether or not to validate the password</param>
    //    /// 
    //    public ComparePasswordsValidator(string passwordPropertyName)
    //    {
    //        this.PasswordPropertyName = passwordPropertyName;
    //    }

    //    /// <summary>
    //    /// IsValid
    //    /// </summary>
    //    /// <param name="value">The value from the Password (Or PasswordVerify) property</param>
    //    /// <param name="validationContext">The ValidationContext object</param>
    //    /// <returns></returns>
    //    protected override ValidationResult IsValid(object _passwordVerifyValue, ValidationContext _validationContext)
    //    {
    //        var passwordVerifyValue = _passwordVerifyValue as string;

    //        // Get the Password value
    //        var propInfo1 = _validationContext.ObjectType.GetProperty(PasswordPropertyName);
    //        var passwordValue = propInfo1.GetValue(_validationContext.ObjectInstance, null) as string;

    //        var passwordEmpty = string.IsNullOrEmpty(passwordValue);
    //        var verifyEmpty = string.IsNullOrEmpty(passwordVerifyValue);

    //        // Ok if password and verify are empty
    //        if (passwordEmpty && verifyEmpty)
    //        {
    //            return ValidationResult.Success;
    //        }

    //        // Password not empty, Verify is empty - Validaton Error
    //        // Password is empty, Verify is not empty - Validation Error
    //        if ((!passwordEmpty && verifyEmpty) || (passwordEmpty && !verifyEmpty))
    //        {
    //            return new ValidationResult(ASCommonResx.PasswordsDoNotMatch);
    //        }

    //        // Password and Verify are not empty and do not match - Validation Error
    //        if (!passwordEmpty && !verifyEmpty)
    //        {
    //            if (passwordVerifyValue != passwordValue)
    //            {
    //                return new ValidationResult(ASCommonResx.PasswordsDoNotMatch);
    //            }
    //        }

    //        return ValidationResult.Success;
    //    }
    //}



    ///// <summary>
    ///// Custom compare validator for passwords
    ///// </summary>
    //public class ComparePasswordsValidator : ValidationAttribute, IClientValidatable
    //{
    //    public string PasswordPropertyName { get; private set; }

    //    /// <summary>
    //    /// Constructor
    //    /// </summary>
    //    /// <param name="passwordPropertyName">The name of the property that we'll be checking to determine whether or not to validate the password</param>
    //    /// 
    //    public ComparePasswordsValidator(string passwordPropertyName)
    //    {
    //        this.PasswordPropertyName = passwordPropertyName;
    //    }

    //    /// <summary>
    //    /// IsValid
    //    /// </summary>
    //    /// <param name="value">The value from the Password (Or PasswordVerify) property</param>
    //    /// <param name="validationContext">The ValidationContext object</param>
    //    /// <returns></returns>
    //    protected override ValidationResult IsValid(object _passwordVerifyValue, ValidationContext _validationContext)
    //    {
    //        var passwordVerifyValue = _passwordVerifyValue as string;

    //        // Get the Password value
    //        var propInfo1 = _validationContext.ObjectType.GetProperty(PasswordPropertyName);
    //        var passwordValue = propInfo1.GetValue(_validationContext.ObjectInstance, null) as string;

    //        var passwordEmpty = string.IsNullOrEmpty(passwordValue);
    //        var verifyEmpty = string.IsNullOrEmpty(passwordVerifyValue);

    //        // Ok if password and verify are empty
    //        if (passwordEmpty && verifyEmpty)
    //        {
    //            return ValidationResult.Success;
    //        }

    //        // Password not empty, Verify is empty - Validaton Error
    //        // Password is empty, Verify is not empty - Validation Error
    //        if ((!passwordEmpty && verifyEmpty) || (passwordEmpty && !verifyEmpty))
    //        {
    //            return new ValidationResult(ASCommonResx.PasswordsDoNotMatch);
    //        }

    //        // Password and Verify are not empty and do not match - Validation Error
    //        if (!passwordEmpty && !verifyEmpty)
    //        {
    //            if (passwordVerifyValue != passwordValue)
    //            {
    //                return new ValidationResult(ASCommonResx.PasswordsDoNotMatch);
    //            }
    //        }

    //        return ValidationResult.Success;
    //    }

    //    public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
    //    {
    //        //throw new System.NotImplementedException();
    //        var rule = new ModelClientValidationRule()
    //        {
    //            ValidationType = "comparepasswords",
    //            ErrorMessage = ASCommonResx.PasswordsDoNotMatch,
    //        };

    //        rule.ValidationParameters.Add("passwordpropertyname", "Password");
    //        //rule.ValidationParameters.Add("maximumdate", MaximumDateProperty.ToShortDateString());

    //        yield return rule;
    //    }
    //}

    /// <summary>
    /// Not Currently Used
    /// </summary>
    public class TimeValidator : ValidationAttribute
    {
        private string _TimeBeginPropertyName;
        private string _TimeEndPropertyName;
        public TimeValidator(string TimeBeginPropertyName, string TimeEndPropertyName)
        {
            _TimeBeginPropertyName = TimeBeginPropertyName;
            _TimeEndPropertyName = TimeEndPropertyName;
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var propertyInfo1 = validationContext.ObjectType.GetProperty(_TimeBeginPropertyName);
            var timeBeginPropertyValue = propertyInfo1.GetValue(validationContext.ObjectInstance, null);

            var propertyInfo2 = validationContext.ObjectType.GetProperty(_TimeEndPropertyName);
            var timeEndPropertyValue = propertyInfo2.GetValue(validationContext.ObjectInstance, null);

            if (value == null)
            {
                // This likely means that the TimeBegin property is invalid
                // For example, it might have been entered as 29:59:59 which is not a valid time.

                return new ValidationResult("Begin Time is not a valid time.");
            }

            return ValidationResult.Success;
        }
    }
}
