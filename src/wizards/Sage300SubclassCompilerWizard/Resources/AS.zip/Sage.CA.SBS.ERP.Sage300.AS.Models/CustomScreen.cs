// Copyright © 2016 Sage Software, Inc

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    /// <summary>
    /// Partial class for Custom Screen.
    /// </summary>
    public partial class CustomScreen : ModelBase
    {
        public CustomScreen() 
        {
            CustomAssigns = new List<CustomAssign>();
        }
        /// <summary>
        /// Gets or sets PackageID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string PackageId { get; set; }

        /// <summary>
        /// Gets or sets ScreenID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ScreenId { get; set; }

        /// <summary>
        /// Gets or sets screen Name
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Name { get; set; }

        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TargetScreen { get; set; }
        
        /// <summary>
        /// Get or set Screen Module
        /// </summary>
        public string Module { get; set; }
        /// <summary>
        /// Gets or sets  screen description
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Description { get; set; }
        
        /// <summary>
        /// Get or set custom assginments 
        /// </summary>
        public IList<CustomAssign> CustomAssigns { get; set; }

    }
}