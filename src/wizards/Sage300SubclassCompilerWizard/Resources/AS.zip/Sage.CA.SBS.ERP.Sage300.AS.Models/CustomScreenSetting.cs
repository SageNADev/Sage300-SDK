﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.AS.Models
{
    public class CustomScreenSetting
    {
        /// <summary>
        /// Custom deploy pacgage id
        /// </summary>
        public string PackageId { get; set; }
        
        /// <summary>
        /// screen priority
        /// </summary>
        public int Priority { get; set; }
    }
}
