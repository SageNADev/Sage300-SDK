// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using Type = Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Type;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for Misc.ChargeOptionalField
    /// </summary>
    public partial class MiscChargeOptionalField : ModelBase
    {
        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets MiscellaneousChargeCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscChargeCode", ResourceType = typeof(MiscellaneousChargesResx))]
        [ViewField(Name = Fields.MiscellaneousChargeCode, Id = Index.MiscellaneousChargeCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string MiscellaneousChargeCode { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Value
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Value", ResourceType = typeof(MiscellaneousChargesResx))]
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public Validate Validate { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(OptionalFieldsResx))] 
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public ValueSet ValueSet { get; set; }

        /// <summary>
        /// To get the string of ValueSet property
        /// </summary>
        public string ValueSetString
        {
            get
            {
                return EnumUtility.GetStringValue(ValueSet);
            }
        }

        /// <summary>
        /// Gets or sets TypedValueFieldIndex
        /// </summary>
        [Display(Name = "TypedValueFieldIndex", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets TextValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TextValue", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string TextValue { get; set; }

        /// <summary>
        /// Gets or sets AmountValue
        /// </summary>
        [Display(Name = "AmountValue", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountValue { get; set; }

        /// <summary>
        /// Gets or sets NumberValue
        /// </summary>
        [Display(Name = "NumberValue", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NumberValue { get; set; }

        /// <summary>
        /// Gets or sets IntegerValue
        /// </summary>
        [Display(Name = "IntegerValue", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long IntegerValue { get; set; }

        /// <summary>
        /// Gets or sets YesNoValue
        /// </summary>
        [Display(Name = "YesNoValue", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.YesNoValue, Id = Index.YesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public YesNoValue YesNoValue { get; set; }

        /// <summary>
        /// Gets or sets DateValue
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateValue", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateValue { get; set; }

        /// <summary>
        /// Gets or sets TimeValue
        /// </summary>
        [Display(Name = "TimeValue", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime? TimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription
        /// </summary>
        [Display(Name = "DefaultValueDescription", ResourceType = typeof(OptionalFieldsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }

        /// <summary>
        /// Gets or sets Line Number
        /// </summary>
        /// <value>The Line Number.</value>
        public long SerialNumber { get; set; }

    }
}
