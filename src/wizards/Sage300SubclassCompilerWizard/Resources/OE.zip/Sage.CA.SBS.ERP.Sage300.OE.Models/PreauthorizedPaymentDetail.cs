// Copyright © 2017 Sage Software, Inc

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for PreauthorizedPaymentDetail
    /// </summary>
    public partial class PreauthorizedPaymentDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets ProcessingCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessingCode", ResourceType = typeof (PreauthorizedPaymentDetailResx))]
        public string ProcessingCode { get; set; }

        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessingCodeFrom", ResourceType = typeof(PreauthorizedPaymentDetailResx))]
        public string ProcessingCodeFrom { get; set; }

        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessingCodeTo", ResourceType = typeof(PreauthorizedPaymentDetailResx))]
        public string ProcessingCodeTo { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof (PreauthorizedPaymentDetailResx))]
        public string OrderNumber { get; set; }

        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumberFrom", ResourceType = typeof(PreauthorizedPaymentDetailResx))]
        public string OrderNumberFrom { get; set; }

        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumberTo", ResourceType = typeof(PreauthorizedPaymentDetailResx))]
        public string OrderNumberTo { get; set; }

        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARReceiptBatchDate", ResourceType = typeof(PreauthorizedPaymentDetailResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime ARReceiptBatchDate { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumber", ResourceType = typeof (PreauthorizedPaymentDetailResx))]
        public string ShipmentNumber { get; set; }

        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumberFrom", ResourceType = typeof(PreauthorizedPaymentDetailResx))]
        public string ShipmentNumberFrom { get; set; }

        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumberTo", ResourceType = typeof(PreauthorizedPaymentDetailResx))]
        public string ShipmentNumberTo { get; set; }

        /// <summary>
        /// Gets or sets OrderDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderDate", ResourceType = typeof (PreauthorizedPaymentDetailResx))]
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof (PreauthorizedPaymentDetailResx))]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof (PreauthorizedPaymentDetailResx))]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets ShipmentUniquifier
        /// </summary>
        [Display(Name = "ShipmentUniquifier", ResourceType = typeof (PreauthorizedPaymentDetailResx))]
        public decimal ShipmentUniquifier { get; set; }

        /// <summary>
        /// Gets or sets OrderUniquifier
        /// </summary>
        [Display(Name = "OrderUniquifier", ResourceType = typeof (PreauthorizedPaymentDetailResx))]
        public decimal OrderUniquifier { get; set; }

        /// <summary>
        /// Gets or sets ProcessingStatus
        /// </summary>
        [Display(Name = "ProcessingStatus", ResourceType = typeof (PreauthorizedPaymentDetailResx))]
        public ProcessingStatus ProcessingStatus { get; set; }

        /// <summary>
        /// Gets or sets Apply
        /// </summary>
        [Display(Name = "Apply", ResourceType = typeof (PreauthorizedPaymentDetailResx))]
        public Apply Apply { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ProcessingStatus string value
        /// </summary>
        public string ProcessingStatusString
        {
         get { return EnumUtility.GetStringValue(ProcessingStatus); }
        }

        /// <summary>
        /// Gets Apply string value
        /// </summary>
        public string ApplyString
        {
         get { return EnumUtility.GetStringValue(Apply); }
        }

        #endregion
    }
}