// Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Partial class for InvoiceDetail
	/// </summary>
	public partial class InvoiceDetail : ModelBase
	{

	    public InvoiceDetail()
	    {
            InvoiceCommentsInstructions = new EnumerableResponse<InvoiceCommentsInstruction>();
            InvoiceDetailOptionalFields = new EnumerableResponse<InvoiceDetailOptionalField>();
            InvoiceDetailSerialNumbers = new EnumerableResponse<InvoiceDetailSerialNumber>();
            InvoiceDetailLotNumbers = new EnumerableResponse<InvoiceDetailLotNumber>();
	    }

	    /// <summary>
        /// Get or Set Attributes
        /// </summary>
        [IgnoreExportImport]
        public IDictionary<string, object> Attributes { get; set; }

		/// <summary>
		/// Gets or sets InvoiceUniquifier
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal InvoiceUniquifier { get; set; }

		/// <summary>
		/// Gets or sets LineUniquifier
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.LineUniquifier, Id = Index.LineUniquifier, FieldType = EntityFieldType.Int, Size = 2)]
		public int LineUniquifier { get; set; }

		/// <summary>
		/// Gets or sets LineType
		/// </summary>
        [Display(Name = "Type", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
		public LineType LineType { get; set; }

		/// <summary>
		/// Gets or sets Item
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNoMiscCharge", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.Item, Id = Index.Item, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string Item { get; set; }

		/// <summary>
		/// Gets or sets MiscellaneousChargesCode
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.MiscellaneousChargesCode, Id = Index.MiscellaneousChargesCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string MiscellaneousChargesCode { get; set; }

		/// <summary>
		/// Gets or sets Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string Description { get; set; }

		/// <summary>
		/// Gets or sets ItemAccountSet
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemAccountSet", ResourceType = typeof(InvoiceEntryResx))]
		[ViewField(Name = Fields.ItemAccountSet, Id = Index.ItemAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string ItemAccountSet { get; set; }

		/// <summary>
		/// Gets or sets UserSpecifiedCostingMethod
		/// </summary>
		[ViewField(Name = Fields.UserSpecifiedCostingMethod, Id = Index.UserSpecifiedCostingMethod, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool UserSpecifiedCostingMethod { get; set; }

		/// <summary>
		/// Gets or sets PriceList
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceList", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string PriceList { get; set; }

		/// <summary>
		/// Gets or sets Category
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string Category { get; set; }

		/// <summary>
		/// Gets or sets Location
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string Location { get; set; }

		/// <summary>
		/// Gets or sets PickingSequence
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PickingSequence", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PickingSequence, Id = Index.PickingSequence, FieldType = EntityFieldType.Char, Size = 10)]
		public string PickingSequence { get; set; }

		/// <summary>
		/// Gets or sets Expected Shipment Date
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ShipmentDate", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.ShipmentDate, Id = Index.ShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipmentDate { get; set; }

		/// <summary>
		/// Gets or sets StockItem
		/// </summary>
        [Display(Name = "StockItem", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool StockItem { get; set; }

		/// <summary>
		/// Gets or sets CurrentQuantityOutstanding
		/// </summary>
        [Display(Name = "CurrentQuantityOutstanding", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.CurrentQuantityOutstanding, Id = Index.CurrentQuantityOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal CurrentQuantityOutstanding { get; set; }

		/// <summary>
		/// Gets or sets QuantityInvoiced
		/// </summary>
         [Display(Name = "QtyInvoiced", ResourceType = typeof(OECommonResx))]
		public decimal QuantityInvoiced { get; set; }

		/// <summary>
		/// Gets or sets QuantityBackordered
		/// </summary>
           [Display(Name = "QtyBO", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.QuantityBackordered, Id = Index.QuantityBackordered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityBackordered { get; set; }

		/// <summary>
		/// Gets or sets InvoiceUnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceUOM", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.InvoiceUnitOfMeasure, Id = Index.InvoiceUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string InvoiceUnitOfMeasure { get; set; }

		/// <summary>
		/// Gets or sets UnitConversion
		/// </summary>
		[Display(Name = "UnitConversion", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.UnitConversion, Id = Index.UnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal UnitConversion { get; set; }

		/// <summary>
		/// Gets or sets UnitPrice
		/// </summary>
		[Display(Name = "UnitPrice", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.UnitPrice, Id = Index.UnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal UnitPrice { get; set; }

		/// <summary>
		/// Gets or sets PriceOverride
		/// </summary>
		[Display(Name = "PriceOverride", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PriceOverride, Id = Index.PriceOverride, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool PriceOverride { get; set; }

		/// <summary>
		/// Gets or sets UnitCost
		/// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal? UnitCost { get; set; }

		/// <summary>
		/// Gets or sets MostRecentUnitCost
		/// </summary>
		[Display(Name = "MostRecentUnitCost", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.MostRecentUnitCost, Id = Index.MostRecentUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal? MostRecentUnitCost { get; set; }

		/// <summary>
		/// Gets or sets StandardUnitCost
		/// </summary>
		[Display(Name = "StandardUnitCost", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.StandardUnitCost, Id = Index.StandardUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal? StandardUnitCost { get; set; }

		/// <summary>
		/// Gets or sets AlternateUnitCost1
		/// </summary>
		[Display(Name = "AlternateUnitCost1", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.AlternateUnitCost1, Id = Index.AlternateUnitCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal? AlternateUnitCost1 { get; set; }

		/// <summary>
		/// Gets or sets AlternateUnitCost2
		/// </summary>
		[Display(Name = "AlternateUnitCost2", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.AlternateUnitCost2, Id = Index.AlternateUnitCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal? AlternateUnitCost2 { get; set; }

		/// <summary>
		/// Gets or sets UnitPriceNoOfDecimals
		/// </summary>
        [Display(Name = "UnitPriceNoOfDecimals", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.UnitPriceNoOfDecimals, Id = Index.UnitPriceNoOfDecimals, FieldType = EntityFieldType.Int, Size = 2)]
		public int UnitPriceNoOfDecimals { get; set; }

		/// <summary>
		/// Gets or sets PricingUnit
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingUOM", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PricingUnit, Id = Index.PricingUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string PricingUnit { get; set; }

		/// <summary>
		/// Gets or sets PricingUnitPrice
		/// </summary>
        [Display(Name = "UnitPrice", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PricingUnitPrice, Id = Index.PricingUnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal PricingUnitPrice { get; set; }

		/// <summary>
		/// Gets or sets PricingUnitConversion
		/// </summary>
		[Display(Name = "PricingUnitConversion", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PricingUnitConversion, Id = Index.PricingUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal PricingUnitConversion { get; set; }

		/// <summary>
		/// Gets or sets PriceDiscountPercentage
		/// </summary>
		[Display(Name = "PriceDiscountPercentage", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PriceDiscountPercentage, Id = Index.PriceDiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
		public decimal PriceDiscountPercentage { get; set; }

		/// <summary>
		/// Gets or sets PriceDiscountAmount
		/// </summary>
        [Display(Name = "PriceDiscountAmount", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PriceDiscountAmount, Id = Index.PriceDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal PriceDiscountAmount { get; set; }

		/// <summary>
		/// Gets or sets PricingBaseUnit
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingBaseUnit", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PricingBaseUnit, Id = Index.PricingBaseUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string PricingBaseUnit { get; set; }

		/// <summary>
		/// Gets or sets PricingBaseUnitPrice
		/// </summary>
        [Display(Name = "PricingBaseUnitPrice", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PricingBaseUnitPrice, Id = Index.PricingBaseUnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal PricingBaseUnitPrice { get; set; }

		/// <summary>
		/// Gets or sets PricingBaseUnitConversion
		/// </summary>
        [Display(Name = "PricingBaseUnitConversion", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PricingBaseUnitConversion, Id = Index.PricingBaseUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal PricingBaseUnitConversion { get; set; }

		/// <summary>
		/// Gets or sets CostingUnit
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostingUOM", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.CostingUnit, Id = Index.CostingUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string CostingUnit { get; set; }

		/// <summary>
		/// Gets or sets CostingUnitCost
		/// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.CostingUnitCost, Id = Index.CostingUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal? CostingUnitCost { get; set; }

		/// <summary>
		/// Gets or sets CostingUnitConversion
		/// </summary>
        [Display(Name = "CostingUnitConversion", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.CostingUnitConversion, Id = Index.CostingUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal? CostingUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostingUOM", ResourceType = typeof(OECommonResx))]
        public string CostingUnitOfMeasure { get; set; }

		/// <summary>
		/// Gets or sets ExtendedDetailCost
		/// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ExtendedDetailCost, Id = Index.ExtendedDetailCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal? ExtendedDetailCost { get; set; }

		/// <summary>
		/// Gets or sets ExtendedShippedPriceMiscCha
		/// </summary>
        [Display(Name = "ExtendedPrice", ResourceType = typeof(InvoiceEntryResx))]
		[ViewField(Name = Fields.ExtendedShippedPriceMiscCha, Id = Index.ExtendedShippedPriceMiscCha, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal ExtendedShippedPriceMiscCha { get; set; }

		/// <summary>
		/// Gets or sets InvoiceDiscountAmount
		/// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.InvoiceDiscountAmount, Id = Index.InvoiceDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal InvoiceDiscountAmount { get; set; }

		/// <summary>
		/// Gets or sets ExtendedAmountOverride
		/// </summary>
        [Display(Name = "ExtendedAmountOverride", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ExtendedAmountOverride, Id = Index.ExtendedAmountOverride, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool ExtendedAmountOverride { get; set; }

		/// <summary>
		/// Gets or sets UnitWeight
		/// </summary>
         [Display(Name = "UnitWeight", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.UnitWeight, Id = Index.UnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal UnitWeight { get; set; }

		/// <summary>
		/// Gets or sets ExtendedWeight
		/// </summary>
        [Display(Name = "ExtendedWeight", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal ExtendedWeight { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority1
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string TaxAuthority1 { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority2
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority3
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority4
		/// </summary>
        [Display(Name = "TaxAuthority4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority5
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

		/// <summary>
		/// Gets or sets TaxClass1
		/// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
		public int TaxClass1 { get; set; }

		/// <summary>
		/// Gets or sets TaxClass2
		/// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

		/// <summary>
		/// Gets or sets TaxClass3
		/// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

		/// <summary>
		/// Gets or sets TaxClass4
		/// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

		/// <summary>
		/// Gets or sets TaxClass5
		/// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

		/// <summary>
		/// Gets or sets TaxIncluded1
		/// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded1 { get; set; }

		/// <summary>
		/// Gets or sets TaxIncluded2
		/// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded2 { get; set; }

		/// <summary>
		/// Gets or sets TaxIncluded3
		/// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded3 { get; set; }

		/// <summary>
		/// Gets or sets TaxIncluded4
		/// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded4 { get; set; }

		/// <summary>
		/// Gets or sets TaxIncluded5
		/// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded5 { get; set; }

		/// <summary>
		/// Gets or sets TaxBase1
		/// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

		/// <summary>
		/// Gets or sets TaxBase2
		/// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

		/// <summary>
		/// Gets or sets TaxBase3
		/// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

		/// <summary>
		/// Gets or sets TaxBase4
		/// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

		/// <summary>
		/// Gets or sets TaxBase5
		/// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

		/// <summary>
		/// Gets or sets TaxAmount1
		/// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal TaxAmount1 { get; set; }

		/// <summary>
		/// Gets or sets TaxAmount2
		/// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

		/// <summary>
		/// Gets or sets TaxAmount3
		/// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

		/// <summary>
		/// Gets or sets TaxAmount4
		/// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

		/// <summary>
		/// Gets or sets TaxAmount5
		/// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

		/// <summary>
		/// Gets or sets TaxRate1
		/// </summary>
        [Display(Name = "TaxRate1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate1 { get; set; }

		/// <summary>
		/// Gets or sets TaxRate2
		/// </summary>
        [Display(Name = "TaxRate2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate2 { get; set; }

		/// <summary>
		/// Gets or sets TaxRate3
		/// </summary>
        [Display(Name = "TaxRate3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate3 { get; set; }

		/// <summary>
		/// Gets or sets TaxRate4
		/// </summary>
        [Display(Name = "TaxRate4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate4 { get; set; }

		/// <summary>
		/// Gets or sets TaxRate5
		/// </summary>
        [Display(Name = "TaxRate5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate5 { get; set; }

		/// <summary>
		/// Gets or sets DetailNumber
		/// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

		/// <summary>
		/// Gets or sets HaveCommentsInstructions
		/// </summary>
        [Display(Name = "CommentsInstructions", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.HaveCommentsInstructions, Id = Index.HaveCommentsInstructions, FieldType = EntityFieldType.Bool, Size = 2)]
		public HaveCommentsInstructions HaveCommentsInstructions { get; set; }

		/// <summary>
		/// Gets or sets PriceListDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "PriceListDescription", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PriceListDescription, Id = Index.PriceListDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string PriceListDescription { get; set; }

		/// <summary>
		/// Gets or sets CategoryDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryDescription", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.CategoryDescription, Id = Index.CategoryDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string CategoryDescription { get; set; }

		/// <summary>
		/// Gets or sets LocationDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationDescription", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.LocationDescription, Id = Index.LocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string LocationDescription { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority1Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TaxAuthority1Description", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxAuthority1Description, Id = Index.TaxAuthority1Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string TaxAuthority1Description { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority2Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TaxAuthority2Description", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxAuthority2Description, Id = Index.TaxAuthority2Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string TaxAuthority2Description { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority3Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TaxAuthority3Description", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxAuthority3Description, Id = Index.TaxAuthority3Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string TaxAuthority3Description { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority4Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TaxAuthority4Description", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxAuthority4Description, Id = Index.TaxAuthority4Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string TaxAuthority4Description { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority5Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TaxAuthority5Description", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxAuthority5Description, Id = Index.TaxAuthority5Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string TaxAuthority5Description { get; set; }

		/// <summary>
		/// Gets or sets TaxClass1Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TaxClass1Description", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string TaxClass1Description { get; set; }

		/// <summary>
		/// Gets or sets TaxClass2Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TaxClass2Description", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string TaxClass2Description { get; set; }

		/// <summary>
		/// Gets or sets TaxClass3Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TaxClass3Description", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string TaxClass3Description { get; set; }

		/// <summary>
		/// Gets or sets TaxClass4Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TaxClass4Description", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string TaxClass4Description { get; set; }

		/// <summary>
		/// Gets or sets TaxClass5Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TaxClass5Description", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string TaxClass5Description { get; set; }

		/// <summary>
		/// Gets or sets NonstockClearingAccount
		/// </summary>
		[StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLNonStkClearingAcct", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.NonstockClearingAccount, Id = Index.NonstockClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
		public string NonstockClearingAccount { get; set; }

		/// <summary>
		/// Gets or sets NonstockClearingAcctDesc
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "NonstockClearingAcctDesc", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.NonstockClearingAcctDesc, Id = Index.NonstockClearingAcctDesc, FieldType = EntityFieldType.Char, Size = 60)]
		public string NonstockClearingAcctDesc { get; set; }

		/// <summary>
		/// Gets or sets AverageUnitCost
		/// </summary>
		[Display(Name = "AverageUnitCost", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.AverageUnitCost, Id = Index.AverageUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal? AverageUnitCost { get; set; }

		/// <summary>
		/// Gets or sets LastUnitCost
		/// </summary>
		[Display(Name = "LastUnitCost", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.LastUnitCost, Id = Index.LastUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal? LastUnitCost { get; set; }

		/// <summary>
		/// Gets or sets ShipmentNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumber", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string ShipmentNumber { get; set; }

		/// <summary>
		/// Gets or sets ShipmentDetailLineNumber
		/// </summary>
		[Display(Name = "ShipmentDetailLineNumber", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ShipmentDetailLineNumber, Id = Index.ShipmentDetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int ShipmentDetailLineNumber { get; set; }

		/// <summary>
		/// Gets or sets TotalMostRecentCost
		/// </summary>
		[Display(Name = "TotalMostRecentCost", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TotalMostRecentCost, Id = Index.TotalMostRecentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal? TotalMostRecentCost { get; set; }

		/// <summary>
		/// Gets or sets TotalStandardCost
		/// </summary>
		[Display(Name = "TotalStandardCost", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TotalStandardCost, Id = Index.TotalStandardCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal? TotalStandardCost { get; set; }

		/// <summary>
		/// Gets or sets TotalAlternateCost1
		/// </summary>
		[Display(Name = "TotalAlternateCost1", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TotalAlternateCost1, Id = Index.TotalAlternateCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal? TotalAlternateCost1 { get; set; }

		/// <summary>
		/// Gets or sets TotalAlternateCost2
		/// </summary>
		[Display(Name = "TotalAlternateCost2", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TotalAlternateCost2, Id = Index.TotalAlternateCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal? TotalAlternateCost2 { get; set; }

		/// <summary>
		/// Gets or sets TotalAverageCost
		/// </summary>
		[Display(Name = "TotalAverageCost", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TotalAverageCost, Id = Index.TotalAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal? TotalAverageCost { get; set; }

		/// <summary>
		/// Gets or sets TotalLastCost
		/// </summary>
		[Display(Name = "TotalLastCost", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TotalLastCost, Id = Index.TotalLastCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal? TotalLastCost { get; set; }

		/// <summary>
		/// Gets or sets ShipmentTrackingNumber
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentTrackingNo", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ShipmentTrackingNumber, Id = Index.ShipmentTrackingNumber, FieldType = EntityFieldType.Char, Size = 36)]
		public string ShipmentTrackingNumber { get; set; }

		/// <summary>
		/// Gets or sets ShipViaCode
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipVia", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string ShipViaCode { get; set; }

		/// <summary>
		/// Gets or sets ShipViaCodeDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipViaCodeDescription", ResourceType = typeof(InvoiceEntryResx))]
		[ViewField(Name = Fields.ShipViaCodeDescription, Id = Index.ShipViaCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string ShipViaCodeDescription { get; set; }

		/// <summary>
		/// Gets or sets DiscountPercent
		/// </summary>
     [Display(Name = "DiscountPercent", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.DiscountPercent, Id = Index.DiscountPercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
		public decimal DiscountPercent { get; set; }

		/// <summary>
		/// Gets or sets ExtendedDiscountedPrice
		/// </summary>
      [Display(Name = "ExtendedDiscountedPrice", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ExtendedDiscountedPrice, Id = Index.ExtendedDiscountedPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal ExtendedDiscountedPrice { get; set; }

		/// <summary>
		/// Gets or sets OrderQuantityOrdered
		/// </summary>
        [Display(Name = "QtyOnOrderOrderUOM", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.OrderQuantityOrdered, Id = Index.OrderQuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal OrderQuantityOrdered { get; set; }

		/// <summary>
		/// Gets or sets OrderQuantityBackordered
		/// </summary>
        [Display(Name = "QtyBO", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.OrderQuantityBackordered, Id = Index.OrderQuantityBackordered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal OrderQuantityBackordered { get; set; }

		/// <summary>
		/// Gets or sets OrderQuantityCommitted
		/// </summary>
        [Display(Name = "QtyCommittedOrderUOM", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.OrderQuantityCommitted, Id = Index.OrderQuantityCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal OrderQuantityCommitted { get; set; }

		/// <summary>
		/// Gets or sets OrderQuantityTrueCommitted
		/// </summary>
		[Display(Name = "OrderQuantityTrueCommitted", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.OrderQuantityTrueCommitted, Id = Index.OrderQuantityTrueCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal OrderQuantityTrueCommitted { get; set; }

		/// <summary>
		/// Gets or sets OrderQuantityShippedtodate
		/// </summary>
        [Display(Name = "ShippedToDateOrderUOM", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.OrderQuantityShippedtodate, Id = Index.OrderQuantityShippedtodate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal OrderQuantityShippedtodate { get; set; }

		/// <summary>
		/// Gets or sets OrderUnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "OrderUnitOfMeasure", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.OrderUnitOfMeasure, Id = Index.OrderUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
		public string OrderUnitOfMeasure { get; set; }

		/// <summary>
		/// Gets or sets OrderUnitConversion
		/// </summary>
		[Display(Name = "OrderUnitConversion", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.OrderUnitConversion, Id = Index.OrderUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal OrderUnitConversion { get; set; }

		/// <summary>
		/// Gets or sets ManufacturersItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ManufacturersItemNo", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ManufacturersItemNumber { get; set; }

		/// <summary>
		/// Gets or sets CustomerItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerItemNo", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.CustomerItemNumber, Id = Index.CustomerItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string CustomerItemNumber { get; set; }

		/// <summary>
		/// Gets or sets QuantityCommitted
		/// </summary>
        [Display(Name = "QtyCommitted", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.QuantityCommitted, Id = Index.QuantityCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityCommitted { get; set; }

		/// <summary>
		/// Gets or sets QuantityTrueCommitted
		/// </summary>
		[Display(Name = "QuantityTrueCommitted", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.QuantityTrueCommitted, Id = Index.QuantityTrueCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityTrueCommitted { get; set; }

		/// <summary>
		/// Gets or sets OrderNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string OrderNumber { get; set; }

		/// <summary>
		/// Gets or sets OrderDetailNumber
		/// </summary>
		[Display(Name = "OrderDetailNumber", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.OrderDetailNumber, Id = Index.OrderDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int OrderDetailNumber { get; set; }

		/// <summary>
		/// Gets or sets RefreshOrderQtyatUpdate
		/// </summary>
		[Display(Name = "RefreshOrderQtyatUpdate", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RefreshOrderQtyatUpdate, Id = Index.RefreshOrderQtyatUpdate, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool RefreshOrderQtyatUpdate { get; set; }

		/// <summary>
		/// Gets or sets OriginalQuantityshipped
		/// </summary>
		[Display(Name = "OriginalQuantityshipped", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.OriginalQuantityshipped, Id = Index.OriginalQuantityshipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal OriginalQuantityshipped { get; set; }

		/// <summary>
		/// Gets or sets DrivenbyUI
		/// </summary>
		[Display(Name = "DrivenbyUI", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.DrivenbyUI, Id = Index.DrivenbyUI, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool DrivenbyUI { get; set; }

		/// <summary>
		/// Gets or sets FoundNegativeInventory
		/// </summary>
		[Display(Name = "FoundNegativeInventory", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.FoundNegativeInventory, Id = Index.FoundNegativeInventory, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool FoundNegativeInventory { get; set; }

		/// <summary>
		/// Gets or sets Action
		/// </summary>
		[Display(Name = "Action", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.Action, Id = Index.Action, FieldType = EntityFieldType.Int, Size = 2)]
		public int Action { get; set; }

		/// <summary>
		/// Gets or sets ShipmentUniquifier
		/// </summary>
		[Display(Name = "ShipmentUniquifier", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ShipmentUniquifier, Id = Index.ShipmentUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal ShipmentUniquifier { get; set; }

		/// <summary>
		/// Gets or sets OrderDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "OrderDate", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime OrderDate { get; set; }

		/// <summary>
		/// Gets or sets OptionalFields
		/// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
		public long OptionalFields { get; set; }
        
        /// <summary>
        /// Gets or Sets OptionalFieldString
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
        public string OptionalFieldString { get; set; }

		/// <summary>
		/// Gets or sets KittingBOM
		/// </summary>
		[Display(Name = "KittingBOM", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.KittingBOM, Id = Index.KittingBOM, FieldType = EntityFieldType.Int, Size = 2)]
		public KittingBOM KittingBOM { get; set; }

		/// <summary>
		/// Gets or sets KitBOMNumber
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "KitBOM", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.KitBOMNumber, Id = Index.KitBOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string KitBOMNumber { get; set; }

		/// <summary>
		/// Gets or sets BOMBuildQty
		/// </summary>
		[Display(Name = "BOMBuildQty", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.BOMBuildQty, Id = Index.BOMBuildQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal BOMBuildQty { get; set; }

		/// <summary>
		/// Gets or sets BOMBuildUnit
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "BOMBuildUnit", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.BOMBuildUnit, Id = Index.BOMBuildUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string BOMBuildUnit { get; set; }

		/// <summary>
		/// Gets or sets BOMBuildUnitConversion
		/// </summary>
		[Display(Name = "BOMBuildUnitConversion", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.BOMBuildUnitConversion, Id = Index.BOMBuildUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal BOMBuildUnitConversion { get; set; }

		/// <summary>
		/// Gets or sets UnformattedItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "UnformattedItemNumber", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string UnformattedItemNumber { get; set; }

		/// <summary>
		/// Gets or sets ShipmentLineNumber
		/// </summary>
		[Display(Name = "ShipmentLineNumber", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ShipmentLineNumber, Id = Index.ShipmentLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int ShipmentLineNumber { get; set; }

		/// <summary>
		/// Gets or sets ProcessCommand
		/// </summary>
		[Display(Name = "ProcessCommand", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
		public ProcessCommand ProcessCommand { get; set; }

		/// <summary>
		/// Gets or sets ePOSPromotionID
		/// </summary>
        [Display(Name = "EposPromotionID", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ePOSPromotionID, Id = Index.ePOSPromotionID, FieldType = EntityFieldType.Int, Size = 2)]
		public int ePOSPromotionID { get; set; }

		/// <summary>
		/// Gets or sets SubjectToPaymentDiscount
		/// </summary>
        [Display(Name = "PaymentDiscountable", ResourceType = typeof(InvoiceEntryResx))]
		[ViewField(Name = Fields.SubjectToPaymentDiscount, Id = Index.SubjectToPaymentDiscount, FieldType = EntityFieldType.Int, Size = 2)]
		public SubjectToPaymentDiscount SubjectToPaymentDiscount { get; set; }

		/// <summary>
		/// Gets or sets PaymentDiscountBaseWithTax
		/// </summary>
		[Display(Name = "PaymentDiscountBaseWithTax", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PaymentDiscountBaseWithTax, Id = Index.PaymentDiscountBaseWithTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal PaymentDiscountBaseWithTax { get; set; }

		/// <summary>
		/// Gets or sets PaymentDiscountBaseWithoutTa
		/// </summary>
		[Display(Name = "PaymentDiscountBaseWithoutTax", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PaymentDiscountBaseWithoutTa, Id = Index.PaymentDiscountBaseWithoutTa, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal PaymentDiscountBaseWithoutTa { get; set; }

		/// <summary>
		/// Gets or sets PricingBaseWeightUnit
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "PricingBaseWeightUnit", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PricingBaseWeightUnit, Id = Index.PricingBaseWeightUnit, FieldType = EntityFieldType.Char, Size = 10)]
		public string PricingBaseWeightUnit { get; set; }

		/// <summary>
		/// Gets or sets WeightUnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceWeightUOM", ResourceType = typeof(InvoiceEntryResx))]
		[ViewField(Name = Fields.WeightUnitOfMeasure, Id = Index.WeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
		public string WeightUnitOfMeasure { get; set; }

		/// <summary>
		/// Gets or sets WeightConversionFactor
		/// </summary>
		[Display(Name = "WeightConversionFactor", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.WeightConversionFactor, Id = Index.WeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal WeightConversionFactor { get; set; }

		/// <summary>
		/// Gets or sets PricingWeightUOM
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "PricingWeightUOM", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PricingWeightUOM, Id = Index.PricingWeightUOM, FieldType = EntityFieldType.Char, Size = 10)]
		public string PricingWeightUOM { get; set; }

		/// <summary>
		/// Gets or sets PricingWeightConversionFactor
		/// </summary>
		[Display(Name = "PricingWeightConversionFactor", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PricingWeightConversionFactor, Id = Index.PricingWeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal PricingWeightConversionFactor { get; set; }

		/// <summary>
		/// Gets or sets PricingBaseWeightConvFactor
		/// </summary>
		[Display(Name = "PricingBaseWeightConvFactor", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PricingBaseWeightConvFactor, Id = Index.PricingBaseWeightConvFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal PricingBaseWeightConvFactor { get; set; }

		/// <summary>
		/// Gets or sets DefWeightUOMUnitWeight
		/// </summary>
		[Display(Name = "DefWeightUOMUnitWeight", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.DefWeightUOMUnitWeight, Id = Index.DefWeightUOMUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal DefWeightUOMUnitWeight { get; set; }

		/// <summary>
		/// Gets or sets DefWeightUOMExtUnitWeight
		/// </summary>
		[Display(Name = "DefWeightUOMExtUnitWeight", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.DefWeightUOMExtUnitWeight, Id = Index.DefWeightUOMExtUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal DefWeightUOMExtUnitWeight { get; set; }

		/// <summary>
		/// Gets or sets PriceBy
		/// </summary>
       [Display(Name = "PriceBy", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PriceBy, Id = Index.PriceBy, FieldType = EntityFieldType.Int, Size = 2)]
		public PriceBy PriceBy { get; set; }

		/// <summary>
		/// Gets or sets PriceCheckPending
		/// </summary>
		[Display(Name = "PriceCheckPending", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PriceCheckPending, Id = Index.PriceCheckPending, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool PriceCheckPending { get; set; }

		/// <summary>
		/// Gets or sets PriceApprovedBy
		/// </summary>
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceApprovedBy", ResourceType = typeof(InvoiceEntryResx))]
		[ViewField(Name = Fields.PriceApprovedBy, Id = Index.PriceApprovedBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
		public string PriceApprovedBy { get; set; }

		/// <summary>
		/// Gets or sets ApprovingUsersPassword
		/// </summary>
		[StringLength(64, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ApprovingUsersPassword", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ApprovingUsersPassword, Id = Index.ApprovingUsersPassword, FieldType = EntityFieldType.Char, Size = 64)]
		public string ApprovingUsersPassword { get; set; }

		/// <summary>
		/// Gets or sets PriceApprovalNeeded
		/// </summary>
		[Display(Name = "PriceApproval", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PriceApprovalNeeded, Id = Index.PriceApprovalNeeded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PriceApprovalNeeded { get; set; }

		/// <summary>
		/// Gets or sets WeightUOMDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "WeightUOMDescription", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.WeightUOMDescription, Id = Index.WeightUOMDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string WeightUOMDescription { get; set; }

		/// <summary>
		/// Gets or sets HeaderDiscount
		/// </summary>
		[Display(Name = "HeaderDiscount", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.HeaderDiscount, Id = Index.HeaderDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal HeaderDiscount { get; set; }

		/// <summary>
		/// Gets or sets TRTaxAmount1
		/// </summary>
		[Display(Name = "TRTaxAmount1", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TRTaxAmount1, Id = Index.TRTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal TRTaxAmount1 { get; set; }

		/// <summary>
		/// Gets or sets TRTaxAmount2
		/// </summary>
		[Display(Name = "TRTaxAmount2", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TRTaxAmount2, Id = Index.TRTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal TRTaxAmount2 { get; set; }

		/// <summary>
		/// Gets or sets TRTaxAmount3
		/// </summary>
		[Display(Name = "TRTaxAmount3", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TRTaxAmount3, Id = Index.TRTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal TRTaxAmount3 { get; set; }

		/// <summary>
		/// Gets or sets TRTaxAmount4
		/// </summary>
		[Display(Name = "TRTaxAmount4", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TRTaxAmount4, Id = Index.TRTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal TRTaxAmount4 { get; set; }

		/// <summary>
		/// Gets or sets TRTaxAmount5
		/// </summary>
		[Display(Name = "TRTaxAmount5", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TRTaxAmount5, Id = Index.TRTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal TRTaxAmount5 { get; set; }

		/// <summary>
		/// Gets or sets ExtendedAmountNetOfTax
		/// </summary>
		[Display(Name = "ExtendedAmountNetOfTax", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ExtendedAmountNetOfTax, Id = Index.ExtendedAmountNetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal ExtendedAmountNetOfTax { get; set; }

		/// <summary>
		/// Gets or sets DiscountedExtendedAmount
		/// </summary>
        [Display(Name = "DiscountedExtendedAmount", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.DiscountedExtendedAmount, Id = Index.DiscountedExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DiscountedExtendedAmount { get; set; }

		/// <summary>
		/// Gets or sets TaxTotal
		/// </summary>
		[Display(Name = "TaxTotal", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal TaxTotal { get; set; }

		/// <summary>
		/// Gets or sets TRTaxTotal
		/// </summary>
		[Display(Name = "TRTaxTotal", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TRTaxTotal, Id = Index.TRTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal TRTaxTotal { get; set; }

		/// <summary>
		/// Gets or sets CostOfGoods
		/// </summary>
		[Display(Name = "CostOfGoods", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.CostOfGoods, Id = Index.CostOfGoods, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal? CostOfGoods { get; set; }

		/// <summary>
		/// Gets or sets RecordCosted
		/// </summary>
		[Display(Name = "RecordCosted", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RecordCosted, Id = Index.RecordCosted, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool RecordCosted { get; set; }

		/// <summary>
		/// Gets or sets JobRelated
		/// </summary>
		[Display(Name = "JobRelated", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool JobRelated { get; set; }

		/// <summary>
		/// Gets or sets ContractCode
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ContractCode", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
		public string ContractCode { get; set; }

		/// <summary>
		/// Gets or sets ProjectCode
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ProjectCode", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
		public string ProjectCode { get; set; }

		/// <summary>
		/// Gets or sets CategoryCode
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "CategoryCode", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
		public string CategoryCode { get; set; }

		/// <summary>
		/// Gets or sets CostClass
		/// </summary>
		[Display(Name = "CostClass", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
		public CostClass CostClass { get; set; }

		/// <summary>
		/// Gets or sets ProjectStyle
		/// </summary>
		[Display(Name = "ProjectStyle", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
		public ProjectStyle ProjectStyle { get; set; }

		/// <summary>
		/// Gets or sets ProjectType
		/// </summary>
		[Display(Name = "ProjectType", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
		public ProjectType ProjectType { get; set; }

		/// <summary>
		/// Gets or sets AccountingMethod
		/// </summary>
		[Display(Name = "AccountingMethod", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
		public AccountingMethod AccountingMethod { get; set; }

		/// <summary>
		/// Gets or sets BillingType
		/// </summary>
		[Display(Name = "BillingType", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
		public BillingType BillingType { get; set; }

		/// <summary>
		/// Gets or sets RevenueBillingAccount
		/// </summary>
		[StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "RevenueBillingAccount", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RevenueBillingAccount, Id = Index.RevenueBillingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
		public string RevenueBillingAccount { get; set; }

		/// <summary>
		/// Gets or sets COGSWIPAccount
		/// </summary>
		[StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "COGSWIPAccount", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.COGSWIPAccount, Id = Index.COGSWIPAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
		public string COGSWIPAccount { get; set; }

		/// <summary>
		/// Gets or sets RetainageAmount
		/// </summary>
		[Display(Name = "RetainageAmount", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageAmount { get; set; }

		/// <summary>
		/// Gets or sets RetainagePercent
		/// </summary>
		[Display(Name = "RetainagePercent", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainagePercent, Id = Index.RetainagePercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
		public decimal RetainagePercent { get; set; }

		/// <summary>
		/// Gets or sets RetainageDays
		/// </summary>
		[Display(Name = "RetainageDays", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageDays, Id = Index.RetainageDays, FieldType = EntityFieldType.Int, Size = 2)]
		public int RetainageDays { get; set; }

		/// <summary>
		/// Gets or sets RetainageDueDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "RetainageDueDate", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageDueDate, Id = Index.RetainageDueDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime RetainageDueDate { get; set; }

		/// <summary>
		/// Gets or sets RetainageDueDateOverride
		/// </summary>
		[Display(Name = "RetainageDueDateOverride", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageDueDateOverride, Id = Index.RetainageDueDateOverride, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool RetainageDueDateOverride { get; set; }

		/// <summary>
		/// Gets or sets RetainageAmountOverride
		/// </summary>
		[Display(Name = "RetainageAmountOverride", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageAmountOverride, Id = Index.RetainageAmountOverride, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool RetainageAmountOverride { get; set; }

		/// <summary>
		/// Gets or sets RetainageTaxBase1
		/// </summary>
		[Display(Name = "RetainageTaxBase1", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageTaxBase1 { get; set; }

		/// <summary>
		/// Gets or sets RetainageTaxBase2
		/// </summary>
		[Display(Name = "RetainageTaxBase2", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageTaxBase2 { get; set; }

		/// <summary>
		/// Gets or sets RetainageTaxBase3
		/// </summary>
		[Display(Name = "RetainageTaxBase3", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageTaxBase3 { get; set; }

		/// <summary>
		/// Gets or sets RetainageTaxBase4
		/// </summary>
		[Display(Name = "RetainageTaxBase4", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageTaxBase4 { get; set; }

		/// <summary>
		/// Gets or sets RetainageTaxBase5
		/// </summary>
		[Display(Name = "RetainageTaxBase5", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageTaxBase5 { get; set; }

		/// <summary>
		/// Gets or sets RetainageTaxAmount1
		/// </summary>
		[Display(Name = "RetainageTaxAmount1", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageTaxAmount1, Id = Index.RetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageTaxAmount1 { get; set; }

		/// <summary>
		/// Gets or sets RetainageTaxAmount2
		/// </summary>
		[Display(Name = "RetainageTaxAmount2", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageTaxAmount2, Id = Index.RetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageTaxAmount2 { get; set; }

		/// <summary>
		/// Gets or sets RetainageTaxAmount3
		/// </summary>
		[Display(Name = "RetainageTaxAmount3", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageTaxAmount3, Id = Index.RetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageTaxAmount3 { get; set; }

		/// <summary>
		/// Gets or sets RetainageTaxAmount4
		/// </summary>
		[Display(Name = "RetainageTaxAmount4", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageTaxAmount4, Id = Index.RetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageTaxAmount4 { get; set; }

		/// <summary>
		/// Gets or sets RetainageTaxAmount5
		/// </summary>
		[Display(Name = "RetainageTaxAmount5", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.RetainageTaxAmount5, Id = Index.RetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageTaxAmount5 { get; set; }

		/// <summary>
		/// Gets or sets DefaultOEPrice
		/// </summary>
		[Display(Name = "DefaultOEPrice", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.DefaultOEPrice, Id = Index.DefaultOEPrice, FieldType = EntityFieldType.Int, Size = 2)]
		public DefaultOEPrice DefaultOEPrice { get; set; }

		/// <summary>
		/// Gets or sets Level1Name
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Level1Name", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.Level1Name, Id = Index.Level1Name, FieldType = EntityFieldType.Char, Size = 30)]
		public string Level1Name { get; set; }

		/// <summary>
		/// Gets or sets Level2Name
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Level2Name", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.Level2Name, Id = Index.Level2Name, FieldType = EntityFieldType.Char, Size = 30)]
		public string Level2Name { get; set; }

		/// <summary>
		/// Gets or sets Level3Name
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Level3Name", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.Level3Name, Id = Index.Level3Name, FieldType = EntityFieldType.Char, Size = 30)]
		public string Level3Name { get; set; }

		/// <summary>
		/// Gets or sets UnformattedContractCode
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "UnformattedContractCode", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.UnformattedContractCode, Id = Index.UnformattedContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
		public string UnformattedContractCode { get; set; }

		/// <summary>
		/// Gets or sets PrepaymentDistributed
		/// </summary>
		[Display(Name = "PrepaymentDistributed", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PrepaymentDistributed, Id = Index.PrepaymentDistributed, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal PrepaymentDistributed { get; set; }

		/// <summary>
		/// Gets or sets ExtPriceNetOfDiscIncTax
		/// </summary>
		[Display(Name = "ExtPriceNetOfDiscIncTax", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ExtPriceNetOfDiscIncTax, Id = Index.ExtPriceNetOfDiscIncTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal ExtPriceNetOfDiscIncTax { get; set; }

		/// <summary>
		/// Gets or sets DetailAmountDue
		/// </summary>
		[Display(Name = "DetailAmountDue", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.DetailAmountDue, Id = Index.DetailAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DetailAmountDue { get; set; }

		/// <summary>
		/// Gets or sets SerialQuantity
		/// </summary>
		[Display(Name = "SerialQuantity", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.SerialQuantity, Id = Index.SerialQuantity, FieldType = EntityFieldType.Long, Size = 4)]
		public long SerialQuantity { get; set; }

		/// <summary>
		/// Gets or sets LotQuantity
		/// </summary>
		[Display(Name = "LotQuantity", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal LotQuantity { get; set; }

		/// <summary>
		/// Gets or sets SerialLotQuantityToProcess
		/// </summary>
		[Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal SerialLotQuantityToProcess { get; set; }

		/// <summary>
		/// Gets or sets NumberOfLotsToGenerate
		/// </summary>
		[Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal NumberOfLotsToGenerate { get; set; }

		/// <summary>
		/// Gets or sets QuantityperLot
		/// </summary>
		[Display(Name = "QuantityperLot", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityperLot { get; set; }

		/// <summary>
		/// Gets or sets AllocateFromSerial
		/// </summary>
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "AllocateFromSerial", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
		public string AllocateFromSerial { get; set; }

		/// <summary>
		/// Gets or sets AllocateFromLot
		/// </summary>
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "AllocateFromLot", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
		public string AllocateFromLot { get; set; }

		/// <summary>
		/// Gets or sets ItemSerializedLotted
		/// </summary>
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemSerializedLotted, Id = Index.ItemSerializedLotted, FieldType = EntityFieldType.Int, Size = 2)]
		public ItemSerializedLotted ItemSerializedLotted { get; set; }

		/// <summary>
		/// Gets or sets SerialLotWindowHandle
		/// </summary>
		[Display(Name = "SerialLotWindowHandle", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
		public long SerialLotWindowHandle { get; set; }

		/// <summary>
		/// Gets or sets SageCRMCompanyID
		/// </summary>
		[Display(Name = "SageCRMCompanyID", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.SageCRMCompanyID, Id = Index.SageCRMCompanyID, FieldType = EntityFieldType.Long, Size = 4)]
		public long SageCRMCompanyID { get; set; }

		/// <summary>
		/// Gets or sets SageCRMOpportunityID
		/// </summary>
		[Display(Name = "SageCRMOpportunityID", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.SageCRMOpportunityID, Id = Index.SageCRMOpportunityID, FieldType = EntityFieldType.Long, Size = 4)]
		public long SageCRMOpportunityID { get; set; }

        /// <summary>
        /// Gets or sets Export Declaration Number 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExportDeclarationNumber", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.EDN, Id = Index.EDN, FieldType = EntityFieldType.Char, Size = 30)]
        public string EDN { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<InvoiceCommentsInstruction> InvoiceCommentsInstructions { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<InvoiceDetailOptionalField> InvoiceDetailOptionalFields { get; set; }
        [IgnoreExportImport]
        public EnumerableResponse<InvoiceDetailSerialNumber> InvoiceDetailSerialNumbers { get; set; }
        [IgnoreExportImport]
        public EnumerableResponse<InvoiceDetailLotNumber> InvoiceDetailLotNumbers { get; set; }

	    #region UI Strings

		/// <summary>
		/// Gets LineType string value
		/// </summary>
		public string LineTypeString
		{
			get { return EnumUtility.GetStringValue(LineType); }
		}
		

		/// <summary>
		/// Gets KittingBOM string value
		/// </summary>
		public string KittingBOMString
		{
			get { return EnumUtility.GetStringValue(KittingBOM); }
		}

		/// <summary>
		/// Gets ProcessCommand string value
		/// </summary>
		public string ProcessCommandString
		{
			get { return EnumUtility.GetStringValue(ProcessCommand); }
		}

		/// <summary>
		/// Gets SubjectToPaymentDiscount string value
		/// </summary>
		public string SubjectToPaymentDiscountString
		{
			get { return EnumUtility.GetStringValue(SubjectToPaymentDiscount); }
		}

		/// <summary>
		/// Gets PriceBy string value
		/// </summary>
		public string PriceByString
		{
			get { return EnumUtility.GetStringValue(PriceBy); }
		}		

		/// <summary>
		/// Gets CostClass string value
		/// </summary>
		public string CostClassString
		{
			get { return EnumUtility.GetStringValue(CostClass); }
		}

		/// <summary>
		/// Gets ProjectStyle string value
		/// </summary>
		public string ProjectStyleString
		{
			get { return EnumUtility.GetStringValue(ProjectStyle); }
		}

		/// <summary>
		/// Gets ProjectType string value
		/// </summary>
		public string ProjectTypeString
		{
			get { return EnumUtility.GetStringValue(ProjectType); }
		}

		/// <summary>
		/// Gets AccountingMethod string value
		/// </summary>
		public string AccountingMethodString
		{
			get { return EnumUtility.GetStringValue(AccountingMethod); }
		}

		/// <summary>
		/// Gets BillingType string value
		/// </summary>
		public string BillingTypeString
		{
			get { return EnumUtility.GetStringValue(BillingType); }
		}

		/// <summary>
		/// Gets DefaultOEPrice string value
		/// </summary>
		public string DefaultOEPriceString
		{
			get { return EnumUtility.GetStringValue(DefaultOEPrice); }
		}

		/// <summary>
		/// Gets ItemSerializedLotted string value
		/// </summary>
		public string ItemSerializedLottedString
		{
			get { return EnumUtility.GetStringValue(ItemSerializedLotted); }
		}


		#endregion
	}
}
