﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Class for CreditDebitTaxDetail
    /// </summary>
    public class CreditDebitTaxDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets TaxAuthority
        /// </summary>
        [Key]
        [Display(Name = "TaxAuthority", ResourceType = typeof(OECommonResx))]
        public string TaxAuthorityCode { get; set; }

        /// <summary>
        /// Gets or sets AuthorityDescription
        /// </summary>
        [Display(Name = "AuthorityDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string AuthorityDescription { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxClass
        /// </summary>
        [Display(Name = "CustomerTaxClass", ResourceType = typeof(OECommonResx))]
        public int CustomerTaxClass { get; set; }

        /// <summary>
        /// Gets or sets ClassDescription
        /// </summary>
        [Display(Name = "ClassDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TaxClassDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxBase
        /// </summary>
        [Display(Name = "TaxBase", ResourceType = typeof(OECommonResx))]
        public decimal TaxBase { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount
        /// </summary>
        [Display(Name = "TaxAmount", ResourceType = typeof(OECommonResx))]
        public decimal TaxAmount { get; set; }

        /// <summary>
        /// Gets or sets RegistrationNumber
        /// </summary>
        [Display(Name = "RegistrationNumber", ResourceType = typeof(OECommonResx))]
        public string RegistrationNumber { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        [Display(Name = "SerialNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount
        /// </summary>
        [Display(Name = "TotalTaxTrc", ResourceType = typeof(OECommonResx))]
        public int TaxReportingAmount { get; set; } 
    }
}
