// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Partial class for SalesStatisticsReport
    /// </summary>
    public partial class SalesStatisticsReport : ReportBase
    {

        #region Public properties
        /// <summary>
        /// Gets or sets From Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromYear", ResourceType = typeof(OECommonResx))]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets To Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToYear", ResourceType = typeof(OECommonResx))]
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or sets From Period 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(OECommonResx))]
        public string FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets To Period 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(OECommonResx))]
        public string ToPeriod { get; set; }

        /// <summary>
        /// Gets or sets From Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromCurrency", ResourceType = typeof(OECommonResx))]
        public string FromCurrency { get; set; }

        /// <summary>
        /// Gets or sets To Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToCurrency", ResourceType = typeof(SalesStatisticsReportResx))]
        public string ToCurrency { get; set; }

        /// <summary>
        /// Gets or sets Consolidate Currencies 
        /// </summary>
        [Display(Name = "ConsolidateCurrency", ResourceType = typeof(SalesStatisticsReportResx))]
        public bool ConsolidateCurrencies { get; set; }

        /// <summary>
        /// Gets or sets Quantity Decimals
        /// </summary>
        public string QuantityDecimals { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        public string Decimals { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency
        /// </summary>
        public string Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets Source Currency
        /// </summary>
        [Display(Name = "AmountsIn", ResourceType = typeof(SalesStatisticsReportResx))]
        public CurrencyType SourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets ActiveMulticurrency
        /// </summary>
        public bool ActiveMulticurrency { get; set; }

        /// <summary>
        /// Gets or sets MaxFromPeriod
        /// </summary>
        public int MaxFromPeriod { get; set; }

        /// <summary>
        /// Gets or sets MaxToPeriod
        /// </summary>
        public int MaxToPeriod { get; set; }

        /// <summary>
        /// Gets or sets MinFromPeriod
        /// </summary>
        public int MinFromPeriod { get; set; }

        /// <summary>
        /// Gets or sets MinToPeriod
        /// </summary>
        public int MinToPeriod { get; set; } 
        #endregion

    }
}
