/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// AgedOrderReport class
    /// </summary>
    public partial class AgedOrderReport : ReportBase
    {
        #region Properties
        /// <summary>
        /// Gets or sets Starting Order Number
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string StartOrdNum { get; set; }
        /// <summary>
        /// Gets or sets Ending Order Number 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string EndOrdNum { get; set; }
        /// <summary>
        /// Gets or sets Starting Customer Number 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string StartCustNum { get; set; }
        /// <summary>
        /// Gets or sets Ending Customer Number 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string EndCustNum { get; set; }
        /// <summary>
        /// Gets or sets Starting Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string StartCurr { get; set; }
        /// <summary>
        /// Gets or sets Ending Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string EndCurr { get; set; }
        /// <summary>
        /// Gets or sets the Sort by parameter
        /// </summary>
        [Display(Name = "SortBy", ResourceType = typeof(OECommonResx))]
        public SortBy SortBy { get; set; }
        /// <summary>
        /// Gets or sets the Contact Phone number
        /// </summary>
         [Display(Name = "Contact", ResourceType = typeof(AgedOrdersReportResx))]
        public bool ContactPhone { get; set; }
        /// <summary>
        /// Gets or sets the Comment given in Report
        /// </summary>
         [Display(Name = "SpaceforComments", ResourceType = typeof(AgedOrdersReportResx))]
        public bool Comment { get; set; }
        /// <summary>
        /// Gets or sets the Invoices
        /// </summary>
        [Display(Name = "Invoice", ResourceType = typeof(OECommonResx))]
        public bool Invoices { get; set; }
        /// <summary>
        /// Gets or sets the Report Currency
        /// </summary>
        public string RptCurrency { get; set; }
        /// <summary>
        /// Gets or sets the As of Date
        /// </summary>
          [Display(Name = "AgedAsof", ResourceType = typeof(AgedOrdersReportResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
          )]
        public DateTime? AsOfDate { get; set; }
        /// <summary>
        /// Gets or sets the Cut Off Date
        /// </summary>
        [Display(Name = "CutoffDate", ResourceType = typeof(AgedOrdersReportResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
          )]
        public DateTime? CutOffDate { get; set; }
        /// <summary>
        /// Gets or sets the first Period
        /// </summary>
        public decimal Period1St { get; set; }
        /// <summary>
        /// Gets or sets the 2nd Period
        /// </summary>
        public decimal Period2Nd { get; set; }
        /// <summary>
        /// Gets or sets the 3rd Period
        /// </summary>
        public decimal Period3Rd { get; set; }
        /// <summary>
        /// Gets or sets the first Period
        /// </summary>
        public decimal Current { get; set; }
        /// <summary>
        /// Gets or sets the Phone format
        /// </summary>
        public bool FmtPhone { get; set; }
        /// <summary>
        /// Gets or sets the MultiCurrency
        /// </summary>
        public bool MultiCurr { get; set; }
        /// <summary>
        /// Gets or sets Summary File
        /// </summary>
        public string CurrSummFile { get; set; }
        /// <summary>
        /// get or set FuncOrVendorCurrency
        /// </summary>
        [Display(Name = "PrintAmountsIn", ResourceType = typeof(OECommonResx))]
        public FuncOrCustomerCurrency FunctionalOrVendorCurrency { get; set; }
        #endregion

    }
      
}