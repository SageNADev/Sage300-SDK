/* Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved. */

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
	/// <summary>
	/// Partial class for InvoiceReport
	/// </summary>
	public partial class InvoiceReport : ModuleEmailReportBase
    {
        /// <summary>
        /// Gets or Sets the Qtydec
        /// </summary>
        public int FractionalQuantityDecimals { get; set; }

        /// <summary>
        /// Gets or Sets the Report Formats
        /// </summary>
        public InvoiceReportType ReportFormats { get; set; }

        /// <summary>
        /// Get or set report file name
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets DataBaseType
        /// </summary>
        public int DataBaseType { get; set; }

		/// <summary>
		/// Gets or sets FromInvoice
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "FromInvoice", ResourceType = typeof (InvoicesResx))]
		public string FromInvoice { get; set; }

		/// <summary>
		/// Gets or sets ToInvoice
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToInvoice", ResourceType = typeof(InvoicesResx))]
		public string ToInvoice { get; set; }

        #region Checkboxes

        /// <summary>
        /// Gets or sets IncludeAlreadyPrinted
        /// </summary>
        [Display(Name = "Chkreprint", ResourceType = typeof(InvoicesResx))]
        public bool IncludeAlreadyPrinted { get; set; }

        /// <summary>
        /// Gets or sets IncludePrintSerialLotNumbers
        /// </summary>
        [Display(Name = "PrintSerialLotNumbers", ResourceType = typeof(OECommonResx))]
        public bool IncludePrintSerialLotNumbers { get; set; }

        /// <summary>
        /// Gets or sets IncludeLabel
        /// </summary>
        [Display(Name = "RequireShippingLabels", ResourceType = typeof(OECommonResx))]
        public bool IncludeLabel { get; set; }

        /// <summary>
        /// Gets or sets IncludeBackOrderedItems
        /// </summary>
        [Display(Name = "Chkboitem", ResourceType = typeof(InvoicesResx))]
        public bool IncludeBackOrderedItems { get; set; }

        /// <summary>
        /// Gets or sets IncludePrintKitItems
        /// </summary>
        [Display(Name = "PrintKitComponentItems", ResourceType = typeof(OECommonResx))]
        public bool IncludePrintKitItems { get; set; }

        /// <summary>
        /// Gets or sets IncludePrintBillsOfMaterialItems
        /// </summary>
        [Display(Name = "PrintBOMComponentItems", ResourceType = typeof(OECommonResx))]
        public bool IncludePrintBillsOfMaterialItems { get; set; }

        /// <summary>
        /// Gets or sets Retainage
        /// </summary>
        [Display(Name = "Retainage", ResourceType = typeof(OECommonResx))]
        public bool Retainage { get; set; }

        #endregion
	}
}
