﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region name Spaces

using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// this class is used for TransactionListReport
    /// </summary>
    public partial class TransactionListReport : ReportBase
    {
        #region Order Report Parameter-Summary

        /// <summary>
        /// Gets or sets the type of the print.
        /// </summary>
        public PrintType PrintType { get; set; }

        /// <summary>
        /// Gets or sets the type of the report.
        /// </summary>
        public ReportType ReportType { get; set; }

        /// <summary>
        /// Gets or sets the sort by.
        /// </summary>
        public TransactionListSortBy TransactionListSortBy { get; set; }

        /// <summary>
        /// Gets or sets from order number.
        /// </summary>
        public string FromOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets to order number.
        /// </summary>
        public string ToOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets from invoice number.
        /// </summary>
        public string FromInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets to invoice number.
        /// </summary>
        public string ToInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets from credit debit number.
        /// </summary>
        public string FromCreditDebitNumber { get; set; }

        /// <summary>
        /// Gets or sets to credit debit number.
        /// </summary>
        public string ToCreditDebitNumber { get; set; }

        /// <summary>
        /// Gets or sets from customer.
        /// </summary>
        public string FromCustomer { get; set; }

        /// <summary>
        /// Gets or sets to customer.
        /// </summary>
        public string ToCustomer { get; set; }

        /// <summary>
        /// Gets or sets the multi currency.
        /// </summary>
        public string MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets the sort by.
        /// </summary>
        public string SortBy { get; set; }

        /// <summary>
        /// Gets or sets the from1.
        /// </summary>
         [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string From1 { get; set; }

        /// <summary>
        /// Gets or sets the to1.
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string To1 { get; set; }

        /// <summary>
        /// Gets or sets the from2.
        /// </summary>
       [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string From2 { get; set; }

        /// <summary>
        /// Gets or sets the to2.
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string To2 { get; set; }

        /// <summary>
        /// Gets or sets from currency.
        /// </summary>
        /// <value>
        /// From currency.
        /// </value>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromCurrency { get; set; }

        /// <summary>
        /// Gets or sets to currency.
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToCurrency { get; set; }

        /// <summary>
        /// Gets or sets the entered.
        /// </summary>
        public string Entered { get; set; }

        /// <summary>
        /// Gets or sets the confirmation.
        /// </summary>
        public string Confirmation { get; set; }

        /// <summary>
        /// Gets or sets the picking slip.
        /// </summary>
        /// <value>
        /// The picking slip.
        /// </value>
        public string PickingSlip { get; set; }

        /// <summary>
        /// Gets or sets the never shipped.
        /// </summary>
        public string NeverShipped { get; set; }

        /// <summary>
        /// Gets or sets the part shipped.
        /// </summary>
        public string PartShipped { get; set; }

        /// <summary>
        /// Gets or sets the complete.
        /// </summary>
        public string Complete { get; set; }

        /// <summary>
        /// Gets or sets the on hold.
        /// </summary>
        public string OnHold { get; set; }

        /// <summary>
        /// Gets or sets the active.
        /// </summary>
        public string Active { get; set; }

        /// <summary>
        /// Gets or sets the future.
        /// </summary>
        public string Future { get; set; }

        /// <summary>
        /// Gets or sets the standing.
        /// </summary>
        /// <value>
        /// The standing.
        /// </value>
        public string Standing { get; set; }

        /// <summary>
        /// Gets or sets the quote.
        /// </summary>
        public string Quote { get; set; }

        /// <summary>
        /// Gets or sets the internet.
        /// </summary>
        public string Internet { get; set; }

        /// <summary>
        /// Gets or sets the ex change.
        /// </summary>
        public string Ec { get; set; }

        /// <summary>
        /// Gets or sets the posted.
        /// </summary>
        public string Posted { get; set; }

        /// <summary>
        /// Gets or sets the decimals.
        /// </summary>
        public string Decimals { get; set; }

        /// <summary>
        /// Gets or sets the fromdate.
        /// </summary>
        [Display(Name = "Fromdate", ResourceType = typeof(TransactionListReportResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? Fromdate { get; set; }

        /// <summary>
        /// Gets or sets the todate.
        /// </summary>
        [Display(Name = "Todate", ResourceType = typeof(TransactionListReportResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? Todate { get; set; }

        #endregion

        #region Shipment Report Parameter-Summary

        /// <summary>
        /// From shipment number
        /// </summary>
        public string FromShipmentNumber { get; set; }

        /// <summary>
        /// To shipment number
        /// </summary>
        public string ToShipmentNumber { get; set; }

        #endregion

        #region  Order List Report- Details

        // Few Properties Are in Order Report

        /// <summary>
        /// Gets or sets the information.
        /// </summary>
        public string Information { get; set; }

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the detail.
        /// </summary>
        public string Detail { get; set; }

        /// <summary>
        /// Gets or sets all orders.
        /// </summary>
        public string AllOrders { get; set; }

        /// <summary>
        /// Gets or sets the prepayment.
        /// </summary>
        public string Prepayment { get; set; }

        /// <summary>
        /// Gets or sets the format phone.
        /// </summary>
        public bool FormatPhone { get; set; }

        /// <summary>
        /// Gets or sets the currency summary file.
        /// </summary>
        public string CurrencySummaryFile { get; set; }

        /// <summary>
        /// Gets or sets the factory quantity.
        /// </summary>
        public bool Fractqty { get; set; }

        /// <summary>
        /// Gets or sets the sales persons.
        /// </summary>
        public string SalesPersons { get; set; }

        /// <summary>
        /// Gets or sets the optional fields.
        /// </summary>
        public string OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets the regional format.
        /// </summary>
        public string RegionalFormat { get; set; }

        /// <summary>
        /// Gets or sets the tax information.
        /// </summary>
        public string TaxInformation { get; set; }

        /// <summary>
        /// Gets or sets the SWPM active.
        /// </summary>
        public string SwpmActive { get; set; }

        /// <summary>
        /// Gets or sets the swincljob.
        /// </summary>
        public string Swincljob { get; set; }

        /// <summary>
        /// Gets or sets the name of the level1.
        /// </summary>
        public string Level1Name { get; set; }

        /// <summary>
        /// Gets or sets the name of the level2.
        /// </summary>
        public string Level2Name { get; set; }

        /// <summary>
        /// Gets or sets the name of the level3.
        /// </summary>
        public string Level3Name { get; set; }

        /// <summary>
        /// Gets or sets the sw retainage.
        /// </summary>
        public string SwRetainage { get; set; }

        /// <summary>
        /// Gets or sets the ar retainage.
        /// </summary>
        public string ArRetainage { get; set; }

        /// <summary>
        /// Gets or sets the serial lot numbers.
        /// </summary>
        public string SerialLotNumbers { get; set; }

        /// <summary>
        /// Gets or sets the swsnltlic.
        /// </summary>
        public string Swsnltlic { get; set; }

        #endregion

        #region CheckBoxes

        [Display(Name = "CheckIncludeOrderInfo", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkOrderInformation { get; set; }

        [Display(Name = "CheckIncludeOrderDetails", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkDetails { get; set; }

        [Display(Name = "CheckIncludeAddresses", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkAddress { get; set; }

        [Display(Name = "CheckIncludeTaxInformation", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkTaxInformation { get; set; }

        [Display(Name = "CheckIncludeSalespersons", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkSalesperson { get; set; }

        [Display(Name = "CheckIncludePrepayments", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkPrepayments { get; set; }

        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
        public bool ChkOptionalFields { get; set; }

        [Display(Name = "JobDetails", ResourceType = typeof(OECommonResx))]
        public bool ChkJobDetails { get; set; }

        [Display(Name = "RetainageDetails", ResourceType = typeof(OECommonResx))]
        public bool ChkRetainageDetails { get; set; }

        [Display(Name = "SerialLotNumbers", ResourceType = typeof(OECommonResx))]
        public bool ChkSerialAndLotNumber { get; set; }

        [Display(Name = "CheckOrderstatusPartiallyShipped", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkPartiallyShipped { get; set; }

        [Display(Name = "CheckOrderstatusNeverShipped", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkNeverShipped { get; set; }

        [Display(Name = "OnHold", ResourceType = typeof(OECommonResx))]
        public bool ChkOnHold { get; set; }

        [Display(Name = "Entered", ResourceType = typeof(OECommonResx))]
        public bool ChkEntered { get; set; }

        [Display(Name = "Internet", ResourceType = typeof(OECommonResx))]
        public bool ChkInternet { get; set; }

        [Display(Name = "Completed", ResourceType = typeof(OECommonResx))]
        public bool ChkCompleted { get; set; }

        [Display(Name = "PickingSlipPrinted", ResourceType = typeof(OECommonResx))]
        public bool ChkPickingSlipPrinted { get; set; }

        [Display(Name = "ConfirmationPrinted", ResourceType = typeof(OECommonResx))]
        public bool ChkConfirmationPrinted { get; set; }

        [Display(Name = "Active", ResourceType = typeof(OECommonResx))]
        public bool ChkActive { get; set; }

        [Display(Name = "Future", ResourceType = typeof(OECommonResx))]
        public bool ChkFuture { get; set; }

        [Display(Name = "Future", ResourceType = typeof(OECommonResx))]
        public bool ChkStanding { get; set; }

        [Display(Name = "Quote", ResourceType = typeof(OECommonResx))]
        public bool ChkQuote { get; set; }

        [Display(Name = "Posted", ResourceType = typeof(OECommonResx))]
        public bool ChkPosted { get; set; }

        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
        public bool ChkIncludeOptionalFields { get; set; }

        [Display(Name = "CheckIncludeShipmentInfo", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkShipmentInfo { get; set; }

        [Display(Name = "CheckIncludeShipmentDetails", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkShipmentDetails { get; set; }

        [Display(Name = "CheckIncludeInvoiceInfo", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkInvoiceInfo { get; set; }

        [Display(Name = "CheckIncludeInvoiceDetails", ResourceType = typeof(TransactionListReportResx))]
        public bool ChkInvoiceDetails { get; set; }


        /// <summary>
        /// Get or set for MultiCurrency
        /// </summary>
        public bool IsMultiCurrrency { get; set; }

        /// <summary>
        /// Get or set for MultiCurrency
        /// </summary>
        public string ThenBy { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from date disable.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is from date disable; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromDateDisable { get; set; }

        #endregion
    }
}
