﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Class for Salesperson Commissions Report
    /// </summary>
    public partial class SalespersonCommissionReport : ReportBase
    {
        #region Public properties

        /// <summary>
        /// Gets or Sets PrintType
        /// </summary>
        [Display(Name = "Print", ResourceType = typeof(CommonResx))]
        public ReportType PrintType { get; set; }

        /// <summary>
        /// Gets or Sets SelectBy
        /// </summary>
        public SelectsBy SelectBy { get; set; }

        /// <summary>
        /// Gets or Sets Include Commission Type
        /// </summary>
        [Display(Name = "CommType", ResourceType = typeof(SalespersonCommissionsReportResx))]
        public bool IncludeCommissionType { get; set; }

        /// <summary>
        /// Gets or Sets FromDate
        /// </summary>
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or Sets ToDate
        /// </summary>
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ToDate { get; set; }
        
        /// <summary>
        /// Gets or sets From Fiscal Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets From Period 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets To Fiscal Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or sets To Period 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToPeriod { get; set; }

        /// <summary>
        /// Gets or Sets From SalesPerson
        /// </summary>
        public string FromSalesPerson { get; set; }

        /// <summary>
        /// Gets or Sets To SalesPerson
        /// </summary>
        public string ToSalesPerson { get; set; }
        
        /// <summary>
        /// Gets or Sets SortBy
        /// </summary>
        public SortsBy SortBy { get; set; }

        /// <summary>
        /// Gets or Sets Subtotal
        /// </summary>
        [Display(Name = "SubTotal", ResourceType = typeof(SalespersonCommissionsReportResx))]
        public bool Subtotal { get; set; }

        /// <summary>
        /// Gets or Sets Decimals
        /// </summary>
        public decimal Decimals { get; set; }

        /// <summary>
        /// Gets or Sets CommissionType
        /// </summary>
        public string CommissionType { get; set; }
        
        #endregion
    }
}
