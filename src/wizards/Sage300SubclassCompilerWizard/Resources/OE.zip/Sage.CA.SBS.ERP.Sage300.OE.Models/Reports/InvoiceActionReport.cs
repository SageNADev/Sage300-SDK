﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Class for Invoice Action Report
    /// </summary>
    public partial class InvoiceActionReport : ReportBase
    {
        #region Public properties

        /// <summary>
        /// Gets or Sets Type
        /// </summary>
        [Display(Name = "ReportType", ResourceType = typeof(OECommonResx))]
        public ReportType ReportType { get; set; }

        /// <summary>
        /// Gets or Sets Fully Shipped
        /// </summary>
        [Display(Name = "OrdersFullyShipped", ResourceType = typeof(Resources.Reports.InvoiceActionReport))]
        public bool FullyShipped { get; set; }

        /// <summary>
        /// Gets or Sets Partially Shipped
        /// </summary>
        [Display(Name = "OrdersPartiallyShipped", ResourceType = typeof(Resources.Reports.InvoiceActionReport))]
        public bool PartiallyShipped { get; set; }

        /// <summary>
        /// Gets or Sets Not Invoiced
        /// </summary>
        [Display(Name = "OrdersNotInvoiced", ResourceType = typeof(Resources.Reports.InvoiceActionReport))]
        public bool NotInvoiced { get; set; }

        /// <summary>
        /// Gets or Sets FromDate
        /// </summary>
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or Sets ToDate
        /// </summary>
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ToDate { get; set; }

        /// <summary>
        /// Gets or Sets Partially Invoiced
        /// </summary>
        [Display(Name = "OrdersPartiallyInvoiced", ResourceType = typeof(Resources.Reports.InvoiceActionReport))]
        public bool PartiallyInvoiced { get; set; }

        /// <summary>
        /// Gets or Sets Fully Invoiced
        /// </summary>
        [Display(Name = "OrdersFullyInvoiced", ResourceType = typeof(Resources.Reports.InvoiceActionReport))]
        public bool FullyInvoiced { get; set; }
        
        /// <summary>
        /// Gets or Sets SelectBy
        /// </summary>
        public SelectBy SelectBy { get; set; }

        /// <summary>
        /// Gets or Sets SelectByFrom
        /// </summary>
        public string SelectByFrom { get; set; }

        /// <summary>
        /// Gets or Sets SelectByTo
        /// </summary>
        public string SelectByTo { get; set; }

        /// <summary>
        /// Gets or Sets OrderNumber
        /// </summary>
         [Display(Name = "OrderNumber", ResourceType = typeof(OECommonResx))]
        public string OrderNumber { get; set; }

         /// <summary>
         /// Gets or Sets ShipmentNumber
         /// </summary>
         [Display(Name = "ShipmentNumber", ResourceType = typeof(OECommonResx))]
         public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or Sets From Order
        /// </summary>
        public string FromOrderNumber { get; set; }

        /// <summary>
        /// Gets or Sets ToOrder
        /// </summary>
        public string ToOrderNumber { get; set; }
        
        /// <summary>
        /// Gets or Sets From Shipment
        /// </summary>
        public string FromShipmentNumber { get; set; }

        /// <summary>
        /// Gets or Sets To Shipment
        /// </summary>
        public string ToShipmentNumber { get; set; }
        
        /// <summary>
        /// Gets or Sets Then By
        /// </summary>
        [Display(Name = "ThenBy", ResourceType = typeof(OECommonResx))]
        public ThenBy ThenBy { get; set; }

        /// <summary>
        /// Gets or Sets Then By From
        /// </summary>
        public string ThenByFrom { get; set; }

        /// <summary>
        /// Gets or Sets Then By To
        /// </summary>
        public string ThenByTo { get; set; }

        /// <summary>
        /// Gets or Sets None
        /// </summary>
        [Display(Name = "None", ResourceType = typeof(OECommonResx))]
        public string None { get; set; }

         /// <summary>
        /// Gets or Sets CustomerNumber
        /// </summary>
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or Sets PrimarySalesPerson
        /// </summary>
        [Display(Name = "Primary", ResourceType = typeof(OECommonResx))]
        public string PrimarySalesPerson { get; set; }

        /// <summary>
        /// Gets or Sets FromCustomerNumber
        /// </summary>
        public string FromCustomerNumber { get; set; }

        /// <summary>
        /// Gets or Sets ToCustomerNumber
        /// </summary>
        public string ToCustomerNumber { get; set; }

        /// <summary>
        /// Gets or Sets FromPrimarySalesPerson
        /// </summary>
        public string FromPrimarySalesPerson { get; set; }

        /// <summary>
        /// Gets or Sets ToPrimarySalesPerson
        /// </summary>
        public string ToPrimarySalesPerson { get; set; }

        
        /// <summary>
        /// Gets or Sets FuncOrVendorCurrency
        /// </summary>
        public PrintAmountIn PrintAmountIn { get; set; }


        /// <summary>
        /// Gets or Sets FuncOrVendorCurrency
        /// </summary>
        [Display(Name = "OrderType", ResourceType = typeof(OECommonResx))]
        public string OrderType { get; set; }

        /// <summary>
        /// Gets or Sets HomeCurrency
        /// </summary>
        public string SourceCurrency { get; set; }

        /// <summary>
        /// Gets or Sets VendorCurrency
        /// </summary>
        public string CustomerCurrency { get; set; }
        
        /// <summary>
        /// Gets or Sets QtyDecs
        /// </summary>
        public decimal QtyDecs { get; set; }

        /// <summary>
        /// Gets or Sets FuncDecs
        /// </summary>
        public decimal FuncDecs { get; set; }

        /// <summary>
        /// Gets or Sets MultiCurrency
        /// </summary>
        public bool MultiCurrency { get; set; }

        /// <summary>
        /// Gets or Sets PMActive
        /// </summary>
        public bool PmActive { get; set; }

        /// <summary>
        /// Gets or Sets SWPMActive
        /// </summary>
        public int SwpmActive { get; set; }

        /// <summary>
        /// Gets or Sets SWInclJob
        /// </summary>
        public string SwInclJob { get; set; }

           /// <summary>
        /// Gets or Sets Level1Name
        /// </summary>
        public string Level1Name { get; set; }

           /// <summary>
        /// Gets or Sets Level2Name
        /// </summary>
        public string Level2Name { get; set; }

          /// <summary>
        /// Gets or Sets Level3Name
        /// </summary>
        public string Level3Name { get; set; }
       #endregion
    }
}
