﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Class for Order Action Report
    /// </summary>
    public partial class OrderActionReport : ReportBase
    {
        #region Public properties

        /// <summary>
        /// Gets or Sets Report Type
        /// </summary>
        [Display(Name = "ReportType", ResourceType = typeof(OECommonResx))]
        public ReportType ReportType { get; set; }

        /// <summary>
        /// Gets or Sets Order Type
        /// </summary>
        [Display(Name = "OrderType", ResourceType = typeof(OECommonResx))]
        public OrderTypeOrderAction OrderType { get; set; }

        /// <summary>
        /// Gets or Sets Print Status
        /// </summary>
        [Display(Name = "PrintStatus", ResourceType = typeof(OrderActionReportResx))]
        public PrintStatus PrintStatus { get; set; }

        /// <summary>
        /// Gets or Sets Item Status
        /// </summary>
        [Display(Name = "ItemStatus", ResourceType = typeof(OrderActionReportResx))]
        public ItemStatus ItemStatus { get; set; }

        /// <summary>
        /// Gets or Sets SortBy
        /// </summary>
        public SortByOrderAction SortBy { get; set; }
        
        /// <summary>
        /// Gets or Sets Home Currency Decimal
        /// </summary>
        public string Decimal { get; set; }

        /// <summary>
        /// Gets or Sets SourceCurrency
        /// </summary>
        public string SourceCurrency { get; set; }

        /// <summary>
        /// Gets or Sets boolean MultiCurrency
        /// </summary>
        public bool MultiCurrency { get; set; }

        /// <summary>
        /// Gets or Sets MultiCurrency
        /// </summary>
        public string MultiCurr { get; set; }

        /// <summary>
        /// Gets or Sets Start Sort
        /// </summary>
        public string StartSort { get; set; }

        /// <summary>
        /// Gets or Sets End Sort
        /// </summary>
        public string EndSort { get; set; }

        /// <summary>
        /// Gets or Sets FromDate
        /// </summary>
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromShipDate { get; set; }

        /// <summary>
        /// Gets or Sets ToDate
        /// </summary>
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ToShipDate { get; set; }

        /// <summary>
        /// Gets or Sets FuncOrVendorCurrency
        /// </summary>
        [Display(Name = "ItemStatus", ResourceType = typeof(OrderActionReportResx))]
        public OrderSourceOrderAction OrderSource { get; set; }

        /// <summary>
        /// Gets or Sets OrderNumber
        /// </summary>
         [Display(Name = "OrderNumber", ResourceType = typeof(OECommonResx))]
        public string OrderNumber { get; set; }

         /// <summary>
        /// Gets or Sets CustomerNumber
        /// </summary>
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or Sets PrimarySalesPerson
        /// </summary>
        [Display(Name = "PrimarySalesPerson", ResourceType = typeof(OECommonResx))]
        public string PrimarySalesPerson { get; set; }

        /// <summary>
        /// Gets or Sets Functional Or CustomerCurrency
        /// </summary>
        public PrintAmountIn PrintAmountIn { get; set; }

        /// <summary>
        /// Gets or Sets PMActive
        /// </summary>
        public bool PmActive { get; set; }

        /// <summary>
        /// Gets or Sets SWPMActive
        /// </summary>
        public int SwpmActive { get; set; }

        /// <summary>
        /// Gets or Sets SWInclJob
        /// </summary>
        public string SwInclJob { get; set; }

           /// <summary>
        /// Gets or Sets Level1Name
        /// </summary>
        public string Level1Name { get; set; }

           /// <summary>
        /// Gets or Sets Level2Name
        /// </summary>
        public string Level2Name { get; set; }

          /// <summary>
        /// Gets or Sets Level3Name
        /// </summary>
        public string Level3Name { get; set; }
       #endregion
    }
}
