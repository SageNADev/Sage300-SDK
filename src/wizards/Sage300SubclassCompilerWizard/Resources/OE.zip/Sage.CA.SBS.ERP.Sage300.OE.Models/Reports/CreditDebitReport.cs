/* Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
	/// <summary>
	/// Partial class for CreditDebitReport
	/// </summary>
	public partial class CreditDebitReport : ModuleEmailReportBase
	{
        /// <summary>
        /// Get or Set the UseNote property
        /// </summary>
        public UseNote UseNote { get; set; }

        /// <summary>
        /// Get or set report file name
        /// </summary>
        public string FileName { get; set; }

		/// <summary>
		/// Gets or sets Sortfrom
		/// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		public string Sortfrom { get; set; }

        /// <summary>
        /// Get or set selection criteria
        /// </summary>
        public string SelectionCriteria { get; set; }

		/// <summary>
		/// Gets or sets Sortto
		/// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		public string Sortto { get; set; }

		/// <summary>
		/// Gets or sets Printed
		/// </summary>
		public bool Printed { get; set; }

		/// <summary>
		/// Gets or sets Qtydec
		/// </summary>
        public decimal Qtydec { get; set; }

		/// <summary>
		/// Gets or sets Adjtype
		/// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(OECommonResx))]
        public CreditDebitNoteType Adjtype { get; set; }

        /// <summary>
        /// Get or Set the PrintKit property
        /// </summary>  
        [Display(Name = "PrintKitComponentItems", ResourceType = typeof(OECommonResx))]
        public bool PrintKit { get; set; }

        /// <summary>
        /// Get or Set the PrintBills property
        /// </summary> 
        [Display(Name = "PrintBOMComponentItems", ResourceType = typeof(OECommonResx))]
        public bool PrintBills { get; set; }

		/// <summary>
		/// Gets or sets Taxinformation
		/// </summary>
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		public string Taxinformation { get; set; }

		/// <summary>
		/// Gets or sets Retainage
		/// </summary>
		public bool Retainage { get; set; }

		/// <summary>
		/// Gets or sets Seriallotnumbers
		/// </summary>
        [Display(Name = "PrintSerialLotNumbers", ResourceType = typeof(OECommonResx))]
		public bool SerialLotNumbers { get; set; }

        /// <summary>
        /// Gets or sets Report Name
        /// </summary>
        public string ReportName { get; set; }

        /// <summary>
        /// Gets or sets DataBaseType
        /// </summary>
        public int DataBaseType { get; set; }
	}
}
