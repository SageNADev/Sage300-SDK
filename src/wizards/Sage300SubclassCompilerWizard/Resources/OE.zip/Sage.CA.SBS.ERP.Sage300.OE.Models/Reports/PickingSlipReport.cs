/* Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// This class is used to generate the report for PickingSlipReport
    /// </summary>
    public partial class PickingSlipReport : ReportBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or Sets the IsPrintedDirect
        /// </summary>
        public bool IsPrintedDirect { get; set; }

        /// <summary>
        /// Gets or Sets the Qtydec
        /// </summary>
        public int FractionalQuantityDecimals { get; set; }

        /// <summary>
        /// Gets or Sets the Report Formats
        /// </summary>
        public PickingSlipReportType ReportFormats { get; set; }

        /// <summary>
        /// Get or set report file name
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets Selectby
        /// </summary>
        public PickingSlipSelectBy SelectBy { get; set; }

        /// <summary>
        /// Gets or sets Sortby
        /// </summary>
        public PickingSlipSortBy SortBy { get; set; }

        /// <summary>
        /// Gets or sets Printby
        /// </summary>
        public PickingSlipPrintBy PrintBy { get; set; }

        /// <summary>
        /// Gets or sets Fromselect
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromSelect { get; set; }

        /// <summary>
        /// Gets or sets Toselect
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToSelect { get; set; }

        /// <summary>
        /// Gets or sets Fromloc
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromLocation", ResourceType = typeof(PickingSlipsResx))]
        public string FromLocation { get; set; }

        /// <summary>
        /// Gets or sets Toloc
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToLocation", ResourceType = typeof(PickingSlipsResx))]
        public string ToLocation { get; set; }

        /// <summary>
        /// Gets or sets Completed
        /// </summary>
        public string Completed { get; set; }

        /// <summary>
        /// Gets or Sets DefaultToSelect
        /// </summary>
        public string DefaultToSelect { get; set; }

        /// <summary>
        /// Gets or sets Reprint
        /// </summary>
        [Display(Name = "IncludePSPrinted", ResourceType = typeof(PickingSlipsResx))]
        public bool IncludeAlreadyPrinted { get; set; }

        /// <summary>
        /// Gets or sets Seriallotnumbers
        /// </summary>
        [Display(Name = "SerialLotNumbers", ResourceType = typeof(OECommonResx))]
        public bool SerialLotNumbers { get; set; }

        /// <summary>
        /// Gets or sets Printbom
        /// </summary>
        [Display(Name = "RequireShippingLabels", ResourceType = typeof(OECommonResx))]
        public bool RequireShippingLabels { get; set; }

        /// <summary>
        /// Gets or sets Printkit
        /// </summary>
        [Display(Name = "PrintKitComponentItems", ResourceType = typeof(OECommonResx))]
        public bool PrintKitComponentItems { get; set; }

        /// <summary>
        /// Gets or sets Printbom
        /// </summary>
        [Display(Name = "PrintBOMComponentItems", ResourceType = typeof(OECommonResx))]
        public bool PrintBomComponentItems { get; set; }

        /// <summary>
        /// Gets or sets Seshndl
        /// </summary>
        public string Seshndl { get; set; }

        #endregion
    }
}
