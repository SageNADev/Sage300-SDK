﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    public partial class ShippingLabelReport : ReportBase
    {
        /// <summary>
        /// Gets or sets SelectItem
        /// </summary>
        [Display(Name = "UseLabel", ResourceType = typeof(ShippingLabelsResx))]
        public UseLabel Label { get; set; }

        /// <summary>
        /// Gets or Sets the FunDec
        /// </summary>
        public decimal FunDec { get; set; }

        /// <summary>
        /// Gets or sets SortBy
        /// </summary>
        [Display(Name = "Select", ResourceType = typeof(ShippingLabelsResx))]
        public SelectItem SortBy { get; set; }

        /// <summary>
        /// Gets or sets SortFrom
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        public string SortFrom { get; set; }

        /// <summary>
        /// Gets or sets SortTo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        public string SortTo { get; set; }

        /// <summary>
        /// Gets or sets IncludePrinted
        /// </summary>
        [Display(Name = "IncludeLabelsPrinted", ResourceType = typeof(ShippingLabelsResx))]
        public bool IncludePrinted { get; set; }

        /// <summary>
        /// Gets or sets RequiredOption
        /// </summary>
        [Display(Name = "PrintOnlyLabelsMarked", ResourceType = typeof(ShippingLabelsResx))]
        public bool RequiredOption { get; set; }

        /// <summary>
        /// Gets or Sets the Alignment
        /// </summary>
        public bool Alignment { get; set; }

        /// <summary>
        /// Gets or Sets the IsLabelMarked
        /// </summary>
        public bool IsLabelMarked { get; set; }

        /// <summary>
        /// Get or set report file name
        /// </summary>
        public string FileName { get; set; }
    }
}
