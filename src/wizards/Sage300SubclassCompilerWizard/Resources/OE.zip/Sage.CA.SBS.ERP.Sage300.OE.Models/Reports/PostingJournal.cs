// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Partial class for PostingJournal
    /// </summary>
    public partial class PostingJournal : ReportBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or sets the Select By PostingJournal 
        /// </summary>
        public SelectByPostingJournal SelectByPostingJournal { get; set; }

        /// <summary>
        /// Gets or sets the Sort By PostingJournal 
        /// </summary>
        public SortByPostingJournal SortByPostingJournal { get; set; }

        /// <summary>
        /// Gets or sets the Sort From
        /// </summary>
        [Display(Name = "FromDayEndNumber", ResourceType = typeof(CommonResx))]
        public int SortFrom { get; set; }

        /// <summary>
        /// Gets or sets the Sort To 
        /// </summary>
        [Display(Name = "ToDayEndNumber", ResourceType = typeof(CommonResx))]
        public int SortTo { get; set; }

        /// <summary>
        /// Gets or sets the Sales Split 
        /// </summary>
        [Display(Name = "InclSalesSplit", ResourceType = typeof(PostingJournalResx))]
        public bool SalesSplit { get; set; }

        /// <summary>
        /// Gets or sets the Fractional 
        /// </summary>
        public int Fractional { get; set; }

        /// <summary>
        /// Gets or sets the Home currency 
        /// </summary>
        public string Homecurrency { get; set; }

        /// <summary>
        /// Gets or sets the Tax Summary 
        /// </summary>
        [Display(Name = "TaxSummary", ResourceType = typeof(PostingJournalResx))]
        public bool TaxSummary { get; set; }

        /// <summary>
        /// Gets or sets the GLActive 
        /// </summary>
        public bool IsGlActive { get; set; }

        /// <summary>
        /// Gets or sets the AR Audit Option 
        /// </summary>
        [Display(Name = "InclARAudit", ResourceType = typeof(PostingJournalResx))]
        public bool ArAuditOption { get; set; }

        /// <summary>
        /// Gets or sets the Tax Information 
        /// </summary>
        [Display(Name = "TaxReport", ResourceType = typeof(PostingJournalResx))]
        public bool TaxInformation { get; set; }

        /// <summary>
        /// Gets or sets the Is PM Active 
        /// </summary>
        public bool IsPmActive { get; set; }

        /// <summary>
        /// Gets or sets the Has Detail OptionalField 
        /// </summary>
        public bool HasDetailOptionalField { get; set; }

        /// <summary>
        /// Gets or sets the AR file 
        /// </summary>
        public string ArFile { get; set; }

        /// <summary>
        /// Gets or sets the GL File 
        /// </summary>
        public string GlFile { get; set; }

        /// <summary>
        /// Gets or sets the CurrentFile
        /// </summary>
        public string CurrentFile { get; set; }

        /// <summary>
        /// Gets or sets Common Posting Journal Properties
        /// </summary>
        public CommonPostingJournal CommonPostingJournal { get; set; }

        #endregion
    }
}
