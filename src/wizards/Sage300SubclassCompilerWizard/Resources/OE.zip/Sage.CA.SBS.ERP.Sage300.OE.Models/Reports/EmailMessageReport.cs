// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Partial class for EmailMessageReport
    /// </summary>
    public partial class EmailMessageReport : ReportBase
    {
        /// <summary>
        /// Gets or sets Reporttype
        /// </summary>
        public string Reporttype { get; set; }
    }
}
