/* Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// This class is used to generate the report for Order Confirmation Report
    /// </summary>
    public partial class OrderConfirmationReport : ModuleEmailReportBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or Sets the Printed property
        /// </summary>
        public bool Printed { get; set; }

        /// <summary>
        /// Gets or Sets the IsPrintedDirect
        /// </summary>
        public bool IsPrintedDirect { get; set; }

        /// <summary>
        /// Gets or Sets the Qtydec
        /// </summary>
        public int FractionalQuantityDecimals { get; set; }

        /// <summary>
        /// Gets or Sets the OrderNumber
        /// </summary>
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or Sets the OnHold
        /// </summary>
        public int OnHold { get; set; }

        /// <summary>
        /// Gets or Sets the Type
        /// </summary>
        public OrderType OrderType { get; set; }

        /// <summary>
        /// Gets or Sets the PrintStat
        /// </summary>
        public OrderPrintStatus PrintStatus { get; set; }

        /// <summary>
        /// Gets or Sets the Report Formats
        /// </summary>
        public OrderConfirmationReportType ReportFormats { get; set; }

        /// <summary>
        /// Get or set report file name
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets FromOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromOrderNumber", ResourceType = typeof(OECommonResx))]
        public string FromOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets ToOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToOrderNumber", ResourceType = typeof(OECommonResx))]
        public string ToOrderNumber { get; set; }

        /// <summary>
        /// Get or set selection criteria
        /// </summary>
        public string SelectionCriteria { get; set; }

        /// <summary>
        /// Gets or sets DataBaseType
        /// </summary>
        public int DataBaseType { get; set; }

        #endregion

        #region CheckBoxes

        [Display(Name = "Chkreprint", ResourceType = typeof(OrderConfirmationsResx))]
        public bool IncludeReprint { get; set; }

        [Display(Name = "PrintSerialLotNumbers", ResourceType = typeof(OECommonResx))]
        public bool IncludePrintSerialLotNumbers { get; set; }

        [Display(Name = "RequireShippingLabels", ResourceType = typeof(OECommonResx))]
        public bool IncludeLabel { get; set; }

        [Display(Name = "PrintKitComponentItems", ResourceType = typeof(OECommonResx))]
        public bool IncludePrintKitItems { get; set; }

        [Display(Name = "PrintBOMComponentItems", ResourceType = typeof(OECommonResx))]
        public bool IncludePrintBillsOfMaterialItems { get; set; }

        [Display(Name = "Printonholdorders", ResourceType = typeof(OrderConfirmationsResx))]
        public bool IncludePrintOnHoldOrders { get; set; }

        #endregion
    }
}
