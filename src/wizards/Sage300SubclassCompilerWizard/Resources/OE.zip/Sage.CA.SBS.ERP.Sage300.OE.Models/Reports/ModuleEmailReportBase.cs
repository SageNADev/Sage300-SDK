﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Email;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    public class ModuleEmailReportBase : EmailReportBase
    {
        /// <summary>
        /// Gets or Sets the delivery method
        /// </summary>
        [Display(Name = "DeliveryMethod", ResourceType = typeof(OECommonResx))]
        public DeliveryType DeliveryMethod { get; set; }

        /// <summary>
        /// Get or set email message id
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MessageID", ResourceType = typeof(OECommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string EmailMessageId { get; set; }

        /// <summary>
        /// Get or set email
        /// </summary>
        public bool Email { get; set; }

        /// <summary>
        /// Get or set Do Not Update Flag
        /// </summary>
        public bool DontUpdateFlag { get; set; }

        /// <summary>
        /// Gets or Sets Do Not Print To Destination
        /// </summary>
        public bool DontPrintToDestination { get; set; }

        /// <summary>
        /// gets ot sets Errors
        /// </summary>
        public List<EntityError> Errors { get; set; }
    }
}