﻿/* Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved. */

#region Namespaces

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// This class is used to generate the report for QuoteReport
    /// </summary>
    public partial class QuoteReport : ModuleEmailReportBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or Sets the OrderNumber
        /// </summary>
        public string OrderNumber { get; set; }
        /// <summary>
        /// Gets or sets Print Stat
        /// </summary>
        public int PrintStat { get; set; }

        /// <summary>
        /// Gets or sets Report Name
        /// </summary>
        public string ReportName { get; set; }

        /// <summary>
        /// Get or Set the SortFrom property
        /// </summary>
        [Display(Name = "FromOrderNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string SortFrom { get; set; }

        /// <summary>
        /// Get or Set the SortTo property
        /// </summary>
        [Display(Name = "ToOrderNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string SortTo { get; set; }

        /// <summary>
        /// Gets or Sets the Type
        /// </summary>
        public OrderType OrderType { get; set; }

        /// <summary>
        /// Get or Set the QtyDecimal property
        /// </summary>     
        public decimal QtyDecimal { get; set; }

        /// <summary>
        /// Gets or sets the Type
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Get or Set the Printed property
        /// </summary>
        [Display(Name = "Chkreprint", ResourceType = typeof(QuotesResx))]
        public bool Printed { get; set; }

        /// <summary>
        /// Get or Set the UseCustomForm property
        /// </summary>
        [Display(Name = "UseCustomForm", ResourceType = typeof(OECommonResx))]
        public bool UseCustomForm { get; set; }

        /// <summary>
        /// Get or Set the PrintKit property
        /// </summary>  
        [Display(Name = "PrintKitComponentItems", ResourceType = typeof(OECommonResx))]
        public bool PrintKit { get; set; }

        /// <summary>
        /// Get or Set the PrintBills property
        /// </summary> 
        [Display(Name = "PrintBOMComponentItems", ResourceType = typeof(OECommonResx))]
        public bool PrintBills { get; set; }

        /// <summary>
        /// Get or Set the UseQuote property
        /// </summary>
        [Display(Name = "Lblrptfile", ResourceType = typeof(QuotesResx))]
        public UseQuote UseQuote { get; set; }

        /// <summary>
        /// Gets or sets DataBaseType
        /// </summary>
        public int DataBaseType { get; set; }

        /// <summary>
        /// Get or Set the FileName property
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// The field for  SelectionCriteria
        /// </summary>
        public string SelectionCriteria { get; set; }

        #region CompanyProfile

        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        public CompanyProfile CompanyProfile { get; set; }

        /// <summary>
        /// Gets or Sets the PrintStat
        /// </summary>
        public OrderPrintStatus PrintStatus { get; set; }

        #endregion

        #endregion
    }
}

