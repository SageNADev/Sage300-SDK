﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespaces

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// This class is used to generate the report for QuoteReport
    /// </summary>
    public partial class QuoteReport : ReportBase
    {

        #region Model Properties
        /// <summary>
        /// Gets or Sets the OrderNumber
        /// </summary>
        public string OrderNumber { get; set; }
        /// <summary>
        /// Gets or sets Print Stat
        /// </summary>
        public int PrintStat { get; set; }

        /// <summary>
        /// Gets or sets Report Name
        /// </summary>
        public string ReportName { get; set; }

        /// <summary>
        /// Gets or sets MessageID
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MessageID", ResourceType = typeof(OECommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string EmailMessageId { get; set; }

        /// <summary>
        /// Get or Set the SortFrom property
        /// </summary>
        [Display(Name = "FromOrderNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string SortFrom { get; set; }

        /// <summary>
        /// Get or Set the SortTo property
        /// </summary>
        [Display(Name = "ToOrderNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string SortTo { get; set; }

        /// <summary>
        /// Gets or Sets the Type
        /// </summary>
        public OrderType OrderType { get; set; }

        /// <summary>
        /// Get or Set the QtyDecimal property
        /// </summary>     
        public decimal QtyDecimal { get; set; }

        /// <summary>
        /// Gets or sets the Type
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Get or Set the Printed property
        /// </summary>
        [Display(Name = "Chkreprint", ResourceType = typeof(QuotesResx))]
        public bool Printed { get; set; }

        /// <summary>
        /// Get or Set the UseCustomForm property
        /// </summary>
        [Display(Name = "UseCustomForm", ResourceType = typeof(OECommonResx))]
        public bool UseCustomForm { get; set; }

        /// <summary>
        /// Get or Set the PrintKit property
        /// </summary>  
        [Display(Name = "PrintKitComponentItems", ResourceType = typeof(OECommonResx))]
        public bool PrintKit { get; set; }

        /// <summary>
        /// Get or Set the PrintBills property
        /// </summary> 
        [Display(Name = "PrintBOMComponentItems", ResourceType = typeof(OECommonResx))]
        public bool PrintBills { get; set; }

        /// <summary>
        /// Get or Set the DeliveryMethod property
        /// </summary>
        [Display(Name = "DeliveryMethod", ResourceType = typeof(OECommonResx))]
        public DeliveryType DeliveryMethod { get; set; }

        /// <summary>
        /// Get or Set the UseQuote property
        /// </summary>
        [Display(Name = "Lblrptfile", ResourceType = typeof(QuotesResx))]
        public UseQuote UseQuote { get; set; }

        /// <summary>
        /// Gets or sets DataBaseType
        /// </summary>
        public int DataBaseType { get; set; }

        /// <summary>
        /// Get or Set the FileName property
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// The field for  SelectionCriteria
        /// </summary>
        public string SelectionCriteria { get; set; }

        /// <summary>
        /// Get or set to email address
        /// </summary>
        public string EmailSendTo { get; set; }

        /// <summary>
        /// Get or set email subject
        /// </summary>
        public string EmailSubject { get; set; }

        /// <summary>
        /// Get or set email body message
        /// </summary>
        public string EmailMessageBody { get; set; }

        #region CompanyProfile

        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        public CompanyProfile CompanyProfile { get; set; }

        /// <summary>
        /// Get or set Dont Update Flag
        /// </summary>
        public bool DontUpdateFlag { get; set; }

        /// <summary>
        /// gets ot sets Errors
        /// </summary>
        public List<EntityError> Errors { get; set; }

        /// <summary>
        /// Gets or Sets Dont Print To Destination
        /// </summary>
        public bool DontPrintToDestination { get; set; }

        /// <summary>
        /// Get or set email
        /// </summary>
        public bool Email { get; set; }

        /// <summary>
        /// Gets or Sets the PrintStat
        /// </summary>
        public OrderPrintStatus PrintStatus { get; set; }

        #endregion

        #endregion

    }
}

