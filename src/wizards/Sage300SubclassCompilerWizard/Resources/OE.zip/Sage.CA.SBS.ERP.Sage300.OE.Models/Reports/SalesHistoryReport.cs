﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region name Spaces

using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// this class is used for SalesHistoryReport
    /// </summary>
    public partial class SalesHistoryReport : ReportBase
    {
        #region Detail Sort by Customer
        /// <summary>
        /// Gets or sets the type of the report for sales history report .
        /// </summary>
        public SalesHistoryReportType ReportType { get; set; }

        /// <summary>
        /// Gets or sets the sort by.
        /// </summary>
        public SalesHistorySortBy SalesHistorySortBy { get; set; }


        /// <summary>
        /// Gets or sets the Print Amount In.
        /// </summary>
        public PrintAmountIn PrintAmountIn { get; set; }

        /// <summary>
        /// Gets or sets from year.
        /// </summary>
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets to From Period.
        /// </summary>
        public string FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets to year.
        /// </summary>
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or sets to period.
        /// </summary>
        public string ToPeriod { get; set; }

        /// <summary>
        /// Gets or sets from customer.
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromCustomer { get; set; }

        /// <summary>
        /// Gets or sets to customer.
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToCustomer { get; set; }

        /// <summary>
        /// Gets or sets from item.
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromItem { get; set; }

        /// <summary>
        /// Gets or sets the To Item.
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToItem { get; set; }

        /// <summary>
        /// Gets or sets the decimals.
        /// </summary>
        public string Decimals { get; set; }

        /// <summary>
        /// Gets or sets the multi currency.
        /// </summary>
        public string MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets the report currency.
        /// </summary>
        public string ReportCurrency { get; set; }

        /// <summary>
        /// Gets or sets from currency.
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromCurrency { get; set; }

        /// <summary>
        /// Gets or sets to currency.
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToCurrency { get; set; }

        /// <summary>
        /// Gets or sets the Quatity Decimal.
        /// </summary>
        public string QuatityDecimal { get; set; }

        /// <summary>
        /// Gets or sets the From Fm Item.
        /// </summary>
        public string FromFmItem { get; set; }

        /// <summary>
        /// Gets or sets to fm item.
        /// </summary>
        public string ToFmItem { get; set; }

        /// <summary>
        /// Gets or sets the Kit Comp.
        /// </summary>
        public string KitComp { get; set; }

        /// <summary>
        /// Gets or sets the From Sales.
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromSalesPerson { get; set; }

        /// <summary>
        /// Gets or sets the To Sales.
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToSalesPerson { get; set; }

        /// <summary>
        /// Gets or sets the From Territory.
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromTerritory", ResourceType = typeof(SalesHistoryReportResx))]
        public string FromTerritory { get; set; }

        /// <summary>
        /// Gets or sets the To Territory.
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToTerritory { get; set; }

        /// <summary>
        /// Gets or sets the Serial Lot.
        /// </summary>
        public string SerialLot { get; set; }

        /// <summary>
        /// Gets or sets the From Serial.
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromSerial { get; set; }

        /// <summary>
        /// Gets or sets the From SerialF.
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromSerialF { get; set; }

        /// <summary>
        /// Gets or sets the ToSerial.
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToSerial { get; set; }

        /// <summary>
        /// Gets or sets the To Serial F.
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToSerialF { get; set; }

        /// <summary>
        /// Gets or sets the From Lot.
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromLot { get; set; }



        /// <summary>
        /// Gets or sets the From LotF.
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromLotF { get; set; }

        /// <summary>
        /// Gets or sets the ToLot.
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToLot { get; set; }


        /// <summary>
        /// Gets or sets the To LotF.
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToLotF { get; set; }

        /// <summary>
        /// Gets or sets the fromdate.
        /// </summary>
        [Display(Name = "Fromdate", ResourceType = typeof(TransactionListReportResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? Fromdate { get; set; }

        /// <summary>
        /// Gets or sets the todate.
        /// </summary>
        [Display(Name = "Todate", ResourceType = typeof(TransactionListReportResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? Todate { get; set; }

        /// <summary>
        /// Gets or sets the select by.
        /// </summary>
        public SalesHistorySelectBy SelectBy { get; set; }

        /// <summary>
        /// Gets or sets the Invoice Detail.
        /// </summary>
        public string InvoiceDetail { get; set; }

        /// <summary>
        /// Gets or sets the SwSntlic.
        /// </summary>
        public string SwSntlic { get; set; }


        /// <summary>
        /// Gets or sets the From Account Set.
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromAccountSet { get; set; }

        /// <summary>
        /// Gets or sets the To Account Set.
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToAccountSet { get; set; }

        /// <summary>
        /// Gets or sets the From Category.
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromCategory { get; set; }

        /// <summary>
        /// Gets or sets the To Category.
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToCategory { get; set; }

        /// <summary>
        /// The Show Comparision
        /// </summary>
        public string ShowComparision { get; set; }


        /// <summary>
        /// The Compare From Date
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? CompareFromDate { get; set; }

        /// <summary>
        /// The Compare To Date
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? CompareToDate { get; set; }


        /// <summary>
        /// The CompareFromYear
        /// </summary>
        public string CompareFromYear { get; set; }

        /// <summary>
        /// The CompareToYear
        /// </summary>
        public string CompareToYear { get; set; }

        /// <summary>
        /// The CompareFromPeriod
        /// </summary>
        public string CompareFromPeriod { get; set; }

        /// <summary>
        /// The CompareToPeriod
        /// </summary>
        public string CompareToPeriod { get; set; }


        /// <summary>
        /// Gets or sets MaxFromPeriod
        /// </summary>
        public int MaxFromPeriod { get; set; }

        /// <summary>
        /// Gets or sets MaxToPeriod
        /// </summary>
        public int MaxToPeriod { get; set; }

        /// <summary>
        /// Gets or sets MinFromPeriod
        /// </summary>
        public int MinFromPeriod { get; set; }

        /// <summary>
        /// Gets or sets MinToPeriod
        /// </summary>
        public int MinToPeriod { get; set; }

        #endregion
        

        #region CheckBoxes

        [Display(Name = "IncludeInvoiceDetails", ResourceType = typeof(SalesHistoryReportResx))]
        public bool ChkIncludeInvoiceDetail{ get; set; }

        [Display(Name = "IncludeSerialLotNumbers", ResourceType = typeof(OECommonResx))]
        public bool ChkIncludeSerialLotNumber { get; set; }


        [Display(Name = "PrintKitComponentItems", ResourceType = typeof(OECommonResx))]
        public bool ChkPrintKitComponentItem { get; set; }

        [Display(Name = "ShowComparison", ResourceType = typeof(SalesHistoryReportResx))]
        public bool ChkShowComparison { get; set; }


        /// <summary>
        /// Get or set for MultiCurrency
        /// </summary>
        public bool IsMultiCurrrency { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from date disable.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is from date disable; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromDateDisable { get; set; }


        /// <summary>
        /// Gets or sets AccumulateHistoryBy
        /// </summary>
        [Display(Name = "Accumulateby", ResourceType = typeof(OptionsResx))]
        public AccumulateStatisticsBy AccumulateSalesHistoryBy { get; set; }

        #endregion
    }
}
