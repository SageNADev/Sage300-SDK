﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Class for Optional Fields Description
    /// </summary>
    public class OptionalFieldDescription
    { 
        /// <summary>
        /// Gets or sets Index
        /// </summary>
        public int Index { get; set; }

        /// <summary>
        /// Gets or sets Field Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Get or set the Roto View ID
        /// </summary>
        public string RotoID{get; set; }
        /// <summary>
        /// Gets or sets Key
        /// </summary>
        public int Key { get; set; }

        /// <summary>
        /// Gets or sets Primary
        /// </summary>
        public bool Primary { get; set; }

        /// <summary>
        /// Gets or sets Type of the Field
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets Minimum Length
        /// </summary>
        public string MinLength { get; set; }

        /// <summary>
        /// Get or set the Options field
        /// </summary>
        public string OptField {get; set; }

        /// <summary>
        /// Get or set the Options Field Length
        /// </summary>
        public int OptionsLength { get; set; }

        /// <summary>
        /// Gets or sets Maximum length
        /// </summary>
        public string MaxLength { get; set; }

        /// <summary>
        /// Gets or sets TypedDefaultValueFieldIndex
        /// </summary>
        public string FieldIndex { get; set; }

        /// <summary>
        /// Gets or sets If the value is used for sorting
        /// </summary>
        public bool Sort { get; set; }

        /// <summary>
        /// Gets or sets If the value is Required
        /// </summary>
        public bool Required { get; set; }

        /// <summary>
        /// Get or Set the Filter value 
        /// </summary>
        public string Filter { get; set; }

        /// <summary>
        /// Get or set Optional Decimal Value
        /// </summary>
        public int OptionsDecimal { get; set; }

        /// <summary>
        /// Get or set the Type Index value
        /// </summary>
        public string TypeIndex { get; set; }

        /// <summary>
        /// Get or set the Default Value
        /// </summary>
        public string DefaultValue { get; set; }
    }
}
