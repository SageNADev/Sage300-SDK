// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Partial class for OrderPaymentSchedule
     /// </summary>
     public partial class OrderPaymentSchedule : ModelBase
     {
          /// <summary>
          /// Gets or sets OrderUniquifier
          /// </summary>
          [Key]
         [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
         [Display(Name = "OrderUniquifier", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal OrderUniquifier {get; set;}

          /// <summary>
          /// Gets or sets PaymentNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "PaymentNumber", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int PaymentNumber {get; set;}

          /// <summary>
          /// Gets or sets DiscountBase
          /// </summary>
          [Display(Name = "DiscountBase", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.DiscountBase, Id = Index.DiscountBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal DiscountBase {get; set;}

          /// <summary>
          /// Gets or sets DiscountDate
          /// </summary>
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "DiscountDate", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime DiscountDate {get; set;}

          /// <summary>
          /// Gets or sets DiscountPercentage
          /// </summary>
          [Display(Name = "DiscountDate", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.DiscountPercentage, Id = Index.DiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal DiscountPercentage {get; set;}

          /// <summary>
          /// Gets or sets DiscountAmount
          /// </summary>
          [Display(Name = "DiscountDate", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal DiscountAmount {get; set;}

          /// <summary>
          /// Gets or sets AmountDueBase
          /// </summary>
          [Display(Name = "AmountDueBase", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.AmountDueBase, Id = Index.AmountDueBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal AmountDueBase {get; set;}

          /// <summary>
          /// Gets or sets DueDate
          /// </summary>
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "DueDate", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime DueDate {get; set;}

          /// <summary>
          /// Gets or sets PercentageDue
          /// </summary>
          [Display(Name = "PercentageDue", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.PercentageDue, Id = Index.PercentageDue, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageDue {get; set;}

          /// <summary>
          /// Gets or sets AmountDue
          /// </summary>
          [Display(Name = "AmountDue", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.AmountDue, Id = Index.AmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal AmountDue {get; set;}

     }
}
