// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for Shipment
    /// </summary>
    public partial class Shipment : ModelBase
    {

        /// <summary>
        /// Shipment class Constructor
        /// </summary>
        public Shipment()
        {
            ShipmentDetails = new EnumerableResponse<ShipmentDetail>();
            ShipmentCommentsInstructions=new EnumerableResponse<ShipmentCommentsInstruction>();
            ShipmentFromOrders = new EnumerableResponse<MultipleOrdersToShipment>();
            ShipmentOptionalFields = new EnumerableResponse<ShipmentOptionalField>();
            ShipmentKittingDetails = new EnumerableResponse<ShipmentKittingDetail>();
            ShipmentSecurity = new ShipmentSecurity();
            ShipmentPaymentSchedules = new EnumerableResponse<ShipmentPaymentSchedule>();
        }

        ///// <summary>
        ///// Gets or Sets Attributes
        ///// </summary>
        //[IgnoreExportImport]
        //public IDictionary<string, object> Attributes { get; set; }

        #region Newly Added Properties


        /// <summary>
        /// Gets or sets ShipmentDetails
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ShipmentDetail> ShipmentDetails { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDetails
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ShipmentCommentsInstruction> ShipmentCommentsInstructions { get; set; }

        /// <summary>
        /// Gets or sets ShipmentFromOrders
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<MultipleOrdersToShipment> ShipmentFromOrders { get; set; }

        /// <summary>
        /// Gets or sets ShipmentOptionalFields
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ShipmentOptionalField> ShipmentOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ShipmentKittingDetails
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ShipmentKittingDetail> ShipmentKittingDetails { get; set; }

        /// <summary>
        /// Gets or sets ShipmentPaymentSchedules
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ShipmentPaymentSchedule> ShipmentPaymentSchedules { get; set; }

        /// <summary>
        /// Gets or sets FunctionalShipmentTotal. This property is used in AR-Customer Inquiry screen. This will hold the equivalent value of Shipment Total for function currency.
        /// </summary>
        [IgnoreExportImport]
        public decimal FunctionalShipmentTotal
        {
            get
            {
                if (ShipmentRate == 0)
                {
                    return ShipmentTotal;
                }
                if (ShipmentRateOperator == 1)
                {
                    return ShipmentTotal * ShipmentRate;
                }
                
                return ShipmentTotal / ShipmentRate;
            }
        }

        /// <summary>
        /// Gets or sets Invoiced. This property is used in AR-Customer Inquiry screen. This will hold the value Yes or No based on shipmentComplete status .
        /// </summary>
        [IgnoreExportImport]
        public string Invoiced
        {
            get
            {
                if (ShipmentCompleted == ShipmentCompleted.IncompleteNotIncluded || ShipmentCompleted == ShipmentCompleted.IncompleteIncluded)
                {
                    return "No";
                }
                return "Yes";
            }
        }

        #endregion

        #region Properties Added for Security

        /// <summary>
        /// Gets or Sets ShipmentSecurity
        /// </summary>
        [IgnoreExportImport]
        public ShipmentSecurity ShipmentSecurity { get; set; }

        #endregion



        /// <summary>
        /// Gets or sets ShipmentUniquifier
        /// </summary>
        [Key]
        [Display(Name = "ShipmentUniquifier", ResourceType = typeof(ShipmentEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentUniquifier, Id = Index.ShipmentUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ShipmentUniquifier { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber
        /// </summary>
        [Display(Name = "ShipmentNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [Display(Name = "OrderNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets ICDayEndTransNumber
        /// </summary>
        [Display(Name = "ICDayEndTransNumber", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ICDayEndTransNumber, Id = Index.ICDayEndTransNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ICDayEndTransNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerGroupCode
        /// </summary>
        [Display(Name = "CustomerGroupCode", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerGroupCode, Id = Index.CustomerGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string CustomerGroupCode { get; set; }

        /// <summary>
        /// Gets or sets BillToName
        /// </summary>
        [Display(Name = "BillToName", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToName, Id = Index.BillToName, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToName { get; set; }

        /// <summary>
        /// Gets or sets BillToAddressLine1
        /// </summary>
        [Display(Name = "BillToAddressLine1", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToAddressLine1, Id = Index.BillToAddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddressLine2
        /// </summary>
        [Display(Name = "BillToAddressLine2", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToAddressLine2, Id = Index.BillToAddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddressLine3
        /// </summary>
        [Display(Name = "BillToAddressLine3", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToAddressLine3, Id = Index.BillToAddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddressLine4
        /// </summary>
        [Display(Name = "BillToAddressLine4", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToAddressLine4, Id = Index.BillToAddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets BillToCity
        /// </summary>
        [Display(Name = "BillToCity", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToCity, Id = Index.BillToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCity { get; set; }

        /// <summary>
        /// Gets or sets BillToStateProvince
        /// </summary>
        [Display(Name = "BillToStateProvince", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToStateProvince, Id = Index.BillToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets BillToZipPostalCode
        /// </summary>
        [Display(Name = "BillToZipPostalCode", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToZipPostalCode, Id = Index.BillToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string BillToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets BillToCountry
        /// </summary>
        [Display(Name = "BillToCountry", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToCountry, Id = Index.BillToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCountry { get; set; }

        /// <summary>
        /// Gets or sets BillToPhoneNumber
        /// </summary>
        [Display(Name = "BillToPhoneNumber", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToPhoneNumber, Id = Index.BillToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets BillToFaxNumber
        /// </summary>
        [Display(Name = "BillToFaxNumber", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToFaxNumber, Id = Index.BillToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets BillToContact
        /// </summary>
        [Display(Name = "BillToContact", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContact, Id = Index.BillToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToContact { get; set; }

        /// <summary>
        /// Gets or sets BillToEmail
        /// </summary>
        [Display(Name = "BillToEmail", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToEmail, Id = Index.BillToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToEmail { get; set; }

        /// <summary>
        /// Gets or sets BillToContactPhone
        /// </summary>
        [Display(Name = "BillToContactPhone", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContactPhone, Id = Index.BillToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets BillToContactFax
        /// </summary>
        [Display(Name = "BillToContactFax", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContactFax, Id = Index.BillToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactFax { get; set; }

        /// <summary>
        /// Gets or sets BillToContactEmail
        /// </summary>
        [Display(Name = "BillToContactEmail", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContactEmail, Id = Index.BillToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocationCode
        /// </summary>
        [Display(Name = "ShipToLocationCode", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToLocationCode, Id = Index.ShipToLocationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipToLocationCode { get; set; }

        /// <summary>
        /// Gets or sets ShipToName
        /// </summary>
        [Display(Name = "ShipToName", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToName, Id = Index.ShipToName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToName { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine1
        /// </summary>
        [Display(Name = "ShipToAddressLine1", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddressLine1, Id = Index.ShipToAddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine2
        /// </summary>
        [Display(Name = "ShipToAddressLine2", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddressLine2, Id = Index.ShipToAddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine3
        /// </summary>
        [Display(Name = "ShipToAddressLine3", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddressLine3, Id = Index.ShipToAddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine4
        /// </summary>
        [Display(Name = "ShipToAddressLine4", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddressLine4, Id = Index.ShipToAddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets ShipToCity
        /// </summary>
        [Display(Name = "ShipToCity", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToCity, Id = Index.ShipToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCity { get; set; }

        /// <summary>
        /// Gets or sets ShipToStateProvince
        /// </summary>
        [Display(Name = "ShipToStateProvince", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToStateProvince, Id = Index.ShipToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets ShipToZipPostalCode
        /// </summary>
        [Display(Name = "ShipToZipPostalCode", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToZipPostalCode, Id = Index.ShipToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ShipToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets ShipToCountry
        /// </summary>
        [Display(Name = "ShipToCountry", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToCountry, Id = Index.ShipToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCountry { get; set; }

        /// <summary>
        /// Gets or sets ShipToPhoneNumber
        /// </summary>
        [Display(Name = "ShipToPhoneNumber", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToPhoneNumber, Id = Index.ShipToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToFaxNumber
        /// </summary>
        [Display(Name = "ShipToFaxNumber", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToFaxNumber, Id = Index.ShipToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToContact
        /// </summary>
        [Display(Name = "ShipToContact", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContact, Id = Index.ShipToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToContact { get; set; }

        /// <summary>
        /// Gets or sets ShipToEmail
        /// </summary>
        [Display(Name = "ShipToEmail", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToEmail, Id = Index.ShipToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactPhone
        /// </summary>
        [Display(Name = "ShipToContactPhone", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactPhone, Id = Index.ShipToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactFax
        /// </summary>
        [Display(Name = "ShipToContactFax", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactFax, Id = Index.ShipToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactFax { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactEmail
        /// </summary>
        [Display(Name = "ShipToContactEmail", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactEmail, Id = Index.ShipToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets CustomerDiscountLevel
        /// </summary>
        [Display(Name = "CustomerDiscountLevel", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerDiscountLevel, Id = Index.CustomerDiscountLevel, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerDiscountLevel CustomerDiscountLevel { get; set; }

        /// <summary>
        /// Gets or sets DefaultPriceListCode
        /// </summary>
        [Display(Name = "DefaultPriceListCode", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultPriceListCode, Id = Index.DefaultPriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultPriceListCode { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [Display(Name = "PurchaseOrderNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets Territory
        /// </summary>
        [Display(Name = "Territory", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Territory, Id = Index.Territory, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Territory { get; set; }

        /// <summary>
        /// Gets or sets TermsCodee
        /// </summary>
        [Display(Name = "TermsCode", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets ShipmentReference
        /// </summary>
        [Display(Name = "ShipmentReference", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentReference, Id = Index.ShipmentReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipmentReference { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDate
        /// </summary>
        [Display(Name = "ShipmentDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.ShipmentDate, Id = Index.ShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets ExpectedShipDate
        /// </summary>
        [Display(Name = "ExpShipDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.ExpectedShipDate, Id = Index.ExpectedShipDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpectedShipDate { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCode
        /// </summary>
        [Display(Name = "ShipViaCode", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCodeDescription
        /// </summary>
        [Display(Name = "ShipViaCodeDescription", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipViaCodeDescription, Id = Index.ShipViaCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets ShipmentFiscalYear
        /// </summary>
        [Display(Name = "ShipmentFiscalYear", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentFiscalYear, Id = Index.ShipmentFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string ShipmentFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets ShipmentFiscalPeriod
        /// </summary>
        [Display(Name = "ShipmentFiscalPeriod", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentFiscalPeriod, Id = Index.ShipmentFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public ShipmentFiscalPeriod ShipmentFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceNumber
        /// </summary>
        [Display(Name = "LastInvoiceNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastInvoiceNumber, Id = Index.LastInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string LastInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfInvoices
        /// </summary>
        [Display(Name = "NumberOfInvoices", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NumberOfInvoices, Id = Index.NumberOfInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfInvoices { get; set; }

        /// <summary>
        /// Gets or sets FreeOnBoardPoint
        /// </summary>
        [Display(Name = "FreeOnBoardPoint", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FreeOnBoardPoint, Id = Index.FreeOnBoardPoint, FieldType = EntityFieldType.Char, Size = 60)]
        public string FreeOnBoardPoint { get; set; }

        /// <summary>
        /// Gets or sets TemplateCode
        /// </summary>
        [Display(Name = "TemplateCode", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TemplateCode { get; set; }

        /// <summary>
        /// Gets or sets DefaultLocationCode
        /// </summary>
        [Display(Name = "DefaultLocationCode", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultLocationCode, Id = Index.DefaultLocationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultLocationCode { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDescription
        /// </summary>
        [Display(Name = "ShipmentDescription", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentDescription, Id = Index.ShipmentDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipmentDescription { get; set; }

        /// <summary>
        /// Gets or sets ShipmentComment
        /// </summary>
        [Display(Name = "ShipmentComment", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentComment, Id = Index.ShipmentComment, FieldType = EntityFieldType.Char, Size = 250)]
        public string ShipmentComment { get; set; }

        /// <summary>
        /// Gets or sets OverCreditLimit
        /// </summary>
        [Display(Name = "OverCreditLimit", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.OverCreditLimit, Id = Index.OverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets ApprovedLimit
        /// </summary>
        [Display(Name = "ApprovedLimit", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ApprovedLimit, Id = Index.ApprovedLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ApprovedLimit { get; set; }

        /// <summary>
        /// Gets or sets AuthorizingUserID
        /// </summary>
        [Display(Name = "AuthorizingUserID", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AuthorizingUserID, Id = Index.AuthorizingUserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string AuthorizingUserID { get; set; }

        /// <summary>
        /// Gets or sets OrderPrintStatus
        /// </summary>
        [Display(Name = "OrderPrintStatus", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.OrderPrintStatus, Id = Index.OrderPrintStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderPrintStatus OrderPrintStatus { get; set; }

        /// <summary>
        /// Gets or sets LastPostingDate
        /// </summary>
        [Display(Name = "LastPostingDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastPostingDate, Id = Index.LastPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPostingDate { get; set; }

        /// <summary>
        /// Gets or sets RequiresShippingLabels
        /// </summary>
        [Display(Name = "RequiresShippingLabels", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.RequiresShippingLabels, Id = Index.RequiresShippingLabels, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RequiresShippingLabels { get; set; }

        /// <summary>
        /// Gets or sets ShippingLabelsPrinted
        /// </summary>
        [Display(Name = "ShippingLabelsPrinted", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShippingLabelsPrinted, Id = Index.ShippingLabelsPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ShippingLabelsPrinted { get; set; }

        /// <summary>
        /// Gets or sets ShipmentHomeCurrency
        /// </summary>
        [Display(Name = "ShipmentHomeCurrency", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentHomeCurrency, Id = Index.ShipmentHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ShipmentHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateType
        /// </summary>
        [Display(Name = "ShipmentRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentRateType, Id = Index.ShipmentRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ShipmentRateType { get; set; }

        /// <summary>
        /// Gets or sets ShipmentSourceCurrency
        /// </summary>
        [Display(Name = "ShipmentSourceCurrency", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentSourceCurrency, Id = Index.ShipmentSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ShipmentSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateDate
        /// </summary>
        [Display(Name = "ShipmentRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentRateDate, Id = Index.ShipmentRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipmentRateDate { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRate
        /// </summary>
        [Display(Name = "ShipmentRate", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentRate, Id = Index.ShipmentRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ShipmentRate { get; set; }

        /// <summary>
        /// Gets or sets ShipmentSpread
        /// </summary>
        [Display(Name = "ShipmentSpread", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentSpread, Id = Index.ShipmentSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ShipmentSpread { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateDateMatching
        /// </summary>
        [Display(Name = "ShipmentRateDateMatching", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentRateDateMatching, Id = Index.ShipmentRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateOperator
        /// </summary>
        [Display(Name = "ShipmentRateOperator", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentRateOperator, Id = Index.ShipmentRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentRateOperator { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateOverrideFlag
        /// </summary>
        [Display(Name = "ShipmentRateOverrideFlag", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentRateOverrideFlag, Id = Index.ShipmentRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ShipmentRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets TotalAmtItems
        /// </summary>
        [Display(Name = "TotalAmtItems", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalAmtItems, Id = Index.TotalAmtItems, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAmtItems { get; set; }

        /// <summary>
        /// Gets or sets TotalAmtMiscCharges
        /// </summary>
        [Display(Name = "TotalAmtMiscCharges", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalAmtMiscCharges, Id = Index.TotalAmtMiscCharges, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAmtMiscCharges { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLinesonShipment
        /// </summary>
        [Display(Name = "NumberOfLinesonShipment", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.NumberOfLinesonShipment, Id = Index.NumberOfLinesonShipment, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfLinesonShipment { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLabels
        /// </summary>
        [Display(Name = "NumberOfLabels", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NumberOfLabels, Id = Index.NumberOfLabels, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfLabels { get; set; }

        /// <summary>
        /// Gets or sets PrevPaymentsTotal
        /// </summary>
        [Display(Name = "PrevPaymentsTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PrevPaymentsTotal, Id = Index.PrevPaymentsTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrevPaymentsTotal { get; set; }

        /// <summary>
        /// Gets or sets PrevPaymentDiscTotal
        /// </summary>
        [Display(Name = "PrevPaymentDiscTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PrevPaymentDiscTotal, Id = Index.PrevPaymentDiscTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrevPaymentDiscTotal { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1
        /// </summary>
        [Display(Name = "Salesperson1", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2
        /// </summary>
        [Display(Name = "Salesperson2", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3
        /// </summary>
        [Display(Name = "Salesperson3", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4
        /// </summary>
        [Display(Name = "Salesperson4", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5
        /// </summary>
        [Display(Name = "Salesperson5", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage1
        /// </summary>
        [Display(Name = "SalesPercentage1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPercentage1, Id = Index.SalesPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage2
        /// </summary>
        [Display(Name = "SalesPercentage2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPercentage2, Id = Index.SalesPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage3
        /// </summary>
        [Display(Name = "SalesPercentage3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPercentage3, Id = Index.SalesPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage4
        /// </summary>
        [Display(Name = "SalesPercentage4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPercentage4, Id = Index.SalesPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage5
        /// </summary>
        [Display(Name = "SalesPercentage5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPercentage5, Id = Index.SalesPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets RecalculateTax
        /// </summary>
        [Display(Name = "RecalculateTax", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RecalculateTax, Id = Index.RecalculateTax, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RecalculateTax { get; set; }

        /// <summary>
        /// Gets or sets TaxOverridden
        /// </summary>
        [Display(Name = "TaxOverridden", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxOverridden, Id = Index.TaxOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [Display(Name = "TaxGroup", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [Display(Name = "TaxAuthority1", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [Display(Name = "TaxAuthority2", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [Display(Name = "TaxAuthority3", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [Display(Name = "TaxAuthority4", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [Display(Name = "TaxAuthority5", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount1
        /// </summary>
        [Display(Name = "ExcludedTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount1, Id = Index.ExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount2
        /// </summary>
        [Display(Name = "ExcludedTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount2, Id = Index.ExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount3
        /// </summary>
        [Display(Name = "ExcludedTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount3, Id = Index.ExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount4
        /// </summary>
        [Display(Name = "ExcludedTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount4, Id = Index.ExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount5
        /// </summary>
        [Display(Name = "ExcludedTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount5, Id = Index.ExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount1
        /// </summary>
        [Display(Name = "IncludedTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount1, Id = Index.IncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount2
        /// </summary>
        [Display(Name = "IncludedTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount2, Id = Index.IncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount3
        /// </summary>
        [Display(Name = "IncludedTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount3, Id = Index.IncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount4
        /// </summary>
        [Display(Name = "IncludedTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount4, Id = Index.IncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount5
        /// </summary>
        [Display(Name = "IncludedTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount5, Id = Index.IncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets Registration1
        /// </summary>
        [Display(Name = "Registration1", ResourceType = typeof(OECommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration1, Id = Index.Registration1, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration1 { get; set; }

        /// <summary>
        /// Gets or sets Registration2
        /// </summary>
        [Display(Name = "Registration2", ResourceType = typeof(OECommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration2, Id = Index.Registration2, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration2 { get; set; }

        /// <summary>
        /// Gets or sets Registration3
        /// </summary>
        [Display(Name = "Registration3", ResourceType = typeof(OECommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration3, Id = Index.Registration3, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration3 { get; set; }

        /// <summary>
        /// Gets or sets Registration4
        /// </summary>
        [Display(Name = "Registration4", ResourceType = typeof(OECommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration4, Id = Index.Registration4, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration4 { get; set; }

        /// <summary>
        /// Gets or sets Registration5
        /// </summary>
        [Display(Name = "Registration5", ResourceType = typeof(OECommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration5, Id = Index.Registration5, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration5 { get; set; }

        /// <summary>
        /// Gets or sets ShipmentCompleted
        /// </summary>
        [Display(Name = "ShipmentCompleted", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentCompleted, Id = Index.ShipmentCompleted, FieldType = EntityFieldType.Int, Size = 2)]
        public ShipmentCompleted ShipmentCompleted { get; set; }

        /// <summary>
        /// Gets or sets ShipmentCompletionDate
        /// </summary>
        [Display(Name = "ShipmentCompletionDate", ResourceType = typeof(ShipmentEntryResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentCompletionDate, Id = Index.ShipmentCompletionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipmentCompletionDate { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTotalEstWeight
        /// </summary>
        [Display(Name = "ShipmentTotalEstWeight", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentTotalEstWeight, Id = Index.ShipmentTotalEstWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ShipmentTotalEstWeight { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDiscMiscCharges
        /// </summary>
        [Display(Name = "ShipmentDiscMiscCharges", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentDiscMiscCharges, Id = Index.ShipmentDiscMiscCharges, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ShipmentDiscMiscCharges { get; set; }

        /// <summary>
        /// Gets or sets NoLinesQtyShipped
        /// </summary>
        [Display(Name = "NoLinesQtyShipped", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.NoLinesQtyShipped, Id = Index.NoLinesQtyShipped, FieldType = EntityFieldType.Int, Size = 2)]
        public int NoLinesQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets NoMiscChargesLines
        /// </summary>
        [Display(Name = "NoMiscChargesLines", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NoMiscChargesLines, Id = Index.NoMiscChargesLines, FieldType = EntityFieldType.Int, Size = 2)]
        public int NoMiscChargesLines { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTotalBeforeTax
        /// </summary>
        [Display(Name = "ShipmentTotalBeforeTax", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentTotalBeforeTax, Id = Index.ShipmentTotalBeforeTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentTotalBeforeTax { get; set; }

        /// <summary>
        /// Gets or sets ShipmentInclTaxTotal
        /// </summary>
        [Display(Name = "ShipmentInclTaxTotal", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentInclTaxTotal, Id = Index.ShipmentInclTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentInclTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets ShipmentItemTotalAmount
        /// </summary>
        [Display(Name = "ShipmentItemTotalAmount", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentItemTotalAmount, Id = Index.ShipmentItemTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentItemTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDiscountBase
        /// </summary>
        [Display(Name = "ShipmentDiscountBase", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentDiscountBase, Id = Index.ShipmentDiscountBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentDiscountBase { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDiscountPercentage
        /// </summary>
        [Display(Name = "ShipmentDiscountPercentage", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentDiscountPercentage, Id = Index.ShipmentDiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal ShipmentDiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDiscountAmount
        /// </summary>
        [Display(Name = "ShipmentDiscountAmount", ResourceType = typeof(ShipmentEntryResx))]
        [GridColumn]
        [ViewField(Name = Fields.ShipmentDiscountAmount, Id = Index.ShipmentDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTotalMiscCharges
        /// </summary>
        [Display(Name = "ShipmentTotalMiscCharges", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentTotalMiscCharges, Id = Index.ShipmentTotalMiscCharges, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentTotalMiscCharges { get; set; }

        /// <summary>
        /// Gets or sets ShipmentSubtotalAmount
        /// </summary>
        [Display(Name = "ShipmentSubtotalAmount", ResourceType = typeof(ShipmentEntryResx))]
        [GridColumn]
        [ViewField(Name = Fields.ShipmentSubtotalAmount, Id = Index.ShipmentSubtotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentSubtotalAmount { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTotalWithInvDisc
        /// </summary>
        [Display(Name = "ShipmentTotalWithInvDisc", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentTotalWithInvDisc, Id = Index.ShipmentTotalWithInvDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentTotalWithInvDisc { get; set; }

        /// <summary>
        /// Gets or sets ShipmentExclTaxTotal
        /// </summary>
        [Display(Name = "ShipmentExclTaxTotal", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentExclTaxTotal, Id = Index.ShipmentExclTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentExclTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTotal
        /// </summary>
        [Display(Name = "ShipmentTotal", ResourceType = typeof(ShipmentEntryResx))]
        [GridColumn]
        [ViewField(Name = Fields.ShipmentTotal, Id = Index.ShipmentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentTotal { get; set; }

        /// <summary>
        /// Gets or sets OrderDate
        /// </summary>
        [Display(Name = "OrderDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets OrderHomeCurrency
        /// </summary>
        [Display(Name = "OrderHomeCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderHomeCurrency, Id = Index.OrderHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string OrderHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets OrderRateType
        /// </summary>
        [Display(Name = "OrderRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderRateType, Id = Index.OrderRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string OrderRateType { get; set; }

        /// <summary>
        /// Gets or sets OrderSourceCurrency
        /// </summary>
        [Display(Name = "OrderSourceCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderSourceCurrency, Id = Index.OrderSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string OrderSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets OrderRateDate
        /// </summary>
        [Display(Name = "OrderRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderRateDate, Id = Index.OrderRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrderRateDate { get; set; }

        /// <summary>
        /// Gets or sets OrderRate
        /// </summary>
        [Display(Name = "OrderRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderRate, Id = Index.OrderRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal OrderRate { get; set; }

        /// <summary>
        /// Gets or sets OrderSpread
        /// </summary>
        [Display(Name = "OrderSpread", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderSpread, Id = Index.OrderSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal OrderSpread { get; set; }

        /// <summary>
        /// Gets or sets OrderRateDateMatching
        /// </summary>
        [Display(Name = "OrderRateDateMatching", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderRateDateMatching, Id = Index.OrderRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrderRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets OrderRateOperator
        /// </summary>
        [Display(Name = "OrderRateOperator", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderRateOperator, Id = Index.OrderRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrderRateOperator { get; set; }

        /// <summary>
        /// Gets or sets OrderRateOverrideFlag
        /// </summary>
        [Display(Name = "OrderRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderRateOverrideFlag, Id = Index.OrderRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OrderRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets AutoTaxCalculationStatus
        /// </summary>
        [Display(Name = "AutoTaxCalculationStatus", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.AutoTaxCalculationStatus, Id = Index.AutoTaxCalculationStatus, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AutoTaxCalculationStatus { get; set; }

        /// <summary>
        /// Gets or sets GenerateFromMultipleOrders
        /// </summary>
        [Display(Name = "GenerateFromMultipleOrders", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.GenerateFromMultipleOrders, Id = Index.GenerateFromMultipleOrders, FieldType = EntityFieldType.Bool, Size = 2)]
        public GenerateFromMultipleOrders GenerateFromMultipleOrders { get; set; }

        /// <summary>
        /// Gets or sets FromHowManyOrders
        /// </summary>
        [Display(Name = "FromHowManyOrders", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.FromHowManyOrders, Id = Index.FromHowManyOrders, FieldType = EntityFieldType.Int, Size = 2)]
        public int FromHowManyOrders { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTrackingNumber
        /// </summary>
        [Display(Name = "ShipmentTrackingNumber", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentTrackingNumber, Id = Index.ShipmentTrackingNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string ShipmentTrackingNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfShipments
        /// </summary>
        [Display(Name = "NoOfShipments", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NumberOfShipments, Id = Index.NumberOfShipments, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfShipments { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets OrderUniquifier
        /// </summary>
        [Display(Name = "OrderUniquifier", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal OrderUniquifier { get; set; }

        /// <summary>
        /// Gets or sets ItemDetailDiscountTotal
        /// </summary>
        [Display(Name = "ItemDetailDiscountTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ItemDetailDiscountTotal, Id = Index.ItemDetailDiscountTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ItemDetailDiscountTotal { get; set; }

        /// <summary>
        /// Gets or sets MiscChargeDetailDiscountTot
        /// </summary>
        [Display(Name = "MiscChargeDetailDiscountTot", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.MiscChargeDetailDiscountTot, Id = Index.MiscChargeDetailDiscountTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MiscChargeDetailDiscountTot { get; set; }

        /// <summary>
        /// Gets or sets AutoCalcTaxReportingAmounts
        /// </summary>
        [Display(Name = "AutoCalcTaxReportingAmounts", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.AutoCalcTaxReportingAmounts, Id = Index.AutoCalcTaxReportingAmounts, FieldType = EntityFieldType.Int, Size = 2)]
        public int AutoCalcTaxReportingAmounts { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTRCurrency
        /// </summary>
        [Display(Name = "TaxReportingTRCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingTRCurrency, Id = Index.TaxReportingTRCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingTRCurrency { get; set; }

        /// <summary>
        /// Gets or sets TRRateType
        /// </summary>
        [Display(Name = "TRRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRRateType, Id = Index.TRRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TRRateType { get; set; }

        /// <summary>
        /// Gets or sets TRRateDate
        /// </summary>
        [Display(Name = "TRRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRRateDate, Id = Index.TRRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TRRateDate { get; set; }

        /// <summary>
        /// Gets or sets TRRate
        /// </summary>
        [Display(Name = "TRRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRRate, Id = Index.TRRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TRRate { get; set; }

        /// <summary>
        /// Gets or sets TRSpread
        /// </summary>
        [Display(Name = "TRSpread", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRSpread, Id = Index.TRSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TRSpread { get; set; }

        /// <summary>
        /// Gets or sets TRRateDateMatching
        /// </summary>
        [Display(Name = "TRRateDateMatching", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRRateDateMatching, Id = Index.TRRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int TRRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets TRRateOperator
        /// </summary>
        [Display(Name = "TRRateOperator", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRRateOperator, Id = Index.TRRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TRRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TRRateOverrideFlag
        /// </summary>
        [Display(Name = "TRRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRRateOverrideFlag, Id = Index.TRRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TRRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount1
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRExcludedTaxAmount1, Id = Index.TRExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount2
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRExcludedTaxAmount2, Id = Index.TRExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount3
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRExcludedTaxAmount3, Id = Index.TRExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount4
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRExcludedTaxAmount4, Id = Index.TRExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount5
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRExcludedTaxAmount5, Id = Index.TRExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount1
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRIncludedTaxAmount1, Id = Index.TRIncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount2
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRIncludedTaxAmount2, Id = Index.TRIncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount3
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRIncludedTaxAmount3, Id = Index.TRIncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount4
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRIncludedTaxAmount4, Id = Index.TRIncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount5
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRIncludedTaxAmount5, Id = Index.TRIncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTROrderCurrenc
        /// </summary>
        [Display(Name = "TaxReportingTROrderCurrenc", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingTROrderCurrenc, Id = Index.TaxReportingTROrderCurrenc, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingTROrderCurrenc { get; set; }

        /// <summary>
        /// Gets or sets TROrderRateType
        /// </summary>
        [Display(Name = "TROrderRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TROrderRateType, Id = Index.TROrderRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TROrderRateType { get; set; }

        /// <summary>
        /// Gets or sets TROrderRateDate
        /// </summary>
        [Display(Name = "TROrderRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TROrderRateDate, Id = Index.TROrderRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TROrderRateDate { get; set; }

        /// <summary>
        /// Gets or sets TROrderRate
        /// </summary>
        [Display(Name = "TROrderRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TROrderRate, Id = Index.TROrderRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TROrderRate { get; set; }

        /// <summary>
        /// Gets or sets TROrderSpread
        /// </summary>
        [Display(Name = "TROrderSpread", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TROrderSpread, Id = Index.TROrderSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TROrderSpread { get; set; }

        /// <summary>
        /// Gets or sets TROrderRateDateMatching
        /// </summary>
        [Display(Name = "TROrderRateDateMatching", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TROrderRateDateMatching, Id = Index.TROrderRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int TROrderRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets TROrderRateOperator
        /// </summary>
        [Display(Name = "TROrderRateOperator", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TROrderRateOperator, Id = Index.TROrderRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TROrderRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TROrderRateOverrideFlag
        /// </summary>
        [Display(Name = "TROrderRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TROrderRateOverrideFlag, Id = Index.TROrderRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TROrderRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDiscountAmountOverrid
        /// </summary>
        [Display(Name = "ShipmentDiscountAmountOverrid", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentDiscountAmountOverrid, Id = Index.ShipmentDiscountAmountOverrid, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ShipmentDiscountAmountOverrid { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNoOfPrepayments
        /// </summary>
        [Display(Name = "ShipmentNoOfPrepayments", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentNoOfPrepayments, Id = Index.ShipmentNoOfPrepayments, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentNoOfPrepayments { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedDetailLines
        /// </summary>
        [Display(Name = "JobRelatedDetailLines", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.JobRelatedDetailLines, Id = Index.JobRelatedDetailLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedDetailLines { get; set; }

        /// <summary>
        /// Gets or sets InvoiceableDetailLines
        /// </summary>
        [Display(Name = "InvoiceableDetailLines", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceableDetailLines, Id = Index.InvoiceableDetailLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long InvoiceableDetailLines { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasRetainage HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageTerms
        /// </summary>
        [Display(Name = "RetainageTerms", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageTerms, Id = Index.RetainageTerms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTerms { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainagePercent
        /// </summary>
        [Display(Name = "RetainagePercent", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainagePercent, Id = Index.RetainagePercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal RetainagePercent { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate
        /// </summary>
        [Display(Name = "RetainageExchangeRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1
        /// </summary>
        [Display(Name = "RetainageTaxBase1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2
        /// </summary>
        [Display(Name = "RetainageTaxBase2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3
        /// </summary>
        [Display(Name = "RetainageTaxBase3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4
        /// </summary>
        [Display(Name = "RetainageTaxBase4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5
        /// </summary>
        [Display(Name = "RetainageTaxBase5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount1, Id = Index.RetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount2, Id = Index.RetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount3, Id = Index.RetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount4, Id = Index.RetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount5, Id = Index.RetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets CustomerAccountSet
        /// </summary>
        [Display(Name = "CustomerAccountSet", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerAccountSet, Id = Index.CustomerAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CustomerAccountSet { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [Display(Name = "EnteredBy", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [Display(Name = "PostingDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets SageCRMOpportunityLines
        /// </summary>
        [Display(Name = "SageCRMOpportunityLines", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SageCRMOpportunityLines, Id = Index.SageCRMOpportunityLines, FieldType = EntityFieldType.Int, Size = 2)]
        public int SageCRMOpportunityLines { get; set; }

        /// <summary>
        /// Gets or sets PriceListCodeDesc
        /// </summary>
        [Display(Name = "PriceListCodeDesc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PriceListCodeDesc, Id = Index.PriceListCodeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PriceListCodeDesc { get; set; }

        /// <summary>
        /// Gets or sets TermsCodeDescription
        /// </summary>
        [Display(Name = "TermsCodeDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TermsCodeDescription, Id = Index.TermsCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TermsCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupCodeDesc
        /// </summary>
        [Display(Name = "TaxGroupCodeDesc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroupCodeDesc, Id = Index.TaxGroupCodeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupCodeDesc { get; set; }

        /// <summary>
        /// Gets or sets LocationCodeDesc
        /// </summary>
        [Display(Name = "LocationCodeDesc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LocationCodeDesc, Id = Index.LocationCodeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationCodeDesc { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName1
        /// </summary>
        [Display(Name = "SalespersonName1", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName1, Id = Index.SalespersonName1, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName1 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName2
        /// </summary>
        [Display(Name = "SalespersonName2", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName2, Id = Index.SalespersonName2, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName2 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName3
        /// </summary>
        [Display(Name = "SalespersonName3", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName3, Id = Index.SalespersonName3, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName3 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName4
        /// </summary>
        [Display(Name = "SalespersonName4", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName4, Id = Index.SalespersonName4, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName4 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName5
        /// </summary>
        [Display(Name = "SalespersonName5", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName5, Id = Index.SalespersonName5, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1Desc
        /// </summary>
        [Display(Name = "TaxAuthority1Desc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1Desc, Id = Index.TaxAuthority1Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority1Desc { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2Desc
        /// </summary>
        [Display(Name = "TaxAuthority2Desc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2Desc, Id = Index.TaxAuthority2Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority2Desc { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3Desc
        /// </summary>
        [Display(Name = "TaxAuthority3Desc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3Desc, Id = Index.TaxAuthority3Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority3Desc { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4Desc
        /// </summary>
        [Display(Name = "TaxAuthority4Desc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4Desc, Id = Index.TaxAuthority4Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority4Desc { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5Desc
        /// </summary>
        [Display(Name = "TaxAuthority5Desc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5Desc, Id = Index.TaxAuthority5Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority5Desc { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [Display(Name = "TaxClass1Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [Display(Name = "TaxClass2Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [Display(Name = "TaxClass3Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [Display(Name = "TaxClass4Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [Display(Name = "TaxClass5Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets ShipmentSourceCurrDesc
        /// </summary>
        [Display(Name = "ShipmentSourceCurrDesc", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentSourceCurrDesc, Id = Index.ShipmentSourceCurrDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipmentSourceCurrDesc { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SHHOMDESC
        /// </summary>
        [Display(Name = "ShipmentHomeCurrencyDesc", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ShipmentHomeCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateTypeDesc
        /// </summary>
        [Display(Name = "ShipmentRateTypeDesc", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentRateTypeDesc, Id = Index.ShipmentRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipmentRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets ShipmentSourceCurrencyDesc
        /// </summary>
        [Display(Name = "ShipmentSourceCurrencyDesc", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentSourceCurrencyDesc, Id = Index.ShipmentSourceCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipmentSourceCurrencyDesc { get; set; }

        //// TODO: The naming convention of this property has to be manually evaluated
        ///// <summary>
        ///// Gets or sets ORHOMDESC
        ///// </summary>
        // [Display(Name = "ORHOMDESC", ResourceType = typeof(OECommonResx))] 
        //[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        ////[ViewField(Name = Fields.ORHOMDESC, Id = Index.ORHOMDESC, FieldType = EntityFieldType.Char, Size = 60)]
        //public string ORHOMDESC {get; set;}

        /// <summary>
        /// Gets or sets ShipmentRateTypeDescription
        /// </summary>
        [Display(Name = "ShipmentRateTypeDescription", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentRateTypeDescription, Id = Index.ShipmentRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipmentRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount1
        /// </summary>
        [Display(Name = "TotalTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount1, Id = Index.TotalTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount2
        /// </summary>
        [Display(Name = "TotalTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount2, Id = Index.TotalTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount3
        /// </summary>
        [Display(Name = "TotalTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount3, Id = Index.TotalTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount4
        /// </summary>
        [Display(Name = "TotalTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount4, Id = Index.TotalTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount5
        /// </summary>
        [Display(Name = "TotalTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount5, Id = Index.TotalTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount
        /// </summary>
        [Display(Name = "TotalTaxAmount", ResourceType = typeof(OECommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.TotalTaxAmount, Id = Index.TotalTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRunningTotal
        /// </summary>
        [Display(Name = "ShipmentRunningTotal", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentRunningTotal, Id = Index.ShipmentRunningTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentRunningTotal { get; set; }

        /// <summary>
        /// Gets or sets PerformTaxCalculation
        /// </summary>
        [Display(Name = "PerformTaxCalculation", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PerformTaxCalculation, Id = Index.PerformTaxCalculation, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformTaxCalculation { get; set; }

        /// <summary>
        /// Gets or sets PerformShipAll
        /// </summary>
        [Display(Name = "PerformShipAll", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.PerformShipAll, Id = Index.PerformShipAll, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformShipAll { get; set; }

        /// <summary>
        /// Gets or sets DOSConversionInProgress
        /// </summary>
        [Display(Name = "DOSConversionInProgress", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DOSConversionInProgress, Id = Index.DOSConversionInProgress, FieldType = EntityFieldType.Bool, Size = 2)]
        public DOSConversionInProgress DOSConversionInProgress { get; set; }

        /// <summary>
        /// Gets or sets PerformForcedTaxCalculation
        /// </summary>
        [Display(Name = "PerformForcedTaxCalculation", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PerformForcedTaxCalculation, Id = Index.PerformForcedTaxCalculation, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformForcedTaxCalculation { get; set; }

        /// <summary>
        /// Gets or sets PerformManualTaxDistribution
        /// </summary>
        [Display(Name = "PerformManualTaxDistribution", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PerformManualTaxDistribution, Id = Index.PerformManualTaxDistribution, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformManualTaxDistribution { get; set; }

        /// <summary>
        /// Gets or sets TaxCalculationInProgress
        /// </summary>
        [Display(Name = "TaxCalculationInProgress", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxCalculationInProgress, Id = Index.TaxCalculationInProgress, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxCalculationInProgress { get; set; }

        /// <summary>
        /// Gets or sets DisplayRateWarning
        /// </summary>
        [Display(Name = "DisplayRateWarning", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DisplayRateWarning, Id = Index.DisplayRateWarning, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DisplayRateWarning { get; set; }

        /// <summary>
        /// Gets or sets CustomerExists
        /// </summary>
        [Display(Name = "CustomerExists", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerExists, Id = Index.CustomerExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerExists { get; set; }

        /// <summary>
        /// Gets or sets SecurityEnabled
        /// </summary>
        [Display(Name = "SecurityEnabled", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SecurityEnabled, Id = Index.SecurityEnabled, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SecurityEnabled { get; set; }

        /// <summary>
        /// Gets or sets UserCanApproveCreditLift
        /// </summary>
        [Display(Name = "UserCanApproveCreditLift", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.UserCanApproveCreditLift, Id = Index.UserCanApproveCreditLift, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UserCanApproveCreditLift { get; set; }

        /// <summary>
        /// Gets or sets PerformCreditLimitCheck
        /// </summary>
        [Display(Name = "PerformCreditLimitCheck", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PerformCreditLimitCheck, Id = Index.PerformCreditLimitCheck, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformCreditLimitCheck { get; set; }

        /// <summary>
        /// Gets or sets AuthorizingUserPassword
        /// </summary>
        [Display(Name = "AuthorizingUserPassword", ResourceType = typeof(OECommonResx))]
        [StringLength(64, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AuthorizingUserPassword, Id = Index.AuthorizingUserPassword, FieldType = EntityFieldType.Char, Size = 64)]
        public string AuthorizingUserPassword { get; set; }

        /// <summary>
        /// Gets or sets Allowpartialshipments
        /// </summary>
        [Display(Name = "Allowpartialshipments", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.Allowpartialshipments, Id = Index.Allowpartialshipments, FieldType = EntityFieldType.Int, Size = 2)]
        public Allowpartialshipments Allowpartialshipments { get; set; }

        /// <summary>
        /// Gets or sets GenerateShipFromSingleOrder
        /// </summary>
        [Display(Name = "GenerateShipFromSingleOrder", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.GenerateShipFromSingleOrder, Id = Index.GenerateShipFromSingleOrder, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool GenerateShipFromSingleOrder { get; set; }

        /// <summary>
        /// Gets or sets GenerateShipFromMultOrders
        /// </summary>
        [Display(Name = "GenerateShipFromMultOrders", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.GenerateShipFromMultOrders, Id = Index.GenerateShipFromMultOrders, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool GenerateShipFromMultOrders { get; set; }

        /// <summary>
        /// Gets or sets CreateInvoiceFromShipment
        /// </summary>
        [Display(Name = "CreateInvoiceFromShipment", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.CreateInvoiceFromShipment, Id = Index.CreateInvoiceFromShipment, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CreateInvoiceFromShipment { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [Display(Name = "InvoiceNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets PostSequenceNumber
        /// </summary>
        [Display(Name = "PostSequenceNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PostSequenceNumber, Id = Index.PostSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long PostSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoiceUniquifier
        /// </summary>
        [Display(Name = "InvoiceUniquifier", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal InvoiceUniquifier { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDate
        /// </summary>
        [Display(Name = "InvoiceDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceDate, Id = Index.InvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceHomeCurrency
        /// </summary>
        [Display(Name = "InvoiceHomeCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceHomeCurrency, Id = Index.InvoiceHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string InvoiceHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateType
        /// </summary>
        [Display(Name = "InvoiceRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceRateType, Id = Index.InvoiceRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string InvoiceRateType { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSourceCurrency
        /// </summary>
        [Display(Name = "InvoiceSourceCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceSourceCurrency, Id = Index.InvoiceSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string InvoiceSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateDate
        /// </summary>
        [Display(Name = "InvoiceRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceRateDate, Id = Index.InvoiceRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoiceRateDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRate
        /// </summary>
        [Display(Name = "InvoiceRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceRate, Id = Index.InvoiceRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal InvoiceRate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSpread
        /// </summary>
        [Display(Name = "InvoiceSpread", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceSpread, Id = Index.InvoiceSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal InvoiceSpread { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateDateMatching
        /// </summary>
        [Display(Name = "InvoiceRateDateMatching", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceRateDateMatching, Id = Index.InvoiceRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoiceRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateOperator
        /// </summary>
        [Display(Name = "InvoiceRateOperator", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceRateOperator, Id = Index.InvoiceRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoiceRateOperator { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateOverrideFlag
        /// </summary>
        [Display(Name = "InvoiceRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceRateOverrideFlag, Id = Index.InvoiceRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InvoiceRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSourceCurrencyDesc
        /// </summary>
        [Display(Name = "InvoiceSourceCurrencyDesc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceSourceCurrencyDesc, Id = Index.InvoiceSourceCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceSourceCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets InvoiceHomeCurrencyDesc
        /// </summary>
        [Display(Name = "InvoiceHomeCurrencyDesc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceHomeCurrencyDesc, Id = Index.InvoiceHomeCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceHomeCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateTypeDescription
        /// </summary>
        [Display(Name = "InvoiceRateTypeDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceRateTypeDescription, Id = Index.InvoiceRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets CreatedFromOrder
        /// </summary>
        [Display(Name = "CreatedFromOrder", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CreatedFromOrder, Id = Index.CreatedFromOrder, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CreatedFromOrder { get; set; }

        /// <summary>
        /// Gets or sets ProcessOIPCommand
        /// </summary>
        [Display(Name = "ProcessOIPCommand", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ProcessOIPCommand, Id = Index.ProcessOIPCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessOIPCommand ProcessOIPCommand { get; set; }

        /// <summary>
        /// Gets or sets ProcessOECommand
        /// </summary>
        [Display(Name = "ProcessOECommand", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ProcessOECommand, Id = Index.ProcessOECommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessOECommand ProcessOECommand { get; set; }

        /// <summary>
        /// Gets or sets UserEnteredApprovalAmount
        /// </summary>
        [Display(Name = "UserEnteredApprovalAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.UserEnteredApprovalAmount, Id = Index.UserEnteredApprovalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UserEnteredApprovalAmount { get; set; }

        /// <summary>
        /// Gets or sets CheckingCustomerCreditLimit
        /// </summary>
        [Display(Name = "CheckingCustomerCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingCustomerCreditLimit, Id = Index.CheckingCustomerCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingCustomerCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingCustomerAgingLimit
        /// </summary>
        [Display(Name = "CheckingCustomerAgingLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingCustomerAgingLimit, Id = Index.CheckingCustomerAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingCustomerAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingNatAcctCreditLimit
        /// </summary>
        [Display(Name = "CheckingNatAcctCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingNatAcctCreditLimit, Id = Index.CheckingNatAcctCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingNatAcctCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingNatAcctAgingLimit
        /// </summary>
        [Display(Name = "CheckingNatAcctAgingLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingNatAcctAgingLimit, Id = Index.CheckingNatAcctAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingNatAcctAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerIsOverCreditLimit
        /// </summary>
        [Display(Name = "CustomerIsOverCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerIsOverCreditLimit, Id = Index.CustomerIsOverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerIsOverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerIsOverAgingLimit
        /// </summary>
        [Display(Name = "CustomerIsOverAgingLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerIsOverAgingLimit, Id = Index.CustomerIsOverAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerIsOverAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctIsOverCreditLimit
        /// </summary>
        [Display(Name = "NatAcctIsOverCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctIsOverCreditLimit, Id = Index.NatAcctIsOverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool NatAcctIsOverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctIsOverAgingLimit
        /// </summary>
        [Display(Name = "NatAcctIsOverAgingLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctIsOverAgingLimit, Id = Index.NatAcctIsOverAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool NatAcctIsOverAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerCreditLimit
        /// </summary>
        [Display(Name = "FrameCust", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerCreditLimit, Id = Index.CustomerCreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerBalancePosted
        /// </summary>
        [Display(Name = "CustomerBalancePosted", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerBalancePosted, Id = Index.CustomerBalancePosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerBalancePosted { get; set; }

        /// <summary>
        /// Gets or sets CustomerDaysOverdue
        /// </summary>
        [Display(Name = "CustomerDaysOverdue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerDaysOverdue, Id = Index.CustomerDaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerDaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets CustomerOverdueLimit
        /// </summary>
        [Display(Name = "CustomerOverdueLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerOverdueLimit, Id = Index.CustomerOverdueLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerOverdueLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerBalanceOverdue
        /// </summary>
        [Display(Name = "CustomerBalanceOverdue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerBalanceOverdue, Id = Index.CustomerBalanceOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerBalanceOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctCreditLimit
        /// </summary>
        [Display(Name = "FrameNatl", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctCreditLimit, Id = Index.NatAcctCreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctBalance
        /// </summary>
        [Display(Name = "NatAcctBalance", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctBalance, Id = Index.NatAcctBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctBalance { get; set; }

        /// <summary>
        /// Gets or sets NatAcctDaysOverdue
        /// </summary>
        [Display(Name = "NatAcctDaysOverdue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctDaysOverdue, Id = Index.NatAcctDaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int NatAcctDaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctOverdueLimit
        /// </summary>
        [Display(Name = "NatAcctOverdueLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctOverdueLimit, Id = Index.NatAcctOverdueLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctOverdueLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctBalanceOverdue
        /// </summary>
        [Display(Name = "NatAcctBalanceOverdue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctBalanceOverdue, Id = Index.NatAcctBalanceOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctBalanceOverdue { get; set; }

        /// <summary>
        /// Gets or sets ARPendingTransIncluded
        /// </summary>
        [Display(Name = "ARPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ARPendingTransIncluded, Id = Index.ARPendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ARPendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets OEPendingTransIncluded
        /// </summary>
        [Display(Name = "OEPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OEPendingTransIncluded, Id = Index.OEPendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OEPendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets OtherPendingTransIncluded
        /// </summary>
        [Display(Name = "OtherPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OtherPendingTransIncluded, Id = Index.OtherPendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OtherPendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets ARPendingBalance
        /// </summary>
        [Display(Name = "AmtArPend", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ARPendingBalance, Id = Index.ARPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ARPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets OEPendingBalance
        /// </summary>
        [Display(Name = "OEPendingBalance", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OEPendingBalance, Id = Index.OEPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OEPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets OtherPendingBalance
        /// </summary>
        [Display(Name = "AmtTxxPend", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OtherPendingBalance, Id = Index.OtherPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OtherPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets CustomerTotalOutstanding
        /// </summary>
        [Display(Name = "CustomerTotalOutstanding", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerTotalOutstanding, Id = Index.CustomerTotalOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTotalOutstanding { get; set; }

        /// <summary>
        /// Gets or sets NatAcctTotalOutstanding
        /// </summary>
        [Display(Name = "NatAcctTotalOutstanding", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctTotalOutstanding, Id = Index.NatAcctTotalOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctTotalOutstanding { get; set; }

        /// <summary>
        /// Gets or sets CustomerLimitLeft
        /// </summary>
        [Display(Name = "CustomerLimitLeft", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerLimitLeft, Id = Index.CustomerLimitLeft, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerLimitLeft { get; set; }

        /// <summary>
        /// Gets or sets NatAcctLimitLeft
        /// </summary>
        [Display(Name = "NatAcctLimitLeft", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctLimitLeft, Id = Index.NatAcctLimitLeft, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctLimitLeft { get; set; }

        /// <summary>
        /// Gets or sets CustomerLimitExceeded
        /// </summary>
        [Display(Name = "CustomerLimitExceeded", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerLimitExceeded, Id = Index.CustomerLimitExceeded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerLimitExceeded { get; set; }

        /// <summary>
        /// Gets or sets NatAcctLimitExceeded
        /// </summary>
        [Display(Name = "NatAcctLimitExceeded", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctLimitExceeded, Id = Index.NatAcctLimitExceeded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctLimitExceeded { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceAmount
        /// </summary>
        [Display(Name = "LastInvoiceAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LastInvoiceAmount, Id = Index.LastInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceDate
        /// </summary>
        [Display(Name = "LastInvoiceDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastInvoiceDate, Id = Index.LastInvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets LastPaymentAmount
        /// </summary>
        [Display(Name = "LastPaymentAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LastPaymentAmount, Id = Index.LastPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets LastPaymentDate
        /// </summary>
        [Display(Name = "LastPaymentDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastPaymentDate, Id = Index.LastPaymentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPaymentDate { get; set; }

        /// <summary>
        /// Gets or sets DrivenbyUI
        /// </summary>
        [Display(Name = "DrivenbyUI", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DrivenbyUI, Id = Index.DrivenbyUI, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DrivenbyUI { get; set; }

        /// <summary>
        /// Gets or sets DetailDiscountTotal
        /// </summary>
        [Display(Name = "DetailDiscountTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DetailDiscountTotal, Id = Index.DetailDiscountTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DetailDiscountTotal { get; set; }

        /// <summary>
        /// Gets or sets DetailDiscountPercentage
        /// </summary>
        [Display(Name = "DetailDiscountPercentage", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DetailDiscountPercentage, Id = Index.DetailDiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DetailDiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets DocumentNetOfDetailDisc
        /// </summary>
        [Display(Name = "DocumentNetOfDetailDisc", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DocumentNetOfDetailDisc, Id = Index.DocumentNetOfDetailDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentNetOfDetailDisc { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount1
        /// </summary>
        [Display(Name = "TRTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRTaxAmount1, Id = Index.TRTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount2
        /// </summary>
        [Display(Name = "TRTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRTaxAmount2, Id = Index.TRTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount3
        /// </summary>
        [Display(Name = "TRTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRTaxAmount3, Id = Index.TRTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount4
        /// </summary>
        [Display(Name = "TRTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRTaxAmount4, Id = Index.TRTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount5
        /// </summary>
        [Display(Name = "TRTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRTaxAmount5, Id = Index.TRTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxTotal
        /// </summary>
        [Display(Name = "TRExcludedTaxTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRExcludedTaxTotal, Id = Index.TRExcludedTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxTotal
        /// </summary>
        [Display(Name = "TRIncludedTaxTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRIncludedTaxTotal, Id = Index.TRIncludedTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TRTaxTotal
        /// </summary>
        [Display(Name = "TRTaxTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRTaxTotal, Id = Index.TRTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingInvoiceTRCurre
        /// </summary>
        [Display(Name = "TaxReportingInvoiceTRCurre", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingInvoiceTRCurre, Id = Index.TaxReportingInvoiceTRCurre, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingInvoiceTRCurre { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRateType
        /// </summary>
        [Display(Name = "TRInvoiceRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRInvoiceRateType, Id = Index.TRInvoiceRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TRInvoiceRateType { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRateDate
        /// </summary>
        [Display(Name = "TRInvoiceRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRInvoiceRateDate, Id = Index.TRInvoiceRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TRInvoiceRateDate { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRate
        /// </summary>
        [Display(Name = "TRInvoiceRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRInvoiceRate, Id = Index.TRInvoiceRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TRInvoiceRate { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceSpread
        /// </summary>
        [Display(Name = "TRInvoiceSpread", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRInvoiceSpread, Id = Index.TRInvoiceSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TRInvoiceSpread { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRateDateMatching
        /// </summary>
        [Display(Name = "TRInvoiceRateDateMatching", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRInvoiceRateDateMatching, Id = Index.TRInvoiceRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int TRInvoiceRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRateOperator
        /// </summary>
        [Display(Name = "TRInvoiceRateOperator", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRInvoiceRateOperator, Id = Index.TRInvoiceRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TRInvoiceRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRateOverrideFlag
        /// </summary>
        [Display(Name = "TRInvoiceRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TRInvoiceRateOverrideFlag, Id = Index.TRInvoiceRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TRInvoiceRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets TRCurrencyDescription
        /// </summary>
        [Display(Name = "TRCurrencyDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRCurrencyDescription, Id = Index.TRCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TRCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentCurrencyDescription
        /// </summary>
        [Display(Name = "TRShipmentCurrencyDescription", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRShipmentCurrencyDescription, Id = Index.TRShipmentCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TRShipmentCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceCurrencyDescription
        /// </summary>
        [Display(Name = "TRInvoiceCurrencyDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRInvoiceCurrencyDescription, Id = Index.TRInvoiceCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TRInvoiceCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TRRateTypeDescription
        /// </summary>
        [Display(Name = "TRRateTypeDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRRateTypeDescription, Id = Index.TRRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TRRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRateTypeDescriptio
        /// </summary>
        [Display(Name = "TRShipmentRateTypeDescriptio", ResourceType = typeof(ShipmentEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRShipmentRateTypeDescriptio, Id = Index.TRShipmentRateTypeDescriptio, FieldType = EntityFieldType.Char, Size = 60)]
        public string TRShipmentRateTypeDescriptio { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRateTypeDescription
        /// </summary>
        [Display(Name = "TRInvoiceRateTypeDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRInvoiceRateTypeDescription, Id = Index.TRInvoiceRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TRInvoiceRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets ReceiptBatchNumber
        /// </summary>
        [Display(Name = "ReceiptBatchNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ReceiptBatchNumber, Id = Index.ReceiptBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal ReceiptBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets BankCode
        /// </summary>
        [Display(Name = "BankCode", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets ReceiptType
        /// </summary>
        [Display(Name = "ReceiptType", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptType, Id = Index.ReceiptType, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ReceiptType { get; set; }

        /// <summary>
        /// Gets or sets CheckDate
        /// </summary>
        [Display(Name = "CheckDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckDate, Id = Index.CheckDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CheckDate { get; set; }

        /// <summary>
        /// Gets or sets CheckFiscalYear
        /// </summary>
        [Display(Name = "CheckFiscalYear", ResourceType = typeof(OECommonResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckFiscalYear, Id = Index.CheckFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string CheckFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets CheckFiscalPeriod
        /// </summary>
        [Display(Name = "CheckFiscalPeriod", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckFiscalPeriod, Id = Index.CheckFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int CheckFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber
        /// </summary>
        [Display(Name = "CheckNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentAppliedTo
        /// </summary>
        [Display(Name = "PaymentAppliedTo", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentAppliedTo, Id = Index.PaymentAppliedTo, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentAppliedTo PaymentAppliedTo { get; set; }

        /// <summary>
        /// Gets or sets PaymentInCustCurrency
        /// </summary>
        [Display(Name = "PaymentInCustCurrency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentInCustCurrency, Id = Index.PaymentInCustCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentInCustCurrency { get; set; }

        /// <summary>
        /// Gets or sets PaymentDisc
        /// </summary>
        [Display(Name = "PaymentDisc", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentDisc, Id = Index.PaymentDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentDisc { get; set; }

        /// <summary>
        /// Gets or sets PaymentInBankCurrency
        /// </summary>
        [Display(Name = "PaymentInBankCurrency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentInBankCurrency, Id = Index.PaymentInBankCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentInBankCurrency { get; set; }

        /// <summary>
        /// Gets or sets PendingPrepaymentAmount
        /// </summary>
        [Display(Name = "PendingPrepaymentAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PendingPrepaymentAmount, Id = Index.PendingPrepaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingPrepaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets PaymentHomeCurrency
        /// </summary>
        [Display(Name = "PaymentHomeCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentHomeCurrency, Id = Index.PaymentHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string PaymentHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets PaymentRateType
        /// </summary>
        [Display(Name = "PaymentRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentRateType, Id = Index.PaymentRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PaymentRateType { get; set; }

        /// <summary>
        /// Gets or sets PaymentSourceCurrency
        /// </summary>
        [Display(Name = "PaymentSourceCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentSourceCurrency, Id = Index.PaymentSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string PaymentSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets PaymentRateDate
        /// </summary>
        [Display(Name = "PaymentRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentRateDate, Id = Index.PaymentRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PaymentRateDate { get; set; }

        /// <summary>
        /// Gets or sets PaymentRate
        /// </summary>
        [Display(Name = "PaymentRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentRate, Id = Index.PaymentRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PaymentRate { get; set; }

        /// <summary>
        /// Gets or sets PaymentSpread
        /// </summary>
        [Display(Name = "PaymentSpread", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentSpread, Id = Index.PaymentSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PaymentSpread { get; set; }

        /// <summary>
        /// Gets or sets PaymentRateDateMatching
        /// </summary>
        [Display(Name = "PaymentRateDateMatching", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentRateDateMatching, Id = Index.PaymentRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int PaymentRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets PaymentRateOperator
        /// </summary>
        [Display(Name = "PaymentRateOperator", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentRateOperator, Id = Index.PaymentRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int PaymentRateOperator { get; set; }

        /// <summary>
        /// Gets or sets PaymentType
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTotalPayment
        /// </summary>
        [Display(Name = "ShipmentTotalPayment", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentTotalPayment, Id = Index.ShipmentTotalPayment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentTotalPayment { get; set; }

        /// <summary>
        /// Gets or sets ShipmentAmountDue
        /// </summary>
        [Display(Name = "ShipmentAmountDue", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ShipmentAmountDue, Id = Index.ShipmentAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentAmountDue { get; set; }

        /// <summary>
        /// Gets or sets AmountDueLessCurrPrepayment
        /// </summary>
        [Display(Name = "AmountDueLessCurrPrepayment", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.AmountDueLessCurrPrepayment, Id = Index.AmountDueLessCurrPrepayment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDueLessCurrPrepayment { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets ProjectInvoicing
        /// </summary>
        [Display(Name = "ProjectInvoicing", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ProjectInvoicing, Id = Index.ProjectInvoicing, FieldType = EntityFieldType.Bool, Size = 2)]
        public ProjectInvoicing ProjectInvoicing { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsDescription
        /// </summary>
        [Display(Name = "RetainageTermsDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageTermsDescription, Id = Index.RetainageTermsDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RetainageTermsDescription { get; set; }

        /// <summary>
        /// Gets or sets CustomerAccountSetDescription
        /// </summary>
        [Display(Name = "CustomerAccountSetDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerAccountSetDescription, Id = Index.CustomerAccountSetDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerAccountSetDescription { get; set; }

        /// <summary>
        /// Gets or sets InvoicePostingDate
        /// </summary>
        [Display(Name = "InvoicePostingDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoicePostingDate, Id = Index.InvoicePostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoicePostingDate { get; set; }

        /// <summary>
        /// Gets or sets OrderPaymentsTotal
        /// </summary>
        [Display(Name = "OrderPaymentsTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderPaymentsTotal, Id = Index.OrderPaymentsTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderPaymentsTotal { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentDistributedAmount
        /// </summary>
        [Display(Name = "PrepaymentDistributedAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PrepaymentDistributedAmount, Id = Index.PrepaymentDistributedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrepaymentDistributedAmount { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentUnappliedAmount
        /// </summary>
        [Display(Name = "PrepaymentUnappliedAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PrepaymentUnappliedAmount, Id = Index.PrepaymentUnappliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrepaymentUnappliedAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalRetainageTaxAmount
        /// </summary>
        [Display(Name = "TotalRetainageTaxAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalRetainageTaxAmount, Id = Index.TotalRetainageTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRetainageTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets PreAuthExistsFortheShipment
        /// </summary>
        [Display(Name = "PreAuthExistsFortheShipment", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PreAuthExistsFortheShipment, Id = Index.PreAuthExistsFortheShipment, FieldType = EntityFieldType.Bool, Size = 2)]
        public PreAuthExistsFortheShipment PreAuthExistsFortheShipment { get; set; }

        /// <summary>
        /// Gets or sets PaymentTypeOnOrder
        /// </summary>
        [Display(Name = "PaymentTypeOnOrder", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentTypeOnOrder, Id = Index.PaymentTypeOnOrder, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentTypeOnOrder PaymentTypeOnOrder { get; set; }

        /// <summary>
        /// Gets or sets PaymentCodeOnOrder
        /// </summary>
        [Display(Name = "PaymentCodeOnOrder", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentCodeOnOrder, Id = Index.PaymentCodeOnOrder, FieldType = EntityFieldType.Char, Size = 12)]
        public string PaymentCodeOnOrder { get; set; }

        /// <summary>
        /// Gets or sets PaymentCardID
        /// </summary>
        [Display(Name = "PaymentCardID", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentCardID, Id = Index.PaymentCardID, FieldType = EntityFieldType.Char, Size = 12)]
        public string PaymentCardID { get; set; }

        #region strings

        /// <summary>
        /// Gets the ShipmentFiscalPeriod string.
        /// </summary>
        [IgnoreExportImport]
        public string ShipmentFiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(ShipmentFiscalPeriod); }
        }

        /// <summary>
        /// Gets the OrderPrintStatus string.
        /// </summary>
        [IgnoreExportImport]
        public string OrderPrintStatusString
        {
            get { return EnumUtility.GetStringValue(OrderPrintStatus); }
        }

        /// <summary>
        /// Gets the ShipmentCompleted string.
        /// </summary>
        [IgnoreExportImport]
        public string ShipmentCompletedString
        {
            get { return EnumUtility.GetStringValue(ShipmentCompleted); }
        }

        /// <summary>
        /// Gets the GenerateFromMultipleOrders string.
        /// </summary>
        [IgnoreExportImport]
        public string GenerateFromMultipleOrdersString
        {
            get { return EnumUtility.GetStringValue(GenerateFromMultipleOrders); }
        }

        /// <summary>
        /// Gets the HasRetainage string.
        /// </summary>
        [IgnoreExportImport]
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Gets the RetainageExchangeRate string.
        /// </summary>
        [IgnoreExportImport]
        public string RetainageExchangeRateString
        {
            get { return EnumUtility.GetStringValue(RetainageExchangeRate); }
        }

        /// <summary>
        /// Gets the DOSConversionInProgress string.
        /// </summary>
        [IgnoreExportImport]
        public string DOSConversionInProgressString
        {
            get { return EnumUtility.GetStringValue(DOSConversionInProgress); }
        }

        /// <summary>
        /// Gets the ShipmentCompleted string.
        /// </summary>
        [IgnoreExportImport]
        public string AllowpartialshipmentsString
        {
            get { return EnumUtility.GetStringValue(Allowpartialshipments); }
        }

        /// <summary>
        /// Gets the ShipmentCompleted string.
        /// </summary>
        [IgnoreExportImport]
        public string ProcessOIPCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessOIPCommand); }
        }

        /// <summary>
        /// Gets the ShipmentCompleted string.
        /// </summary>
        [IgnoreExportImport]
        public string ProcessOECommandString
        {
            get { return EnumUtility.GetStringValue(ProcessOECommand); }
        }

        /// <summary>
        /// Gets the ShipmentCompleted string.
        /// </summary>
        [IgnoreExportImport]
        public string PaymentAppliedToString
        {
            get { return EnumUtility.GetStringValue(PaymentAppliedTo); }
        }

        /// <summary>
        /// Gets the ShipmentCompleted string.
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string PaymentTypeString
        {
            get { return EnumUtility.GetStringValue(PaymentType); }
        }

        /// <summary>
        /// Gets the ShipmentCompleted string.
        /// </summary>
        [IgnoreExportImport]
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets the ShipmentCompleted string.
        /// </summary>
        [IgnoreExportImport]
        public string ProjectInvoicingString
        {
            get { return EnumUtility.GetStringValue(ProjectInvoicing); }
        }

        /// <summary>
        /// Gets the ShipmentCompleted string.
        /// </summary>
        [IgnoreExportImport]
        public string PreAuthExistsFortheShipmentString
        {
            get { return EnumUtility.GetStringValue(PreAuthExistsFortheShipment); }
        }

        /// <summary>
        /// Gets the ShipmentCompleted string.
        /// </summary>
        [IgnoreExportImport]
        public string PaymentTypeOnOrderString
        {
            get { return EnumUtility.GetStringValue(PaymentTypeOnOrder); }
        }

        /// <summary>
        /// Gets the CustomerDiscountLevel string.
        /// </summary>
        public string CustomerDiscountLevelString
        {
            get { return EnumUtility.GetStringValue(CustomerDiscountLevel); }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ShipmentRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string ShipmentRateOverrideFlagString
        {
            get
            {
                if (ShipmentRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "OverCreditLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string OverCreditLimitString
        {
            get
            {
                if (OverCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "RequiresShippingLabels", ResourceType = typeof(ShipmentEntryResx))]
        [IgnoreExportImport]
        public string RequiresShippingLabelsString
        {
            get
            {
                if (RequiresShippingLabels)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ShippingLabelsPrinted", ResourceType = typeof(ShipmentEntryResx))]
        [IgnoreExportImport]
        public string ShippingLabelsPrintedString
        {
            get
            {
                if (ShippingLabelsPrinted)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "RecalculateTax", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string RecalculateTaxString
        {
            get
            {
                if (RecalculateTax)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "TaxOverridden", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string TaxOverriddenString
        {
            get
            {
                if (TaxOverridden)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ShipmentDiscMiscCharges", ResourceType = typeof(ShipmentEntryResx))]
        [IgnoreExportImport]
        public string ShipmentDiscMiscChargesString
        {
            get
            {
                if (ShipmentDiscMiscCharges)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "OrderRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string OrderRateOverrideFlagString
        {
            get
            {
                if (OrderRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "AutoTaxCalculationStatus", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string AutoTaxCalculationStatusString
        {
            get
            {
                if (AutoTaxCalculationStatus)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "TRRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string TRRateOverrideFlagString
        {
            get
            {
                if (TRRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "TROrderRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string TROrderRateOverrideFlagString
        {
            get
            {
                if (TROrderRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ShipmentDiscountAmountOverrid", ResourceType = typeof(ShipmentEntryResx))]
        [IgnoreExportImport]
        public string ShipmentDiscountAmountOverridString
        {
            get
            {
                if (ShipmentDiscountAmountOverrid)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "PerformTaxCalculation", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string PerformTaxCalculationString
        {
            get
            {
                if (PerformTaxCalculation)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "PerformShipAll", ResourceType = typeof(ShipmentEntryResx))]
        [IgnoreExportImport]
        public string PerformShipAllString
        {
            get
            {
                if (PerformShipAll)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "PerformForcedTaxCalculation", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string PerformForcedTaxCalculationString
        {
            get
            {
                if (PerformForcedTaxCalculation)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "PerformManualTaxDistribution", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string PerformManualTaxDistributionString
        {
            get
            {
                if (PerformManualTaxDistribution)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "TaxCalculationInProgress", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string TaxCalculationInProgressString
        {
            get
            {
                if (TaxCalculationInProgress)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "DisplayRateWarning", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string DisplayRateWarningString
        {
            get
            {
                if (DisplayRateWarning)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CustomerExists", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CustomerExistsString
        {
            get
            {
                if (CustomerExists)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "SecurityEnabled", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string SecurityEnabledString
        {
            get
            {
                if (SecurityEnabled)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "UserCanApproveCreditLift", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string UserCanApproveCreditLiftString
        {
            get
            {
                if (UserCanApproveCreditLift)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "PerformCreditLimitCheck", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string PerformCreditLimitCheckString
        {
            get
            {
                if (PerformCreditLimitCheck)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "GenerateShipFromSingleOrder", ResourceType = typeof(ShipmentEntryResx))]
        [IgnoreExportImport]
        public string GenerateShipFromSingleOrderString
        {
            get
            {
                if (GenerateShipFromSingleOrder)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "GenerateShipFromMultOrders", ResourceType = typeof(ShipmentEntryResx))]
        [IgnoreExportImport]
        public string GenerateShipFromMultOrdersString
        {
            get
            {
                if (GenerateShipFromMultOrders)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CreateInvoiceFromShipment", ResourceType = typeof(ShipmentEntryResx))]
        [IgnoreExportImport]
        public string CreateInvoiceFromShipmentString
        {
            get
            {
                if (CreateInvoiceFromShipment)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "InvoiceRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string InvoiceRateOverrideFlagString
        {
            get
            {
                if (InvoiceRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CreatedFromOrder", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CreatedFromOrderString
        {
            get
            {
                if (CreatedFromOrder)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CheckingCustomerCreditLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CheckingCustomerCreditLimitString
        {
            get
            {
                if (CheckingCustomerCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CheckingCustomerAgingLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CheckingCustomerAgingLimitString
        {
            get
            {
                if (CheckingCustomerAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CheckingNatAcctCreditLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CheckingNatAcctCreditLimitString
        {
            get
            {
                if (CheckingNatAcctCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CheckingNatAcctAgingLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CheckingNatAcctAgingLimitString
        {
            get
            {
                if (CheckingNatAcctAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CustomerIsOverCreditLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CustomerIsOverCreditLimitString
        {
            get
            {
                if (CustomerIsOverCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CustomerIsOverAgingLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CustomerIsOverAgingLimitString
        {
            get
            {
                if (CustomerIsOverAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "NatAcctIsOverCreditLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string NatAcctIsOverCreditLimitString
        {
            get
            {
                if (NatAcctIsOverCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "NatAcctIsOverAgingLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string NatAcctIsOverAgingLimitString
        {
            get
            {
                if (NatAcctIsOverAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ARPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string ARPendingTransIncludedString
        {
            get
            {
                if (ARPendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "OEPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string OEPendingTransIncludedString
        {
            get
            {
                if (OEPendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "OtherPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string OtherPendingTransIncludedString
        {
            get
            {
                if (OtherPendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "DrivenbyUI", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string DrivenbyUIString
        {
            get
            {
                if (DrivenbyUI)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "TRInvoiceRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string TRInvoiceRateOverrideFlagString
        {
            get
            {
                if (TRInvoiceRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Gets or sets PreCreditCheckStatus
        /// </summary>
        [IgnoreExportImport]
        public PreCreditCheckStatus PreCreditCheckStatus { get; set; }

        /// <summary>
        /// Gets or sets ProceedPreCreditCheckStatus
        /// </summary>
        [IgnoreExportImport]
        public bool ProceedPreCreditCheckStatus { get; set; }

        #endregion

    }
}
