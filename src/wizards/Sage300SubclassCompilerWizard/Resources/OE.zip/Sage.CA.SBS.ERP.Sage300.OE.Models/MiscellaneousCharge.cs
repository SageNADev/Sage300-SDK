// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// MiscellaneousCharge model
    /// </summary>
    public partial class MiscellaneousCharge : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the MiscellaneousCharge Header/> class.
        /// </summary>
        public MiscellaneousCharge()
        {
            TaxDetails = new EnumerableResponse<MiscellaneousChargeTax>();
            OptionalFieldDetails = new EnumerableResponse<MiscChargeOptionalField>();
        }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets MiscellaneousChargeCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscChargeCode", ResourceType = typeof(MiscellaneousChargesResx))]
        [ViewField(Name = Fields.MiscellaneousChargeCode, Id = Index.MiscellaneousChargeCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string MiscellaneousChargeCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscChargeCodeDesc", ResourceType = typeof(MiscellaneousChargesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets MiscChargeRevenueAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscChargeRevenue", ResourceType = typeof(MiscellaneousChargesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.MiscChargeRevenueAccount, Id = Index.MiscChargeRevenueAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string MiscChargeRevenueAccount { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [Display(Name = "Amount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets AccountDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountDescription", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.AccountDescription, Id = Index.AccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Get or Set ProcessCommand 
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(OECommonResx))]
        public string ProcessCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank JobRelated { get; set; }

        /// <summary>
        /// Get or Set JobRelated 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(OECommonResx))]
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets MiscChargeExpenseAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscChargeExpenseAccount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.MiscChargeExpenseAccount, Id = Index.MiscChargeExpenseAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string MiscChargeExpenseAccount { get; set; }

        /// <summary>
        /// Gets or sets MiscChargeClearingAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscChargeClearingAccount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.MiscChargeClearingAccount, Id = Index.MiscChargeClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string MiscChargeClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets MiscChargeCostExpenseAccount
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscChargeExpenseAccountDesc", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.MiscChargeCostExpenseAccountDescription, Id = Index.MiscChargeCostExpenseAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string MiscChargeCostExpenseAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets Misc.Charge Clearing Account Desc.
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscChargeClearingAccountDesc", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.MiscChargeClearingAccountDescription, Id = Index.MiscChargeClearingAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string MiscChargeClearingAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FunctionalCurrency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Tax details list
        /// </summary>
        public EnumerableResponse<MiscellaneousChargeTax> TaxDetails { get; set; }

        /// <summary>
        /// Optional Field details list
        /// </summary>
        public EnumerableResponse<MiscChargeOptionalField> OptionalFieldDetails { get; set; }

        /// <summary>
        /// Gets or sets Is New Record
        /// </summary>
        public bool IsNewRecord { get; set; }

        /// <summary>
        /// Optional field popup loaded flag
        /// </summary>
        public bool IsOptinalFieldLoaded { get; set; }
    }
}
