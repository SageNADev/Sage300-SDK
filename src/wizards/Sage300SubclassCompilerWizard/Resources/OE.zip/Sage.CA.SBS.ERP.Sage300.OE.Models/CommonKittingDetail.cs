﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Class for CommonKittingDetail
    /// </summary>
    public class CommonKittingDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Uniquifier
        /// </summary>
        [Key]
        [Display(Name = "CNUniquifier", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public decimal CnUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Display(Name = "LineNumber", ResourceType = typeof(OECommonResx))]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        [Display(Name = "SerialNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public int SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentLineNumber
        /// </summary>
        [Display(Name = "ComponentLineNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public long ComponentLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentItem
        /// </summary>
        [Display(Name = "ComponentItemNumber", ResourceType = typeof(OECommonResx))]
        public string ComponentItem { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(OECommonResx))]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets KittingQuantity
        /// </summary>
        [Display(Name = "KittingQuantity", ResourceType = typeof(OECommonResx))]
        public decimal KittingQuantity { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturned
        /// </summary>
        [Display(Name = "QuantityReturned", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public decimal QuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets ItemSerializedLotted
        /// </summary>
        [Display(Name = "ItemSerializedLotted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public ItemSerializedLotted ItemSerializedLotted { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(OECommonResx))]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets WeightUnitOfMeasure
        /// </summary>
        [Display(Name = "WeightUnitofMeasure", ResourceType = typeof(OECommonResx))]
        public string WeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets WeightUomDescription
        /// </summary>
        [Display(Name = "WeightUOMDescription", ResourceType = typeof(OECommonResx))]
        public string WeightUomDescription { get; set; }

        /// <summary>
        /// Gets or sets UnitWeight
        /// </summary>
        [Display(Name = "UnitWeight", ResourceType = typeof(OECommonResx))]
        public decimal UnitWeight { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [Display(Name = "ExtendedWeight", ResourceType = typeof(OECommonResx))]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitOfMeasure
        /// </summary>
        [Display(Name = "CostingUnitOfMeasure", ResourceType = typeof(OECommonResx))]
        public string CostingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitCost
        /// </summary>
        [Display(Name = "CostingUnitCost", ResourceType = typeof(OECommonResx))]
        public decimal CostingUnitCost { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearingAccount
        /// </summary>
        [Display(Name = "NonstockClearingAccount", ResourceType = typeof(OECommonResx))]
        public string NonstockClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(OECommonResx))]
        public decimal UnitCost { get; set; }
    }
}
