﻿/* Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    public class InvoiceSecurity
    {
        #region Properties Added for Security

        /// <summary>
        /// Gets or sets HasInquiryRightsOeshhd
        /// </summary>
        [IgnoreExportImport]
        public bool HasOEUpdateRights { get; set; }

        /// <summary>
        /// Gets or sets HasInquiryRightsOeshhd
        /// </summary>
        [IgnoreExportImport]
        public bool HasInquiryRightsOeshhd { get; set; }

        /// <summary>
        /// Gets or sets bCanAddARCustomer
        /// </summary>
        [IgnoreExportImport]
        public bool CanAddARCustomer { get; set; }

        /// <summary>
        /// Gets or sets HasOnHoldRemovalRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasOnHoldRemovalRights { get; set; }

        /// <summary>
        /// Gets or sets HasAddModifyRightsArbta
        /// </summary>
        [IgnoreExportImport]
        public bool HasAddModifyRightsArbta { get; set; }
        /// <summary>
        /// Gets or sets CanPrintTransList
        /// </summary>
        [IgnoreExportImport]
        public bool CanPrintTransList { get; set; }

        /// <summary>
        /// Gets or sets HasShipmentRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasShipmentRights { get; set; }

        /// <summary>
        /// Gets or sets HasInvoiceRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasInvoiceRights { get; set; }

        /// <summary>
        /// Gets or sets HasOFTransRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasOFTransRights { get; set; }

        /// <summary>
        /// Gets or sets HasYPTransactionRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasYPTransactionRights { get; set; }

        /// <summary>
        /// Gets or sets HasPOCreateRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasPOCreateRights { get; set; }

        /// <summary>
        /// Gets or sets HasPrintOrder
        /// </summary>
        [IgnoreExportImport]
        public bool HasPrintOrder { get; set; }

        /// <summary>
        /// Gets or sets HasPrintPickingSlip
        /// </summary>
        [IgnoreExportImport]
        public bool HasPrintPickingSlip { get; set; }

        /// <summary>
        /// Gets or sets HasPrintInvoice
        /// </summary>
        [IgnoreExportImport]
        public bool HasPrintInvoice { get; set; }

        /// <summary>
        /// Gets or sets HasQuotesPrintRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasQuotesPrintRights { get; set; }

        /// <summary>
        /// Gets or sets Optional Field active
        /// </summary>
        [IgnoreExportImport]
        public bool OptionalFieldActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating the right to approve price checks.
        /// license)
        /// </summary>
        [IgnoreExportImport]
        public bool PriceCheckApproval { get; set; }

        /// <summary>
        /// Gets or sets a value indicating the right to item cost inquiry checks.
        /// license)
        /// </summary>
        [IgnoreExportImport]
        public bool HasItemCostInquiryRight { get; set; }

        /// <summary>
        /// Gets or sets a value indicating the right to item location document inquiry checks.
        /// license)
        /// </summary>
        [IgnoreExportImport]
        public bool HasICLocationDocumentRights { get; set; }

        /// <summary>
        /// Gets or sets a value indicating the right to access sales history checks.
        /// license)
        /// </summary>
        [IgnoreExportImport]
        public bool CanAccessSalesHistory { get; set; }

        /// <summary>
        /// Gets or sets a value indicating the right to modify invoice checks.
        /// license)
        /// </summary>
        [IgnoreExportImport]
        public bool CanModifyInvoice { get; set; }
        #endregion
    }
}
