// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Partial class for OrderfromQuote
     /// </summary>
     public partial class OrderfromQuote : ModelBase
     {
          /// <summary>
          /// Gets or sets OrderUniquifier
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal OrderUniquifier {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int LineNumber {get; set;}

          /// <summary>
          /// Gets or sets QuoteUniquifier
          /// </summary>
          [ViewField(Name = Fields.QuoteUniquifier, Id = Index.QuoteUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal QuoteUniquifier {get; set;}

          /// <summary>
          /// Gets or sets QuoteNumber
          /// </summary>
          [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "QuoteNUMBER", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.QuoteNumber, Id = Index.QuoteNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
          public string QuoteNumber {get; set;}

          /// <summary>
          /// Gets or sets DocumentDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime DocumentDate {get; set;}

          /// <summary>
          /// Gets or sets Description
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
          public string Description {get; set;}

     }
}
