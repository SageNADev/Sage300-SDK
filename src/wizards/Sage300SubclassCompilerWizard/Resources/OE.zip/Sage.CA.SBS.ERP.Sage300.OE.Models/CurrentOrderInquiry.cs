// /* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for Current OrderInquiry
    /// </summary>
    public partial class CurrentOrderInquiry : ModelBase
    {
        /// <summary>
        /// Gets or sets Ordernumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets POnumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof (OECommonResx))]
        public string PoNumber { get; set; }

        /// <summary>
        /// Gets or sets Printstatus
        /// </summary>
        [Display(Name = "PrintStatus", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.PrintStatus, Id = Index.PrintStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public PrintStatus PrintStatus { get; set; }

        /// <summary>
        /// Gets or sets Orderdate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "OrderDate", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets Expectedshipdate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "ExpShipDate", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.ExpectedShipDate, Id = Index.ExpectedShipDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpectedShipDate { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets Onhold
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Bool, Size = 2)]
        public OnHold OnHold { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderType Type { get; set; }

        /// <summary>
        /// Gets or sets Shipto
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ShipToLocation", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipTo, Id = Index.ShipTo, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipTo { get; set; }

        /// <summary>
        /// Gets or sets Shipvia
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ShipVia", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.ShipVia, Id = Index.ShipVia, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipVia { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets FOB
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "FobPoint", ResourceType = typeof(CurrentOrderInquiryResx))]
        public string FobPoint { get; set; }

        /// <summary>
        /// Gets or sets Territory
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Territory", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.Territory, Id = Index.Territory, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Territory { get; set; }

        /// <summary>
        /// Gets or sets Terms
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Terms", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Pricelist
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PriceList", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceList { get; set; }

        /// <summary>
        /// Gets or sets Taxgroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets Customernumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets Fromordernumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "FromOrderNumber", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.FromOrderNumber, Id = Index.FromOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string FromOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets Toordernumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ToOrderNumber", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.ToOrderNumber, Id = Index.ToOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ToOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets Fromorderdate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderDate", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.FromOrderDate, Id = Index.FromOrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? FromOrderDate { get; set; }

        /// <summary>
        /// Gets or sets Toorderdate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OrderDate", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.ToOrderDate, Id = Index.ToOrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ToOrderDate { get; set; }

        /// <summary>
        /// Gets or sets FromExpectedshipdate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpShipDate", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.FromExpectedShipDate, Id = Index.FromExpectedShipDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? FromExpectedShipDate { get; set; }

        /// <summary>
        /// Gets or sets ToExpectedshipdate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ExpShipDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ToExpectedShipDate, Id = Index.ToExpectedShipDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ToExpectedShipDate { get; set; }

        /// <summary>
        /// Gets or sets Ordertype
        /// </summary>
        [Display(Name = "OrderType", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.OrderType, Id = Index.OrderType, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderTypeInquiry OrderType { get; set; }

        /// <summary>
        /// Gets or sets OrderStatus
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.OrderStatus, Id = Index.OrderStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderStatusAll OrderStatus { get; set; }

        /// <summary>
        /// Gets or sets OrderStatus
        /// Duplicating the property because on order type change, order status should be different.
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(OECommonResx))]
        public OrderStatusOther OrderStatusOther { get; set; }

        /// <summary>
        /// Gets or sets OrderStatus
        /// Duplicating the property because on order type change, order status should be different.
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(OECommonResx))]
        public OrderStatusQuote OrderStatusQuote { get; set; }

        /// <summary>
        /// Gets or sets Action
        /// </summary>
        [Display(Name = "Action", ResourceType = typeof (CurrentOrderInquiryResx))]
        [ViewField(Name = Fields.Action, Id = Index.Action, FieldType = EntityFieldType.Int, Size = 2)]
        public int Action { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Printstatus string value
        /// </summary>
        public string PrintStatusString
        {
            get { return EnumUtility.GetStringValue(PrintStatus); }
        }

        /// <summary>
        /// Gets Onhold string value
        /// </summary>
        public string OnHoldString
        {
            get { return EnumUtility.GetStringValue(OnHold); }
        }

        /// <summary>
        /// Gets Type string value
        /// </summary>
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets Ordertype string value
        /// </summary>
        public string OrderTypeString
        {
            get { return EnumUtility.GetStringValue(OrderType); }
        }

        /// <summary>
        /// Gets OrderStatus string value
        /// </summary>
        public string OrderStatusString
        {
            get { return EnumUtility.GetStringValue(OrderStatus); }
        }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The SerialNumber.</value>
        public long SerialNumber { get; set; } 

        #endregion
    }
}
