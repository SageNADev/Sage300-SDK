// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Class for Common BOMDetail
    /// </summary>
    public  class CommonBomDetail:ModelBase
    {

        /// <summary>
        /// Gets or sets Uniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal Uniquifier { get; set; }

        /// <summary>
        /// Gets or sets DetailLineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int DetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ParentComponentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public long ParentComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public long ComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentItemNo
        /// </summary>
        [Display(Name = "ComponentItemNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ComponentItemNo { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(OECommonResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturned
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(CommonResx))]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets ComponentsBOMNumber
        /// </summary>
        [Display(Name = "CompBomNo", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ComponentsBomNumber { get; set; }

        /// <summary>
        /// Gets or sets QuantityOrdered
        /// </summary>
        [Display(Name = "QtyOrdered", ResourceType = typeof(OECommonResx))]
        public decimal QuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets QuantityShipped
        /// </summary>
        [Display(Name = "QtyShipped", ResourceType = typeof(OECommonResx))]
        public decimal QuantityShipped { get; set; }

    }
}
