// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for CreditDebitKittingDetail
    /// </summary>
    public partial class CreditDebitKittingDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets CNUniquifier
        /// </summary>
        [Key]
        [Display(Name = "CNUniquifier", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CnUniquifier, Id = Index.CnUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CnUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Display(Name = "LineNumber", ResourceType = typeof(OECommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets Serial Number
        /// </summary>
        [Display(Name = "SerialNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public int SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets ParentComponentNumber
        /// </summary>
        [Key]
        [Display(Name = "ParentComponentNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ParentComponentNumber, Id = Index.ParentComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ParentComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentNumber
        /// </summary>
        [Key]
        [Display(Name = "ComponentNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ComponentNumber, Id = Index.ComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentItem
        /// </summary>
        [Display(Name = "ComponentItemNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ComponentItem, Id = Index.ComponentItem, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ComponentItem { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ItemAccountSet
        /// </summary>
        [Display(Name = "ItemAccountSet", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ItemAccountSet, Id = Index.ItemAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ItemAccountSet { get; set; }

        /// <summary>
        /// Gets or sets UserSpecifiedCostingMethod
        /// </summary>
        [Display(Name = "UserSpecifiedCostingMethod", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UserSpecifiedCostingMethod, Id = Index.UserSpecifiedCostingMethod, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UserSpecifiedCostingMethod { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Display(Name = "Location", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets PickingSequence
        /// </summary>
        [Display(Name = "PickingSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PickingSequence, Id = Index.PickingSequence, FieldType = EntityFieldType.Char, Size = 10)]
        public string PickingSequence { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        [Display(Name = "StockItem", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StockItem { get; set; }

        /// <summary>
        /// Gets or sets KittingQuantity
        /// </summary>
        [Display(Name = "KittingQuantity", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.KittingQuantity, Id = Index.KittingQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal KittingQuantity { get; set; }

        /// <summary>
        /// Gets or sets ParentQuantityReturned
        /// </summary>
        [Display(Name = "ParentQuantityReturned", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ParentQuantityReturned, Id = Index.ParentQuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ParentQuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets ParentUnitOfMeasure
        /// </summary>
        [Display(Name = "ParentUnitOfMeasure", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ParentUnitOfMeasure, Id = Index.ParentUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string ParentUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets ParentUnitConversion
        /// </summary>
        [Display(Name = "ParentUnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ParentUnitConversion, Id = Index.ParentUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ParentUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturned
        /// </summary>
        [Display(Name = "QuantityReturned", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.QuantityReturned, Id = Index.QuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(OECommonResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets UnitConversion
        /// </summary>
        [Display(Name = "UnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnitConversion, Id = Index.UnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitConversion { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets MostRecentUnitCost
        /// </summary>
        [Display(Name = "MostRecentUnitCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.MostRecentUnitCost, Id = Index.MostRecentUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal MostRecentUnitCost { get; set; }

        /// <summary>
        /// Gets or sets StandardUnitCost
        /// </summary>
        [Display(Name = "StandardUnitCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.StandardUnitCost, Id = Index.StandardUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal StandardUnitCost { get; set; }

        /// <summary>
        /// Gets or sets AlternateUnitCost1
        /// </summary>
        [Display(Name = "AlternateUnitCost1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AlternateUnitCost1, Id = Index.AlternateUnitCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AlternateUnitCost1 { get; set; }

        /// <summary>
        /// Gets or sets AlternateUnitCost2
        /// </summary>
        [Display(Name = "AlternateUnitCost2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AlternateUnitCost2, Id = Index.AlternateUnitCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AlternateUnitCost2 { get; set; }

        /// <summary>
        /// Gets or sets AverageUnitCost
        /// </summary>
        [Display(Name = "AverageUnitCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AverageUnitCost, Id = Index.AverageUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AverageUnitCost { get; set; }

        /// <summary>
        /// Gets or sets LastUnitCost
        /// </summary>
        [Display(Name = "LastUnitCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LastUnitCost, Id = Index.LastUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal LastUnitCost { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CostingUnitOfMeasure, Id = Index.CostingUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string CostingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitCost
        /// </summary>
        [Display(Name = "CostingUnitOfMeasure", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CostingUnitCost, Id = Index.CostingUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal CostingUnitCost { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitConversion
        /// </summary>
        [Display(Name = "CostingUnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CostingUnitConversion, Id = Index.CostingUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal CostingUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets ExtendedOrderCost
        /// </summary>
        [Display(Name = "ExtendedOrderCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtendedOrderCost, Id = Index.ExtendedOrderCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedOrderCost { get; set; }

        /// <summary>
        /// Gets or sets UnitWeight
        /// </summary>
        [Display(Name = "UnitWeight", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.UnitWeight, Id = Index.UnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal UnitWeight { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [Display(Name = "ExtendedWeight", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearingAccount
        /// </summary>
        [Display(Name = "NonstockClearingAccount", ResourceType = typeof(OECommonResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NonstockClearingAccount, Id = Index.NonstockClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string NonstockClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets WeightUnitOfMeasure
        /// </summary>
        [Display(Name = "WeightUnitofMeasure", ResourceType = typeof(OECommonResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.WeightUnitOfMeasure, Id = Index.WeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string WeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets WeightConversionFactor
        /// </summary>
        [Display(Name = "WeightConversionFactor", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.WeightConversionFactor, Id = Index.WeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal WeightConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets ParentWeightConversionFactor
        /// </summary>
        [Display(Name = "ParentWeightConversionFactor", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ParentWeightConversionFactor, Id = Index.ParentWeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ParentWeightConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets ParentWeightUOMUnitWeight
        /// </summary>
        [Display(Name = "ParentWeightUomUnitWeight", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ParentWeightUomUnitWeight, Id = Index.ParentWeightUomUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ParentWeightUomUnitWeight { get; set; }

        /// <summary>
        /// Gets or sets ParentWUOMExtendedUnitWeight
        /// </summary>
        [Display(Name = "ParentWUomExtendedUnitWeight", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ParentWUomExtendedUnitWeight, Id = Index.ParentWUomExtendedUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ParentWUomExtendedUnitWeight { get; set; }

        /// <summary>
        /// Gets or sets KitNo
        /// </summary>
        [Display(Name = "KittingNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.KitNo, Id = Index.KitNo, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string KitNo { get; set; }

        /// <summary>
        /// Gets or sets CostOfGoods
        /// </summary>
        [Display(Name = "CostOfGoods", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CostOfGoods, Id = Index.CostOfGoods, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostOfGoods { get; set; }

        /// <summary>
        /// Gets or sets RecordCosted
        /// </summary>
        [Display(Name = "RecordCosted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RecordCosted, Id = Index.RecordCosted, FieldType = EntityFieldType.Bool, Size = 2)]
        public RecordCosted RecordCosted { get; set; }

        /// <summary>
        /// Gets or sets SerialQuantity
        /// </summary>
        [Display(Name = "SerialQuantity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.SerialQuantity, Id = Index.SerialQuantity, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialQuantity { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets ItemSerializedLotted
        /// </summary>
        [Display(Name = "ItemSerializedLotted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ItemSerializedLotted, Id = Index.ItemSerializedLotted, FieldType = EntityFieldType.Int, Size = 2)]
        public ItemSerializedLotted ItemSerializedLotted { get; set; }

        /// <summary>
        /// Gets or sets ComponentUnitCost
        /// </summary>
        [Display(Name = "ComponentUnitCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ComponentUnitCost, Id = Index.ComponentUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ComponentUnitCost { get; set; }

        /// <summary>
        /// Gets or sets MostRecentComponentCost
        /// </summary>
        [Display(Name = "MostRecentComponentCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.MostRecentComponentCost, Id = Index.MostRecentComponentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal MostRecentComponentCost { get; set; }

        /// <summary>
        /// Gets or sets StandardComponentCost
        /// </summary>
        [Display(Name = "StandardComponentCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.StandardComponentCost, Id = Index.StandardComponentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal StandardComponentCost { get; set; }

        /// <summary>
        /// Gets or sets AlternateComponentCost1
        /// </summary>
        [Display(Name = "AlternateComponentCost1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AlternateComponentCost1, Id = Index.AlternateComponentCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AlternateComponentCost1 { get; set; }

        /// <summary>
        /// Gets or sets AlternateComponentCost2
        /// </summary>
        [Display(Name = "AlternateComponentCost2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AlternateComponentCost2, Id = Index.AlternateComponentCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AlternateComponentCost2 { get; set; }

        /// <summary>
        /// Gets or sets AverageComponentCost
        /// </summary>
        [Display(Name = "AverageComponentCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AverageComponentCost, Id = Index.AverageComponentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AverageComponentCost { get; set; }

        /// <summary>
        /// Gets or sets LastComponentCost
        /// </summary>
        [Display(Name = "LastComponentCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LastComponentCost, Id = Index.LastComponentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal LastComponentCost { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearingAcctDesc
        /// </summary>
        [Display(Name = "NonstockClearingAcctDesc", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NonstockClearingAcctDesc, Id = Index.NonstockClearingAcctDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string NonstockClearingAcctDesc { get; set; }

        /// <summary>
        /// Gets or sets InterprocessCommID
        /// </summary>
        [Display(Name = "InterprocessCommId", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InterprocessCommID, Id = Index.InterprocessCommID, FieldType = EntityFieldType.Long, Size = 4)]
        public long InterprocessCommID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSN
        /// </summary>
        [Display(Name = "ForcePopupSn", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ForcePopupSn, Id = Index.ForcePopupSn, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupSN ForcePopupSn { get; set; }

        /// <summary>
        /// Gets or sets PopupSN
        /// </summary>
        [Display(Name = "PopupSn", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PopupSn, Id = Index.PopupSn, FieldType = EntityFieldType.Int, Size = 2)]
        public PopupSN PopupSn { get; set; }

        /// <summary>
        /// Gets or sets CloseSN
        /// </summary>
        [Display(Name = "CloseSn", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CloseSn, Id = Index.CloseSn, FieldType = EntityFieldType.Bool, Size = 2)]
        public CloseSN CloseSn { get; set; }

        /// <summary>
        /// Gets or sets LTSetID
        /// </summary>
        [Display(Name = "LtSetId", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LtSetId, Id = Index.LtSetId, FieldType = EntityFieldType.Long, Size = 4)]
        public long LtSetId { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLT
        /// </summary>
        [Display(Name = "ForcePopupLt", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ForcePopupLt, Id = Index.ForcePopupLt, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupLT ForcePopupLt { get; set; }

        /// <summary>
        /// Gets or sets PopupLT
        /// </summary>
        [Display(Name = "PopupLt", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PopupLt, Id = Index.PopupLt, FieldType = EntityFieldType.Int, Size = 2)]
        public PopupLT PopupLt { get; set; }

        /// <summary>
        /// Gets or sets CloseLT
        /// </summary>
        [Display(Name = "CloseLt", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CloseLt, Id = Index.CloseLt, FieldType = EntityFieldType.Bool, Size = 2)]
        public CloseLT CloseLt { get; set; }

        /// <summary>
        /// Gets or sets CcomponentSerialized
        /// </summary>
        [Display(Name = "CcomponentSerialized", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CcomponentSerialized, Id = Index.CcomponentSerialized, FieldType = EntityFieldType.Bool, Size = 2)]
        public ComponentSerialized CcomponentSerialized { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber
        /// </summary>
        [Display(Name = "ShipmentNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDetailLineNumber
        /// </summary>
        [Display(Name = "ShipmentDetailLineNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipmentDetailLineNumber, Id = Index.ShipmentDetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentDetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ReturnType
        /// </summary>
        [Display(Name = "ReturnType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ReturnType, Id = Index.ReturnType, FieldType = EntityFieldType.Int, Size = 2)]
        public ReturnType ReturnType { get; set; }

        /// <summary>
        /// Gets or sets ComponentLotted
        /// </summary>
        [Display(Name = "ComponentLotted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ComponentLotted, Id = Index.ComponentLotted, FieldType = EntityFieldType.Bool, Size = 2)]
        public ComponentLotted ComponentLotted { get; set; }

        /// <summary>
        /// Gets or sets WeightUOMDescription
        /// </summary>
        [Display(Name = "WeightUOMDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.WeightUomDescription, Id = Index.WeightUomDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string WeightUomDescription { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets SerialLotQuantityToProcess
        /// </summary>
        [Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SerialLotQuantityToProcess { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate
        /// </summary>
        [Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets QuantityperLot
        /// </summary>
        [Display(Name = "QuantityperLot", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityperLot { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromSerial
        /// </summary>
        [Display(Name = "AllocateFromSerial", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromSerial { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromLot
        /// </summary>
        [Display(Name = "AllocateFromLot", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromLot { get; set; }

        /// <summary>
        /// Gets or sets SerialLotWindowHandle
        /// </summary>
        [Display(Name = "SerialLotWindowHandle", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialLotWindowHandle { get; set; }
    }
}
