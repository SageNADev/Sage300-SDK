/*Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.*/

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
    /// Partial class for Ship-Via Code
     /// </summary>
    public partial class ShipViaCode : ModelBase
     {
          /// <summary>
          /// Gets or sets Code
          /// </summary>
          [Key]
          [Display(Name = "ShipViaCode", ResourceType = typeof(OECommonResx))]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Code, Id = Index.Code, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
          public string Code {get; set;}

          /// <summary>
          /// Gets or sets Name
          /// </summary>
          [Display(Name = "Name", ResourceType = typeof(CommonResx))]
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
          public string Name {get; set;}

          /// <summary>
          /// Gets or sets AddressLine1
          /// </summary>
          [Display(Name = "AddressLine1", ResourceType = typeof(OECommonResx))]
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
          public string AddressLine1 {get; set;}

          /// <summary>
          /// Gets or sets AddressLine2
          /// </summary>
          [Display(Name = "AddressLine2", ResourceType = typeof(OECommonResx))]
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
          public string AddressLine2 {get; set;}

          /// <summary>
          /// Gets or sets AddressLine3
          /// </summary>
          [Display(Name = "AddressLine3", ResourceType = typeof(OECommonResx))]
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
          public string AddressLine3 {get; set;}

          /// <summary>
          /// Gets or sets AddressLine4
          /// </summary>
          [Display(Name = "AddressLine4", ResourceType = typeof(OECommonResx))]
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
          public string AddressLine4 {get; set;}

          /// <summary>
          /// Gets or sets City
          /// </summary>
          [Display(Name = "City", ResourceType = typeof(OECommonResx))]
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
          public string City {get; set;}

          /// <summary>
          /// Gets or sets StateProvince
          /// </summary>
          [Display(Name = "StateProvince", ResourceType = typeof(OECommonResx))]
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.StateProvince, Id = Index.StateProvince, FieldType = EntityFieldType.Char, Size = 30)]
          public string StateProvince {get; set;}

          /// <summary>
          /// Gets or sets ZipPostalCode
          /// </summary>
          [Display(Name = "ZIPPostal", ResourceType = typeof(CommonResx))]
          [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ZipPostalCode, Id = Index.ZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
          public string ZipPostalCode {get; set;}

          /// <summary>
          /// Gets or sets Country
          /// </summary>
          [Display(Name = "Country", ResourceType = typeof(OECommonResx))]
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
          public string Country {get; set;}

          /// <summary>
          /// Gets or sets PhoneNumber
          /// </summary>
          [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
          public string PhoneNumber {get; set;}

          /// <summary>
          /// Gets or sets FaxNumber
          /// </summary>
           [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
          public string FaxNumber {get; set;}

          /// <summary>
          /// Gets or sets Contact
          /// </summary>
          [Display(Name = "Name", ResourceType = typeof(CommonResx))]
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
          public string Contact {get; set;}

          /// <summary>
          /// Gets or sets Comment
          /// </summary>
          [Display(Name = "Comment", ResourceType = typeof(OECommonResx))]
          [StringLength(80, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 80)]
          public string Comment {get; set;}

          /// <summary>
          /// Gets or sets ShipViaEmail
          /// </summary>
          [Display(Name = "Email", ResourceType = typeof(CommonResx))]
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ShipViaEmail, Id = Index.ShipViaEmail, FieldType = EntityFieldType.Char, Size = 50)]
          public string ShipViaEmail {get; set;}

          /// <summary>
          /// Gets or sets ContactPhone
          /// </summary>
          [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ContactPhone, Id = Index.ContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
          public string ContactPhone {get; set;}

          /// <summary>
          /// Gets or sets ContactFax
          /// </summary>
           [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ContactFax, Id = Index.ContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
          public string ContactFax {get; set;}

          /// <summary>
          /// Gets or sets ContactEmail
          /// </summary>
          [Display(Name = "Email", ResourceType = typeof(CommonResx))]
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ContactEmail, Id = Index.ContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
          public string ContactEmail {get; set;}
     }
}
