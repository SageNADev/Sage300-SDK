﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    ///  Static Class for OE Module constants 
    /// </summary>
    public static class OeConstants
    {
        #region Reports

        /// <summary>
        /// Constant for Application Id
        /// </summary>
        public const string OEApplicationId = "OE";

        /// <summary>
        /// Constant for Yes Value
        /// </summary>
        public const string Yes = "Y";

        /// <summary>
        /// Constant for No Value
        /// </summary>
        public const string No = "N";

        /// <summary>
        /// Constant for Zero Value
        /// </summary>
        public const int Inactive = 0;

        /// <summary>
        /// Constant for One Value
        /// </summary>
        public const int Active = 1;

        /// <summary>
        /// Constant for Empty String
        /// </summary>
        public const string EmptyValue = " ";

        /// <summary>
        /// Constant for Functional Currency
        /// </summary>
        public const string FunctionalCurrency = "F";

        /// <summary>
        /// Constant for Vendor Currency
        /// </summary>
        public const string VendorCurrency = "V";

        /// <summary>
        /// Constant for Customer Currency
        /// </summary>
        public const string CustomerCurrency = "S";

        /// <summary>
        /// Constant for Empty Date Value
        /// </summary>
        public const string EmptyDate = "00000000";

        /// <summary>
        /// Constant for Empty Year
        /// </summary>
        public const string EmptyYear = "0000";

        /// <summary>
        /// Constant for Adding Comma with Space
        /// </summary>
        public const string AddComma = ", ";

        /// <summary>
        /// Constant for Currency Decimal
        /// </summary>
        public const string CurrencyDecimal = "3";

        /// <summary>
        /// Constant for Age Sequence
        /// </summary>
        public const string AgeSequence = "1";

		 /// <summary>
        /// Constant for Question Mark
        /// </summary>
        public const string Question = "?";

        /// <summary>
        /// Constant for Default Pad Value
        /// </summary>
        public const int DefaultPadValue = 2;

        /// <summary>
        /// Constant for Field Length Four
        /// </summary>
        public const string FieldLengthFour = "4";

        /// <summary>
        /// Constant for Field Length Six
        /// </summary>
        public const string FieldLengthSix = "6";

        /// <summary>
        /// Constant for Field Length Ten
        /// </summary>
        public const string FieldLengthTen = "10";

        /// <summary>
        /// Constant for Field Length Twelve
        /// </summary>
        public const string FieldLengthTwelve = "12";

        /// <summary>
        /// Constant for Field Length Six
        /// </summary>
        public const string FieldLengthFourteen = "14";

        /// <summary>
        /// Constant for Field Length Six
        /// </summary>
        public const string FieldLengthSixty = "60";

        /// <summary>
        /// Constant for Count
        /// </summary>
        public const string Count = "/Count";

        /// <summary>
        /// Constant for Null Date value
        /// </summary>
        public const string NullDate = "0";

        /// <summary>
        /// Constant for Closing Bracket
        /// </summary>
        public const string ClosingBracket = ")";

        /// <summary>
        /// Constant for False Value
        /// </summary>
        public const string Exclude = "0";

        /// <summary>
        /// Constant for True Value
        /// </summary>
        public const string Include = "1";
		
        /// <summary>
        /// The level1 name
        /// </summary>
        public const string Level1Name = "Contract";
        
        /// <summary>
        /// The level2 name
        /// </summary>
        public const string Level2Name = "Project";

        /// <summary>
        /// The level2 name
        /// </summary>
        public const string Level3Name = "Category";

        /// <summary>
        /// The level2 name
        /// </summary>
        public const string OrderNumber = "ORDNUMBER";

        /// <summary>
        /// The level2 name
        /// </summary>
        public const string CustomerNumber = "CUSTOMER";

        /// <summary>
        /// The level2 name
        /// </summary>
        public const string PrimarySalesPerson = "SALESPER1";
        
        /// <summary>
        /// Application Id
        /// </summary>
        public const string ApplicationId = "PM";

        /// <summary>
        /// The check language string
        /// </summary>
        public const string CheckLanguageString = "Check Languages";

        #region Order Action Report

        public const string OaProgramId = "OE3120";

        public const string OrderActionDetail = "OEORDACD";

        public const string OrderActionSummary = "OEORDACS";

        public const int FieldLengthTwentyTwo = 22;
        
        #endregion
        
        #region O/E Forms - Order Confirmations Report

        public const string OcProgramId = "OE3110";

        public const string OcReportName = "OETRANSACTIONLIST";

        #endregion

        #region Transaction List Report
        public const string TlProgramId = "OE3110";

        public const string Report = "OETRANSACTIONLIST";

        public const string SortFromOrderThenCustomer = "OEORDH.ORDNUMBER,OEORDH.CUSTOMER";

        public const string SortFromInvoiceThenCustomer = "OEINVH.INVNUMBER,OEINVH.CUSTOMER";

        public const string SortFromShipmentThenCustomer = "OESHIH.SHINUMBER,OESHIH.CUSTOMER";

        public const string SortFromCreditNoteThenCustomer = "OECRDH.CRDNUMBER,OECRDH.CUSTOMER";

        public const string OrderSummaryReportName = "OEORDSUM";

        public const string OrderDetailReportName = "OEORLST1";


        public const string InvoiceSummaryReportName = "OEINVSUM";

        public const string InvoiceDetailReportName = "OEINLST1";

        public const string CreditNoteSummaryReportName = "OECNSUM";

        public const string CreditNoteDetailReportName = "OECRLST1";

        public const string ShipmentSummaryReportName = "OESHISUM";

        public const string ShipmentDetailReportName = "OESHLST1";

        public const string SortFromCustomerThenOrder = "OEORDH.CUSTOMER,OEORDH.ORDNUMBER";

        public const string SortFromCustomerThenInvoice = "OEINVH.CUSTOMER,OEINVH.INVNUMBER";

        public const string SortFromCustomerThenShipment = "OESHIH.CUSTOMER,OESHIH.SHINUMBER";

        public const string SortFromCustomerThenCreditNote = "OECRDH.CUSTOMER,OECRDH.CRDNUMBER";

        public const string TocuurencyForSingleCurrency = "ZZZ";

        public const string SearchCriteriaCreditDebitNote = "{OECRDH.CRDNUMBER}";

        public const string SearchCriteriaInvoice = "{OEINVH.INVNUMBER}";


        /// <summary>
        /// Constant for Default Date Format for Transaction Report Screen
        /// </summary>
        public const string TlDefaultDateFormat = "yyyyddMM";

        #endregion


        #region AgedOrder
        public const int OerptsOperationCreatetmpfile = 1;
        public const int OerptsOperationDeletetmpfile = 2;
        public const int OerptsOperationCreatetmpfile2 = 3;
        public const int OerptsOperationDeletetmpfile2 = 4;

        public const string AOReportName = "OEAGED01";
        public const string ProgramId = "OE3140";
        public const string MenuId = "<MENU ID>";
        public const string OrderNumberparam = "ORDNUMBER";
        public const string Customerparam = "CUSTOMER";
        public const string SourceCurrparam = "ORSOURCURR";

        #endregion AgedOrder

        #region SalespersonCommissions
        public const string SpProgramId = "OE3220";
        public const string ReportDetail1 = "OEDCOMM";
        public const string ReportDetail2 = "OEDCOMM2";
        public const string ReportDetail3 = "OEDCOMM1";
        public const string ReportSummary1 = "OESCOMM";
        public const string ReportSummary2 = "OESCOMM1";
        public const char Z = 'Z';
        public const int LenToSales = 8;
        #endregion SalespersonCommissions

        public const string PJRptNameLegalMulticurrShipmnt = "OESIPJM1";
        public const string PJRptNameLetterMulticurrShipmnt = "OESIPJM2";
        public const string PJRptNameSinglecurShipmnt = "OESIPJ01";
        public const string PJRptNameLegalMulticurrCrDb = "OECDPJM1";
        public const string PJRptNameLetterMulticurrCrDb = "OECDPJM2";
        public const string PJRptNameSinglecurCrDb= "OECDPJ01";

        //sort by enums
        public const string SortByDayend = "SORTBY_DAYEND";
        public const string SortByShipment = "SORTBY_TRANSNUM";
        public const string SortbyTransactionDate = "SORTBY_TRANSDATE";
        public const string SortBycustomer = "SORTBY_CUSTOMER";

        //selectby enums
        public const string SelectByShipment = "3";
        public const string SelectByInvoices = "1";
        public const string SelectByCrDbtNo = "2";

        //PaperSize param
        public const string PaperSizeLetter = "SIZE_LETTER";
        public const string PaperSizeLegal ="SIZE_LEGAL";

        //AR Audit option
        public const string ZeroParam = "0";
        public const string OneParam = "1";
        public const string TwoParam = "2";
        public const string ThreeParam = "3";
        public const string Levelname = " ";

        public const string PJProgramId = "OE1800";
        public const string PJMenuId = PJProgramId;
        #region Posting Journal

        #endregion


        #endregion
    }
}
