// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Partial class for OrderKittingSerialNumber
     /// </summary>
     public partial class OrderKittingSerialNumber : ModelBase
     {
          /// <summary>
          /// Gets or sets OrderUniquifier
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal OrderUniquifier {get; set;}

          /// <summary>
          /// Gets or sets DetailLineNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DetailLineNumber, Id = Index.DetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int DetailLineNumber {get; set;}

          /// <summary>
          /// Gets or sets ParentComponentNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ParentComponentNumber, Id = Index.ParentComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
          public long ParentComponentNumber {get; set;}

          /// <summary>
          /// Gets or sets ComponentNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ComponentNumber, Id = Index.ComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
          public long ComponentNumber {get; set;}

          /// <summary>
          /// Gets or sets SerialNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
          public string SerialNumber {get; set;}

          /// <summary>
          /// Gets or sets DetailNumber
          /// </summary>
          [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int DetailNumber {get; set;}

          /// <summary>
          /// Gets or sets Shipped
          /// </summary>
          [ViewField(Name = Fields.Shipped, Id = Index.Shipped, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool Shipped {get; set;}

          /// <summary>
          /// Gets or sets TransactionQuantity
          /// </summary>
          [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Long, Size = 4)]
          public long TransactionQuantity {get; set;}

          /// <summary>
          /// Gets or sets QuantityShipped
          /// </summary>
          [ViewField(Name = Fields.QuantityShipped, Id = Index.QuantityShipped, FieldType = EntityFieldType.Long, Size = 4)]
          public long QuantityShipped {get; set;}

     }
}
