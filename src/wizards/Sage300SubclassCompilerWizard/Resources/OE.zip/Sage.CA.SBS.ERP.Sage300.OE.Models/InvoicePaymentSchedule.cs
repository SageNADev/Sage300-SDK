// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Partial class for InvoicePaymentSchedule
	/// </summary>
	public partial class InvoicePaymentSchedule : ModelBase
	{
		/// <summary>
		/// Gets or sets InvoiceUniquifier
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceUniquifier", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal InvoiceUniquifier { get; set; }

		/// <summary>
		/// Gets or sets PaymentNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentNumber", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int PaymentNumber { get; set; }

		/// <summary>
		/// Gets or sets DiscountBase
		/// </summary>
        [Display(Name = "DiscountBase", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.DiscountBase, Id = Index.DiscountBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DiscountBase { get; set; }

		/// <summary>
		/// Gets or sets DiscountDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DiscountDate", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? DiscountDate { get; set; }

		/// <summary>
		/// Gets or sets DiscountPercentage
		/// </summary>
        [Display(Name = "DiscountPercentage", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.DiscountPercentage, Id = Index.DiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
		public decimal DiscountPercentage { get; set; }

		/// <summary>
		/// Gets or sets DiscountAmount
		/// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DiscountAmount { get; set; }

		/// <summary>
		/// Gets or sets DueAmountBase
		/// </summary>
        [Display(Name = "DueAmountBase", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.DueAmountBase, Id = Index.DueAmountBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DueAmountBase { get; set; }

		/// <summary>
		/// Gets or sets DueDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "DueDate", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DueDate { get; set; }

		/// <summary>
		/// Gets or sets PercentageDue
		/// </summary>
		[Display(Name = "PercentageDue", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.PercentageDue, Id = Index.PercentageDue, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
		public decimal PercentageDue { get; set; }

		/// <summary>
		/// Gets or sets AmountDue
		/// </summary>
		[Display(Name = "AmountDue", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.AmountDue, Id = Index.AmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal AmountDue { get; set; }

		#region UI Strings

		#endregion
	}
}
