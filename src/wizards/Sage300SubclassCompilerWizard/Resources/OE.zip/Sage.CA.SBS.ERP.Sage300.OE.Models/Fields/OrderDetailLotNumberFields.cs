// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of OrderDetailLotNumber Constants
     /// </summary>
     public partial class OrderDetailLotNumber
     {
          /// <summary>
         /// Entity Name
          /// </summary>
          public const string EntityName = "OE0507";

          #region Properties
          /// <summary>
          /// Contains list of OrderDetailLotNumber Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for OrderUniquifier
               /// </summary>
               public const string OrderUniquifier = "ORDUNIQ";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "LINENUM";

               /// <summary>
               /// Property for LotNumber
               /// </summary>
               public const string LotNumber = "LOTNUMF";

               /// <summary>
               /// Property for DetailNumber
               /// </summary>
               public const string DetailNumber = "DETAILNUM";

               /// <summary>
               /// Property for ExpirationDate
               /// </summary>
               public const string ExpirationDate = "EXPIRYDATE";

               /// <summary>
               /// Property for QuantityInStockingUom
               /// </summary>
               public const string QuantityInStockingUom = "STKQTY";

               /// <summary>
               /// Property for TransactionQuantity
               /// </summary>
               public const string TransactionQuantity = "QTY";

               /// <summary>
               /// Property for QtyShippedInStockingUom
               /// </summary>
               public const string QtyShippedInStockingUom = "STKQTYMOVE";

               /// <summary>
               /// Property for QuantityShipped
               /// </summary>
               public const string QuantityShipped = "QTYMOVED";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of OrderDetailLotNumber Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for OrderUniquifier
               /// </summary>
               public const int OrderUniquifier = 1;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 2;

               /// <summary>
               /// Property Indexer for LotNumber
               /// </summary>
               public const int LotNumber = 3;

               /// <summary>
               /// Property Indexer for DetailNumber
               /// </summary>
               public const int DetailNumber = 4;

               /// <summary>
               /// Property Indexer for ExpirationDate
               /// </summary>
               public const int ExpirationDate = 5;

               /// <summary>
               /// Property Indexer for QuantityInStockingUom
               /// </summary>
               public const int QuantityInStockingUom = 6;

               /// <summary>
               /// Property Indexer for TransactionQuantity
               /// </summary>
               public const int TransactionQuantity = 7;

               /// <summary>
               /// Property Indexer for QtyShippedInStockingUom
               /// </summary>
               public const int QtyShippedInStockingUom = 8;

               /// <summary>
               /// Property Indexer for QuantityShipped
               /// </summary>
               public const int QuantityShipped = 9;

          }
          #endregion

     }
}
