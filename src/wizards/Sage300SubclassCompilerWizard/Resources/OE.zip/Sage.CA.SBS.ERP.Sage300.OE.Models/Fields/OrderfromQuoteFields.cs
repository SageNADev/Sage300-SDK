// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of OrderfromQuote Constants
     /// </summary>
     public partial class OrderfromQuote
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "OE0526";

          #region Properties
          /// <summary>
          /// Contains list of OrderfromQuote Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for OrderUniquifier
               /// </summary>
               public const string OrderUniquifier = "ORDUNIQ";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "LINENUM";

               /// <summary>
               /// Property for QuoteUniquifier
               /// </summary>
               public const string QuoteUniquifier = "QUOUNIQ";

               /// <summary>
               /// Property for QuoteNumber
               /// </summary>
               public const string QuoteNumber = "QUONUMBER";

               /// <summary>
               /// Property for DocumentDate
               /// </summary>
               public const string DocumentDate = "ORDDATE";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of OrderfromQuote Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for OrderUniquifier
               /// </summary>
               public const int OrderUniquifier = 1;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 2;

               /// <summary>
               /// Property Indexer for QuoteUniquifier
               /// </summary>
               public const int QuoteUniquifier = 3;

               /// <summary>
               /// Property Indexer for QuoteNumber
               /// </summary>
               public const int QuoteNumber = 4;

               /// <summary>
               /// Property Indexer for DocumentDate
               /// </summary>
               public const int DocumentDate = 50;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 51;

          }
          #endregion

     }
}
