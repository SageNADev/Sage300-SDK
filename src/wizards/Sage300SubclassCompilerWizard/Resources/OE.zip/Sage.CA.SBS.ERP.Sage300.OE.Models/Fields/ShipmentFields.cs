// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of Shipment Constants
     /// </summary>
     public partial class Shipment
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "OE0692";
         public const string ImportEntityName = "OE0434";

          #region Properties
          /// <summary>
          /// Contains list of Shipment Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for ShipmentUniquifier
               /// </summary>
               public const string ShipmentUniquifier = "SHIUNIQ";

               /// <summary>
               /// Property for ShipmentNumber
               /// </summary>
               public const string ShipmentNumber = "SHINUMBER";

               /// <summary>
               /// Property for OrderNumber
               /// </summary>
               public const string OrderNumber = "ORDNUMBER";

               /// <summary>
               /// Property for ICDayEndTransNumber
               /// </summary>
               public const string ICDayEndTransNumber = "DAYENDNUM";

               /// <summary>
               /// Property for CustomerNumber
               /// </summary>
               public const string CustomerNumber = "CUSTOMER";

               /// <summary>
               /// Property for CustomerGroupCode
               /// </summary>
               public const string CustomerGroupCode = "CUSTGROUP";

               /// <summary>
               /// Property for BillToName
               /// </summary>
               public const string BillToName = "BILNAME";

               /// <summary>
               /// Property for BillToAddressLine1
               /// </summary>
               public const string BillToAddressLine1 = "BILADDR1";

               /// <summary>
               /// Property for BillToAddressLine2
               /// </summary>
               public const string BillToAddressLine2 = "BILADDR2";

               /// <summary>
               /// Property for BillToAddressLine3
               /// </summary>
               public const string BillToAddressLine3 = "BILADDR3";

               /// <summary>
               /// Property for BillToAddressLine4
               /// </summary>
               public const string BillToAddressLine4 = "BILADDR4";

               /// <summary>
               /// Property for BillToCity
               /// </summary>
               public const string BillToCity = "BILCITY";

               /// <summary>
               /// Property for BillToStateProvince
               /// </summary>
               public const string BillToStateProvince = "BILSTATE";

               /// <summary>
               /// Property for BillToZipPostalCode
               /// </summary>
               public const string BillToZipPostalCode = "BILZIP";

               /// <summary>
               /// Property for BillToCountry
               /// </summary>
               public const string BillToCountry = "BILCOUNTRY";

               /// <summary>
               /// Property for BillToPhoneNumber
               /// </summary>
               public const string BillToPhoneNumber = "BILPHONE";

               /// <summary>
               /// Property for BillToFaxNumber
               /// </summary>
               public const string BillToFaxNumber = "BILFAX";

               /// <summary>
               /// Property for BillToContact
               /// </summary>
               public const string BillToContact = "BILCONTACT";

               /// <summary>
               /// Property for BillToEmail
               /// </summary>
               public const string BillToEmail = "BILEMAIL";

               /// <summary>
               /// Property for BillToContactPhone
               /// </summary>
               public const string BillToContactPhone = "BILPHONEC";

               /// <summary>
               /// Property for BillToContactFax
               /// </summary>
               public const string BillToContactFax = "BILFAXC";

               /// <summary>
               /// Property for BillToContactEmail
               /// </summary>
               public const string BillToContactEmail = "BILEMAILC";

               /// <summary>
               /// Property for ShipToLocationCode
               /// </summary>
               public const string ShipToLocationCode = "SHIPTO";

               /// <summary>
               /// Property for ShipToName
               /// </summary>
               public const string ShipToName = "SHPNAME";

               /// <summary>
               /// Property for ShipToAddressLine1
               /// </summary>
               public const string ShipToAddressLine1 = "SHPADDR1";

               /// <summary>
               /// Property for ShipToAddressLine2
               /// </summary>
               public const string ShipToAddressLine2 = "SHPADDR2";

               /// <summary>
               /// Property for ShipToAddressLine3
               /// </summary>
               public const string ShipToAddressLine3 = "SHPADDR3";

               /// <summary>
               /// Property for ShipToAddressLine4
               /// </summary>
               public const string ShipToAddressLine4 = "SHPADDR4";

               /// <summary>
               /// Property for ShipToCity
               /// </summary>
               public const string ShipToCity = "SHPCITY";

               /// <summary>
               /// Property for ShipToStateProvince
               /// </summary>
               public const string ShipToStateProvince = "SHPSTATE";

               /// <summary>
               /// Property for ShipToZipPostalCode
               /// </summary>
               public const string ShipToZipPostalCode = "SHPZIP";

               /// <summary>
               /// Property for ShipToCountry
               /// </summary>
               public const string ShipToCountry = "SHPCOUNTRY";

               /// <summary>
               /// Property for ShipToPhoneNumber
               /// </summary>
               public const string ShipToPhoneNumber = "SHPPHONE";

               /// <summary>
               /// Property for ShipToFaxNumber
               /// </summary>
               public const string ShipToFaxNumber = "SHPFAX";

               /// <summary>
               /// Property for ShipToContact
               /// </summary>
               public const string ShipToContact = "SHPCONTACT";

               /// <summary>
               /// Property for ShipToEmail
               /// </summary>
               public const string ShipToEmail = "SHPEMAIL";

               /// <summary>
               /// Property for ShipToContactPhone
               /// </summary>
               public const string ShipToContactPhone = "SHPPHONEC";

               /// <summary>
               /// Property for ShipToContactFax
               /// </summary>
               public const string ShipToContactFax = "SHPFAXC";

               /// <summary>
               /// Property for ShipToContactEmail
               /// </summary>
               public const string ShipToContactEmail = "SHPEMAILC";

               /// <summary>
               /// Property for CustomerDiscountLevel
               /// </summary>
               public const string CustomerDiscountLevel = "CUSTDISC";

               /// <summary>
               /// Property for DefaultPriceListCode
               /// </summary>
               public const string DefaultPriceListCode = "PRICELIST";

               /// <summary>
               /// Property for PurchaseOrderNumber
               /// </summary>
               public const string PurchaseOrderNumber = "PONUMBER";

               /// <summary>
               /// Property for Territory
               /// </summary>
               public const string Territory = "TERRITORY";

               /// <summary>
               /// Property for TermsCode
               /// </summary>
               public const string TermsCode = "TERMS";

               /// <summary>
               /// Property for ShipmentReference
               /// </summary>
               public const string ShipmentReference = "REFERENCE";

               /// <summary>
               /// Property for ShipmentDate
               /// </summary>
               public const string ShipmentDate = "SHIDATE";

               /// <summary>
               /// Property for ExpectedShipDate
               /// </summary>
               public const string ExpectedShipDate = "EXPDATE";

               /// <summary>
               /// Property for ShipViaCode
               /// </summary>
               public const string ShipViaCode = "SHIPVIA";

               /// <summary>
               /// Property for ShipViaCodeDescription
               /// </summary>
               public const string ShipViaCodeDescription = "VIADESC";

               /// <summary>
               /// Property for ShipmentFiscalYear
               /// </summary>
               public const string ShipmentFiscalYear = "SHIFISCYR";

               /// <summary>
               /// Property for ShipmentFiscalPeriod
               /// </summary>
               public const string ShipmentFiscalPeriod = "SHIFISCPER";

               /// <summary>
               /// Property for LastInvoiceNumber
               /// </summary>
               public const string LastInvoiceNumber = "LASTINVNUM";

               /// <summary>
               /// Property for NumberOfInvoices
               /// </summary>
               public const string NumberOfInvoices = "NUMINVOICE";

               /// <summary>
               /// Property for FreeOnBoardPoint
               /// </summary>
               public const string FreeOnBoardPoint = "FOB";

               /// <summary>
               /// Property for TemplateCode
               /// </summary>
               public const string TemplateCode = "TEMPLATE";

               /// <summary>
               /// Property for DefaultLocationCode
               /// </summary>
               public const string DefaultLocationCode = "LOCATION";

               /// <summary>
               /// Property for ShipmentDescription
               /// </summary>
               public const string ShipmentDescription = "DESC";

               /// <summary>
               /// Property for ShipmentComment
               /// </summary>
               public const string ShipmentComment = "COMMENT";

               /// <summary>
               /// Property for OverCreditLimit
               /// </summary>
               public const string OverCreditLimit = "OVERCREDIT";

               /// <summary>
               /// Property for ApprovedLimit
               /// </summary>
               public const string ApprovedLimit = "APPROVELMT";

               /// <summary>
               /// Property for AuthorizingUserID
               /// </summary>
               public const string AuthorizingUserID = "APPROVEBY";

               /// <summary>
               /// Property for OrderPrintStatus
               /// </summary>
               public const string OrderPrintStatus = "PRINTSTAT";

               /// <summary>
               /// Property for LastPostingDate
               /// </summary>
               public const string LastPostingDate = "LASTPOST";

               /// <summary>
               /// Property for RequiresShippingLabels
               /// </summary>
               public const string RequiresShippingLabels = "SHIPLABEL";

               /// <summary>
               /// Property for ShippingLabelsPrinted
               /// </summary>
               public const string ShippingLabelsPrinted = "LBLPRINTED";

               /// <summary>
               /// Property for ShipmentHomeCurrency
               /// </summary>
               public const string ShipmentHomeCurrency = "SHHOMECURR";

               /// <summary>
               /// Property for ShipmentRateType
               /// </summary>
               public const string ShipmentRateType = "SHRATETYPE";

               /// <summary>
               /// Property for ShipmentSourceCurrency
               /// </summary>
               public const string ShipmentSourceCurrency = "SHSOURCURR";

               /// <summary>
               /// Property for ShipmentRateDate
               /// </summary>
               public const string ShipmentRateDate = "SHRATEDATE";

               /// <summary>
               /// Property for ShipmentRate
               /// </summary>
               public const string ShipmentRate = "SHRATE";

               /// <summary>
               /// Property for ShipmentSpread
               /// </summary>
               public const string ShipmentSpread = "SHSPREAD";

               /// <summary>
               /// Property for ShipmentRateDateMatching
               /// </summary>
               public const string ShipmentRateDateMatching = "SHDATEMTCH";

               /// <summary>
               /// Property for ShipmentRateOperator
               /// </summary>
               public const string ShipmentRateOperator = "SHRATEREP";

               /// <summary>
               /// Property for ShipmentRateOverrideFlag
               /// </summary>
               public const string ShipmentRateOverrideFlag = "SHRATEOVER";

               /// <summary>
               /// Property for TotalAmtItems
               /// </summary>
               public const string TotalAmtItems = "SHITOTAL";

               /// <summary>
               /// Property for TotalAmtMiscCharges
               /// </summary>
               public const string TotalAmtMiscCharges = "SHIMTOTAL";

               /// <summary>
               /// Property for NumberOfLinesonShipment
               /// </summary>
               public const string NumberOfLinesonShipment = "SHILINES";

               /// <summary>
               /// Property for NumberOfLabels
               /// </summary>
               public const string NumberOfLabels = "NUMLABELS";

               /// <summary>
               /// Property for PrevPaymentsTotal
               /// </summary>
               public const string PrevPaymentsTotal = "SHIPAYTOT";

               /// <summary>
               /// Property for PrevPaymentDiscTotal
               /// </summary>
               public const string PrevPaymentDiscTotal = "SHIPYDSTOT";

               /// <summary>
               /// Property for Salesperson1
               /// </summary>
               public const string Salesperson1 = "SALESPER1";

               /// <summary>
               /// Property for Salesperson2
               /// </summary>
               public const string Salesperson2 = "SALESPER2";

               /// <summary>
               /// Property for Salesperson3
               /// </summary>
               public const string Salesperson3 = "SALESPER3";

               /// <summary>
               /// Property for Salesperson4
               /// </summary>
               public const string Salesperson4 = "SALESPER4";

               /// <summary>
               /// Property for Salesperson5
               /// </summary>
               public const string Salesperson5 = "SALESPER5";

               /// <summary>
               /// Property for SalesPercentage1
               /// </summary>
               public const string SalesPercentage1 = "SALESPLT1";

               /// <summary>
               /// Property for SalesPercentage2
               /// </summary>
               public const string SalesPercentage2 = "SALESPLT2";

               /// <summary>
               /// Property for SalesPercentage3
               /// </summary>
               public const string SalesPercentage3 = "SALESPLT3";

               /// <summary>
               /// Property for SalesPercentage4
               /// </summary>
               public const string SalesPercentage4 = "SALESPLT4";

               /// <summary>
               /// Property for SalesPercentage5
               /// </summary>
               public const string SalesPercentage5 = "SALESPLT5";

               /// <summary>
               /// Property for RecalculateTax
               /// </summary>
               public const string RecalculateTax = "RECALCTAX";

               /// <summary>
               /// Property for TaxOverridden
               /// </summary>
               public const string TaxOverridden = "TAXOVERRD";

               /// <summary>
               /// Property for TaxGroup
               /// </summary>
               public const string TaxGroup = "TAXGROUP";

               /// <summary>
               /// Property for TaxAuthority1
               /// </summary>
               public const string TaxAuthority1 = "TAUTH1";

               /// <summary>
               /// Property for TaxAuthority2
               /// </summary>
               public const string TaxAuthority2 = "TAUTH2";

               /// <summary>
               /// Property for TaxAuthority3
               /// </summary>
               public const string TaxAuthority3 = "TAUTH3";

               /// <summary>
               /// Property for TaxAuthority4
               /// </summary>
               public const string TaxAuthority4 = "TAUTH4";

               /// <summary>
               /// Property for TaxAuthority5
               /// </summary>
               public const string TaxAuthority5 = "TAUTH5";

               /// <summary>
               /// Property for TaxClass1
               /// </summary>
               public const string TaxClass1 = "TCLASS1";

               /// <summary>
               /// Property for TaxClass2
               /// </summary>
               public const string TaxClass2 = "TCLASS2";

               /// <summary>
               /// Property for TaxClass3
               /// </summary>
               public const string TaxClass3 = "TCLASS3";

               /// <summary>
               /// Property for TaxClass4
               /// </summary>
               public const string TaxClass4 = "TCLASS4";

               /// <summary>
               /// Property for TaxClass5
               /// </summary>
               public const string TaxClass5 = "TCLASS5";

               /// <summary>
               /// Property for TaxBase1
               /// </summary>
               public const string TaxBase1 = "TBASE1";

               /// <summary>
               /// Property for TaxBase2
               /// </summary>
               public const string TaxBase2 = "TBASE2";

               /// <summary>
               /// Property for TaxBase3
               /// </summary>
               public const string TaxBase3 = "TBASE3";

               /// <summary>
               /// Property for TaxBase4
               /// </summary>
               public const string TaxBase4 = "TBASE4";

               /// <summary>
               /// Property for TaxBase5
               /// </summary>
               public const string TaxBase5 = "TBASE5";

               /// <summary>
               /// Property for ExcludedTaxAmount1
               /// </summary>
               public const string ExcludedTaxAmount1 = "TEAMOUNT1";

               /// <summary>
               /// Property for ExcludedTaxAmount2
               /// </summary>
               public const string ExcludedTaxAmount2 = "TEAMOUNT2";

               /// <summary>
               /// Property for ExcludedTaxAmount3
               /// </summary>
               public const string ExcludedTaxAmount3 = "TEAMOUNT3";

               /// <summary>
               /// Property for ExcludedTaxAmount4
               /// </summary>
               public const string ExcludedTaxAmount4 = "TEAMOUNT4";

               /// <summary>
               /// Property for ExcludedTaxAmount5
               /// </summary>
               public const string ExcludedTaxAmount5 = "TEAMOUNT5";

               /// <summary>
               /// Property for IncludedTaxAmount1
               /// </summary>
               public const string IncludedTaxAmount1 = "TIAMOUNT1";

               /// <summary>
               /// Property for IncludedTaxAmount2
               /// </summary>
               public const string IncludedTaxAmount2 = "TIAMOUNT2";

               /// <summary>
               /// Property for IncludedTaxAmount3
               /// </summary>
               public const string IncludedTaxAmount3 = "TIAMOUNT3";

               /// <summary>
               /// Property for IncludedTaxAmount4
               /// </summary>
               public const string IncludedTaxAmount4 = "TIAMOUNT4";

               /// <summary>
               /// Property for IncludedTaxAmount5
               /// </summary>
               public const string IncludedTaxAmount5 = "TIAMOUNT5";

               /// <summary>
               /// Property for Registration1
               /// </summary>
               public const string Registration1 = "TEXEMPT1";

               /// <summary>
               /// Property for Registration2
               /// </summary>
               public const string Registration2 = "TEXEMPT2";

               /// <summary>
               /// Property for Registration3
               /// </summary>
               public const string Registration3 = "TEXEMPT3";

               /// <summary>
               /// Property for Registration4
               /// </summary>
               public const string Registration4 = "TEXEMPT4";

               /// <summary>
               /// Property for Registration5
               /// </summary>
               public const string Registration5 = "TEXEMPT5";

               /// <summary>
               /// Property for ShipmentCompleted
               /// </summary>
               public const string ShipmentCompleted = "COMPLETE";

               /// <summary>
               /// Property for ShipmentCompletionDate
               /// </summary>
               public const string ShipmentCompletionDate = "COMPDATE";

               /// <summary>
               /// Property for ShipmentTotalEstWeight
               /// </summary>
               public const string ShipmentTotalEstWeight = "SHIWEIGHT";

               /// <summary>
               /// Property for NextDetailNumber
               /// </summary>
               public const string NextDetailNumber = "NEXTDTLNUM";

               /// <summary>
               /// Property for ShipmentDiscMiscCharges
               /// </summary>
               public const string ShipmentDiscMiscCharges = "SDISONMISC";

               /// <summary>
               /// Property for NoLinesQtyShipped
               /// </summary>
               public const string NoLinesQtyShipped = "NOSHIPLINE";

               /// <summary>
               /// Property for NoMiscChargesLines
               /// </summary>
               public const string NoMiscChargesLines = "NOMISCLINE";

               /// <summary>
               /// Property for ShipmentTotalBeforeTax
               /// </summary>
               public const string ShipmentTotalBeforeTax = "SHINETNOTX";

               /// <summary>
               /// Property for ShipmentInclTaxTotal
               /// </summary>
               public const string ShipmentInclTaxTotal = "SHIITAXTOT";

               /// <summary>
               /// Property for ShipmentItemTotalAmount
               /// </summary>
               public const string ShipmentItemTotalAmount = "SHIITMTOT";

               /// <summary>
               /// Property for ShipmentDiscountBase
               /// </summary>
               public const string ShipmentDiscountBase = "SHIDISCBAS";

               /// <summary>
               /// Property for ShipmentDiscountPercentage
               /// </summary>
               public const string ShipmentDiscountPercentage = "SHIDISCPER";

               /// <summary>
               /// Property for ShipmentDiscountAmount
               /// </summary>
               public const string ShipmentDiscountAmount = "SHIDISCAMT";

               /// <summary>
               /// Property for ShipmentTotalMiscCharges
               /// </summary>
               public const string ShipmentTotalMiscCharges = "SHIMISC";

               /// <summary>
               /// Property for ShipmentSubtotalAmount
               /// </summary>
               public const string ShipmentSubtotalAmount = "SHISUBTOT";

               /// <summary>
               /// Property for ShipmentTotalWithInvDisc
               /// </summary>
               public const string ShipmentTotalWithInvDisc = "SHINET";

               /// <summary>
               /// Property for ShipmentExclTaxTotal
               /// </summary>
               public const string ShipmentExclTaxTotal = "SHIETAXTOT";

               /// <summary>
               /// Property for ShipmentTotal
               /// </summary>
               public const string ShipmentTotal = "SHINETWTX";

               /// <summary>
               /// Property for OrderDate
               /// </summary>
               public const string OrderDate = "ORDDATE";

               /// <summary>
               /// Property for OrderHomeCurrency
               /// </summary>
               public const string OrderHomeCurrency = "ORHOMECURR";

               /// <summary>
               /// Property for OrderRateType
               /// </summary>
               public const string OrderRateType = "ORRATETYPE";

               /// <summary>
               /// Property for OrderSourceCurrency
               /// </summary>
               public const string OrderSourceCurrency = "ORSOURCURR";

               /// <summary>
               /// Property for OrderRateDate
               /// </summary>
               public const string OrderRateDate = "ORRATEDATE";

               /// <summary>
               /// Property for OrderRate
               /// </summary>
               public const string OrderRate = "ORRATE";

               /// <summary>
               /// Property for OrderSpread
               /// </summary>
               public const string OrderSpread = "ORSPREAD";

               /// <summary>
               /// Property for OrderRateDateMatching
               /// </summary>
               public const string OrderRateDateMatching = "ORDATEMTCH";

               /// <summary>
               /// Property for OrderRateOperator
               /// </summary>
               public const string OrderRateOperator = "ORRATEREP";

               /// <summary>
               /// Property for OrderRateOverrideFlag
               /// </summary>
               public const string OrderRateOverrideFlag = "ORRATEOVER";

               /// <summary>
               /// Property for AutoTaxCalculationStatus
               /// </summary>
               public const string AutoTaxCalculationStatus = "AUTOTAXCAL";

               /// <summary>
               /// Property for GenerateFromMultipleOrders
               /// </summary>
               public const string GenerateFromMultipleOrders = "MULTIORD";

               /// <summary>
               /// Property for FromHowManyOrders
               /// </summary>
               public const string FromHowManyOrders = "ORDS";

               /// <summary>
               /// Property for ShipmentTrackingNumber
               /// </summary>
               public const string ShipmentTrackingNumber = "SHIPTRACK";

               /// <summary>
               /// Property for NumberOfShipments
               /// </summary>
               public const string NumberOfShipments = "NUMSHPMENT";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for OrderUniquifier
               /// </summary>
               public const string OrderUniquifier = "ORDUNIQ";

               /// <summary>
               /// Property for ItemDetailDiscountTotal
               /// </summary>
               public const string ItemDetailDiscountTotal = "ITEMDISTOT";

               /// <summary>
               /// Property for MiscChargeDetailDiscountTot
               /// </summary>
               public const string MiscChargeDetailDiscountTot = "MISCDISTOT";

               /// <summary>
               /// Property for AutoCalcTaxReportingAmounts
               /// </summary>
               public const string AutoCalcTaxReportingAmounts = "STRMETHOD";

               /// <summary>
               /// Property for TaxReportingTRCurrency
               /// </summary>
               public const string TaxReportingTRCurrency = "STRCURRNCY";

               /// <summary>
               /// Property for TRRateType
               /// </summary>
               public const string TRRateType = "STRRATTYPE";

               /// <summary>
               /// Property for TRRateDate
               /// </summary>
               public const string TRRateDate = "STRRATDATE";

               /// <summary>
               /// Property for TRRate
               /// </summary>
               public const string TRRate = "STRRATE";

               /// <summary>
               /// Property for TRSpread
               /// </summary>
               public const string TRSpread = "STRSPREAD";

               /// <summary>
               /// Property for TRRateDateMatching
               /// </summary>
               public const string TRRateDateMatching = "STRDATMTCH";

               /// <summary>
               /// Property for TRRateOperator
               /// </summary>
               public const string TRRateOperator = "STRRATEOP";

               /// <summary>
               /// Property for TRRateOverrideFlag
               /// </summary>
               public const string TRRateOverrideFlag = "STRRATOVER";

               /// <summary>
               /// Property for TRExcludedTaxAmount1
               /// </summary>
               public const string TRExcludedTaxAmount1 = "STREAMNT1";

               /// <summary>
               /// Property for TRExcludedTaxAmount2
               /// </summary>
               public const string TRExcludedTaxAmount2 = "STREAMNT2";

               /// <summary>
               /// Property for TRExcludedTaxAmount3
               /// </summary>
               public const string TRExcludedTaxAmount3 = "STREAMNT3";

               /// <summary>
               /// Property for TRExcludedTaxAmount4
               /// </summary>
               public const string TRExcludedTaxAmount4 = "STREAMNT4";

               /// <summary>
               /// Property for TRExcludedTaxAmount5
               /// </summary>
               public const string TRExcludedTaxAmount5 = "STREAMNT5";

               /// <summary>
               /// Property for TRIncludedTaxAmount1
               /// </summary>
               public const string TRIncludedTaxAmount1 = "STRIAMNT1";

               /// <summary>
               /// Property for TRIncludedTaxAmount2
               /// </summary>
               public const string TRIncludedTaxAmount2 = "STRIAMNT2";

               /// <summary>
               /// Property for TRIncludedTaxAmount3
               /// </summary>
               public const string TRIncludedTaxAmount3 = "STRIAMNT3";

               /// <summary>
               /// Property for TRIncludedTaxAmount4
               /// </summary>
               public const string TRIncludedTaxAmount4 = "STRIAMNT4";

               /// <summary>
               /// Property for TRIncludedTaxAmount5
               /// </summary>
               public const string TRIncludedTaxAmount5 = "STRIAMNT5";

               /// <summary>
               /// Property for TaxReportingTROrderCurrenc
               /// </summary>
               public const string TaxReportingTROrderCurrenc = "OTRCURRNCY";

               /// <summary>
               /// Property for TROrderRateType
               /// </summary>
               public const string TROrderRateType = "OTRRATTYPE";

               /// <summary>
               /// Property for TROrderRateDate
               /// </summary>
               public const string TROrderRateDate = "OTRRATDATE";

               /// <summary>
               /// Property for TROrderRate
               /// </summary>
               public const string TROrderRate = "OTRRATE";

               /// <summary>
               /// Property for TROrderSpread
               /// </summary>
               public const string TROrderSpread = "OTRSPREAD";

               /// <summary>
               /// Property for TROrderRateDateMatching
               /// </summary>
               public const string TROrderRateDateMatching = "OTRDATMTCH";

               /// <summary>
               /// Property for TROrderRateOperator
               /// </summary>
               public const string TROrderRateOperator = "OTRRATEOP";

               /// <summary>
               /// Property for TROrderRateOverrideFlag
               /// </summary>
               public const string TROrderRateOverrideFlag = "OTRRATOVER";

               /// <summary>
               /// Property for ShipmentDiscountAmountOverrid
               /// </summary>
               public const string ShipmentDiscountAmountOverrid = "DISAMTOVER";

               /// <summary>
               /// Property for ShipmentNoOfPrepayments
               /// </summary>
               public const string ShipmentNoOfPrepayments = "SHNOPREPAY";

               /// <summary>
               /// Property for JobRelatedDetailLines
               /// </summary>
               public const string JobRelatedDetailLines = "JOBLINES";

               /// <summary>
               /// Property for InvoiceableDetailLines
               /// </summary>
               public const string InvoiceableDetailLines = "LNINVABLE";

               /// <summary>
               /// Property for HasRetainage
               /// </summary>
               public const string HasRetainage = "HASRTG";

               /// <summary>
               /// Property for RetainageTerms
               /// </summary>
               public const string RetainageTerms = "RTGTERMS";

               /// <summary>
               /// Property for RetainageAmount
               /// </summary>
               public const string RetainageAmount = "RTGAMOUNT";

               /// <summary>
               /// Property for RetainagePercent
               /// </summary>
               public const string RetainagePercent = "RTGPERCENT";

               /// <summary>
               /// Property for RetainageExchangeRate
               /// </summary>
               public const string RetainageExchangeRate = "RTGRATE";

               /// <summary>
               /// Property for RetainageTaxBase1
               /// </summary>
               public const string RetainageTaxBase1 = "RTGTXBASE1";

               /// <summary>
               /// Property for RetainageTaxBase2
               /// </summary>
               public const string RetainageTaxBase2 = "RTGTXBASE2";

               /// <summary>
               /// Property for RetainageTaxBase3
               /// </summary>
               public const string RetainageTaxBase3 = "RTGTXBASE3";

               /// <summary>
               /// Property for RetainageTaxBase4
               /// </summary>
               public const string RetainageTaxBase4 = "RTGTXBASE4";

               /// <summary>
               /// Property for RetainageTaxBase5
               /// </summary>
               public const string RetainageTaxBase5 = "RTGTXBASE5";

               /// <summary>
               /// Property for RetainageTaxAmount1
               /// </summary>
               public const string RetainageTaxAmount1 = "RTGTXAMT1";

               /// <summary>
               /// Property for RetainageTaxAmount2
               /// </summary>
               public const string RetainageTaxAmount2 = "RTGTXAMT2";

               /// <summary>
               /// Property for RetainageTaxAmount3
               /// </summary>
               public const string RetainageTaxAmount3 = "RTGTXAMT3";

               /// <summary>
               /// Property for RetainageTaxAmount4
               /// </summary>
               public const string RetainageTaxAmount4 = "RTGTXAMT4";

               /// <summary>
               /// Property for RetainageTaxAmount5
               /// </summary>
               public const string RetainageTaxAmount5 = "RTGTXAMT5";

               /// <summary>
               /// Property for CustomerAccountSet
               /// </summary>
               public const string CustomerAccountSet = "CUSACCTSET";

               /// <summary>
               /// Property for EnteredBy
               /// </summary>
               public const string EnteredBy = "ENTEREDBY";

               /// <summary>
               /// Property for PostingDate
               /// </summary>
               public const string PostingDate = "DATEBUS";

               /// <summary>
               /// Property for SageCRMOpportunityLines
               /// </summary>
               public const string SageCRMOpportunityLines = "OPPOLINES";

               /// <summary>
               /// Property for PriceListCodeDesc
               /// </summary>
               public const string PriceListCodeDesc = "PCODDESC";

               /// <summary>
               /// Property for TermsCodeDescription
               /// </summary>
               public const string TermsCodeDescription = "TERMDESC";

               /// <summary>
               /// Property for TaxGroupCodeDesc
               /// </summary>
               public const string TaxGroupCodeDesc = "TXGRPDESC";

               /// <summary>
               /// Property for LocationCodeDesc
               /// </summary>
               public const string LocationCodeDesc = "LOCDESC";

               /// <summary>
               /// Property for SalespersonName1
               /// </summary>
               public const string SalespersonName1 = "SALES1NAME";

               /// <summary>
               /// Property for SalespersonName2
               /// </summary>
               public const string SalespersonName2 = "SALES2NAME";

               /// <summary>
               /// Property for SalespersonName3
               /// </summary>
               public const string SalespersonName3 = "SALES3NAME";

               /// <summary>
               /// Property for SalespersonName4
               /// </summary>
               public const string SalespersonName4 = "SALES4NAME";

               /// <summary>
               /// Property for SalespersonName5
               /// </summary>
               public const string SalespersonName5 = "SALES5NAME";

               /// <summary>
               /// Property for TaxAuthority1Desc
               /// </summary>
               public const string TaxAuthority1Desc = "TAUTH1DESC";

               /// <summary>
               /// Property for TaxAuthority2Desc
               /// </summary>
               public const string TaxAuthority2Desc = "TAUTH2DESC";

               /// <summary>
               /// Property for TaxAuthority3Desc
               /// </summary>
               public const string TaxAuthority3Desc = "TAUTH3DESC";

               /// <summary>
               /// Property for TaxAuthority4Desc
               /// </summary>
               public const string TaxAuthority4Desc = "TAUTH4DESC";

               /// <summary>
               /// Property for TaxAuthority5Desc
               /// </summary>
               public const string TaxAuthority5Desc = "TAUTH5DESC";

               /// <summary>
               /// Property for TaxClass1Description
               /// </summary>
               public const string TaxClass1Description = "TCLAS1DESC";

               /// <summary>
               /// Property for TaxClass2Description
               /// </summary>
               public const string TaxClass2Description = "TCLAS2DESC";

               /// <summary>
               /// Property for TaxClass3Description
               /// </summary>
               public const string TaxClass3Description = "TCLAS3DESC";

               /// <summary>
               /// Property for TaxClass4Description
               /// </summary>
               public const string TaxClass4Description = "TCLAS4DESC";

               /// <summary>
               /// Property for TaxClass5Description
               /// </summary>
               public const string TaxClass5Description = "TCLAS5DESC";

               /// <summary>
               /// Property for ShipmentSourceCurrDesc
               /// </summary>
               public const string ShipmentSourceCurrDesc = "SHSRCDESC";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SHHOMDESC
               /// </summary>
               public const string ShipmentHomeCurrencyDesc = "SHHOMDESC";

               /// <summary>
               /// Property for ShipmentRateTypeDesc
               /// </summary>
               public const string ShipmentRateTypeDesc = "SHRTTYDESC";

               /// <summary>
               /// Property for ShipmentSourceCurrencyDesc
               /// </summary>
               public const string ShipmentSourceCurrencyDesc = "ORSRCDESC";

               //// TODO: The naming convention of this property has to be manually evaluated
               ///// <summary>
               ///// Property for ORHOMDESC
               ///// </summary>
               //public const string ORHOMDESC = "ORHOMDESC";

               /// <summary>
               /// Property for ShipmentRateTypeDescription
               /// </summary>
               public const string ShipmentRateTypeDescription = "ORRTTYDESC";

               /// <summary>
               /// Property for TotalTaxAmount1
               /// </summary>
               public const string TotalTaxAmount1 = "TAMOUNT1";

               /// <summary>
               /// Property for TotalTaxAmount2
               /// </summary>
               public const string TotalTaxAmount2 = "TAMOUNT2";

               /// <summary>
               /// Property for TotalTaxAmount3
               /// </summary>
               public const string TotalTaxAmount3 = "TAMOUNT3";

               /// <summary>
               /// Property for TotalTaxAmount4
               /// </summary>
               public const string TotalTaxAmount4 = "TAMOUNT4";

               /// <summary>
               /// Property for TotalTaxAmount5
               /// </summary>
               public const string TotalTaxAmount5 = "TAMOUNT5";

               /// <summary>
               /// Property for TotalTaxAmount
               /// </summary>
               public const string TotalTaxAmount = "SHITAXTOT";

               /// <summary>
               /// Property for ShipmentRunningTotal
               /// </summary>
               public const string ShipmentRunningTotal = "RUNNINGTOT";

               /// <summary>
               /// Property for PerformTaxCalculation
               /// </summary>
               public const string PerformTaxCalculation = "GOCALCTAX";

               /// <summary>
               /// Property for PerformShipAll
               /// </summary>
               public const string PerformShipAll = "GOSHIPALL";

               /// <summary>
               /// Property for DOSConversionInProgress
               /// </summary>
               public const string DOSConversionInProgress = "DOSCONVERT";

               /// <summary>
               /// Property for PerformForcedTaxCalculation
               /// </summary>
               public const string PerformForcedTaxCalculation = "GOFCALCTAX";

               /// <summary>
               /// Property for PerformManualTaxDistribution
               /// </summary>
               public const string PerformManualTaxDistribution = "GODISTTAX";

               /// <summary>
               /// Property for TaxCalculationInProgress
               /// </summary>
               public const string TaxCalculationInProgress = "TXCALCINPG";

               /// <summary>
               /// Property for DisplayRateWarning
               /// </summary>
               public const string DisplayRateWarning = "RTWARNMSG";

               /// <summary>
               /// Property for CustomerExists
               /// </summary>
               public const string CustomerExists = "CUSTEXIST";

               /// <summary>
               /// Property for SecurityEnabled
               /// </summary>
               public const string SecurityEnabled = "SECENABLED";

               /// <summary>
               /// Property for UserCanApproveCreditLift
               /// </summary>
               public const string UserCanApproveCreditLift = "GOAPPROSEC";

               /// <summary>
               /// Property for PerformCreditLimitCheck
               /// </summary>
               public const string PerformCreditLimitCheck = "GOCHKCRDT";

               /// <summary>
               /// Property for AuthorizingUserPassword
               /// </summary>
               public const string AuthorizingUserPassword = "APPPASSWRD";

               /// <summary>
               /// Property for Allowpartialshipments
               /// </summary>
               public const string Allowpartialshipments = "SWPARTSHIP";

               /// <summary>
               /// Property for GenerateShipFromSingleOrder
               /// </summary>
               public const string GenerateShipFromSingleOrder = "SHIP1ORDER";

               /// <summary>
               /// Property for GenerateShipFromMultOrders
               /// </summary>
               public const string GenerateShipFromMultOrders = "SHIPORDERS";

               /// <summary>
               /// Property for CreateInvoiceFromShipment
               /// </summary>
               public const string CreateInvoiceFromShipment = "CREATEINV";

               /// <summary>
               /// Property for InvoiceNumber
               /// </summary>
               public const string InvoiceNumber = "INVNUMBER";

               /// <summary>
               /// Property for PostSequenceNumber
               /// </summary>
               public const string PostSequenceNumber = "POSTSEQNUM";

               /// <summary>
               /// Property for InvoiceUniquifier
               /// </summary>
               public const string InvoiceUniquifier = "INVUNIQ";

               /// <summary>
               /// Property for InvoiceDate
               /// </summary>
               public const string InvoiceDate = "INVDATE";

               /// <summary>
               /// Property for InvoiceHomeCurrency
               /// </summary>
               public const string InvoiceHomeCurrency = "INHOMECURR";

               /// <summary>
               /// Property for InvoiceRateType
               /// </summary>
               public const string InvoiceRateType = "INRATETYPE";

               /// <summary>
               /// Property for InvoiceSourceCurrency
               /// </summary>
               public const string InvoiceSourceCurrency = "INSOURCURR";

               /// <summary>
               /// Property for InvoiceRateDate
               /// </summary>
               public const string InvoiceRateDate = "INRATEDATE";

               /// <summary>
               /// Property for InvoiceRate
               /// </summary>
               public const string InvoiceRate = "INRATE";

               /// <summary>
               /// Property for InvoiceSpread
               /// </summary>
               public const string InvoiceSpread = "INSPREAD";

               /// <summary>
               /// Property for InvoiceRateDateMatching
               /// </summary>
               public const string InvoiceRateDateMatching = "INDATEMTCH";

               /// <summary>
               /// Property for InvoiceRateOperator
               /// </summary>
               public const string InvoiceRateOperator = "INRATEREP";

               /// <summary>
               /// Property for InvoiceRateOverrideFlag
               /// </summary>
               public const string InvoiceRateOverrideFlag = "INRATEOVER";

               /// <summary>
               /// Property for InvoiceSourceCurrencyDesc
               /// </summary>
               public const string InvoiceSourceCurrencyDesc = "INSRCDESC";

               /// <summary>
               /// Property for InvoiceHomeCurrencyDesc
               /// </summary>
               public const string InvoiceHomeCurrencyDesc = "INHOMDESC";

               /// <summary>
               /// Property for InvoiceRateTypeDescription
               /// </summary>
               public const string InvoiceRateTypeDescription = "INRTTYDESC";

               /// <summary>
               /// Property for CreatedFromOrder
               /// </summary>
               public const string CreatedFromOrder = "FROMORDER";

               /// <summary>
               /// Property for ProcessOIPCommand
               /// </summary>
               public const string ProcessOIPCommand = "PROCESSCMD";

               /// <summary>
               /// Property for ProcessOECommand
               /// </summary>
               public const string ProcessOECommand = "OECOMMAND";

               /// <summary>
               /// Property for UserEnteredApprovalAmount
               /// </summary>
               public const string UserEnteredApprovalAmount = "EDAPRVLMT";

               /// <summary>
               /// Property for CheckingCustomerCreditLimit
               /// </summary>
               public const string CheckingCustomerCreditLimit = "SWCHKLIMC";

               /// <summary>
               /// Property for CheckingCustomerAgingLimit
               /// </summary>
               public const string CheckingCustomerAgingLimit = "SWCHKODUEC";

               /// <summary>
               /// Property for CheckingNatAcctCreditLimit
               /// </summary>
               public const string CheckingNatAcctCreditLimit = "SWCHKLIMA";

               /// <summary>
               /// Property for CheckingNatAcctAgingLimit
               /// </summary>
               public const string CheckingNatAcctAgingLimit = "SWCHKODUEA";

               /// <summary>
               /// Property for CustomerIsOverCreditLimit
               /// </summary>
               public const string CustomerIsOverCreditLimit = "SWOVERLIMC";

               /// <summary>
               /// Property for CustomerIsOverAgingLimit
               /// </summary>
               public const string CustomerIsOverAgingLimit = "SWOVERDUEC";

               /// <summary>
               /// Property for NatAcctIsOverCreditLimit
               /// </summary>
               public const string NatAcctIsOverCreditLimit = "SWOVERLIMA";

               /// <summary>
               /// Property for NatAcctIsOverAgingLimit
               /// </summary>
               public const string NatAcctIsOverAgingLimit = "SWOVERDUEA";

               /// <summary>
               /// Property for CustomerCreditLimit
               /// </summary>
               public const string CustomerCreditLimit = "AMTLIMITC";

               /// <summary>
               /// Property for CustomerBalancePosted
               /// </summary>
               public const string CustomerBalancePosted = "AMTBALCUST";

               /// <summary>
               /// Property for CustomerDaysOverdue
               /// </summary>
               public const string CustomerDaysOverdue = "OVDUEDAYSC";

               /// <summary>
               /// Property for CustomerOverdueLimit
               /// </summary>
               public const string CustomerOverdueLimit = "OVDUELMTC";

               /// <summary>
               /// Property for CustomerBalanceOverdue
               /// </summary>
               public const string CustomerBalanceOverdue = "OVDUEBALC";

               /// <summary>
               /// Property for NatAcctCreditLimit
               /// </summary>
               public const string NatAcctCreditLimit = "AMTLIMITA";

               /// <summary>
               /// Property for NatAcctBalance
               /// </summary>
               public const string NatAcctBalance = "AMTBALACCT";

               /// <summary>
               /// Property for NatAcctDaysOverdue
               /// </summary>
               public const string NatAcctDaysOverdue = "OVDUEDAYSA";

               /// <summary>
               /// Property for NatAcctOverdueLimit
               /// </summary>
               public const string NatAcctOverdueLimit = "OVDUELMTA";

               /// <summary>
               /// Property for NatAcctBalanceOverdue
               /// </summary>
               public const string NatAcctBalanceOverdue = "OVDUEBALA";

               /// <summary>
               /// Property for ARPendingTransIncluded
               /// </summary>
               public const string ARPendingTransIncluded = "SWARPEND";

               /// <summary>
               /// Property for OEPendingTransIncluded
               /// </summary>
               public const string OEPendingTransIncluded = "SWOEPEND";

               /// <summary>
               /// Property for OtherPendingTransIncluded
               /// </summary>
               public const string OtherPendingTransIncluded = "SWXXPEND";

               /// <summary>
               /// Property for ARPendingBalance
               /// </summary>
               public const string ARPendingBalance = "AMTARPEND";

               /// <summary>
               /// Property for OEPendingBalance
               /// </summary>
               public const string OEPendingBalance = "AMTOEPEND";

               /// <summary>
               /// Property for OtherPendingBalance
               /// </summary>
               public const string OtherPendingBalance = "AMTXXPEND";

               /// <summary>
               /// Property for CustomerTotalOutstanding
               /// </summary>
               public const string CustomerTotalOutstanding = "AMTTOTCUST";

               /// <summary>
               /// Property for NatAcctTotalOutstanding
               /// </summary>
               public const string NatAcctTotalOutstanding = "AMTTOTACCT";

               /// <summary>
               /// Property for CustomerLimitLeft
               /// </summary>
               public const string CustomerLimitLeft = "AMTLEFTC";

               /// <summary>
               /// Property for NatAcctLimitLeft
               /// </summary>
               public const string NatAcctLimitLeft = "AMTLEFTA";

               /// <summary>
               /// Property for CustomerLimitExceeded
               /// </summary>
               public const string CustomerLimitExceeded = "AMTOVERC";

               /// <summary>
               /// Property for NatAcctLimitExceeded
               /// </summary>
               public const string NatAcctLimitExceeded = "AMTOVERA";

               /// <summary>
               /// Property for LastInvoiceAmount
               /// </summary>
               public const string LastInvoiceAmount = "AMTLASTIVT";

               /// <summary>
               /// Property for LastInvoiceDate
               /// </summary>
               public const string LastInvoiceDate = "DATELASTIV";

               /// <summary>
               /// Property for LastPaymentAmount
               /// </summary>
               public const string LastPaymentAmount = "AMTLASTPYT";

               /// <summary>
               /// Property for LastPaymentDate
               /// </summary>
               public const string LastPaymentDate = "DATELASTPA";

               /// <summary>
               /// Property for DrivenbyUI
               /// </summary>
               public const string DrivenbyUI = "DRIVENBYUI";

               /// <summary>
               /// Property for DetailDiscountTotal
               /// </summary>
               public const string DetailDiscountTotal = "DTLDISCTOT";

               /// <summary>
               /// Property for DetailDiscountPercentage
               /// </summary>
               public const string DetailDiscountPercentage = "DTLDISCPER";

               /// <summary>
               /// Property for DocumentNetOfDetailDisc
               /// </summary>
               public const string DocumentNetOfDetailDisc = "SHINTDTDIS";

               /// <summary>
               /// Property for TRTaxAmount1
               /// </summary>
               public const string TRTaxAmount1 = "STRAMOUNT1";

               /// <summary>
               /// Property for TRTaxAmount2
               /// </summary>
               public const string TRTaxAmount2 = "STRAMOUNT2";

               /// <summary>
               /// Property for TRTaxAmount3
               /// </summary>
               public const string TRTaxAmount3 = "STRAMOUNT3";

               /// <summary>
               /// Property for TRTaxAmount4
               /// </summary>
               public const string TRTaxAmount4 = "STRAMOUNT4";

               /// <summary>
               /// Property for TRTaxAmount5
               /// </summary>
               public const string TRTaxAmount5 = "STRAMOUNT5";

               /// <summary>
               /// Property for TRExcludedTaxTotal
               /// </summary>
               public const string TRExcludedTaxTotal = "STRETOTAL";

               /// <summary>
               /// Property for TRIncludedTaxTotal
               /// </summary>
               public const string TRIncludedTaxTotal = "STRITOTAL";

               /// <summary>
               /// Property for TRTaxTotal
               /// </summary>
               public const string TRTaxTotal = "STRTOTAL";

               /// <summary>
               /// Property for TaxReportingInvoiceTRCurre
               /// </summary>
               public const string TaxReportingInvoiceTRCurre = "ITRCURRNCY";

               /// <summary>
               /// Property for TRInvoiceRateType
               /// </summary>
               public const string TRInvoiceRateType = "ITRRATTYPE";

               /// <summary>
               /// Property for TRInvoiceRateDate
               /// </summary>
               public const string TRInvoiceRateDate = "ITRRATDATE";

               /// <summary>
               /// Property for TRInvoiceRate
               /// </summary>
               public const string TRInvoiceRate = "ITRRATE";

               /// <summary>
               /// Property for TRInvoiceSpread
               /// </summary>
               public const string TRInvoiceSpread = "ITRSPREAD";

               /// <summary>
               /// Property for TRInvoiceRateDateMatching
               /// </summary>
               public const string TRInvoiceRateDateMatching = "ITRDATMTCH";

               /// <summary>
               /// Property for TRInvoiceRateOperator
               /// </summary>
               public const string TRInvoiceRateOperator = "ITRRATEOP";

               /// <summary>
               /// Property for TRInvoiceRateOverrideFlag
               /// </summary>
               public const string TRInvoiceRateOverrideFlag = "ITRRATOVER";

               /// <summary>
               /// Property for TRCurrencyDescription
               /// </summary>
               public const string TRCurrencyDescription = "OTRCURDESC";

               /// <summary>
               /// Property for TRShipmentCurrencyDescription
               /// </summary>
               public const string TRShipmentCurrencyDescription = "STRCURDESC";

               /// <summary>
               /// Property for TRInvoiceCurrencyDescription
               /// </summary>
               public const string TRInvoiceCurrencyDescription = "ITRCURDESC";

               /// <summary>
               /// Property for TRRateTypeDescription
               /// </summary>
               public const string TRRateTypeDescription = "OTRRTYDESC";

               /// <summary>
               /// Property for TRShipmentRateTypeDescriptio
               /// </summary>
               public const string TRShipmentRateTypeDescriptio = "STRRTYDESC";

               /// <summary>
               /// Property for TRInvoiceRateTypeDescription
               /// </summary>
               public const string TRInvoiceRateTypeDescription = "ITRRTYDESC";

               /// <summary>
               /// Property for ReceiptBatchNumber
               /// </summary>
               public const string ReceiptBatchNumber = "REBATCHNUM";

               /// <summary>
               /// Property for BankCode
               /// </summary>
               public const string BankCode = "BANKCODE";

               /// <summary>
               /// Property for ReceiptType
               /// </summary>
               public const string ReceiptType = "BANKRECTYP";

               /// <summary>
               /// Property for CheckDate
               /// </summary>
               public const string CheckDate = "CHECKDATE";

               /// <summary>
               /// Property for CheckFiscalYear
               /// </summary>
               public const string CheckFiscalYear = "CHKFISCYR";

               /// <summary>
               /// Property for CheckFiscalPeriod
               /// </summary>
               public const string CheckFiscalPeriod = "CHKFISCPER";

               /// <summary>
               /// Property for CheckNumber
               /// </summary>
               public const string CheckNumber = "CHECKNUM";

               /// <summary>
               /// Property for PaymentAppliedTo
               /// </summary>
               public const string PaymentAppliedTo = "APPLYTO";

               /// <summary>
               /// Property for PaymentInCustCurrency
               /// </summary>
               public const string PaymentInCustCurrency = "PAYMENT";

               /// <summary>
               /// Property for PaymentDisc
               /// </summary>
               public const string PaymentDisc = "PAYDISC";

               /// <summary>
               /// Property for PaymentInBankCurrency
               /// </summary>
               public const string PaymentInBankCurrency = "BANKPAYMNT";

               /// <summary>
               /// Property for PendingPrepaymentAmount
               /// </summary>
               public const string PendingPrepaymentAmount = "PENDPREPAY";

               /// <summary>
               /// Property for PaymentHomeCurrency
               /// </summary>
               public const string PaymentHomeCurrency = "PAHOMECURR";

               /// <summary>
               /// Property for PaymentRateType
               /// </summary>
               public const string PaymentRateType = "PARATETYPE";

               /// <summary>
               /// Property for PaymentSourceCurrency
               /// </summary>
               public const string PaymentSourceCurrency = "PASOURCURR";

               /// <summary>
               /// Property for PaymentRateDate
               /// </summary>
               public const string PaymentRateDate = "PARATEDATE";

               /// <summary>
               /// Property for PaymentRate
               /// </summary>
               public const string PaymentRate = "PARATE";

               /// <summary>
               /// Property for PaymentSpread
               /// </summary>
               public const string PaymentSpread = "PASPREAD";

               /// <summary>
               /// Property for PaymentRateDateMatching
               /// </summary>
               public const string PaymentRateDateMatching = "PADATEMTCH";

               /// <summary>
               /// Property for PaymentRateOperator
               /// </summary>
               public const string PaymentRateOperator = "PARATEREP";

               /// <summary>
               /// Property for PaymentType
               /// </summary>
               public const string PaymentType = "PAYMTYPE";

               /// <summary>
               /// Property for ShipmentTotalPayment
               /// </summary>
               public const string ShipmentTotalPayment = "SHIPAYMENT";

               /// <summary>
               /// Property for ShipmentAmountDue
               /// </summary>
               public const string ShipmentAmountDue = "SHIAMTDUE";

               /// <summary>
               /// Property for AmountDueLessCurrPrepayment
               /// </summary>
               public const string AmountDueLessCurrPrepayment = "AMTDUENODS";

               /// <summary>
               /// Property for JobRelated
               /// </summary>
               public const string JobRelated = "HASJOB";

               /// <summary>
               /// Property for ProjectInvoicing
               /// </summary>
               public const string ProjectInvoicing = "NONINVABLE";

               /// <summary>
               /// Property for RetainageTermsDescription
               /// </summary>
               public const string RetainageTermsDescription = "RTGTERMDSC";

               /// <summary>
               /// Property for CustomerAccountSetDescription
               /// </summary>
               public const string CustomerAccountSetDescription = "CUSACTDESC";

               /// <summary>
               /// Property for InvoicePostingDate
               /// </summary>
               public const string InvoicePostingDate = "INVDATEBUS";

               /// <summary>
               /// Property for OrderPaymentsTotal
               /// </summary>
               public const string OrderPaymentsTotal = "ORDPAYTOT";

               /// <summary>
               /// Property for PrepaymentDistributedAmount
               /// </summary>
               public const string PrepaymentDistributedAmount = "PAYDISTTOT";

               /// <summary>
               /// Property for PrepaymentUnappliedAmount
               /// </summary>
               public const string PrepaymentUnappliedAmount = "UNAPPLDPAY";

               /// <summary>
               /// Property for TotalRetainageTaxAmount
               /// </summary>
               public const string TotalRetainageTaxAmount = "RTXAMTTOT";

               /// <summary>
               /// Property for PreAuthExistsFortheShipment
               /// </summary>
               public const string PreAuthExistsFortheShipment = "PAUTHEXIST";

               /// <summary>
               /// Property for PaymentTypeOnOrder
               /// </summary>
               public const string PaymentTypeOnOrder = "PAYMONORD";

               /// <summary>
               /// Property for PaymentCodeOnOrder
               /// </summary>
               public const string PaymentCodeOnOrder = "PAYMCODE";

               /// <summary>
               /// Property for PaymentCardID
               /// </summary>
               public const string PaymentCardID = "IDCARD";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of Shipment Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for ShipmentUniquifier
               /// </summary>
               public const int ShipmentUniquifier = 1;

               /// <summary>
               /// Property Indexer for ShipmentNumber
               /// </summary>
               public const int ShipmentNumber = 2;

               /// <summary>
               /// Property Indexer for OrderNumber
               /// </summary>
               public const int OrderNumber = 3;

               /// <summary>
               /// Property Indexer for ICDayEndTransNumber
               /// </summary>
               public const int ICDayEndTransNumber = 4;

               /// <summary>
               /// Property Indexer for CustomerNumber
               /// </summary>
               public const int CustomerNumber = 5;

               /// <summary>
               /// Property Indexer for CustomerGroupCode
               /// </summary>
               public const int CustomerGroupCode = 6;

               /// <summary>
               /// Property Indexer for BillToName
               /// </summary>
               public const int BillToName = 7;

               /// <summary>
               /// Property Indexer for BillToAddressLine1
               /// </summary>
               public const int BillToAddressLine1 = 8;

               /// <summary>
               /// Property Indexer for BillToAddressLine2
               /// </summary>
               public const int BillToAddressLine2 = 9;

               /// <summary>
               /// Property Indexer for BillToAddressLine3
               /// </summary>
               public const int BillToAddressLine3 = 10;

               /// <summary>
               /// Property Indexer for BillToAddressLine4
               /// </summary>
               public const int BillToAddressLine4 = 11;

               /// <summary>
               /// Property Indexer for BillToCity
               /// </summary>
               public const int BillToCity = 12;

               /// <summary>
               /// Property Indexer for BillToStateProvince
               /// </summary>
               public const int BillToStateProvince = 13;

               /// <summary>
               /// Property Indexer for BillToZipPostalCode
               /// </summary>
               public const int BillToZipPostalCode = 14;

               /// <summary>
               /// Property Indexer for BillToCountry
               /// </summary>
               public const int BillToCountry = 15;

               /// <summary>
               /// Property Indexer for BillToPhoneNumber
               /// </summary>
               public const int BillToPhoneNumber = 16;

               /// <summary>
               /// Property Indexer for BillToFaxNumber
               /// </summary>
               public const int BillToFaxNumber = 17;

               /// <summary>
               /// Property Indexer for BillToContact
               /// </summary>
               public const int BillToContact = 18;

               /// <summary>
               /// Property Indexer for BillToEmail
               /// </summary>
               public const int BillToEmail = 19;

               /// <summary>
               /// Property Indexer for BillToContactPhone
               /// </summary>
               public const int BillToContactPhone = 20;

               /// <summary>
               /// Property Indexer for BillToContactFax
               /// </summary>
               public const int BillToContactFax = 21;

               /// <summary>
               /// Property Indexer for BillToContactEmail
               /// </summary>
               public const int BillToContactEmail = 22;

               /// <summary>
               /// Property Indexer for ShipToLocationCode
               /// </summary>
               public const int ShipToLocationCode = 23;

               /// <summary>
               /// Property Indexer for ShipToName
               /// </summary>
               public const int ShipToName = 24;

               /// <summary>
               /// Property Indexer for ShipToAddressLine1
               /// </summary>
               public const int ShipToAddressLine1 = 25;

               /// <summary>
               /// Property Indexer for ShipToAddressLine2
               /// </summary>
               public const int ShipToAddressLine2 = 26;

               /// <summary>
               /// Property Indexer for ShipToAddressLine3
               /// </summary>
               public const int ShipToAddressLine3 = 27;

               /// <summary>
               /// Property Indexer for ShipToAddressLine4
               /// </summary>
               public const int ShipToAddressLine4 = 28;

               /// <summary>
               /// Property Indexer for ShipToCity
               /// </summary>
               public const int ShipToCity = 29;

               /// <summary>
               /// Property Indexer for ShipToStateProvince
               /// </summary>
               public const int ShipToStateProvince = 30;

               /// <summary>
               /// Property Indexer for ShipToZipPostalCode
               /// </summary>
               public const int ShipToZipPostalCode = 31;

               /// <summary>
               /// Property Indexer for ShipToCountry
               /// </summary>
               public const int ShipToCountry = 32;

               /// <summary>
               /// Property Indexer for ShipToPhoneNumber
               /// </summary>
               public const int ShipToPhoneNumber = 33;

               /// <summary>
               /// Property Indexer for ShipToFaxNumber
               /// </summary>
               public const int ShipToFaxNumber = 34;

               /// <summary>
               /// Property Indexer for ShipToContact
               /// </summary>
               public const int ShipToContact = 35;

               /// <summary>
               /// Property Indexer for ShipToEmail
               /// </summary>
               public const int ShipToEmail = 36;

               /// <summary>
               /// Property Indexer for ShipToContactPhone
               /// </summary>
               public const int ShipToContactPhone = 37;

               /// <summary>
               /// Property Indexer for ShipToContactFax
               /// </summary>
               public const int ShipToContactFax = 38;

               /// <summary>
               /// Property Indexer for ShipToContactEmail
               /// </summary>
               public const int ShipToContactEmail = 39;

               /// <summary>
               /// Property Indexer for CustomerDiscountLevel
               /// </summary>
               public const int CustomerDiscountLevel = 40;

               /// <summary>
               /// Property Indexer for DefaultPriceListCode
               /// </summary>
               public const int DefaultPriceListCode = 41;

               /// <summary>
               /// Property Indexer for PurchaseOrderNumber
               /// </summary>
               public const int PurchaseOrderNumber = 42;

               /// <summary>
               /// Property Indexer for Territory
               /// </summary>
               public const int Territory = 43;

               /// <summary>
               /// Property Indexer for TermsCode
               /// </summary>
               public const int TermsCode = 44;

               /// <summary>
               /// Property Indexer for ShipmentReference
               /// </summary>
               public const int ShipmentReference = 45;

               /// <summary>
               /// Property Indexer for ShipmentDate
               /// </summary>
               public const int ShipmentDate = 46;

               /// <summary>
               /// Property Indexer for ExpectedShipDate
               /// </summary>
               public const int ExpectedShipDate = 47;

               /// <summary>
               /// Property Indexer for ShipViaCode
               /// </summary>
               public const int ShipViaCode = 48;

               /// <summary>
               /// Property Indexer for ShipViaCodeDescription
               /// </summary>
               public const int ShipViaCodeDescription = 49;

               /// <summary>
               /// Property Indexer for ShipmentFiscalYear
               /// </summary>
               public const int ShipmentFiscalYear = 50;

               /// <summary>
               /// Property Indexer for ShipmentFiscalPeriod
               /// </summary>
               public const int ShipmentFiscalPeriod = 51;

               /// <summary>
               /// Property Indexer for LastInvoiceNumber
               /// </summary>
               public const int LastInvoiceNumber = 52;

               /// <summary>
               /// Property Indexer for NumberOfInvoices
               /// </summary>
               public const int NumberOfInvoices = 53;

               /// <summary>
               /// Property Indexer for FreeOnBoardPoint
               /// </summary>
               public const int FreeOnBoardPoint = 54;

               /// <summary>
               /// Property Indexer for TemplateCode
               /// </summary>
               public const int TemplateCode = 55;

               /// <summary>
               /// Property Indexer for DefaultLocationCode
               /// </summary>
               public const int DefaultLocationCode = 56;

               /// <summary>
               /// Property Indexer for ShipmentDescription
               /// </summary>
               public const int ShipmentDescription = 57;

               /// <summary>
               /// Property Indexer for ShipmentComment
               /// </summary>
               public const int ShipmentComment = 58;

               /// <summary>
               /// Property Indexer for OverCreditLimit
               /// </summary>
               public const int OverCreditLimit = 59;

               /// <summary>
               /// Property Indexer for ApprovedLimit
               /// </summary>
               public const int ApprovedLimit = 60;

               /// <summary>
               /// Property Indexer for AuthorizingUserID
               /// </summary>
               public const int AuthorizingUserID = 61;

               /// <summary>
               /// Property Indexer for OrderPrintStatus
               /// </summary>
               public const int OrderPrintStatus = 62;

               /// <summary>
               /// Property Indexer for LastPostingDate
               /// </summary>
               public const int LastPostingDate = 63;

               /// <summary>
               /// Property Indexer for RequiresShippingLabels
               /// </summary>
               public const int RequiresShippingLabels = 64;

               /// <summary>
               /// Property Indexer for ShippingLabelsPrinted
               /// </summary>
               public const int ShippingLabelsPrinted = 65;

               /// <summary>
               /// Property Indexer for ShipmentHomeCurrency
               /// </summary>
               public const int ShipmentHomeCurrency = 66;

               /// <summary>
               /// Property Indexer for ShipmentRateType
               /// </summary>
               public const int ShipmentRateType = 67;

               /// <summary>
               /// Property Indexer for ShipmentSourceCurrency
               /// </summary>
               public const int ShipmentSourceCurrency = 68;

               /// <summary>
               /// Property Indexer for ShipmentRateDate
               /// </summary>
               public const int ShipmentRateDate = 69;

               /// <summary>
               /// Property Indexer for ShipmentRate
               /// </summary>
               public const int ShipmentRate = 70;

               /// <summary>
               /// Property Indexer for ShipmentSpread
               /// </summary>
               public const int ShipmentSpread = 71;

               /// <summary>
               /// Property Indexer for ShipmentRateDateMatching
               /// </summary>
               public const int ShipmentRateDateMatching = 72;

               /// <summary>
               /// Property Indexer for ShipmentRateOperator
               /// </summary>
               public const int ShipmentRateOperator = 73;

               /// <summary>
               /// Property Indexer for ShipmentRateOverrideFlag
               /// </summary>
               public const int ShipmentRateOverrideFlag = 74;

               /// <summary>
               /// Property Indexer for TotalAmtItems
               /// </summary>
               public const int TotalAmtItems = 75;

               /// <summary>
               /// Property Indexer for TotalAmtMiscCharges
               /// </summary>
               public const int TotalAmtMiscCharges = 76;

               /// <summary>
               /// Property Indexer for NumberOfLinesonShipment
               /// </summary>
               public const int NumberOfLinesonShipment = 77;

               /// <summary>
               /// Property Indexer for NumberOfLabels
               /// </summary>
               public const int NumberOfLabels = 78;

               /// <summary>
               /// Property Indexer for PrevPaymentsTotal
               /// </summary>
               public const int PrevPaymentsTotal = 79;

               /// <summary>
               /// Property Indexer for PrevPaymentDiscTotal
               /// </summary>
               public const int PrevPaymentDiscTotal = 80;

               /// <summary>
               /// Property Indexer for Salesperson1
               /// </summary>
               public const int Salesperson1 = 81;

               /// <summary>
               /// Property Indexer for Salesperson2
               /// </summary>
               public const int Salesperson2 = 82;

               /// <summary>
               /// Property Indexer for Salesperson3
               /// </summary>
               public const int Salesperson3 = 83;

               /// <summary>
               /// Property Indexer for Salesperson4
               /// </summary>
               public const int Salesperson4 = 84;

               /// <summary>
               /// Property Indexer for Salesperson5
               /// </summary>
               public const int Salesperson5 = 85;

               /// <summary>
               /// Property Indexer for SalesPercentage1
               /// </summary>
               public const int SalesPercentage1 = 86;

               /// <summary>
               /// Property Indexer for SalesPercentage2
               /// </summary>
               public const int SalesPercentage2 = 87;

               /// <summary>
               /// Property Indexer for SalesPercentage3
               /// </summary>
               public const int SalesPercentage3 = 88;

               /// <summary>
               /// Property Indexer for SalesPercentage4
               /// </summary>
               public const int SalesPercentage4 = 89;

               /// <summary>
               /// Property Indexer for SalesPercentage5
               /// </summary>
               public const int SalesPercentage5 = 90;

               /// <summary>
               /// Property Indexer for RecalculateTax
               /// </summary>
               public const int RecalculateTax = 91;

               /// <summary>
               /// Property Indexer for TaxOverridden
               /// </summary>
               public const int TaxOverridden = 92;

               /// <summary>
               /// Property Indexer for TaxGroup
               /// </summary>
               public const int TaxGroup = 93;

               /// <summary>
               /// Property Indexer for TaxAuthority1
               /// </summary>
               public const int TaxAuthority1 = 94;

               /// <summary>
               /// Property Indexer for TaxAuthority2
               /// </summary>
               public const int TaxAuthority2 = 95;

               /// <summary>
               /// Property Indexer for TaxAuthority3
               /// </summary>
               public const int TaxAuthority3 = 96;

               /// <summary>
               /// Property Indexer for TaxAuthority4
               /// </summary>
               public const int TaxAuthority4 = 97;

               /// <summary>
               /// Property Indexer for TaxAuthority5
               /// </summary>
               public const int TaxAuthority5 = 98;

               /// <summary>
               /// Property Indexer for TaxClass1
               /// </summary>
               public const int TaxClass1 = 99;

               /// <summary>
               /// Property Indexer for TaxClass2
               /// </summary>
               public const int TaxClass2 = 100;

               /// <summary>
               /// Property Indexer for TaxClass3
               /// </summary>
               public const int TaxClass3 = 101;

               /// <summary>
               /// Property Indexer for TaxClass4
               /// </summary>
               public const int TaxClass4 = 102;

               /// <summary>
               /// Property Indexer for TaxClass5
               /// </summary>
               public const int TaxClass5 = 103;

               /// <summary>
               /// Property Indexer for TaxBase1
               /// </summary>
               public const int TaxBase1 = 104;

               /// <summary>
               /// Property Indexer for TaxBase2
               /// </summary>
               public const int TaxBase2 = 105;

               /// <summary>
               /// Property Indexer for TaxBase3
               /// </summary>
               public const int TaxBase3 = 106;

               /// <summary>
               /// Property Indexer for TaxBase4
               /// </summary>
               public const int TaxBase4 = 107;

               /// <summary>
               /// Property Indexer for TaxBase5
               /// </summary>
               public const int TaxBase5 = 108;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount1
               /// </summary>
               public const int ExcludedTaxAmount1 = 109;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount2
               /// </summary>
               public const int ExcludedTaxAmount2 = 110;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount3
               /// </summary>
               public const int ExcludedTaxAmount3 = 111;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount4
               /// </summary>
               public const int ExcludedTaxAmount4 = 112;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount5
               /// </summary>
               public const int ExcludedTaxAmount5 = 113;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount1
               /// </summary>
               public const int IncludedTaxAmount1 = 114;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount2
               /// </summary>
               public const int IncludedTaxAmount2 = 115;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount3
               /// </summary>
               public const int IncludedTaxAmount3 = 116;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount4
               /// </summary>
               public const int IncludedTaxAmount4 = 117;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount5
               /// </summary>
               public const int IncludedTaxAmount5 = 118;

               /// <summary>
               /// Property Indexer for Registration1
               /// </summary>
               public const int Registration1 = 119;

               /// <summary>
               /// Property Indexer for Registration2
               /// </summary>
               public const int Registration2 = 120;

               /// <summary>
               /// Property Indexer for Registration3
               /// </summary>
               public const int Registration3 = 121;

               /// <summary>
               /// Property Indexer for Registration4
               /// </summary>
               public const int Registration4 = 122;

               /// <summary>
               /// Property Indexer for Registration5
               /// </summary>
               public const int Registration5 = 123;

               /// <summary>
               /// Property Indexer for ShipmentCompleted
               /// </summary>
               public const int ShipmentCompleted = 132;

               /// <summary>
               /// Property Indexer for ShipmentCompletionDate
               /// </summary>
               public const int ShipmentCompletionDate = 133;

               /// <summary>
               /// Property Indexer for ShipmentTotalEstWeight
               /// </summary>
               public const int ShipmentTotalEstWeight = 134;

               /// <summary>
               /// Property Indexer for NextDetailNumber
               /// </summary>
               public const int NextDetailNumber = 135;

               /// <summary>
               /// Property Indexer for ShipmentDiscMiscCharges
               /// </summary>
               public const int ShipmentDiscMiscCharges = 136;

               /// <summary>
               /// Property Indexer for NoLinesQtyShipped
               /// </summary>
               public const int NoLinesQtyShipped = 137;

               /// <summary>
               /// Property Indexer for NoMiscChargesLines
               /// </summary>
               public const int NoMiscChargesLines = 138;

               /// <summary>
               /// Property Indexer for ShipmentTotalBeforeTax
               /// </summary>
               public const int ShipmentTotalBeforeTax = 139;

               /// <summary>
               /// Property Indexer for ShipmentInclTaxTotal
               /// </summary>
               public const int ShipmentInclTaxTotal = 140;

               /// <summary>
               /// Property Indexer for ShipmentItemTotalAmount
               /// </summary>
               public const int ShipmentItemTotalAmount = 141;

               /// <summary>
               /// Property Indexer for ShipmentDiscountBase
               /// </summary>
               public const int ShipmentDiscountBase = 142;

               /// <summary>
               /// Property Indexer for ShipmentDiscountPercentage
               /// </summary>
               public const int ShipmentDiscountPercentage = 143;

               /// <summary>
               /// Property Indexer for ShipmentDiscountAmount
               /// </summary>
               public const int ShipmentDiscountAmount = 144;

               /// <summary>
               /// Property Indexer for ShipmentTotalMiscCharges
               /// </summary>
               public const int ShipmentTotalMiscCharges = 145;

               /// <summary>
               /// Property Indexer for ShipmentSubtotalAmount
               /// </summary>
               public const int ShipmentSubtotalAmount = 146;

               /// <summary>
               /// Property Indexer for ShipmentTotalWithInvDisc
               /// </summary>
               public const int ShipmentTotalWithInvDisc = 147;

               /// <summary>
               /// Property Indexer for ShipmentExclTaxTotal
               /// </summary>
               public const int ShipmentExclTaxTotal = 148;

               /// <summary>
               /// Property Indexer for ShipmentTotal
               /// </summary>
               public const int ShipmentTotal = 149;

               /// <summary>
               /// Property Indexer for OrderDate
               /// </summary>
               public const int OrderDate = 150;

               /// <summary>
               /// Property Indexer for OrderHomeCurrency
               /// </summary>
               public const int OrderHomeCurrency = 151;

               /// <summary>
               /// Property Indexer for OrderRateType
               /// </summary>
               public const int OrderRateType = 152;

               /// <summary>
               /// Property Indexer for OrderSourceCurrency
               /// </summary>
               public const int OrderSourceCurrency = 153;

               /// <summary>
               /// Property Indexer for OrderRateDate
               /// </summary>
               public const int OrderRateDate = 154;

               /// <summary>
               /// Property Indexer for OrderRate
               /// </summary>
               public const int OrderRate = 155;

               /// <summary>
               /// Property Indexer for OrderSpread
               /// </summary>
               public const int OrderSpread = 156;

               /// <summary>
               /// Property Indexer for OrderRateDateMatching
               /// </summary>
               public const int OrderRateDateMatching = 157;

               /// <summary>
               /// Property Indexer for OrderRateOperator
               /// </summary>
               public const int OrderRateOperator = 158;

               /// <summary>
               /// Property Indexer for OrderRateOverrideFlag
               /// </summary>
               public const int OrderRateOverrideFlag = 159;

               /// <summary>
               /// Property Indexer for AutoTaxCalculationStatus
               /// </summary>
               public const int AutoTaxCalculationStatus = 160;

               /// <summary>
               /// Property Indexer for GenerateFromMultipleOrders
               /// </summary>
               public const int GenerateFromMultipleOrders = 161;

               /// <summary>
               /// Property Indexer for FromHowManyOrders
               /// </summary>
               public const int FromHowManyOrders = 162;

               /// <summary>
               /// Property Indexer for ShipmentTrackingNumber
               /// </summary>
               public const int ShipmentTrackingNumber = 163;

               /// <summary>
               /// Property Indexer for NumberOfShipments
               /// </summary>
               public const int NumberOfShipments = 164;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 165;

               /// <summary>
               /// Property Indexer for OrderUniquifier
               /// </summary>
               public const int OrderUniquifier = 166;

               /// <summary>
               /// Property Indexer for ItemDetailDiscountTotal
               /// </summary>
               public const int ItemDetailDiscountTotal = 167;

               /// <summary>
               /// Property Indexer for MiscChargeDetailDiscountTot
               /// </summary>
               public const int MiscChargeDetailDiscountTot = 168;

               /// <summary>
               /// Property Indexer for AutoCalcTaxReportingAmounts
               /// </summary>
               public const int AutoCalcTaxReportingAmounts = 169;

               /// <summary>
               /// Property Indexer for TaxReportingTRCurrency
               /// </summary>
               public const int TaxReportingTRCurrency = 170;

               /// <summary>
               /// Property Indexer for TRRateType
               /// </summary>
               public const int TRRateType = 171;

               /// <summary>
               /// Property Indexer for TRRateDate
               /// </summary>
               public const int TRRateDate = 172;

               /// <summary>
               /// Property Indexer for TRRate
               /// </summary>
               public const int TRRate = 173;

               /// <summary>
               /// Property Indexer for TRSpread
               /// </summary>
               public const int TRSpread = 174;

               /// <summary>
               /// Property Indexer for TRRateDateMatching
               /// </summary>
               public const int TRRateDateMatching = 175;

               /// <summary>
               /// Property Indexer for TRRateOperator
               /// </summary>
               public const int TRRateOperator = 176;

               /// <summary>
               /// Property Indexer for TRRateOverrideFlag
               /// </summary>
               public const int TRRateOverrideFlag = 177;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount1
               /// </summary>
               public const int TRExcludedTaxAmount1 = 178;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount2
               /// </summary>
               public const int TRExcludedTaxAmount2 = 179;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount3
               /// </summary>
               public const int TRExcludedTaxAmount3 = 180;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount4
               /// </summary>
               public const int TRExcludedTaxAmount4 = 181;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount5
               /// </summary>
               public const int TRExcludedTaxAmount5 = 182;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount1
               /// </summary>
               public const int TRIncludedTaxAmount1 = 183;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount2
               /// </summary>
               public const int TRIncludedTaxAmount2 = 184;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount3
               /// </summary>
               public const int TRIncludedTaxAmount3 = 185;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount4
               /// </summary>
               public const int TRIncludedTaxAmount4 = 186;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount5
               /// </summary>
               public const int TRIncludedTaxAmount5 = 187;

               /// <summary>
               /// Property Indexer for TaxReportingTROrderCurrenc
               /// </summary>
               public const int TaxReportingTROrderCurrenc = 188;

               /// <summary>
               /// Property Indexer for TROrderRateType
               /// </summary>
               public const int TROrderRateType = 189;

               /// <summary>
               /// Property Indexer for TROrderRateDate
               /// </summary>
               public const int TROrderRateDate = 190;

               /// <summary>
               /// Property Indexer for TROrderRate
               /// </summary>
               public const int TROrderRate = 191;

               /// <summary>
               /// Property Indexer for TROrderSpread
               /// </summary>
               public const int TROrderSpread = 192;

               /// <summary>
               /// Property Indexer for TROrderRateDateMatching
               /// </summary>
               public const int TROrderRateDateMatching = 193;

               /// <summary>
               /// Property Indexer for TROrderRateOperator
               /// </summary>
               public const int TROrderRateOperator = 194;

               /// <summary>
               /// Property Indexer for TROrderRateOverrideFlag
               /// </summary>
               public const int TROrderRateOverrideFlag = 195;

               /// <summary>
               /// Property Indexer for ShipmentDiscountAmountOverrid
               /// </summary>
               public const int ShipmentDiscountAmountOverrid = 196;

               /// <summary>
               /// Property Indexer for ShipmentNoOfPrepayments
               /// </summary>
               public const int ShipmentNoOfPrepayments = 197;

               /// <summary>
               /// Property Indexer for JobRelatedDetailLines
               /// </summary>
               public const int JobRelatedDetailLines = 198;

               /// <summary>
               /// Property Indexer for InvoiceableDetailLines
               /// </summary>
               public const int InvoiceableDetailLines = 199;

               /// <summary>
               /// Property Indexer for HasRetainage
               /// </summary>
               public const int HasRetainage = 200;

               /// <summary>
               /// Property Indexer for RetainageTerms
               /// </summary>
               public const int RetainageTerms = 201;

               /// <summary>
               /// Property Indexer for RetainageAmount
               /// </summary>
               public const int RetainageAmount = 202;

               /// <summary>
               /// Property Indexer for RetainagePercent
               /// </summary>
               public const int RetainagePercent = 203;

               /// <summary>
               /// Property Indexer for RetainageExchangeRate
               /// </summary>
               public const int RetainageExchangeRate = 204;

               /// <summary>
               /// Property Indexer for RetainageTaxBase1
               /// </summary>
               public const int RetainageTaxBase1 = 205;

               /// <summary>
               /// Property Indexer for RetainageTaxBase2
               /// </summary>
               public const int RetainageTaxBase2 = 206;

               /// <summary>
               /// Property Indexer for RetainageTaxBase3
               /// </summary>
               public const int RetainageTaxBase3 = 207;

               /// <summary>
               /// Property Indexer for RetainageTaxBase4
               /// </summary>
               public const int RetainageTaxBase4 = 208;

               /// <summary>
               /// Property Indexer for RetainageTaxBase5
               /// </summary>
               public const int RetainageTaxBase5 = 209;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount1
               /// </summary>
               public const int RetainageTaxAmount1 = 210;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount2
               /// </summary>
               public const int RetainageTaxAmount2 = 211;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount3
               /// </summary>
               public const int RetainageTaxAmount3 = 212;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount4
               /// </summary>
               public const int RetainageTaxAmount4 = 213;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount5
               /// </summary>
               public const int RetainageTaxAmount5 = 214;

               /// <summary>
               /// Property Indexer for CustomerAccountSet
               /// </summary>
               public const int CustomerAccountSet = 215;

               /// <summary>
               /// Property Indexer for EnteredBy
               /// </summary>
               public const int EnteredBy = 216;

               /// <summary>
               /// Property Indexer for PostingDate
               /// </summary>
               public const int PostingDate = 217;

               /// <summary>
               /// Property Indexer for SageCRMOpportunityLines
               /// </summary>
               public const int SageCRMOpportunityLines = 218;

               /// <summary>
               /// Property Indexer for PriceListCodeDesc
               /// </summary>
               public const int PriceListCodeDesc = 400;

               /// <summary>
               /// Property Indexer for TermsCodeDescription
               /// </summary>
               public const int TermsCodeDescription = 401;

               /// <summary>
               /// Property Indexer for TaxGroupCodeDesc
               /// </summary>
               public const int TaxGroupCodeDesc = 402;

               /// <summary>
               /// Property Indexer for LocationCodeDesc
               /// </summary>
               public const int LocationCodeDesc = 403;

               /// <summary>
               /// Property Indexer for SalespersonName1
               /// </summary>
               public const int SalespersonName1 = 404;

               /// <summary>
               /// Property Indexer for SalespersonName2
               /// </summary>
               public const int SalespersonName2 = 405;

               /// <summary>
               /// Property Indexer for SalespersonName3
               /// </summary>
               public const int SalespersonName3 = 406;

               /// <summary>
               /// Property Indexer for SalespersonName4
               /// </summary>
               public const int SalespersonName4 = 407;

               /// <summary>
               /// Property Indexer for SalespersonName5
               /// </summary>
               public const int SalespersonName5 = 408;

               /// <summary>
               /// Property Indexer for TaxAuthority1Desc
               /// </summary>
               public const int TaxAuthority1Desc = 409;

               /// <summary>
               /// Property Indexer for TaxAuthority2Desc
               /// </summary>
               public const int TaxAuthority2Desc = 410;

               /// <summary>
               /// Property Indexer for TaxAuthority3Desc
               /// </summary>
               public const int TaxAuthority3Desc = 411;

               /// <summary>
               /// Property Indexer for TaxAuthority4Desc
               /// </summary>
               public const int TaxAuthority4Desc = 412;

               /// <summary>
               /// Property Indexer for TaxAuthority5Desc
               /// </summary>
               public const int TaxAuthority5Desc = 413;

               /// <summary>
               /// Property Indexer for TaxClass1Description
               /// </summary>
               public const int TaxClass1Description = 414;

               /// <summary>
               /// Property Indexer for TaxClass2Description
               /// </summary>
               public const int TaxClass2Description = 415;

               /// <summary>
               /// Property Indexer for TaxClass3Description
               /// </summary>
               public const int TaxClass3Description = 416;

               /// <summary>
               /// Property Indexer for TaxClass4Description
               /// </summary>
               public const int TaxClass4Description = 417;

               /// <summary>
               /// Property Indexer for TaxClass5Description
               /// </summary>
               public const int TaxClass5Description = 418;

               /// <summary>
               /// Property Indexer for ShipmentSourceCurrDesc
               /// </summary>
               public const int ShipmentSourceCurrDesc = 419;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SHHOMDESC
               /// </summary>
               public const int SHHOMDESC = 420;

               /// <summary>
               /// Property Indexer for ShipmentRateTypeDesc
               /// </summary>
               public const int ShipmentRateTypeDesc = 421;

               /// <summary>
               /// Property Indexer for ShipmentSourceCurrencyDesc
               /// </summary>
               public const int ShipmentSourceCurrencyDesc = 422;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for ORHOMDESC
               /// </summary>
               public const int ORHOMDESC = 423;

               /// <summary>
               /// Property Indexer for ShipmentRateTypeDescription
               /// </summary>
               public const int ShipmentRateTypeDescription = 424;

               /// <summary>
               /// Property Indexer for TotalTaxAmount1
               /// </summary>
               public const int TotalTaxAmount1 = 425;

               /// <summary>
               /// Property Indexer for TotalTaxAmount2
               /// </summary>
               public const int TotalTaxAmount2 = 426;

               /// <summary>
               /// Property Indexer for TotalTaxAmount3
               /// </summary>
               public const int TotalTaxAmount3 = 427;

               /// <summary>
               /// Property Indexer for TotalTaxAmount4
               /// </summary>
               public const int TotalTaxAmount4 = 428;

               /// <summary>
               /// Property Indexer for TotalTaxAmount5
               /// </summary>
               public const int TotalTaxAmount5 = 429;

               /// <summary>
               /// Property Indexer for TotalTaxAmount
               /// </summary>
               public const int TotalTaxAmount = 430;

               /// <summary>
               /// Property Indexer for ShipmentRunningTotal
               /// </summary>
               public const int ShipmentRunningTotal = 431;

               /// <summary>
               /// Property Indexer for PerformTaxCalculation
               /// </summary>
               public const int PerformTaxCalculation = 432;

               /// <summary>
               /// Property Indexer for PerformShipAll
               /// </summary>
               public const int PerformShipAll = 433;

               /// <summary>
               /// Property Indexer for DOSConversionInProgress
               /// </summary>
               public const int DOSConversionInProgress = 434;

               /// <summary>
               /// Property Indexer for PerformForcedTaxCalculation
               /// </summary>
               public const int PerformForcedTaxCalculation = 435;

               /// <summary>
               /// Property Indexer for PerformManualTaxDistribution
               /// </summary>
               public const int PerformManualTaxDistribution = 436;

               /// <summary>
               /// Property Indexer for TaxCalculationInProgress
               /// </summary>
               public const int TaxCalculationInProgress = 437;

               /// <summary>
               /// Property Indexer for DisplayRateWarning
               /// </summary>
               public const int DisplayRateWarning = 448;

               /// <summary>
               /// Property Indexer for CustomerExists
               /// </summary>
               public const int CustomerExists = 449;

               /// <summary>
               /// Property Indexer for SecurityEnabled
               /// </summary>
               public const int SecurityEnabled = 450;

               /// <summary>
               /// Property Indexer for UserCanApproveCreditLift
               /// </summary>
               public const int UserCanApproveCreditLift = 451;

               /// <summary>
               /// Property Indexer for PerformCreditLimitCheck
               /// </summary>
               public const int PerformCreditLimitCheck = 452;

               /// <summary>
               /// Property Indexer for AuthorizingUserPassword
               /// </summary>
               public const int AuthorizingUserPassword = 453;

               /// <summary>
               /// Property Indexer for Allowpartialshipments
               /// </summary>
               public const int Allowpartialshipments = 454;

               /// <summary>
               /// Property Indexer for GenerateShipFromSingleOrder
               /// </summary>
               public const int GenerateShipFromSingleOrder = 455;

               /// <summary>
               /// Property Indexer for GenerateShipFromMultOrders
               /// </summary>
               public const int GenerateShipFromMultOrders = 456;

               /// <summary>
               /// Property Indexer for CreateInvoiceFromShipment
               /// </summary>
               public const int CreateInvoiceFromShipment = 457;

               /// <summary>
               /// Property Indexer for InvoiceNumber
               /// </summary>
               public const int InvoiceNumber = 458;

               /// <summary>
               /// Property Indexer for PostSequenceNumber
               /// </summary>
               public const int PostSequenceNumber = 460;

               /// <summary>
               /// Property Indexer for InvoiceUniquifier
               /// </summary>
               public const int InvoiceUniquifier = 461;

               /// <summary>
               /// Property Indexer for InvoiceDate
               /// </summary>
               public const int InvoiceDate = 462;

               /// <summary>
               /// Property Indexer for InvoiceHomeCurrency
               /// </summary>
               public const int InvoiceHomeCurrency = 463;

               /// <summary>
               /// Property Indexer for InvoiceRateType
               /// </summary>
               public const int InvoiceRateType = 464;

               /// <summary>
               /// Property Indexer for InvoiceSourceCurrency
               /// </summary>
               public const int InvoiceSourceCurrency = 465;

               /// <summary>
               /// Property Indexer for InvoiceRateDate
               /// </summary>
               public const int InvoiceRateDate = 466;

               /// <summary>
               /// Property Indexer for InvoiceRate
               /// </summary>
               public const int InvoiceRate = 467;

               /// <summary>
               /// Property Indexer for InvoiceSpread
               /// </summary>
               public const int InvoiceSpread = 468;

               /// <summary>
               /// Property Indexer for InvoiceRateDateMatching
               /// </summary>
               public const int InvoiceRateDateMatching = 469;

               /// <summary>
               /// Property Indexer for InvoiceRateOperator
               /// </summary>
               public const int InvoiceRateOperator = 470;

               /// <summary>
               /// Property Indexer for InvoiceRateOverrideFlag
               /// </summary>
               public const int InvoiceRateOverrideFlag = 471;

               /// <summary>
               /// Property Indexer for InvoiceSourceCurrencyDesc
               /// </summary>
               public const int InvoiceSourceCurrencyDesc = 472;

               /// <summary>
               /// Property Indexer for InvoiceHomeCurrencyDesc
               /// </summary>
               public const int InvoiceHomeCurrencyDesc = 473;

               /// <summary>
               /// Property Indexer for InvoiceRateTypeDescription
               /// </summary>
               public const int InvoiceRateTypeDescription = 474;

               /// <summary>
               /// Property Indexer for CreatedFromOrder
               /// </summary>
               public const int CreatedFromOrder = 475;

               /// <summary>
               /// Property Indexer for ProcessOIPCommand
               /// </summary>
               public const int ProcessOIPCommand = 476;

               /// <summary>
               /// Property Indexer for ProcessOECommand
               /// </summary>
               public const int ProcessOECommand = 477;

               /// <summary>
               /// Property Indexer for UserEnteredApprovalAmount
               /// </summary>
               public const int UserEnteredApprovalAmount = 478;

               /// <summary>
               /// Property Indexer for CheckingCustomerCreditLimit
               /// </summary>
               public const int CheckingCustomerCreditLimit = 479;

               /// <summary>
               /// Property Indexer for CheckingCustomerAgingLimit
               /// </summary>
               public const int CheckingCustomerAgingLimit = 480;

               /// <summary>
               /// Property Indexer for CheckingNatAcctCreditLimit
               /// </summary>
               public const int CheckingNatAcctCreditLimit = 481;

               /// <summary>
               /// Property Indexer for CheckingNatAcctAgingLimit
               /// </summary>
               public const int CheckingNatAcctAgingLimit = 482;

               /// <summary>
               /// Property Indexer for CustomerIsOverCreditLimit
               /// </summary>
               public const int CustomerIsOverCreditLimit = 483;

               /// <summary>
               /// Property Indexer for CustomerIsOverAgingLimit
               /// </summary>
               public const int CustomerIsOverAgingLimit = 484;

               /// <summary>
               /// Property Indexer for NatAcctIsOverCreditLimit
               /// </summary>
               public const int NatAcctIsOverCreditLimit = 485;

               /// <summary>
               /// Property Indexer for NatAcctIsOverAgingLimit
               /// </summary>
               public const int NatAcctIsOverAgingLimit = 486;

               /// <summary>
               /// Property Indexer for CustomerCreditLimit
               /// </summary>
               public const int CustomerCreditLimit = 487;

               /// <summary>
               /// Property Indexer for CustomerBalancePosted
               /// </summary>
               public const int CustomerBalancePosted = 488;

               /// <summary>
               /// Property Indexer for CustomerDaysOverdue
               /// </summary>
               public const int CustomerDaysOverdue = 489;

               /// <summary>
               /// Property Indexer for CustomerOverdueLimit
               /// </summary>
               public const int CustomerOverdueLimit = 490;

               /// <summary>
               /// Property Indexer for CustomerBalanceOverdue
               /// </summary>
               public const int CustomerBalanceOverdue = 491;

               /// <summary>
               /// Property Indexer for NatAcctCreditLimit
               /// </summary>
               public const int NatAcctCreditLimit = 492;

               /// <summary>
               /// Property Indexer for NatAcctBalance
               /// </summary>
               public const int NatAcctBalance = 493;

               /// <summary>
               /// Property Indexer for NatAcctDaysOverdue
               /// </summary>
               public const int NatAcctDaysOverdue = 494;

               /// <summary>
               /// Property Indexer for NatAcctOverdueLimit
               /// </summary>
               public const int NatAcctOverdueLimit = 495;

               /// <summary>
               /// Property Indexer for NatAcctBalanceOverdue
               /// </summary>
               public const int NatAcctBalanceOverdue = 496;

               /// <summary>
               /// Property Indexer for ARPendingTransIncluded
               /// </summary>
               public const int ARPendingTransIncluded = 497;

               /// <summary>
               /// Property Indexer for OEPendingTransIncluded
               /// </summary>
               public const int OEPendingTransIncluded = 498;

               /// <summary>
               /// Property Indexer for OtherPendingTransIncluded
               /// </summary>
               public const int OtherPendingTransIncluded = 499;

               /// <summary>
               /// Property Indexer for ARPendingBalance
               /// </summary>
               public const int ARPendingBalance = 500;

               /// <summary>
               /// Property Indexer for OEPendingBalance
               /// </summary>
               public const int OEPendingBalance = 501;

               /// <summary>
               /// Property Indexer for OtherPendingBalance
               /// </summary>
               public const int OtherPendingBalance = 502;

               /// <summary>
               /// Property Indexer for CustomerTotalOutstanding
               /// </summary>
               public const int CustomerTotalOutstanding = 503;

               /// <summary>
               /// Property Indexer for NatAcctTotalOutstanding
               /// </summary>
               public const int NatAcctTotalOutstanding = 504;

               /// <summary>
               /// Property Indexer for CustomerLimitLeft
               /// </summary>
               public const int CustomerLimitLeft = 505;

               /// <summary>
               /// Property Indexer for NatAcctLimitLeft
               /// </summary>
               public const int NatAcctLimitLeft = 506;

               /// <summary>
               /// Property Indexer for CustomerLimitExceeded
               /// </summary>
               public const int CustomerLimitExceeded = 507;

               /// <summary>
               /// Property Indexer for NatAcctLimitExceeded
               /// </summary>
               public const int NatAcctLimitExceeded = 508;

               /// <summary>
               /// Property Indexer for LastInvoiceAmount
               /// </summary>
               public const int LastInvoiceAmount = 509;

               /// <summary>
               /// Property Indexer for LastInvoiceDate
               /// </summary>
               public const int LastInvoiceDate = 510;

               /// <summary>
               /// Property Indexer for LastPaymentAmount
               /// </summary>
               public const int LastPaymentAmount = 511;

               /// <summary>
               /// Property Indexer for LastPaymentDate
               /// </summary>
               public const int LastPaymentDate = 512;

               /// <summary>
               /// Property Indexer for DrivenbyUI
               /// </summary>
               public const int DrivenbyUI = 513;

               /// <summary>
               /// Property Indexer for DetailDiscountTotal
               /// </summary>
               public const int DetailDiscountTotal = 514;

               /// <summary>
               /// Property Indexer for DetailDiscountPercentage
               /// </summary>
               public const int DetailDiscountPercentage = 515;

               /// <summary>
               /// Property Indexer for DocumentNetOfDetailDisc
               /// </summary>
               public const int DocumentNetOfDetailDisc = 516;

               /// <summary>
               /// Property Indexer for TRTaxAmount1
               /// </summary>
               public const int TRTaxAmount1 = 517;

               /// <summary>
               /// Property Indexer for TRTaxAmount2
               /// </summary>
               public const int TRTaxAmount2 = 518;

               /// <summary>
               /// Property Indexer for TRTaxAmount3
               /// </summary>
               public const int TRTaxAmount3 = 519;

               /// <summary>
               /// Property Indexer for TRTaxAmount4
               /// </summary>
               public const int TRTaxAmount4 = 520;

               /// <summary>
               /// Property Indexer for TRTaxAmount5
               /// </summary>
               public const int TRTaxAmount5 = 521;

               /// <summary>
               /// Property Indexer for TRExcludedTaxTotal
               /// </summary>
               public const int TRExcludedTaxTotal = 522;

               /// <summary>
               /// Property Indexer for TRIncludedTaxTotal
               /// </summary>
               public const int TRIncludedTaxTotal = 523;

               /// <summary>
               /// Property Indexer for TRTaxTotal
               /// </summary>
               public const int TRTaxTotal = 524;

               /// <summary>
               /// Property Indexer for TaxReportingInvoiceTRCurre
               /// </summary>
               public const int TaxReportingInvoiceTRCurre = 525;

               /// <summary>
               /// Property Indexer for TRInvoiceRateType
               /// </summary>
               public const int TRInvoiceRateType = 526;

               /// <summary>
               /// Property Indexer for TRInvoiceRateDate
               /// </summary>
               public const int TRInvoiceRateDate = 527;

               /// <summary>
               /// Property Indexer for TRInvoiceRate
               /// </summary>
               public const int TRInvoiceRate = 528;

               /// <summary>
               /// Property Indexer for TRInvoiceSpread
               /// </summary>
               public const int TRInvoiceSpread = 529;

               /// <summary>
               /// Property Indexer for TRInvoiceRateDateMatching
               /// </summary>
               public const int TRInvoiceRateDateMatching = 530;

               /// <summary>
               /// Property Indexer for TRInvoiceRateOperator
               /// </summary>
               public const int TRInvoiceRateOperator = 531;

               /// <summary>
               /// Property Indexer for TRInvoiceRateOverrideFlag
               /// </summary>
               public const int TRInvoiceRateOverrideFlag = 532;

               /// <summary>
               /// Property Indexer for TRCurrencyDescription
               /// </summary>
               public const int TRCurrencyDescription = 533;

               /// <summary>
               /// Property Indexer for TRShipmentCurrencyDescription
               /// </summary>
               public const int TRShipmentCurrencyDescription = 534;

               /// <summary>
               /// Property Indexer for TRInvoiceCurrencyDescription
               /// </summary>
               public const int TRInvoiceCurrencyDescription = 535;

               /// <summary>
               /// Property Indexer for TRRateTypeDescription
               /// </summary>
               public const int TRRateTypeDescription = 536;

               /// <summary>
               /// Property Indexer for TRShipmentRateTypeDescriptio
               /// </summary>
               public const int TRShipmentRateTypeDescriptio = 537;

               /// <summary>
               /// Property Indexer for TRInvoiceRateTypeDescription
               /// </summary>
               public const int TRInvoiceRateTypeDescription = 538;

               /// <summary>
               /// Property Indexer for ReceiptBatchNumber
               /// </summary>
               public const int ReceiptBatchNumber = 539;

               /// <summary>
               /// Property Indexer for BankCode
               /// </summary>
               public const int BankCode = 540;

               /// <summary>
               /// Property Indexer for ReceiptType
               /// </summary>
               public const int ReceiptType = 541;

               /// <summary>
               /// Property Indexer for CheckDate
               /// </summary>
               public const int CheckDate = 542;

               /// <summary>
               /// Property Indexer for CheckFiscalYear
               /// </summary>
               public const int CheckFiscalYear = 543;

               /// <summary>
               /// Property Indexer for CheckFiscalPeriod
               /// </summary>
               public const int CheckFiscalPeriod = 544;

               /// <summary>
               /// Property Indexer for CheckNumber
               /// </summary>
               public const int CheckNumber = 545;

               /// <summary>
               /// Property Indexer for PaymentAppliedTo
               /// </summary>
               public const int PaymentAppliedTo = 546;

               /// <summary>
               /// Property Indexer for PaymentInCustCurrency
               /// </summary>
               public const int PaymentInCustCurrency = 547;

               /// <summary>
               /// Property Indexer for PaymentDisc
               /// </summary>
               public const int PaymentDisc = 548;

               /// <summary>
               /// Property Indexer for PaymentInBankCurrency
               /// </summary>
               public const int PaymentInBankCurrency = 549;

               /// <summary>
               /// Property Indexer for PendingPrepaymentAmount
               /// </summary>
               public const int PendingPrepaymentAmount = 550;

               /// <summary>
               /// Property Indexer for PaymentHomeCurrency
               /// </summary>
               public const int PaymentHomeCurrency = 551;

               /// <summary>
               /// Property Indexer for PaymentRateType
               /// </summary>
               public const int PaymentRateType = 552;

               /// <summary>
               /// Property Indexer for PaymentSourceCurrency
               /// </summary>
               public const int PaymentSourceCurrency = 553;

               /// <summary>
               /// Property Indexer for PaymentRateDate
               /// </summary>
               public const int PaymentRateDate = 554;

               /// <summary>
               /// Property Indexer for PaymentRate
               /// </summary>
               public const int PaymentRate = 555;

               /// <summary>
               /// Property Indexer for PaymentSpread
               /// </summary>
               public const int PaymentSpread = 556;

               /// <summary>
               /// Property Indexer for PaymentRateDateMatching
               /// </summary>
               public const int PaymentRateDateMatching = 557;

               /// <summary>
               /// Property Indexer for PaymentRateOperator
               /// </summary>
               public const int PaymentRateOperator = 558;

               /// <summary>
               /// Property Indexer for PaymentType
               /// </summary>
               public const int PaymentType = 559;

               /// <summary>
               /// Property Indexer for ShipmentTotalPayment
               /// </summary>
               public const int ShipmentTotalPayment = 564;

               /// <summary>
               /// Property Indexer for ShipmentAmountDue
               /// </summary>
               public const int ShipmentAmountDue = 565;

               /// <summary>
               /// Property Indexer for AmountDueLessCurrPrepayment
               /// </summary>
               public const int AmountDueLessCurrPrepayment = 566;

               /// <summary>
               /// Property Indexer for JobRelated
               /// </summary>
               public const int JobRelated = 567;

               /// <summary>
               /// Property Indexer for ProjectInvoicing
               /// </summary>
               public const int ProjectInvoicing = 568;

               /// <summary>
               /// Property Indexer for RetainageTermsDescription
               /// </summary>
               public const int RetainageTermsDescription = 569;

               /// <summary>
               /// Property Indexer for CustomerAccountSetDescription
               /// </summary>
               public const int CustomerAccountSetDescription = 570;

               /// <summary>
               /// Property Indexer for InvoicePostingDate
               /// </summary>
               public const int InvoicePostingDate = 571;

               /// <summary>
               /// Property Indexer for OrderPaymentsTotal
               /// </summary>
               public const int OrderPaymentsTotal = 572;

               /// <summary>
               /// Property Indexer for PrepaymentDistributedAmount
               /// </summary>
               public const int PrepaymentDistributedAmount = 573;

               /// <summary>
               /// Property Indexer for PrepaymentUnappliedAmount
               /// </summary>
               public const int PrepaymentUnappliedAmount = 574;

               /// <summary>
               /// Property Indexer for TotalRetainageTaxAmount
               /// </summary>
               public const int TotalRetainageTaxAmount = 575;

               /// <summary>
               /// Property Indexer for PreAuthExistsFortheShipment
               /// </summary>
               public const int PreAuthExistsFortheShipment = 576;

               /// <summary>
               /// Property Indexer for PaymentTypeOnOrder
               /// </summary>
               public const int PaymentTypeOnOrder = 577;

               /// <summary>
               /// Property Indexer for PaymentCodeOnOrder
               /// </summary>
               public const int PaymentCodeOnOrder = 578;

               /// <summary>
               /// Property Indexer for PaymentCardID
               /// </summary>
               public const int PaymentCardID = 579;

          }
          #endregion

          #region Keys

          /// <summary>
          /// Order Keys
          /// </summary>
          public class Keys
          {
              /// <summary>
              /// Shipment Uniquifier Key
              /// </summary>
              public const int ShipmentUniquifier = 0;

              /// <summary>
              /// Shipment Number Key
              /// </summary>
              public const int ShipmentNumber = 1;
          }

          #endregion

     }
}
