// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Process
{
    /// <summary>
    /// Contains list of ReportService Constants
    /// </summary>
    public partial class ReportServiceSuperview
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "OE0633";

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of ReportService Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for Operation
            /// </summary>
            public const string Operation = "OPERATION";

            /// <summary>
            /// Property for TempFileName
            /// </summary>
            public const string TempFileName = "FILENAME";

            /// <summary>
            /// Property for TempFileName2
            /// </summary>
            public const string TempFileName2 = "FILENAME2";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of ReportService Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for Operation
            /// </summary>
            public const int Operation = 1;

            /// <summary>
            /// Property Indexer for TempFileName
            /// </summary>
            public const int TempFileName = 2;

            /// <summary>
            /// Property Indexer for TempFileName2
            /// </summary>
            public const int TempFileName2 = 3;

        }

        #endregion
    }
}
