// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Process
{
    /// <summary>
    /// Contains list of FlagPrintedRecord Constants
    /// </summary>
    public partial class FlagPrintedRecord
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "OE0270";

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of FlagPrintedRecord Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for FlagOperation
            /// </summary>
            public const string FlagOperation = "OPTYPE";

            /// <summary>
            /// Property for FromDayEndNumber
            /// </summary>
            public const string FromDayEndNumber = "FROMDAYEND";

            /// <summary>
            /// Property for ToDayEndNumber
            /// </summary>
            public const string ToDayEndNumber = "TODAYEND";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "AUDTYPE";

            /// <summary>
            /// Property for SetLabelsPrinted
            /// </summary>
            public const string SetLabelsPrinted = "LBLPRINTED";

            /// <summary>
            /// Property for SetLabelsRequiredFlag
            /// </summary>
            public const string SetLabelsRequiredFlag = "LBLREQUIRE";

            /// <summary>
            /// Property for FromOrderNumber
            /// </summary>
            public const string FromOrderNumber = "FROMORDER";

            /// <summary>
            /// Property for ToOrderNumber
            /// </summary>
            public const string ToOrderNumber = "TOORDER";

            /// <summary>
            /// Property for FromInvoiceNumber
            /// </summary>
            public const string FromInvoiceNumber = "FROMINV";

            /// <summary>
            /// Property for ToInvoiceNumber
            /// </summary>
            public const string ToInvoiceNumber = "TOINV";

            /// <summary>
            /// Property for FromCreditDebitNoteNumber
            /// </summary>
            public const string FromCreditDebitNoteNumber = "FROMCRD";

            /// <summary>
            /// Property for ToCreditDebitNoteNumber
            /// </summary>
            public const string ToCreditDebitNoteNumber = "TOCRD";

            /// <summary>
            /// Property for FromLocation
            /// </summary>
            public const string FromLocation = "FROMLOC";

            /// <summary>
            /// Property for ToLocation
            /// </summary>
            public const string ToLocation = "TOLOC";

            /// <summary>
            /// Property for DisplayFormsPrintedMessageFl
            /// </summary>
            public const string DisplayFormsPrintedMessageFl = "ASKUPDATE";

            /// <summary>
            /// Property for FromShipmentNumber
            /// </summary>
            public const string FromShipmentNumber = "FROMSHI";

            /// <summary>
            /// Property for ToShipmentNumber
            /// </summary>
            public const string ToShipmentNumber = "TOSHI";

            /// <summary>
            /// Property for PrintPickingSlipsSessionHand
            /// </summary>
            public const string PrintPickingSlipsSessionHand = "SESHNDL";

            /// <summary>
            /// Property for Reprint
            /// </summary>
            public const string Reprint = "REPRINT";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of FlagPrintedRecord Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for FlagOperation
            /// </summary>
            public const int FlagOperation = 1;

            /// <summary>
            /// Property Indexer for FromDayEndNumber
            /// </summary>
            public const int FromDayEndNumber = 2;

            /// <summary>
            /// Property Indexer for ToDayEndNumber
            /// </summary>
            public const int ToDayEndNumber = 3;

            /// <summary>
            /// Property Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 4;

            /// <summary>
            /// Property Indexer for SetLabelsPrinted
            /// </summary>
            public const int SetLabelsPrinted = 5;

            /// <summary>
            /// Property Indexer for SetLabelsRequiredFlag
            /// </summary>
            public const int SetLabelsRequiredFlag = 6;

            /// <summary>
            /// Property Indexer for FromOrderNumber
            /// </summary>
            public const int FromOrderNumber = 7;

            /// <summary>
            /// Property Indexer for ToOrderNumber
            /// </summary>
            public const int ToOrderNumber = 8;

            /// <summary>
            /// Property Indexer for FromInvoiceNumber
            /// </summary>
            public const int FromInvoiceNumber = 9;

            /// <summary>
            /// Property Indexer for ToInvoiceNumber
            /// </summary>
            public const int ToInvoiceNumber = 10;

            /// <summary>
            /// Property Indexer for FromCreditDebitNoteNumber
            /// </summary>
            public const int FromCreditDebitNoteNumber = 11;

            /// <summary>
            /// Property Indexer for ToCreditDebitNoteNumber
            /// </summary>
            public const int ToCreditDebitNoteNumber = 12;

            /// <summary>
            /// Property Indexer for FromLocation
            /// </summary>
            public const int FromLocation = 13;

            /// <summary>
            /// Property Indexer for ToLocation
            /// </summary>
            public const int ToLocation = 14;

            /// <summary>
            /// Property Indexer for DisplayFormsPrintedMessageFl
            /// </summary>
            public const int DisplayFormsPrintedMessageFl = 15;

            /// <summary>
            /// Property Indexer for FromShipmentNumber
            /// </summary>
            public const int FromShipmentNumber = 16;

            /// <summary>
            /// Property Indexer for ToShipmentNumber
            /// </summary>
            public const int ToShipmentNumber = 17;

            /// <summary>
            /// Property Indexer for PrintPickingSlipsSessionHand
            /// </summary>
            public const int PrintPickingSlipsSessionHand = 18;

            /// <summary>
            /// Property Indexer for Reprint
            /// </summary>
            public const int Reprint = 19;

        }

        #endregion
    }
}
