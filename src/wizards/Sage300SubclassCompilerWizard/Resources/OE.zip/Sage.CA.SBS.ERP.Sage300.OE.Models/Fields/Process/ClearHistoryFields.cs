// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Process
{
    /// <summary>
    /// Contains list of ClearHistory Constants
    /// </summary>
    public partial class ClearHistory
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "OE0130";

        #region Properties
        /// <summary>
        /// Contains list of ClearHistory Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for ClearOrderHistory
            /// </summary>
            public const string ClearOrderHistory = "ORDHIST";

            /// <summary>
            /// Property for ThroughOrderHistoryDate
            /// </summary>
            public const string ThroughOrderHistoryDate = "OHDATE";

            /// <summary>
            /// Property for ClearSalesHistory
            /// </summary>
            public const string ClearSalesHistory = "SALHIST";

            /// <summary>
            /// Property for SalesHistoryYear
            /// </summary>
            public const string SalesHistoryYear = "SHYR";

            /// <summary>
            /// Property for SalesHistoryPeriod
            /// </summary>
            public const string SalesHistoryPeriod = "SHPR";

            /// <summary>
            /// Property for ByCustomerorItem
            /// </summary>
            public const string ByCustomerorItem = "BYCUST";

            /// <summary>
            /// Property for FromCustomer
            /// </summary>
            public const string FromCustomer = "FRCUST";

            /// <summary>
            /// Property for ToCustomer
            /// </summary>
            public const string ToCustomer = "TOCUST";

            /// <summary>
            /// Property for FromItem
            /// </summary>
            public const string FromItem = "FRITEM";

            /// <summary>
            /// Property for ToItem
            /// </summary>
            public const string ToItem = "TOITEM";

            /// <summary>
            /// Property for ClearStatistics
            /// </summary>
            public const string ClearStatistics = "STATS";

            /// <summary>
            /// Property for StatisticsYear
            /// </summary>
            public const string StatisticsYear = "STATYR";

            /// <summary>
            /// Property for StatisticsPeriod
            /// </summary>
            public const string StatisticsPeriod = "STATPR";

            /// <summary>
            /// Property for ClearSalespersonCommission
            /// </summary>
            public const string ClearSalespersonCommission = "SALCOMM";

            /// <summary>
            /// Property for FromSalesperson
            /// </summary>
            public const string FromSalesperson = "FRSALESPER";

            /// <summary>
            /// Property for ToSalesperson
            /// </summary>
            public const string ToSalesperson = "TOSALESPER";

            /// <summary>
            /// Property for ClearPrintedPostingJournals
            /// </summary>
            public const string ClearPrintedPostingJournals = "POSTJ";

            /// <summary>
            /// Property for ThroughDayEndNo
            /// </summary>
            public const string ThroughDayEndNo = "DAYENDNUM";

            /// <summary>
            /// Property for Invoices
            /// </summary>
            public const string Invoices = "INV";

            /// <summary>
            /// Property for CreditNotes
            /// </summary>
            public const string CreditNotes = "CRN";

            /// <summary>
            /// Property for Shipments
            /// </summary>
            public const string Shipments = "SHI";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of ClearHistory Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for ClearOrderHistory
            /// </summary>
            public const int ClearOrderHistory = 1;

            /// <summary>
            /// Property Indexer for ThroughOrderHistoryDate
            /// </summary>
            public const int ThroughOrderHistoryDate = 2;

            /// <summary>
            /// Property Indexer for ClearSalesHistory
            /// </summary>
            public const int ClearSalesHistory = 3;

            /// <summary>
            /// Property Indexer for SalesHistoryYear
            /// </summary>
            public const int SalesHistoryYear = 4;

            /// <summary>
            /// Property Indexer for SalesHistoryPeriod
            /// </summary>
            public const int SalesHistoryPeriod = 5;

            /// <summary>
            /// Property Indexer for ByCustomerorItem
            /// </summary>
            public const int ByCustomerorItem = 6;

            /// <summary>
            /// Property Indexer for FromCustomer
            /// </summary>
            public const int FromCustomer = 7;

            /// <summary>
            /// Property Indexer for ToCustomer
            /// </summary>
            public const int ToCustomer = 8;

            /// <summary>
            /// Property Indexer for FromItem
            /// </summary>
            public const int FromItem = 9;

            /// <summary>
            /// Property Indexer for ToItem
            /// </summary>
            public const int ToItem = 10;

            /// <summary>
            /// Property Indexer for ClearStatistics
            /// </summary>
            public const int ClearStatistics = 11;

            /// <summary>
            /// Property Indexer for StatisticsYear
            /// </summary>
            public const int StatisticsYear = 12;

            /// <summary>
            /// Property Indexer for StatisticsPeriod
            /// </summary>
            public const int StatisticsPeriod = 13;

            /// <summary>
            /// Property Indexer for ClearSalespersonCommission
            /// </summary>
            public const int ClearSalespersonCommission = 14;

            /// <summary>
            /// Property Indexer for FromSalesperson
            /// </summary>
            public const int FromSalesperson = 15;

            /// <summary>
            /// Property Indexer for ToSalesperson
            /// </summary>
            public const int ToSalesperson = 16;

            /// <summary>
            /// Property Indexer for ClearPrintedPostingJournals
            /// </summary>
            public const int ClearPrintedPostingJournals = 17;

            /// <summary>
            /// Property Indexer for ThroughDayEndNo
            /// </summary>
            public const int ThroughDayEndNo = 18;

            /// <summary>
            /// Property Indexer for Invoices
            /// </summary>
            public const int Invoices = 19;

            /// <summary>
            /// Property Indexer for CreditNotes
            /// </summary>
            public const int CreditNotes = 20;

            /// <summary>
            /// Property Indexer for Shipments
            /// </summary>
            public const int Shipments = 21;

        }
        #endregion

    }
}
