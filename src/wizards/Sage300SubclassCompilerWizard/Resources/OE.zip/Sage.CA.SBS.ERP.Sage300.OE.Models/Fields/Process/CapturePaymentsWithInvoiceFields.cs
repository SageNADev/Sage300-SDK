// Copyright © 2017 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Process
{
    /// <summary>
    /// Contains list of CapturePaymentsWithInvoice Constants
    /// </summary>
    public partial class CapturePaymentsWithInvoice
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "OE0126";


        #region Properties

        /// <summary>
        /// Contains list of CapturePaymentsWithInvoice Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for BatchDate
            /// </summary>
            public const string BatchDate = "DATEBTCH";

            /// <summary>
            /// Property for FromOrderNumber
            /// </summary>
            public const string FromOrderNumber = "FROMORDER";

            /// <summary>
            /// Property for ToOrderNumber
            /// </summary>
            public const string ToOrderNumber = "TOORDER";

            /// <summary>
            /// Property for FromShipmentNumber
            /// </summary>
            public const string FromShipmentNumber = "FROMSHIP";

            /// <summary>
            /// Property for ToShipmentNumber
            /// </summary>
            public const string ToShipmentNumber = "TOSHIP";

            /// <summary>
            /// Property for FromProcessingCode
            /// </summary>
            public const string FromProcessingCode = "FROMPRCODE";

            /// <summary>
            /// Property for ToProcessingCode
            /// </summary>
            public const string ToProcessingCode = "TOPRCODE";

            /// <summary>
            /// Property for FirstGeneratedOEInvoiceNumbe
            /// </summary>
            public const string FirstGeneratedOEInvoiceNumbe = "FIRSTINV";

            /// <summary>
            /// Property for LastGeneratedOEInvoiceNumber
            /// </summary>
            public const string LastGeneratedOEInvoiceNumber = "LASTINV";

            /// <summary>
            /// Property for FirstGeneratedARBatchNumber
            /// </summary>
            public const string FirstGeneratedARBatchNumber = "FIRSTBTCH";

            /// <summary>
            /// Property for LastGeneratedARBatchNumber
            /// </summary>
            public const string LastGeneratedARBatchNumber = "LASTBTCH";

            /// <summary>
            /// Property for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of CapturePaymentsWithInvoice Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for BatchDate
            /// </summary>
            public const int BatchDate = 1;

            /// <summary>
            /// Property Indexer for FromOrderNumber
            /// </summary>
            public const int FromOrderNumber = 2;

            /// <summary>
            /// Property Indexer for ToOrderNumber
            /// </summary>
            public const int ToOrderNumber = 3;

            /// <summary>
            /// Property Indexer for FromShipmentNumber
            /// </summary>
            public const int FromShipmentNumber = 4;

            /// <summary>
            /// Property Indexer for ToShipmentNumber
            /// </summary>
            public const int ToShipmentNumber = 5;

            /// <summary>
            /// Property Indexer for FromProcessingCode
            /// </summary>
            public const int FromProcessingCode = 6;

            /// <summary>
            /// Property Indexer for ToProcessingCode
            /// </summary>
            public const int ToProcessingCode = 7;

            /// <summary>
            /// Property Indexer for FirstGeneratedOEInvoiceNumbe
            /// </summary>
            public const int FirstGeneratedOEInvoiceNumbe = 8;

            /// <summary>
            /// Property Indexer for LastGeneratedOEInvoiceNumber
            /// </summary>
            public const int LastGeneratedOEInvoiceNumber = 9;

            /// <summary>
            /// Property Indexer for FirstGeneratedARBatchNumber
            /// </summary>
            public const int FirstGeneratedARBatchNumber = 10;

            /// <summary>
            /// Property Indexer for LastGeneratedARBatchNumber
            /// </summary>
            public const int LastGeneratedARBatchNumber = 11;

            /// <summary>
            /// Property Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 40;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 41;

            /// <summary>
            /// Property Indexer for TRANIDCAP, generated capture guid for oepauth
            /// </summary>
            public const int TranIdCap = 42;

        }

        #endregion

    }
}