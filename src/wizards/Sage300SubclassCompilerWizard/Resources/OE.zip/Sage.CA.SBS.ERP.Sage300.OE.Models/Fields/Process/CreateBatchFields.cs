// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.
// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Process
{
     /// <summary>
     /// Partial class for list of CreateBatch Constants
     /// </summary>
     public partial class CreateBatch
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "OE0271";

          #region Fields

          /// <summary>
          /// Class for Create Batch Fields.
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for CreateGLBatchUptoSequence
               /// </summary>
               public const string CreateGLBatchUptoSequence = "SEQEND";

               /// <summary>
               /// Property for TransactionsCreated
               /// </summary>
               public const string TransactionsCreated = "TRANSCREAT";

               /// <summary>
               /// Property for PostGLBatch
               /// </summary>
               public const string PostGLBatch = "POSTGLBTCH";

               /// <summary>
               /// Property for PostARBatch
               /// </summary>
               public const string PostARBatch = "POSTARBTCH";
          }

          #endregion

          #region Index

          /// <summary>
          /// Class for Create Batch Index.
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for CreateGLBatchUptoSequence
               /// </summary>
               public const int CreateGLBatchUptoSequence = 1;

               /// <summary>
               /// Property Indexer for TransactionsCreated
               /// </summary>
               public const int TransactionsCreated = 2;

               /// <summary>
               /// Property Indexer for PostGLBatch
               /// </summary>
               public const int PostGLBatch = 3;

               /// <summary>
               /// Property Indexer for PostARBatch
               /// </summary>
               public const int PostARBatch = 4;
          }

          #endregion
     }
}
