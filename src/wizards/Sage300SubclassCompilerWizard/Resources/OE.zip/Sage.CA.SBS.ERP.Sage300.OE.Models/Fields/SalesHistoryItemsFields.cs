﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of SalesHistoryDetailItem Constants
    /// </summary>
    public partial class SalesHistory
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0690";

        #region Properties
        /// <summary>
        /// Contains list of SalesHistory Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTOMER";

            /// <summary>
            /// Property for UnformattedItemNumber
            /// </summary>
            public const string UnformattedItemNumber = "ITEM";

            /// <summary>
            /// Property for Year
            /// </summary>
            public const string Year = "YR";

            /// <summary>
            /// Property for Period
            /// </summary>
            public const string Period = "PERIOD";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "SCURN";

            /// <summary>
            /// Property for QuantitySold
            /// </summary>
            public const string QuantitySold = "QTYSOLD";

            /// <summary>
            /// Property for FuncSalesAmount
            /// </summary>
            public const string FuncSalesAmount = "FTOTSALES";

            /// <summary>
            /// Property for SrceSalesAmount
            /// </summary>
            public const string SrceSalesAmount = "STOTSALES";

            /// <summary>
            /// Property for FuncCostOfSales
            /// </summary>
            public const string FuncCostOfSales = "FCSTSALES";

            /// <summary>
            /// Property for SrceCostOfSales
            /// </summary>
            public const string SrceCostOfSales = "SCSTSALES";

            /// <summary>
            /// Property for SalesCount
            /// </summary>
            public const string SalesCount = "SALESCNT";

            /// <summary>
            /// Property for ReturnsCount
            /// </summary>
            public const string ReturnsCount = "RETCNT";

            /// <summary>
            /// Property for FuncReturnAmount
            /// </summary>
            public const string FuncReturnAmount = "FRETSALES";

            /// <summary>
            /// Property for SrceReturnAmount
            /// </summary>
            public const string SrceReturnAmount = "SRETSALES";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "CUSTDESC";

            /// <summary>
            /// Property for FuncProfitMargin
            /// </summary>
            public const string FuncProfitMargin = "MARGINF";

            /// <summary>
            /// Property for SrceProfitMargin
            /// </summary>
            public const string SrceProfitMargin = "MARGINS";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMFMT";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of SalesHistory Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for UnformattedItemNumber
            /// </summary>
            public const int UnformattedItemNumber = 2;

            /// <summary>
            /// Property Indexer for Year
            /// </summary>
            public const int Year = 3;

            /// <summary>
            /// Property Indexer for Period
            /// </summary>
            public const int Period = 4;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 5;

            /// <summary>
            /// Property Indexer for QuantitySold
            /// </summary>
            public const int QuantitySold = 6;

            /// <summary>
            /// Property Indexer for FuncSalesAmount
            /// </summary>
            public const int FuncSalesAmount = 7;

            /// <summary>
            /// Property Indexer for SrceSalesAmount
            /// </summary>
            public const int SrceSalesAmount = 8;

            /// <summary>
            /// Property Indexer for FuncCostOfSales
            /// </summary>
            public const int FuncCostOfSales = 9;

            /// <summary>
            /// Property Indexer for SrceCostOfSales
            /// </summary>
            public const int SrceCostOfSales = 10;

            /// <summary>
            /// Property Indexer for SalesCount
            /// </summary>
            public const int SalesCount = 11;

            /// <summary>
            /// Property Indexer for ReturnsCount
            /// </summary>
            public const int ReturnsCount = 12;

            /// <summary>
            /// Property Indexer for FuncReturnAmount
            /// </summary>
            public const int FuncReturnAmount = 13;

            /// <summary>
            /// Property Indexer for SrceReturnAmount
            /// </summary>
            public const int SrceReturnAmount = 14;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 50;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 51;

            /// <summary>
            /// Property Indexer for FuncProfitMargin
            /// </summary>
            public const int FuncProfitMargin = 52;

            /// <summary>
            /// Property Indexer for SrceProfitMargin
            /// </summary>
            public const int SrceProfitMargin = 53;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 54;

        }
        #endregion

    }
}
