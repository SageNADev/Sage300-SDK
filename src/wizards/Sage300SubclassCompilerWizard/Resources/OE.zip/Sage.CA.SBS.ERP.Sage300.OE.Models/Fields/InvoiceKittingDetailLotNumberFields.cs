// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of InvoiceKittingDetailLotNumber Constants
	/// </summary>
	public partial class InvoiceKittingDetailLotNumber
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0405";

		#region Properties

		/// <summary>
		/// Contains list of InvoiceKittingDetailLotNumbe Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for InvoiceUniquifier
			/// </summary>
			public const string InvoiceUniquifier = "INVUNIQ";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "LINENUM";

			/// <summary>
			/// Property for ParentComponentNumber
			/// </summary>
			public const string ParentComponentNumber = "PRNCOMPNUM";

			/// <summary>
			/// Property for ComponentNumber
			/// </summary>
			public const string ComponentNumber = "COMPNUM";

			/// <summary>
			/// Property for LotNumber
			/// </summary>
			public const string LotNumber = "LOTNUMF";

			/// <summary>
			/// Property for DetailNumber
			/// </summary>
			public const string DetailNumber = "DETAILNUM";

			/// <summary>
			/// Property for ExpirationDate
			/// </summary>
			public const string ExpirationDate = "EXPIRYDATE";

			/// <summary>
			/// Property for QuantityInStockingUOM
			/// </summary>
			public const string QuantityInStockingUOM = "STKQTY";

			/// <summary>
			/// Property for TransactionQuantity
			/// </summary>
			public const string TransactionQuantity = "QTY";

			/// <summary>
			/// Property for Cost
			/// </summary>
			public const string Cost = "COST";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of InvoiceKittingDetailLotNumbe Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for InvoiceUniquifier
			/// </summary>
			public const int InvoiceUniquifier = 1;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 2;

			/// <summary>
			/// Property Indexer for ParentComponentNumber
			/// </summary>
			public const int ParentComponentNumber = 3;

			/// <summary>
			/// Property Indexer for ComponentNumber
			/// </summary>
			public const int ComponentNumber = 4;

			/// <summary>
			/// Property Indexer for LotNumber
			/// </summary>
			public const int LotNumber = 5;

			/// <summary>
			/// Property Indexer for DetailNumber
			/// </summary>
			public const int DetailNumber = 6;

			/// <summary>
			/// Property Indexer for ExpirationDate
			/// </summary>
			public const int ExpirationDate = 7;

			/// <summary>
			/// Property Indexer for QuantityInStockingUOM
			/// </summary>
			public const int QuantityInStockingUOM = 8;

			/// <summary>
			/// Property Indexer for TransactionQuantity
			/// </summary>
			public const int TransactionQuantity = 9;

			/// <summary>
			/// Property Indexer for Cost
			/// </summary>
			public const int Cost = 10;

		}

		#endregion

	}
}
