// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of OrderPrepayment Constants
	/// </summary>
	public partial class OrderPrepayment
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "OE0530";

		#region Properties

		/// <summary>
		/// Contains list of OrderPrepayment Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for OrderUniquifier
			/// </summary>
			public const string OrderUniquifier = "ORDUNIQ";

			/// <summary>
			/// Property for CustomerNumber
			/// </summary>
			public const string CustomerNumber = "CUSTOMER";

			/// <summary>
			/// Property for CustomerName
			/// </summary>
			public const string CustomerName = "CUSTDESC";

			/// <summary>
			/// Property for CustomerCurrency
			/// </summary>
			public const string CustomerCurrency = "CUSTCURN";

			/// <summary>
			/// Property for CustRate
			/// </summary>
			public const string CustRate = "CRATE";

			/// <summary>
			/// Property for CustRateDate
			/// </summary>
			public const string CustRateDate = "CRATEDATE";

			/// <summary>
			/// Property for CustRateType
			/// </summary>
			public const string CustRateType = "CRATETYPE";

			/// <summary>
			/// Property for OperCustCurnToFunc
			/// </summary>
			public const string OperCustCurnToFunc = "CRATEOPER";

			/// <summary>
			/// Property for DocumentTotal
			/// </summary>
			public const string DocumentTotal = "DOCTOTAL";

			/// <summary>
			/// Property for DiscountAvailable
			/// </summary>
			public const string DiscountAvailable = "DISCAVAIL";

			/// <summary>
			/// Property for AmountDue
			/// </summary>
			public const string AmountDue = "AMOUNTDUE";

			/// <summary>
			/// Property for ReceiptBatchNumber
			/// </summary>
			public const string ReceiptBatchNumber = "BATCHNUM";

			/// <summary>
			/// Property for BankCode
			/// </summary>
			public const string BankCode = "BANKCODE";

			/// <summary>
			/// Property for ReceiptType
			/// </summary>
			public const string ReceiptType = "RECPTYPE";

			/// <summary>
			/// Property for CheckReceiptNo
			/// </summary>
			public const string CheckReceiptNo = "CHECKNUM";

			/// <summary>
			/// Property for ReceiptDate
			/// </summary>
			public const string ReceiptDate = "RECPDATE";

			/// <summary>
			/// Property for ReceiptAmount
			/// </summary>
			public const string ReceiptAmount = "RECPAMOUNT";

			/// <summary>
			/// Property for BankCurrency
			/// </summary>
			public const string BankCurrency = "BANKCURN";

			/// <summary>
			/// Property for RateType
			/// </summary>
			public const string RateType = "RATETYPE";

			/// <summary>
			/// Property for BankRate
			/// </summary>
			public const string BankRate = "BANKRATE";

			/// <summary>
			/// Property for RateDate
			/// </summary>
			public const string RateDate = "RATEDATE";

			/// <summary>
			/// Property for BatchDescription
			/// </summary>
			public const string BatchDescription = "BATCHDESC";

			/// <summary>
			/// Property for ReceiptDescription
			/// </summary>
			public const string ReceiptDescription = "RECPDESC";

			/// <summary>
			/// Property for BankRateSpread
			/// </summary>
			public const string BankRateSpread = "BANKSPREAD";

			/// <summary>
			/// Property for PrepaymentID
			/// </summary>
			public const string PrepaymentID = "IDPPD";

			/// <summary>
			/// Property for PaymentType
			/// </summary>
			public const string PaymentType = "PAYMTYPE";

			/// <summary>
			/// Property for PreauthCurrency
			/// </summary>
			public const string PreauthCurrency = "PAUTHCURR";

			/// <summary>
			/// Property for PreauthTransactionID
			/// </summary>
			public const string PreauthTransactionID = "TRANIDPRE";

			/// <summary>
			/// Property for CaptureTransactionID
			/// </summary>
			public const string CaptureTransactionID = "TRANIDCAP";

			/// <summary>
			/// Property for VoidTransactionID
			/// </summary>
			public const string VoidTransactionID = "TRANIDVOID";

			/// <summary>
			/// Property for PreauthAmount
			/// </summary>
			public const string PreauthAmount = "PAUTHAMT";

			/// <summary>
			/// Property for CreditCardChargeStatus
			/// </summary>
			public const string CreditCardChargeStatus = "CHARGESTTS";

			/// <summary>
			/// Property for YPProcessCode
			/// </summary>
			public const string YpProcessCode = "YPPROCCODE";

			/// <summary>
			/// Property for CapturePreauthorization
			/// </summary>
			public const string CapturePreauthorization = "CPTPREAUTH";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of OrderPrepayment Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for OrderUniquifier
			/// </summary>
			public const int OrderUniquifier = 1;

			/// <summary>
			/// Property Indexer for CustomerNumber
			/// </summary>
			public const int CustomerNumber = 2;

			/// <summary>
			/// Property Indexer for CustomerName
			/// </summary>
			public const int CustomerName = 3;

			/// <summary>
			/// Property Indexer for CustomerCurrency
			/// </summary>
			public const int CustomerCurrency = 4;

			/// <summary>
			/// Property Indexer for CustRate
			/// </summary>
			public const int CustRate = 5;

			/// <summary>
			/// Property Indexer for CustRateDate
			/// </summary>
			public const int CustRateDate = 6;

			/// <summary>
			/// Property Indexer for CustRateType
			/// </summary>
			public const int CustRateType = 7;

			/// <summary>
			/// Property Indexer for OperCustCurnToFunc
			/// </summary>
			public const int OperCustCurnToFunc = 8;

			/// <summary>
			/// Property Indexer for DocumentTotal
			/// </summary>
			public const int DocumentTotal = 9;

			/// <summary>
			/// Property Indexer for DiscountAvailable
			/// </summary>
			public const int DiscountAvailable = 10;

			/// <summary>
			/// Property Indexer for AmountDue
			/// </summary>
			public const int AmountDue = 11;

			/// <summary>
			/// Property Indexer for ReceiptBatchNumber
			/// </summary>
			public const int ReceiptBatchNumber = 12;

			/// <summary>
			/// Property Indexer for BankCode
			/// </summary>
			public const int BankCode = 13;

			/// <summary>
			/// Property Indexer for ReceiptType
			/// </summary>
			public const int ReceiptType = 14;

			/// <summary>
			/// Property Indexer for CheckReceiptNo
			/// </summary>
			public const int CheckReceiptNo = 15;

			/// <summary>
			/// Property Indexer for ReceiptDate
			/// </summary>
			public const int ReceiptDate = 16;

			/// <summary>
			/// Property Indexer for ReceiptAmount
			/// </summary>
			public const int ReceiptAmount = 17;

			/// <summary>
			/// Property Indexer for BankCurrency
			/// </summary>
			public const int BankCurrency = 18;

			/// <summary>
			/// Property Indexer for RateType
			/// </summary>
			public const int RateType = 19;

			/// <summary>
			/// Property Indexer for BankRate
			/// </summary>
			public const int BankRate = 20;

			/// <summary>
			/// Property Indexer for RateDate
			/// </summary>
			public const int RateDate = 21;

			/// <summary>
			/// Property Indexer for BatchDescription
			/// </summary>
			public const int BatchDescription = 22;

			/// <summary>
			/// Property Indexer for ReceiptDescription
			/// </summary>
			public const int ReceiptDescription = 23;

			/// <summary>
			/// Property Indexer for BankRateSpread
			/// </summary>
			public const int BankRateSpread = 24;

			/// <summary>
			/// Property Indexer for PrepaymentID
			/// </summary>
			public const int PrepaymentID = 25;

			/// <summary>
			/// Property Indexer for PaymentType
			/// </summary>
			public const int PaymentType = 26;

			/// <summary>
			/// Property Indexer for PreauthCurrency
			/// </summary>
			public const int PreauthCurrency = 34;

			/// <summary>
			/// Property Indexer for PreauthTransactionID
			/// </summary>
			public const int PreauthTransactionID = 35;

			/// <summary>
			/// Property Indexer for CaptureTransactionID
			/// </summary>
			public const int CaptureTransactionID = 36;

			/// <summary>
			/// Property Indexer for VoidTransactionID
			/// </summary>
			public const int VoidTransactionID = 37;

			/// <summary>
			/// Property Indexer for PreauthAmount
			/// </summary>
			public const int PreauthAmount = 38;

			/// <summary>
			/// Property Indexer for CreditCardChargeStatus
			/// </summary>
			public const int CreditCardChargeStatus = 39;

			/// <summary>
			/// Property Indexer for YPProcessCode
			/// </summary>
			public const int YpProcessCode = 40;

			/// <summary>
			/// Property Indexer for CapturePreauthorization
			/// </summary>
			public const int CapturePreauthorization = 41;

            /// <summary>
            /// Property Indexer for CapturePreauthorization
            /// </summary>
            public const int ProcessNow = 42;

            /// <summary>
            /// Property Indexer for the quick pre-auth/charge transaction ID
            /// </summary>
            public const int TransID = 43;

            /// <summary>
            /// Property Indexer for XML String for Quick Charge/Pre-Authorization
            /// </summary>
            public const int XmlString = 44;

            /// <summary>
            /// Property Indexer for Respond Indicator
            /// </summary>
            public const int ResponseIndicator = 45;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int ResponseCode = 46;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int ResponseMessage = 47;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int AuthorizationCode = 48;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int AVSResult = 49;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int CVVResult = 50;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int Transdate = 51;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int Vanref = 52;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int Last4 = 53;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int PmtDesc = 54;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int PmtTypeID = 55;
        }

		#endregion

	}
}
