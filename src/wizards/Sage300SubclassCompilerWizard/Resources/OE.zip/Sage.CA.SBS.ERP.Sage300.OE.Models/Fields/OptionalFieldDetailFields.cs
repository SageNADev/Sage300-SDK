// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of OptionalField Constants
     /// </summary>
    public partial class OptionalFieldDetail
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "OE0470";

          #region Properties
          /// <summary>
          /// Contains list of OptionalField Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for OptionalField
               /// </summary>
               public const string OptionalField = "OPTFIELD";

               /// <summary>
               /// Property for DefaultValue
               /// </summary>
               public const string DefaultValue = "DEFVAL";

               /// <summary>
               /// Property for Type
               /// </summary>
               public const string Type = "TYPE";

               /// <summary>
               /// Property for Length
               /// </summary>
               public const string Length = "LENGTH";

               /// <summary>
               /// Property for Decimals
               /// </summary>
               public const string Decimals = "DECIMALS";

               /// <summary>
               /// Property for AllowBlank
               /// </summary>
               public const string AllowBlank = "ALLOWNULL";

               /// <summary>
               /// Property for Validate
               /// </summary>
               public const string Validate = "VALIDATE";

               /// <summary>
               /// Property for AutoInsert
               /// </summary>
               public const string AutoInsert = "INITFLAG";

               /// <summary>
               /// Property for InventoryControl
               /// </summary>
               public const string InventoryControl = "SWICCTL";

               /// <summary>
               /// Property for ShipmentClearing
               /// </summary>
               public const string ShipmentClearing = "SWSHCLRSH";

               /// <summary>
               /// Property for NonstockClearing
               /// </summary>
               public const string NonstockClearing = "SWNSCLR";

               /// <summary>
               /// Property for CostVariance
               /// </summary>
               public const string CostVariance = "SWCV";

               /// <summary>
               /// Property for ARInvoicesOptionalFields
               /// </summary>
               public const string ARInvoicesOptionalFields = "SWARINV";

               /// <summary>
               /// Property for SalesShipmentClearingCOGS
               /// </summary>
               public const string SalesShipmentClearingCOGS = "SWSALES";

               /// <summary>
               /// Property for MiscellaneousCharges
               /// </summary>
               public const string MiscellaneousCharges = "SWMISC";

               /// <summary>
               /// Property for Returns
               /// </summary>
               public const string Returns = "SWRETURN";

               /// <summary>
               /// Property for DamagedGoods
               /// </summary>
               public const string DamagedGoods = "SWDAMAGE";

               /// <summary>
               /// Property for Required
               /// </summary>
               public const string Required = "SWREQUIRED";

               /// <summary>
               /// Property for ValueSet
               /// </summary>
               public const string ValueSet = "SWSET";

               /// <summary>
               /// Property for ExternalCostTransactions
               /// </summary>
               public const string ExternalCostTransactions = "SWPM";

               /// <summary>
               /// Property for Labor
               /// </summary>
               public const string Labor = "SWPMLABOR";

               /// <summary>
               /// Property for Overhead
               /// </summary>
               public const string Overhead = "SWPMOH";

               /// <summary>
               /// Property for CreditDebitNoteClearing
               /// </summary>
               public const string CreditDebitNoteClearing = "SWCNDNCLR";

               /// <summary>
               /// Property for TypedDefaultValueFieldIndex
               /// </summary>
               public const string TypedDefaultValueFieldIndex = "DVINDEX";

               /// <summary>
               /// Property for DefaultTextValue
               /// </summary>
               public const string DefaultTextValue = "DVIFTEXT";

               /// <summary>
               /// Property for DefaultMoneyValue
               /// </summary>
               public const string DefaultAmountValue = "DVIFMONEY";

               /// <summary>
               /// Property for DefaultNumberValue
               /// </summary>
               public const string DefaultNumberValue = "DVIFNUM";

               /// <summary>
               /// Property for DefaultIntegerValue
               /// </summary>
               public const string DefaultIntegerValue = "DVIFLONG";

               /// <summary>
               /// Property for DefaultYesNoValue
               /// </summary>
               public const string DefaultYesNoValue = "DVIFBOOL";

               /// <summary>
               /// Property for DefaultDateValue
               /// </summary>
               public const string DefaultDateValue = "DVIFDATE";

               /// <summary>
               /// Property for DefaultTimeValue
               /// </summary>
               public const string DefaultTimeValue = "DVIFTIME";

               /// <summary>
               /// Property for OptionalFieldDescription
               /// </summary>
               public const string OptionalFieldDescription = "FDESC";

               /// <summary>
               /// Property for DefaultValueDescription
               /// </summary>
               public const string DefaultValueDescription = "VDESC";

          }

          #endregion

          #region Properties

          /// <summary>
          /// Contains list of OptionalField Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 1;

               /// <summary>
               /// Property Indexer for OptionalField
               /// </summary>
               public const int OptionalField = 2;

               /// <summary>
               /// Property Indexer for DefaultValue
               /// </summary>
               public const int DefaultValue = 3;

               /// <summary>
               /// Property Indexer for Type
               /// </summary>
               public const int Type = 4;

               /// <summary>
               /// Property Indexer for Length
               /// </summary>
               public const int Length = 5;

               /// <summary>
               /// Property Indexer for Decimals
               /// </summary>
               public const int Decimals = 6;

               /// <summary>
               /// Property Indexer for AllowBlank
               /// </summary>
               public const int AllowBlank = 7;

               /// <summary>
               /// Property Indexer for Validate
               /// </summary>
               public const int Validate = 8;

               /// <summary>
               /// Property Indexer for AutoInsert
               /// </summary>
               public const int AutoInsert = 9;

               /// <summary>
               /// Property Indexer for InventoryControl
               /// </summary>
               public const int InventoryControl = 10;

               /// <summary>
               /// Property Indexer for ShipmentClearing
               /// </summary>
               public const int ShipmentClearing = 11;

               /// <summary>
               /// Property Indexer for NonstockClearing
               /// </summary>
               public const int NonstockClearing = 12;

               /// <summary>
               /// Property Indexer for CostVariance
               /// </summary>
               public const int CostVariance = 13;

               /// <summary>
               /// Property Indexer for ARInvoicesOptionalFields
               /// </summary>
               public const int ARInvoicesOptionalFields = 14;

               /// <summary>
               /// Property Indexer for SalesShipmentClearingCOGS
               /// </summary>
               public const int SalesShipmentClearingCOGS = 15;

               /// <summary>
               /// Property Indexer for MiscellaneousCharges
               /// </summary>
               public const int MiscellaneousCharges = 18;

               /// <summary>
               /// Property Indexer for Returns
               /// </summary>
               public const int Returns = 19;

               /// <summary>
               /// Property Indexer for DamagedGoods
               /// </summary>
               public const int DamagedGoods = 20;

               /// <summary>
               /// Property Indexer for Required
               /// </summary>
               public const int Required = 21;

               /// <summary>
               /// Property Indexer for ValueSet
               /// </summary>
               public const int ValueSet = 22;

               /// <summary>
               /// Property Indexer for ExternalCostTransactions
               /// </summary>
               public const int ExternalCostTransactions = 23;

               /// <summary>
               /// Property Indexer for Labor
               /// </summary>
               public const int Labor = 24;

               /// <summary>
               /// Property Indexer for Overhead
               /// </summary>
               public const int Overhead = 25;

               /// <summary>
               /// Property Indexer for CreditDebitNoteClearing
               /// </summary>
               public const int CreditDebitNoteClearing = 26;

               /// <summary>
               /// Property Indexer for TypedDefaultValueFieldIndex
               /// </summary>
               public const int TypedDefaultValueFieldIndex = 40;

               /// <summary>
               /// Property Indexer for DefaultTextValue
               /// </summary>
               public const int DefaultTextValue = 41;

               /// <summary>
               /// Property Indexer for DefaultMoneyValue
               /// </summary>
               public const int DefaultAmountValue = 42;

               /// <summary>
               /// Property Indexer for DefaultNumberValue
               /// </summary>
               public const int DefaultNumberValue = 43;

               /// <summary>
               /// Property Indexer for DefaultIntegerValue
               /// </summary>
               public const int DefaultIntegerValue = 44;

               /// <summary>
               /// Property Indexer for DefaultYesNoValue
               /// </summary>
               public const int DefaultYesNoValue = 45;

               /// <summary>
               /// Property Indexer for DefaultDateValue
               /// </summary>
               public const int DefaultDateValue = 46;

               /// <summary>
               /// Property Indexer for DefaultTimeValue
               /// </summary>
               public const int DefaultTimeValue = 47;

               /// <summary>
               /// Property Indexer for OptionalFieldDescription
               /// </summary>
               public const int OptionalFieldDescription = 48;

               /// <summary>
               /// Property Indexer for DefaultValueDescription
               /// </summary>
               public const int DefaultValueDescription = 49;
          }

          #endregion
     }
}
