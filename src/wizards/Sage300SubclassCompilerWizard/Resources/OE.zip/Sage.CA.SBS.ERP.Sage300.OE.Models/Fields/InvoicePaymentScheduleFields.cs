// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of InvoicePaymentSchedule Constants
	/// </summary>
	public partial class InvoicePaymentSchedule
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0720";

		#region Properties

		/// <summary>
		/// Contains list of InvoicePaymentSchedule Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for InvoiceUniquifier
			/// </summary>
			public const string InvoiceUniquifier = "INVUNIQ";

			/// <summary>
			/// Property for PaymentNumber
			/// </summary>
			public const string PaymentNumber = "PAYMENT";

			/// <summary>
			/// Property for DiscountBase
			/// </summary>
			public const string DiscountBase = "DISCBASE";

			/// <summary>
			/// Property for DiscountDate
			/// </summary>
			public const string DiscountDate = "DISCDATE";

			/// <summary>
			/// Property for DiscountPercentage
			/// </summary>
			public const string DiscountPercentage = "DISCPER";

			/// <summary>
			/// Property for DiscountAmount
			/// </summary>
			public const string DiscountAmount = "DISCAMT";

			/// <summary>
			/// Property for DueAmountBase
			/// </summary>
			public const string DueAmountBase = "DUEBASE";

			/// <summary>
			/// Property for DueDate
			/// </summary>
			public const string DueDate = "DUEDATE";

			/// <summary>
			/// Property for PercentageDue
			/// </summary>
			public const string PercentageDue = "DUEPER";

			/// <summary>
			/// Property for AmountDue
			/// </summary>
			public const string AmountDue = "DUEAMT";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of InvoicePaymentSchedule Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for InvoiceUniquifier
			/// </summary>
			public const int InvoiceUniquifier = 1;

			/// <summary>
			/// Property Indexer for PaymentNumber
			/// </summary>
			public const int PaymentNumber = 2;

			/// <summary>
			/// Property Indexer for DiscountBase
			/// </summary>
			public const int DiscountBase = 3;

			/// <summary>
			/// Property Indexer for DiscountDate
			/// </summary>
			public const int DiscountDate = 4;

			/// <summary>
			/// Property Indexer for DiscountPercentage
			/// </summary>
			public const int DiscountPercentage = 5;

			/// <summary>
			/// Property Indexer for DiscountAmount
			/// </summary>
			public const int DiscountAmount = 6;

			/// <summary>
			/// Property Indexer for DueAmountBase
			/// </summary>
			public const int DueAmountBase = 7;

			/// <summary>
			/// Property Indexer for DueDate
			/// </summary>
			public const int DueDate = 8;

			/// <summary>
			/// Property Indexer for PercentageDue
			/// </summary>
			public const int PercentageDue = 9;

			/// <summary>
			/// Property Indexer for AmountDue
			/// </summary>
			public const int AmountDue = 10;

		}

		#endregion

	}
}
