// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of SalesStatistic Constants
	/// </summary>
	public partial class SalesStatistic
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0700";

		#region Properties

		/// <summary>
		/// Contains list of SalesStatistic Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Year
			/// </summary>
			public const string Year = "YR";

			/// <summary>
			/// Property for Period
			/// </summary>
			public const string Period = "PERIOD";

			/// <summary>
			/// Property for Currency
			/// </summary>
			public const string Currency = "CURRENCY";

			/// <summary>
			/// Property for NumberOfOrders
			/// </summary>
			public const string NumberOfOrders = "NUMORD";

			/// <summary>
			/// Property for NetQuantitySold
			/// </summary>
			public const string NetQuantitySold = "QTYSOLD";

			/// <summary>
			/// Property for NetSalesAmountFunc
			/// </summary>
			public const string NetSalesAmountFunc = "SALESAMTF";

			/// <summary>
			/// Property for NetSalesAmountSrce
			/// </summary>
			public const string NetSalesAmountSrce = "SALESAMTS";

			/// <summary>
			/// Property for NetInvoiceAmountFunc
			/// </summary>
			public const string NetInvoiceAmountFunc = "INVAMTF";

			/// <summary>
			/// Property for NetInvoiceAmountSrce
			/// </summary>
			public const string NetInvoiceAmountSrce = "INVAMTS";

			/// <summary>
			/// Property for CostOfSalesFunc
			/// </summary>
			public const string CostOfSalesFunc = "COGSF";

			/// <summary>
			/// Property for CostOfSalesSrce
			/// </summary>
			public const string CostOfSalesSrce = "COGSS";

			/// <summary>
			/// Property for NumberOfInvoices
			/// </summary>
			public const string NumberOfInvoices = "INVCOUNT";

			/// <summary>
			/// Property for AverageInvoiceFunc
			/// </summary>
			public const string AverageInvoiceFunc = "AVGINVF";

			/// <summary>
			/// Property for AverageInvoiceSrce
			/// </summary>
			public const string AverageInvoiceSrce = "AVGINVS";

			/// <summary>
			/// Property for LargestInvoiceFunc
			/// </summary>
			public const string LargestInvoiceFunc = "LARGSTINF";

			/// <summary>
			/// Property for LargestInvoiceSrce
			/// </summary>
			public const string LargestInvoiceSrce = "LARGSTINS";

			/// <summary>
			/// Property for CustomerLargestInvoice
			/// </summary>
			public const string CustomerLargestInvoice = "LINVCUST";

			/// <summary>
			/// Property for SmallestInvoiceFunc
			/// </summary>
			public const string SmallestInvoiceFunc = "SMALSTINF";

			/// <summary>
			/// Property for SmallestInvoiceSrce
			/// </summary>
			public const string SmallestInvoiceSrce = "SMALSTINS";

			/// <summary>
			/// Property for CustomerSmallestInvoice
			/// </summary>
			public const string CustomerSmallestInvoice = "SINVCUST";

			/// <summary>
			/// Property for NumberOfCreditNotes
			/// </summary>
			public const string NumberOfCreditNotes = "CNCOUNT";

			/// <summary>
			/// Property for AverageCreditNoteFunc
			/// </summary>
			public const string AverageCreditNoteFunc = "AVGCNF";

			/// <summary>
			/// Property for AverageCreditNoteSrce
			/// </summary>
			public const string AverageCreditNoteSrce = "AVGCNS";

			/// <summary>
			/// Property for LargestCreditNoteFunc
			/// </summary>
			public const string LargestCreditNoteFunc = "LARGSTCNF";

			/// <summary>
			/// Property for LargestCreditNoteSrce
			/// </summary>
			public const string LargestCreditNoteSrce = "LARGSTCNS";

			/// <summary>
			/// Property for CustomerLargestCreditNote
			/// </summary>
			public const string CustomerLargestCreditNote = "LCNCUST";

			/// <summary>
			/// Property for SmallestCreditNoteFunc
			/// </summary>
			public const string SmallestCreditNoteFunc = "SMALSTCNF";

			/// <summary>
			/// Property for SmallestCreditNoteSrce
			/// </summary>
			public const string SmallestCreditNoteSrce = "SMALSTCNS";

			/// <summary>
			/// Property for TotalSalesLostFunc
			/// </summary>
			public const string TotalSalesLostFunc = "TSLELOSTF";

			/// <summary>
			/// Property for TotalSalesLostSrce
			/// </summary>
			public const string TotalSalesLostSrce = "TSLELOSTS";

			/// <summary>
			/// Property for CustomerSmallestCreditNote
			/// </summary>
			public const string CustomerSmallestCreditNote = "SCNCUST";

			/// <summary>
			/// Property for MarginSrce
			/// </summary>
			public const string MarginSrce = "MARGINS";

			/// <summary>
			/// Property for MarginFunc
			/// </summary>
			public const string MarginFunc = "MARGINF";

			/// <summary>
			/// Property for AverageSalesLostSrce
			/// </summary>
			public const string AverageSalesLostSrce = "ASLELOSTS";

			/// <summary>
			/// Property for AverageSalesLostFunc
			/// </summary>
			public const string AverageSalesLostFunc = "ASLELOSTF";

			/// <summary>
			/// Property for NumberOfDebitNotes
			/// </summary>
			public const string NumberOfDebitNotes = "DNCOUNT";

			/// <summary>
			/// Property for AverageDebitNoteFunc
			/// </summary>
			public const string AverageDebitNoteFunc = "AVGDNF";

			/// <summary>
			/// Property for AverageDebitNoteSrce
			/// </summary>
			public const string AverageDebitNoteSrce = "AVGDNS";

			/// <summary>
			/// Property for LargestDebitNoteFunc
			/// </summary>
			public const string LargestDebitNoteFunc = "LARGSTDNF";

			/// <summary>
			/// Property for LargestDebitNoteSrce
			/// </summary>
			public const string LargestDebitNoteSrce = "LARGSTDNS";

			/// <summary>
			/// Property for CustomerLargestDebitNote
			/// </summary>
			public const string CustomerLargestDebitNote = "LDNCUST";

			/// <summary>
			/// Property for SmallestDebitNoteFunc
			/// </summary>
			public const string SmallestDebitNoteFunc = "SMALSTDNF";

			/// <summary>
			/// Property for SmallestDebitNoteSrce
			/// </summary>
			public const string SmallestDebitNoteSrce = "SMALSTDNS";

			/// <summary>
			/// Property for CustomerSmallestDebitNote
			/// </summary>
			public const string CustomerSmallestDebitNote = "SDNCUST";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of SalesStatistic Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Year
			/// </summary>
			public const int Year = 1;

			/// <summary>
			/// Property Indexer for Period
			/// </summary>
			public const int Period = 2;

			/// <summary>
			/// Property Indexer for Currency
			/// </summary>
			public const int Currency = 3;

			/// <summary>
			/// Property Indexer for NumberOfOrders
			/// </summary>
			public const int NumberOfOrders = 4;

			/// <summary>
			/// Property Indexer for NetQuantitySold
			/// </summary>
			public const int NetQuantitySold = 5;

			/// <summary>
			/// Property Indexer for NetSalesAmountFunc
			/// </summary>
			public const int NetSalesAmountFunc = 6;

			/// <summary>
			/// Property Indexer for NetSalesAmountSrce
			/// </summary>
			public const int NetSalesAmountSrce = 7;

			/// <summary>
			/// Property Indexer for NetInvoiceAmountFunc
			/// </summary>
			public const int NetInvoiceAmountFunc = 8;

			/// <summary>
			/// Property Indexer for NetInvoiceAmountSrce
			/// </summary>
			public const int NetInvoiceAmountSrce = 9;

			/// <summary>
			/// Property Indexer for CostOfSalesFunc
			/// </summary>
			public const int CostOfSalesFunc = 10;

			/// <summary>
			/// Property Indexer for CostOfSalesSrce
			/// </summary>
			public const int CostOfSalesSrce = 11;

			/// <summary>
			/// Property Indexer for NumberOfInvoices
			/// </summary>
			public const int NumberOfInvoices = 12;

			/// <summary>
			/// Property Indexer for AverageInvoiceFunc
			/// </summary>
			public const int AverageInvoiceFunc = 13;

			/// <summary>
			/// Property Indexer for AverageInvoiceSrce
			/// </summary>
			public const int AverageInvoiceSrce = 14;

			/// <summary>
			/// Property Indexer for LargestInvoiceFunc
			/// </summary>
			public const int LargestInvoiceFunc = 15;

			/// <summary>
			/// Property Indexer for LargestInvoiceSrce
			/// </summary>
			public const int LargestInvoiceSrce = 16;

			/// <summary>
			/// Property Indexer for CustomerLargestInvoice
			/// </summary>
			public const int CustomerLargestInvoice = 17;

			/// <summary>
			/// Property Indexer for SmallestInvoiceFunc
			/// </summary>
			public const int SmallestInvoiceFunc = 18;

			/// <summary>
			/// Property Indexer for SmallestInvoiceSrce
			/// </summary>
			public const int SmallestInvoiceSrce = 19;

			/// <summary>
			/// Property Indexer for CustomerSmallestInvoice
			/// </summary>
			public const int CustomerSmallestInvoice = 20;

			/// <summary>
			/// Property Indexer for NumberOfCreditNotes
			/// </summary>
			public const int NumberOfCreditNotes = 21;

			/// <summary>
			/// Property Indexer for AverageCreditNoteFunc
			/// </summary>
			public const int AverageCreditNoteFunc = 22;

			/// <summary>
			/// Property Indexer for AverageCreditNoteSrce
			/// </summary>
			public const int AverageCreditNoteSrce = 23;

			/// <summary>
			/// Property Indexer for LargestCreditNoteFunc
			/// </summary>
			public const int LargestCreditNoteFunc = 24;

			/// <summary>
			/// Property Indexer for LargestCreditNoteSrce
			/// </summary>
			public const int LargestCreditNoteSrce = 25;

			/// <summary>
			/// Property Indexer for CustomerLargestCreditNote
			/// </summary>
			public const int CustomerLargestCreditNote = 26;

			/// <summary>
			/// Property Indexer for SmallestCreditNoteFunc
			/// </summary>
			public const int SmallestCreditNoteFunc = 27;

			/// <summary>
			/// Property Indexer for SmallestCreditNoteSrce
			/// </summary>
			public const int SmallestCreditNoteSrce = 28;

			/// <summary>
			/// Property Indexer for TotalSalesLostFunc
			/// </summary>
			public const int TotalSalesLostFunc = 29;

			/// <summary>
			/// Property Indexer for TotalSalesLostSrce
			/// </summary>
			public const int TotalSalesLostSrce = 30;

			/// <summary>
			/// Property Indexer for CustomerSmallestCreditNote
			/// </summary>
			public const int CustomerSmallestCreditNote = 31;

			/// <summary>
			/// Property Indexer for MarginSrce
			/// </summary>
			public const int MarginSrce = 32;

			/// <summary>
			/// Property Indexer for MarginFunc
			/// </summary>
			public const int MarginFunc = 33;

			/// <summary>
			/// Property Indexer for AverageSalesLostSrce
			/// </summary>
			public const int AverageSalesLostSrce = 34;

			/// <summary>
			/// Property Indexer for AverageSalesLostFunc
			/// </summary>
			public const int AverageSalesLostFunc = 35;

			/// <summary>
			/// Property Indexer for NumberOfDebitNotes
			/// </summary>
			public const int NumberOfDebitNotes = 36;

			/// <summary>
			/// Property Indexer for AverageDebitNoteFunc
			/// </summary>
			public const int AverageDebitNoteFunc = 37;

			/// <summary>
			/// Property Indexer for AverageDebitNoteSrce
			/// </summary>
			public const int AverageDebitNoteSrce = 38;

			/// <summary>
			/// Property Indexer for LargestDebitNoteFunc
			/// </summary>
			public const int LargestDebitNoteFunc = 39;

			/// <summary>
			/// Property Indexer for LargestDebitNoteSrce
			/// </summary>
			public const int LargestDebitNoteSrce = 40;

			/// <summary>
			/// Property Indexer for CustomerLargestDebitNote
			/// </summary>
			public const int CustomerLargestDebitNote = 41;

			/// <summary>
			/// Property Indexer for SmallestDebitNoteFunc
			/// </summary>
			public const int SmallestDebitNoteFunc = 42;

			/// <summary>
			/// Property Indexer for SmallestDebitNoteSrce
			/// </summary>
			public const int SmallestDebitNoteSrce = 43;

			/// <summary>
			/// Property Indexer for CustomerSmallestDebitNote
			/// </summary>
			public const int CustomerSmallestDebitNote = 44;

		}

		#endregion

	}
}
