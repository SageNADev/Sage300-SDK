// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of EmailMessage Constants
	/// </summary>
	public partial class EmailMessage
	{
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0465";

		#region Properties

		/// <summary>
		/// Contains list of EmailMessage Field Constants
		/// </summary>
		public class Fields
		{
			/// <summary>
			/// Property for MessageType
			/// </summary>
			public const string MessageType = "MSGTYPE";

            /// <summary>
            /// Property for MessageType 
            /// </summary>
            public const string MessageTypeString = "MSGTYPE";

			/// <summary>
			/// Property for MessageID
			/// </summary>
			public const string MessageID = "MSGID";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "TEXTDESC";

			/// <summary>
			/// Property for Status
			/// </summary>
			public const string Status = "ACTIVESW";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string StatusString = "ACTIVESW";

			/// <summary>
			/// Property for InactiveDate
			/// </summary>
			public const string InactiveDate = "DATEINAC";

			/// <summary>
			/// Property for DateLastMaintained
			/// </summary>
			public const string DateLastMaintained = "DTELSTMNTN";

			/// <summary>
			/// Property for EmailSubject
			/// </summary>
			public const string EmailSubject = "SUBJECT";

			/// <summary>
			/// Property for EmailBodyText1Of10
			/// </summary>
			public const string EmailBodyText1Of10 = "BODY1";

			/// <summary>
			/// Property for EmailBodyText2Of10
			/// </summary>
			public const string EmailBodyText2Of10 = "BODY2";

			/// <summary>
			/// Property for EmailBodyText3Of10
			/// </summary>
			public const string EmailBodyText3Of10 = "BODY3";

			/// <summary>
			/// Property for EmailBodyText4Of10
			/// </summary>
			public const string EmailBodyText4Of10 = "BODY4";

			/// <summary>
			/// Property for EmailBodyText5Of10
			/// </summary>
			public const string EmailBodyText5Of10 = "BODY5";

			/// <summary>
			/// Property for EmailBodyText6Of10
			/// </summary>
			public const string EmailBodyText6Of10 = "BODY6";

			/// <summary>
			/// Property for EmailBodyText7Of10
			/// </summary>
			public const string EmailBodyText7Of10 = "BODY7";

			/// <summary>
			/// Property for EmailBodyText8Of10
			/// </summary>
			public const string EmailBodyText8Of10 = "BODY8";

			/// <summary>
			/// Property for EmailBodyText9Of10
			/// </summary>
			public const string EmailBodyText9Of10 = "BODY9";

			/// <summary>
			/// Property for EmailBodyText10Of10
			/// </summary>
			public const string EmailBodyText10Of10 = "BODY10";

			/// <summary>
			/// Property for EmailBody
			/// </summary>
			public const string EmailBody = "BODY";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of EmailMessage Index Constants
		/// </summary>
		public class Index
		{
			/// <summary>
			/// Property Indexer for MessageType
			/// </summary>
			public const int MessageType = 1;

			/// <summary>
			/// Property Indexer for MessageID
			/// </summary>
			public const int MessageID = 2;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 3;

			/// <summary>
			/// Property Indexer for Status
			/// </summary>
			public const int Status = 4;

			/// <summary>
			/// Property Indexer for InactiveDate
			/// </summary>
			public const int InactiveDate = 5;

			/// <summary>
			/// Property Indexer for DateLastMaintained
			/// </summary>
			public const int DateLastMaintained = 6;

			/// <summary>
			/// Property Indexer for EmailSubject
			/// </summary>
			public const int EmailSubject = 7;

			/// <summary>
			/// Property Indexer for EmailBodyText1Of10
			/// </summary>
			public const int EmailBodyText1Of10 = 8;

			/// <summary>
			/// Property Indexer for EmailBodyText2Of10
			/// </summary>
			public const int EmailBodyText2Of10 = 9;

			/// <summary>
			/// Property Indexer for EmailBodyText3Of10
			/// </summary>
			public const int EmailBodyText3Of10 = 10;

			/// <summary>
			/// Property Indexer for EmailBodyText4Of10
			/// </summary>
			public const int EmailBodyText4Of10 = 11;

			/// <summary>
			/// Property Indexer for EmailBodyText5Of10
			/// </summary>
			public const int EmailBodyText5Of10 = 12;

			/// <summary>
			/// Property Indexer for EmailBodyText6Of10
			/// </summary>
			public const int EmailBodyText6Of10 = 13;

			/// <summary>
			/// Property Indexer for EmailBodyText7Of10
			/// </summary>
			public const int EmailBodyText7Of10 = 14;

			/// <summary>
			/// Property Indexer for EmailBodyText8Of10
			/// </summary>
			public const int EmailBodyText8Of10 = 15;

			/// <summary>
			/// Property Indexer for EmailBodyText9Of10
			/// </summary>
			public const int EmailBodyText9Of10 = 16;

			/// <summary>
			/// Property Indexer for EmailBodyText10Of10
			/// </summary>
			public const int EmailBodyText10Of10 = 17;

			/// <summary>
			/// Property Indexer for EmailBody
			/// </summary>
			public const int EmailBody = 30;

		}

		#endregion
	}
}
