﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of SalesHistoryDetail Constants
    /// </summary>
    public partial class SalesHistoryDetail1
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "OE0685";

        #region Properties

        /// <summary>
        /// Contains list of SalesHistoryDetail Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTOMER";

            /// <summary>
            /// Property for ITEM
            /// </summary>
            public const string ItemNumber = "ITEM";

            /// <summary>
            /// Property for ITEMFMT
            /// </summary>
            public const string FormattedItemNumber = "ITEMFMT";


            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "CUSTDESC";

            /// <summary>
            /// Property for Year
            /// </summary>
            public const string Year = "YR";

            /// <summary>
            /// Property for Period
            /// </summary>
            public const string Period = "PERIOD";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string CustCurrency = "SCURN";

        }

        #endregion

        #region Propperties

        public class Index
        {
            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for ITEM
            /// </summary>
            public const int ItemNumber = 2;

            /// <summary>
            /// Property Indexer for ITEMFMT
            /// </summary>
            public const int FormattedItemNumber = 50;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 50;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 51;

            /// <summary>
            /// Property Indexer for Year
            /// </summary>
            public const int Year = 3;

            /// <summary>
            /// Property Indexer for Period
            /// </summary>
            public const int Period = 4;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int CustCurrency = 5;

        }


        #endregion

    }
}
