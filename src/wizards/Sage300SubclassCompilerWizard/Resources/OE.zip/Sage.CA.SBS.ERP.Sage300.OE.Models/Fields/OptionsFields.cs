// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of OEOption Constants
    /// </summary>
    public partial class Options
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0480";

        #region Properties

        /// <summary>
        /// Contains list of OEOption Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for DummyKey
            /// </summary>
            public const string DummyKey = "DUMMY";

            /// <summary>
            /// Property for Phone
            /// </summary>
            public const string Phone = "PHONE";

            /// <summary>
            /// Property for Fax
            /// </summary>
            public const string Fax = "FAX";

            /// <summary>
            /// Property for ContactName
            /// </summary>
            public const string ContactName = "CONTACT";

            /// <summary>
            /// Property for DayEndPending
            /// </summary>
            public const string DayEndPending = "DAYEND";

            /// <summary>
            /// Property for DirectPrintingonInvoices
            /// </summary>
            public const string DirectPrintingonInvoices = "DIRECT";

            /// <summary>
            /// Property for KeepOrderHistory
            /// </summary>
            public const string KeepOrderHistory = "ORDHIST";

            /// <summary>
            /// Property for TrackCommissions
            /// </summary>
            public const string TrackCommissions = "COMMISSION";

            /// <summary>
            /// Property for CommissionType
            /// </summary>
            public const string CommissionType = "COMMTYPE";

            /// <summary>
            /// Property for CalculateBackorderQuantities
            /// </summary>
            public const string CalculateBackorderQuantities = "BACKORD";

            /// <summary>
            /// Property for AllowQtyShippedonOrders
            /// </summary>
            public const string AllowQtyShippedonOrders = "ALLOWSHIP";

            /// <summary>
            /// Property for AccumulateStatistics
            /// </summary>
            public const string AccumulateStatistics = "STATACCUM";

            /// <summary>
            /// Property for AllowEditStatistics
            /// </summary>
            public const string AllowEditStatistics = "STATEDIT";

            /// <summary>
            /// Property for AccumulateStatisticsBy
            /// </summary>
            public const string AccumulateStatisticsBy = "STATCLNDR";

            /// <summary>
            /// Property for StatisticsPeriodBy
            /// </summary>
            public const string StatisticsPeriodBy = "STATPRD";

            /// <summary>
            /// Property for AgingPeriod1
            /// </summary>
            public const string AgingPeriod1 = "AGING1";

            /// <summary>
            /// Property for AgingPeriod2
            /// </summary>
            public const string AgingPeriod2 = "AGING2";

            /// <summary>
            /// Property for AgingPeriod3
            /// </summary>
            public const string AgingPeriod3 = "AGING3";

            /// <summary>
            /// Property for DefaultRateType
            /// </summary>
            public const string DefaultRateType = "RATETYPE";

            /// <summary>
            /// Property for AccumulateSalesHistory
            /// </summary>
            public const string AccumulateSalesHistory = "TRANHIST";

            /// <summary>
            /// Property for AccumulateSalesHistoryBy
            /// </summary>
            public const string AccumulateSalesHistoryBy = "TRANCLNDR";

            /// <summary>
            /// Property for SalesHistoryPeriodBy
            /// </summary>
            public const string SalesHistoryPeriodBy = "TRANPRD";

            /// <summary>
            /// Property for DefaultTemplateCode
            /// </summary>
            public const string DefaultTemplateCode = "DEFTEMP";

            /// <summary>
            /// Property for OrderNumberLength
            /// </summary>
            public const string OrderNumberLength = "ORDNUMBERL";

            /// <summary>
            /// Property for OrderNumberPrefix
            /// </summary>
            public const string OrderNumberPrefix = "ORDPREFIXD";


            /// <summary>
            /// Property for ORDBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string ORDBODYD = "ORDBODYD";

            /// <summary>
            /// Property for NextOrderUniquifierKey
            /// </summary>
            public const string NextOrderUniquifierKey = "NEXTOUNIQ";

            /// <summary>
            /// Property for InvoiceNumberLength
            /// </summary>
            public const string InvoiceNumberLength = "INVNUMBERL";

            /// <summary>
            /// Property for InvoiceNumberPrefix
            /// </summary>
            public const string InvoiceNumberPrefix = "INVPREFIXD";


            /// <summary>
            /// Property for INVBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string INVBODYD = "INVBODYD";

            /// <summary>
            /// Property for CreditNoteNumberLength
            /// </summary>
            public const string CreditNoteNumberLength = "CRDNUMBERL";

            /// <summary>
            /// Property for CreditNoteNumberPrefix
            /// </summary>
            public const string CreditNoteNumberPrefix = "CRDPREFIXD";


            /// <summary>
            /// Property for CRDBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string CRDBODYD = "CRDBODYD";

            /// <summary>
            /// Property for NextCreditNoteUniquifierKey
            /// </summary>
            public const string NextCreditNoteUniquifierKey = "NEXTCUNIQ";

            /// <summary>
            /// Property for DayEndBrowseNumber
            /// </summary>
            public const string DayEndBrowseNumber = "BROWSENUM";

            /// <summary>
            /// Property for QuoteNumberLength
            /// </summary>
            public const string QuoteNumberLength = "QUONUMBERL";

            /// <summary>
            /// Property for QuoteNumberPrefix
            /// </summary>
            public const string QuoteNumberPrefix = "QUOPREFIXD";


            /// <summary>
            /// Property for QUOBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string QUOBODYD = "QUOBODYD";

            /// <summary>
            /// Property for DefaultOrderUOM
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string DefaultOrderUOM = "UOMBY";

            /// <summary>
            /// Property for AllowpostTononexistcustomer
            /// </summary>
            public const string AllowpostTononexistcustomer = "NONCUST";

            /// <summary>
            /// Property for Defaultquoteexpiringdays
            /// </summary>
            public const string Defaultquoteexpiringdays = "QUOEXPIRE";

            /// <summary>
            /// Property for DebitNoteNumberLength
            /// </summary>
            public const string DebitNoteNumberLength = "DBNNUMBERL";

            /// <summary>
            /// Property for DebitNoteNumberPrefix
            /// </summary>
            public const string DebitNoteNumberPrefix = "DBNPREFIXD";


            /// <summary>
            /// Property for DBNBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string DBNBODYD = "DBNBODYD";

            /// <summary>
            /// Property for NextInvoiceUniquifierKey
            /// </summary>
            public const string NextInvoiceUniquifierKey = "NEXTIUNIQ";

            /// <summary>
            /// Property for ShipmentNumberLength
            /// </summary>
            public const string ShipmentNumberLength = "SHINUMBERL";

            /// <summary>
            /// Property for ShipmentNumberPrefix
            /// </summary>
            public const string ShipmentNumberPrefix = "SHIPREFIXD";


            /// <summary>
            /// Property for SHIBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string SHIBODYD = "SHIBODYD";

            /// <summary>
            /// Property for NextShipmentUniquifierKey
            /// </summary>
            public const string NextShipmentUniquifierKey = "NEXTSUNIQ";

            /// <summary>
            /// Property for DeferredGLPosting
            /// </summary>
            public const string DeferredGLPosting = "DEFERGLPST";

            /// <summary>
            /// Property for GLTransCreatedThruDayEnd
            /// </summary>
            public const string GLTransCreatedThruDayEnd = "GLDAYEND";

            /// <summary>
            /// Property for AppendToGLBatch
            /// </summary>
            public const string AppendToGLBatch = "APPENDGL";

            /// <summary>
            /// Property for ConsolidateGLBatch
            /// </summary>
            public const string ConsolidateGLBatch = "CONSOLGL";

            /// <summary>
            /// Property for GLReferenceField
            /// </summary>
            public const string GLReferenceField = "REFCHOICE";

            /// <summary>
            /// Property for GLDescriptionField
            /// </summary>
            public const string GLDescriptionField = "DESCCHOICE";

            /// <summary>
            /// Property for DefaultQtyOrderedToCommitte
            /// </summary>
            public const string DefaultQtyOrderedToCommitte = "DEFQCOMMIT";

            /// <summary>
            /// Property for CreateInvoiceWhenQtyShipped
            /// </summary>
            public const string CreateInvoiceWhenQtyShipped = "CREATEINV";

            /// <summary>
            /// Property for ApplyCNToinvoicethatwascre
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string ApplyCNToinvoicethatwascre = "INCREDITED";

            /// <summary>
            /// Property for IncludePendingARTransactions
            /// </summary>
            public const string IncludePendingARTransactions = "INCARPEND";

            /// <summary>
            /// Property for IncludePendingOETransactions
            /// </summary>
            public const string IncludePendingOETransactions = "INCOEPEND";

            /// <summary>
            /// Property for IncludeOtherPendingTransactio
            /// </summary>
            public const string IncludeOtherPendingTransactio = "INCXXPEND";

            /// <summary>
            /// Property for TaxReportingCalculationMethod
            /// </summary>
            public const string TaxReportingCalculationMethod = "TAXREPCALC";

            /// <summary>
            /// Property for DefaultOrderWeightUOM
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string DefaultOrderWeightUOM = "WUOMBY";

            /// <summary>
            /// Property for DeferredARPosting
            /// </summary>
            public const string DeferredARPosting = "DEFERARPST";

            /// <summary>
            /// Property for OEShipments
            /// </summary>
            public const string OEShipments = "SRCTYPESH";

            /// <summary>
            /// Property for OEInvoices
            /// </summary>
            public const string OEInvoices = "SRCTYPEIN";

            /// <summary>
            /// Property for OECreditNotes
            /// </summary>
            public const string OECreditNotes = "SRCTYPECN";

            /// <summary>
            /// Property for OEDebitNotes
            /// </summary>
            public const string OEDebitNotes = "SRCTYPEDN";

            /// <summary>
            /// Property for OEConsolidatedEntry
            /// </summary>
            public const string OEConsolidatedEntry = "SRCTYPECO";

            /// <summary>
            /// Property for DefaultPostingDate
            /// </summary>
            public const string DefaultPostingDate = "DATEBUSDFT";

            /// <summary>
            /// Property for ClearExpiredQuotes
            /// </summary>
            public const string ClearExpiredQuotes = "PURGEEXPQT";

            /// <summary>
            /// Property for ClearExpiredQuotesDays
            /// </summary>
            public const string ClearExpiredQuotesDays = "QTPURGEDAY";

            /// <summary>
            /// Property for StatisticalPeriodType
            /// </summary>
            public const string StatisticalPeriodType = "STATPRDTYP";

            /// <summary>
            /// Property for StatisticalPeriodLength
            /// </summary>
            public const string StatisticalPeriodLength = "STATPRDLNG";

            /// <summary>
            /// Property for StatisticalPeriods
            /// </summary>
            public const string StatisticalPeriods = "STATPRDS";

            /// <summary>
            /// Property for SalesHistoryPeriodType
            /// </summary>
            public const string SalesHistoryPeriodType = "TRANPRDTYP";

            /// <summary>
            /// Property for SalesHistoryPeriodLength
            /// </summary>
            public const string SalesHistoryPeriodLength = "TRANPRDLNG";

            /// <summary>
            /// Property for SalesHistoryPeriods
            /// </summary>
            public const string SalesHistoryPeriods = "TRANPRDS";

            /// <summary>
            /// Property for DefaultOrderNumber
            /// </summary>
            public const string DefaultOrderNumber = "ORDDEFAULT";


            /// <summary>
            /// Property for ORDVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string ORDVALUE = "ORDVALUE";

            /// <summary>
            /// Property for DefaultInvoiceNumber
            /// </summary>
            public const string DefaultInvoiceNumber = "INVDEFAULT";


            /// <summary>
            /// Property for INVVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string INVVALUE = "INVVALUE";

            /// <summary>
            /// Property for DefaultCreditNoteNumber
            /// </summary>
            public const string DefaultCreditNoteNumber = "CRDDEFAULT";


            /// <summary>
            /// Property for CRDVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string CRDVALUE = "CRDVALUE";

            /// <summary>
            /// Property for DefaultQuoteNumber
            /// </summary>
            public const string DefaultQuoteNumber = "QUODEFAULT";


            /// <summary>
            /// Property for QUOVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string QUOVALUE = "QUOVALUE";

            /// <summary>
            /// Property for HomeCurrency
            /// </summary>
            public const string HomeCurrency = "HOMECURR";

            /// <summary>
            /// Property for DatabaseDriverID
            /// </summary>
            public const string DatabaseDriverID = "DRIVERID";

            /// <summary>
            /// Property for DefaultDebitNoteNumber
            /// </summary>
            public const string DefaultDebitNoteNumber = "DBNDEFAULT";


            /// <summary>
            /// Property for DBNVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string DBNVALUE = "DBNVALUE";

            /// <summary>
            /// Property for DefaultShipmentNumber
            /// </summary>
            public const string DefaultShipmentNumber = "SHIDEFAULT";


            /// <summary>
            /// Property for SHIVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string SHIVALUE = "SHIVALUE";

            /// <summary>
            /// Property for NextDayEndPostingSeq
            /// </summary>
            public const string NextDayEndPostingSeq = "DAYENDSEQ";

            /// <summary>
            /// Property for Action
            /// </summary>
            public const string Action = "ACTION";

            /// <summary>
            /// Property for CurrentSalesHistoryYear
            /// </summary>
            public const string CurrentSalesHistoryYear = "SHFISCYR";

            /// <summary>
            /// Property for CurrentSalesHistoryPeriod
            /// </summary>
            public const string CurrentSalesHistoryPeriod = "SHFISCPER";

            /// <summary>
            /// Property for CurrentSalesStatisticsYear
            /// </summary>
            public const string CurrentSalesStatisticsYear = "SSFISCYR";

            /// <summary>
            /// Property for CurrentSalesStatisticsPeriod
            /// </summary>
            public const string CurrentSalesStatisticsPeriod = "SSFISCPER";

            /// <summary>
            /// Property for RequireInvoicingatShipping
            /// </summary>
            public const string RequireInvoicingatShipping = "SWCAPTURE";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of OEOption Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for DummyKey
            /// </summary>
            public const int DummyKey = 1;

            /// <summary>
            /// Property Indexer for Phone
            /// </summary>
            public const int Phone = 2;

            /// <summary>
            /// Property Indexer for Fax
            /// </summary>
            public const int Fax = 3;

            /// <summary>
            /// Property Indexer for ContactName
            /// </summary>
            public const int ContactName = 4;

            /// <summary>
            /// Property Indexer for DayEndPending
            /// </summary>
            public const int DayEndPending = 5;

            /// <summary>
            /// Property Indexer for DirectPrintingonInvoices
            /// </summary>
            public const int DirectPrintingonInvoices = 6;

            /// <summary>
            /// Property Indexer for KeepOrderHistory
            /// </summary>
            public const int KeepOrderHistory = 7;

            /// <summary>
            /// Property Indexer for TrackCommissions
            /// </summary>
            public const int TrackCommissions = 8;

            /// <summary>
            /// Property Indexer for CommissionType
            /// </summary>
            public const int CommissionType = 9;

            /// <summary>
            /// Property Indexer for CalculateBackorderQuantities
            /// </summary>
            public const int CalculateBackorderQuantities = 10;

            /// <summary>
            /// Property Indexer for AllowQtyShippedonOrders
            /// </summary>
            public const int AllowQtyShippedonOrders = 11;

            /// <summary>
            /// Property Indexer for AccumulateStatistics
            /// </summary>
            public const int AccumulateStatistics = 12;

            /// <summary>
            /// Property Indexer for AllowEditStatistics
            /// </summary>
            public const int AllowEditStatistics = 13;

            /// <summary>
            /// Property Indexer for AccumulateStatisticsBy
            /// </summary>
            public const int AccumulateStatisticsBy = 14;

            /// <summary>
            /// Property Indexer for StatisticsPeriodBy
            /// </summary>
            public const int StatisticsPeriodBy = 15;

            /// <summary>
            /// Property Indexer for AgingPeriod1
            /// </summary>
            public const int AgingPeriod1 = 16;

            /// <summary>
            /// Property Indexer for AgingPeriod2
            /// </summary>
            public const int AgingPeriod2 = 17;

            /// <summary>
            /// Property Indexer for AgingPeriod3
            /// </summary>
            public const int AgingPeriod3 = 18;

            /// <summary>
            /// Property Indexer for DefaultRateType
            /// </summary>
            public const int DefaultRateType = 19;

            /// <summary>
            /// Property Indexer for AccumulateSalesHistory
            /// </summary>
            public const int AccumulateSalesHistory = 20;

            /// <summary>
            /// Property Indexer for AccumulateSalesHistoryBy
            /// </summary>
            public const int AccumulateSalesHistoryBy = 21;

            /// <summary>
            /// Property Indexer for SalesHistoryPeriodBy
            /// </summary>
            public const int SalesHistoryPeriodBy = 22;

            /// <summary>
            /// Property Indexer for DefaultTemplateCode
            /// </summary>
            public const int DefaultTemplateCode = 23;

            /// <summary>
            /// Property Indexer for OrderNumberLength
            /// </summary>
            public const int OrderNumberLength = 46;

            /// <summary>
            /// Property Indexer for OrderNumberPrefix
            /// </summary>
            public const int OrderNumberPrefix = 47;


            /// <summary>
            /// Property Indexer for ORDBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int ORDBODYD = 48;

            /// <summary>
            /// Property Indexer for NextOrderUniquifierKey
            /// </summary>
            public const int NextOrderUniquifierKey = 49;

            /// <summary>
            /// Property Indexer for InvoiceNumberLength
            /// </summary>
            public const int InvoiceNumberLength = 50;

            /// <summary>
            /// Property Indexer for InvoiceNumberPrefix
            /// </summary>
            public const int InvoiceNumberPrefix = 51;


            /// <summary>
            /// Property Indexer for INVBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int INVBODYD = 52;

            /// <summary>
            /// Property Indexer for CreditNoteNumberLength
            /// </summary>
            public const int CreditNoteNumberLength = 53;

            /// <summary>
            /// Property Indexer for CreditNoteNumberPrefix
            /// </summary>
            public const int CreditNoteNumberPrefix = 54;


            /// <summary>
            /// Property Indexer for CRDBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int CRDBODYD = 55;

            /// <summary>
            /// Property Indexer for NextCreditNoteUniquifierKey
            /// </summary>
            public const int NextCreditNoteUniquifierKey = 56;

            /// <summary>
            /// Property Indexer for DayEndBrowseNumber
            /// </summary>
            public const int DayEndBrowseNumber = 57;

            /// <summary>
            /// Property Indexer for QuoteNumberLength
            /// </summary>
            public const int QuoteNumberLength = 58;

            /// <summary>
            /// Property Indexer for QuoteNumberPrefix
            /// </summary>
            public const int QuoteNumberPrefix = 59;


            /// <summary>
            /// Property Indexer for QUOBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int QUOBODYD = 60;

            /// <summary>
            /// Property Indexer for DefaultOrderUOM
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int DefaultOrderUOM = 61;

            /// <summary>
            /// Property Indexer for AllowpostTononexistcustomer
            /// </summary>
            public const int AllowpostTononexistcustomer = 62;

            /// <summary>
            /// Property Indexer for Defaultquoteexpiringdays
            /// </summary>
            public const int Defaultquoteexpiringdays = 63;

            /// <summary>
            /// Property Indexer for DebitNoteNumberLength
            /// </summary>
            public const int DebitNoteNumberLength = 64;

            /// <summary>
            /// Property Indexer for DebitNoteNumberPrefix
            /// </summary>
            public const int DebitNoteNumberPrefix = 65;


            /// <summary>
            /// Property Indexer for DBNBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int DBNBODYD = 66;

            /// <summary>
            /// Property Indexer for NextInvoiceUniquifierKey
            /// </summary>
            public const int NextInvoiceUniquifierKey = 67;

            /// <summary>
            /// Property Indexer for ShipmentNumberLength
            /// </summary>
            public const int ShipmentNumberLength = 68;

            /// <summary>
            /// Property Indexer for ShipmentNumberPrefix
            /// </summary>
            public const int ShipmentNumberPrefix = 69;


            /// <summary>
            /// Property Indexer for SHIBODYD
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int SHIBODYD = 70;

            /// <summary>
            /// Property Indexer for NextShipmentUniquifierKey
            /// </summary>
            public const int NextShipmentUniquifierKey = 71;

            /// <summary>
            /// Property Indexer for DeferredGLPosting
            /// </summary>
            public const int DeferredGLPosting = 72;

            /// <summary>
            /// Property Indexer for GLTransCreatedThruDayEnd
            /// </summary>
            public const int GLTransCreatedThruDayEnd = 73;

            /// <summary>
            /// Property Indexer for AppendToGLBatch
            /// </summary>
            public const int AppendToGLBatch = 74;

            /// <summary>
            /// Property Indexer for ConsolidateGLBatch
            /// </summary>
            public const int ConsolidateGLBatch = 75;

            /// <summary>
            /// Property Indexer for GLReferenceField
            /// </summary>
            public const int GLReferenceField = 76;

            /// <summary>
            /// Property Indexer for GLDescriptionField
            /// </summary>
            public const int GLDescriptionField = 77;

            /// <summary>
            /// Property Indexer for DefaultQtyOrderedToCommitte
            /// </summary>
            public const int DefaultQtyOrderedToCommitte = 78;

            /// <summary>
            /// Property Indexer for CreateInvoiceWhenQtyShipped
            /// </summary>
            public const int CreateInvoiceWhenQtyShipped = 79;

            /// <summary>
            /// Property Indexer for ApplyCNToinvoicethatwascre
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int ApplyCNToinvoicethatwascre = 80;

            /// <summary>
            /// Property Indexer for IncludePendingARTransactions
            /// </summary>
            public const int IncludePendingARTransactions = 81;

            /// <summary>
            /// Property Indexer for IncludePendingOETransactions
            /// </summary>
            public const int IncludePendingOETransactions = 82;

            /// <summary>
            /// Property Indexer for IncludeOtherPendingTransactio
            /// </summary>
            public const int IncludeOtherPendingTransactio = 83;

            /// <summary>
            /// Property Indexer for TaxReportingCalculationMethod
            /// </summary>
            public const int TaxReportingCalculationMethod = 84;

            /// <summary>
            /// Property Indexer for DefaultOrderWeightUOM
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int DefaultOrderWeightUOM = 85;

            /// <summary>
            /// Property Indexer for DeferredARPosting
            /// </summary>
            public const int DeferredARPosting = 86;

            /// <summary>
            /// Property Indexer for OEShipments
            /// </summary>
            public const int OEShipments = 87;

            /// <summary>
            /// Property Indexer for OEInvoices
            /// </summary>
            public const int OEInvoices = 88;

            /// <summary>
            /// Property Indexer for OECreditNotes
            /// </summary>
            public const int OECreditNotes = 89;

            /// <summary>
            /// Property Indexer for OEDebitNotes
            /// </summary>
            public const int OEDebitNotes = 90;

            /// <summary>
            /// Property Indexer for OEConsolidatedEntry
            /// </summary>
            public const int OEConsolidatedEntry = 91;

            /// <summary>
            /// Property Indexer for DefaultPostingDate
            /// </summary>
            public const int DefaultPostingDate = 92;

            /// <summary>
            /// Property Indexer for ClearExpiredQuotes
            /// </summary>
            public const int ClearExpiredQuotes = 93;

            /// <summary>
            /// Property Indexer for ClearExpiredQuotesDays
            /// </summary>
            public const int ClearExpiredQuotesDays = 94;

            /// <summary>
            /// Property Indexer for StatisticalPeriodType
            /// </summary>
            public const int StatisticalPeriodType = 101;

            /// <summary>
            /// Property Indexer for StatisticalPeriodLength
            /// </summary>
            public const int StatisticalPeriodLength = 102;

            /// <summary>
            /// Property Indexer for StatisticalPeriods
            /// </summary>
            public const int StatisticalPeriods = 103;

            /// <summary>
            /// Property Indexer for SalesHistoryPeriodType
            /// </summary>
            public const int SalesHistoryPeriodType = 104;

            /// <summary>
            /// Property Indexer for SalesHistoryPeriodLength
            /// </summary>
            public const int SalesHistoryPeriodLength = 105;

            /// <summary>
            /// Property Indexer for SalesHistoryPeriods
            /// </summary>
            public const int SalesHistoryPeriods = 106;

            /// <summary>
            /// Property Indexer for DefaultOrderNumber
            /// </summary>
            public const int DefaultOrderNumber = 107;


            /// <summary>
            /// Property Indexer for ORDVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int ORDVALUE = 108;

            /// <summary>
            /// Property Indexer for DefaultInvoiceNumber
            /// </summary>
            public const int DefaultInvoiceNumber = 109;


            /// <summary>
            /// Property Indexer for INVVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int INVVALUE = 110;

            /// <summary>
            /// Property Indexer for DefaultCreditNoteNumber
            /// </summary>
            public const int DefaultCreditNoteNumber = 111;


            /// <summary>
            /// Property Indexer for CRDVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int CRDVALUE = 112;

            /// <summary>
            /// Property Indexer for DefaultQuoteNumber
            /// </summary>
            public const int DefaultQuoteNumber = 113;


            /// <summary>
            /// Property Indexer for QUOVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int QUOVALUE = 114;

            /// <summary>
            /// Property Indexer for HomeCurrency
            /// </summary>
            public const int HomeCurrency = 115;

            /// <summary>
            /// Property Indexer for DatabaseDriverID
            /// </summary>
            public const int DatabaseDriverID = 116;

            /// <summary>
            /// Property Indexer for DefaultDebitNoteNumber
            /// </summary>
            public const int DefaultDebitNoteNumber = 117;


            /// <summary>
            /// Property Indexer for DBNVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int DBNVALUE = 118;

            /// <summary>
            /// Property Indexer for DefaultShipmentNumber
            /// </summary>
            public const int DefaultShipmentNumber = 119;


            /// <summary>
            /// Property Indexer for SHIVALUE
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int SHIVALUE = 120;

            /// <summary>
            /// Property Indexer for NextDayEndPostingSeq
            /// </summary>
            public const int NextDayEndPostingSeq = 121;

            /// <summary>
            /// Property Indexer for Action
            /// </summary>
            public const int Action = 122;

            /// <summary>
            /// Property Indexer for CurrentSalesHistoryYear
            /// </summary>
            public const int CurrentSalesHistoryYear = 123;

            /// <summary>
            /// Property Indexer for CurrentSalesHistoryPeriod
            /// </summary>
            public const int CurrentSalesHistoryPeriod = 124;

            /// <summary>
            /// Property Indexer for CurrentSalesStatisticsYear
            /// </summary>
            public const int CurrentSalesStatisticsYear = 125;

            /// <summary>
            /// Property Indexer for CurrentSalesStatisticsPeriod
            /// </summary>
            public const int CurrentSalesStatisticsPeriod = 126;

            /// <summary>
            /// Property Indexer for RequireInvoicingatShipping
            /// </summary>
            public const int RequireInvoicingatShipping = 127;

        }

        #endregion

    }
}
