// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of OrderKittingDetail Constants
     /// </summary>
     public partial class OrderKittingDetail
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "OE0502";

          #region Properties
          /// <summary>
          /// Contains list of OrderKittingDetail Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for OrderUniquifier
               /// </summary>
               public const string OrderUniquifier = "ORDUNIQ";

               /// <summary>
               /// Property for DetailLineNumber
               /// </summary>
               public const string DetailLineNumber = "LINENUM";

               /// <summary>
               /// Property for ParentComponentNumber
               /// </summary>
               public const string ParentComponentNumber = "PRNCOMPNUM";

               /// <summary>
               /// Property for ComponentNumber
               /// </summary>
               public const string ComponentNumber = "COMPNUM";

               /// <summary>
               /// Property for DetailNumber
               /// </summary>
               public const string DetailNumber = "DETAILNUM";

               /// <summary>
               /// Property for ComponentItem
               /// </summary>
               public const string ComponentItem = "COMPONENT";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for ItemAccountSet
               /// </summary>
               public const string ItemAccountSet = "ACCTSET";

               /// <summary>
               /// Property for UserSpecifiedCostingMethod
               /// </summary>
               public const string UserSpecifiedCostingMethod = "USERCOSTMD";

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for PickingSequence
               /// </summary>
               public const string PickingSequence = "PICKSEQ";

               /// <summary>
               /// Property for StockItem
               /// </summary>
               public const string StockItem = "STOCKITEM";

               /// <summary>
               /// Property for KittingQuantity
               /// </summary>
               public const string KittingQuantity = "QTY";

               /// <summary>
               /// Property for ParentQuantityOrdered
               /// </summary>
               public const string ParentQuantityOrdered = "PRNQTYORD";

               /// <summary>
               /// Property for ParentQuantityShipped
               /// </summary>
               public const string ParentQuantityShipped = "PRNQTYSHIP";

               /// <summary>
               /// Property for ParentUnitOfMeasure
               /// </summary>
               public const string ParentUnitOfMeasure = "PRNUNIT";

               /// <summary>
               /// Property for ParentUnitConversion
               /// </summary>
               public const string ParentUnitConversion = "PRNUNTCONV";

               /// <summary>
               /// Property for QuantityOrdered
               /// </summary>
               public const string QuantityOrdered = "QTYORDERED";

               /// <summary>
               /// Property for QuantityShipped
               /// </summary>
               public const string QuantityShipped = "QTYSHIPPED";

               /// <summary>
               /// Property for POQuantityOrdered
               /// </summary>
               public const string POQuantityOrdered = "QTYPO";

               /// <summary>
               /// Property for OrderUnitOfMeasure
               /// </summary>
               public const string UnitOfMeasure = "ORDUNIT";

               /// <summary>
               /// Property for OrderUnitConversion
               /// </summary>
               public const string OrderUnitConversion = "UNITCONV";

               /// <summary>
               /// Property for OrderUnitCost
               /// </summary>
               public const string OrderUnitCost = "UNITCOST";

               /// <summary>
               /// Property for MostRecentUnitCost
               /// </summary>
               public const string MostRecentUnitCost = "MOSTREC";

               /// <summary>
               /// Property for StandardUnitCost
               /// </summary>
               public const string StandardUnitCost = "STDCOST";

               /// <summary>
               /// Property for AlternateUnitCost1
               /// </summary>
               public const string AlternateUnitCost1 = "COST1";

               /// <summary>
               /// Property for AlternateUnitCost2
               /// </summary>
               public const string AlternateUnitCost2 = "COST2";

               /// <summary>
               /// Property for AverageUnitCost
               /// </summary>
               public const string AverageUnitCost = "AVGCOST";

               /// <summary>
               /// Property for LastUnitCost
               /// </summary>
               public const string LastUnitCost = "LASTCOST";

               /// <summary>
               /// Property for CostingUnitOfMeasure
               /// </summary>
               public const string CostingUnitOfMeasure = "COSTUNIT";

               /// <summary>
               /// Property for CostingUnitCost
               /// </summary>
               public const string CostingUnitCost = "COSUNTCST";

               /// <summary>
               /// Property for CostingUnitConversion
               /// </summary>
               public const string CostingUnitConversion = "COSUNTCONV";

               /// <summary>
               /// Property for ExtendedOrderCost
               /// </summary>
               public const string ExtendedOrderCost = "EXTOCOST";

               /// <summary>
               /// Property for UnitWeight
               /// </summary>
               public const string UnitWeight = "UNITWEIGHT";

               /// <summary>
               /// Property for ExtendedWeight
               /// </summary>
               public const string ExtendedWeight = "EXTWEIGHT";

               /// <summary>
               /// Property for NonstockClearingAccount
               /// </summary>
               public const string NonstockClearingAccount = "GLNONSTKCR";

               /// <summary>
               /// Property for WeightUnitOfMeasure
               /// </summary>
               public const string WeightUnitOfMeasure = "WEIGHTUNIT";

               /// <summary>
               /// Property for WeightConversionFactor
               /// </summary>
               public const string WeightConversionFactor = "WEIGHTCONV";

               /// <summary>
               /// Property for ParentWeightConversionFactor
               /// </summary>
               public const string ParentWeightConversionFactor = "PRNWGTCONV";

               /// <summary>
               /// Property for ParentWeightUOMUnitWeight
               /// </summary>
               public const string ParentWeightUOMUnitWeight = "PRNUWEIGHT";

               /// <summary>
               /// Property for ParentWUOMExtendedUnitWeight
               /// </summary>
               public const string ParentWUOMExtendedUnitWeight = "PRNEXTWGHT";

               /// <summary>
               /// Property for KitNo
               /// </summary>
               public const string KitNo = "DDTLNO";

               /// <summary>
               /// Property for SerialQuantity
               /// </summary>
               public const string SerialQuantity = "SERIALQTY";

               /// <summary>
               /// Property for LotQuantity
               /// </summary>
               public const string LotQuantity = "LOTQTY";

               /// <summary>
               /// Property for SerialQtyShipped
               /// </summary>
               public const string SerialQtyShipped = "SQTYMOVED";

               /// <summary>
               /// Property for LotQtyShipped
               /// </summary>
               public const string LotQtyShipped = "LQTYMOVED";

               /// <summary>
               /// Property for ItemSerializedLotted
               /// </summary>
               public const string ItemSerializedLotted = "SLITEM";

               /// <summary>
               /// Property for ComponentUnitCost
               /// </summary>
               public const string ComponentUnitCost = "CMPUNTCOST";

               /// <summary>
               /// Property for MostRecentComponentCost
               /// </summary>
               public const string MostRecentComponentCost = "CMPMOSTREC";

               /// <summary>
               /// Property for StandardComponentCost
               /// </summary>
               public const string StandardComponentCost = "CMPSTDCOST";

               /// <summary>
               /// Property for AlternateComponentCost1
               /// </summary>
               public const string AlternateComponentCost1 = "CMPCOST1";

               /// <summary>
               /// Property for AlternateComponentCost2
               /// </summary>
               public const string AlternateComponentCost2 = "CMPCOST2";

               /// <summary>
               /// Property for AverageComponentCost
               /// </summary>
               public const string AverageComponentCost = "CMPAVGCOST";

               /// <summary>
               /// Property for LastComponentCost
               /// </summary>
               public const string LastComponentCost = "CMPLSTCOST";

               /// <summary>
               /// Property for NonstockClearingAcctDesc
               /// </summary>
               public const string NonstockClearingAcctDesc = "GLNONSTKCD";

               /// <summary>
               /// Property for InterprocessCommID
               /// </summary>
               public const string InterprocessCommID = "IPCID";

               /// <summary>
               /// Property for ForcePopupSNonQtyOrdered
               /// </summary>
               public const string ForcePopupSNonQtyOrdered = "FPOPSNQO";

               /// <summary>
               /// Property for ForcePopupSNonQtyShipped
               /// </summary>
               public const string ForcePopupSNonQtyShipped = "FPOPSNQS";

               /// <summary>
               /// Property for PopupSN
               /// </summary>
               public const string PopupSN = "POPUPSN";

               /// <summary>
               /// Property for CloseSN
               /// </summary>
               public const string CloseSN = "CLOSESN";

               /// <summary>
               /// Property for LTSetID
               /// </summary>
               public const string LTSetID = "LTSETID";

               /// <summary>
               /// Property for ForcePopupLTonQtyOrdered
               /// </summary>
               public const string ForcePopupLTonQtyOrdered = "FPOPLTQO";

               /// <summary>
               /// Property for ForcePopupLTonQtyShipped
               /// </summary>
               public const string ForcePopupLTonQtyShipped = "FPOPLTQS";

               /// <summary>
               /// Property for PopupLT
               /// </summary>
               public const string PopupLT = "POPUPLT";

               /// <summary>
               /// Property for CloseLT
               /// </summary>
               public const string CloseLT = "CLOSELT";

               /// <summary>
               /// Property for ComponentSerialized
               /// </summary>
               public const string ComponentSerialized = "SERIALITEM";

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "UNFMTITEM";

               /// <summary>
               /// Property for ComponentLotted
               /// </summary>
               public const string ComponentLotted = "LOTTEDITEM";

               /// <summary>
               /// Property for WeightUOMDescription
               /// </summary>
               public const string WeightUomDescription = "WUOMDESC";

               /// <summary>
               /// Property for ProcessCommand
               /// </summary>
               public const string ProcessCommand = "PROCESSCMD";

               /// <summary>
               /// Property for SerialLotQuantityToProcess
               /// </summary>
               public const string SerialLotQuantityToProcess = "XGENALCQTY";

               /// <summary>
               /// Property for NumberOfLotsToGenerate
               /// </summary>
               public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

               /// <summary>
               /// Property for QuantityperLot
               /// </summary>
               public const string QuantityperLot = "XPERLOTQTY";

               /// <summary>
               /// Property for AllocateFromSerial
               /// </summary>
               public const string AllocateFromSerial = "SALLOCFROM";

               /// <summary>
               /// Property for AllocateFromLot
               /// </summary>
               public const string AllocateFromLot = "LALLOCFROM";

               /// <summary>
               /// Property for SerialLotWindowHandle
               /// </summary>
               public const string SerialLotWindowHandle = "METERHWND";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of OrderKittingDetail Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for OrderUniquifier
               /// </summary>
               public const int OrderUniquifier = 1;

               /// <summary>
               /// Property Indexer for DetailLineNumber
               /// </summary>
               public const int DetailLineNumber = 2;

               /// <summary>
               /// Property Indexer for ParentComponentNumber
               /// </summary>
               public const int ParentComponentNumber = 3;

               /// <summary>
               /// Property Indexer for ComponentNumber
               /// </summary>
               public const int ComponentNumber = 4;

               /// <summary>
               /// Property Indexer for DetailNumber
               /// </summary>
               public const int DetailNumber = 5;

               /// <summary>
               /// Property Indexer for ComponentItem
               /// </summary>
               public const int ComponentItem = 6;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 7;

               /// <summary>
               /// Property Indexer for ItemAccountSet
               /// </summary>
               public const int ItemAccountSet = 8;

               /// <summary>
               /// Property Indexer for UserSpecifiedCostingMethod
               /// </summary>
               public const int UserSpecifiedCostingMethod = 9;

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 10;

               /// <summary>
               /// Property Indexer for PickingSequence
               /// </summary>
               public const int PickingSequence = 11;

               /// <summary>
               /// Property Indexer for StockItem
               /// </summary>
               public const int StockItem = 12;

               /// <summary>
               /// Property Indexer for KittingQuantity
               /// </summary>
               public const int KittingQuantity = 13;

               /// <summary>
               /// Property Indexer for ParentQuantityOrdered
               /// </summary>
               public const int ParentQuantityOrdered = 14;

               /// <summary>
               /// Property Indexer for ParentQuantityShipped
               /// </summary>
               public const int ParentQuantityShipped = 15;

               /// <summary>
               /// Property Indexer for ParentUnitOfMeasure
               /// </summary>
               public const int ParentUnitOfMeasure = 16;

               /// <summary>
               /// Property Indexer for ParentUnitConversion
               /// </summary>
               public const int ParentUnitConversion = 17;

               /// <summary>
               /// Property Indexer for QuantityOrdered
               /// </summary>
               public const int QuantityOrdered = 18;

               /// <summary>
               /// Property Indexer for QuantityShipped
               /// </summary>
               public const int QuantityShipped = 19;

               /// <summary>
               /// Property Indexer for POQuantityOrdered
               /// </summary>
               public const int POQuantityOrdered = 20;

               /// <summary>
               /// Property Indexer for OrderUnitOfMeasure
               /// </summary>
               public const int UnitOfMeasure = 21;

               /// <summary>
               /// Property Indexer for OrderUnitConversion
               /// </summary>
               public const int OrderUnitConversion = 22;

               /// <summary>
               /// Property Indexer for OrderUnitCost
               /// </summary>
               public const int OrderUnitCost = 23;

               /// <summary>
               /// Property Indexer for MostRecentUnitCost
               /// </summary>
               public const int MostRecentUnitCost = 24;

               /// <summary>
               /// Property Indexer for StandardUnitCost
               /// </summary>
               public const int StandardUnitCost = 25;

               /// <summary>
               /// Property Indexer for AlternateUnitCost1
               /// </summary>
               public const int AlternateUnitCost1 = 26;

               /// <summary>
               /// Property Indexer for AlternateUnitCost2
               /// </summary>
               public const int AlternateUnitCost2 = 27;

               /// <summary>
               /// Property Indexer for AverageUnitCost
               /// </summary>
               public const int AverageUnitCost = 28;

               /// <summary>
               /// Property Indexer for LastUnitCost
               /// </summary>
               public const int LastUnitCost = 29;

               /// <summary>
               /// Property Indexer for CostingUnitOfMeasure
               /// </summary>
               public const int CostingUnitOfMeasure = 30;

               /// <summary>
               /// Property Indexer for CostingUnitCost
               /// </summary>
               public const int CostingUnitCost = 31;

               /// <summary>
               /// Property Indexer for CostingUnitConversion
               /// </summary>
               public const int CostingUnitConversion = 32;

               /// <summary>
               /// Property Indexer for ExtendedOrderCost
               /// </summary>
               public const int ExtendedOrderCost = 33;

               /// <summary>
               /// Property Indexer for UnitWeight
               /// </summary>
               public const int UnitWeight = 34;

               /// <summary>
               /// Property Indexer for ExtendedWeight
               /// </summary>
               public const int ExtendedWeight = 35;

               /// <summary>
               /// Property Indexer for NonstockClearingAccount
               /// </summary>
               public const int NonstockClearingAccount = 37;

               /// <summary>
               /// Property Indexer for WeightUnitOfMeasure
               /// </summary>
               public const int WeightUnitOfMeasure = 38;

               /// <summary>
               /// Property Indexer for WeightConversionFactor
               /// </summary>
               public const int WeightConversionFactor = 39;

               /// <summary>
               /// Property Indexer for ParentWeightConversionFactor
               /// </summary>
               public const int ParentWeightConversionFactor = 40;

               /// <summary>
               /// Property Indexer for ParentWeightUOMUnitWeight
               /// </summary>
               public const int ParentWeightUOMUnitWeight = 41;

               /// <summary>
               /// Property Indexer for ParentWUOMExtendedUnitWeight
               /// </summary>
               public const int ParentWUOMExtendedUnitWeight = 42;

               /// <summary>
               /// Property Indexer for KitNo
               /// </summary>
               public const int KitNo = 43;

               /// <summary>
               /// Property Indexer for SerialQuantity
               /// </summary>
               public const int SerialQuantity = 44;

               /// <summary>
               /// Property Indexer for LotQuantity
               /// </summary>
               public const int LotQuantity = 45;

               /// <summary>
               /// Property Indexer for SerialQtyShipped
               /// </summary>
               public const int SerialQtyShipped = 46;

               /// <summary>
               /// Property Indexer for LotQtyShipped
               /// </summary>
               public const int LotQtyShipped = 47;

               /// <summary>
               /// Property Indexer for ItemSerializedLotted
               /// </summary>
               public const int ItemSerializedLotted = 48;

               /// <summary>
               /// Property Indexer for ComponentUnitCost
               /// </summary>
               public const int ComponentUnitCost = 100;

               /// <summary>
               /// Property Indexer for MostRecentComponentCost
               /// </summary>
               public const int MostRecentComponentCost = 101;

               /// <summary>
               /// Property Indexer for StandardComponentCost
               /// </summary>
               public const int StandardComponentCost = 102;

               /// <summary>
               /// Property Indexer for AlternateComponentCost1
               /// </summary>
               public const int AlternateComponentCost1 = 103;

               /// <summary>
               /// Property Indexer for AlternateComponentCost2
               /// </summary>
               public const int AlternateComponentCost2 = 104;

               /// <summary>
               /// Property Indexer for AverageComponentCost
               /// </summary>
               public const int AverageComponentCost = 105;

               /// <summary>
               /// Property Indexer for LastComponentCost
               /// </summary>
               public const int LastComponentCost = 106;

               /// <summary>
               /// Property Indexer for NonstockClearingAcctDesc
               /// </summary>
               public const int NonstockClearingAcctDesc = 107;

               /// <summary>
               /// Property Indexer for InterprocessCommID
               /// </summary>
               public const int InterprocessCommID = 108;

               /// <summary>
               /// Property Indexer for ForcePopupSNonQtyOrdered
               /// </summary>
               public const int ForcePopupSNonQtyOrdered = 109;

               /// <summary>
               /// Property Indexer for ForcePopupSNonQtyShipped
               /// </summary>
               public const int ForcePopupSNonQtyShipped = 110;

               /// <summary>
               /// Property Indexer for PopupSN
               /// </summary>
               public const int PopupSN = 111;

               /// <summary>
               /// Property Indexer for CloseSN
               /// </summary>
               public const int CloseSN = 112;

               /// <summary>
               /// Property Indexer for LTSetID
               /// </summary>
               public const int LTSetID = 113;

               /// <summary>
               /// Property Indexer for ForcePopupLTonQtyOrdered
               /// </summary>
               public const int ForcePopupLTonQtyOrdered = 114;

               /// <summary>
               /// Property Indexer for ForcePopupLTonQtyShipped
               /// </summary>
               public const int ForcePopupLTonQtyShipped = 115;

               /// <summary>
               /// Property Indexer for PopupLT
               /// </summary>
               public const int PopupLT = 116;

               /// <summary>
               /// Property Indexer for CloseLT
               /// </summary>
               public const int CloseLT = 117;

               /// <summary>
               /// Property Indexer for ComponentSerialized
               /// </summary>
               public const int ComponentSerialized = 118;

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 119;

               /// <summary>
               /// Property Indexer for ComponentLotted
               /// </summary>
               public const int ComponentLotted = 120;

               /// <summary>
               /// Property Indexer for WeightUOMDescription
               /// </summary>
               public const int WeightUomDescription = 121;

               /// <summary>
               /// Property Indexer for ProcessCommand
               /// </summary>
               public const int ProcessCommand = 122;

               /// <summary>
               /// Property Indexer for SerialLotQuantityToProcess
               /// </summary>
               public const int SerialLotQuantityToProcess = 123;

               /// <summary>
               /// Property Indexer for NumberOfLotsToGenerate
               /// </summary>
               public const int NumberOfLotsToGenerate = 124;

               /// <summary>
               /// Property Indexer for QuantityperLot
               /// </summary>
               public const int QuantityperLot = 125;

               /// <summary>
               /// Property Indexer for AllocateFromSerial
               /// </summary>
               public const int AllocateFromSerial = 126;

               /// <summary>
               /// Property Indexer for AllocateFromLot
               /// </summary>
               public const int AllocateFromLot = 127;

               /// <summary>
               /// Property Indexer for SerialLotWindowHandle
               /// </summary>
               public const int SerialLotWindowHandle = 128;

          }
          #endregion

     }
}
