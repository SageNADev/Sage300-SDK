// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of MultipleShipmentsToInvoice Constants
	/// </summary>
	public partial class MultipleShipmentsToInvoice
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0427";

		#region Properties

		/// <summary>
		/// Contains list of MultipleShipmentsToInvoice Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for InvoiceUniquifier
			/// </summary>
			public const string InvoiceUniquifier = "INVUNIQ";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "LINENUM";

			/// <summary>
			/// Property for ShipmentUniquifier
			/// </summary>
			public const string ShipmentUniquifier = "SHIUNIQ";

			/// <summary>
			/// Property for ShipmentNumber
			/// </summary>
			public const string ShipmentNumber = "SHINUMBER";

			/// <summary>
			/// Property for PONumber
			/// </summary>
			public const string PONumber = "PONUMBER";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of MultipleShipmentsToInvoice Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for InvoiceUniquifier
			/// </summary>
			public const int InvoiceUniquifier = 1;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 2;

			/// <summary>
			/// Property Indexer for ShipmentUniquifier
			/// </summary>
			public const int ShipmentUniquifier = 3;

			/// <summary>
			/// Property Indexer for ShipmentNumber
			/// </summary>
			public const int ShipmentNumber = 4;

			/// <summary>
			/// Property Indexer for PONumber
			/// </summary>
			public const int PONumber = 5;

		}

		#endregion

	}
}
