﻿// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of Template Constants
    /// </summary>
    public partial class Template
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0540";

        #region Properties
        /// <summary>
        /// Contains list of Template Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for TemplateCode
            /// </summary>
            public const string TemplateCode = "TEMPLATE";

            /// <summary>
            /// Property for TemplateDescription
            /// </summary>
            public const string TemplateDescription = "PLATEDESC";

            /// <summary>
            /// Property for DefaultOrderType
            /// </summary>
            public const string DefaultOrderType = "ORDTYPE";

            /// <summary>
            /// Property for DefaultFreeOnBoardPoint
            /// </summary>
            public const string DefaultFreeOnBoardPoint = "FOB";

            /// <summary>
            /// Property for DefaultOnHold
            /// </summary>
            public const string DefaultOnHold = "ONHOLD";

            /// <summary>
            /// Property for OnHoldString, UI Property
            /// </summary>
            public const string OnHoldString = "ONHOLD";

            /// <summary>
            /// Property for DefaultLocation
            /// </summary>
            public const string DefaultLocation = "LOCATION";

            /// <summary>
            /// Property for DefaultDescription
            /// </summary>
            public const string DefaultDescription = "DESC";

            /// <summary>
            /// Property for DefaultReference
            /// </summary>
            public const string DefaultReference = "REFERENCE";

            /// <summary>
            /// Property for DefaultComment
            /// </summary>
            public const string DefaultComment = "COMMENT";

            /// <summary>
            /// Property for DefaultShipViaCode
            /// </summary>
            public const string DefaultShipViaCode = "SHIPVIA";

            /// <summary>
            /// Property for DefaultCustomerType
            /// </summary>
            public const string DefaultCustomerType = "CUSTDISC";

            /// <summary>
            /// Property for DefaultPriceList
            /// </summary>
            public const string DefaultPriceList = "PRICELIST";

            /// <summary>
            /// Property for DefaultTerritory
            /// </summary>
            public const string DefaultTerritory = "TERRITORY";

            /// <summary>
            /// Property for DefaultTaxGroup
            /// </summary>
            public const string DefaultTaxGroup = "TAXGROUP";

            /// <summary>
            /// Property for DefaultPaymentTerms
            /// </summary>
            public const string DefaultPaymentTerms = "TERMS";

            /// <summary>
            /// Property for ShipViaCodeDescription
            /// </summary>
            public const string ShipViaCodeDescription = "SHPVIADESC";

            /// <summary>
            /// Property for PriceListCodeDescription
            /// </summary>
            public const string PriceListCodeDescription = "PCODDESC";

            /// <summary>
            /// Property for PaymentTermsDescription
            /// </summary>
            public const string PaymentTermsDescription = "TERMSDESC";

            /// <summary>
            /// Property for TaxGroupDescription
            /// </summary>
            public const string TaxGroupDescription = "TXGRPDESC";

            /// <summary>
            /// Property for LocationDescription
            /// </summary>
            public const string LocationDescription = "LOCDESC";

            /// <summary>
            /// Property for TaxGroupCurrency
            /// </summary>
            public const string TaxGroupCurrency = "CURRENCY";

            /// <summary>
            /// Property for OnholdReason
            /// </summary>
            public const string OnholdReason = "HOLDREASON";

            /// <summary>
            /// UI Property
            /// </summary>
            public const string CustomerTypeDescription = "CUSTDISC";

            /// <summary>
            /// UI Property
            /// </summary>
            public const string OrderTypeDescription = "ORDTYPE";

            /// <summary>
            /// Property for DefaultCustomerAccountSet
            /// </summary>
            public const string DefaultCustomerAccountSet = "CUSACCTSET";

            /// <summary>
            /// Property for CustomerAccountSetDescription
            /// </summary>
            public const string CustomerAccountSetDescription = "ACCSETDESC";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of Template Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for TemplateCode
            /// </summary>
            public const int TemplateCode = 1;

            /// <summary>
            /// Property Indexer for TemplateDescription
            /// </summary>
            public const int TemplateDescription = 2;

            /// <summary>
            /// Property Indexer for DefaultOrderType
            /// </summary>
            public const int DefaultOrderType = 3;

            /// <summary>
            /// Property Indexer for DefaultFreeOnBoardPoint
            /// </summary>
            public const int DefaultFreeOnBoardPoint = 4;

            /// <summary>
            /// Property Indexer for DefaultOnHold
            /// </summary>
            public const int DefaultOnHold = 5;

            /// <summary>
            /// Property Indexer for DefaultOnHold
            /// </summary>
            public const int OnHoldString = 5;


            /// <summary>
            /// Property Indexer for DefaultLocation
            /// </summary>
            public const int DefaultLocation = 6;

            /// <summary>
            /// Property Indexer for DefaultDescription
            /// </summary>
            public const int DefaultDescription = 7;

            /// <summary>
            /// Property Indexer for DefaultReference
            /// </summary>
            public const int DefaultReference = 8;

            /// <summary>
            /// Property Indexer for DefaultComment
            /// </summary>
            public const int DefaultComment = 9;

            /// <summary>
            /// Property Indexer for DefaultShipViaCode
            /// </summary>
            public const int DefaultShipViaCode = 10;

            /// <summary>
            /// Property Indexer for DefaultCustomerType
            /// </summary>
            public const int DefaultCustomerType = 11;

            /// <summary>
            /// Property Indexer for DefaultPriceList
            /// </summary>
            public const int DefaultPriceList = 12;

            /// <summary>
            /// Property Indexer for DefaultTerritory
            /// </summary>
            public const int DefaultTerritory = 13;

            /// <summary>
            /// Property Indexer for DefaultTaxGroup
            /// </summary>
            public const int DefaultTaxGroup = 14;

            /// <summary>
            /// Property Indexer for DefaultPaymentTerms
            /// </summary>
            public const int DefaultPaymentTerms = 15;

            /// <summary>
            /// Property Indexer for ShipViaCodeDescription
            /// </summary>
            public const int ShipViaCodeDescription = 16;

            /// <summary>
            /// Property Indexer for PriceListCodeDescription
            /// </summary>
            public const int PriceListCodeDescription = 17;

            /// <summary>
            /// Property Indexer for PaymentTermsDescription
            /// </summary>
            public const int PaymentTermsDescription = 18;

            /// <summary>
            /// Property Indexer for TaxGroupDescription
            /// </summary>
            public const int TaxGroupDescription = 19;

            /// <summary>
            /// Property Indexer for LocationDescription
            /// </summary>
            public const int LocationDescription = 20;

            /// <summary>
            /// Property Indexer for TaxGroupCurrency
            /// </summary>
            public const int TaxGroupCurrency = 21;

            /// <summary>
            /// Property Indexer for OnholdReason
            /// </summary>
            public const int OnholdReason = 22;

            /// <summary>
            /// Property Indexer for DefaultCustomerAccountSet
            /// </summary>
            public const int DefaultCustomerAccountSet = 23;

            /// <summary>
            /// Property Indexer for CustomerAccountSetDescription
            /// </summary>
            public const int CustomerAccountSetDescription = 24;

        }
        #endregion

    }
}
