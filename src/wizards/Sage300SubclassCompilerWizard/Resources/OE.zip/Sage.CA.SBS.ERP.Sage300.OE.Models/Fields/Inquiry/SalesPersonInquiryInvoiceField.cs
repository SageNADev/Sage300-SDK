﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Fields.Inquiry
{
    public class SalesPersonInquiryInvoiceField
    {
        /// <summary>
        /// SalesPersonInquiry Invoice Report
        /// </summary>
        public const string EntityName = "1B44D6EB-DD34-409F-8A29-492AE96FA766";

        #region Field Properties

        /// <summary>
        /// Contains list of SalesPersonInquiry Invoice Report Field Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Field property for SortFrom
            /// </summary>
            public const string SortFrom = "SORTFROM";

            /// <summary>
            /// Field property for SortTo
            /// </summary>
            public const string SortTo = "SORTTO";
            /// <summary>
            /// Field property for Printed
            /// </summary>
            public const string Printed = "PRINTED";

            /// <summary>
            /// Field property for  QtyDecimal
            /// </summary>
            public const string QtyDecimal = "QTYDEC";

            /// <summary>
            /// Field property for DeliveryMethod 
            /// </summary>
            public const string DeliveryMethod = "DELMETHOD";

            /// <summary>
            /// Field property for  Ecenabled
            /// </summary>
            public const string Ecenabled = "ECENABLED";

            /// <summary>
            /// Field property for  Directec
            /// </summary>
            public const string Directec = "DIRECTEC";

            /// <summary>
            /// Field property for  Swdelmethod
            /// </summary>
            public const string Swdelmethod = "SWDELMETHOD";

            /// <summary>
            /// Field property for BoItem
            /// </summary>
            public const string BoItem = "BOITEM";

            /// <summary>
            /// Field property for PrintKit
            /// </summary>
            public const string PrintKit = "PRINTKIT";

            /// <summary>
            /// Field property for  Printbom
            /// </summary>
            public const string Printbom = "PRINTBOM";

            /// <summary>
            /// Field property for Retainage
            /// </summary>
            public const string Retainage = "RETAINAGE";

            /// <summary>
            /// Field property for Serial Lot Numbers
            /// </summary>
            public const string SerialLotNumbers = "SERIALLOTNUMBERS";

            #endregion
        }

        #endregion

        #region Index Properties
        /// <summary>
        /// Contains list of SalesPersonInquiry Invoice Report Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            ///Property Index for SortFrom
            /// </summary>
            public const string SortFrom = "2";

            /// <summary>
            /// Property Index for SortTo
            /// </summary>
            public const string SortTo = "3";

            /// <summary>
            /// Property Index for Printed
            /// </summary>
            public const string Printed = "4";

            /// <summary>
            /// Property Index for  QtyDecimal
            /// </summary>
            public const string QtyDecimal = "5";

            /// <summary>
            /// Property Index for DeliveryMethod 
            /// </summary>
            public const string DeliveryMethod = "6";

            /// <summary>
            /// Property Index for  Ecenabled
            /// </summary>
            public const string Ecenabled = "7";

            /// <summary>
            /// Property Index for  Directec
            /// </summary>
            public const string Directec = "8";

            /// <summary>
            ///Property Index for BoItem
            /// </summary>
            public const string BoItem = "9";

            /// <summary>
            /// Property Index for  Swdelmethod
            /// </summary>
            public const string Swdelmethod = "10";

            /// <summary>
            /// Property Index for PrintKit
            /// </summary>
            public const string PrintKit = "11";

            /// <summary>
            /// Property Index for Printbom
            /// </summary>
            public const string Printbom = "12";

            /// <summary>
            /// Property Index for Retainage
            /// </summary>
            public const string Retainage = "13";

            /// <summary>
            /// Property Index for Serial Lot Numbers
            /// </summary>
            public const string SerialLotNumbers = "14";

            #endregion
        }

        #endregion
    }
}
