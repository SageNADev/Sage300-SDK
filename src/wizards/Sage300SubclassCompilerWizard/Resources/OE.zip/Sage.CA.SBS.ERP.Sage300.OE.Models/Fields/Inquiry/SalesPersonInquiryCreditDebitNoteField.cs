﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Fields.Inquiry
{
   public class SalesPersonInquiryCreditDebitNoteField
    {
        /// <summary>
        /// SalesPersonInquiry Credit/Debit note Report
        /// </summary>
       public const string EntityName = "57FE20C6-A2D1-412D-B7EE-5D7249122B46";

       #region Field Properties

       /// <summary>
       /// Contains list of SalesPersonInquiry Invoice Report Field Constants
       /// </summary>
       public class Fields
       {
           #region Properties

           /// <summary>
           /// Field property for SortFrom
           /// </summary>
           public const string SortFrom = "SORTFROM";

           /// <summary>
           /// Field property for SortTo
           /// </summary>
           public const string SortTo = "SORTTO";

           /// <summary>
           /// Field property for Printed
           /// </summary>
           public const string Printed = "PRINTED";

           /// <summary>
           /// Field property for  QtyDecimal
           /// </summary>
           public const string QtyDecimal = "QTYDEC";

           /// <summary>
           /// Field property for  Swdelmethod
           /// </summary>
           public const string Swdelmethod = "SWDELMETHOD";

           /// <summary>
           /// Field property for AdjustmentType 
           /// </summary>
           public const string AdjustmentType = "ADJTYPE";

           /// <summary>
           /// Field property for PrintKit
           /// </summary>
           public const string PrintKit = "PRINTKIT";

           /// <summary>
           /// Field property for  Printbom
           /// </summary>
           public const string Printbom = "PRINTBOM";

           /// <summary>
           /// Field property for  TaxInformation
           /// </summary>
           public const string TaxInformation = "TAXINFORMATION";
            
           /// <summary>
           /// Field property for Retainage
           /// </summary>
           public const string Retainage = "RETAINAGE";

           /// <summary>
           /// Field property for Serial Lot Numbers
           /// </summary>
           public const string SerialLotNumbers = "SERIALLOTNUMBERS";

           #endregion
       }

       #endregion

       #region Index Properties

       /// <summary>
       /// Contains list of SalesPersonInquiry Invoice Report Index Constants
       /// </summary>
       public class Index
       {
           #region Properties

           /// <summary>
           ///Property Index for SortFrom
           /// </summary>
           public const string SortFrom = "2";

           /// <summary>
           /// Property Index for SortTo
           /// </summary>
           public const string SortTo = "3";

           /// <summary>
           /// Property Index for Printed
           /// </summary>
           public const string Printed = "4";

           /// <summary>
           /// Property Index for  QtyDecimal
           /// </summary>
           public const string QtyDecimal = "5";

           /// <summary>
           /// Property Index for Swdelmethod 
           /// </summary>
           public const string Swdelmethod = "6";

           /// <summary>
           /// Property Index for AdjustmentType 
           /// </summary>
           public const string AdjustmentType = "7";

           /// <summary>
           /// Property Index for PrintKit
           /// </summary>
           public const string PrintKit = "8";

           /// <summary>
           /// Property Index for  Printbom
           /// </summary>
           public const string Printbom = "9";

           /// <summary>
           /// Property Index for  TaxInformation
           /// </summary>
           public const string TaxInformation = "10";

           /// <summary>
           /// Property Index for Retainage
           /// </summary>
           public const string Retainage = "11";

           /// <summary>
           /// Property Index for Serial Lot Numbers
           /// </summary>
           public const string SerialLotNumbers = "12"; 

           #endregion
       }

       #endregion
    }
}
