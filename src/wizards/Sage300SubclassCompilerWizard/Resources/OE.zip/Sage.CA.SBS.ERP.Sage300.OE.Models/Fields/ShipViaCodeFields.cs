﻿/*Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.*/

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of Ship-Via Code Constants
    /// </summary>
    public partial class ShipViaCode
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0760";

        #region Properties
        /// <summary>
        /// Contains list of Ship-Via Code Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Code
            /// </summary>
            public const string Code = "CODE";

            /// <summary>
            /// Property for Name
            /// </summary>
            public const string Name = "NAME";

            /// <summary>
            /// Property for AddressLine1
            /// </summary>
            public const string AddressLine1 = "ADDRESS1";

            /// <summary>
            /// Property for AddressLine2
            /// </summary>
            public const string AddressLine2 = "ADDRESS2";

            /// <summary>
            /// Property for AddressLine3
            /// </summary>
            public const string AddressLine3 = "ADDRESS3";

            /// <summary>
            /// Property for AddressLine4
            /// </summary>
            public const string AddressLine4 = "ADDRESS4";

            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "CITY";

            /// <summary>
            /// Property for StateProvince
            /// </summary>
            public const string StateProvince = "STATE";

            /// <summary>
            /// Property for ZipPostalCode
            /// </summary>
            public const string ZipPostalCode = "ZIP";

            /// <summary>
            /// Property for Country
            /// </summary>
            public const string Country = "COUNTRY";

            /// <summary>
            /// Property for PhoneNumber
            /// </summary>
            public const string PhoneNumber = "PHONE";

            /// <summary>
            /// Property for FaxNumber
            /// </summary>
            public const string FaxNumber = "FAX";

            /// <summary>
            /// Property for Contact
            /// </summary>
            public const string Contact = "CONTACT";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for ShipViaEmail
            /// </summary>
            public const string ShipViaEmail = "EMAIL";

            /// <summary>
            /// Property for ContactPhone
            /// </summary>
            public const string ContactPhone = "PHONEC";

            /// <summary>
            /// Property for ContactFax
            /// </summary>
            public const string ContactFax = "FAXC";

            /// <summary>
            /// Property for ContactEmail
            /// </summary>
            public const string ContactEmail = "EMAILC";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of Ship-Via Code Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Code
            /// </summary>
            public const int Code = 1;

            /// <summary>
            /// Property Indexer for Name
            /// </summary>
            public const int Name = 2;

            /// <summary>
            /// Property Indexer for AddressLine1
            /// </summary>
            public const int AddressLine1 = 3;

            /// <summary>
            /// Property Indexer for AddressLine2
            /// </summary>
            public const int AddressLine2 = 4;

            /// <summary>
            /// Property Indexer for AddressLine3
            /// </summary>
            public const int AddressLine3 = 5;

            /// <summary>
            /// Property Indexer for AddressLine4
            /// </summary>
            public const int AddressLine4 = 6;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 7;

            /// <summary>
            /// Property Indexer for StateProvince
            /// </summary>
            public const int StateProvince = 8;

            /// <summary>
            /// Property Indexer for ZipPostalCode
            /// </summary>
            public const int ZipPostalCode = 9;

            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 10;

            /// <summary>
            /// Property Indexer for PhoneNumber
            /// </summary>
            public const int PhoneNumber = 11;

            /// <summary>
            /// Property Indexer for FaxNumber
            /// </summary>
            public const int FaxNumber = 12;

            /// <summary>
            /// Property Indexer for Contact
            /// </summary>
            public const int Contact = 13;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 14;

            /// <summary>
            /// Property Indexer for ShipViaEmail
            /// </summary>
            public const int ShipViaEmail = 15;

            /// <summary>
            /// Property Indexer for ContactPhone
            /// </summary>
            public const int ContactPhone = 16;

            /// <summary>
            /// Property Indexer for ContactFax
            /// </summary>
            public const int ContactFax = 17;

            /// <summary>
            /// Property Indexer for ContactEmail
            /// </summary>
            public const int ContactEmail = 18;
        }
        #endregion
    }
}
