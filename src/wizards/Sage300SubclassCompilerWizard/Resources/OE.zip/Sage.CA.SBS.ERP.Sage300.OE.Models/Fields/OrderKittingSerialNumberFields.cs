// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of OrderKittingSerialNumber Constants
     /// </summary>
     public partial class OrderKittingSerialNumber
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "OE0504";

          #region Properties
          /// <summary>
          /// Contains list of OrderKittingSerialNumber Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for OrderUniquifier
               /// </summary>
               public const string OrderUniquifier = "ORDUNIQ";

               /// <summary>
               /// Property for DetailLineNumber
               /// </summary>
               public const string DetailLineNumber = "LINENUM";

               /// <summary>
               /// Property for ParentComponentNumber
               /// </summary>
               public const string ParentComponentNumber = "PRNCOMPNUM";

               /// <summary>
               /// Property for ComponentNumber
               /// </summary>
               public const string ComponentNumber = "COMPNUM";

               /// <summary>
               /// Property for SerialNumber
               /// </summary>
               public const string SerialNumber = "SERIALNUMF";

               /// <summary>
               /// Property for DetailNumber
               /// </summary>
               public const string DetailNumber = "DETAILNUM";

               /// <summary>
               /// Property for Shipped
               /// </summary>
               public const string Shipped = "MOVED";

               /// <summary>
               /// Property for TransactionQuantity
               /// </summary>
               public const string TransactionQuantity = "QTY";

               /// <summary>
               /// Property for QuantityShipped
               /// </summary>
               public const string QuantityShipped = "QTYMOVED";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of OrderKittingSerialNumber Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for OrderUniquifier
               /// </summary>
               public const int OrderUniquifier = 1;

               /// <summary>
               /// Property Indexer for DetailLineNumber
               /// </summary>
               public const int DetailLineNumber = 2;

               /// <summary>
               /// Property Indexer for ParentComponentNumber
               /// </summary>
               public const int ParentComponentNumber = 3;

               /// <summary>
               /// Property Indexer for ComponentNumber
               /// </summary>
               public const int ComponentNumber = 4;

               /// <summary>
               /// Property Indexer for SerialNumber
               /// </summary>
               public const int SerialNumber = 5;

               /// <summary>
               /// Property Indexer for DetailNumber
               /// </summary>
               public const int DetailNumber = 6;

               /// <summary>
               /// Property Indexer for Shipped
               /// </summary>
               public const int Shipped = 7;

               /// <summary>
               /// Property Indexer for TransactionQuantity
               /// </summary>
               public const int TransactionQuantity = 50;

               /// <summary>
               /// Property Indexer for QuantityShipped
               /// </summary>
               public const int QuantityShipped = 51;

          }
          #endregion

     }
}
