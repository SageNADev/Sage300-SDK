// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of InvoiceKittingDetail Constants
	/// </summary>
	public partial class InvoiceKittingDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0402";

		#region Properties

		/// <summary>
		/// Contains list of InvoiceKittingDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for InvoiceUniquifier
			/// </summary>
			public const string InvoiceUniquifier = "INVUNIQ";

			/// <summary>
			/// Property for DetailLineNumber
			/// </summary>
			public const string DetailLineNumber = "LINENUM";

			/// <summary>
			/// Property for ParentComponentNumber
			/// </summary>
			public const string ParentComponentNumber = "PRNCOMPNUM";

			/// <summary>
			/// Property for ComponentNumber
			/// </summary>
			public const string ComponentNumber = "COMPNUM";

			/// <summary>
			/// Property for DetailNumber
			/// </summary>
			public const string DetailNumber = "DETAILNUM";

			/// <summary>
			/// Property for ComponentItem
			/// </summary>
			public const string ComponentItem = "COMPONENT";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "DESC";

			/// <summary>
			/// Property for ItemAccountSet
			/// </summary>
			public const string ItemAccountSet = "ACCTSET";

			/// <summary>
			/// Property for UserSpecifiedCostingMethod
			/// </summary>
			public const string UserSpecifiedCostingMethod = "USERCOSTMD";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for PickingSequence
			/// </summary>
			public const string PickingSequence = "PICKSEQ";

			/// <summary>
			/// Property for StockItem
			/// </summary>
			public const string StockItem = "STOCKITEM";

			/// <summary>
			/// Property for KittingQuantity
			/// </summary>
			public const string KittingQuantity = "QTY";

			/// <summary>
			/// Property for ParentQuantityShipped
			/// </summary>
			public const string ParentQuantityShipped = "PRNQTYSHIP";

			/// <summary>
			/// Property for ParentUnitOfMeasure
			/// </summary>
			public const string ParentUnitOfMeasure = "PRNUNIT";

			/// <summary>
			/// Property for ParentUnitConversion
			/// </summary>
			public const string ParentUnitConversion = "PRNUNTCONV";

			/// <summary>
			/// Property for QuantityShipped
			/// </summary>
			public const string QuantityShipped = "QTYSHIPPED";

			/// <summary>
			/// Property for InvoiceUnitOfMeasure
			/// </summary>
			public const string InvoiceUnitOfMeasure = "INVUNIT";

			/// <summary>
			/// Property for InvoiceUnitConversion
			/// </summary>
			public const string InvoiceUnitConversion = "UNITCONV";

			/// <summary>
			/// Property for InvoiceUnitCost
			/// </summary>
			public const string InvoiceUnitCost = "UNITCOST";

			/// <summary>
			/// Property for MostRecentUnitCost
			/// </summary>
			public const string MostRecentUnitCost = "MOSTREC";

			/// <summary>
			/// Property for StandardUnitCost
			/// </summary>
			public const string StandardUnitCost = "STDCOST";

			/// <summary>
			/// Property for AlternateUnitCost1
			/// </summary>
			public const string AlternateUnitCost1 = "COST1";

			/// <summary>
			/// Property for AlternateUnitCost2
			/// </summary>
			public const string AlternateUnitCost2 = "COST2";

			/// <summary>
			/// Property for AverageUnitCost
			/// </summary>
			public const string AverageUnitCost = "AVGCOST";

			/// <summary>
			/// Property for LastUnitCost
			/// </summary>
			public const string LastUnitCost = "LASTCOST";

			/// <summary>
			/// Property for CostingUnitOfMeasure
			/// </summary>
			public const string CostingUnitOfMeasure = "COSTUNIT";

			/// <summary>
			/// Property for CostingUnitCost
			/// </summary>
			public const string CostingUnitCost = "COSUNTCST";

			/// <summary>
			/// Property for CostingUnitConversion
			/// </summary>
			public const string CostingUnitConversion = "COSUNTCONV";

			/// <summary>
			/// Property for ExtendedInvoiceCost
			/// </summary>
			public const string ExtendedInvoiceCost = "EXTICOST";

			/// <summary>
			/// Property for UnitWeight
			/// </summary>
			public const string UnitWeight = "UNITWEIGHT";

			/// <summary>
			/// Property for ExtendedWeight
			/// </summary>
			public const string ExtendedWeight = "EXTWEIGHT";

			/// <summary>
			/// Property for NonstockClearingAccount
			/// </summary>
			public const string NonstockClearingAccount = "GLNONSTKCR";

			/// <summary>
			/// Property for WeightUnitOfMeasure
			/// </summary>
			public const string WeightUnitOfMeasure = "WEIGHTUNIT";

			/// <summary>
			/// Property for WeightConversionFactor
			/// </summary>
			public const string WeightConversionFactor = "WEIGHTCONV";

			/// <summary>
			/// Property for ParentWeightConversionFactor
			/// </summary>
			public const string ParentWeightConversionFactor = "PRNWGTCONV";

			/// <summary>
			/// Property for ParentWeightUOMUnitWeight
			/// </summary>
			public const string ParentWeightUOMUnitWeight = "PRNUWEIGHT";

			/// <summary>
			/// Property for ParentWUOMExtendedUnitWeight
			/// </summary>
			public const string ParentWUOMExtendedUnitWeight = "PRNEXTWGHT";

			/// <summary>
			/// Property for KitNo
			/// </summary>
			public const string KitNo = "DDTLNO";

			/// <summary>
			/// Property for CostOfGoods
			/// </summary>
			public const string CostOfGoods = "COG";

			/// <summary>
			/// Property for RecordCosted
			/// </summary>
			public const string RecordCosted = "COSTED";

			/// <summary>
			/// Property for SerialQuantity
			/// </summary>
			public const string SerialQuantity = "SERIALQTY";

			/// <summary>
			/// Property for LotQuantity
			/// </summary>
			public const string LotQuantity = "LOTQTY";

			/// <summary>
			/// Property for ItemSerializedLotted
			/// </summary>
			public const string ItemSerializedLotted = "SLITEM";

			/// <summary>
			/// Property for ComponentUnitCost
			/// </summary>
			public const string ComponentUnitCost = "CMPUNTCOST";

			/// <summary>
			/// Property for MostRecentComponentCost
			/// </summary>
			public const string MostRecentComponentCost = "CMPMOSTREC";

			/// <summary>
			/// Property for StandardComponentCost
			/// </summary>
			public const string StandardComponentCost = "CMPSTDCOST";

			/// <summary>
			/// Property for AlternateComponentCost1
			/// </summary>
			public const string AlternateComponentCost1 = "CMPCOST1";

			/// <summary>
			/// Property for AlternateComponentCost2
			/// </summary>
			public const string AlternateComponentCost2 = "CMPCOST2";

			/// <summary>
			/// Property for AverageComponentCost
			/// </summary>
			public const string AverageComponentCost = "CMPAVGCOST";

			/// <summary>
			/// Property for LastComponentCost
			/// </summary>
			public const string LastComponentCost = "CMPLSTCOST";

			/// <summary>
			/// Property for NonstockClearingAcctDesc
			/// </summary>
			public const string NonstockClearingAcctDesc = "GLNONSTKCD";

			/// <summary>
			/// Property for WeightUOMDescription
			/// </summary>
			public const string WeightUOMDescription = "WUOMDESC";

			/// <summary>
			/// Property for ProcessCommand
			/// </summary>
			public const string ProcessCommand = "PROCESSCMD";

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property for UNFMTITEM
			/// </summary>
			public const string UNFMTITEM = "UNFMTITEM";

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property for ORDNUMBER
			/// </summary>
			public const string ORDNUMBER = "ORDNUMBER";

			/// <summary>
			/// Property for SerialLotQuantityToProcess
			/// </summary>
			public const string SerialLotQuantityToProcess = "XGENALCQTY";

			/// <summary>
			/// Property for NumberOfLotsToGenerate
			/// </summary>
			public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

			/// <summary>
			/// Property for QuantityperLot
			/// </summary>
			public const string QuantityperLot = "XPERLOTQTY";

			/// <summary>
			/// Property for ComponentSerialized
			/// </summary>
			public const string ComponentSerialized = "SERIALITEM";

			/// <summary>
			/// Property for ComponentLotted
			/// </summary>
			public const string ComponentLotted = "LOTTEDITEM";

			/// <summary>
			/// Property for AllocateFromSerial
			/// </summary>
			public const string AllocateFromSerial = "SALLOCFROM";

			/// <summary>
			/// Property for AllocateFromLot
			/// </summary>
			public const string AllocateFromLot = "LALLOCFROM";

			/// <summary>
			/// Property for SerialLotWindowHandle
			/// </summary>
			public const string SerialLotWindowHandle = "METERHWND";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of InvoiceKittingDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for InvoiceUniquifier
			/// </summary>
			public const int InvoiceUniquifier = 1;

			/// <summary>
			/// Property Indexer for DetailLineNumber
			/// </summary>
			public const int DetailLineNumber = 2;

			/// <summary>
			/// Property Indexer for ParentComponentNumber
			/// </summary>
			public const int ParentComponentNumber = 3;

			/// <summary>
			/// Property Indexer for ComponentNumber
			/// </summary>
			public const int ComponentNumber = 4;

			/// <summary>
			/// Property Indexer for DetailNumber
			/// </summary>
			public const int DetailNumber = 5;

			/// <summary>
			/// Property Indexer for ComponentItem
			/// </summary>
			public const int ComponentItem = 6;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 7;

			/// <summary>
			/// Property Indexer for ItemAccountSet
			/// </summary>
			public const int ItemAccountSet = 8;

			/// <summary>
			/// Property Indexer for UserSpecifiedCostingMethod
			/// </summary>
			public const int UserSpecifiedCostingMethod = 9;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 10;

			/// <summary>
			/// Property Indexer for PickingSequence
			/// </summary>
			public const int PickingSequence = 11;

			/// <summary>
			/// Property Indexer for StockItem
			/// </summary>
			public const int StockItem = 12;

			/// <summary>
			/// Property Indexer for KittingQuantity
			/// </summary>
			public const int KittingQuantity = 13;

			/// <summary>
			/// Property Indexer for ParentQuantityShipped
			/// </summary>
			public const int ParentQuantityShipped = 14;

			/// <summary>
			/// Property Indexer for ParentUnitOfMeasure
			/// </summary>
			public const int ParentUnitOfMeasure = 15;

			/// <summary>
			/// Property Indexer for ParentUnitConversion
			/// </summary>
			public const int ParentUnitConversion = 16;

			/// <summary>
			/// Property Indexer for QuantityShipped
			/// </summary>
            public const int QuantityOrdered = 17;

			/// <summary>
			/// Property Indexer for InvoiceUnitOfMeasure
			/// </summary>
			public const int InvoiceUnitOfMeasure = 18;

			/// <summary>
			/// Property Indexer for InvoiceUnitConversion
			/// </summary>
			public const int InvoiceUnitConversion = 19;

			/// <summary>
			/// Property Indexer for InvoiceUnitCost
			/// </summary>
			public const int InvoiceUnitCost = 20;

			/// <summary>
			/// Property Indexer for MostRecentUnitCost
			/// </summary>
			public const int MostRecentUnitCost = 21;

			/// <summary>
			/// Property Indexer for StandardUnitCost
			/// </summary>
			public const int StandardUnitCost = 22;

			/// <summary>
			/// Property Indexer for AlternateUnitCost1
			/// </summary>
			public const int AlternateUnitCost1 = 23;

			/// <summary>
			/// Property Indexer for AlternateUnitCost2
			/// </summary>
			public const int AlternateUnitCost2 = 24;

			/// <summary>
			/// Property Indexer for AverageUnitCost
			/// </summary>
			public const int AverageUnitCost = 25;

			/// <summary>
			/// Property Indexer for LastUnitCost
			/// </summary>
			public const int LastUnitCost = 26;

			/// <summary>
			/// Property Indexer for CostingUnitOfMeasure
			/// </summary>
			public const int CostingUnitOfMeasure = 27;

			/// <summary>
			/// Property Indexer for CostingUnitCost
			/// </summary>
			public const int CostingUnitCost = 28;

			/// <summary>
			/// Property Indexer for CostingUnitConversion
			/// </summary>
			public const int CostingUnitConversion = 29;

			/// <summary>
			/// Property Indexer for ExtendedInvoiceCost
			/// </summary>
			public const int ExtendedInvoiceCost = 30;

			/// <summary>
			/// Property Indexer for UnitWeight
			/// </summary>
			public const int UnitWeight = 31;

			/// <summary>
			/// Property Indexer for ExtendedWeight
			/// </summary>
			public const int ExtendedWeight = 32;

			/// <summary>
			/// Property Indexer for NonstockClearingAccount
			/// </summary>
			public const int NonstockClearingAccount = 34;

			/// <summary>
			/// Property Indexer for WeightUnitOfMeasure
			/// </summary>
			public const int WeightUnitOfMeasure = 35;

			/// <summary>
			/// Property Indexer for WeightConversionFactor
			/// </summary>
			public const int WeightConversionFactor = 36;

			/// <summary>
			/// Property Indexer for ParentWeightConversionFactor
			/// </summary>
			public const int ParentWeightConversionFactor = 37;

			/// <summary>
			/// Property Indexer for ParentWeightUOMUnitWeight
			/// </summary>
			public const int ParentWeightUOMUnitWeight = 38;

			/// <summary>
			/// Property Indexer for ParentWUOMExtendedUnitWeight
			/// </summary>
			public const int ParentWUOMExtendedUnitWeight = 39;

			/// <summary>
			/// Property Indexer for KitNo
			/// </summary>
			public const int KitNo = 40;

			/// <summary>
			/// Property Indexer for CostOfGoods
			/// </summary>
			public const int CostOfGoods = 41;

			/// <summary>
			/// Property Indexer for RecordCosted
			/// </summary>
			public const int RecordCosted = 42;

			/// <summary>
			/// Property Indexer for SerialQuantity
			/// </summary>
			public const int SerialQuantity = 43;

			/// <summary>
			/// Property Indexer for LotQuantity
			/// </summary>
			public const int LotQuantity = 44;

			/// <summary>
			/// Property Indexer for ItemSerializedLotted
			/// </summary>
			public const int ItemSerializedLotted = 45;

			/// <summary>
			/// Property Indexer for ComponentUnitCost
			/// </summary>
			public const int ComponentUnitCost = 100;

			/// <summary>
			/// Property Indexer for MostRecentComponentCost
			/// </summary>
			public const int MostRecentComponentCost = 101;

			/// <summary>
			/// Property Indexer for StandardComponentCost
			/// </summary>
			public const int StandardComponentCost = 102;

			/// <summary>
			/// Property Indexer for AlternateComponentCost1
			/// </summary>
			public const int AlternateComponentCost1 = 103;

			/// <summary>
			/// Property Indexer for AlternateComponentCost2
			/// </summary>
			public const int AlternateComponentCost2 = 104;

			/// <summary>
			/// Property Indexer for AverageComponentCost
			/// </summary>
			public const int AverageComponentCost = 105;

			/// <summary>
			/// Property Indexer for LastComponentCost
			/// </summary>
			public const int LastComponentCost = 106;

			/// <summary>
			/// Property Indexer for NonstockClearingAcctDesc
			/// </summary>
			public const int NonstockClearingAcctDesc = 107;

			/// <summary>
			/// Property Indexer for WeightUOMDescription
			/// </summary>
			public const int WeightUOMDescription = 108;

			/// <summary>
			/// Property Indexer for ProcessCommand
			/// </summary>
			public const int ProcessCommand = 109;

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property Indexer for UNFMTITEM
			/// </summary>
			public const int UNFMTITEM = 110;

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property Indexer for ORDNUMBER
			/// </summary>
			public const int ORDNUMBER = 111;

			/// <summary>
			/// Property Indexer for SerialLotQuantityToProcess
			/// </summary>
			public const int SerialLotQuantityToProcess = 112;

			/// <summary>
			/// Property Indexer for NumberOfLotsToGenerate
			/// </summary>
			public const int NumberOfLotsToGenerate = 113;

			/// <summary>
			/// Property Indexer for QuantityperLot
			/// </summary>
			public const int QuantityperLot = 114;

			/// <summary>
			/// Property Indexer for ComponentSerialized
			/// </summary>
			public const int ComponentSerialized = 115;

			/// <summary>
			/// Property Indexer for ComponentLotted
			/// </summary>
			public const int ComponentLotted = 116;

			/// <summary>
			/// Property Indexer for AllocateFromSerial
			/// </summary>
			public const int AllocateFromSerial = 117;

			/// <summary>
			/// Property Indexer for AllocateFromLot
			/// </summary>
			public const int AllocateFromLot = 118;

			/// <summary>
			/// Property Indexer for SerialLotWindowHandle
			/// </summary>
			public const int SerialLotWindowHandle = 119;

		}

		#endregion

	}
}
