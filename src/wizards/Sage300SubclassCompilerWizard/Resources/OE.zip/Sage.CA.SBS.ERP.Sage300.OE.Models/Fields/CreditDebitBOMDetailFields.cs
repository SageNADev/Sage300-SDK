// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of CreditDebitBOMDetail Constants
     /// </summary>
     public partial class CreditDebitBomDetail
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "OE0223";

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitBOMDetail Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CNUniquifier
               /// </summary>
               public const string CNUniquifier = "CRDUNIQ";

               /// <summary>
               /// Property for DetailLineNumber
               /// </summary>
               public const string DetailLineNumber = "LINENUM";

               /// <summary>
               /// Property for ParentComponentNumber
               /// </summary>
               public const string ParentComponentNumber = "PRNCOMPNUM";

               /// <summary>
               /// Property for ComponentNumber
               /// </summary>
               public const string ComponentNumber = "COMPNUM";

               /// <summary>
               /// Property for ComponentItemNo
               /// </summary>
               public const string ComponentItemNo = "COMPONENT";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for ComponentQuantity
               /// </summary>
               public const string ComponentQuantity = "QTY";

               /// <summary>
               /// Property for UnitOfMeasure
               /// </summary>
               public const string UnitOfMeasure = "UNIT";

               /// <summary>
               /// Property for QuantityReturned
               /// </summary>
               public const string QuantityReturned = "QTYRETURN";

               /// <summary>
               /// Property for ComponentsBOMNumber
               /// </summary>
               public const string ComponentsBOMNumber = "DDTLNO";

               /// <summary>
               /// Property for ComponentsBOMBuildQty
               /// </summary>
               public const string ComponentsBOMBuildQty = "BUILDQTY";

               /// <summary>
               /// Property for ComponentsBOMBuildUnit
               /// </summary>
               public const string ComponentsBOMBuildUnit = "BUILDUNIT";

               /// <summary>
               /// Property for ComponentsBOMBuildUnitConv
               /// </summary>
               public const string ComponentsBOMBuildUnitConv = "BLDUNTCONV";

               /// <summary>
               /// Property for UnitConversion
               /// </summary>
               public const string UnitConversion = "UNITCONV";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitBOMDetail Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CNUniquifier
               /// </summary>
               public const int CNUniquifier = 1;

               /// <summary>
               /// Property Indexer for DetailLineNumber
               /// </summary>
               public const int DetailLineNumber = 2;

               /// <summary>
               /// Property Indexer for ParentComponentNumber
               /// </summary>
               public const int ParentComponentNumber = 3;

               /// <summary>
               /// Property Indexer for ComponentNumber
               /// </summary>
               public const int ComponentNumber = 4;

               /// <summary>
               /// Property Indexer for ComponentItemNo
               /// </summary>
               public const int ComponentItemNo = 5;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 6;

               /// <summary>
               /// Property Indexer for ComponentQuantity
               /// </summary>
               public const int ComponentQuantity = 7;

               /// <summary>
               /// Property Indexer for UnitOfMeasure
               /// </summary>
               public const int UnitOfMeasure = 8;

               /// <summary>
               /// Property Indexer for QuantityReturned
               /// </summary>
               public const int QuantityReturned = 9;

               /// <summary>
               /// Property Indexer for ComponentsBOMNumber
               /// </summary>
               public const int ComponentsBOMNumber = 10;

               /// <summary>
               /// Property Indexer for ComponentsBOMBuildQty
               /// </summary>
               public const int ComponentsBOMBuildQty = 11;

               /// <summary>
               /// Property Indexer for ComponentsBOMBuildUnit
               /// </summary>
               public const int ComponentsBOMBuildUnit = 12;

               /// <summary>
               /// Property Indexer for ComponentsBOMBuildUnitConv
               /// </summary>
               public const int ComponentsBOMBuildUnitConv = 13;

               /// <summary>
               /// Property Indexer for UnitConversion
               /// </summary>
               public const int UnitConversion = 14;

          }
          #endregion

     }
}
