// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of PendingShipment Constants
    /// </summary>
    public partial class PendingShipment
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0521";

        #region Properties

        /// <summary>
        /// Contains list of PendingShipment Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for OrderUniquifier
            /// </summary>
            public const string OrderUniquifier = "ORDUNIQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENUM";

            /// <summary>
            /// Property for OrderNumber
            /// </summary>
            public const string OrderNumber = "ORDNUMBER";

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTOMER";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "BILNAME";

            /// <summary>
            /// Property for OrderType
            /// </summary>
            public const string OrderType = "ORDERTYPE";

            /// <summary>
            /// Property for OrderDate
            /// </summary>
            public const string OrderDate = "ORDDATE";

            /// <summary>
            /// Property for ExpectedShipmentDate
            /// </summary>
            public const string ExpectedShipmentDate = "EXPDATE";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEM";

            /// <summary>
            /// Property for Desc
            /// </summary>
            public const string Desc = "DESC";

            /// <summary>
            /// Property for KittingBom
            /// </summary>
            public const string KittingBom = "DDTLTYPE";

            /// <summary>
            /// Property for ComponentItem
            /// </summary>
            public const string ComponentItem = "COMPONENT";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Compdesc
            /// </summary>
            public const string Compdesc = "COMPDESC";

            /// <summary>
            /// Property for OrderDescription
            /// </summary>
            public const string OrderDescription = "ORDERDESC";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PendingShipment Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for OrderUniquifier
            /// </summary>
            public const int OrderUniquifier = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for OrderNumber
            /// </summary>
            public const int OrderNumber = 3;

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 4;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 5;

            /// <summary>
            /// Property Indexer for OrderType
            /// </summary>
            public const int OrderType = 6;

            /// <summary>
            /// Property Indexer for OrderDate
            /// </summary>
            public const int OrderDate = 7;

            /// <summary>
            /// Property Indexer for ExpectedShipmentDate
            /// </summary>
            public const int ExpectedShipmentDate = 8;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 9;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 10;

            /// <summary>
            /// Property Indexer for DESC
            /// </summary>
            public const int Desc = 11;

            /// <summary>
            /// Property Indexer for KittingBom
            /// </summary>
            public const int KittingBom = 12;

            /// <summary>
            /// Property Indexer for ComponentItem
            /// </summary>
            public const int ComponentItem = 13;

            /// <summary>
            /// Property Indexer for Compdesc
            /// </summary>
            public const int Compdesc = 14;

            /// <summary>
            /// Property Indexer for OrderDescription
            /// </summary>
            public const int OrderDescription = 15;

        }

        #endregion

    }
}
