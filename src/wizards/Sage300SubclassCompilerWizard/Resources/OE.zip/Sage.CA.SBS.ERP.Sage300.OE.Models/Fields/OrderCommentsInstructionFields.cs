// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of OrderCommentsInstruction Constants
     /// </summary>
     public partial class OrderCommentsInstruction
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "OE0180";

          #region Properties
          /// <summary>
          /// Contains list of OrderCommentsInstruction Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for OrderUniquifier
               /// </summary>
               public const string OrderUniquifier = "ORDUNIQ";

               /// <summary>
               /// Property for Uniquifier
               /// </summary>
               public const string Uniquifier = "UNIQUIFIER";

               /// <summary>
               /// Property for DetailNumber
               /// </summary>
               public const string DetailNumber = "DETAILNUM";

               /// <summary>
               /// Property for CommentsInstructionsType
               /// </summary>
               public const string CommentsInstructionsType = "COINTYPE";

               /// <summary>
               /// Property for CommentsInstructions
               /// </summary>
               public const string CommentsInstructions = "COIN";

               /// <summary>
               /// Property for Invoiced
               /// </summary>
               public const string Invoiced = "INVOICED";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of OrderCommentsInstruction Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for OrderUniquifier
               /// </summary>
               public const int OrderUniquifier = 1;

               /// <summary>
               /// Property Indexer for Uniquifier
               /// </summary>
               public const int Uniquifier = 2;

               /// <summary>
               /// Property Indexer for DetailNumber
               /// </summary>
               public const int DetailNumber = 3;

               /// <summary>
               /// Property Indexer for CommentsInstructionsType
               /// </summary>
               public const int CommentsInstructionsType = 4;

               /// <summary>
               /// Property Indexer for CommentsInstructions
               /// </summary>
               public const int CommentsInstructions = 5;

               /// <summary>
               /// Property Indexer for Invoiced
               /// </summary>
               public const int Invoiced = 6;

          }
          #endregion

     }
}
