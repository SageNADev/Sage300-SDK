// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

using System.Collections.Generic;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of CreditDebitDetail Constants
    /// </summary>
    public partial class CreditDebitDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0220";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
                    {"LINETYPE", "LineType"},
					{"ITEM", "Item"},
					{"MISCCHARGE", "MiscellaneousChargesCode"},
					{"DESC", "Description"},
					{"ACCTSET", "ItemAccountSet"},
					{"USERCOSTMD", "UserSpecifiedCostingMethod"},
					{"PRICELIST", "PriceList"},
					{"CATEGORY", "Category"},
					{"LOCATION", "Location"},
					{"PICKSEQ", "PickingSequence"},
					{"STOCKITEM", "StockItem"},
					{"QTYRETURN", "QuantityReturned"},
					{"CRDUNIT", "CreditDebitNoteUom"},
					{"PRIUNTPRC", "PricingUnitPrice"},
					{"COSUNTCST", "CostingUnitCost"},
					{"EXTCCOST", "ExtendedDetailCost"},
					{"EXTCRDMISC", "ExtendedAmountMiscCharge"},
					{"CRDDISC", "CreditNoteDiscountAmount"},
					{"UNITWEIGHT", "UnitWeight"},
					{"EXTWEIGHT", "ExtendedWeight"},
					{"RETURNTYPE", "ReturnType"},
					{"TCLASS1", "TaxClass1"},
					{"TCLASS2", "TaxClass2"},
					{"TCLASS3", "TaxClass3"},
					{"TCLASS4", "TaxClass4"},
					{"TCLASS5", "TaxClass5"},
					{"TINCLUDED1", "TaxIncluded1"},
					{"TINCLUDED2", "TaxIncluded2"},
					{"TINCLUDED3", "TaxIncluded3"},
					{"TINCLUDED4", "TaxIncluded4"},
					{"TINCLUDED5", "TaxIncluded5"},
					{"TBASE1", "TaxBase1"},
					{"TBASE2", "TaxBase2"},
					{"TBASE3", "TaxBase3"},
					{"TBASE4", "TaxBase4"},
					{"TBASE5", "TaxBase5"},
					{"TAMOUNT1", "TaxAmount1"},
					{"TAMOUNT2", "TaxAmount2"},
					{"TAMOUNT3", "TaxAmount3"},
					{"TAMOUNT4", "TaxAmount4"},
					{"TAMOUNT5", "TaxAmount5"},
					{"COMMINST", "HaveCommentsInstructions"},
					{"GLNONSTKCR", "NonstockClearingAccount"},
					{"SHIPTRACK", "ShipmentTrackingNumber"},
					{"SHIPVIA", "ShipViaCode"},
					{"VIADESC", "ShipViaCodeDescription"},
					{"DISCPER", "DiscountPercent"},
					{"MANITEMNO", "ManufacturersItemNumber"},
					{"CUSTITEMNO", "CustomerItemNumber"},
					{"DDTLNO", "KitBomNumber"},
					{"WEIGHTUNIT", "WeightUnitOfMeasure"},
					{"PRWGHTUNIT", "PricingWeightUOM"},
					{"NEEDPCHECK", "PriceCheckPending"},
					{"CAPPROVEBY", "PriceApprovedBy"},
					{"CAPPRPWORD", "ApprovingUsersPassword"},
					{"CTRAMOUNT1", "TRTaxAmount1"},
					{"CTRAMOUNT2", "TRTaxAmount2"},
					{"CTRAMOUNT3", "TRTaxAmount3"},
					{"CTRAMOUNT4", "TRTaxAmount4"},
					{"CTRAMOUNT5", "TRTaxAmount5"},
					{"CONTRACT", "ContractCode"},
					{"PROJECT", "ProjectCode"},
					{"CCATEGORY", "CategoryCode"},
					{"COSTCLASS", "CostClass"},
					{"REVBILL", "RevenueBillingAccount"},
					{"COGSWIP", "COGSWIPAccount"},
					{"RTGAMOUNT", "RetainageAmount"},
					{"RTGPERCENT", "RetainagePercent"},
					{"RTGDAYS", "RetainageDays"},
					{"RTGDATEDUE", "RetainageDueDate"},
					{"RTGDDTOVR", "RetainageDueDateOverride"},
					{"RTGAMTOVR", "RetainageAmountOverride"},
                    {"SERIALQTY", "SerialQuantity"},
					{"LOTQTY", "LotQuantity"}
				};
            }
        }
        #region Properties
        /// <summary>
        /// Contains list of CreditDebitDetail Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for CNUniquifier
            /// </summary>
            public const string CnUniquifier = "CRDUNIQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENUM";

            /// <summary>
            /// Property for LineType
            /// </summary>
            public const string LineType = "LINETYPE";

            /// <summary>
            /// Property for Item
            /// </summary>
            public const string Item = "ITEM";

            /// <summary>
            /// Property for MiscellaneousChargesCode
            /// </summary>
            public const string MiscellaneousChargesCode = "MISCCHARGE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for ItemAccountSet
            /// </summary>
            public const string ItemAccountSet = "ACCTSET";

            /// <summary>
            /// Property for UserSpecifiedCostingMethod
            /// </summary>
            public const string UserSpecifiedCostingMethod = "USERCOSTMD";

            /// <summary>
            /// Property for PriceList
            /// </summary>
            public const string PriceList = "PRICELIST";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for PickingSequence
            /// </summary>
            public const string PickingSequence = "PICKSEQ";

            /// <summary>
            /// Property for StockItem
            /// </summary>
            public const string StockItem = "STOCKITEM";

            /// <summary>
            /// Property for QuantityReturned
            /// </summary>
            public const string QuantityReturned = "QTYRETURN";

            /// <summary>
            /// Property for QuantityShipped
            /// </summary>
            public const string QuantityShipped = "QTYSHIPPED";

            /// <summary>
            /// Property for QuantityBackordered
            /// </summary>
            public const string QuantityBackordered = "QTYBACKORD";

            /// <summary>
            /// Property for CreditDebitNoteUOM
            /// </summary>
            public const string CreditDebitNoteUom = "CRDUNIT";

            /// <summary>
            /// Property for UnitConversion
            /// </summary>
            public const string UnitConversion = "UNITCONV";

            /// <summary>
            /// Property for UnitPrice
            /// </summary>
            public const string UnitPrice = "UNITPRICE";

            /// <summary>
            /// Property for PriceOverride
            /// </summary>
            public const string PriceOverride = "PRICEOVER";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for MostRecentUnitCost
            /// </summary>
            public const string MostRecentUnitCost = "MOSTREC";

            /// <summary>
            /// Property for StandardUnitCost
            /// </summary>
            public const string StandardUnitCost = "STDCOST";

            /// <summary>
            /// Property for AlternateUnitCost1
            /// </summary>
            public const string AlternateUnitCost1 = "COST1";

            /// <summary>
            /// Property for AlternateUnitCost2
            /// </summary>
            public const string AlternateUnitCost2 = "COST2";

            /// <summary>
            /// Property for UnitPriceNoOfDecimals
            /// </summary>
            public const string UnitPriceNoOfDecimals = "UNITPRCDEC";

            /// <summary>
            /// Property for PricingUnit
            /// </summary>
            public const string PricingUnit = "PRICEUNIT";

            /// <summary>
            /// Property for PricingUnitPrice
            /// </summary>
            public const string PricingUnitPrice = "PRIUNTPRC";

            /// <summary>
            /// Property for PricingUnitConversion
            /// </summary>
            public const string PricingUnitConversion = "PRIUNTCONV";

            /// <summary>
            /// Property for PriceDiscountPercentage
            /// </summary>
            public const string PriceDiscountPercentage = "PRIPERCENT";

            /// <summary>
            /// Property for PriceDiscountAmount
            /// </summary>
            public const string PriceDiscountAmount = "PRIAMOUNT";

            /// <summary>
            /// Property for PricingBaseUnit
            /// </summary>
            public const string PricingBaseUnit = "BASEUNIT";

            /// <summary>
            /// Property for PricingBaseUnitPrice
            /// </summary>
            public const string PricingBaseUnitPrice = "PRIBASPRC";

            /// <summary>
            /// Property for PricingBaseUnitConversion
            /// </summary>
            public const string PricingBaseUnitConversion = "PRIBASCONV";

            /// <summary>
            /// Property for CostingUnit
            /// </summary>
            public const string CostingUnit = "COSTUNIT";

            /// <summary>
            /// Property for CostingUnitCost
            /// </summary>
            public const string CostingUnitCost = "COSUNTCST";

            /// <summary>
            /// Property for CostingUnitConversion
            /// </summary>
            public const string CostingUnitConversion = "COSUNTCONV";

            /// <summary>
            /// Property for ExtendedDetailCost
            /// </summary>
            public const string ExtendedDetailCost = "EXTCCOST";

            /// <summary>
            /// Property for ExtendedAmountMiscCharge
            /// </summary>
            public const string ExtendedAmountMiscCharge = "EXTCRDMISC";

            /// <summary>
            /// Property for CreditNoteDiscountAmount
            /// </summary>
            public const string CreditNoteDiscountAmount = "CRDDISC";

            /// <summary>
            /// Property for ExtendedAmountOverride
            /// </summary>
            public const string ExtendedAmountOverride = "EXTOVER";

            /// <summary>
            /// Property for InvoiceExtendedCost
            /// </summary>
            public const string InvoiceExtendedCost = "EXTICOST";

            /// <summary>
            /// Property for UnitWeight
            /// </summary>
            public const string UnitWeight = "UNITWEIGHT";

            /// <summary>
            /// Property for ExtendedWeight
            /// </summary>
            public const string ExtendedWeight = "EXTWEIGHT";

            /// <summary>
            /// Property for ReturnType
            /// </summary>
            public const string ReturnType = "RETURNTYPE";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TCLASS5";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TINCLUDED1";

            /// <summary>
            /// Property for TaxIncluded2
            /// </summary>
            public const string TaxIncluded2 = "TINCLUDED2";

            /// <summary>
            /// Property for TaxIncluded3
            /// </summary>
            public const string TaxIncluded3 = "TINCLUDED3";

            /// <summary>
            /// Property for TaxIncluded4
            /// </summary>
            public const string TaxIncluded4 = "TINCLUDED4";

            /// <summary>
            /// Property for TaxIncluded5
            /// </summary>
            public const string TaxIncluded5 = "TINCLUDED5";

            /// <summary>
            /// Property for TaxBase1
            /// </summary>
            public const string TaxBase1 = "TBASE1";

            /// <summary>
            /// Property for TaxBase2
            /// </summary>
            public const string TaxBase2 = "TBASE2";

            /// <summary>
            /// Property for TaxBase3
            /// </summary>
            public const string TaxBase3 = "TBASE3";

            /// <summary>
            /// Property for TaxBase4
            /// </summary>
            public const string TaxBase4 = "TBASE4";

            /// <summary>
            /// Property for TaxBase5
            /// </summary>
            public const string TaxBase5 = "TBASE5";

            /// <summary>
            /// Property for TaxAmount1
            /// </summary>
            public const string TaxAmount1 = "TAMOUNT1";

            /// <summary>
            /// Property for TaxAmount2
            /// </summary>
            public const string TaxAmount2 = "TAMOUNT2";

            /// <summary>
            /// Property for TaxAmount3
            /// </summary>
            public const string TaxAmount3 = "TAMOUNT3";

            /// <summary>
            /// Property for TaxAmount4
            /// </summary>
            public const string TaxAmount4 = "TAMOUNT4";

            /// <summary>
            /// Property for TaxAmount5
            /// </summary>
            public const string TaxAmount5 = "TAMOUNT5";

            /// <summary>
            /// Property for TaxRate1
            /// </summary>
            public const string TaxRate1 = "TRATE1";

            /// <summary>
            /// Property for TaxRate2
            /// </summary>
            public const string TaxRate2 = "TRATE2";

            /// <summary>
            /// Property for TaxRate3
            /// </summary>
            public const string TaxRate3 = "TRATE3";

            /// <summary>
            /// Property for TaxRate4
            /// </summary>
            public const string TaxRate4 = "TRATE4";

            /// <summary>
            /// Property for TaxRate5
            /// </summary>
            public const string TaxRate5 = "TRATE5";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for HaveCommentsInstructions
            /// </summary>
            public const string HaveCommentsInstructions = "COMMINST";

            /// <summary>
            /// Property for TotalCRMostRecentCost
            /// </summary>
            public const string TotalCrMostRecentCost = "EXTCMOSTRE";

            /// <summary>
            /// Property for TotalCRStandardCost
            /// </summary>
            public const string TotalCrStandardCost = "EXTCSTDCOS";

            /// <summary>
            /// Property for TotalCRCost1
            /// </summary>
            public const string TotalCrCost1 = "EXTCCOST1";

            /// <summary>
            /// Property for TotalCRCost2
            /// </summary>
            public const string TotalCrCost2 = "EXTCCOST2";

            /// <summary>
            /// Property for PriceListDescription
            /// </summary>
            public const string PriceListDescription = "PCODDESC";

            /// <summary>
            /// Property for CategoryDescription
            /// </summary>
            public const string CategoryDescription = "CATGDESC";

            /// <summary>
            /// Property for LocationDescription
            /// </summary>
            public const string LocationDescription = "LOCDESC";

            /// <summary>
            /// Property for TaxAuthority1Description
            /// </summary>
            public const string TaxAuthority1Description = "TAUTH1DESC";

            /// <summary>
            /// Property for TaxAuthority2Description
            /// </summary>
            public const string TaxAuthority2Description = "TAUTH2DESC";

            /// <summary>
            /// Property for TaxAuthority3Description
            /// </summary>
            public const string TaxAuthority3Description = "TAUTH3DESC";

            /// <summary>
            /// Property for TaxAuthority4Description
            /// </summary>
            public const string TaxAuthority4Description = "TAUTH4DESC";

            /// <summary>
            /// Property for TaxAuthority5Description
            /// </summary>
            public const string TaxAuthority5Description = "TAUTH5DESC";

            /// <summary>
            /// Property for TaxClass1Description
            /// </summary>
            public const string TaxClass1Description = "TCLAS1DESC";

            /// <summary>
            /// Property for TaxClass2Description
            /// </summary>
            public const string TaxClass2Description = "TCLAS2DESC";

            /// <summary>
            /// Property for TaxClass3Description
            /// </summary>
            public const string TaxClass3Description = "TCLAS3DESC";

            /// <summary>
            /// Property for TaxClass4Description
            /// </summary>
            public const string TaxClass4Description = "TCLAS4DESC";

            /// <summary>
            /// Property for TaxClass5Description
            /// </summary>
            public const string TaxClass5Description = "TCLAS5DESC";

            /// <summary>
            /// Property for DrivenbyUI
            /// </summary>
            public const string DrivenbyUi = "DRIVENBYUI";

            /// <summary>
            /// Property for FoundNegativeInventory
            /// </summary>
            public const string FoundNegativeInventory = "NEGINVENT";

            /// <summary>
            /// Property for NonstockClearingAccount
            /// </summary>
            public const string NonstockClearingAccount = "GLNONSTKCR";

            /// <summary>
            /// Property for NonstockClearingAcctDesc
            /// </summary>
            public const string NonstockClearingAcctDesc = "GLNONSTKCD";

            /// <summary>
            /// Property for InterprocessCommID
            /// </summary>
            public const string InterprocessCommId = "IPCID";

            /// <summary>
            /// Property for ForcePopupSN
            /// </summary>
            public const string ForcePopupSn = "FORCEPOPSN";

            /// <summary>
            /// Property for PopupSN
            /// </summary>
            public const string PopupSn = "POPUPSN";

            /// <summary>
            /// Property for CloseSN
            /// </summary>
            public const string CloseSn = "CLOSESN";

            /// <summary>
            /// Property for LTSetID
            /// </summary>
            public const string LtSetId = "LTSETID";

            /// <summary>
            /// Property for ForcePopupLT
            /// </summary>
            public const string ForcePopupLt = "FORCEPOPLT";

            /// <summary>
            /// Property for PopupLT
            /// </summary>
            public const string PopupLt = "POPUPLT";

            /// <summary>
            /// Property for CloseLT
            /// </summary>
            public const string CloseLt = "CLOSELT";

            /// <summary>
            /// Property for AverageUnitCost
            /// </summary>
            public const string AverageUnitCost = "AVGCOST";

            /// <summary>
            /// Property for LastUnitCost
            /// </summary>
            public const string LastUnitCost = "LASTCOST";

            /// <summary>
            /// Property for TotalCRAverageCost
            /// </summary>
            public const string TotalCrAverageCost = "EXTCAVGCST";

            /// <summary>
            /// Property for TotalCRLastCost
            /// </summary>
            public const string TotalCrLastCost = "EXTCLSTCST";

            /// <summary>
            /// Property for ShipmentTrackingNumber
            /// </summary>
            public const string ShipmentTrackingNumber = "SHIPTRACK";

            /// <summary>
            /// Property for ShipViaCode
            /// </summary>
            public const string ShipViaCode = "SHIPVIA";

            /// <summary>
            /// Property for ShipViaCodeDescription
            /// </summary>
            public const string ShipViaCodeDescription = "VIADESC";

            /// <summary>
            /// Property for DiscountPercent
            /// </summary>
            public const string DiscountPercent = "DISCPER";

            /// <summary>
            /// Property for ExtendedDiscountedPrice
            /// </summary>
            public const string ExtendedDiscountedPrice = "EDCCRDMISC";

            /// <summary>
            /// Property for ShipmentDate
            /// </summary>
            public const string ShipmentDate = "EXPDATE";

            /// <summary>
            /// Property for InvoiceCurrentQtyOutstanding
            /// </summary>
            public const string InvoiceCurrentQtyOutstanding = "QTYORDERED";

            /// <summary>
            /// Property for InvoiceUnitOfMeasure
            /// </summary>
            public const string InvoiceUnitOfMeasure = "INVUNIT";

            /// <summary>
            /// Property for InvoiceUnitConversion
            /// </summary>
            public const string InvoiceUnitConversion = "INVUNITCON";

            /// <summary>
            /// Property for OrderQuantityOrdered
            /// </summary>
            public const string OrderQuantityOrdered = "ORDQTYORD";

            /// <summary>
            /// Property for OrderQuantityBackordered
            /// </summary>
            public const string OrderQuantityBackordered = "ORDQTYBKOR";

            /// <summary>
            /// Property for OrderQuantityCommitted
            /// </summary>
            public const string OrderQuantityCommitted = "ORDQTYCOMM";

            /// <summary>
            /// Property for OrderQuantityShippedtodate
            /// </summary>
            public const string OrderQuantityShippedtodate = "ORDQTYSTD";

            /// <summary>
            /// Property for OrderUnitOfMeasure
            /// </summary>
            public const string OrderUnitOfMeasure = "ORDUNIT";

            /// <summary>
            /// Property for OrderUnitConversion
            /// </summary>
            public const string OrderUnitConversion = "ORDUNITCON";

            /// <summary>
            /// Property for ManufacturersItemNumber
            /// </summary>
            public const string ManufacturersItemNumber = "MANITEMNO";

            /// <summary>
            /// Property for CustomerItemNumber
            /// </summary>
            public const string CustomerItemNumber = "CUSTITEMNO";

            /// <summary>
            /// Property for InvoicesShipmentNumber
            /// </summary>
            public const string InvoicesShipmentNumber = "SHINUMBER";

            /// <summary>
            /// Property for InvoicesShipmentDetailNumber
            /// </summary>
            public const string InvoicesShipmentDetailNumber = "SHIDTLNUM";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for KittingBOM
            /// </summary>
            public const string KittingBom = "DDTLTYPE";

            /// <summary>
            /// Property for KitBOMNumber
            /// </summary>
            public const string KitBomNumber = "DDTLNO";

            /// <summary>
            /// Property for BOMBuildQty
            /// </summary>
            public const string BomBuildQty = "BUILDQTY";

            /// <summary>
            /// Property for BOMBuildUnit
            /// </summary>
            public const string BomBuildUnit = "BUILDUNIT";

            /// <summary>
            /// Property for BOMBuildUnitConversion
            /// </summary>
            public const string BomBuildUnitConversion = "BLDUNTCONV";

            /// <summary>
            /// Property for UnformattedItemNumber
            /// </summary>
            public const string UnformattedItemNumber = "UNFMTITEM";

            /// <summary>
            /// Property for InvoiceNumber
            /// </summary>
            public const string InvoiceNumber = "INVNUMBER";

            /// <summary>
            /// Property for InvoiceUniquifier
            /// </summary>
            public const string InvoiceUniquifier = "INVUNIQ";

            /// <summary>
            /// Property for InvoiceLineNumber
            /// </summary>
            public const string InvoiceLineNumber = "INVLINENUM";

            /// <summary>
            /// Property for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Property for NextComponentNumber
            /// </summary>
            public const string NextComponentNumber = "NEXTCMPNUM";

            /// <summary>
            /// Property for ePOSPromotionID
            /// </summary>
            public const string EposPromotionId = "EPOSPROMID";

            /// <summary>
            /// Property for PricingBaseWeightUnit
            /// </summary>
            public const string PricingBaseWeightUnit = "BASEWUNIT";

            /// <summary>
            /// Property for WeightUnitOfMeasure
            /// </summary>
            public const string WeightUnitOfMeasure = "WEIGHTUNIT";

            /// <summary>
            /// Property for WeightConversionFactor
            /// </summary>
            public const string WeightConversionFactor = "WEIGHTCONV";

            /// <summary>
            /// Property for PricingWeightUOM
            /// </summary>
            public const string PricingWeightUom = "PRWGHTUNIT";

            /// <summary>
            /// Property for PricingWeightConversionFactor
            /// </summary>
            public const string PricingWeightConversionFactor = "PRWGHTCONV";

            /// <summary>
            /// Property for PricingBaseWeightConvFactor
            /// </summary>
            public const string PricingBaseWeightConvFactor = "PRIBASWCNV";

            /// <summary>
            /// Property for DefWeightUOMUnitWeight
            /// </summary>
            public const string DefWeightUomUnitWeight = "DEFUWEIGHT";

            /// <summary>
            /// Property for DefWeightUOMExtUnitWeight
            /// </summary>
            public const string DefWeightUomExtUnitWeight = "DEFEXTWGHT";

            /// <summary>
            /// Property for PriceBy
            /// </summary>
            public const string PriceBy = "PRPRICEBY";

            /// <summary>
            /// Property for PriceCheckPending
            /// </summary>
            public const string PriceCheckPending = "NEEDPCHECK";

            /// <summary>
            /// Property for PriceApprovedBy
            /// </summary>
            public const string PriceApprovedBy = "CAPPROVEBY";

            /// <summary>
            /// Property for ApprovingUsersPassword
            /// </summary>
            public const string ApprovingUsersPassword = "CAPPRPWORD";

            /// <summary>
            /// Property for PriceApprovalNeeded
            /// </summary>
            public const string PriceApprovalNeeded = "NEEDCAPP";

            /// <summary>
            /// Property for WeightUOMDescription
            /// </summary>
            public const string WeightUomDescription = "WUOMDESC";

            /// <summary>
            /// Property for HeaderDiscount
            /// </summary>
            public const string HeaderDiscount = "HDRDISC";

            /// <summary>
            /// Property for TRTaxAmount1
            /// </summary>
            public const string TrTaxAmount1 = "CTRAMOUNT1";

            /// <summary>
            /// Property for TRTaxAmount2
            /// </summary>
            public const string TrTaxAmount2 = "CTRAMOUNT2";

            /// <summary>
            /// Property for TRTaxAmount3
            /// </summary>
            public const string TrTaxAmount3 = "CTRAMOUNT3";

            /// <summary>
            /// Property for TRTaxAmount4
            /// </summary>
            public const string TrTaxAmount4 = "CTRAMOUNT4";

            /// <summary>
            /// Property for TRTaxAmount5
            /// </summary>
            public const string TrTaxAmount5 = "CTRAMOUNT5";

            /// <summary>
            /// Property for ExtendedAmountNetOfTax
            /// </summary>
            public const string ExtendedAmountNetOfTax = "EXTNETPRI";

            /// <summary>
            /// Property for DiscountedExtendedAmount
            /// </summary>
            public const string DiscountedExtendedAmount = "DISCRDMISC";

            /// <summary>
            /// Property for TaxTotal
            /// </summary>
            public const string TaxTotal = "TAXTOTAL";

            /// <summary>
            /// Property for TRTaxTotal
            /// </summary>
            public const string TrTaxTotal = "CTRTOTAL";

            /// <summary>
            /// Property for CostOfGoods
            /// </summary>
            public const string CostOfGoods = "COG";

            /// <summary>
            /// Property for RecordCosted
            /// </summary>
            public const string RecordCosted = "COSTED";

            /// <summary>
            /// Property for JobRelated
            /// </summary>
            public const string JobRelated = "JOBRELATED";

            /// <summary>
            /// Property for ContractCode
            /// </summary>
            public const string ContractCode = "CONTRACT";

            /// <summary>
            /// Property for ProjectCode
            /// </summary>
            public const string ProjectCode = "PROJECT";

            /// <summary>
            /// Property for CategoryCode
            /// </summary>
            public const string CategoryCode = "CCATEGORY";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "COSTCLASS";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "PROJSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for RevenueBillingAccount
            /// </summary>
            public const string RevenueBillingAccount = "REVBILL";

            /// <summary>
            /// Property for COGSWIPAccount
            /// </summary>
            public const string CogSwipAccount = "COGSWIP";

            /// <summary>
            /// Property for RetainageAmount
            /// </summary>
            public const string RetainageAmount = "RTGAMOUNT";

            /// <summary>
            /// Property for RetainagePercent
            /// </summary>
            public const string RetainagePercent = "RTGPERCENT";

            /// <summary>
            /// Property for RetainageDays
            /// </summary>
            public const string RetainageDays = "RTGDAYS";

            /// <summary>
            /// Property for RetainageDueDate
            /// </summary>
            public const string RetainageDueDate = "RTGDATEDUE";

            /// <summary>
            /// Property for RetainageDueDateOverride
            /// </summary>
            public const string RetainageDueDateOverride = "RTGDDTOVR";

            /// <summary>
            /// Property for RetainageAmountOverride
            /// </summary>
            public const string RetainageAmountOverride = "RTGAMTOVR";

            /// <summary>
            /// Property for RetainageTaxBase1
            /// </summary>
            public const string RetainageTaxBase1 = "RTGTXBASE1";

            /// <summary>
            /// Property for RetainageTaxBase2
            /// </summary>
            public const string RetainageTaxBase2 = "RTGTXBASE2";

            /// <summary>
            /// Property for RetainageTaxBase3
            /// </summary>
            public const string RetainageTaxBase3 = "RTGTXBASE3";

            /// <summary>
            /// Property for RetainageTaxBase4
            /// </summary>
            public const string RetainageTaxBase4 = "RTGTXBASE4";

            /// <summary>
            /// Property for RetainageTaxBase5
            /// </summary>
            public const string RetainageTaxBase5 = "RTGTXBASE5";

            /// <summary>
            /// Property for RetainageTaxAmount1
            /// </summary>
            public const string RetainageTaxAmount1 = "RTGTXAMT1";

            /// <summary>
            /// Property for RetainageTaxAmount2
            /// </summary>
            public const string RetainageTaxAmount2 = "RTGTXAMT2";

            /// <summary>
            /// Property for RetainageTaxAmount3
            /// </summary>
            public const string RetainageTaxAmount3 = "RTGTXAMT3";

            /// <summary>
            /// Property for RetainageTaxAmount4
            /// </summary>
            public const string RetainageTaxAmount4 = "RTGTXAMT4";

            /// <summary>
            /// Property for RetainageTaxAmount5
            /// </summary>
            public const string RetainageTaxAmount5 = "RTGTXAMT5";

            /// <summary>
            /// Property for DefaultOEPrice
            /// </summary>
            public const string DefaultOePrice = "PRICEOPT";

            /// <summary>
            /// Property for Level1Name
            /// </summary>
            public const string Level1Name = "LVL1NAME";

            /// <summary>
            /// Property for Level2Name
            /// </summary>
            public const string Level2Name = "LVL2NAME";

            /// <summary>
            /// Property for Level3Name
            /// </summary>
            public const string Level3Name = "LVL3NAME";

            /// <summary>
            /// Property for UnformattedContractCode
            /// </summary>
            public const string UnformattedContractCode = "UFMTCONTNO";

            /// <summary>
            /// Property for SerialQuantity
            /// </summary>
            public const string SerialQuantity = "SERIALQTY";

            /// <summary>
            /// Property for LotQuantity
            /// </summary>
            public const string LotQuantity = "LOTQTY";

            /// <summary>
            /// Property for SerialLotQuantityToProcess
            /// </summary>
            public const string SerialLotQuantityToProcess = "XGENALCQTY";

            /// <summary>
            /// Property for NumberOfLotsToGenerate
            /// </summary>
            public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

            /// <summary>
            /// Property for QuantityperLot
            /// </summary>
            public const string QuantityperLot = "XPERLOTQTY";

            /// <summary>
            /// Property for AllocateFromSerial
            /// </summary>
            public const string AllocateFromSerial = "SALLOCFROM";

            /// <summary>
            /// Property for AllocateFromLot
            /// </summary>
            public const string AllocateFromLot = "LALLOCFROM";

            /// <summary>
            /// Property for ItemSerializedLotted
            /// </summary>
            public const string ItemSerializedLotted = "SLITEM";

            /// <summary>
            /// Property for SerialLotWindowHandle
            /// </summary>
            public const string SerialLotWindowHandle = "METERHWND";

            /// <summary>
            /// Property for SetCreditApproval
            /// </summary>
            public const string SetCreditApproval = "SETCAPPR";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of CreditDebitDetail Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for CNUniquifier
            /// </summary>
            public const int CnUniquifier = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for LineType
            /// </summary>
            public const int LineType = 3;

            /// <summary>
            /// Property Indexer for Item
            /// </summary>
            public const int Item = 4;

            /// <summary>
            /// Property Indexer for MiscellaneousChargesCode
            /// </summary>
            public const int MiscellaneousChargesCode = 5;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 6;

            /// <summary>
            /// Property Indexer for ItemAccountSet
            /// </summary>
            public const int ItemAccountSet = 7;

            /// <summary>
            /// Property Indexer for UserSpecifiedCostingMethod
            /// </summary>
            public const int UserSpecifiedCostingMethod = 8;

            /// <summary>
            /// Property Indexer for PriceList
            /// </summary>
            public const int PriceList = 9;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 10;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 11;

            /// <summary>
            /// Property Indexer for PickingSequence
            /// </summary>
            public const int PickingSequence = 12;

            /// <summary>
            /// Property Indexer for StockItem
            /// </summary>
            public const int StockItem = 13;

            /// <summary>
            /// Property Indexer for QuantityReturned
            /// </summary>
            public const int QuantityReturned = 14;

            /// <summary>
            /// Property Indexer for QuantityShipped
            /// </summary>
            public const int QuantityShipped = 15;

            /// <summary>
            /// Property Indexer for QuantityBackordered
            /// </summary>
            public const int QuantityBackordered = 16;

            /// <summary>
            /// Property Indexer for CreditDebitNoteUOM
            /// </summary>
            public const int CreditDebitNoteUom = 17;

            /// <summary>
            /// Property Indexer for UnitConversion
            /// </summary>
            public const int UnitConversion = 18;

            /// <summary>
            /// Property Indexer for UnitPrice
            /// </summary>
            public const int UnitPrice = 19;

            /// <summary>
            /// Property Indexer for PriceOverride
            /// </summary>
            public const int PriceOverride = 20;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 21;

            /// <summary>
            /// Property Indexer for MostRecentUnitCost
            /// </summary>
            public const int MostRecentUnitCost = 22;

            /// <summary>
            /// Property Indexer for StandardUnitCost
            /// </summary>
            public const int StandardUnitCost = 23;

            /// <summary>
            /// Property Indexer for AlternateUnitCost1
            /// </summary>
            public const int AlternateUnitCost1 = 24;

            /// <summary>
            /// Property Indexer for AlternateUnitCost2
            /// </summary>
            public const int AlternateUnitCost2 = 25;

            /// <summary>
            /// Property Indexer for UnitPriceNoOfDecimals
            /// </summary>
            public const int UnitPriceNoOfDecimals = 26;

            /// <summary>
            /// Property Indexer for PricingUnit
            /// </summary>
            public const int PricingUnit = 27;

            /// <summary>
            /// Property Indexer for PricingUnitPrice
            /// </summary>
            public const int PricingUnitPrice = 28;

            /// <summary>
            /// Property Indexer for PricingUnitConversion
            /// </summary>
            public const int PricingUnitConversion = 29;

            /// <summary>
            /// Property Indexer for PriceDiscountPercentage
            /// </summary>
            public const int PriceDiscountPercentage = 30;

            /// <summary>
            /// Property Indexer for PriceDiscountAmount
            /// </summary>
            public const int PriceDiscountAmount = 31;

            /// <summary>
            /// Property Indexer for PricingBaseUnit
            /// </summary>
            public const int PricingBaseUnit = 32;

            /// <summary>
            /// Property Indexer for PricingBaseUnitPrice
            /// </summary>
            public const int PricingBaseUnitPrice = 33;

            /// <summary>
            /// Property Indexer for PricingBaseUnitConversion
            /// </summary>
            public const int PricingBaseUnitConversion = 34;

            /// <summary>
            /// Property Indexer for CostingUnit
            /// </summary>
            public const int CostingUnit = 35;

            /// <summary>
            /// Property Indexer for CostingUnitCost
            /// </summary>
            public const int CostingUnitCost = 36;

            /// <summary>
            /// Property Indexer for CostingUnitConversion
            /// </summary>
            public const int CostingUnitConversion = 37;

            /// <summary>
            /// Property Indexer for ExtendedDetailCost
            /// </summary>
            public const int ExtendedDetailCost = 38;

            /// <summary>
            /// Property Indexer for ExtendedAmountMiscCharge
            /// </summary>
            public const int ExtendedAmountMiscCharge = 39;

            /// <summary>
            /// Property Indexer for CreditNoteDiscountAmount
            /// </summary>
            public const int CreditNoteDiscountAmount = 40;

            /// <summary>
            /// Property Indexer for ExtendedAmountOverride
            /// </summary>
            public const int ExtendedAmountOverride = 41;

            /// <summary>
            /// Property Indexer for InvoiceExtendedCost
            /// </summary>
            public const int InvoiceExtendedCost = 42;

            /// <summary>
            /// Property Indexer for UnitWeight
            /// </summary>
            public const int UnitWeight = 43;

            /// <summary>
            /// Property Indexer for ExtendedWeight
            /// </summary>
            public const int ExtendedWeight = 44;

            /// <summary>
            /// Property Indexer for ReturnType
            /// </summary>
            public const int ReturnType = 45;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 46;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 47;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 48;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 49;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 50;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 51;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 52;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 53;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 54;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 55;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 56;

            /// <summary>
            /// Property Indexer for TaxIncluded2
            /// </summary>
            public const int TaxIncluded2 = 57;

            /// <summary>
            /// Property Indexer for TaxIncluded3
            /// </summary>
            public const int TaxIncluded3 = 58;

            /// <summary>
            /// Property Indexer for TaxIncluded4
            /// </summary>
            public const int TaxIncluded4 = 59;

            /// <summary>
            /// Property Indexer for TaxIncluded5
            /// </summary>
            public const int TaxIncluded5 = 60;

            /// <summary>
            /// Property Indexer for TaxBase1
            /// </summary>
            public const int TaxBase1 = 61;

            /// <summary>
            /// Property Indexer for TaxBase2
            /// </summary>
            public const int TaxBase2 = 62;

            /// <summary>
            /// Property Indexer for TaxBase3
            /// </summary>
            public const int TaxBase3 = 63;

            /// <summary>
            /// Property Indexer for TaxBase4
            /// </summary>
            public const int TaxBase4 = 64;

            /// <summary>
            /// Property Indexer for TaxBase5
            /// </summary>
            public const int TaxBase5 = 65;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 66;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 67;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 68;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 69;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 70;

            /// <summary>
            /// Property Indexer for TaxRate1
            /// </summary>
            public const int TaxRate1 = 71;

            /// <summary>
            /// Property Indexer for TaxRate2
            /// </summary>
            public const int TaxRate2 = 72;

            /// <summary>
            /// Property Indexer for TaxRate3
            /// </summary>
            public const int TaxRate3 = 73;

            /// <summary>
            /// Property Indexer for TaxRate4
            /// </summary>
            public const int TaxRate4 = 74;

            /// <summary>
            /// Property Indexer for TaxRate5
            /// </summary>
            public const int TaxRate5 = 75;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 77;

            /// <summary>
            /// Property Indexer for HaveCommentsInstructions
            /// </summary>
            public const int HaveCommentsInstructions = 79;

            /// <summary>
            /// Property Indexer for TotalCRMostRecentCost
            /// </summary>
            public const int TotalCrMostRecentCost = 80;

            /// <summary>
            /// Property Indexer for TotalCRStandardCost
            /// </summary>
            public const int TotalCrStandardCost = 81;

            /// <summary>
            /// Property Indexer for TotalCRCost1
            /// </summary>
            public const int TotalCrCost1 = 82;

            /// <summary>
            /// Property Indexer for TotalCRCost2
            /// </summary>
            public const int TotalCrCost2 = 83;

            /// <summary>
            /// Property Indexer for PriceListDescription
            /// </summary>
            public const int PriceListDescription = 84;

            /// <summary>
            /// Property Indexer for CategoryDescription
            /// </summary>
            public const int CategoryDescription = 85;

            /// <summary>
            /// Property Indexer for LocationDescription
            /// </summary>
            public const int LocationDescription = 86;

            /// <summary>
            /// Property Indexer for TaxAuthority1Description
            /// </summary>
            public const int TaxAuthority1Description = 87;

            /// <summary>
            /// Property Indexer for TaxAuthority2Description
            /// </summary>
            public const int TaxAuthority2Description = 88;

            /// <summary>
            /// Property Indexer for TaxAuthority3Description
            /// </summary>
            public const int TaxAuthority3Description = 89;

            /// <summary>
            /// Property Indexer for TaxAuthority4Description
            /// </summary>
            public const int TaxAuthority4Description = 90;

            /// <summary>
            /// Property Indexer for TaxAuthority5Description
            /// </summary>
            public const int TaxAuthority5Description = 91;

            /// <summary>
            /// Property Indexer for TaxClass1Description
            /// </summary>
            public const int TaxClass1Description = 92;

            /// <summary>
            /// Property Indexer for TaxClass2Description
            /// </summary>
            public const int TaxClass2Description = 93;

            /// <summary>
            /// Property Indexer for TaxClass3Description
            /// </summary>
            public const int TaxClass3Description = 94;

            /// <summary>
            /// Property Indexer for TaxClass4Description
            /// </summary>
            public const int TaxClass4Description = 95;

            /// <summary>
            /// Property Indexer for TaxClass5Description
            /// </summary>
            public const int TaxClass5Description = 96;

            /// <summary>
            /// Property Indexer for DrivenbyUI
            /// </summary>
            public const int DrivenbyUi = 97;

            /// <summary>
            /// Property Indexer for FoundNegativeInventory
            /// </summary>
            public const int FoundNegativeInventory = 98;

            /// <summary>
            /// Property Indexer for NonstockClearingAccount
            /// </summary>
            public const int NonstockClearingAccount = 99;

            /// <summary>
            /// Property Indexer for NonstockClearingAcctDesc
            /// </summary>
            public const int NonstockClearingAcctDesc = 100;

            /// <summary>
            /// Property Indexer for InterprocessCommID
            /// </summary>
            public const int InterprocessCommId = 101;

            /// <summary>
            /// Property Indexer for ForcePopupSN
            /// </summary>
            public const int ForcePopupSn = 102;

            /// <summary>
            /// Property Indexer for PopupSN
            /// </summary>
            public const int PopupSn = 103;

            /// <summary>
            /// Property Indexer for CloseSN
            /// </summary>
            public const int CloseSn = 104;

            /// <summary>
            /// Property Indexer for LTSetID
            /// </summary>
            public const int LtSetId = 105;

            /// <summary>
            /// Property Indexer for ForcePopupLT
            /// </summary>
            public const int ForcePopupLt = 106;

            /// <summary>
            /// Property Indexer for PopupLT
            /// </summary>
            public const int PopupLt = 107;

            /// <summary>
            /// Property Indexer for CloseLT
            /// </summary>
            public const int CloseLt = 108;

            /// <summary>
            /// Property Indexer for AverageUnitCost
            /// </summary>
            public const int AverageUnitCost = 109;

            /// <summary>
            /// Property Indexer for LastUnitCost
            /// </summary>
            public const int LastUnitCost = 110;

            /// <summary>
            /// Property Indexer for TotalCRAverageCost
            /// </summary>
            public const int TotalCrAverageCost = 111;

            /// <summary>
            /// Property Indexer for TotalCRLastCost
            /// </summary>
            public const int TotalCrLastCost = 112;

            /// <summary>
            /// Property Indexer for ShipmentTrackingNumber
            /// </summary>
            public const int ShipmentTrackingNumber = 113;

            /// <summary>
            /// Property Indexer for ShipViaCode
            /// </summary>
            public const int ShipViaCode = 114;

            /// <summary>
            /// Property Indexer for ShipViaCodeDescription
            /// </summary>
            public const int ShipViaCodeDescription = 115;

            /// <summary>
            /// Property Indexer for DiscountPercent
            /// </summary>
            public const int DiscountPercent = 116;

            /// <summary>
            /// Property Indexer for ExtendedDiscountedPrice
            /// </summary>
            public const int ExtendedDiscountedPrice = 117;

            /// <summary>
            /// Property Indexer for ShipmentDate
            /// </summary>
            public const int ShipmentDate = 118;

            /// <summary>
            /// Property Indexer for InvoiceCurrentQtyOutstanding
            /// </summary>
            public const int InvoiceCurrentQtyOutstanding = 119;

            /// <summary>
            /// Property Indexer for InvoiceUnitOfMeasure
            /// </summary>
            public const int InvoiceUnitOfMeasure = 120;

            /// <summary>
            /// Property Indexer for InvoiceUnitConversion
            /// </summary>
            public const int InvoiceUnitConversion = 121;

            /// <summary>
            /// Property Indexer for OrderQuantityOrdered
            /// </summary>
            public const int OrderQuantityOrdered = 122;

            /// <summary>
            /// Property Indexer for OrderQuantityBackordered
            /// </summary>
            public const int OrderQuantityBackordered = 123;

            /// <summary>
            /// Property Indexer for OrderQuantityCommitted
            /// </summary>
            public const int OrderQuantityCommitted = 124;

            /// <summary>
            /// Property Indexer for OrderQuantityShippedtodate
            /// </summary>
            public const int OrderQuantityShippedtodate = 125;

            /// <summary>
            /// Property Indexer for OrderUnitOfMeasure
            /// </summary>
            public const int OrderUnitOfMeasure = 126;

            /// <summary>
            /// Property Indexer for OrderUnitConversion
            /// </summary>
            public const int OrderUnitConversion = 127;

            /// <summary>
            /// Property Indexer for ManufacturersItemNumber
            /// </summary>
            public const int ManufacturersItemNumber = 128;

            /// <summary>
            /// Property Indexer for CustomerItemNumber
            /// </summary>
            public const int CustomerItemNumber = 129;

            /// <summary>
            /// Property Indexer for InvoicesShipmentNumber
            /// </summary>
            public const int InvoicesShipmentNumber = 130;

            /// <summary>
            /// Property Indexer for InvoicesShipmentDetailNumber
            /// </summary>
            public const int InvoicesShipmentDetailNumber = 131;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 132;

            /// <summary>
            /// Property Indexer for KittingBOM
            /// </summary>
            public const int KittingBom = 133;

            /// <summary>
            /// Property Indexer for KitBOMNumber
            /// </summary>
            public const int KitBomNumber = 134;

            /// <summary>
            /// Property Indexer for BOMBuildQty
            /// </summary>
            public const int BomBuildQty = 135;

            /// <summary>
            /// Property Indexer for BOMBuildUnit
            /// </summary>
            public const int BomBuildUnit = 136;

            /// <summary>
            /// Property Indexer for BOMBuildUnitConversion
            /// </summary>
            public const int BomBuildUnitConversion = 137;

            /// <summary>
            /// Property Indexer for UnformattedItemNumber
            /// </summary>
            public const int UnformattedItemNumber = 138;

            /// <summary>
            /// Property Indexer for InvoiceNumber
            /// </summary>
            public const int InvoiceNumber = 139;

            /// <summary>
            /// Property Indexer for InvoiceUniquifier
            /// </summary>
            public const int InvoiceUniquifier = 140;

            /// <summary>
            /// Property Indexer for InvoiceLineNumber
            /// </summary>
            public const int InvoiceLineNumber = 141;

            /// <summary>
            /// Property Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 142;

            /// <summary>
            /// Property Indexer for NextComponentNumber
            /// </summary>
            public const int NextComponentNumber = 143;

            /// <summary>
            /// Property Indexer for ePOSPromotionID
            /// </summary>
            public const int EposPromotionId = 144;

            /// <summary>
            /// Property Indexer for PricingBaseWeightUnit
            /// </summary>
            public const int PricingBaseWeightUnit = 145;

            /// <summary>
            /// Property Indexer for WeightUnitOfMeasure
            /// </summary>
            public const int WeightUnitOfMeasure = 146;

            /// <summary>
            /// Property Indexer for WeightConversionFactor
            /// </summary>
            public const int WeightConversionFactor = 147;

            /// <summary>
            /// Property Indexer for PricingWeightUOM
            /// </summary>
            public const int PricingWeightUom = 148;

            /// <summary>
            /// Property Indexer for PricingWeightConversionFactor
            /// </summary>
            public const int PricingWeightConversionFactor = 149;

            /// <summary>
            /// Property Indexer for PricingBaseWeightConvFactor
            /// </summary>
            public const int PricingBaseWeightConvFactor = 150;

            /// <summary>
            /// Property Indexer for DefWeightUOMUnitWeight
            /// </summary>
            public const int DefWeightUomUnitWeight = 151;

            /// <summary>
            /// Property Indexer for DefWeightUOMExtUnitWeight
            /// </summary>
            public const int DefWeightUomExtUnitWeight = 152;

            /// <summary>
            /// Property Indexer for PriceBy
            /// </summary>
            public const int PriceBy = 153;

            /// <summary>
            /// Property Indexer for PriceCheckPending
            /// </summary>
            public const int PriceCheckPending = 154;

            /// <summary>
            /// Property Indexer for PriceApprovedBy
            /// </summary>
            public const int PriceApprovedBy = 155;

            /// <summary>
            /// Property Indexer for ApprovingUsersPassword
            /// </summary>
            public const int ApprovingUsersPassword = 156;

            /// <summary>
            /// Property Indexer for PriceApprovalNeeded
            /// </summary>
            public const int PriceApprovalNeeded = 157;

            /// <summary>
            /// Property Indexer for WeightUOMDescription
            /// </summary>
            public const int WeightUomDescription = 158;

            /// <summary>
            /// Property Indexer for HeaderDiscount
            /// </summary>
            public const int HeaderDiscount = 159;

            /// <summary>
            /// Property Indexer for TRTaxAmount1
            /// </summary>
            public const int TrTaxAmount1 = 160;

            /// <summary>
            /// Property Indexer for TRTaxAmount2
            /// </summary>
            public const int TrTaxAmount2 = 161;

            /// <summary>
            /// Property Indexer for TRTaxAmount3
            /// </summary>
            public const int TrTaxAmount3 = 162;

            /// <summary>
            /// Property Indexer for TRTaxAmount4
            /// </summary>
            public const int TrTaxAmount4 = 163;

            /// <summary>
            /// Property Indexer for TRTaxAmount5
            /// </summary>
            public const int TrTaxAmount5 = 164;

            /// <summary>
            /// Property Indexer for ExtendedAmountNetOfTax
            /// </summary>
            public const int ExtendedAmountNetOfTax = 165;

            /// <summary>
            /// Property Indexer for DiscountedExtendedAmount
            /// </summary>
            public const int DiscountedExtendedAmount = 166;

            /// <summary>
            /// Property Indexer for TaxTotal
            /// </summary>
            public const int TaxTotal = 167;

            /// <summary>
            /// Property Indexer for TRTaxTotal
            /// </summary>
            public const int TrTaxTotal = 168;

            /// <summary>
            /// Property Indexer for CostOfGoods
            /// </summary>
            public const int CostOfGoods = 169;

            /// <summary>
            /// Property Indexer for RecordCosted
            /// </summary>
            public const int RecordCosted = 170;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 171;

            /// <summary>
            /// Property Indexer for ContractCode
            /// </summary>
            public const int ContractCode = 172;

            /// <summary>
            /// Property Indexer for ProjectCode
            /// </summary>
            public const int ProjectCode = 173;

            /// <summary>
            /// Property Indexer for CategoryCode
            /// </summary>
            public const int CategoryCode = 174;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 175;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 176;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 177;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 178;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 179;

            /// <summary>
            /// Property Indexer for RevenueBillingAccount
            /// </summary>
            public const int RevenueBillingAccount = 180;

            /// <summary>
            /// Property Indexer for COGSWIPAccount
            /// </summary>
            public const int CogSwipAccount = 181;

            /// <summary>
            /// Property Indexer for RetainageAmount
            /// </summary>
            public const int RetainageAmount = 182;

            /// <summary>
            /// Property Indexer for RetainagePercent
            /// </summary>
            public const int RetainagePercent = 183;

            /// <summary>
            /// Property Indexer for RetainageDays
            /// </summary>
            public const int RetainageDays = 184;

            /// <summary>
            /// Property Indexer for RetainageDueDate
            /// </summary>
            public const int RetainageDueDate = 185;

            /// <summary>
            /// Property Indexer for RetainageDueDateOverride
            /// </summary>
            public const int RetainageDueDateOverride = 186;

            /// <summary>
            /// Property Indexer for RetainageAmountOverride
            /// </summary>
            public const int RetainageAmountOverride = 187;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1
            /// </summary>
            public const int RetainageTaxBase1 = 188;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2
            /// </summary>
            public const int RetainageTaxBase2 = 189;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3
            /// </summary>
            public const int RetainageTaxBase3 = 190;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4
            /// </summary>
            public const int RetainageTaxBase4 = 191;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5
            /// </summary>
            public const int RetainageTaxBase5 = 192;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1
            /// </summary>
            public const int RetainageTaxAmount1 = 193;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2
            /// </summary>
            public const int RetainageTaxAmount2 = 194;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3
            /// </summary>
            public const int RetainageTaxAmount3 = 195;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4
            /// </summary>
            public const int RetainageTaxAmount4 = 196;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5
            /// </summary>
            public const int RetainageTaxAmount5 = 197;

            /// <summary>
            /// Property Indexer for DefaultOEPrice
            /// </summary>
            public const int DefaultOEPrice = 198;

            /// <summary>
            /// Property Indexer for Level1Name
            /// </summary>
            public const int Level1Name = 199;

            /// <summary>
            /// Property Indexer for Level2Name
            /// </summary>
            public const int Level2Name = 200;

            /// <summary>
            /// Property Indexer for Level3Name
            /// </summary>
            public const int Level3Name = 201;

            /// <summary>
            /// Property Indexer for UnformattedContractCode
            /// </summary>
            public const int UnformattedContractCode = 202;

            /// <summary>
            /// Property Indexer for SerialQuantity
            /// </summary>
            public const int SerialQuantity = 203;

            /// <summary>
            /// Property Indexer for LotQuantity
            /// </summary>
            public const int LotQuantity = 204;

            /// <summary>
            /// Property Indexer for SerialLotQuantityToProcess
            /// </summary>
            public const int SerialLotQuantityToProcess = 205;

            /// <summary>
            /// Property Indexer for NumberOfLotsToGenerate
            /// </summary>
            public const int NumberOfLotsToGenerate = 206;

            /// <summary>
            /// Property Indexer for QuantityperLot
            /// </summary>
            public const int QuantityperLot = 207;

            /// <summary>
            /// Property Indexer for AllocateFromSerial
            /// </summary>
            public const int AllocateFromSerial = 208;

            /// <summary>
            /// Property Indexer for AllocateFromLot
            /// </summary>
            public const int AllocateFromLot = 209;

            /// <summary>
            /// Property Indexer for ItemSerializedLotted
            /// </summary>
            public const int ItemSerializedLotted = 210;

            /// <summary>
            /// Property Indexer for SerialLotWindowHandle
            /// </summary>
            public const int SerialLotWindowHandle = 211;

            /// <summary>
            /// Property Indexer for SetCreditApproval
			/// </summary>
            public const int SetCreditApproval = 212;
        }
        #endregion

    }
}
