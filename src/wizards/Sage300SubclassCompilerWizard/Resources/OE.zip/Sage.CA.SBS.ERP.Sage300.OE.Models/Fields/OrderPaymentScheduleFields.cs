// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of OrderPaymentSchedule Constants
     /// </summary>
     public partial class OrderPaymentSchedule
     {
          /// <summary>
          /// Entity Name
          /// </summary>
          public const string EntityName = "OE0740";

          #region Properties
          /// <summary>
          /// Contains list of OrderPaymentSchedule Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for OrderUniquifier
               /// </summary>
               public const string OrderUniquifier = "ORDUNIQ";

               /// <summary>
               /// Property for PaymentNumber
               /// </summary>
               public const string PaymentNumber = "PAYMENT";

               /// <summary>
               /// Property for DiscountBase
               /// </summary>
               public const string DiscountBase = "DISCBASE";

               /// <summary>
               /// Property for DiscountDate
               /// </summary>
               public const string DiscountDate = "DISCDATE";

               /// <summary>
               /// Property for DiscountPercentage
               /// </summary>
               public const string DiscountPercentage = "DISCPER";

               /// <summary>
               /// Property for DiscountAmount
               /// </summary>
               public const string DiscountAmount = "DISCAMT";

               /// <summary>
               /// Property for AmountDueBase
               /// </summary>
               public const string AmountDueBase = "DUEBASE";

               /// <summary>
               /// Property for DueDate
               /// </summary>
               public const string DueDate = "DUEDATE";

               /// <summary>
               /// Property for PercentageDue
               /// </summary>
               public const string PercentageDue = "DUEPER";

               /// <summary>
               /// Property for AmountDue
               /// </summary>
               public const string AmountDue = "DUEAMT";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of OrderPaymentSchedule Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for OrderUniquifier
               /// </summary>
               public const int OrderUniquifier = 1;

               /// <summary>
               /// Property Indexer for PaymentNumber
               /// </summary>
               public const int PaymentNumber = 2;

               /// <summary>
               /// Property Indexer for DiscountBase
               /// </summary>
               public const int DiscountBase = 3;

               /// <summary>
               /// Property Indexer for DiscountDate
               /// </summary>
               public const int DiscountDate = 4;

               /// <summary>
               /// Property Indexer for DiscountPercentage
               /// </summary>
               public const int DiscountPercentage = 5;

               /// <summary>
               /// Property Indexer for DiscountAmount
               /// </summary>
               public const int DiscountAmount = 6;

               /// <summary>
               /// Property Indexer for AmountDueBase
               /// </summary>
               public const int AmountDueBase = 7;

               /// <summary>
               /// Property Indexer for DueDate
               /// </summary>
               public const int DueDate = 8;

               /// <summary>
               /// Property Indexer for PercentageDue
               /// </summary>
               public const int PercentageDue = 9;

               /// <summary>
               /// Property Indexer for AmountDue
               /// </summary>
               public const int AmountDue = 10;

          }
          #endregion

     }
}
