// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of ItemPricing Constants
	/// </summary>
	public partial class ItemPricing
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "OE0630";

		#region Properties

		/// <summary>
		/// Contains list of ItemPricing Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Currency
			/// </summary>
			public const string Currency = "CURRENCY";

			/// <summary>
			/// Property for Item
			/// </summary>
			public const string Item = "ITEMNO";

			/// <summary>
			/// Property for PriceList
			/// </summary>
			public const string PriceList = "PRICELIST";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "DESC";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for OrderQuantity
			/// </summary>
			public const string OrderQuantity = "ORDERQTY";

			/// <summary>
			/// Property for OrderUOM
			/// </summary>
			public const string OrderUOM = "ORDERUNIT";

			/// <summary>
			/// Property for OrderDate
			/// </summary>
			public const string OrderDate = "ORDERDATE";

			/// <summary>
			/// Property for TaxGroup
			/// </summary>
			public const string TaxGroup = "TAXGROUP";

			/// <summary>
			/// Property for TaxAuthority1
			/// </summary>
			public const string TaxAuthority1 = "TAXAUTH1";

			/// <summary>
			/// Property for TaxAuthority2
			/// </summary>
			public const string TaxAuthority2 = "TAXAUTH2";

			/// <summary>
			/// Property for TaxAuthority3
			/// </summary>
			public const string TaxAuthority3 = "TAXAUTH3";

			/// <summary>
			/// Property for TaxAuthority4
			/// </summary>
			public const string TaxAuthority4 = "TAXAUTH4";

			/// <summary>
			/// Property for TaxAuthority5
			/// </summary>
			public const string TaxAuthority5 = "TAXAUTH5";

			/// <summary>
			/// Property for ItemTaxClass1
			/// </summary>
			public const string ItemTaxClass1 = "ITAXCLASS1";

			/// <summary>
			/// Property for ItemTaxClass2
			/// </summary>
			public const string ItemTaxClass2 = "ITAXCLASS2";

			/// <summary>
			/// Property for ItemTaxClass3
			/// </summary>
			public const string ItemTaxClass3 = "ITAXCLASS3";

			/// <summary>
			/// Property for ItemTaxClass4
			/// </summary>
			public const string ItemTaxClass4 = "ITAXCLASS4";

			/// <summary>
			/// Property for ItemTaxClass5
			/// </summary>
			public const string ItemTaxClass5 = "ITAXCLASS5";

			/// <summary>
			/// Property for ItemTaxIncluded1
			/// </summary>
			public const string ItemTaxIncluded1 = "ITAXINCL1";

			/// <summary>
			/// Property for ItemTaxIncluded2
			/// </summary>
			public const string ItemTaxIncluded2 = "ITAXINCL2";

			/// <summary>
			/// Property for ItemTaxIncluded3
			/// </summary>
			public const string ItemTaxIncluded3 = "ITAXINCL3";

			/// <summary>
			/// Property for ItemTaxIncluded4
			/// </summary>
			public const string ItemTaxIncluded4 = "ITAXINCL4";

			/// <summary>
			/// Property for ItemTaxIncluded5
			/// </summary>
			public const string ItemTaxIncluded5 = "ITAXINCL5";

			/// <summary>
			/// Property for CustomerTaxClass1
			/// </summary>
			public const string CustomerTaxClass1 = "CTAXCLASS1";

			/// <summary>
			/// Property for CustomerTaxClass2
			/// </summary>
			public const string CustomerTaxClass2 = "CTAXCLASS2";

			/// <summary>
			/// Property for CustomerTaxClass3
			/// </summary>
			public const string CustomerTaxClass3 = "CTAXCLASS3";

			/// <summary>
			/// Property for CustomerTaxClass4
			/// </summary>
			public const string CustomerTaxClass4 = "CTAXCLASS4";

			/// <summary>
			/// Property for CustomerTaxClass5
			/// </summary>
			public const string CustomerTaxClass5 = "CTAXCLASS5";

			/// <summary>
			/// Property for BasePrice
			/// </summary>
			public const string BasePrice = "BASEPRICE";

			/// <summary>
			/// Property for StandardCost
			/// </summary>
			public const string StandardCost = "STDCOST";

			/// <summary>
			/// Property for MostRecentCost
			/// </summary>
			public const string MostRecentCost = "MOSTREC";

			/// <summary>
			/// Property for Cost1
			/// </summary>
			public const string Cost1 = "ALTCOST1";

			/// <summary>
			/// Property for Cost2
			/// </summary>
			public const string Cost2 = "ALTCOST2";

			/// <summary>
			/// Property for BaseUnitOfMeasure
			/// </summary>
			public const string BaseUnitOfMeasure = "BASEUNIT";

			/// <summary>
			/// Property for BaseConversionFactor
			/// </summary>
			public const string BaseConversionFactor = "BASEFACTOR";

			/// <summary>
			/// Property for PriceType
			/// </summary>
			public const string PriceType = "PRICETYPE";

			/// <summary>
			/// Property for PriceBase
			/// </summary>
			public const string PriceBase = "PRICEBASE";

			/// <summary>
			/// Property for PriceFormat
			/// </summary>
			public const string PriceFormat = "PRICEFMT";

			/// <summary>
			/// Property for Selection
			/// </summary>
			public const string Selection = "RECORDTYPE";

			/// <summary>
			/// Property for KeyPrice
			/// </summary>
			public const string KeyPrice = "KEYPRICE";

			/// <summary>
			/// Property for KeyUnit
			/// </summary>
			public const string KeyUnit = "KEYUNIT";

			/// <summary>
			/// Property for Quantity
			/// </summary>
			public const string Quantity = "QUANTITY";

			/// <summary>
			/// Property for CustomerType
			/// </summary>
			public const string CustomerType = "CUSTTYPE";

			/// <summary>
			/// Property for Percentage
			/// </summary>
			public const string Percentage = "DISCPERCNT";

			/// <summary>
			/// Property for Amount
			/// </summary>
			public const string Amount = "DISCAMOUNT";

			/// <summary>
			/// Property for UnitPrice
			/// </summary>
			public const string UnitPrice = "CALCPRICE";

			/// <summary>
			/// Property for PricingUOM
			/// </summary>
			public const string PricingUOM = "PRICEUNIT";

			/// <summary>
			/// Property for PriceConversionFactor
			/// </summary>
			public const string PriceConversionFactor = "PRICFACTOR";

			/// <summary>
			/// Property for UnitPriceOrderUOM
			/// </summary>
			public const string UnitPriceOrderUOM = "ORDERPRICE";

			/// <summary>
			/// Property for PriceDecimals
			/// </summary>
			public const string PriceDecimals = "PRICEDECS";

			/// <summary>
			/// Property for CustomerNumber
			/// </summary>
			public const string CustomerNumber = "CUSTNO";

			/// <summary>
			/// Property for Category
			/// </summary>
			public const string Category = "CATEGORY";

			/// <summary>
			/// Property for StockingUnit
			/// </summary>
			public const string StockingUnit = "STOCKUNIT";

			/// <summary>
			/// Property for KeyOrderUnit
			/// </summary>
			public const string KeyOrderUnit = "KEYORDUNIT";

			/// <summary>
			/// Property for ShowErrors
			/// </summary>
			public const string ShowErrors = "BROWSECHK";

			/// <summary>
			/// Property for AverageCost
			/// </summary>
			public const string AverageCost = "AVGCOST";

			/// <summary>
			/// Property for LastCost
			/// </summary>
			public const string LastCost = "LASTCOST";

			/// <summary>
			/// Property for OrderWeight
			/// </summary>
			public const string OrderWeight = "ORDERWGHT";

			/// <summary>
			/// Property for Weight
			/// </summary>
			public const string Weight = "WEIGHT";

			/// <summary>
			/// Property for OrderWeightUOM
			/// </summary>
			public const string OrderWeightUOM = "ORDERWUNIT";

			/// <summary>
			/// Property for BaseWeightUOM
			/// </summary>
			public const string BaseWeightUOM = "BASEWUNIT";

			/// <summary>
			/// Property for BaseWeightConversionFactor
			/// </summary>
			public const string BaseWeightConversionFactor = "BASWFACTOR";

			/// <summary>
			/// Property for KeyWeightUnit
			/// </summary>
			public const string KeyWeightUnit = "KEYWUNIT";

			/// <summary>
			/// Property for PricingWeightUOM
			/// </summary>
			public const string PricingWeightUOM = "PRICEWUNIT";

			/// <summary>
			/// Property for PriceWeightConversionFactor
			/// </summary>
			public const string PriceWeightConversionFactor = "PRIWFACTOR";

			/// <summary>
			/// Property for DefaultWeightUOM
			/// </summary>
			public const string DefaultWeightUOM = "DEFWUNIT";

			/// <summary>
			/// Property for KeyOrderWeightUnit
			/// </summary>
			public const string KeyOrderWeightUnit = "KEYORDWUNT";

			/// <summary>
			/// Property for PriceBy
			/// </summary>
			public const string PriceBy = "PRPRICEBY";

			/// <summary>
			/// Property for SetTaxIncluded
			/// </summary>
			public const string SetTaxIncluded = "SETTAXINCL";

			/// <summary>
			/// Property for ProcessCommand
			/// </summary>
			public const string ProcessCommand = "PROCESSCMD";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ItemPricing Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Currency
			/// </summary>
			public const int Currency = 1;

			/// <summary>
			/// Property Indexer for Item
			/// </summary>
			public const int Item = 2;

			/// <summary>
			/// Property Indexer for PriceList
			/// </summary>
			public const int PriceList = 3;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 4;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 5;

			/// <summary>
			/// Property Indexer for OrderQuantity
			/// </summary>
			public const int OrderQuantity = 6;

			/// <summary>
			/// Property Indexer for OrderUOM
			/// </summary>
			public const int OrderUOM = 7;

			/// <summary>
			/// Property Indexer for OrderDate
			/// </summary>
			public const int OrderDate = 8;

			/// <summary>
			/// Property Indexer for TaxGroup
			/// </summary>
			public const int TaxGroup = 9;

			/// <summary>
			/// Property Indexer for TaxAuthority1
			/// </summary>
			public const int TaxAuthority1 = 10;

			/// <summary>
			/// Property Indexer for TaxAuthority2
			/// </summary>
			public const int TaxAuthority2 = 11;

			/// <summary>
			/// Property Indexer for TaxAuthority3
			/// </summary>
			public const int TaxAuthority3 = 12;

			/// <summary>
			/// Property Indexer for TaxAuthority4
			/// </summary>
			public const int TaxAuthority4 = 13;

			/// <summary>
			/// Property Indexer for TaxAuthority5
			/// </summary>
			public const int TaxAuthority5 = 14;

			/// <summary>
			/// Property Indexer for ItemTaxClass1
			/// </summary>
			public const int ItemTaxClass1 = 15;

			/// <summary>
			/// Property Indexer for ItemTaxClass2
			/// </summary>
			public const int ItemTaxClass2 = 16;

			/// <summary>
			/// Property Indexer for ItemTaxClass3
			/// </summary>
			public const int ItemTaxClass3 = 17;

			/// <summary>
			/// Property Indexer for ItemTaxClass4
			/// </summary>
			public const int ItemTaxClass4 = 18;

			/// <summary>
			/// Property Indexer for ItemTaxClass5
			/// </summary>
			public const int ItemTaxClass5 = 19;

			/// <summary>
			/// Property Indexer for ItemTaxIncluded1
			/// </summary>
			public const int ItemTaxIncluded1 = 20;

			/// <summary>
			/// Property Indexer for ItemTaxIncluded2
			/// </summary>
			public const int ItemTaxIncluded2 = 21;

			/// <summary>
			/// Property Indexer for ItemTaxIncluded3
			/// </summary>
			public const int ItemTaxIncluded3 = 22;

			/// <summary>
			/// Property Indexer for ItemTaxIncluded4
			/// </summary>
			public const int ItemTaxIncluded4 = 23;

			/// <summary>
			/// Property Indexer for ItemTaxIncluded5
			/// </summary>
			public const int ItemTaxIncluded5 = 24;

			/// <summary>
			/// Property Indexer for CustomerTaxClass1
			/// </summary>
			public const int CustomerTaxClass1 = 25;

			/// <summary>
			/// Property Indexer for CustomerTaxClass2
			/// </summary>
			public const int CustomerTaxClass2 = 26;

			/// <summary>
			/// Property Indexer for CustomerTaxClass3
			/// </summary>
			public const int CustomerTaxClass3 = 27;

			/// <summary>
			/// Property Indexer for CustomerTaxClass4
			/// </summary>
			public const int CustomerTaxClass4 = 28;

			/// <summary>
			/// Property Indexer for CustomerTaxClass5
			/// </summary>
			public const int CustomerTaxClass5 = 29;

			/// <summary>
			/// Property Indexer for BasePrice
			/// </summary>
			public const int BasePrice = 30;

			/// <summary>
			/// Property Indexer for StandardCost
			/// </summary>
			public const int StandardCost = 31;

			/// <summary>
			/// Property Indexer for MostRecentCost
			/// </summary>
			public const int MostRecentCost = 32;

			/// <summary>
			/// Property Indexer for Cost1
			/// </summary>
			public const int Cost1 = 33;

			/// <summary>
			/// Property Indexer for Cost2
			/// </summary>
			public const int Cost2 = 34;

			/// <summary>
			/// Property Indexer for BaseUnitOfMeasure
			/// </summary>
			public const int BaseUnitOfMeasure = 35;

			/// <summary>
			/// Property Indexer for BaseConversionFactor
			/// </summary>
			public const int BaseConversionFactor = 36;

			/// <summary>
			/// Property Indexer for PriceType
			/// </summary>
			public const int PriceType = 37;

			/// <summary>
			/// Property Indexer for PriceBase
			/// </summary>
			public const int PriceBase = 38;

			/// <summary>
			/// Property Indexer for PriceFormat
			/// </summary>
			public const int PriceFormat = 39;

			/// <summary>
			/// Property Indexer for Selection
			/// </summary>
			public const int Selection = 40;

			/// <summary>
			/// Property Indexer for KeyPrice
			/// </summary>
			public const int KeyPrice = 41;

			/// <summary>
			/// Property Indexer for KeyUnit
			/// </summary>
			public const int KeyUnit = 42;

			/// <summary>
			/// Property Indexer for Quantity
			/// </summary>
			public const int Quantity = 43;

			/// <summary>
			/// Property Indexer for CustomerType
			/// </summary>
			public const int CustomerType = 44;

			/// <summary>
			/// Property Indexer for Percentage
			/// </summary>
			public const int Percentage = 45;

			/// <summary>
			/// Property Indexer for Amount
			/// </summary>
			public const int Amount = 46;

			/// <summary>
			/// Property Indexer for UnitPrice
			/// </summary>
			public const int UnitPrice = 47;

			/// <summary>
			/// Property Indexer for PricingUOM
			/// </summary>
			public const int PricingUOM = 48;

			/// <summary>
			/// Property Indexer for PriceConversionFactor
			/// </summary>
			public const int PriceConversionFactor = 49;

			/// <summary>
			/// Property Indexer for UnitPriceOrderUOM
			/// </summary>
			public const int UnitPriceOrderUOM = 50;

			/// <summary>
			/// Property Indexer for PriceDecimals
			/// </summary>
			public const int PriceDecimals = 51;

			/// <summary>
			/// Property Indexer for CustomerNumber
			/// </summary>
			public const int CustomerNumber = 52;

			/// <summary>
			/// Property Indexer for Category
			/// </summary>
			public const int Category = 53;

			/// <summary>
			/// Property Indexer for StockingUnit
			/// </summary>
			public const int StockingUnit = 54;

			/// <summary>
			/// Property Indexer for KeyOrderUnit
			/// </summary>
			public const int KeyOrderUnit = 55;

			/// <summary>
			/// Property Indexer for ShowErrors
			/// </summary>
			public const int ShowErrors = 56;

			/// <summary>
			/// Property Indexer for AverageCost
			/// </summary>
			public const int AverageCost = 57;

			/// <summary>
			/// Property Indexer for LastCost
			/// </summary>
			public const int LastCost = 58;

			/// <summary>
			/// Property Indexer for OrderWeight
			/// </summary>
			public const int OrderWeight = 59;

			/// <summary>
			/// Property Indexer for Weight
			/// </summary>
			public const int Weight = 60;

			/// <summary>
			/// Property Indexer for OrderWeightUOM
			/// </summary>
			public const int OrderWeightUOM = 61;

			/// <summary>
			/// Property Indexer for BaseWeightUOM
			/// </summary>
			public const int BaseWeightUOM = 62;

			/// <summary>
			/// Property Indexer for BaseWeightConversionFactor
			/// </summary>
			public const int BaseWeightConversionFactor = 63;

			/// <summary>
			/// Property Indexer for KeyWeightUnit
			/// </summary>
			public const int KeyWeightUnit = 64;

			/// <summary>
			/// Property Indexer for PricingWeightUOM
			/// </summary>
			public const int PricingWeightUOM = 65;

			/// <summary>
			/// Property Indexer for PriceWeightConversionFactor
			/// </summary>
			public const int PriceWeightConversionFactor = 66;

			/// <summary>
			/// Property Indexer for DefaultWeightUOM
			/// </summary>
			public const int DefaultWeightUOM = 67;

			/// <summary>
			/// Property Indexer for KeyOrderWeightUnit
			/// </summary>
			public const int KeyOrderWeightUnit = 68;

			/// <summary>
			/// Property Indexer for PriceBy
			/// </summary>
			public const int PriceBy = 69;

			/// <summary>
			/// Property Indexer for SetTaxIncluded
			/// </summary>
			public const int SetTaxIncluded = 70;

			/// <summary>
			/// Property Indexer for ProcessCommand
			/// </summary>
			public const int ProcessCommand = 71;

		}

		#endregion

	}
}
