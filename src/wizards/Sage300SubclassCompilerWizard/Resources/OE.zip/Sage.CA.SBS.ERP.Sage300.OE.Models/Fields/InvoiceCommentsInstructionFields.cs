// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of InvoiceCommentsInstruction Constants
	/// </summary>
	public partial class InvoiceCommentsInstruction
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0160";

		#region Properties

		/// <summary>
		/// Contains list of InvoiceCommentsInstruction Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for InvoiceUniquifier
			/// </summary>
			public const string InvoiceUniquifier = "INVUNIQ";

			/// <summary>
			/// Property for LineUniquifier
			/// </summary>
			public const string LineUniquifier = "UNIQUIFIER";

			/// <summary>
			/// Property for DetailNumber
			/// </summary>
			public const string DetailNumber = "DETAILNUM";

			/// <summary>
			/// Property for CommentsInstructionsType
			/// </summary>
			public const string CommentsInstructionsType = "COINTYPE";

			/// <summary>
			/// Property for CommentsInstructions
			/// </summary>
			public const string CommentsInstructions = "COIN";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of InvoiceCommentsInstruction Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for InvoiceUniquifier
			/// </summary>
			public const int InvoiceUniquifier = 1;

			/// <summary>
			/// Property Indexer for LineUniquifier
			/// </summary>
			public const int LineUniquifier = 2;

			/// <summary>
			/// Property Indexer for DetailNumber
			/// </summary>
			public const int DetailNumber = 3;

			/// <summary>
			/// Property Indexer for CommentsInstructionsType
			/// </summary>
			public const int CommentsInstructionsType = 4;

			/// <summary>
			/// Property Indexer for CommentsInstructions
			/// </summary>
			public const int CommentsInstructions = 5;

		}

		#endregion

	}
}
