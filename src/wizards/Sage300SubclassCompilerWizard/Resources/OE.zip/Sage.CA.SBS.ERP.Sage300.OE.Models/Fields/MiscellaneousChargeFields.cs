// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of MiscellaneousCharge Constants
     /// </summary>
     public partial class MiscellaneousCharge
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "OE0440";

          #region Properties
          /// <summary>
          /// Contains list of MiscellaneousCharge Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Currency
               /// </summary>
               public const string Currency = "CURRENCY";

               /// <summary>
               /// Property for MiscellaneousChargeCode
               /// </summary>
               public const string MiscellaneousChargeCode = "MISCCHARGE";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for MiscChargeRevenueAccount
               /// </summary>
               public const string MiscChargeRevenueAccount = "MISCACCT";

               /// <summary>
               /// Property for Amount
               /// </summary>
               public const string Amount = "AMOUNT";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for AccountDescription
               /// </summary>
               public const string AccountDescription = "MISCACDESC";

               /// <summary>
               /// Property for ProcessCommand
               /// </summary>
               public const string ProcessCommand = "PROCESSCMD";

               /// <summary>
               /// Property for JobRelated
               /// </summary>
               public const string JobRelated = "HASJOB";

               /// <summary>
               /// Property for ExtendedCost
               /// </summary>
               public const string ExtendedCost = "EXTCOST";

               /// <summary>
               /// Property for MiscChargeExpenseAccount
               /// </summary>
               public const string MiscChargeExpenseAccount = "MCCOSTEXP";

               /// <summary>
               /// Property for MiscChargeClearingAccount
               /// </summary>
               public const string MiscChargeClearingAccount = "MCCLEARING";

               /// <summary>
               /// Property for MiscChargeCostExpenseAccountDescription
               /// </summary>
               public const string MiscChargeCostExpenseAccountDescription = "CSTEXPDESC";

               /// <summary>
               /// Property for MiscChargeClearingAccountDescription
               /// </summary>
               public const string MiscChargeClearingAccountDescription = "MCCLRDESC";

               /// <summary>
               /// Property for FunctionalCurrency
               /// </summary>
               public const string FunctionalCurrency = "FUNCCURR";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of MiscellaneousCharge Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Currency
               /// </summary>
               public const int Currency = 1;

               /// <summary>
               /// Property Indexer for MiscellaneousChargeCode
               /// </summary>
               public const int MiscellaneousChargeCode = 2;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 3;

               /// <summary>
               /// Property Indexer for MiscChargeRevenueAccount
               /// </summary>
               public const int MiscChargeRevenueAccount = 4;

               /// <summary>
               /// Property Indexer for Amount
               /// </summary>
               public const int Amount = 5;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 6;

               /// <summary>
               /// Property Indexer for AccountDescription
               /// </summary>
               public const int AccountDescription = 7;

               /// <summary>
               /// Property Indexer for ProcessCommand
               /// </summary>
               public const int ProcessCommand = 8;

               /// <summary>
               /// Property Indexer for JobRelated
               /// </summary>
               public const int JobRelated = 9;

               /// <summary>
               /// Property Indexer for ExtendedCost
               /// </summary>
               public const int ExtendedCost = 10;

               /// <summary>
               /// Property Indexer for MiscChargeExpenseAccount
               /// </summary>
               public const int MiscChargeExpenseAccount = 11;

               /// <summary>
               /// Property Indexer for MiscChargeClearingAccount
               /// </summary>
               public const int MiscChargeClearingAccount = 12;

               /// <summary>
               /// Property Indexer for MiscChargeCostExpenseAccoun
               /// </summary>
               public const int MiscChargeCostExpenseAccountDescription = 13;

               /// <summary>
               /// Property Indexer for MiscChargeClearingAccountDe
               /// </summary>
               public const int MiscChargeClearingAccountDescription = 14;

               /// <summary>
               /// Property Indexer for FunctionalCurrency
               /// </summary>
               public const int FunctionalCurrency = 15;

          }
          #endregion

     }
}
