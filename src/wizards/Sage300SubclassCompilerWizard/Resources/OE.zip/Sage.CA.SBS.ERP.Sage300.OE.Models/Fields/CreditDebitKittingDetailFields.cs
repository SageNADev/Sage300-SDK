// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CreditDebitKittingDetail Constants
    /// </summary>
    public partial class CreditDebitKittingDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0222";

        #region Properties
        /// <summary>
        /// Contains list of CreditDebitKittingDetail Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for CNUniquifier
            /// </summary>
            public const string CnUniquifier = "CRDUNIQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENUM";

            /// <summary>
            /// Property for ParentComponentNumber
            /// </summary>
            public const string ParentComponentNumber = "PRNCOMPNUM";

            /// <summary>
            /// Property for ComponentNumber
            /// </summary>
            public const string ComponentNumber = "COMPNUM";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for ComponentItem
            /// </summary>
            public const string ComponentItem = "COMPONENT";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for ItemAccountSet
            /// </summary>
            public const string ItemAccountSet = "ACCTSET";

            /// <summary>
            /// Property for UserSpecifiedCostingMethod
            /// </summary>
            public const string UserSpecifiedCostingMethod = "USERCOSTMD";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for PickingSequence
            /// </summary>
            public const string PickingSequence = "PICKSEQ";

            /// <summary>
            /// Property for StockItem
            /// </summary>
            public const string StockItem = "STOCKITEM";

            /// <summary>
            /// Property for KittingQuantity
            /// </summary>
            public const string KittingQuantity = "QTY";

            /// <summary>
            /// Property for ParentQuantityReturned
            /// </summary>
            public const string ParentQuantityReturned = "PRNQTYRET";

            /// <summary>
            /// Property for ParentUnitOfMeasure
            /// </summary>
            public const string ParentUnitOfMeasure = "PRNUNIT";

            /// <summary>
            /// Property for ParentUnitConversion
            /// </summary>
            public const string ParentUnitConversion = "PRNUNTCONV";

            /// <summary>
            /// Property for QuantityReturned
            /// </summary>
            public const string QuantityReturned = "QTYRETURN";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "CRDUNIT";

            /// <summary>
            /// Property for UnitConversion
            /// </summary>
            public const string UnitConversion = "UNITCONV";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for MostRecentUnitCost
            /// </summary>
            public const string MostRecentUnitCost = "MOSTREC";

            /// <summary>
            /// Property for StandardUnitCost
            /// </summary>
            public const string StandardUnitCost = "STDCOST";

            /// <summary>
            /// Property for AlternateUnitCost1
            /// </summary>
            public const string AlternateUnitCost1 = "COST1";

            /// <summary>
            /// Property for AlternateUnitCost2
            /// </summary>
            public const string AlternateUnitCost2 = "COST2";

            /// <summary>
            /// Property for AverageUnitCost
            /// </summary>
            public const string AverageUnitCost = "AVGCOST";

            /// <summary>
            /// Property for LastUnitCost
            /// </summary>
            public const string LastUnitCost = "LASTCOST";

            /// <summary>
            /// Property for CostingUnitOfMeasure
            /// </summary>
            public const string CostingUnitOfMeasure = "COSTUNIT";

            /// <summary>
            /// Property for CostingUnitCost
            /// </summary>
            public const string CostingUnitCost = "COSUNTCST";

            /// <summary>
            /// Property for CostingUnitConversion
            /// </summary>
            public const string CostingUnitConversion = "COSUNTCONV";

            /// <summary>
            /// Property for ExtendedOrderCost
            /// </summary>
            public const string ExtendedOrderCost = "EXTCCOST";

            /// <summary>
            /// Property for UnitWeight
            /// </summary>
            public const string UnitWeight = "UNITWEIGHT";

            /// <summary>
            /// Property for ExtendedWeight
            /// </summary>
            public const string ExtendedWeight = "EXTWEIGHT";

            /// <summary>
            /// Property for NonstockClearingAccount
            /// </summary>
            public const string NonstockClearingAccount = "GLNONSTKCR";

            /// <summary>
            /// Property for WeightUnitOfMeasure
            /// </summary>
            public const string WeightUnitOfMeasure = "WEIGHTUNIT";

            /// <summary>
            /// Property for WeightConversionFactor
            /// </summary>
            public const string WeightConversionFactor = "WEIGHTCONV";

            /// <summary>
            /// Property for ParentWeightConversionFactor
            /// </summary>
            public const string ParentWeightConversionFactor = "PRNWGTCONV";

            /// <summary>
            /// Property for ParentWeightUOMUnitWeight
            /// </summary>
            public const string ParentWeightUomUnitWeight = "PRNUWEIGHT";

            /// <summary>
            /// Property for ParentWUOMExtendedUnitWeight
            /// </summary>
            public const string ParentWUomExtendedUnitWeight = "PRNEXTWGHT";

            /// <summary>
            /// Property for KitNo
            /// </summary>
            public const string KitNo = "DDTLNO";

            /// <summary>
            /// Property for CostOfGoods
            /// </summary>
            public const string CostOfGoods = "COG";

            /// <summary>
            /// Property for RecordCosted
            /// </summary>
            public const string RecordCosted = "COSTED";

            /// <summary>
            /// Property for SerialQuantity
            /// </summary>
            public const string SerialQuantity = "SERIALQTY";

            /// <summary>
            /// Property for LotQuantity
            /// </summary>
            public const string LotQuantity = "LOTQTY";

            /// <summary>
            /// Property for ItemSerializedLotted
            /// </summary>
            public const string ItemSerializedLotted = "SLITEM";

            /// <summary>
            /// Property for ComponentUnitCost
            /// </summary>
            public const string ComponentUnitCost = "CMPUNTCOST";

            /// <summary>
            /// Property for MostRecentComponentCost
            /// </summary>
            public const string MostRecentComponentCost = "CMPMOSTREC";

            /// <summary>
            /// Property for StandardComponentCost
            /// </summary>
            public const string StandardComponentCost = "CMPSTDCOST";

            /// <summary>
            /// Property for AlternateComponentCost1
            /// </summary>
            public const string AlternateComponentCost1 = "CMPCOST1";

            /// <summary>
            /// Property for AlternateComponentCost2
            /// </summary>
            public const string AlternateComponentCost2 = "CMPCOST2";

            /// <summary>
            /// Property for AverageComponentCost
            /// </summary>
            public const string AverageComponentCost = "CMPAVGCOST";

            /// <summary>
            /// Property for LastComponentCost
            /// </summary>
            public const string LastComponentCost = "CMPLSTCOST";

            /// <summary>
            /// Property for NonstockClearingAcctDesc
            /// </summary>
            public const string NonstockClearingAcctDesc = "GLNONSTKCD";

            /// <summary>
            /// Property for InterprocessCommID
            /// </summary>
            public const string InterprocessCommID = "IPCID";

            /// <summary>
            /// Property for ForcePopupSN
            /// </summary>
            public const string ForcePopupSn = "FORCEPOPSN";

            /// <summary>
            /// Property for PopupSN
            /// </summary>
            public const string PopupSn = "POPUPSN";

            /// <summary>
            /// Property for CloseSN
            /// </summary>
            public const string CloseSn = "CLOSESN";

            /// <summary>
            /// Property for LTSetID
            /// </summary>
            public const string LtSetId = "LTSETID";

            /// <summary>
            /// Property for ForcePopupLT
            /// </summary>
            public const string ForcePopupLt = "FORCEPOPLT";

            /// <summary>
            /// Property for PopupLT
            /// </summary>
            public const string PopupLt = "POPUPLT";

            /// <summary>
            /// Property for CloseLT
            /// </summary>
            public const string CloseLt = "CLOSELT";

            /// <summary>
            /// Property for CcomponentSerialized
            /// </summary>
            public const string CcomponentSerialized = "SERIALITEM";

            /// <summary>
            /// Property for UnformattedItemNumber
            /// </summary>
            public const string UnformattedItemNumber = "UNFMTITEM";

            /// <summary>
            /// Property for ShipmentNumber
            /// </summary>
            public const string ShipmentNumber = "SHINUMBER";

            /// <summary>
            /// Property for ShipmentDetailLineNumber
            /// </summary>
            public const string ShipmentDetailLineNumber = "SHIDTLNUM";

            /// <summary>
            /// Property for ReturnType
            /// </summary>
            public const string ReturnType = "RETURNTYPE";

            /// <summary>
            /// Property for ComponentLotted
            /// </summary>
            public const string ComponentLotted = "LOTTEDITEM";

            /// <summary>
            /// Property for WeightUOMDescription
            /// </summary>
            public const string WeightUomDescription = "WUOMDESC";

            /// <summary>
            /// Property for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Property for SerialLotQuantityToProcess
            /// </summary>
            public const string SerialLotQuantityToProcess = "XGENALCQTY";

            /// <summary>
            /// Property for NumberOfLotsToGenerate
            /// </summary>
            public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

            /// <summary>
            /// Property for QuantityperLot
            /// </summary>
            public const string QuantityperLot = "XPERLOTQTY";

            /// <summary>
            /// Property for AllocateFromSerial
            /// </summary>
            public const string AllocateFromSerial = "SALLOCFROM";

            /// <summary>
            /// Property for AllocateFromLot
            /// </summary>
            public const string AllocateFromLot = "LALLOCFROM";

            /// <summary>
            /// Property for SerialLotWindowHandle
            /// </summary>
            public const string SerialLotWindowHandle = "METERHWND";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of CreditDebitKittingDetail Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for CNUniquifier
            /// </summary>
            public const int CnUniquifier = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for ParentComponentNumber
            /// </summary>
            public const int ParentComponentNumber = 3;

            /// <summary>
            /// Property Indexer for ComponentNumber
            /// </summary>
            public const int ComponentNumber = 4;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 5;

            /// <summary>
            /// Property Indexer for ComponentItem
            /// </summary>
            public const int ComponentItem = 6;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 7;

            /// <summary>
            /// Property Indexer for ItemAccountSet
            /// </summary>
            public const int ItemAccountSet = 8;

            /// <summary>
            /// Property Indexer for UserSpecifiedCostingMethod
            /// </summary>
            public const int UserSpecifiedCostingMethod = 9;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 10;

            /// <summary>
            /// Property Indexer for PickingSequence
            /// </summary>
            public const int PickingSequence = 11;

            /// <summary>
            /// Property Indexer for StockItem
            /// </summary>
            public const int StockItem = 12;

            /// <summary>
            /// Property Indexer for KittingQuantity
            /// </summary>
            public const int KittingQuantity = 13;

            /// <summary>
            /// Property Indexer for ParentQuantityReturned
            /// </summary>
            public const int ParentQuantityReturned = 14;

            /// <summary>
            /// Property Indexer for ParentUnitOfMeasure
            /// </summary>
            public const int ParentUnitOfMeasure = 15;

            /// <summary>
            /// Property Indexer for ParentUnitConversion
            /// </summary>
            public const int ParentUnitConversion = 16;

            /// <summary>
            /// Property Indexer for QuantityReturned
            /// </summary>
            public const int QuantityReturned = 17;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 18;

            /// <summary>
            /// Property Indexer for UnitConversion
            /// </summary>
            public const int UnitConversion = 19;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 20;

            /// <summary>
            /// Property Indexer for MostRecentUnitCost
            /// </summary>
            public const int MostRecentUnitCost = 21;

            /// <summary>
            /// Property Indexer for StandardUnitCost
            /// </summary>
            public const int StandardUnitCost = 22;

            /// <summary>
            /// Property Indexer for AlternateUnitCost1
            /// </summary>
            public const int AlternateUnitCost1 = 23;

            /// <summary>
            /// Property Indexer for AlternateUnitCost2
            /// </summary>
            public const int AlternateUnitCost2 = 24;

            /// <summary>
            /// Property Indexer for AverageUnitCost
            /// </summary>
            public const int AverageUnitCost = 25;

            /// <summary>
            /// Property Indexer for LastUnitCost
            /// </summary>
            public const int LastUnitCost = 26;

            /// <summary>
            /// Property Indexer for CostingUnitOfMeasure
            /// </summary>
            public const int CostingUnitOfMeasure = 27;

            /// <summary>
            /// Property Indexer for CostingUnitCost
            /// </summary>
            public const int CostingUnitCost = 28;

            /// <summary>
            /// Property Indexer for CostingUnitConversion
            /// </summary>
            public const int CostingUnitConversion = 29;

            /// <summary>
            /// Property Indexer for ExtendedOrderCost
            /// </summary>
            public const int ExtendedOrderCost = 30;

            /// <summary>
            /// Property Indexer for UnitWeight
            /// </summary>
            public const int UnitWeight = 31;

            /// <summary>
            /// Property Indexer for ExtendedWeight
            /// </summary>
            public const int ExtendedWeight = 32;

            /// <summary>
            /// Property Indexer for NonstockClearingAccount
            /// </summary>
            public const int NonstockClearingAccount = 34;

            /// <summary>
            /// Property Indexer for WeightUnitOfMeasure
            /// </summary>
            public const int WeightUnitOfMeasure = 35;

            /// <summary>
            /// Property Indexer for WeightConversionFactor
            /// </summary>
            public const int WeightConversionFactor = 36;

            /// <summary>
            /// Property Indexer for ParentWeightConversionFactor
            /// </summary>
            public const int ParentWeightConversionFactor = 37;

            /// <summary>
            /// Property Indexer for ParentWeightUOMUnitWeight
            /// </summary>
            public const int ParentWeightUomUnitWeight = 38;

            /// <summary>
            /// Property Indexer for ParentWUOMExtendedUnitWeight
            /// </summary>
            public const int ParentWUomExtendedUnitWeight = 39;

            /// <summary>
            /// Property Indexer for KitNo
            /// </summary>
            public const int KitNo = 40;

            /// <summary>
            /// Property Indexer for CostOfGoods
            /// </summary>
            public const int CostOfGoods = 41;

            /// <summary>
            /// Property Indexer for RecordCosted
            /// </summary>
            public const int RecordCosted = 42;

            /// <summary>
            /// Property Indexer for SerialQuantity
            /// </summary>
            public const int SerialQuantity = 43;

            /// <summary>
            /// Property Indexer for LotQuantity
            /// </summary>
            public const int LotQuantity = 44;

            /// <summary>
            /// Property Indexer for ItemSerializedLotted
            /// </summary>
            public const int ItemSerializedLotted = 45;

            /// <summary>
            /// Property Indexer for ComponentUnitCost
            /// </summary>
            public const int ComponentUnitCost = 100;

            /// <summary>
            /// Property Indexer for MostRecentComponentCost
            /// </summary>
            public const int MostRecentComponentCost = 101;

            /// <summary>
            /// Property Indexer for StandardComponentCost
            /// </summary>
            public const int StandardComponentCost = 102;

            /// <summary>
            /// Property Indexer for AlternateComponentCost1
            /// </summary>
            public const int AlternateComponentCost1 = 103;

            /// <summary>
            /// Property Indexer for AlternateComponentCost2
            /// </summary>
            public const int AlternateComponentCost2 = 104;

            /// <summary>
            /// Property Indexer for AverageComponentCost
            /// </summary>
            public const int AverageComponentCost = 105;

            /// <summary>
            /// Property Indexer for LastComponentCost
            /// </summary>
            public const int LastComponentCost = 106;

            /// <summary>
            /// Property Indexer for NonstockClearingAcctDesc
            /// </summary>
            public const int NonstockClearingAcctDesc = 107;

            /// <summary>
            /// Property Indexer for InterprocessCommID
            /// </summary>
            public const int InterprocessCommID = 108;

            /// <summary>
            /// Property Indexer for ForcePopupSN
            /// </summary>
            public const int ForcePopupSn = 109;

            /// <summary>
            /// Property Indexer for PopupSN
            /// </summary>
            public const int PopupSn = 110;

            /// <summary>
            /// Property Indexer for CloseSN
            /// </summary>
            public const int CloseSn = 111;

            /// <summary>
            /// Property Indexer for LTSetID
            /// </summary>
            public const int LtSetId = 112;

            /// <summary>
            /// Property Indexer for ForcePopupLT
            /// </summary>
            public const int ForcePopupLt = 113;

            /// <summary>
            /// Property Indexer for PopupLT
            /// </summary>
            public const int PopupLt = 114;

            /// <summary>
            /// Property Indexer for CloseLT
            /// </summary>
            public const int CloseLt = 115;

            /// <summary>
            /// Property Indexer for CcomponentSerialized
            /// </summary>
            public const int CcomponentSerialized = 116;

            /// <summary>
            /// Property Indexer for UnformattedItemNumber
            /// </summary>
            public const int UnformattedItemNumber = 117;

            /// <summary>
            /// Property Indexer for ShipmentNumber
            /// </summary>
            public const int ShipmentNumber = 118;

            /// <summary>
            /// Property Indexer for ShipmentDetailLineNumber
            /// </summary>
            public const int ShipmentDetailLineNumber = 119;

            /// <summary>
            /// Property Indexer for ReturnType
            /// </summary>
            public const int ReturnType = 120;

            /// <summary>
            /// Property Indexer for ComponentLotted
            /// </summary>
            public const int ComponentLotted = 121;

            /// <summary>
            /// Property Indexer for WeightUOMDescription
            /// </summary>
            public const int WeightUomDescription = 122;

            /// <summary>
            /// Property Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 123;

            /// <summary>
            /// Property Indexer for SerialLotQuantityToProcess
            /// </summary>
            public const int SerialLotQuantityToProcess = 124;

            /// <summary>
            /// Property Indexer for NumberOfLotsToGenerate
            /// </summary>
            public const int NumberOfLotsToGenerate = 125;

            /// <summary>
            /// Property Indexer for QuantityperLot
            /// </summary>
            public const int QuantityperLot = 126;

            /// <summary>
            /// Property Indexer for AllocateFromSerial
            /// </summary>
            public const int AllocateFromSerial = 127;

            /// <summary>
            /// Property Indexer for AllocateFromLot
            /// </summary>
            public const int AllocateFromLot = 128;

            /// <summary>
            /// Property Indexer for SerialLotWindowHandle
            /// </summary>
            public const int SerialLotWindowHandle = 129;

        }
        #endregion

    }
}
