// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of CreateOrderfromExistingOrder Constants
     /// </summary>
     public partial class CreateOrderfromExistingOrder
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "OE0490";

          #region Properties
          /// <summary>
          /// Contains list of CreateOrderfromExistingOrder Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for FromCustomerNumber
               /// </summary>
               public const string FromCustomerNumber = "FRCUST";

               /// <summary>
               /// Property for ToCustomerNumber
               /// </summary>
               public const string ToCustomerNumber = "TOCUST";

               /// <summary>
               /// Property for FromOrderNumber
               /// </summary>
               public const string FromOrderNumber = "FRORDER";

               /// <summary>
               /// Property for ToOrderNumber
               /// </summary>
               public const string ToOrderNumber = "TOORDER";

               /// <summary>
               /// Property for PriceList
               /// </summary>
               public const string PriceList = "PRICELIST";

               /// <summary>
               /// Property for PriceListDescription
               /// </summary>
               public const string PriceListDescription = "PCODDESC";

               /// <summary>
               /// Property for ActionPerformed
               /// </summary>
               public const string ActionPerformed = "ACTION";

               /// <summary>
               /// Property for TaxGroup
               /// </summary>
               public const string TaxGroup = "TAXGROUP";

               /// <summary>
               /// Property for TaxGroupDescription
               /// </summary>
               public const string TaxGroupDescription = "TXGRPDESC";

               /// <summary>
               /// Property for TaxGroupCurrency
               /// </summary>
               public const string TaxGroupCurrency = "TXGRPCURR";

               /// <summary>
               /// Property for FromCustomerCurrency
               /// </summary>
               public const string FromCustomerCurrency = "FRCUSTCURR";

               /// <summary>
               /// Property for ToCustomerCurrency
               /// </summary>
               public const string ToCustomerCurrency = "TOCUSTCURR";

               /// <summary>
               /// Property for FromCustomerName
               /// </summary>
               public const string FromCustomerName = "FRCUSTNAME";

               /// <summary>
               /// Property for ToCustomerName
               /// </summary>
               public const string ToCustomerName = "TOCUSTNAME";

               /// <summary>
               /// Property for OrderType
               /// </summary>
               public const string OrderType = "ORDTYPE";

               /// <summary>
               /// Property for JobRelated
               /// </summary>
               public const string JobRelated = "HASJOB";

               /// <summary>
               /// Property for ProjectInvoicing
               /// </summary>
               public const string ProjectInvoicing = "NONINVABLE";
          }

          #endregion

          #region Properties

          /// <summary>
          /// Contains list of CreateOrderfromExistingOrder Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for FromCustomerNumber
               /// </summary>
               public const int FromCustomerNumber = 1;

               /// <summary>
               /// Property Indexer for ToCustomerNumber
               /// </summary>
               public const int ToCustomerNumber = 2;

               /// <summary>
               /// Property Indexer for FromOrderNumber
               /// </summary>
               public const int FromOrderNumber = 3;

               /// <summary>
               /// Property Indexer for ToOrderNumber
               /// </summary>
               public const int ToOrderNumber = 4;

               /// <summary>
               /// Property Indexer for PriceList
               /// </summary>
               public const int PriceList = 5;

               /// <summary>
               /// Property Indexer for PriceListDescription
               /// </summary>
               public const int PriceListDescription = 6;

               /// <summary>
               /// Property Indexer for ActionPerformed
               /// </summary>
               public const int ActionPerformed = 7;

               /// <summary>
               /// Property Indexer for TaxGroup
               /// </summary>
               public const int TaxGroup = 8;

               /// <summary>
               /// Property Indexer for TaxGroupDescription
               /// </summary>
               public const int TaxGroupDescription = 9;

               /// <summary>
               /// Property Indexer for TaxGroupCurrency
               /// </summary>
               public const int TaxGroupCurrency = 10;

               /// <summary>
               /// Property Indexer for FromCustomerCurrency
               /// </summary>
               public const int FromCustomerCurrency = 11;

               /// <summary>
               /// Property Indexer for ToCustomerCurrency
               /// </summary>
               public const int ToCustomerCurrency = 12;

               /// <summary>
               /// Property Indexer for FromCustomerName
               /// </summary>
               public const int FromCustomerName = 13;

               /// <summary>
               /// Property Indexer for ToCustomerName
               /// </summary>
               public const int ToCustomerName = 14;

               /// <summary>
               /// Property Indexer for OrderType
               /// </summary>
               public const int OrderType = 15;

               /// <summary>
               /// Property Indexer for JobRelated
               /// </summary>
               public const int JobRelated = 16;

               /// <summary>
               /// Property Indexer for ProjectInvoicing
               /// </summary>
               public const int ProjectInvoicing = 17;
          }

          #endregion
     }
}
