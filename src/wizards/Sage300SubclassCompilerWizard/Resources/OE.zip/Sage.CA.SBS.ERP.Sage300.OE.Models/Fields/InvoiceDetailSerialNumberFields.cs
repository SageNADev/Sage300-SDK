// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of InvoiceDetailSerialNumber Constants
	/// </summary>
	public partial class InvoiceDetailSerialNumber
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0407";

		#region Properties

		/// <summary>
		/// Contains list of InvoiceDetailSerialNumber Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for InvoiceUniquifier
			/// </summary>
			public const string InvoiceUniquifier = "INVUNIQ";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "LINENUM";

			/// <summary>
			/// Property for SerialNumber
			/// </summary>
			public const string SerialNumber = "SERIALNUMF";

			/// <summary>
			/// Property for DetailNumber
			/// </summary>
			public const string DetailNumber = "DETAILNUM";

			/// <summary>
			/// Property for Cost
			/// </summary>
			public const string Cost = "COST";

			/// <summary>
			/// Property for TransactionQuantity
			/// </summary>
			public const string TransactionQuantity = "QTY";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of InvoiceDetailSerialNumber Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for InvoiceUniquifier
			/// </summary>
			public const int InvoiceUniquifier = 1;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 2;

			/// <summary>
			/// Property Indexer for SerialNumber
			/// </summary>
			public const int SerialNumber = 3;

			/// <summary>
			/// Property Indexer for DetailNumber
			/// </summary>
			public const int DetailNumber = 4;

			/// <summary>
			/// Property Indexer for Cost
			/// </summary>
			public const int Cost = 5;

			/// <summary>
			/// Property Indexer for TransactionQuantity
			/// </summary>
			public const int TransactionQuantity = 50;

		}

		#endregion

	}
}
