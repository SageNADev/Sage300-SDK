// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of OrderBOMDetail Constants
     /// </summary>
     public partial class OrderBOMDetail
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "OE0503";

          #region Properties
          /// <summary>
          /// Contains list of OrderBOMDetail Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for OrderUniquifier
               /// </summary>
               public const string OrderUniquifier = "ORDUNIQ";

               /// <summary>
               /// Property for DetailLineNumber
               /// </summary>
               public const string DetailLineNumber = "LINENUM";

               /// <summary>
               /// Property for ParentComponentNumber
               /// </summary>
               public const string ParentComponentNumber = "PRNCOMPNUM";

               /// <summary>
               /// Property for ComponentNumber
               /// </summary>
               public const string ComponentNumber = "COMPNUM";

               /// <summary>
               /// Property for ComponentItemNumber
               /// </summary>
               public const string ComponentItemNumber = "COMPONENT";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for ComponentQuantity
               /// </summary>
               public const string ComponentQuantity = "QTY";

               /// <summary>
               /// Property for UnitOfMeasure
               /// </summary>
               public const string UnitOfMeasure = "UNIT";

               /// <summary>
               /// Property for QuantityOrdered
               /// </summary>
               public const string QuantityOrdered = "QTYORDERED";

               /// <summary>
               /// Property for QuantityShipped
               /// </summary>
               public const string QuantityShipped = "QTYSHIPPED";

               /// <summary>
               /// Property for ComponentsBOMNumber
               /// </summary>
               public const string ComponentsBOMNumber = "DDTLNO";

               /// <summary>
               /// Property for ComponentsBOMBuildQty
               /// </summary>
               public const string ComponentsBOMBuildQty = "BUILDQTY";

               /// <summary>
               /// Property for ComponentsBOMBuildUnit
               /// </summary>
               public const string ComponentsBOMBuildUnit = "BUILDUNIT";

               /// <summary>
               /// Property for ComponentsBOMBuildUnitConv
               /// </summary>
               public const string ComponentsBOMBuildUnitConv = "BLDUNTCONV";

               /// <summary>
               /// Property for UnitConversion
               /// </summary>
               public const string UnitConversion = "UNITCONV";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of OrderBOMDetail Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for OrderUniquifier
               /// </summary>
               public const int OrderUniquifier = 1;

               /// <summary>
               /// Property Indexer for DetailLineNumber
               /// </summary>
               public const int DetailLineNumber = 2;

               /// <summary>
               /// Property Indexer for ParentComponentNumber
               /// </summary>
               public const int ParentComponentNumber = 3;

               /// <summary>
               /// Property Indexer for ComponentNumber
               /// </summary>
               public const int ComponentNumber = 4;

               /// <summary>
               /// Property Indexer for ComponentItemNumber
               /// </summary>
               public const int ComponentItemNumber = 5;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 6;

               /// <summary>
               /// Property Indexer for ComponentQuantity
               /// </summary>
               public const int ComponentQuantity = 7;

               /// <summary>
               /// Property Indexer for UnitOfMeasure
               /// </summary>
               public const int UnitOfMeasure = 8;

               /// <summary>
               /// Property Indexer for QuantityOrdered
               /// </summary>
               public const int QuantityOrdered = 9;

               /// <summary>
               /// Property Indexer for QuantityShipped
               /// </summary>
               public const int QuantityShipped = 10;

               /// <summary>
               /// Property Indexer for ComponentsBOMNumber
               /// </summary>
               public const int ComponentsBOMNumber = 11;

               /// <summary>
               /// Property Indexer for ComponentsBOMBuildQty
               /// </summary>
               public const int ComponentsBOMBuildQty = 12;

               /// <summary>
               /// Property Indexer for ComponentsBOMBuildUnit
               /// </summary>
               public const int ComponentsBOMBuildUnit = 13;

               /// <summary>
               /// Property Indexer for ComponentsBOMBuildUnitConv
               /// </summary>
               public const int ComponentsBOMBuildUnitConv = 14;

               /// <summary>
               /// Property Indexer for UnitConversion
               /// </summary>
               public const int UnitConversion = 15;

          }
          #endregion

     }
}
