// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using System.Collections.Generic;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of OrderDetail Constants
     /// </summary>
     public partial class OrderDetail
     {
          /// <summary>
          /// Entity Name
          /// </summary>
          public const string EntityName = "OE0500";

          /// <summary>
          /// Dynamic Attributes contain a reverse mapping of field and property
          /// </summary>
          public static Dictionary<string, string> DynamicAttributes
          {
              get
              {
                  return new Dictionary<string, string>
				{
					{"LINETYPE", "LineType"},
					{"ITEM", "Item"},
					{"MISCCHARGE", "MiscellaneousChargesCode"},
					{"DESC", "Description"},
					{"ACCTSET", "ItemAccountSet"},
					{"USERCOSTMD", "UserSpecifiedCostingMethod"},
					{"PRICELIST", "PriceList"},
					{"CATEGORY", "Category"},
					{"LOCATION", "Location"},
					{"PICKSEQ", "PickingSequence"},
					{"EXPDATE", "ExpectedShipmentDate"},
					{"STOCKITEM", "StockItem"},
					{"QTYORDERED", "QuantityOrdered"},
					{"QTYSHIPPED", "QuantityShipped"},
					{"QTYBACKORD", "QuantityBackordered"},
					{"ORDUNIT", "OrderUnitOfMeasure"},
					{"PRIUNTPRC", "PricingUnitPrice"},
					{"COSUNTCST", "CostingUnitCost"},
					{"EXTOCOST", "ExtendedOrderCost"},
					{"EXTINVMISC", "ExtendedAmount"},
					{"INVDISC", "OrderDiscountAmount"},
					{"UNITWEIGHT", "UnitWeight"},
					{"EXTWEIGHT", "ExtendedWeight"},
					{"COMPLETE", "DetailCompleted"},
					{"TCLASS1", "TaxClass1"},
					{"TCLASS2", "TaxClass2"},
					{"TCLASS3", "TaxClass3"},
					{"TCLASS4", "TaxClass4"},
					{"TCLASS5", "TaxClass5"},
					{"TINCLUDED1", "TaxIncluded1"},
					{"TINCLUDED2", "TaxIncluded2"},
					{"TINCLUDED3", "TaxIncluded3"},
					{"TINCLUDED4", "TaxIncluded4"},
					{"TINCLUDED5", "TaxIncluded5"},
					{"TBASE1", "TaxBase1"},
					{"TBASE2", "TaxBase2"},
					{"TBASE3", "TaxBase3"},
					{"TBASE4", "TaxBase4"},
					{"TBASE5", "TaxBase5"},
					{"TAMOUNT1", "TaxAmount1"},
					{"TAMOUNT2", "TaxAmount2"},
					{"TAMOUNT3", "TaxAmount3"},
					{"TAMOUNT4", "TaxAmount4"},
					{"TAMOUNT5", "TaxAmount5"},
					{"COMMINST", "UseCommentsInstructions"},
					{"GLNONSTKCR", "NonstockClearingAccount"},
					{"COPYDETAIL", "CopyThisDetailLine"},
					{"SHIPTRACK", "ShipmentTrackingNumber"},
					{"SHIPVIA", "ShipViaCode"},
					{"VIADESC", "ShipViaCodeDescription"},
					{"DISCPER", "DiscountPercent"},
					{"QTYCOMMIT", "QuantityCommitted"},
					{"MANITEMNO", "ManufacturersItemNumber"},
					{"CUSTITEMNO", "CustomerItemNumber"},
					{"QTYTRUECOM", "TrueQuantityCommitted"},
					{"DDTLNO", "KitBOMNumber"},
					{"PROCESSCMD", "ProcessCommand"},
					{"WEIGHTUNIT", "OrderWeightUOM"},
					{"PRWGHTUNIT", "PricingWeightUOM"},
					{"NEEDPCHECK", "PriceCheckPending"},
					{"CAPPROVEBY", "PriceApprovedBy"},
					{"CAPPRPWORD", "ApprovingUsersPassword"},
					{"OTRAMOUNT1", "TRTaxAmount1"},
					{"OTRAMOUNT2", "TRTaxAmount2"},
					{"OTRAMOUNT3", "TRTaxAmount3"},
					{"OTRAMOUNT4", "TRTaxAmount4"},
					{"OTRAMOUNT5", "TRTaxAmount5"},
					{"CONTRACT", "ContractCode"},
					{"PROJECT", "ProjectCode"},
					{"CCATEGORY", "CategoryCode"},
					{"COSTCLASS", "CostClass"},
					{"REVBILL", "RevenueBillingAccount"},
					{"COGSWIP", "COGSWIPAccount"},
					{"RTGPERCENT", "RetainagePercent"},
					{"RTGDAYS", "RetainageDays"},
					{"ARITEMNO", "ARItemNumber"},
					{"ARUNIT", "ARItemUnit"},
					{"PAYMNTDIST", "PrepaymentDistributed"},
					{"SERIALQTY", "SerialQuantity"},
					{"LOTQTY", "LotQuantity"},
					{"SQTYMOVED", "SerialQtyShipped"},
					{"LQTYMOVED", "LotQtyShipped"},
					{"REQUESDATE", "DateRequested"}
				};
              }
          }
          #region Properties
          /// <summary>
          /// Contains list of OrderDetail Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for OrderUniquifier
               /// </summary>
               public const string OrderUniquifier = "ORDUNIQ";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "LINENUM";

               /// <summary>
               /// Property for LineType
               /// </summary>
               public const string LineType = "LINETYPE";

               /// <summary>
               /// Property for Item
               /// </summary>
               public const string Item = "ITEM";

               /// <summary>
               /// Property for MiscellaneousChargesCode
               /// </summary>
               public const string MiscellaneousChargesCode = "MISCCHARGE";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for ItemAccountSet
               /// </summary>
               public const string ItemAccountSet = "ACCTSET";

               /// <summary>
               /// Property for UserSpecifiedCostingMethod
               /// </summary>
               public const string UserSpecifiedCostingMethod = "USERCOSTMD";

               /// <summary>
               /// Property for PriceList
               /// </summary>
               public const string PriceList = "PRICELIST";

               /// <summary>
               /// Property for Category
               /// </summary>
               public const string Category = "CATEGORY";

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for PickingSequence
               /// </summary>
               public const string PickingSequence = "PICKSEQ";

               /// <summary>
               /// Property for ExpectedShipmentDate
               /// </summary>
               public const string ExpectedShipmentDate = "EXPDATE";

               /// <summary>
               /// Property for StockItem
               /// </summary>
               public const string StockItem = "STOCKITEM";

               /// <summary>
               /// Property for QuantityOrdered
               /// </summary>
               public const string QuantityOrdered = "QTYORDERED";

               /// <summary>
               /// Property for QuantityShipped
               /// </summary>
               public const string QuantityShipped = "QTYSHIPPED";

               /// <summary>
               /// Property for QuantityBackordered
               /// </summary>
               public const string QuantityBackordered = "QTYBACKORD";

               /// <summary>
               /// Property for QuantityShippedtodate
               /// </summary>
               public const string QuantityShippedtodate = "QTYSHPTODT";

               /// <summary>
               /// Property for OriginalQuantityOrdered
               /// </summary>
               public const string OriginalQuantityOrdered = "ORIGQTY";

               /// <summary>
               /// Property for POQuantityOrdered
               /// </summary>
               public const string POQuantityOrdered = "QTYPO";

               /// <summary>
               /// Property for OrderUnitOfMeasure
               /// </summary>
               public const string OrderUnitOfMeasure = "ORDUNIT";

               /// <summary>
               /// Property for OrderUnitConversion
               /// </summary>
               public const string OrderUnitConversion = "UNITCONV";

               /// <summary>
               /// Property for OrderUnitPrice
               /// </summary>
               public const string OrderUnitPrice = "UNITPRICE";

               /// <summary>
               /// Property for PriceOverride
               /// </summary>
               public const string PriceOverride = "PRICEOVER";

               /// <summary>
               /// Property for OrderUnitCost
               /// </summary>
               public const string OrderUnitCost = "UNITCOST";

               /// <summary>
               /// Property for MostRecentUnitCost
               /// </summary>
               public const string MostRecentUnitCost = "MOSTREC";

               /// <summary>
               /// Property for StandardUnitCost
               /// </summary>
               public const string StandardUnitCost = "STDCOST";

               /// <summary>
               /// Property for AlternateUnitCost1
               /// </summary>
               public const string AlternateUnitCost1 = "COST1";

               /// <summary>
               /// Property for AlternateUnitCost2
               /// </summary>
               public const string AlternateUnitCost2 = "COST2";

               /// <summary>
               /// Property for UnitPriceNoOfDecimals
               /// </summary>
               public const string UnitPriceNoOfDecimals = "UNITPRCDEC";

               /// <summary>
               /// Property for PricingUnitOfMeasure
               /// </summary>
               public const string PricingUnitOfMeasure = "PRICEUNIT";

               /// <summary>
               /// Property for PricingUnitPrice
               /// </summary>
               public const string PricingUnitPrice = "PRIUNTPRC";

               /// <summary>
               /// Property for PricingUnitConversion
               /// </summary>
               public const string PricingUnitConversion = "PRIUNTCONV";

               /// <summary>
               /// Property for PriceDiscountPercentage
               /// </summary>
               public const string PriceDiscountPercentage = "PRIPERCENT";

               /// <summary>
               /// Property for PriceDiscountAmount
               /// </summary>
               public const string PriceDiscountAmount = "PRIAMOUNT";

               /// <summary>
               /// Property for PricingBaseUnit
               /// </summary>
               public const string PricingBaseUnit = "BASEUNIT";

               /// <summary>
               /// Property for PricingBaseUnitPrice
               /// </summary>
               public const string PricingBaseUnitPrice = "PRIBASPRC";

               /// <summary>
               /// Property for PricingBaseUnitConversion
               /// </summary>
               public const string PricingBaseUnitConversion = "PRIBASCONV";

               /// <summary>
               /// Property for CostingUnitOfMeasure
               /// </summary>
               public const string CostingUnitOfMeasure = "COSTUNIT";

               /// <summary>
               /// Property for CostingUnitCost
               /// </summary>
               public const string CostingUnitCost = "COSUNTCST";

               /// <summary>
               /// Property for CostingUnitConversion
               /// </summary>
               public const string CostingUnitConversion = "COSUNTCONV";

               /// <summary>
               /// Property for ExtendedOrderAmount
               /// </summary>
               public const string ExtendedOrderAmount = "EXTOPRICE";

               /// <summary>
               /// Property for ExtendedOrderCost
               /// </summary>
               public const string ExtendedOrderCost = "EXTOCOST";

               /// <summary>
               /// Property for ExtendedAmount
               /// </summary>
               public const string ExtendedAmount = "EXTINVMISC";

               /// <summary>
               /// Property for OrderDiscountAmount
               /// </summary>
               public const string OrderDiscountAmount = "INVDISC";

               /// <summary>
               /// Property for ExtendedDetailCost
               /// </summary>
               public const string ExtendedDetailCost = "EXTICOST";

               /// <summary>
               /// Property for ExtendedShippedAmtOverride
               /// </summary>
               public const string ExtendedShippedAmtOverride = "EXTOVER";

               /// <summary>
               /// Property for UnitWeight
               /// </summary>
               public const string UnitWeight = "UNITWEIGHT";

               /// <summary>
               /// Property for ExtendedWeight
               /// </summary>
               public const string ExtendedWeight = "EXTWEIGHT";

               /// <summary>
               /// Property for DetailCompleted
               /// </summary>
               public const string DetailCompleted = "COMPLETE";

               /// <summary>
               /// Property for RecognizedInItemLocation
               /// </summary>
               public const string RecognizedInItemLocation = "ADDTOILOC";

               /// <summary>
               /// Property for LostSalesAmount
               /// </summary>
               public const string LostSalesAmount = "SALESLOST";

               /// <summary>
               /// Property for TaxAuthority1
               /// </summary>
               public const string TaxAuthority1 = "TAUTH1";

               /// <summary>
               /// Property for TaxAuthority2
               /// </summary>
               public const string TaxAuthority2 = "TAUTH2";

               /// <summary>
               /// Property for TaxAuthority3
               /// </summary>
               public const string TaxAuthority3 = "TAUTH3";

               /// <summary>
               /// Property for TaxAuthority4
               /// </summary>
               public const string TaxAuthority4 = "TAUTH4";

               /// <summary>
               /// Property for TaxAuthority5
               /// </summary>
               public const string TaxAuthority5 = "TAUTH5";

               /// <summary>
               /// Property for TaxClass1
               /// </summary>
               public const string TaxClass1 = "TCLASS1";

               /// <summary>
               /// Property for TaxClass2
               /// </summary>
               public const string TaxClass2 = "TCLASS2";

               /// <summary>
               /// Property for TaxClass3
               /// </summary>
               public const string TaxClass3 = "TCLASS3";

               /// <summary>
               /// Property for TaxClass4
               /// </summary>
               public const string TaxClass4 = "TCLASS4";

               /// <summary>
               /// Property for TaxClass5
               /// </summary>
               public const string TaxClass5 = "TCLASS5";

               /// <summary>
               /// Property for TaxIncluded1
               /// </summary>
               public const string TaxIncluded1 = "TINCLUDED1";

               /// <summary>
               /// Property for TaxIncluded2
               /// </summary>
               public const string TaxIncluded2 = "TINCLUDED2";

               /// <summary>
               /// Property for TaxIncluded3
               /// </summary>
               public const string TaxIncluded3 = "TINCLUDED3";

               /// <summary>
               /// Property for TaxIncluded4
               /// </summary>
               public const string TaxIncluded4 = "TINCLUDED4";

               /// <summary>
               /// Property for TaxIncluded5
               /// </summary>
               public const string TaxIncluded5 = "TINCLUDED5";

               /// <summary>
               /// Property for TaxBase1
               /// </summary>
               public const string TaxBase1 = "TBASE1";

               /// <summary>
               /// Property for TaxBase2
               /// </summary>
               public const string TaxBase2 = "TBASE2";

               /// <summary>
               /// Property for TaxBase3
               /// </summary>
               public const string TaxBase3 = "TBASE3";

               /// <summary>
               /// Property for TaxBase4
               /// </summary>
               public const string TaxBase4 = "TBASE4";

               /// <summary>
               /// Property for TaxBase5
               /// </summary>
               public const string TaxBase5 = "TBASE5";

               /// <summary>
               /// Property for TaxAmount1
               /// </summary>
               public const string TaxAmount1 = "TAMOUNT1";

               /// <summary>
               /// Property for TaxAmount2
               /// </summary>
               public const string TaxAmount2 = "TAMOUNT2";

               /// <summary>
               /// Property for TaxAmount3
               /// </summary>
               public const string TaxAmount3 = "TAMOUNT3";

               /// <summary>
               /// Property for TaxAmount4
               /// </summary>
               public const string TaxAmount4 = "TAMOUNT4";

               /// <summary>
               /// Property for TaxAmount5
               /// </summary>
               public const string TaxAmount5 = "TAMOUNT5";

               /// <summary>
               /// Property for TaxRate1
               /// </summary>
               public const string TaxRate1 = "TRATE1";

               /// <summary>
               /// Property for TaxRate2
               /// </summary>
               public const string TaxRate2 = "TRATE2";

               /// <summary>
               /// Property for TaxRate3
               /// </summary>
               public const string TaxRate3 = "TRATE3";

               /// <summary>
               /// Property for TaxRate4
               /// </summary>
               public const string TaxRate4 = "TRATE4";

               /// <summary>
               /// Property for TaxRate5
               /// </summary>
               public const string TaxRate5 = "TRATE5";

               /// <summary>
               /// Property for DetailNumber
               /// </summary>
               public const string DetailNumber = "DETAILNUM";

               /// <summary>
               /// Property for UseCommentsInstructions
               /// </summary>
               public const string UseCommentsInstructions = "COMMINST";

               /// <summary>
               /// Property for TotalOrderMostRecentCost
               /// </summary>
               public const string TotalOrderMostRecentCost = "EXTOMOSTRE";

               /// <summary>
               /// Property for TotalOrderStandardCost
               /// </summary>
               public const string TotalOrderStandardCost = "EXTOSTDCOS";

               /// <summary>
               /// Property for TotalOrderCost1
               /// </summary>
               public const string TotalOrderCost1 = "EXTOCOST1";

               /// <summary>
               /// Property for TotalOrderCost2
               /// </summary>
               public const string TotalOrderCost2 = "EXTOCOST2";

               /// <summary>
               /// Property for TotalInvoiceMostRecentCost
               /// </summary>
               public const string TotalInvoiceMostRecentCost = "EXTIMOSTRE";

               /// <summary>
               /// Property for TotalInvoiceStandardCost
               /// </summary>
               public const string TotalInvoiceStandardCost = "EXTISTDCOS";

               /// <summary>
               /// Property for TotalInvoiceCost1
               /// </summary>
               public const string TotalInvoiceCost1 = "EXTICOST1";

               /// <summary>
               /// Property for TotalInvoiceCost2
               /// </summary>
               public const string TotalInvoiceCost2 = "EXTICOST2";

               /// <summary>
               /// Property for PriceListDescription
               /// </summary>
               public const string PriceListDescription = "PCODDESC";

               /// <summary>
               /// Property for CategoryDescription
               /// </summary>
               public const string CategoryDescription = "CATGDESC";

               /// <summary>
               /// Property for LocationDescription
               /// </summary>
               public const string LocationDescription = "LOCDESC";

               /// <summary>
               /// Property for TaxAuthority1Description
               /// </summary>
               public const string TaxAuthority1Description = "TAUTH1DESC";

               /// <summary>
               /// Property for TaxAuthority2Description
               /// </summary>
               public const string TaxAuthority2Description = "TAUTH2DESC";

               /// <summary>
               /// Property for TaxAuthority3Description
               /// </summary>
               public const string TaxAuthority3Description = "TAUTH3DESC";

               /// <summary>
               /// Property for TaxAuthority4Description
               /// </summary>
               public const string TaxAuthority4Description = "TAUTH4DESC";

               /// <summary>
               /// Property for TaxAuthority5Description
               /// </summary>
               public const string TaxAuthority5Description = "TAUTH5DESC";

               /// <summary>
               /// Property for TaxClass1Description
               /// </summary>
               public const string TaxClass1Description = "TCLAS1DESC";

               /// <summary>
               /// Property for TaxClass2Description
               /// </summary>
               public const string TaxClass2Description = "TCLAS2DESC";

               /// <summary>
               /// Property for TaxClass3Description
               /// </summary>
               public const string TaxClass3Description = "TCLAS3DESC";

               /// <summary>
               /// Property for TaxClass4Description
               /// </summary>
               public const string TaxClass4Description = "TCLAS4DESC";

               /// <summary>
               /// Property for TaxClass5Description
               /// </summary>
               public const string TaxClass5Description = "TCLAS5DESC";

               /// <summary>
               /// Property for DrivenbyUI
               /// </summary>
               public const string DrivenbyUI = "DRIVENBYUI";

               /// <summary>
               /// Property for FoundNegativeInventory
               /// </summary>
               public const string FoundNegativeInventory = "NEGINVENT";

               /// <summary>
               /// Property for NonstockClearingAccount
               /// </summary>
               public const string NonstockClearingAccount = "GLNONSTKCR";

               /// <summary>
               /// Property for NonstockClearingAcctDesc
               /// </summary>
               public const string NonstockClearingAcctDesc = "GLNONSTKCD";

               /// <summary>
               /// Property for InterprocessCommID
               /// </summary>
               public const string InterprocessCommID = "IPCID";

               /// <summary>
               /// Property for ForcePopupSNonQtyOrdered
               /// </summary>
               public const string ForcePopupSNonQtyOrdered = "FPOPSNQO";

               /// <summary>
               /// Property for ForcePopupSNonQtyShipped
               /// </summary>
               public const string ForcePopupSNonQtyShipped = "FPOPSNQS";

               /// <summary>
               /// Property for PopupSn
               /// </summary>
               public const string PopupSn = "POPUPSN";

               /// <summary>
               /// Property for CloseSn
               /// </summary>
               public const string CloseSn = "CLOSESN";

               /// <summary>
               /// Property for LtSetID
               /// </summary>
               public const string LtSetID = "LTSETID";

               /// <summary>
               /// Property for ForcePopupLTonQtyOrdered
               /// </summary>
               public const string ForcePopupLTonQtyOrdered = "FPOPLTQO";

               /// <summary>
               /// Property for ForcePopupLTonQtyShipped
               /// </summary>
               public const string ForcePopupLTonQtyShipped = "FPOPLTQS";

               /// <summary>
               /// Property for PopupLt
               /// </summary>
               public const string PopupLt = "POPUPLT";

               /// <summary>
               /// Property for CloseLt
               /// </summary>
               public const string CloseLt = "CLOSELT";

               /// <summary>
               /// Property for AverageUnitCost
               /// </summary>
               public const string AverageUnitCost = "AVGCOST";

               /// <summary>
               /// Property for LastUnitCost
               /// </summary>
               public const string LastUnitCost = "LASTCOST";

               /// <summary>
               /// Property for TotalOrderAverageCost
               /// </summary>
               public const string TotalOrderAverageCost = "EXTOAVGCST";

               /// <summary>
               /// Property for TotalOrderLastCost
               /// </summary>
               public const string TotalOrderLastCost = "EXTOLSTCST";

               /// <summary>
               /// Property for TotalInvoiceAverageCost
               /// </summary>
               public const string TotalInvoiceAverageCost = "EXTIAVGCST";

               /// <summary>
               /// Property for TotalInvoiceLastCost
               /// </summary>
               public const string TotalInvoiceLastCost = "EXTILSTCST";

               /// <summary>
               /// Property for CopyThisDetailLine
               /// </summary>
               public const string CopyThisDetailLine = "COPYDETAIL";

               /// <summary>
               /// Property for QuoteNumber
               /// </summary>
               public const string QuoteNumber = "QUONUMBER";

               /// <summary>
               /// Property for QuoteDetailLineNumber
               /// </summary>
               public const string QuoteDetailLineNumber = "QUODTLNUM";

               /// <summary>
               /// Property for ShipmentTrackingNumber
               /// </summary>
               public const string ShipmentTrackingNumber = "SHIPTRACK";

               /// <summary>
               /// Property for ShipViaCode
               /// </summary>
               public const string ShipViaCode = "SHIPVIA";

               /// <summary>
               /// Property for ShipViaCodeDescription
               /// </summary>
               public const string ShipViaCodeDescription = "VIADESC";

               /// <summary>
               /// Property for DiscountPercent
               /// </summary>
               public const string DiscountPercent = "DISCPER";

               /// <summary>
               /// Property for ExtendedDiscountedPrice
               /// </summary>
               public const string ExtendedDiscountedPrice = "EDCORDMISC";

               /// <summary>
               /// Property for QuantityCommitted
               /// </summary>
               public const string QuantityCommitted = "QTYCOMMIT";

               /// <summary>
               /// Property for ManufacturersItemNumber
               /// </summary>
               public const string ManufacturersItemNumber = "MANITEMNO";

               /// <summary>
               /// Property for CustomerItemNumber
               /// </summary>
               public const string CustomerItemNumber = "CUSTITEMNO";

               /// <summary>
               /// Property for TrueQuantityCommitted
               /// </summary>
               public const string TrueQuantityCommitted = "QTYTRUECOM";

               /// <summary>
               /// Property for ItemSerialized
               /// </summary>
               public const string ItemSerialized = "SERIALITEM";

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "UNFMTITEM";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for KittingBOM
               /// </summary>
               public const string KittingBOM = "DDTLTYPE";

               /// <summary>
               /// Property for KitBOMNumber
               /// </summary>
               public const string KitBOMNumber = "DDTLNO";

               /// <summary>
               /// Property for BOMBuildQty
               /// </summary>
               public const string BOMBuildQty = "BUILDQTY";

               /// <summary>
               /// Property for BOMBuildUnit
               /// </summary>
               public const string BOMBuildUnit = "BUILDUNIT";

               /// <summary>
               /// Property for BOMBuildUnitConversion
               /// </summary>
               public const string BOMBuildUnitConversion = "BLDUNTCONV";

               /// <summary>
               /// Property for PredecessorNumber
               /// </summary>
               public const string PredecessorNumber = "FRMNUMBER";

               /// <summary>
               /// Property for PredecessorUniquifier
               /// </summary>
               public const string PredecessorUniquifier = "FRMUNIQ";

               /// <summary>
               /// Property for PredecessorLineNumber
               /// </summary>
               public const string PredecessorLineNumber = "FRMLINENUM";

               /// <summary>
               /// Property for ProcessCommand
               /// </summary>
               public const string ProcessCommand = "PROCESSCMD";

               /// <summary>
               /// Property for NextComponentNumber
               /// </summary>
               public const string NextComponentNumber = "NEXTCMPNUM";

               /// <summary>
               /// Property for EposPromotionID
               /// </summary>
               public const string EposPromotionID = "EPOSPROMID";

               /// <summary>
               /// Property for ShipmentUniquifier
               /// </summary>
               public const string ShipmentUniquifier = "SHIUNIQ";

               /// <summary>
               /// Property for PricingBaseWeightUnit
               /// </summary>
               public const string PricingBaseWeightUnit = "BASEWUNIT";

               /// <summary>
               /// Property for OrderWeightUOM
               /// </summary>
               public const string OrderWeightUOM = "WEIGHTUNIT";

               /// <summary>
               /// Property for OrderWeightConversionFactor
               /// </summary>
               public const string OrderWeightConversionFactor = "WEIGHTCONV";

               /// <summary>
               /// Property for PricingWeightUOM
               /// </summary>
               public const string PricingWeightUOM = "PRWGHTUNIT";

               /// <summary>
               /// Property for PricingWeightConversionFactor
               /// </summary>
               public const string PricingWeightConversionFactor = "PRWGHTCONV";

               /// <summary>
               /// Property for PricingBaseWeightConvFactor
               /// </summary>
               public const string PricingBaseWeightConvFactor = "PRIBASWCNV";

               /// <summary>
               /// Property for DefWeightUOMUnitWeight
               /// </summary>
               public const string DefWeightUOMUnitWeight = "DEFUWEIGHT";

               /// <summary>
               /// Property for DefWeightUOMExtUnitWeight
               /// </summary>
               public const string DefWeightUOMExtUnitWeight = "DEFEXTWGHT";

               /// <summary>
               /// Property for PriceBy
               /// </summary>
               public const string PriceBy = "PRPRICEBY";

               /// <summary>
               /// Property for PriceCheckPending
               /// </summary>
               public const string PriceCheckPending = "NEEDPCHECK";

               /// <summary>
               /// Property for PriceApprovedBy
               /// </summary>
               public const string PriceApprovedBy = "CAPPROVEBY";

               /// <summary>
               /// Property for ApprovingUsersPassword
               /// </summary>
               public const string ApprovingUsersPassword = "CAPPRPWORD";

               /// <summary>
               /// Property for PriceApprovalNeeded
               /// </summary>
               public const string PriceApprovalNeeded = "NEEDCAPP";

               /// <summary>
               /// Property for WeightUOMDescription
               /// </summary>
               public const string WeightUOMDescription = "WUOMDESC";

               /// <summary>
               /// Property for HeaderDiscount
               /// </summary>
               public const string HeaderDiscount = "HDRDISC";

               /// <summary>
               /// Property for TRTaxAmount1
               /// </summary>
               public const string TRTaxAmount1 = "OTRAMOUNT1";

               /// <summary>
               /// Property for TRTaxAmount2
               /// </summary>
               public const string TRTaxAmount2 = "OTRAMOUNT2";

               /// <summary>
               /// Property for TRTaxAmount3
               /// </summary>
               public const string TRTaxAmount3 = "OTRAMOUNT3";

               /// <summary>
               /// Property for TRTaxAmount4
               /// </summary>
               public const string TRTaxAmount4 = "OTRAMOUNT4";

               /// <summary>
               /// Property for TRTaxAmount5
               /// </summary>
               public const string TRTaxAmount5 = "OTRAMOUNT5";

               /// <summary>
               /// Property for ExtendedAmountNetOfTax
               /// </summary>
               public const string ExtendedAmountNetOfTax = "EXTNETPRI";

               /// <summary>
               /// Property for DiscountedExtendedAmount
               /// </summary>
               public const string DiscountedExtendedAmount = "DISORDMISC";

               /// <summary>
               /// Property for TaxTotal
               /// </summary>
               public const string TaxTotal = "TAXTOTAL";

               /// <summary>
               /// Property for TRTaxTotal
               /// </summary>
               public const string TRTaxTotal = "OTRTOTAL";

               /// <summary>
               /// Property for PickingSlipPrinted
               /// </summary>
               public const string PickingSlipPrinted = "PSPRINTED";

               /// <summary>
               /// Property for JobRelated
               /// </summary>
               public const string JobRelated = "JOBRELATED";

               /// <summary>
               /// Property for ContractCode
               /// </summary>
               public const string ContractCode = "CONTRACT";

               /// <summary>
               /// Property for ProjectCode
               /// </summary>
               public const string ProjectCode = "PROJECT";

               /// <summary>
               /// Property for CategoryCode
               /// </summary>
               public const string CategoryCode = "CCATEGORY";

               /// <summary>
               /// Property for CostClass
               /// </summary>
               public const string CostClass = "COSTCLASS";

               /// <summary>
               /// Property for ProjectStyle
               /// </summary>
               public const string ProjectStyle = "PROJSTYLE";

               /// <summary>
               /// Property for ProjectType
               /// </summary>
               public const string ProjectType = "PROJTYPE";

               /// <summary>
               /// Property for AccountingMethod
               /// </summary>
               public const string AccountingMethod = "REVREC";

               /// <summary>
               /// Property for BillingType
               /// </summary>
               public const string BillingType = "BILLTYPE";

               /// <summary>
               /// Property for RevenueBillingAccount
               /// </summary>
               public const string RevenueBillingAccount = "REVBILL";

               /// <summary>
               /// Property for CogswipAccount
               /// </summary>
               public const string CogswipAccount = "COGSWIP";

               /// <summary>
               /// Property for RetainagePercent
               /// </summary>
               public const string RetainagePercent = "RTGPERCENT";

               /// <summary>
               /// Property for RetainageDays
               /// </summary>
               public const string RetainageDays = "RTGDAYS";

               /// <summary>
               /// Property for DefaultOEPrice
               /// </summary>
               public const string DefaultOEPrice = "PRICEOPT";

               /// <summary>
               /// Property for ARItemNumber
               /// </summary>
               public const string ARItemNumber = "ARITEMNO";

               /// <summary>
               /// Property for ARItemUnit
               /// </summary>
               public const string ARItemUnit = "ARUNIT";

               /// <summary>
               /// Property for Level1Name
               /// </summary>
               public const string Level1Name = "LVL1NAME";

               /// <summary>
               /// Property for Level2Name
               /// </summary>
               public const string Level2Name = "LVL2NAME";

               /// <summary>
               /// Property for Level3Name
               /// </summary>
               public const string Level3Name = "LVL3NAME";

               /// <summary>
               /// Property for UnformattedContractCode
               /// </summary>
               public const string UnformattedContractCode = "UFMTCONTNO";

               /// <summary>
               /// Property for PrepaymentDistributed
               /// </summary>
               public const string PrepaymentDistributed = "PAYMNTDIST";

               /// <summary>
               /// Property for ExtPriceNetOfDiscIncTax
               /// </summary>
               public const string ExtPriceNetOfDiscIncTax = "NETPRIWTX";

               /// <summary>
               /// Property for SerialQuantity
               /// </summary>
               public const string SerialQuantity = "SERIALQTY";

               /// <summary>
               /// Property for LotQuantity
               /// </summary>
               public const string LotQuantity = "LOTQTY";

               /// <summary>
               /// Property for SerialQtyShipped
               /// </summary>
               public const string SerialQtyShipped = "SQTYMOVED";

               /// <summary>
               /// Property for LotQtyShipped
               /// </summary>
               public const string LotQtyShipped = "LQTYMOVED";

               /// <summary>
               /// Property for SerialLotQuantityToProcess
               /// </summary>
               public const string SerialLotQuantityToProcess = "XGENALCQTY";

               /// <summary>
               /// Property for NumberOfLotsToGenerate
               /// </summary>
               public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

               /// <summary>
               /// Property for QuantityperLot
               /// </summary>
               public const string QuantityperLot = "XPERLOTQTY";

               /// <summary>
               /// Property for AllocateFromSerial
               /// </summary>
               public const string AllocateFromSerial = "SALLOCFROM";

               /// <summary>
               /// Property for AllocateFromLot
               /// </summary>
               public const string AllocateFromLot = "LALLOCFROM";

               /// <summary>
               /// Property for ItemSerializedLotted
               /// </summary>
               public const string ItemSerializedLotted = "SLITEM";

               /// <summary>
               /// Property for SerialLotWindowHandle
               /// </summary>
               public const string SerialLotWindowHandle = "METERHWND";

               /// <summary>
               /// Property for UseSimplePriceChecking
               /// </summary>
               public const string UseSimplePriceChecking = "SIMPLEPCHK";

               /// <summary>
               /// Property for DateRequested
               /// </summary>
               public const string DateRequested = "REQUESDATE";
               /// <summary>
               /// Property for SetCreditApproval
               /// </summary>
               public const string SetCreditApproval = "SETCAPPR";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of OrderDetail Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for OrderUniquifier
               /// </summary>
               public const int OrderUniquifier = 1;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 2;

               /// <summary>
               /// Property Indexer for LineType
               /// </summary>
               public const int LineType = 3;

               /// <summary>
               /// Property Indexer for Item
               /// </summary>
               public const int Item = 4;

               /// <summary>
               /// Property Indexer for MiscellaneousChargesCode
               /// </summary>
               public const int MiscellaneousChargesCode = 5;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 6;

               /// <summary>
               /// Property Indexer for ItemAccountSet
               /// </summary>
               public const int ItemAccountSet = 7;

               /// <summary>
               /// Property Indexer for UserSpecifiedCostingMethod
               /// </summary>
               public const int UserSpecifiedCostingMethod = 8;

               /// <summary>
               /// Property Indexer for PriceList
               /// </summary>
               public const int PriceList = 9;

               /// <summary>
               /// Property Indexer for Category
               /// </summary>
               public const int Category = 10;

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 11;

               /// <summary>
               /// Property Indexer for PickingSequence
               /// </summary>
               public const int PickingSequence = 12;

               /// <summary>
               /// Property Indexer for ExpectedShipmentDate
               /// </summary>
               public const int ExpectedShipmentDate = 13;

               /// <summary>
               /// Property Indexer for StockItem
               /// </summary>
               public const int StockItem = 14;

               /// <summary>
               /// Property Indexer for QuantityOrdered
               /// </summary>
               public const int QuantityOrdered = 15;

               /// <summary>
               /// Property Indexer for QuantityShipped
               /// </summary>
               public const int QuantityShipped = 16;

               /// <summary>
               /// Property Indexer for QuantityBackordered
               /// </summary>
               public const int QuantityBackordered = 17;

               /// <summary>
               /// Property Indexer for QuantityShippedtodate
               /// </summary>
               public const int QuantityShippedtodate = 18;

               /// <summary>
               /// Property Indexer for OriginalQuantityOrdered
               /// </summary>
               public const int OriginalQuantityOrdered = 19;

               /// <summary>
               /// Property Indexer for POQuantityOrdered
               /// </summary>
               public const int POQuantityOrdered = 20;

               /// <summary>
               /// Property Indexer for OrderUnitOfMeasure
               /// </summary>
               public const int OrderUnitOfMeasure = 21;

               /// <summary>
               /// Property Indexer for OrderUnitConversion
               /// </summary>
               public const int OrderUnitConversion = 22;

               /// <summary>
               /// Property Indexer for OrderUnitPrice
               /// </summary>
               public const int OrderUnitPrice = 23;

               /// <summary>
               /// Property Indexer for PriceOverride
               /// </summary>
               public const int PriceOverride = 24;

               /// <summary>
               /// Property Indexer for OrderUnitCost
               /// </summary>
               public const int OrderUnitCost = 25;

               /// <summary>
               /// Property Indexer for MostRecentUnitCost
               /// </summary>
               public const int MostRecentUnitCost = 26;

               /// <summary>
               /// Property Indexer for StandardUnitCost
               /// </summary>
               public const int StandardUnitCost = 27;

               /// <summary>
               /// Property Indexer for AlternateUnitCost1
               /// </summary>
               public const int AlternateUnitCost1 = 28;

               /// <summary>
               /// Property Indexer for AlternateUnitCost2
               /// </summary>
               public const int AlternateUnitCost2 = 29;

               /// <summary>
               /// Property Indexer for UnitPriceNoOfDecimals
               /// </summary>
               public const int UnitPriceNoOfDecimals = 30;

               /// <summary>
               /// Property Indexer for PricingUnitOfMeasure
               /// </summary>
               public const int PricingUnitOfMeasure = 31;

               /// <summary>
               /// Property Indexer for PricingUnitPrice
               /// </summary>
               public const int PricingUnitPrice = 32;

               /// <summary>
               /// Property Indexer for PricingUnitConversion
               /// </summary>
               public const int PricingUnitConversion = 33;

               /// <summary>
               /// Property Indexer for PriceDiscountPercentage
               /// </summary>
               public const int PriceDiscountPercentage = 34;

               /// <summary>
               /// Property Indexer for PriceDiscountAmount
               /// </summary>
               public const int PriceDiscountAmount = 35;

               /// <summary>
               /// Property Indexer for PricingBaseUnit
               /// </summary>
               public const int PricingBaseUnit = 36;

               /// <summary>
               /// Property Indexer for PricingBaseUnitPrice
               /// </summary>
               public const int PricingBaseUnitPrice = 37;

               /// <summary>
               /// Property Indexer for PricingBaseUnitConversion
               /// </summary>
               public const int PricingBaseUnitConversion = 38;

               /// <summary>
               /// Property Indexer for CostingUnitOfMeasure
               /// </summary>
               public const int CostingUnitOfMeasure = 39;

               /// <summary>
               /// Property Indexer for CostingUnitCost
               /// </summary>
               public const int CostingUnitCost = 40;

               /// <summary>
               /// Property Indexer for CostingUnitConversion
               /// </summary>
               public const int CostingUnitConversion = 41;

               /// <summary>
               /// Property Indexer for ExtendedOrderAmount
               /// </summary>
               public const int ExtendedOrderAmount = 42;

               /// <summary>
               /// Property Indexer for ExtendedOrderCost
               /// </summary>
               public const int ExtendedOrderCost = 43;

               /// <summary>
               /// Property Indexer for ExtendedAmount
               /// </summary>
               public const int ExtendedAmount = 44;

               /// <summary>
               /// Property Indexer for OrderDiscountAmount
               /// </summary>
               public const int OrderDiscountAmount = 45;

               /// <summary>
               /// Property Indexer for ExtendedDetailCost
               /// </summary>
               public const int ExtendedDetailCost = 46;

               /// <summary>
               /// Property Indexer for ExtendedShippedAmtOverride
               /// </summary>
               public const int ExtendedShippedAmtOverride = 47;

               /// <summary>
               /// Property Indexer for UnitWeight
               /// </summary>
               public const int UnitWeight = 48;

               /// <summary>
               /// Property Indexer for ExtendedWeight
               /// </summary>
               public const int ExtendedWeight = 49;

               /// <summary>
               /// Property Indexer for DetailCompleted
               /// </summary>
               public const int DetailCompleted = 50;

               /// <summary>
               /// Property Indexer for RecognizedInItemLocation
               /// </summary>
               public const int RecognizedInItemLocation = 51;

               /// <summary>
               /// Property Indexer for LostSalesAmount
               /// </summary>
               public const int LostSalesAmount = 52;

               /// <summary>
               /// Property Indexer for TaxAuthority1
               /// </summary>
               public const int TaxAuthority1 = 53;

               /// <summary>
               /// Property Indexer for TaxAuthority2
               /// </summary>
               public const int TaxAuthority2 = 54;

               /// <summary>
               /// Property Indexer for TaxAuthority3
               /// </summary>
               public const int TaxAuthority3 = 55;

               /// <summary>
               /// Property Indexer for TaxAuthority4
               /// </summary>
               public const int TaxAuthority4 = 56;

               /// <summary>
               /// Property Indexer for TaxAuthority5
               /// </summary>
               public const int TaxAuthority5 = 57;

               /// <summary>
               /// Property Indexer for TaxClass1
               /// </summary>
               public const int TaxClass1 = 58;

               /// <summary>
               /// Property Indexer for TaxClass2
               /// </summary>
               public const int TaxClass2 = 59;

               /// <summary>
               /// Property Indexer for TaxClass3
               /// </summary>
               public const int TaxClass3 = 60;

               /// <summary>
               /// Property Indexer for TaxClass4
               /// </summary>
               public const int TaxClass4 = 61;

               /// <summary>
               /// Property Indexer for TaxClass5
               /// </summary>
               public const int TaxClass5 = 62;

               /// <summary>
               /// Property Indexer for TaxIncluded1
               /// </summary>
               public const int TaxIncluded1 = 63;

               /// <summary>
               /// Property Indexer for TaxIncluded2
               /// </summary>
               public const int TaxIncluded2 = 64;

               /// <summary>
               /// Property Indexer for TaxIncluded3
               /// </summary>
               public const int TaxIncluded3 = 65;

               /// <summary>
               /// Property Indexer for TaxIncluded4
               /// </summary>
               public const int TaxIncluded4 = 66;

               /// <summary>
               /// Property Indexer for TaxIncluded5
               /// </summary>
               public const int TaxIncluded5 = 67;

               /// <summary>
               /// Property Indexer for TaxBase1
               /// </summary>
               public const int TaxBase1 = 68;

               /// <summary>
               /// Property Indexer for TaxBase2
               /// </summary>
               public const int TaxBase2 = 69;

               /// <summary>
               /// Property Indexer for TaxBase3
               /// </summary>
               public const int TaxBase3 = 70;

               /// <summary>
               /// Property Indexer for TaxBase4
               /// </summary>
               public const int TaxBase4 = 71;

               /// <summary>
               /// Property Indexer for TaxBase5
               /// </summary>
               public const int TaxBase5 = 72;

               /// <summary>
               /// Property Indexer for TaxAmount1
               /// </summary>
               public const int TaxAmount1 = 73;

               /// <summary>
               /// Property Indexer for TaxAmount2
               /// </summary>
               public const int TaxAmount2 = 74;

               /// <summary>
               /// Property Indexer for TaxAmount3
               /// </summary>
               public const int TaxAmount3 = 75;

               /// <summary>
               /// Property Indexer for TaxAmount4
               /// </summary>
               public const int TaxAmount4 = 76;

               /// <summary>
               /// Property Indexer for TaxAmount5
               /// </summary>
               public const int TaxAmount5 = 77;

               /// <summary>
               /// Property Indexer for TaxRate1
               /// </summary>
               public const int TaxRate1 = 78;

               /// <summary>
               /// Property Indexer for TaxRate2
               /// </summary>
               public const int TaxRate2 = 79;

               /// <summary>
               /// Property Indexer for TaxRate3
               /// </summary>
               public const int TaxRate3 = 80;

               /// <summary>
               /// Property Indexer for TaxRate4
               /// </summary>
               public const int TaxRate4 = 81;

               /// <summary>
               /// Property Indexer for TaxRate5
               /// </summary>
               public const int TaxRate5 = 82;

               /// <summary>
               /// Property Indexer for DetailNumber
               /// </summary>
               public const int DetailNumber = 84;

               /// <summary>
               /// Property Indexer for UseCommentsInstructions
               /// </summary>
               public const int UseCommentsInstructions = 86;

               /// <summary>
               /// Property Indexer for TotalOrderMostRecentCost
               /// </summary>
               public const int TotalOrderMostRecentCost = 87;

               /// <summary>
               /// Property Indexer for TotalOrderStandardCost
               /// </summary>
               public const int TotalOrderStandardCost = 88;

               /// <summary>
               /// Property Indexer for TotalOrderCost1
               /// </summary>
               public const int TotalOrderCost1 = 89;

               /// <summary>
               /// Property Indexer for TotalOrderCost2
               /// </summary>
               public const int TotalOrderCost2 = 90;

               /// <summary>
               /// Property Indexer for TotalInvoiceMostRecentCost
               /// </summary>
               public const int TotalInvoiceMostRecentCost = 91;

               /// <summary>
               /// Property Indexer for TotalInvoiceStandardCost
               /// </summary>
               public const int TotalInvoiceStandardCost = 92;

               /// <summary>
               /// Property Indexer for TotalInvoiceCost1
               /// </summary>
               public const int TotalInvoiceCost1 = 93;

               /// <summary>
               /// Property Indexer for TotalInvoiceCost2
               /// </summary>
               public const int TotalInvoiceCost2 = 94;

               /// <summary>
               /// Property Indexer for PriceListDescription
               /// </summary>
               public const int PriceListDescription = 95;

               /// <summary>
               /// Property Indexer for CategoryDescription
               /// </summary>
               public const int CategoryDescription = 96;

               /// <summary>
               /// Property Indexer for LocationDescription
               /// </summary>
               public const int LocationDescription = 97;

               /// <summary>
               /// Property Indexer for TaxAuthority1Description
               /// </summary>
               public const int TaxAuthority1Description = 98;

               /// <summary>
               /// Property Indexer for TaxAuthority2Description
               /// </summary>
               public const int TaxAuthority2Description = 99;

               /// <summary>
               /// Property Indexer for TaxAuthority3Description
               /// </summary>
               public const int TaxAuthority3Description = 100;

               /// <summary>
               /// Property Indexer for TaxAuthority4Description
               /// </summary>
               public const int TaxAuthority4Description = 101;

               /// <summary>
               /// Property Indexer for TaxAuthority5Description
               /// </summary>
               public const int TaxAuthority5Description = 102;

               /// <summary>
               /// Property Indexer for TaxClass1Description
               /// </summary>
               public const int TaxClass1Description = 103;

               /// <summary>
               /// Property Indexer for TaxClass2Description
               /// </summary>
               public const int TaxClass2Description = 104;

               /// <summary>
               /// Property Indexer for TaxClass3Description
               /// </summary>
               public const int TaxClass3Description = 105;

               /// <summary>
               /// Property Indexer for TaxClass4Description
               /// </summary>
               public const int TaxClass4Description = 106;

               /// <summary>
               /// Property Indexer for TaxClass5Description
               /// </summary>
               public const int TaxClass5Description = 107;

               /// <summary>
               /// Property Indexer for DrivenbyUI
               /// </summary>
               public const int DrivenbyUI = 108;

               /// <summary>
               /// Property Indexer for FoundNegativeInventory
               /// </summary>
               public const int FoundNegativeInventory = 109;

               /// <summary>
               /// Property Indexer for NonstockClearingAccount
               /// </summary>
               public const int NonstockClearingAccount = 110;

               /// <summary>
               /// Property Indexer for NonstockClearingAcctDesc
               /// </summary>
               public const int NonstockClearingAcctDesc = 111;

               /// <summary>
               /// Property Indexer for InterprocessCommID
               /// </summary>
               public const int InterprocessCommID = 112;

               /// <summary>
               /// Property Indexer for ForcePopupSNonQtyOrdered
               /// </summary>
               public const int ForcePopupSNonQtyOrdered = 113;

               /// <summary>
               /// Property Indexer for ForcePopupSNonQtyShipped
               /// </summary>
               public const int ForcePopupSNonQtyShipped = 114;

               /// <summary>
               /// Property Indexer for PopupSn
               /// </summary>
               public const int PopupSn = 115;

               /// <summary>
               /// Property Indexer for CloseSn
               /// </summary>
               public const int CloseSn = 116;

               /// <summary>
               /// Property Indexer for LtSetID
               /// </summary>
               public const int LtSetID = 117;

               /// <summary>
               /// Property Indexer for ForcePopupLTonQtyOrdered
               /// </summary>
               public const int ForcePopupLTonQtyOrdered = 118;

               /// <summary>
               /// Property Indexer for ForcePopupLTonQtyShipped
               /// </summary>
               public const int ForcePopupLTonQtyShipped = 119;

               /// <summary>
               /// Property Indexer for PopupLt
               /// </summary>
               public const int PopupLt = 120;

               /// <summary>
               /// Property Indexer for CloseLt
               /// </summary>
               public const int CloseLt = 121;

               /// <summary>
               /// Property Indexer for AverageUnitCost
               /// </summary>
               public const int AverageUnitCost = 122;

               /// <summary>
               /// Property Indexer for LastUnitCost
               /// </summary>
               public const int LastUnitCost = 123;

               /// <summary>
               /// Property Indexer for TotalOrderAverageCost
               /// </summary>
               public const int TotalOrderAverageCost = 124;

               /// <summary>
               /// Property Indexer for TotalOrderLastCost
               /// </summary>
               public const int TotalOrderLastCost = 125;

               /// <summary>
               /// Property Indexer for TotalInvoiceAverageCost
               /// </summary>
               public const int TotalInvoiceAverageCost = 126;

               /// <summary>
               /// Property Indexer for TotalInvoiceLastCost
               /// </summary>
               public const int TotalInvoiceLastCost = 127;

               /// <summary>
               /// Property Indexer for CopyThisDetailLine
               /// </summary>
               public const int CopyThisDetailLine = 128;

               /// <summary>
               /// Property Indexer for QuoteNumber
               /// </summary>
               public const int QuoteNumber = 129;

               /// <summary>
               /// Property Indexer for QuoteDetailLineNumber
               /// </summary>
               public const int QuoteDetailLineNumber = 130;

               /// <summary>
               /// Property Indexer for ShipmentTrackingNumber
               /// </summary>
               public const int ShipmentTrackingNumber = 131;

               /// <summary>
               /// Property Indexer for ShipViaCode
               /// </summary>
               public const int ShipViaCode = 132;

               /// <summary>
               /// Property Indexer for ShipViaCodeDescription
               /// </summary>
               public const int ShipViaCodeDescription = 133;

               /// <summary>
               /// Property Indexer for DiscountPercent
               /// </summary>
               public const int DiscountPercent = 134;

               /// <summary>
               /// Property Indexer for ExtendedDiscountedPrice
               /// </summary>
               public const int ExtendedDiscountedPrice = 135;

               /// <summary>
               /// Property Indexer for QuantityCommitted
               /// </summary>
               public const int QuantityCommitted = 136;

               /// <summary>
               /// Property Indexer for ManufacturersItemNumber
               /// </summary>
               public const int ManufacturersItemNumber = 137;

               /// <summary>
               /// Property Indexer for CustomerItemNumber
               /// </summary>
               public const int CustomerItemNumber = 138;

               /// <summary>
               /// Property Indexer for TrueQuantityCommitted
               /// </summary>
               public const int TrueQuantityCommitted = 139;

               /// <summary>
               /// Property Indexer for ItemSerialized
               /// </summary>
               public const int ItemSerialized = 140;

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 141;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 142;

               /// <summary>
               /// Property Indexer for KittingBOM
               /// </summary>
               public const int KittingBOM = 143;

               /// <summary>
               /// Property Indexer for KitBOMNumber
               /// </summary>
               public const int KitBOMNumber = 144;

               /// <summary>
               /// Property Indexer for BOMBuildQty
               /// </summary>
               public const int BOMBuildQty = 145;

               /// <summary>
               /// Property Indexer for BOMBuildUnit
               /// </summary>
               public const int BOMBuildUnit = 146;

               /// <summary>
               /// Property Indexer for BOMBuildUnitConversion
               /// </summary>
               public const int BOMBuildUnitConversion = 147;

               /// <summary>
               /// Property Indexer for PredecessorNumber
               /// </summary>
               public const int PredecessorNumber = 148;

               /// <summary>
               /// Property Indexer for PredecessorUniquifier
               /// </summary>
               public const int PredecessorUniquifier = 149;

               /// <summary>
               /// Property Indexer for PredecessorLineNumber
               /// </summary>
               public const int PredecessorLineNumber = 150;

               /// <summary>
               /// Property Indexer for ProcessCommand
               /// </summary>
               public const int ProcessCommand = 151;

               /// <summary>
               /// Property Indexer for NextComponentNumber
               /// </summary>
               public const int NextComponentNumber = 152;

               /// <summary>
               /// Property Indexer for EposPromotionID
               /// </summary>
               public const int EposPromotionID = 153;

               /// <summary>
               /// Property Indexer for ShipmentUniquifier
               /// </summary>
               public const int ShipmentUniquifier = 154;

               /// <summary>
               /// Property Indexer for PricingBaseWeightUnit
               /// </summary>
               public const int PricingBaseWeightUnit = 155;

               /// <summary>
               /// Property Indexer for OrderWeightUOM
               /// </summary>
               public const int OrderWeightUOM = 156;

               /// <summary>
               /// Property Indexer for OrderWeightConversionFactor
               /// </summary>
               public const int OrderWeightConversionFactor = 157;

               /// <summary>
               /// Property Indexer for PricingWeightUOM
               /// </summary>
               public const int PricingWeightUOM = 158;

               /// <summary>
               /// Property Indexer for PricingWeightConversionFactor
               /// </summary>
               public const int PricingWeightConversionFactor = 159;

               /// <summary>
               /// Property Indexer for PricingBaseWeightConvFactor
               /// </summary>
               public const int PricingBaseWeightConvFactor = 160;

               /// <summary>
               /// Property Indexer for DefWeightUOMUnitWeight
               /// </summary>
               public const int DefWeightUOMUnitWeight = 161;

               /// <summary>
               /// Property Indexer for DefWeightUOMExtUnitWeight
               /// </summary>
               public const int DefWeightUOMExtUnitWeight = 162;

               /// <summary>
               /// Property Indexer for PriceBy
               /// </summary>
               public const int PriceBy = 163;

               /// <summary>
               /// Property Indexer for PriceCheckPending
               /// </summary>
               public const int PriceCheckPending = 164;

               /// <summary>
               /// Property Indexer for PriceApprovedBy
               /// </summary>
               public const int PriceApprovedBy = 165;

               /// <summary>
               /// Property Indexer for ApprovingUsersPassword
               /// </summary>
               public const int ApprovingUsersPassword = 166;

               /// <summary>
               /// Property Indexer for PriceApprovalNeeded
               /// </summary>
               public const int PriceApprovalNeeded = 167;

               /// <summary>
               /// Property Indexer for WeightUOMDescription
               /// </summary>
               public const int WeightUOMDescription = 168;

               /// <summary>
               /// Property Indexer for HeaderDiscount
               /// </summary>
               public const int HeaderDiscount = 169;

               /// <summary>
               /// Property Indexer for TRTaxAmount1
               /// </summary>
               public const int TRTaxAmount1 = 170;

               /// <summary>
               /// Property Indexer for TRTaxAmount2
               /// </summary>
               public const int TRTaxAmount2 = 171;

               /// <summary>
               /// Property Indexer for TRTaxAmount3
               /// </summary>
               public const int TRTaxAmount3 = 172;

               /// <summary>
               /// Property Indexer for TRTaxAmount4
               /// </summary>
               public const int TRTaxAmount4 = 173;

               /// <summary>
               /// Property Indexer for TRTaxAmount5
               /// </summary>
               public const int TRTaxAmount5 = 174;

               /// <summary>
               /// Property Indexer for ExtendedAmountNetOfTax
               /// </summary>
               public const int ExtendedAmountNetOfTax = 175;

               /// <summary>
               /// Property Indexer for DiscountedExtendedAmount
               /// </summary>
               public const int DiscountedExtendedAmount = 176;

               /// <summary>
               /// Property Indexer for TaxTotal
               /// </summary>
               public const int TaxTotal = 177;

               /// <summary>
               /// Property Indexer for TRTaxTotal
               /// </summary>
               public const int TRTaxTotal = 178;

               /// <summary>
               /// Property Indexer for PickingSlipPrinted
               /// </summary>
               public const int PickingSlipPrinted = 179;

               /// <summary>
               /// Property Indexer for JobRelated
               /// </summary>
               public const int JobRelated = 180;

               /// <summary>
               /// Property Indexer for ContractCode
               /// </summary>
               public const int ContractCode = 181;

               /// <summary>
               /// Property Indexer for ProjectCode
               /// </summary>
               public const int ProjectCode = 182;

               /// <summary>
               /// Property Indexer for CategoryCode
               /// </summary>
               public const int CategoryCode = 183;

               /// <summary>
               /// Property Indexer for CostClass
               /// </summary>
               public const int CostClass = 184;

               /// <summary>
               /// Property Indexer for ProjectStyle
               /// </summary>
               public const int ProjectStyle = 185;

               /// <summary>
               /// Property Indexer for ProjectType
               /// </summary>
               public const int ProjectType = 186;

               /// <summary>
               /// Property Indexer for AccountingMethod
               /// </summary>
               public const int AccountingMethod = 187;

               /// <summary>
               /// Property Indexer for BillingType
               /// </summary>
               public const int BillingType = 188;

               /// <summary>
               /// Property Indexer for RevenueBillingAccount
               /// </summary>
               public const int RevenueBillingAccount = 189;

               /// <summary>
               /// Property Indexer for CogswipAccount
               /// </summary>
               public const int CogswipAccount = 190;

               /// <summary>
               /// Property Indexer for RetainagePercent
               /// </summary>
               public const int RetainagePercent = 191;

               /// <summary>
               /// Property Indexer for RetainageDays
               /// </summary>
               public const int RetainageDays = 192;

               /// <summary>
               /// Property Indexer for DefaultOEPrice
               /// </summary>
               public const int DefaultOEPrice = 193;

               /// <summary>
               /// Property Indexer for ARItemNumber
               /// </summary>
               public const int ARItemNumber = 194;

               /// <summary>
               /// Property Indexer for ARItemUnit
               /// </summary>
               public const int ARItemUnit = 195;

               /// <summary>
               /// Property Indexer for Level1Name
               /// </summary>
               public const int Level1Name = 196;

               /// <summary>
               /// Property Indexer for Level2Name
               /// </summary>
               public const int Level2Name = 197;

               /// <summary>
               /// Property Indexer for Level3Name
               /// </summary>
               public const int Level3Name = 198;

               /// <summary>
               /// Property Indexer for UnformattedContractCode
               /// </summary>
               public const int UnformattedContractCode = 199;

               /// <summary>
               /// Property Indexer for PrepaymentDistributed
               /// </summary>
               public const int PrepaymentDistributed = 200;

               /// <summary>
               /// Property Indexer for ExtPriceNetOfDiscIncTax
               /// </summary>
               public const int ExtPriceNetOfDiscIncTax = 201;

               /// <summary>
               /// Property Indexer for SerialQuantity
               /// </summary>
               public const int SerialQuantity = 202;

               /// <summary>
               /// Property Indexer for LotQuantity
               /// </summary>
               public const int LotQuantity = 203;

               /// <summary>
               /// Property Indexer for SerialQtyShipped
               /// </summary>
               public const int SerialQtyShipped = 204;

               /// <summary>
               /// Property Indexer for LotQtyShipped
               /// </summary>
               public const int LotQtyShipped = 205;

               /// <summary>
               /// Property Indexer for SerialLotQuantityToProcess
               /// </summary>
               public const int SerialLotQuantityToProcess = 206;

               /// <summary>
               /// Property Indexer for NumberOfLotsToGenerate
               /// </summary>
               public const int NumberOfLotsToGenerate = 207;

               /// <summary>
               /// Property Indexer for QuantityperLot
               /// </summary>
               public const int QuantityperLot = 208;

               /// <summary>
               /// Property Indexer for AllocateFromSerial
               /// </summary>
               public const int AllocateFromSerial = 209;

               /// <summary>
               /// Property Indexer for AllocateFromLot
               /// </summary>
               public const int AllocateFromLot = 210;

               /// <summary>
               /// Property Indexer for ItemSerializedLotted
               /// </summary>
               public const int ItemSerializedLotted = 211;

               /// <summary>
               /// Property Indexer for SerialLotWindowHandle
               /// </summary>
               public const int SerialLotWindowHandle = 212;

               /// <summary>
               /// Property Indexer for UseSimplePriceChecking
               /// </summary>
               public const int UseSimplePriceChecking = 213;

               /// <summary>
               /// Property Indexer for DateRequested
               /// </summary>
               public const int DateRequested = 214;

               /// <summary>
               /// Property Indexer for SetCreditApproval
               /// </summary>
               public const int SetCreditApproval = 215;

          }
          #endregion

     }
}
