// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of MiscellaneousChargeTaxe Constants
     /// </summary>
     public partial class MiscellaneousChargeTax
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "OE0460";

          #region Properties
          /// <summary>
          /// Contains list of MiscellaneousChargeTaxe Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Currency
               /// </summary>
               public const string Currency = "CURRENCY";

               /// <summary>
               /// Property for MiscellaneousChargeCode
               /// </summary>
               public const string MiscellaneousChargeCode = "MISCCHARGE";

               /// <summary>
               /// Property for Authority
               /// </summary>
               public const string Authority = "AUTHORITY";

               /// <summary>
               /// Property for SalesTaxClass
               /// </summary>
               public const string SalesTaxClass = "TAXCLASS";

               /// <summary>
               /// Property for AuthorityDescription
               /// </summary>
               public const string AuthorityDescription = "TAUTHDESC";

               /// <summary>
               /// Property for ClassDescription
               /// </summary>
               public const string ClassDescription = "TCLASSDESC";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of MiscellaneousChargeTaxe Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Currency
               /// </summary>
               public const int Currency = 1;

               /// <summary>
               /// Property Indexer for MiscellaneousChargeCode
               /// </summary>
               public const int MiscellaneousChargeCode = 2;

               /// <summary>
               /// Property Indexer for Authority
               /// </summary>
               public const int Authority = 3;

               /// <summary>
               /// Property Indexer for SalesTaxClass
               /// </summary>
               public const int SalesTaxClass = 4;

               /// <summary>
               /// Property Indexer for AuthorityDescription
               /// </summary>
               public const int AuthorityDescription = 5;

               /// <summary>
               /// Property Indexer for ClassDescription
               /// </summary>
               public const int ClassDescription = 6;

          }
          #endregion

     }
}
