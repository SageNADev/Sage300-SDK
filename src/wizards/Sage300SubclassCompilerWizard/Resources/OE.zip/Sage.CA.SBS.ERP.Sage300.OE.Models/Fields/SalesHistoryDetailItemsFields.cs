// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of SalesHistoryDetail Constants
    /// </summary>
    public partial class SalesHistoryDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "OE0685";

        #region Properties
        /// <summary>
        /// Contains list of SalesHistoryDetail Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTOMER";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ITEM
            /// </summary>
            public const string ItemNumber = "ITEM";

            /// <summary>
            /// Property for Year
            /// </summary>
            public const string Year = "YR";

            /// <summary>
            /// Property for Period
            /// </summary>
            public const string Period = "PERIOD";

            /// <summary>
            /// Property for TransDate
            /// </summary>
            public const string TransDate = "TRANDATE";

            /// <summary>
            /// Property for DayEndNumber
            /// </summary>
            public const string DayEndNumber = "DAYENDSEQ";

            /// <summary>
            /// Property for EntryNumber
            /// </summary>
            public const string EntryNumber = "TRANSSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for TransNumber
            /// </summary>
            public const string TransNumber = "TRANNUM";

            /// <summary>
            /// Property for TransType
            /// </summary>
            public const string TransType = "TRANTYPE";

            /// <summary>
            /// Property for OrderDate
            /// </summary>
            public const string OrderDate = "ORDDATE";

            /// <summary>
            /// Property for OrderNumber
            /// </summary>
            public const string OrderNumber = "ORDNUMBER";

            /// <summary>
            /// Property for ShipDate
            /// </summary>
            public const string ShipDate = "SHIPDATE";

            /// <summary>
            /// Property for Salesperson
            /// </summary>
            public const string Salesperson = "SALESPER";

            /// <summary>
            /// Property for Territory
            /// </summary>
            public const string Territory = "TERRITORY";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for QuantitySold
            /// </summary>
            public const string QuantitySold = "QTYSOLD";

            /// <summary>
            /// Property for CustCurrency
            /// </summary>
            public const string CustCurrency = "SCURN";

            /// <summary>
            /// Property for FuncCostOfSales
            /// </summary>
            public const string FuncCostOfSales = "FCSTSALES";

            /// <summary>
            /// Property for SrceCostOfSales
            /// </summary>
            public const string SrceCostOfSales = "SCSTSALES";

            /// <summary>
            /// Property for FuncSalesAmount
            /// </summary>
            public const string FuncSalesAmount = "FAMTSALES";

            /// <summary>
            /// Property for SrceSalesAmount
            /// </summary>
            public const string SrceSalesAmount = "SAMTSALES";

            /// <summary>
            /// Property for FuncReturnAmount
            /// </summary>
            public const string FuncReturnAmount = "FRETSALES";

            /// <summary>
            /// Property for SrceReturnAmount
            /// </summary>
            public const string SrceReturnAmount = "SRETSALES";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "PONUMBER";

            /// <summary>
            /// Property for FunctionalAmount
            /// </summary>
            public const string FunctionalAmount = "FAMTTRAN";

            /// <summary>
            /// Property for SourceAmount
            /// </summary>
            public const string SourceAmount = "SAMTTRAN";

            /// <summary>
            /// Property for FunctionalDiscountAmount
            /// </summary>
            public const string FunctionalDiscountAmount = "FAMTDISC";

            /// <summary>
            /// Property for SourceDiscountAmount
            /// </summary>
            public const string SourceDiscountAmount = "SAMTDISC";

            /// <summary>
            /// Property for ShipmentNumber
            /// </summary>
            public const string ShipmentNumber = "SHINUMBER";

            /// <summary>
            /// Property for ShipmentDetailNumber
            /// </summary>
            public const string ShipmentDetailNumber = "SHIDTLNUM";

            /// <summary>
            /// Property for ITEMFMT
            /// </summary>
            public const string FormattedItemNumber = "ITEMFMT";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of SalesHistoryDetail Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for ITEM
            /// </summary>
            public const int ItemNumber = 2;

            /// <summary>
            /// Property Indexer for Year
            /// </summary>
            public const int Year = 3;

            /// <summary>
            /// Property Indexer for Period
            /// </summary>
            public const int Period = 4;

            /// <summary>
            /// Property Indexer for TransDate
            /// </summary>
            public const int TransDate = 5;

            /// <summary>
            /// Property Indexer for DayEndNumber
            /// </summary>
            public const int DayEndNumber = 6;

            /// <summary>
            /// Property Indexer for EntryNumber
            /// </summary>
            public const int EntryNumber = 7;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 8;

            /// <summary>
            /// Property Indexer for TransNumber
            /// </summary>
            public const int TransNumber = 9;

            /// <summary>
            /// Property Indexer for TransType
            /// </summary>
            public const int TransType = 10;

            /// <summary>
            /// Property Indexer for OrderDate
            /// </summary>
            public const int OrderDate = 11;

            /// <summary>
            /// Property Indexer for OrderNumber
            /// </summary>
            public const int OrderNumber = 12;

            /// <summary>
            /// Property Indexer for ShipDate
            /// </summary>
            public const int ShipDate = 13;

            /// <summary>
            /// Property Indexer for Salesperson
            /// </summary>
            public const int Salesperson = 14;

            /// <summary>
            /// Property Indexer for Territory
            /// </summary>
            public const int Territory = 15;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 16;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 17;

            /// <summary>
            /// Property Indexer for QuantitySold
            /// </summary>
            public const int QuantitySold = 18;

            /// <summary>
            /// Property Indexer for CustCurrency
            /// </summary>
            public const int CustCurrency = 19;

            /// <summary>
            /// Property Indexer for FuncCostOfSales
            /// </summary>
            public const int FuncCostOfSales = 20;

            /// <summary>
            /// Property Indexer for SrceCostOfSales
            /// </summary>
            public const int SrceCostOfSales = 21;

            /// <summary>
            /// Property Indexer for FuncSalesAmount
            /// </summary>
            public const int FuncSalesAmount = 22;

            /// <summary>
            /// Property Indexer for SrceSalesAmount
            /// </summary>
            public const int SrceSalesAmount = 23;

            /// <summary>
            /// Property Indexer for FuncReturnAmount
            /// </summary>
            public const int FuncReturnAmount = 24;

            /// <summary>
            /// Property Indexer for SrceReturnAmount
            /// </summary>
            public const int SrceReturnAmount = 25;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 26;

            /// <summary>
            /// Property Indexer for FunctionalAmount
            /// </summary>
            public const int FunctionalAmount = 27;

            /// <summary>
            /// Property Indexer for SourceAmount
            /// </summary>
            public const int SourceAmount = 28;

            /// <summary>
            /// Property Indexer for FunctionalDiscountAmount
            /// </summary>
            public const int FunctionalDiscountAmount = 29;

            /// <summary>
            /// Property Indexer for SourceDiscountAmount
            /// </summary>
            public const int SourceDiscountAmount = 30;

            /// <summary>
            /// Property Indexer for ShipmentNumber
            /// </summary>
            public const int ShipmentNumber = 31;

            /// <summary>
            /// Property Indexer for ShipmentDetailNumber
            /// </summary>
            public const int ShipmentDetailNumber = 32;

            /// <summary>
            /// Property Indexer for ITEMFMT
            /// </summary>
            public const int FormattedItemNumber = 50;

        }
        #endregion
    }
}
