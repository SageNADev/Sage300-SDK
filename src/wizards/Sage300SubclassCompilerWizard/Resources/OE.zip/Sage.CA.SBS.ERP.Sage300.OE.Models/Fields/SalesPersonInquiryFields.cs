// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of SalesPersonInquiryDetail Constants
    /// </summary>
    public partial class SalesPersonInquiry
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0695";

        #region Properties Name

        /// <summary>
        /// Contains list of Sales Person Inquiry Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTOMER";

            /// <summary>
            /// Property for Salesperson
            /// </summary>
            public const string SalesPerson = "SALESPER";

            /// <summary>
            /// Property for Year
            /// </summary>
            public const string Year = "YR";

            /// <summary>
            /// Property for Period
            /// </summary>
            public const string Period = "PERIOD";

            /// <summary>
            /// Property for DocDate
            /// </summary>
            public const string DocDate = "TRANDATE";

            /// <summary>
            /// Property for DocNumber
            /// </summary>
            public const string DocNumber = "TRANNUM";

            /// <summary>
            /// Property for DocType
            /// </summary>
            public const string DocType = "TRANTYPE";

            /// <summary>
            /// Property for OrderDate
            /// </summary>
            public const string OrderDate = "ORDDATE";

            /// <summary>
            /// Property for OrderNumber
            /// </summary>
            public const string OrderNumber = "ORDNUMBER";

            /// <summary>
            /// Property for CustCurrency
            /// </summary>
            public const string CustCurrency = "SCURN";

            /// <summary>
            /// Property for ShipDate
            /// </summary>
            public const string ShipDate = "SHIPDATE";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "PONUMBER";

            /// <summary>
            /// Property for DocFuncAmount
            /// </summary>
            public const string DocFuncAmount = "FAMTTRAN";

            /// <summary>
            /// Property for DocSrcAmount
            /// </summary>
            public const string DocSrcAmount = "SAMTTRAN";

            /// <summary>
            /// Property for PrintDataPipeInvoice
            /// </summary>
            public const string PrintDataPipeInvoice = "PRINTDPINV";

        }

        #endregion

        #region Properties Index

        /// <summary>
        /// Contains list of Sales Person Inquiry Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for Salesperson
            /// </summary>
            public const int SalesPerson = 2;

            /// <summary>
            /// Property Indexer for Year
            /// </summary>
            public const int Year = 3;

            /// <summary>
            /// Property Indexer for Period
            /// </summary>
            public const int Period = 4;

            /// <summary>
            /// Property Indexer for DocDate
            /// </summary>
            public const int DocDate = 5;

            /// <summary>
            /// Property Indexer for DocNumber
            /// </summary>
            public const int DocNumber = 6;

            /// <summary>
            /// Property Indexer for DocType
            /// </summary>
            public const int DocType = 7;

            /// <summary>
            /// Property Indexer for OrderDate
            /// </summary>
            public const int OrderDate = 8;

            /// <summary>
            /// Property Indexer for OrderNumber
            /// </summary>
            public const int OrderNumber = 9;

            /// <summary>
            /// Property Indexer for CustCurrency
            /// </summary>
            public const int CustCurrency = 10;

            /// <summary>
            /// Property Indexer for ShipDate
            /// </summary>
            public const int ShipDate = 11;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 12;

            /// <summary>
            /// Property Indexer for DocFuncAmount
            /// </summary>
            public const int DocFuncAmount = 13;

            /// <summary>
            /// Property Indexer for DocSrcAmount
            /// </summary>
            public const int DocSrcAmount = 14;

            /// <summary>
            /// Property Indexer for PrintDataPipeInvoice
            /// </summary>
            public const int PrintDataPipeInvoice = 15;

        }

        #endregion
    }
}
