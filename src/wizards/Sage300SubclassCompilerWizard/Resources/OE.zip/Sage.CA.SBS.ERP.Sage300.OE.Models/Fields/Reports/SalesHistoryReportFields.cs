﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 


// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Class of Sales History Report for Feilds
    /// </summary>
    public partial class SalesHistoryReport
    {
        /// <summary>
        /// The entity name
        /// </summary>
        public const string EntityName = "63AE988F-A030-4BE7-AAF0-58C9E0DF42B8";

        /// <summary>
        /// Contains Sales History Report Fields Constants
        /// </summary>
        public class Fields
        {
            #region Detail Sort by Customer

            /// <summary>
            /// From year
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// From period
            /// </summary>
            public const string FromPeriod = "FROMPERIOD";

            /// <summary>
            /// To year
            /// </summary>
            public const string ToYear = "TOYEAR";

            /// <summary>
            /// To period
            /// </summary>
            public const string ToPeriod = "TOPERIOD";

            /// <summary>
            /// From customer
            /// </summary>
            public const string FromCustomer = "FROMCUST";

            /// <summary>
            /// To customer
            /// </summary>
            public const string ToCustomer = "TOCUST";

            /// <summary>
            /// From item
            /// </summary>
            public const string FromItem = "FROMITEM";

            /// <summary>
            /// The To Item
            /// </summary>
            public const string ToItem = "TOITEM";

            /// <summary>
            /// The decimals
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// The multi currency
            /// </summary>
            public const string MultiCurrency = "MULTICURR";


            /// <summary>
            /// The Report Currency
            /// </summary>
            public const string ReportCurrency = "RPTCURR";

            /// <summary>
            /// From currency
            /// </summary>
            public const string FromCurrency = "FROMCURR";

            /// <summary>
            /// To currency
            /// </summary>
            public const string ToCurrency = "TOCURR";

            /// <summary>
            /// The Quatity Decimal
            /// </summary>
            public const string QuatityDecimal = "QTYDEC";

            /// <summary>
            /// The From Fm Item
            /// </summary>
            public const string FromFmItem = "FROMFMTITEM";

            /// <summary>
            /// The To Fm Item
            /// </summary>
            public const string ToFmItem = "TOFMTITEM";

            /// <summary>
            /// The Kit Comp
            /// </summary>
            public const string KitComp = "KITCOMP";

            /// <summary>
            /// The From Sales
            /// </summary>
            public const string FromSalesPerson = "FROMSALES";

            /// <summary>
            /// The To Sales
            /// </summary>
            public const string ToSalesPerson = "TOSALES";

            /// <summary>
            /// The on From Territory
            /// </summary>
            public const string FromTerritory = "FROMTERRITORY";

            /// <summary>
            /// The To Territory
            /// </summary>
            public const string ToTerritory = "TOTERRITORY";

            /// <summary>
            /// The SerialLot
            /// </summary>
            public const string SerialLot = "SERIALLOT";

            /// <summary>
            /// The From Serial
            /// </summary>
            public const string FromSerial = "FROMSERIAL";

            /// <summary>
            /// The From SerialF
            /// </summary>
            public const string FromSerialF = "FROMSERIALF";

            /// <summary>
            /// The To Serial
            /// </summary>
            public const string ToSerial = "TOSERIAL";

            /// <summary>
            /// The To SerialF
            /// </summary>
            public const string ToSerialF = "TOSERIALF";

            /// <summary>
            /// The From Lot
            /// </summary>
            public const string FromLot = "FROMLOT";

            /// <summary>
            /// The From LotF
            /// </summary>
            public const string FromLotF = "FROMLOTF";

            /// <summary>
            /// The To Lot
            /// </summary>
            public const string ToLot = "TOLOT";

            /// <summary>
            /// The To LotF
            /// </summary>
            public const string ToLotF = "TOLOTF";

            /// <summary>
            /// The fromdate
            /// </summary>
            public const string Fromdate = "FROMDATE";

            /// <summary>
            /// The todate
            /// </summary>
            public const string Todate = "TODATE";

            /// <summary>
            /// The todate
            /// </summary>
            public const string SelectBy = "SELECTBY";

            /// <summary>
            /// The Invoice Detail
            /// </summary>
            public const string InvoiceDetail = "INVOICEDETAIL";


            /// <summary>
            /// The SwSntlic
            /// </summary>
            public const string SwSntlic = "SWSNLTLIC";

            /// <summary>
            /// The FromAccountSet
            /// </summary>
            public const string FromAccountSet = "FROMACCOUNTSET";


            /// <summary>
            /// The ToAccountSet
            /// </summary>
            public const string ToAccountSet = "TOACCOUNTSET";

            /// <summary>
            /// The FromCategory
            /// </summary>
            public const string FromCategory = "FROMCATEGORY";

            /// <summary>
            /// The SwSntlic
            /// </summary>
            public const string ToCategory = "TOCATEGORY";



            /// <summary>
            /// The Show Comparision
            /// </summary>
            public const string ShowComparision = "SHOWCOMP";


            /// <summary>
            /// The Compare From Date
            /// </summary>
            public const string CompareFromDate = "COMPFROMDATE";

            /// <summary>
            /// The Compare To Date
            /// </summary>
            public const string CompareToDate = "COMPTODATE";


            /// <summary>
            /// The CompareFromYear
            /// </summary>
            public const string CompareFromYear = "COMPFROMYEAR";

            /// <summary>
            /// The CompareToYear
            /// </summary>
            public const string CompareToYear = "COMPTOYEAR";

            /// <summary>
            /// The CompareFromPeriod
            /// </summary>
            public const string CompareFromPeriod = "COMPFROMPERIOD";

            /// <summary>
            /// The CompareToPeriod
            /// </summary>
            public const string CompareToPeriod = "COMPTOPERIOD";

            #endregion
        }

        /// <summary>
        /// Contains SalesHistory Report Index Constants
        /// </summary>
        public class Index
        {
            #region Detail Sort by Customer

            /// <summary>
            /// From year
            /// </summary>
            public const int FromYear = 1;

            /// <summary>
            /// From period
            /// </summary>
            public const int FromPeriod = 2;

            /// <summary>
            /// To year
            /// </summary>
            public const int ToYear = 3;

            /// <summary>
            /// To period
            /// </summary>
            public const int ToPeriod = 4;

            /// <summary>
            /// From customer
            /// </summary>
            public const int FromCustomer = 5;

            /// <summary>
            /// To customer
            /// </summary>
            public const int ToCustomer = 6;

            /// <summary>
            /// From item
            /// </summary>
            public const int FromItem = 7;

            /// <summary>
            /// The To Item
            /// </summary>
            public const int ToItem = 8;

            /// <summary>
            /// The decimals
            /// </summary>
            public const int Decimals = 9;

            /// <summary>
            /// The multi currency
            /// </summary>
            public const int MultiCurrency = 10;


            /// <summary>
            /// The Report Currency
            /// </summary>
            public const int ReportCurrency = 11;

            /// <summary>
            /// From currency
            /// </summary>
            public const int FromCurrency = 12;

            /// <summary>
            /// To currency
            /// </summary>
            public const int ToCurrency = 13;

            /// <summary>
            /// The Quatity Decimal
            /// </summary>
            public const int QuatityDecimal = 14;

            /// <summary>
            /// The From Fm Item
            /// </summary>
            public const int FromFmItem = 15;

            /// <summary>
            /// The To Fm Item
            /// </summary>
            public const int ToFmItem = 16;

            /// <summary>
            /// The Kit Comp
            /// </summary>
            public const int KitComp = 17;

            /// <summary>
            /// The From Sales
            /// </summary>
            public const int FromSalesPerson = 18;

            /// <summary>
            /// The To Sales
            /// </summary>
            public const int ToSalesPerson = 19;

            /// <summary>
            /// The on From Territory
            /// </summary>
            public const int FromTerritory = 20;

            /// <summary>
            /// The To Territory
            /// </summary>
            public const int ToTerritory = 21;

            /// <summary>
            /// The SerialLot
            /// </summary>
            public const int SerialLot = 22;

            /// <summary>
            /// The From Serial
            /// </summary>
            public const int FromSerial = 23;

            /// <summary>
            /// The From SerialF
            /// </summary>
            public const int FromSerialF = 24;

            /// <summary>
            /// The To Serial
            /// </summary>
            public const int ToSerial = 25;

            /// <summary>
            /// The To SerialF
            /// </summary>
            public const int ToSerialF = 26;

            /// <summary>
            /// The From Lot
            /// </summary>
            public const int FromLot = 27;

            /// <summary>
            /// The From LotF
            /// </summary>
            public const int FromLotF = 28;

            /// <summary>
            /// The To Lot
            /// </summary>
            public const int ToLot = 29;

            /// <summary>
            /// The To LotF
            /// </summary>
            public const int ToLotF = 30;

            /// <summary>
            /// The fromdate
            /// </summary>
            public const int Fromdate = 31;

            /// <summary>
            /// The todate
            /// </summary>
            public const int Todate = 32;

            /// <summary>
            /// The todate
            /// </summary>
            public const int SelectBy = 33;

            /// <summary>
            /// The Invoice Detail
            /// </summary>
            public const int InvoiceDetail = 34;


            /// <summary>
            /// The SwSntlic
            /// </summary>
            public const int SwSntlic = 35;

            /// <summary>
            /// The FromAccountSet
            /// </summary>
            public const int FromAccountSet = 36;


            /// <summary>
            /// The ToAccountSet
            /// </summary>
            public const int ToAccountSet = 37;

            /// <summary>
            /// The FromCategory
            /// </summary>
            public const int FromCategory = 38;

            /// <summary>
            /// The SwSntlic
            /// </summary>
            public const int ToCategory = 39;



            /// <summary>
            /// The Show Comparision
            /// </summary>
            public const int ShowComparision = 40;


            /// <summary>
            /// The Compare From Date
            /// </summary>
            public const int CompareFromDate = 41;

            /// <summary>
            /// The Compare To Date
            /// </summary>
            public const int CompareToDate = 42;


            /// <summary>
            /// The CompareFromYear
            /// </summary>
            public const int CompareFromYear = 43;

            /// <summary>
            /// The CompareToYear
            /// </summary>
            public const int CompareToYear = 44;

            /// <summary>
            /// The CompareFromPeriod
            /// </summary>
            public const int CompareFromPeriod = 45;

            /// <summary>
            /// The CompareToPeriod
            /// </summary>
            public const int CompareToPeriod = 46;

            #endregion
        }
    }
}
