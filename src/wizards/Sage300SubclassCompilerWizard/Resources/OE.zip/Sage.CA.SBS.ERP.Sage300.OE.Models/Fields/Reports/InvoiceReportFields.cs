// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
	/// <summary>
	/// Contains list of InvoiceReport Constants
	/// </summary>
	public partial class InvoiceReport
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "f76ed543-0f7d-43c9-b945-9183b240471e";

		#region Properties

		/// <summary>
		/// Contains list of InvoiceReport Field Constants
		/// </summary>
		public class Fields
		{

		    /// <summary>
		    /// Property for FromInvoice
		    /// </summary>
		    public const string FromInvoice = "SORTFROM";

			/// <summary>
			/// Property for ToInvoice
			/// </summary>
            public const string ToInvoice = "SORTTO";

			/// <summary>
			/// Property for Printed
			/// </summary>
			public const string Printed = "PRINTED";

			/// <summary>
			/// Property for Qtydec
			/// </summary>
            public const string FractionalQuantityDecimals = "QTYDEC";

			/// <summary>
			/// Property for Delmethod
			/// </summary>
			public const string Delmethod = "DELMETHOD";

			/// <summary>
			/// Property for Ecenabled
			/// </summary>
			public const string Ecenabled = "ECENABLED";

			/// <summary>
			/// Property for Directec
			/// </summary>
			public const string Directec = "DIRECTEC";

			/// <summary>
			/// Property for IncludeBackOrderedItems
			/// </summary>
            public const string IncludeBackOrderedItems = "BOITEM";

			/// <summary>
			/// Property for Swdelmethod
			/// </summary>
			public const string Swdelmethod = "SWDELMETHOD";

			/// <summary>
			/// Property for Printkit
			/// </summary>
            public const string IncludePrintKitItems = "PRINTKIT";

			/// <summary>
			/// Property for Printbom
			/// </summary>
            public const string IncludePrintBillsOfMaterialItems = "PRINTBOM";

			/// <summary>
			/// Property for Retainage
			/// </summary>
			public const string Retainage = "RETAINAGE";

			/// <summary>
			/// Property for Seriallotnumbers
			/// </summary>
            public const string IncludePrintSerialLotNumbers = "SERIALLOTNUMBERS";

            /// <summary>
            /// Property for EmailSendTo
            /// </summary>
            public const string EmailSendTo = "EMAILSENDTO";

            /// <summary>
            /// Property for EmailSubject
            /// </summary>
            public const string EmailSubject = "EMAILSUBJECT";

            /// <summary>
            /// Property for EmailMessageBody
            /// </summary>
            public const string EmailMessageBody = "EMAILTEXT";

            /// <summary>
            /// Property for SelectionCriteria
            /// </summary>
            public const string SelectionCriteria = "IDSELECT";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of InvoiceReport Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for FromInvoice
			/// </summary>
			public const int Sortfrom = 2;

			/// <summary>
			/// Property Indexer for ToInvoice
			/// </summary>
			public const int Sortto = 3;

			/// <summary>
			/// Property Indexer for Printed
			/// </summary>
			public const int Printed = 4;

			/// <summary>
			/// Property Indexer for Qtydec
			/// </summary>
			public const int Qtydec = 5;

			/// <summary>
			/// Property Indexer for Delmethod
			/// </summary>
			public const int Delmethod = 6;

			/// <summary>
			/// Property Indexer for Ecenabled
			/// </summary>
			public const int Ecenabled = 7;

			/// <summary>
			/// Property Indexer for Directec
			/// </summary>
			public const int Directec = 8;

			/// <summary>
			/// Property Indexer for IncludeBackOrderedItems
			/// </summary>
			public const int Boitem = 9;

			/// <summary>
			/// Property Indexer for Swdelmethod
			/// </summary>
			public const int Swdelmethod = 10;

			/// <summary>
			/// Property Indexer for Printkit
			/// </summary>
			public const int Printkit = 11;

			/// <summary>
			/// Property Indexer for Printbom
			/// </summary>
			public const int Printbom = 12;

			/// <summary>
			/// Property Indexer for Retainage
			/// </summary>
			public const int Retainage = 13;

			/// <summary>
			/// Property Indexer for Seriallotnumbers
			/// </summary>
			public const int Seriallotnumbers = 14;

		}

		#endregion

	}
}
