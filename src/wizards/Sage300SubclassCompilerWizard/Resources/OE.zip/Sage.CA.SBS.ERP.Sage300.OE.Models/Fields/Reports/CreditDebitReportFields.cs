// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
	/// <summary>
	/// Contains list of CreditDebitReport Constants
	/// </summary>
	public partial class CreditDebitReport
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string ViewName = "fd81abf0-875d-4f4a-aaf3-648891e0c990";

		#region Properties

		/// <summary>
		/// Contains list of CreditDebitReport Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Sortfrom
			/// </summary>
			public const string Sortfrom = "SORTFROM";

			/// <summary>
			/// Property for Sortto
			/// </summary>
			public const string Sortto = "SORTTO";

			/// <summary>
			/// Property for Printed
			/// </summary>
			public const string Printed = "PRINTED";

			/// <summary>
			/// Property for Qtydec
			/// </summary>
			public const string Qtydec = "QTYDEC";

            /// <summary>
            /// The field for Swdelmethod
            /// </summary>
            public const string DeliveryMethod = "SWDELMETHOD";

            /// <summary>
            /// The field for  SelectionCriteria
            /// </summary>
            public const string SelectionCriteria = "IDSELECT";

			/// <summary>
			/// Property for Adjtype
			/// </summary>
			public const string Adjtype = "ADJTYPE";

			/// <summary>
			/// Property for Printkit
			/// </summary>
			public const string Printkit = "PRINTKIT";

			/// <summary>
			/// Property for Printbom
			/// </summary>
			public const string Printbom = "PRINTBOM";

			/// <summary>
			/// Property for Taxinformation
			/// </summary>
			public const string Taxinformation = "TAXINFORMATION";

			/// <summary>
			/// Property for Retainage
			/// </summary>
			public const string Retainage = "RETAINAGE";

			/// <summary>
			/// Property for Seriallotnumbers
			/// </summary>
			public const string Seriallotnumbers = "SERIALLOTNUMBERS";

            /// <summary>
            /// Property for EmailSendTo
            /// </summary>
            public const string EmailSendTo = "EMAILSENDTO";

            /// <summary>
            /// Property for EmailSubject
            /// </summary>
            public const string EmailSubject = "EMAILSUBJECT";

            /// <summary>
            /// Property for EmailMessageBody
            /// </summary>
            public const string EmailMessageBody = "EMAILTEXT";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of CreditDebitReport Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Sortfrom
			/// </summary>
			public const int Sortfrom = 2;

			/// <summary>
			/// Property Indexer for Sortto
			/// </summary>
			public const int Sortto = 3;

			/// <summary>
			/// Property Indexer for Printed
			/// </summary>
			public const int Printed = 4;

			/// <summary>
			/// Property Indexer for Qtydec
			/// </summary>
			public const int Qtydec = 5;

			/// <summary>
			/// Property Indexer for Swdelmethod
			/// </summary>
			public const int Swdelmethod = 6;

			/// <summary>
			/// Property Indexer for Adjtype
			/// </summary>
			public const int Adjtype = 7;

			/// <summary>
			/// Property Indexer for Printkit
			/// </summary>
			public const int Printkit = 8;

			/// <summary>
			/// Property Indexer for Printbom
			/// </summary>
			public const int Printbom = 9;

			/// <summary>
			/// Property Indexer for Taxinformation
			/// </summary>
			public const int Taxinformation = 10;

			/// <summary>
			/// Property Indexer for Retainage
			/// </summary>
			public const int Retainage = 11;

			/// <summary>
			/// Property Indexer for Seriallotnumbers
			/// </summary>
			public const int Seriallotnumbers = 12;

		}

		#endregion

	}
}
