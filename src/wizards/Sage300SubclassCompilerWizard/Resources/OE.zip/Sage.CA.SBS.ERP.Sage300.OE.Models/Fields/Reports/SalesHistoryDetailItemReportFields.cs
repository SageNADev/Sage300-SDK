// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
	/// <summary>
	/// Contains list of SalesHistoryDetailItemReport Constants
	/// </summary>
	public partial class SalesHistoryDetailItemReport
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "e851c72b-446a-4d5b-a9cd-cb109ac80956";

		#region Properties

		/// <summary>
		/// Contains list of SalesHistoryDetailItemReport Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Fromyear
			/// </summary>
			public const string Fromyear = "FROMYEAR";

			/// <summary>
			/// Property for Fromperiod
			/// </summary>
			public const string Fromperiod = "FROMPERIOD";

			/// <summary>
			/// Property for Toyear
			/// </summary>
			public const string Toyear = "TOYEAR";

			/// <summary>
			/// Property for Toperiod
			/// </summary>
			public const string Toperiod = "TOPERIOD";

			/// <summary>
			/// Property for Fromcust
			/// </summary>
			public const string Fromcust = "FROMCUST";

			/// <summary>
			/// Property for Tocust
			/// </summary>
			public const string Tocust = "TOCUST";

			/// <summary>
			/// Property for Fromitem
			/// </summary>
			public const string Fromitem = "FROMITEM";

			/// <summary>
			/// Property for Toitem
			/// </summary>
			public const string Toitem = "TOITEM";

			/// <summary>
			/// Property for Decimals
			/// </summary>
			public const string Decimals = "DECIMALS";

			/// <summary>
			/// Property for Multicurr
			/// </summary>
			public const string Multicurr = "MULTICURR";

			/// <summary>
			/// Property for Rptcurr
			/// </summary>
			public const string Rptcurr = "RPTCURR";

			/// <summary>
			/// Property for Fromcurr
			/// </summary>
			public const string Fromcurr = "FROMCURR";

			/// <summary>
			/// Property for Tocurr
			/// </summary>
			public const string Tocurr = "TOCURR";

			/// <summary>
			/// Property for Qtydec
			/// </summary>
			public const string Qtydec = "QTYDEC";

			/// <summary>
			/// Property for Fromfmtitem
			/// </summary>
			public const string Fromfmtitem = "FROMFMTITEM";

			/// <summary>
			/// Property for Tofmtitem
			/// </summary>
			public const string Tofmtitem = "TOFMTITEM";

			/// <summary>
			/// Property for Kitcomp
			/// </summary>
			public const string Kitcomp = "KITCOMP";

			/// <summary>
			/// Property for Fromaccountset
			/// </summary>
			public const string Fromaccountset = "FROMACCOUNTSET";

			/// <summary>
			/// Property for Toaccountset
			/// </summary>
			public const string Toaccountset = "TOACCOUNTSET";

			/// <summary>
			/// Property for Fromcategory
			/// </summary>
			public const string Fromcategory = "FROMCATEGORY";

			/// <summary>
			/// Property for Tocategory
			/// </summary>
			public const string Tocategory = "TOCATEGORY";

			/// <summary>
			/// Property for Seriallot
			/// </summary>
			public const string Seriallot = "SERIALLOT";

			/// <summary>
			/// Property for Fromserial
			/// </summary>
			public const string Fromserial = "FROMSERIAL";

			/// <summary>
			/// Property for Fromserialf
			/// </summary>
			public const string Fromserialf = "FROMSERIALF";

			/// <summary>
			/// Property for Toserial
			/// </summary>
			public const string Toserial = "TOSERIAL";

			/// <summary>
			/// Property for Toserialf
			/// </summary>
			public const string Toserialf = "TOSERIALF";

			/// <summary>
			/// Property for Fromlot
			/// </summary>
			public const string Fromlot = "FROMLOT";

			/// <summary>
			/// Property for Fromlotf
			/// </summary>
			public const string Fromlotf = "FROMLOTF";

			/// <summary>
			/// Property for Tolot
			/// </summary>
			public const string Tolot = "TOLOT";

			/// <summary>
			/// Property for Tolotf
			/// </summary>
			public const string Tolotf = "TOLOTF";

			/// <summary>
			/// Property for Fromdate
			/// </summary>
			public const string Fromdate = "FROMDATE";

			/// <summary>
			/// Property for Todate
			/// </summary>
			public const string Todate = "TODATE";

			/// <summary>
			/// Property for Selectby
			/// </summary>
			public const string Selectby = "SELECTBY";

			/// <summary>
			/// Property for Invoicedetail
			/// </summary>
			public const string Invoicedetail = "INVOICEDETAIL";

			/// <summary>
			/// Property for Swsnltlic
			/// </summary>
			public const string Swsnltlic = "SWSNLTLIC";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of SalesHistoryDetailItemReport Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Fromyear
			/// </summary>
			public const int Fromyear = 2;

			/// <summary>
			/// Property Indexer for Fromperiod
			/// </summary>
			public const int Fromperiod = 3;

			/// <summary>
			/// Property Indexer for Toyear
			/// </summary>
			public const int Toyear = 4;

			/// <summary>
			/// Property Indexer for Toperiod
			/// </summary>
			public const int Toperiod = 5;

			/// <summary>
			/// Property Indexer for Fromcust
			/// </summary>
			public const int Fromcust = 6;

			/// <summary>
			/// Property Indexer for Tocust
			/// </summary>
			public const int Tocust = 7;

			/// <summary>
			/// Property Indexer for Fromitem
			/// </summary>
			public const int Fromitem = 8;

			/// <summary>
			/// Property Indexer for Toitem
			/// </summary>
			public const int Toitem = 9;

			/// <summary>
			/// Property Indexer for Decimals
			/// </summary>
			public const int Decimals = 10;

			/// <summary>
			/// Property Indexer for Multicurr
			/// </summary>
			public const int Multicurr = 11;

			/// <summary>
			/// Property Indexer for Rptcurr
			/// </summary>
			public const int Rptcurr = 12;

			/// <summary>
			/// Property Indexer for Fromcurr
			/// </summary>
			public const int Fromcurr = 13;

			/// <summary>
			/// Property Indexer for Tocurr
			/// </summary>
			public const int Tocurr = 14;

			/// <summary>
			/// Property Indexer for Qtydec
			/// </summary>
			public const int Qtydec = 15;

			/// <summary>
			/// Property Indexer for Fromfmtitem
			/// </summary>
			public const int Fromfmtitem = 16;

			/// <summary>
			/// Property Indexer for Tofmtitem
			/// </summary>
			public const int Tofmtitem = 17;

			/// <summary>
			/// Property Indexer for Kitcomp
			/// </summary>
			public const int Kitcomp = 18;

			/// <summary>
			/// Property Indexer for Fromaccountset
			/// </summary>
			public const int Fromaccountset = 19;

			/// <summary>
			/// Property Indexer for Toaccountset
			/// </summary>
			public const int Toaccountset = 20;

			/// <summary>
			/// Property Indexer for Fromcategory
			/// </summary>
			public const int Fromcategory = 21;

			/// <summary>
			/// Property Indexer for Tocategory
			/// </summary>
			public const int Tocategory = 22;

			/// <summary>
			/// Property Indexer for Seriallot
			/// </summary>
			public const int Seriallot = 23;

			/// <summary>
			/// Property Indexer for Fromserial
			/// </summary>
			public const int Fromserial = 24;

			/// <summary>
			/// Property Indexer for Fromserialf
			/// </summary>
			public const int Fromserialf = 25;

			/// <summary>
			/// Property Indexer for Toserial
			/// </summary>
			public const int Toserial = 26;

			/// <summary>
			/// Property Indexer for Toserialf
			/// </summary>
			public const int Toserialf = 27;

			/// <summary>
			/// Property Indexer for Fromlot
			/// </summary>
			public const int Fromlot = 28;

			/// <summary>
			/// Property Indexer for Fromlotf
			/// </summary>
			public const int Fromlotf = 29;

			/// <summary>
			/// Property Indexer for Tolot
			/// </summary>
			public const int Tolot = 30;

			/// <summary>
			/// Property Indexer for Tolotf
			/// </summary>
			public const int Tolotf = 31;

			/// <summary>
			/// Property Indexer for Fromdate
			/// </summary>
			public const int Fromdate = 32;

			/// <summary>
			/// Property Indexer for Todate
			/// </summary>
			public const int Todate = 33;

			/// <summary>
			/// Property Indexer for Selectby
			/// </summary>
			public const int Selectby = 34;

			/// <summary>
			/// Property Indexer for Invoicedetail
			/// </summary>
			public const int Invoicedetail = 35;

			/// <summary>
			/// Property Indexer for Swsnltlic
			/// </summary>
			public const int Swsnltlic = 36;

		}

		#endregion

	}
}
