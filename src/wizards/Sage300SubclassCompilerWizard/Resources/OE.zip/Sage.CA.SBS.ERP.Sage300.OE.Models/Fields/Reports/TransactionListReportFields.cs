﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 


// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    public partial class TransactionListReport
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "6683A9C1-0C85-4E7E-A537-7EE02515C768";

        /// <summary>
        /// Contains Transaction list  Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties Order List Report
            /// <summary>
            /// From order number
            /// </summary>
            public const string FromOrderNumber = "FROMORDNUM";

            /// <summary>
            /// To order number
            /// </summary>
            public const string ToOrderNumber = "TOORDNUM";

            /// <summary>
            /// From invoice number
            /// </summary>
            public const string FromInvoiceNumber = "FROMINVNUM";

            /// <summary>
            /// To invoice number
            /// </summary>
            public const string ToInvoiceNumber = "TOINVNUM";

            /// <summary>
            /// From credit debit number
            /// </summary>
            public const string FromCreditDebitNumber = "FROMCRDNUM";

            /// <summary>
            /// To credit debit number
            /// </summary>
            public const string ToCreditDebitNumber = "TOCRDNUM";

            /// <summary>
            /// From customer
            /// </summary>
            public const string FromCustomer = "FROMCUSTOMER";

            /// <summary>
            /// To customer
            /// </summary>
            public const string ToCustomer = "TOCUSTOMER";

            /// <summary>
            /// The multi currency
            /// </summary>
            public const string MultiCurrency = "MULTICURR";

            /// <summary>
            /// The sort by
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// The from1
            /// </summary>
            public const string From1 = "FROM1";

            /// <summary>
            /// The to1
            /// </summary>
            public const string To1 = "TO1";

            /// <summary>
            /// The from2
            /// </summary>
            public const string From2 = "FROM2";

            /// <summary>
            /// The to2
            /// </summary>
            public const string To2 = "TO2";

            /// <summary>
            /// From currency
            /// </summary>
            public const string FromCurrency = "FROMCURR";

            /// <summary>
            /// To currency
            /// </summary>
            public const string ToCurrency = "TOCURR";

            /// <summary>
            /// The entered
            /// </summary>
            public const string Entered = "ENTERED";

            /// <summary>
            /// The confirmation
            /// </summary>
            public const string Confirmation = "CONFIRMATION";

            /// <summary>
            /// The picking slip
            /// </summary>
            public const string PickingSlip = "PICKINGSLIP";

            /// <summary>
            /// The never shipped
            /// </summary>
            public const string NeverShipped = "NEVERSHIPPED";

            /// <summary>
            /// The part shipped
            /// </summary>
            public const string PartShipped = "PARTSHIPPED";

            /// <summary>
            /// The complete
            /// </summary>
            public const string Complete = "COMPLETE";

            /// <summary>
            /// The on hold
            /// </summary>
            public const string OnHold = "ONHOLD";

            /// <summary>
            /// The active
            /// </summary>
            public const string Active = "ACTIVE";

            /// <summary>
            /// The future
            /// </summary>
            public const string Future = "FUTURE";

            /// <summary>
            /// The standing
            /// </summary>
            public const string Standing = "STANDING";

            /// <summary>
            /// The quote
            /// </summary>
            public const string Quote = "QUOTE";

            /// <summary>
            /// The internet
            /// </summary>
            public const string Internet = "INTERNET";

            /// <summary>
            /// The ex change
            /// </summary>
            public const string Ec = "EC";

            /// <summary>
            /// The posted
            /// </summary>
            public const string Posted = "POSTED";

            /// <summary>
            /// The decimals
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// The fromdate
            /// </summary>
            public const string Fromdate = "FROMDATE";

            /// <summary>
            /// The todate
            /// </summary>
            public const string Todate = "TODATE";

            #endregion

            #region Properties Credit Note List Report

            /// <summary>
            /// The information
            /// </summary>
            public const string Information = "INFORMATION";

            /// <summary>
            /// The address
            /// </summary>
            public const string Address = "ADDRESS";

            /// <summary>
            /// The detail
            /// </summary>
            public const string Detail = "DETAIL";

            /// <summary>
            /// All orders
            /// </summary>
            public const string AllOrders = "ALLORDERS";

            /// <summary>
            /// The prepayment
            /// </summary>
            public const string Prepayment = "PREPAYMENT";

            /// <summary>
            /// The format phone
            /// </summary>
            public const string FormatPhone = "FMTPHONE";

            /// <summary>
            /// The currency summary file
            /// </summary>
            public const string CurrencySummaryFile = "CURRSUMMFILE";

            /// <summary>
            /// The fractqty
            /// </summary>
            public const string Fractqty = "FRACTQTY";

            /// <summary>
            /// The sales persons
            /// </summary>
            public const string SalesPersons = "SALESPERSONS";

            /// <summary>
            /// The optional fields
            /// </summary>
            public const string OptionalFields = "OPTFLDS";

            /// <summary>
            /// The regional format
            /// </summary>
            public const string RegionalFormat = "REGIONALFMT";

            /// <summary>
            /// The tax information
            /// </summary>
            public const string TaxInformation = "TAXINFORMATION";

            /// <summary>
            /// The SWPM active
            /// </summary>
            public const string SwpmActive = "SWPMACTIVE";

            /// <summary>
            /// The swincljob
            /// </summary>
            public const string Swincljob = "SWINCLJOB";

            /// <summary>
            /// The level1 name
            /// </summary>
            public const string Level1Name = "LEVEL1NAME";

            /// <summary>
            /// The level2 name
            /// </summary>
            public const string Level2Name = "LEVEL2NAME";

            /// <summary>
            /// The level3 name
            /// </summary>
            public const string Level3Name = "LEVEL3NAME";

            /// <summary>
            /// The sw retainage
            /// </summary>
            public const string SwRetainage = "SWRETAINAGE";

            /// <summary>
            /// The ar retainage
            /// </summary>
            public const string ArRetainage = "ARRETAINAGE";

            /// <summary>
            /// The serial lot numbers
            /// </summary>
            public const string SerialLotNumbers = "SERIALLOTNUMBERS";

            /// <summary>
            /// The swsnltlic
            /// </summary>
            public const string Swsnltlic = "SWSNLTLIC";

            #endregion


            #region Shitpment List

            /// <summary>
            /// From shipment number
            /// </summary>
           public const string FromShipmentNumber = "FROMSHINUM";


            /// <summary>
            /// To shipment number
            /// </summary>
            public const string ToShipmentNumber = "TOSHINUM";


            #endregion
        }

        /// <summary>
        /// Contains Transaction list Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// From order number
            /// </summary>
            public const int FromOrderNumber = 1;

            /// <summary>
            /// To order number
            /// </summary>
            public const int ToOrderNumber = 2;

            /// <summary>
            /// From invoice number
            /// </summary>
            public const int FromInvoiceNumber = 3;

            /// <summary>
            /// To invoice number
            /// </summary>
            public const int ToInvoiceNumber = 4;

            /// <summary>
            /// From credit debit number
            /// </summary>
            public const int FromCreditDebitNumber = 5;

            /// <summary>
            /// To credit debit number
            /// </summary>
            public const int ToCreditDebitNumber = 6;

            /// <summary>
            /// From customer
            /// </summary>
            public const int FromCustomer = 7;

            /// <summary>
            /// To customer
            /// </summary>
            public const int ToCustomer = 8;

            /// <summary>
            /// The multi currency
            /// </summary>
            public const int MultiCurrency = 9;

            /// <summary>
            /// The sort by
            /// </summary>
            public const int SortBy = 10;

            /// <summary>
            /// The from1
            /// </summary>
            public const int From1 = 11;

            /// <summary>
            /// The to1
            /// </summary>
            public const int To1 = 12;

            /// <summary>
            /// The from2
            /// </summary>
            public const int From2 = 13;

            /// <summary>
            /// The to2
            /// </summary>
            public const int To2 = 14;

            /// <summary>
            /// From currency
            /// </summary>
            public const int FromCurrency = 15;

            /// <summary>
            /// To currency
            /// </summary>
            public const int ToCurrency = 16;

            /// <summary>
            /// The entered
            /// </summary>
            public const int Entered = 17;

            /// <summary>
            /// The confirmation
            /// </summary>
            public const int Confirmation = 18;

            /// <summary>
            /// The picking slip
            /// </summary>
            public const int PickingSlip = 19;

            /// <summary>
            /// The never shipped
            /// </summary>
            public const int NeverShipped = 20;

            /// <summary>
            /// The part shipped
            /// </summary>
            public const int PartShipped = 21;

            /// <summary>
            /// The complete
            /// </summary>
            public const int Complete = 22;

            /// <summary>
            /// The on hold
            /// </summary>
            public const int OnHold = 23;

            /// <summary>
            /// The active
            /// </summary>
            public const int Active = 24;

            /// <summary>
            /// The future
            /// </summary>
            public const int Future = 25;

            /// <summary>
            /// The standing
            /// </summary>
            public const int Standing = 26;

            /// <summary>
            /// The quote
            /// </summary>
            public const int Quote = 27;

            /// <summary>
            /// The internet
            /// </summary>
            public const int Internet = 28;

            /// <summary>
            /// The ex change
            /// </summary>
            public const int Ec = 29;

            /// <summary>
            /// The posted
            /// </summary>
            public const int Posted = 30;

            /// <summary>
            /// The decimals
            /// </summary>
            public const int Decimals = 31;

            /// <summary>
            /// The fromdate
            /// </summary>
            public const int Fromdate = 32;

            /// <summary>
            /// The todate
            /// </summary>
            public const int Todate = 33;

            /// <summary>
            /// The information
            /// </summary>
            public const int Information = 34;

            /// <summary>
            /// The address
            /// </summary>
            public const int Address = 35;

            /// <summary>
            /// The detail
            /// </summary>
            public const int Detail = 36;

            /// <summary>
            /// All orders
            /// </summary>
            public const int AllOrders = 37;

            /// <summary>
            /// The prepayment
            /// </summary>
            public const int Prepayment = 38;

            /// <summary>
            /// The format phone
            /// </summary>
            public const int FormatPhone = 39;

            /// <summary>
            /// The currency summary file
            /// </summary>
            public const int CurrencySummaryFile = 40;

            /// <summary>
            /// The factory quantity
            /// </summary>
            public const int Fractqty = 41;

            /// <summary>
            /// The sales persons
            /// </summary>
            public const int SalesPersons = 42;

            /// <summary>
            /// The optional fields
            /// </summary>
            public const int OptionalFields = 43;

            /// <summary>
            /// The regional format
            /// </summary>
            public const int RegionalFormat = 44;

            /// <summary>
            /// The SWPM active
            /// </summary>
            public const int SwpmActive = 45;

            /// <summary>
            /// The swincljob
            /// </summary>
            public const int Swincljob = 46;

            /// <summary>
            /// The level1 name
            /// </summary>
            public const int Level1Name = 47;

            /// <summary>
            /// The level2 name
            /// </summary>
            public const int Level2Name = 48;

            /// <summary>
            /// The level3 name
            /// </summary>
            public const int Level3Name = 49;

            /// <summary>
            /// The sw retainage
            /// </summary>
            public const int SwRetainage = 50;

            /// <summary>
            /// The ar retainage
            /// </summary>
            public const int ArRetainage = 51;

            /// <summary>
            /// The serial lot numbers
            /// </summary>
            public const int SerialLotNumbers = 52;

            /// <summary>
            /// The swsnltlic
            /// </summary>
            public const int Swsnltlic = 53;


            /// <summary>
            /// From shipment number
            /// </summary>
            public const int FromShipmentNumber = 54;

            /// <summary>
            /// To shipment number
            /// </summary>
            public const int ToShipmentNumber = 55;

            #endregion
        }
    }
}
