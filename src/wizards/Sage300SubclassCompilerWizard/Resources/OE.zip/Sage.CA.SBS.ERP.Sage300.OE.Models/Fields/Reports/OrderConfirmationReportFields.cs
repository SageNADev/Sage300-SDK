/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Contains list of Order Confirmation Report Fields
    /// </summary>
    public partial class OrderConfirmationReport
    {
        /// <summary>
        /// View Name for Order Confirmation Report
        /// </summary>
        public const string ViewName = "099ade2a-fc1c-42d2-8b26-bc21e423ee0d";

        /// <summary>
        /// The Program Id for Order Confirmation Report
        /// </summary>
        public const string ViewId = "OE1200";

        /// <summary>
        /// Class for fields of Order Confirmation Report
        /// </summary>
        public class Fields
        {
            #region Fields

            /// <summary>
            /// The field for OnHold
            /// </summary>
            public const string OnHold = "ONHOLD";

            /// <summary>
            /// The field for Type
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// The field for PrintStat
            /// </summary>
            public const string PrintStat = "PRINTSTAT";

            /// <summary>
            /// The field for ORDNUMBER
            /// </summary>
            public const string OrderNumber = "ORDNUMBER";

            /// <summary>
            /// The field for SortFrom
            /// </summary>
            public const string FromOrderNumber = "SORTFROM";

            /// <summary>
            /// The field for SortTo
            /// </summary>
            public const string ToOrderNumber = "SORTTO";

            /// <summary>
            /// The field for Printed
            /// </summary>
            public const string Printed = "PRINTED";

            /// <summary>
            /// The field for FractionalQuantityDecimals
            /// </summary>
            public const string FractionalQuantityDecimals = "QTYDEC";

            /// <summary>
            /// The field for Swdelmethod
            /// </summary>
            public const string DeliveryMethod = "SWDELMETHOD";

            /// <summary>
            /// The field for PrintKit
            /// </summary>
            public const string IncludePrintKitItems = "PRINTKIT";

            /// <summary>
            /// The field for Printbom
            /// </summary>
            public const string IncludePrintBillsOfMaterialItems = "PRINTBOM";

            /// <summary>
            /// The field for SwprintOnHold
            /// </summary>
            public const string IncludePrintOnHoldOrders = "SWPRINTONHOLD";

            /// <summary>
            /// The field for SerialLotNumbers
            /// </summary>
            public const string IncludePrintSerialLotNumbers = "SERIALLOTNUMBERS";

            /// <summary>
            /// Property for EmailSendTo
            /// </summary>
            public const string EmailSendTo = "EMAILSENDTO";

            /// <summary>
            /// Property for EmailSubject
            /// </summary>
            public const string EmailSubject = "EMAILSUBJECT";

            /// <summary>
            /// Property for EmailMessageBody
            /// </summary>
            public const string EmailMessageBody = "EMAILTEXT";

            /// <summary>
            /// Property for SelectionCriteria
            /// </summary>
            public const string SelectionCriteria = "@SELECTION_CRITERIA";

            #endregion
        }
    }
}
