// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
	/// <summary>
	/// Contains list of EmailMessageReport Constants
	/// </summary>
	public partial class EmailMessageReport
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "8d7f1c1a-23b4-4f62-aae1-e5f9781f781a";

		#region Properties
		/// <summary>
		/// Contains list of EmailMessageReport Field Constants
		/// </summary>
		public class Fields
		{
			/// <summary>
			/// Property for Reporttype
			/// </summary>
			public const string Reporttype = "REPORTTYPE";
		}
		#endregion

		#region Properties
		/// <summary>
		/// Contains list of EmailMessageReport Index Constants
		/// </summary>
		public class Index
		{
			/// <summary>
			/// Property Indexer for Reporttype
			/// </summary>
			public const int Reporttype = 2;
		}
		#endregion
	}
}