﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */


// ReSharper disable once CheckNamespace


namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Contains list of Order Action Report Constants
    /// </summary>
    public partial class OrderActionReport
    {
        #region Constants

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "48B1DF1C-A58A-418E-B9C4-8641E6F94257";

        #endregion

        /// <summary>
        /// Order Action Report Field Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class
            
            /// <summary>
            /// Property for OrderType
            /// </summary>
            public const string OrderType = "ORDERTYPE";

            /// <summary>
            /// Property for PrintStatus
            /// </summary>
            public const string PrintStatus = "PRINTSTATUS";

            /// <summary>
            /// Property for ItemStatus
            /// </summary>
            public const string ItemStatus  = "ITEMSTATUS";

            /// <summary>
            /// Property for SortBy
            /// </summary>
            public const string SortBy  = "SORTBY";

            /// <summary>
            /// Property for Home Currency Decimal
            /// </summary>
            public const string Decimal  = "DECIMALS";

            /// <summary>
            /// Property for Source Currency 
            /// </summary>
            public const string SourceCurrency = "SOURCECURR";

            /// <summary>
            /// Property for MultiCurrency  
            /// </summary>
            public const string MultiCurr = "MULTICURR";

            /// <summary>
            /// Property for StartSort
            /// </summary>
            public const string StartSort = "STARTSORT";

            /// <summary>
            /// Property for EndSort
            /// </summary>
            public const string EndSort = "ENDSORT";

            /// <summary>
            /// Property for FromShipDate
            /// </summary>
            public const string FromShipDate = "FROMSHPDATE";

            /// <summary>
            /// Property for ToShipDate
            /// </summary>
            public const string ToShipDate = "TOSHPDATE";

            /// <summary>
            /// Property for OrderSource
            /// </summary>
            public const string OrderSource = "ORDSOURCE";

            /// <summary>
            /// Property for SWPMActive 
            /// </summary>
            public const string SwpmActive = "SWPMACTIVE";

            /// <summary>
            /// Property for SWInclJob 
            /// </summary>
            public const string SwInclJob = "SWINCLJOB";

            /// <summary>
            /// Property for Level1Name 
            /// </summary>
            public const string Level1Name = "LEVEL1NAME";

            /// <summary>
            /// Property for Level2Name 
            /// </summary>
            public const string Level2Name = "LEVEL2NAME";

            /// <summary>
            /// Property for Level3Name 
            /// </summary>
            public const string Level3Name = "LEVEL3NAME";


            #endregion
        }

        /// <summary>
        /// Order Action Report Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for OrderType
            /// </summary>
            public const string OrderType = "2";

            /// <summary>
            /// Property Indexer for PrintStatus
            /// </summary>
            public const string PrintStatus = "3";

            /// <summary>
            /// Property Indexer for ItemStatus
            /// </summary>
            public const string ItemStatus = "4";

            /// <summary>
            /// Property Indexer for SortBy
            /// </summary>
            public const string SortBy = "5";

            /// <summary>
            /// Property Indexer for Home Currency Decimal
            /// </summary>
            public const string Decimal = "6";

            /// <summary>
            /// Property Indexer for Source Currency 
            /// </summary>
            public const string SourceCurrency = "7";

            /// <summary>
            /// Property Indexer for MultiCurrency  
            /// </summary>
            public const string MultiCurr = "8";

            /// <summary>
            /// Property Indexer for StartSort
            /// </summary>
            public const string StartSort = "9";

            /// <summary>
            /// Property Indexer for EndSort
            /// </summary>
            public const string EndSort = "10";

            /// <summary>
            /// Property Indexer for FromShipDate
            /// </summary>
            public const string FromShipDate = "11";

            /// <summary>
            /// Property Indexer for ToShipDate
            /// </summary>
            public const string ToShipDate = "12";

            /// <summary>
            /// Property Indexer for OrderSource
            /// </summary>
            public const string OrderSource = "13";

            /// <summary>
            /// Property Indexer for SWPMActive 
            /// </summary>
            public const string SwpmActive = "14";

            /// <summary>
            /// Property Indexer for SWInclJob 
            /// </summary>
            public const string SwInclJob = "15";

            /// <summary>
            /// Property Indexer for Level1Name 
            /// </summary>
            public const string Level1Name = "16";

            /// <summary>
            /// Property Indexer for Level2Name 
            /// </summary>
            public const string Level2Name = "17";

            /// <summary>
            /// Property Indexer for Level3Name 
            /// </summary>
            public const string Level3Name = "18";

            #endregion
        }
    }
}
