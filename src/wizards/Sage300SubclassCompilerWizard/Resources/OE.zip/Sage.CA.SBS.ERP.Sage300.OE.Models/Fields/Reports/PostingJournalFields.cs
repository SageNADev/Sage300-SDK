// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Contains list of PostingJournal Constants
    /// </summary>
    public partial class PostingJournal
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "6F0F3330-7204-48E8-BB6C-105F7B5534B4";

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PostingJournal Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for SortFrom
            /// </summary>
            public const string SortFrom = "SORTFROM";

            /// <summary>
            /// Property for SortTo 
            /// </summary>
            public const string SortTo = "SORTTO";

            /// <summary>
            /// Property for Sales Split 
            /// </summary>
            public const string SalesSplit = "SALESSPLIT";

            /// <summary>
            /// Property for Fractional 
            /// </summary>
            public const string Fractional = "FRACTIONAL";

            /// <summary>
            /// Property for Home currency 
            /// </summary>
            public const string Homecurrency = "HCURN";

            /// <summary>
            /// Property for TaxSummary 
            /// </summary>
            public const string TaxSummary = "TAXSUMMARY";

            /// <summary>
            /// Property for Is GlActive 
            /// </summary>
            public const string IsGlActive = "GLACTIVE";

            /// <summary>
            /// Property for Ar Audit Option 
            /// </summary>
            public const string ArAuditOption = "ARAUDITOPTION";

            /// <summary>
            /// Property for Tax Information 
            /// </summary>
            public const string TaxInformation = "TAXINFORMATION";

            /// <summary>
            /// Property for Has Detail OptionalField 
            /// </summary>
            public const string HasDetailOptionalField = "HASDETAILOPTIONALFIELDS";

            /// <summary>
            /// Property for Include Serial Lot Numbers 
            /// </summary>
            public const string InclSerialLotNumbers = "INCLSERIALLOTNUMBERS";

            /// <summary>
            /// Property for AR File 
            /// </summary>
            public const string ArFile = "ARFILE";

            /// <summary>
            /// Property for GLFile 
            /// </summary>
            public const string GlFile = "GLFILE";

            /// <summary>
            /// Property for CurrentFile
            /// </summary>
            public const string CurrentFile = "CURFILE";
        }
        #endregion
    }
}
