﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */


// ReSharper disable once CheckNamespace


namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Contains list of Salesperson Commissions Report Constants
    /// </summary>
    public partial class SalespersonCommissionReport
    {
        #region Constants

        /// <summary>
        /// View Name - New Guid
        /// </summary>
        public const string ViewName = "OE0200";

        #endregion

        /// <summary>
        /// Invoice Action Report Field Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for IncludeCommissionType
            /// </summary>
            public const string IncludeCommissionType = "INCLUDECOMMTYPE";

            /// <summary>
            /// Property for FromDate
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for ToDate
            /// </summary>
            public const string ToDate = "TODATE";

            /// <summary>
            /// Property for FromYear
            /// </summary>
            public const string FromYear = "FROMYR";

            /// <summary>
            /// Property for ToYear
            /// </summary>
            public const string ToYear = "TOYR";
            
            /// <summary>
            /// Property for FromPeriod 
            /// </summary>
            public const string FromPeriod = "FROMPR";

            /// <summary>
            /// Property for ToPeriod 
            /// </summary>
            public const string ToPeriod = "TOPR";

            /// <summary>
            /// Property for SortBy
            /// </summary>
            public const string SortBy = "SORTBY";
            
            /// <summary>
            /// Property for SelectBy 
            /// </summary>
            public const string SelectBy = "SELECTBY";

            /// <summary>
            /// Property for FromSalesPerson 
            /// </summary>
            public const string FromSalesPerson = "FROMSALESPERSON";

            /// <summary>
            /// Property for ToSalesPerson 
            /// </summary>
            public const string ToSalesPerson = "TOSALESPERSON";

            /// <summary>
            /// Property for Decimals
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for CommissionType 
            /// </summary>
            public const string CommissionType = "COMMTYPE";

            /// <summary>
            /// Property for Subtotal  
            /// </summary>
            public const string Subtotal = "SUBTOTAL";

            

            #endregion
        }

        /// <summary>
        /// Vendor Report Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for IncludeCommissionType 
            /// </summary>
            public const string IncludeCommissionType = "2";

            /// <summary>
            /// Property Indexer for FromDate 
            /// </summary>
            public const string FromDate = "3";

            /// <summary>
            /// Property Indexer for ToDate 
            /// </summary>
            public const string ToDate = "4";

            /// <summary>
            /// Property Indexer for FromYear
            /// </summary>
            public const string FromYear = "5";

            /// <summary>
            /// Property Indexer for ToYear
            /// </summary>
            public const string ToYear = "6";

            /// <summary>
            /// Property Indexer for FromPeriod
            /// </summary>
            public const string FromPeriod = "7";

            /// <summary>
            /// Property Indexer for ToPeriod
            /// </summary>
            public const string ToPeriod = "8";

            /// <summary>
            /// Property Indexer for SortBy 
            /// </summary>
            public const string SortBy = "9";

            /// <summary>
            /// Property Indexer for SelectBy 
            /// </summary>
            public const string SelectBy = "10";

            /// <summary>
            /// Property Indexer for FromSalesPerson 
            /// </summary>
            public const string FromSalesPerson = "11";

            /// <summary>
            /// Property Indexer for ToSalesPerson 
            /// </summary>
            public const string ToSalesPerson = "12";

            /// <summary>
            /// Property Indexer for Decimals 
            /// </summary>
            public const string Decimals = "13";

            /// <summary>
            /// Property Indexer for CommissionType    
            /// </summary>
            public const string CommissionType = "14";

            /// <summary>
            /// Property Indexer for Subtotal    
            /// </summary>
            public const string Subtotal = "15";

            #endregion
        }
    }
}
