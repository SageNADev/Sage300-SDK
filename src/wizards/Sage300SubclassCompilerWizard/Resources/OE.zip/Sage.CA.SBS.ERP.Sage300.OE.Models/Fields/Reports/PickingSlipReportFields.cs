/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Contains list of Picking Slips Report Fields
    /// </summary>
    public partial class PickingSlipReport
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "c12b0d9a-e22e-4c8c-86f9-255ebfaca108";
        
        /// <summary>
        /// Class for fields of PickingSlipReport
        /// </summary>
        public class Fields
        {
            #region Fields

            /// <summary>
            /// The field for  SelectBy
            /// </summary>
            public const string SelectBy = "SELECTBY";
            
            /// <summary>
            /// The field for  SortBy
            /// </summary>
            public const string SortBy = "SORTBY";
            
            /// <summary>
            /// The field for  FromSelect
            /// </summary>
            public const string FromSelect = "FROMSELECT";
            
            /// <summary>
            /// The field for  ToSelect
            /// </summary>
            public const string ToSelect = "TOSELECT";
            
            /// <summary>
            /// The field for  FromLoc
            /// </summary>
            public const string FromLoc = "FROMLOC";
            
            /// <summary>
            /// The field for  ToLoc
            /// </summary>
            public const string ToLoc = "TOLOC";

            /// <summary>
            /// The field for  Reprint
            /// </summary>
            public const string IncludeAlreadyPrinted = "REPRINT";
            
            /// <summary>
            /// The field for  QtyDec
            /// </summary>
            public const string QtyDec = "QTYDEC";
            
            /// <summary>
            /// The field for  Completed
            /// </summary>
            public const string Completed = "COMPLETED";
            
            /// <summary>
            /// The field for  Printkit
            /// </summary>
            public const string PrintKitComponentItems = "PRINTKIT";

            /// <summary>
            /// The field for  Printbom
            /// </summary>
            public const string PrintBomComponentItems = "PRINTBOM";
            
            /// <summary>
            /// The field for  Seshndl
            /// </summary>
            public const string Seshndl = "SESHNDL";
            
            /// <summary>
            /// The field for  PrintBy
            /// </summary>
            public const string PrintBy = "PRINTBY";
            
            /// <summary>
            /// The field for  SerialLotNumbers
            /// </summary>
            public const string SerialLotNumbers = "SERIALLOTNUMBERS";

            #endregion
        }
    }
}
