﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    public partial class ShippingLabelReport
    {
        
        #region Properties

        /// <summary>
        /// Contains list of Shipping Label Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for SelectItem
            /// </summary>
            public const string FuncDec = "FUNCDEC";

            /// <summary>
            /// Property for SelectItem
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// Property for FromItem
            /// </summary>
            public const string SortFrom = "SORTFROM";

            /// <summary>
            /// Property for ToItem
            /// </summary>
            public const string SortTo = "SORTTO";

            /// <summary>
            /// Property for IncludePrinted
            /// </summary>
            public const string IncludePrinted = "PRINTED";

            /// <summary>
            /// Property for RequiredOption
            /// </summary>
            public const string RequiredOption = "REQUIRED";

        }

        #endregion
    }
}
