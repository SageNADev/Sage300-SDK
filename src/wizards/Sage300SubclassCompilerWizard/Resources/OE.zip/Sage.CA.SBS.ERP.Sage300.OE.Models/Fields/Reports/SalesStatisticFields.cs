// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Contains list of SalesStatisticsReport Constants
    /// </summary>
    public partial class SalesStatisticsReport
    {
        #region Constants
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "OE0700";
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of SalesStatisticsReport Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for FromYear 
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for ToYear 
            /// </summary>
            public const string ToYear = "TOYEAR";

            /// <summary>
            /// Property for FromPeriod 
            /// </summary>
            public const string FromPeriod = "FROMPERIOD";

            /// <summary>
            /// Property for ToPeriod 
            /// </summary>
            public const string ToPeriod = "TOPERIOD";

            /// <summary>
            /// Property for FromCurrency 
            /// </summary>
            public const string FromCurrency = "FROMCURR";

            /// <summary>
            /// Property for ToCurrency 
            /// </summary>
            public const string ToCurrency = "TOCURR";

            /// <summary>
            /// Property for ConsolidateCurrencies 
            /// </summary>
            public const string ConsolidateCurrencies = "CONSOLIDATE";

            /// <summary>
            /// Property for QuantityDecimals 
            /// </summary>
            public const string QuantityDecimals = "QTYDECMLS";

            /// <summary>
            /// Property for Decimals 
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for Multicurrency 
            /// </summary>
            public const string Multicurrency = "MULTICURR";

            /// <summary>
            /// Property for SourceCurrency 
            /// </summary>
            public const string SourceCurrency = "SOURCECURR";



        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of SalesStatisticsReport Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for FromYear 
            /// </summary>
            public const int FromYear = 2;

            /// <summary>
            /// Property Indexer for FromPeriod 
            /// </summary>
            public const int FromPeriod = 3;

            /// <summary>
            /// Property Indexer for ToYear 
            /// </summary>
            public const int ToYear = 4;

            /// <summary>
            /// Property Indexer for ToPeriod 
            /// </summary>
            public const int ToPeriod = 5;

            /// <summary>
            /// Property Indexer for Multicurrency 
            /// </summary>
            public const int Multicurrency = 6;

            /// <summary>
            /// Property Indexer for SourceCurrency 
            /// </summary>
            public const int SourceCurrency = 7;

            /// <summary>
            /// Property Indexer for FromCurrency 
            /// </summary>
            public const int FromCurrency = 8;

            /// <summary>
            /// Property Indexer for ToCurrency 
            /// </summary>
            public const int ToCurrency = 9;

            /// <summary>
            /// Property Indexer for Decimals 
            /// </summary>
            public const int Decimals = 10;

            /// <summary>
            /// Property Indexer for ConsolidateCurrencies 
            /// </summary>
            public const int ConsolidateCurrencies = 11;

            /// <summary>
            /// Property Indexer for QuantityDecimals 
            /// </summary>
            public const int QuantityDecimals = 12;

        }
        #endregion

    }
}
