// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 


// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports

{
    /// <summary>
    /// Contains list of AgedOrderReport Constants 
    /// </summary>
    public partial class AgedOrderReport
	{

        #region Constants

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "E2A39845-F942-421C-B013-E05F343D483F";

        #endregion

        /// <summary>
        /// Contains list of AgedOrder Field Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
            /// <summary>
            /// Property for Starting Order Number
            /// </summary>
            public const string StartOrdNum = "STARTORDNUM";
	        /// <summary>
            /// Property for Ending Order Number 
            /// </summary>
            public const string EndOrdNum = "ENDORDNUM";
	        /// <summary>
            /// Property for Starting Customer Number 
            /// </summary>
            public const string StartCustNum = "STARTCUSTNUM";
	        /// <summary>
            /// Property for Ending Customer Number  
            /// </summary>
            public const string EndCustNum = "ENDCUSTNUM";
	        /// <summary>
            /// Property for Starting Currency 
            /// </summary>
            public const string StartCurr = "STARTCURR";
            /// <summary>
            /// Property for  Ending Currency 
            /// </summary>
            public const string EndCurr = "ENDCURR";
	        /// <summary>
            /// Property for Sort by parameter 
            /// </summary>
            public const string SortBy = "SORTBY";
	        /// <summary>
            /// Property for the Contact Phone number
            /// </summary>
            public const string ContactPhone = "CONTACTPHONE";
	        /// <summary>
            /// Property for Comment given in Report 
            /// </summary>
            public const string Comment = "COMMENT";
	        /// <summary>
            /// Property for Invoices 
            /// </summary>
            public const string Invoices = "INVOICES";
            /// <summary>
            /// Property for Report Currency 
            /// </summary>
            public const string RptCurrency = "RPTCURRENCY";
            /// <summary>
            /// Property for As of Date 
            /// </summary>
            public const string AsOfDate = "ASOFDATE";
            /// <summary>
            /// Property for Cut Off Date 
            /// </summary>
            public const string CutOffDate = "CUTOFFDATE";
            /// <summary>
            /// Property for first Period 
            /// </summary>
            public const string Period1St = "PERIOD1ST";
            /// <summary>
            /// Property for 2nd Period 
            /// </summary>
            public const string Period2Nd = "PERIOD2ND";
            /// <summary>
            /// Property for 3rd Period 
            /// </summary>
            public const string Period3Rd = "PERIOD3RD";
            /// <summary>
            /// Property for Phone format 
            /// </summary>
            public const string FmtPhone = "FMTPHONE";
            /// <summary>
            /// Property for MultiCurrency 
            /// </summary>
            public const string MultiCurr = "MULTICURR";
            /// <summary>
            /// Property for Summary File 
            /// </summary>
            public const string CurrSummFile = "CURRSUMMFILE";
            /// <summary>
            /// Property for Current Period
            /// </summary>
            public const string Current = "CURRNT";
            
        #endregion
	    }


		/// <summary>
        /// Contains list of PrintT5018CprsReport Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	        /// <summary>
            /// Property Indexer for Starting Order Number 
            /// </summary>
            public const int StartOrdNum = 1;
            /// <summary>
            /// Property Indexer for Ending Order Number 
            /// </summary>
            public const int EndOrdNum = 2;
	        /// <summary>
            /// Property Indexer for Starting Customer Number 
            /// </summary>
            public const int StartCustNum = 3;
	        /// <summary>
            /// Property Indexer for Ending Customer Number 
            /// </summary>
            public const int EndCustNum = 4;
	        /// <summary>
            /// Property Indexer for Starting Currency 
            /// </summary>
            public const int StartCurr = 5;
	        /// <summary>
            /// Property Indexer for Ending Currency 
            /// </summary>
            public const int EndCurr = 6;
	        /// <summary>
            /// Property Indexer for Sort by 
            /// </summary>
            public const int SortBy = 7;
	        /// <summary>
            /// Property Indexer for Contact Phone number 
            /// </summary>
            public const int ContactPhone = 8;
	        /// <summary>
            /// Property Indexer for Comment given in Report 
            /// </summary>
            public const int Comment = 9;
            /// <summary>
            /// Property Indexer for Invoices 
            /// </summary>
            public const int Invoices = 10;
            /// <summary>
            /// Property Indexer for Report Currency
            /// </summary>
            public const int RptCurrency = 11;
            /// <summary>
            /// Property Indexer for As of Date
            /// </summary>
            public const int AsOfDate = 12;
            /// <summary>
            /// Property Indexer for Cut Off Date
            /// </summary>
            public const int CutOffDate = 13;
            /// <summary>
            /// Property Indexer for first Period
            /// </summary>
            public const int Period1St = 14;
            /// <summary>
            /// Property Indexer for 2nd Period
            /// </summary>
            public const int Period2Nd = 15;
            /// <summary>
            /// Property Indexer for  3rd Period
            /// </summary>
            public const int Period3Rd = 16;
            /// <summary>
            /// Property Indexer for Phone format
            /// </summary>
            public const int FmtPhone = 17;
            /// <summary>
            /// Property Indexer for MultiCurrency
            /// </summary>
            public const int MultiCurr = 18;
            /// <summary>
            /// Property Indexer for Summary File 
            /// </summary>
            public const int CurrSummFile = 19;
            /// <summary>
            /// Property Indexer for Current Period
            /// </summary>
            public const int Current = 20;
            #endregion
        }

	
	}
}
	