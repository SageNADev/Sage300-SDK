﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Contains list of QuoteReportFields Report Constants
    /// </summary>
    public partial class QuoteReport
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "8dd855e7-9179-45d3-a254-81dc8d97f72f";

        /// <summary>
        /// Class for fields of QuoteReport
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// The field for  ORDNUMBER
            /// </summary>
            public const string OrderNumber = "ORDNUMBER";

            #region Fields
            /// <summary>
            /// The field for Printstat
            /// </summary>
            public const string PrintStat = "PRINTSTAT";

            /// <summary>
            /// The field for Type
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// The field for Complete
            /// </summary>
            public const string Complete = "COMPLETE";

            /// <summary>
            /// The field for  SortFrom
            /// </summary>
            public const string SortFrom = "SORTFROM";

            /// <summary>
            /// The field for  SortTo
            /// </summary>
            public const string SortTo = "SORTTO";

            /// <summary>
            /// The field for  Printed
            /// </summary>
            public const string Printed = "PRINTED";

            /// <summary>
            /// The field for  QtyDecimal
            /// </summary>
            public const string QtyDecimal = "QTYDEC";

            /// <summary>
            /// The field for  Swdelmethod
            /// </summary>
            public const string DeliveryMethod = "SWDELMETHOD";

            /// <summary>
            /// The field for  PrintKit
            /// </summary>
            public const string PrintKit = "PRINTKIT";

            /// <summary>
            /// The field for  PrintBills
            /// </summary>
            public const string PrintBills = "PRINTBOM";

            /// <summary>
            /// The field for  CustomForm
            /// </summary>
            public const string UseCustomForm = "CUSTOMFORM";

            /// <summary>
            /// The field for  SelectionCriteria
            /// </summary>
            public const string SelectionCriteria = "@IDSELECT";

            /// <summary>
            /// Property for EmailSendTo
            /// </summary>
            public const string EmailSendTo = "EMAILSENDTO";

            /// <summary>
            /// Property for EmailSubject
            /// </summary>
            public const string EmailSubject = "EMAILSUBJECT";

            /// <summary>
            /// Property for EmailMessageBody
            /// </summary>
            public const string EmailMessageBody = "EMAILTEXT";

            #endregion
        }
    }
}
