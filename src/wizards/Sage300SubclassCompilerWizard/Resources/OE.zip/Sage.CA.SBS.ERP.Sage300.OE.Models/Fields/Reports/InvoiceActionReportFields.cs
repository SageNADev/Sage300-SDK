﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */


// ReSharper disable once CheckNamespace


namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Reports
{
    /// <summary>
    /// Contains list of Invoice Action Report Constants
    /// </summary>
    public partial class InvoiceActionReport
    {
        #region Constants

        /// <summary>
        /// View Name - New Guid
        /// </summary>
        //public const string ViewName = "OE0520";
        public const string ViewName = "OE0420";
        
        #endregion

        /// <summary>
        /// Invoice Action Report Field Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for PartiallyShipped
            /// </summary>
            public const string PartiallyShipped = "PARTIALLYSHIPPED";

            /// <summary>
            /// Property for FullyShipped
            /// </summary>
            public const string FullyShipped = "FULLYSHIPPED";

            /// <summary>
            /// Property for NotInvoiced
            /// </summary>
            public const string NotInvoiced = "NOTINVOICED";

            /// <summary>
            /// Property for PartiallyInvoiced
            /// </summary>
            public const string PartiallyInvoiced = "PARTIALLYINVOICED";

            /// <summary>
            /// Property for FullyInvoiced
            /// </summary>
            public const string FullyInvoiced = "FULLYINVOICED";

            /// <summary>
            /// Property for FromDate
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for ToDate
            /// </summary>
            public const string ToDate = "TODATE";
            
            /// <summary>
            /// Property for FromOrderNumber
            /// </summary>
            public const string FromOrderNumber = "FROMORDER";

            /// <summary>
            /// Property for ToOrderNumber
            /// </summary>
            public const string ToOrderNumber = "TOORDER";

            /// <summary>
            /// Property for ThenBy
            /// </summary>
            public const string ThenBy = "THENBY";

            /// <summary>
            /// Property for ThenBy from
            /// </summary>
            public const string ThenByFrom = "THENBYFROM";

            /// <summary>
            /// Property for ThenBy To
            /// </summary>
            public const string ThenByTo = "THENBYTO";

            /// <summary>
            /// Property for FromShipmentNumber 
            /// </summary>
            public const string FromShipmentNumber = "FROMSHIPMENT";

            /// <summary>
            /// Property for ToShipmentNumber 
            /// </summary>
            public const string ToShipmentNumber = "TOSHIPMENT";

            /// <summary>
            /// Property for Report Type 
            /// </summary>
            public const string ReportType = "REPORTTYPE";

          

            /// <summary>
            /// Property for Functional Decimals
            /// </summary>
            public const string FuncDecs = "FUNCDECS";

            /// <summary>
            /// Property for funcOrVendorCurrency 
            /// </summary>
            public const string PrintAmountIn = "PRINTAMTIN";

            /// <summary>
            /// Property for MultiCurrency  
            /// </summary>
            public const string MultiCurrency = "SWMULTICURR";

            /// <summary>
            /// Property for QtyDecs  
            /// </summary>
            public const string QtyDecs = "QTYDECS";


            /// <summary>
            /// Property for SWPMActive 
            /// </summary>
            public const string SwpmActive = "SWPMACTIVE";

            /// <summary>
            /// Property for SWInclJob 
            /// </summary>
            public const string SwInclJob = "SWINCLJOB";

            /// <summary>
            /// Property for Level1Name 
            /// </summary>
            public const string Level1Name = "LEVEL1NAME";

            /// <summary>
            /// Property for Level2Name 
            /// </summary>
            public const string Level2Name = "LEVEL2NAME";

            /// <summary>
            /// Property for Level3Name 
            /// </summary>
            public const string Level3Name = "LEVEL3NAME";


            #endregion
        }

        /// <summary>
        /// Vendor Report Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for PartiallyShipped 
            /// </summary>
            public const string PartiallyShipped = "2";

            /// <summary>
            /// Property Indexer for FullyShipped 
            /// </summary>
            public const string FullyShipped = "3";

            /// <summary>
            /// Property Indexer for NotInvoiced 
            /// </summary>
            public const string NotInvoiced = "4";

            /// <summary>
            /// Property Indexer for PartiallyInvoiced
            /// </summary>
            public const string PartiallyInvoiced = "5";

            /// <summary>
            /// Property Indexer for FullyInvoiced
            /// </summary>
            public const string FullyInvoiced = "6";

            /// <summary>
            /// Property Indexer for FromDate
            /// </summary>
            public const string FromDate = "7";

            /// <summary>
            /// Property Indexer for ToDate
            /// </summary>
            public const string ToDate = "8";

            /// <summary>
            /// Property Indexer for FromOrderNumber 
            /// </summary>
            public const string FromOrderNumber = "9";

            /// <summary>
            /// Property Indexer for ToOrderNumber 
            /// </summary>
            public const string ToOrderNumber = "10";

            /// <summary>
            /// Property Indexer for ThenBy 
            /// </summary>
            public const string ThenBy = "11";

            /// <summary>
            /// Property Indexer for ThenBy From 
            /// </summary>
            public const string ThenByFrom = "12";

            /// <summary>
            /// Property Indexer for ThenBy To  
            /// </summary>
            public const string ThenByTo = "13";

            /// <summary>
            /// Property Indexer for FromShipmentNumber    
            /// </summary>
            public const string FromShipmentNumber = "14";

            /// <summary>
            /// Property Indexer for ToShipmentNumber    
            /// </summary>
            public const string ToShipmentNumber = "15";

            /// <summary>
            /// Property Indexer for ReportType 
            /// </summary>
            public const string ReportType = "16";

            /// <summary>
            /// Property Indexer for funcdecs  
            /// </summary>
            public const string FuncDecs = "17";

            /// <summary>
            /// Property Indexer for FuncOrVendorCurrency 
            /// </summary>
            public const string FuncOrVendorCurrency = "18";

            /// <summary>
            /// Property Indexer for MultiCurrency 
            /// </summary>
            public const string MultiCurrency = "19";

            /// <summary>
            /// Property Indexer for QtyDecs 
            /// </summary>
            public const string QtyDecs = "20";

            /// <summary>
            /// Property Indexer for SWPMActive 
            /// </summary>
            public const string SwpmActive = "21";

            /// <summary>
            /// Property Indexer for SWInclJob 
            /// </summary>
            public const string SwInclJob = "22";

            /// <summary>
            /// Property Indexer for Level1Name 
            /// </summary>
            public const string Level1Name = "23";

            /// <summary>
            /// Property Indexer for Level2Name 
            /// </summary>
            public const string Level2Name = "24";

            /// <summary>
            /// Property Indexer for Level3Name 
            /// </summary>
            public const string Level3Name = "25";




            #endregion
        }
    }
}
