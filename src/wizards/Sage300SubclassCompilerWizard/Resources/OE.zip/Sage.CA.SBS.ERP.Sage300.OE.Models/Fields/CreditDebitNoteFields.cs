// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
using System.Collections.Generic;
namespace Sage.CA.SBS.ERP.Sage300.OE.Models
// ReSharper restore CheckNamespace
{
     /// <summary>
     /// Contains list of CreditDebitNote Constants
     /// </summary>
     public partial class CreditDebitNote
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "OE0240";

          /// <summary>
          /// Dynamic Attributes contain a reverse mapping of field and property
          /// </summary>
          public static Dictionary<string, string> DynamicAttributes
          {
              get
              {
                  return new Dictionary<string, string>
				{
					{"PONUMBER", "PurchaseOrderNumber"},
					{"CRRATETYPE", "CreditDebitNoteRateType"},
					{"CRRATEDATE", "CreditDebitNoteRateDate"},
					{"CRRATE", "CreditDebitNoteRate"},
					{"TBASE1", "TaxBase1"},
					{"TBASE2", "TaxBase2"},
					{"TBASE3", "TaxBase3"},
					{"TBASE4", "TaxBase4"},
					{"TBASE5", "TaxBase5"},
					{"TAMOUNT1", "TotalTaxAmount1"},
					{"TAMOUNT2", "TotalTaxAmount2"},
					{"TAMOUNT3", "TotalTaxAmount3"},
					{"TAMOUNT4", "TotalTaxAmount4"},
					{"TAMOUNT5", "TotalTaxAmount5"},
					{"ADJTYPE", "Type"},
					{"APPROVELMT", "ApprovedLimit"},
					{"APPPASSWRD", "AuthorizingUserPassword"},
					{"CTRRATTYPE", "TRRateType"},
					{"CTRRATDATE", "TRRateDate"},
					{"CTRRATE", "TRRate"},
					{"CTRAMOUNT1", "TRTaxAmount1"},
					{"CTRAMOUNT2", "TRTaxAmount2"},
					{"CTRAMOUNT3", "TRTaxAmount3"},
					{"CTRAMOUNT4", "TRTaxAmount4"},
					{"CTRAMOUNT5", "TRTaxAmount5"},
					{"HASJOB", "JobRelated"},
					{"HASRTG", "HasRetainage"},
					{"RTGPERCENT", "RetainagePercent"},
					{"RTGRATE", "RetainageExchangeRate"}
				};
              }
          }

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitNote Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CNUniquifier
               /// </summary>
               public const string CnUniquifier = "CRDUNIQ";

               /// <summary>
               /// Property for OrderNumber
               /// </summary>
               public const string OrderNumber = "ORDNUMBER";

               /// <summary>
               /// Property for InvoiceNumber
               /// </summary>
               public const string InvoiceNumber = "INVNUMBER";

               /// <summary>
               /// Property for CreditDebitNoteNumber
               /// </summary>
               public const string CreditDebitNoteNumber = "CRDNUMBER";

               /// <summary>
               /// Property for ICDayEndTransNumber
               /// </summary>
               public const string ICDayEndTransNumber = "DAYENDNUM";

               /// <summary>
               /// Property for CustomerNumber
               /// </summary>
               public const string CustomerNumber = "CUSTOMER";

               /// <summary>
               /// Property for BillTo
               /// </summary>
               public const string BillTo = "BILNAME";

               /// <summary>
               /// Property for BillToAddress1
               /// </summary>
               public const string BillToAddress1 = "BILADDR1";

               /// <summary>
               /// Property for BillToAddress2
               /// </summary>
               public const string BillToAddress2 = "BILADDR2";

               /// <summary>
               /// Property for BillToAddress3
               /// </summary>
               public const string BillToAddress3 = "BILADDR3";

               /// <summary>
               /// Property for BillToAddress4
               /// </summary>
               public const string BillToAddress4 = "BILADDR4";

               /// <summary>
               /// Property for BillToCity
               /// </summary>
               public const string BillToCity = "BILCITY";

               /// <summary>
               /// Property for BillToState
               /// </summary>
               public const string BillToState = "BILSTATE";

               /// <summary>
               /// Property for BillToZipCode
               /// </summary>
               public const string BillToZipCode = "BILZIP";

               /// <summary>
               /// Property for BillToCountry
               /// </summary>
               public const string BillToCountry = "BILCOUNTRY";

               /// <summary>
               /// Property for BillToPhone
               /// </summary>
               public const string BillToPhone = "BILPHONE";

               /// <summary>
               /// Property for BillToFax
               /// </summary>
               public const string BillToFax = "BILFAX";

               /// <summary>
               /// Property for BillToContact
               /// </summary>
               public const string BillToContact = "BILCONTACT";

               /// <summary>
               /// Property for CustomerDiscountLevel
               /// </summary>
               public const string CustomerDiscountLevel = "CUSTDISC";

               /// <summary>
               /// Property for DefaultPriceListCode
               /// </summary>
               public const string DefaultPriceListCode = "PRICELIST";

               /// <summary>
               /// Property for PurchaseOrderNumber
               /// </summary>
               public const string PurchaseOrderNumber = "PONUMBER";

               /// <summary>
               /// Property for Territory
               /// </summary>
               public const string Territory = "TERRITORY";

               /// <summary>
               /// Property for Reference
               /// </summary>
               public const string Reference = "REFERENCE";

               /// <summary>
               /// Property for OrderDate
               /// </summary>
               public const string OrderDate = "ORDDATE";

               /// <summary>
               /// Property for FreeOnBoardPoint
               /// </summary>
               public const string FreeOnBoardPoint = "FOB";

               /// <summary>
               /// Property for TemplateCode
               /// </summary>
               public const string TemplateCode = "TEMPLATE";

               /// <summary>
               /// Property for DefaultLocationCode
               /// </summary>
               public const string DefaultLocationCode = "LOCATION";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for Comment
               /// </summary>
               public const string Comment = "COMMENT";

               /// <summary>
               /// Property for ShipmentDate
               /// </summary>
               public const string ShipmentDate = "SHIPDATE";

               /// <summary>
               /// Property for InvoiceDate
               /// </summary>
               public const string InvoiceDate = "INVDATE";

               /// <summary>
               /// Property for InvoiceFiscalYear
               /// </summary>
               public const string InvoiceFiscalYear = "INVFISCYR";

               /// <summary>
               /// Property for InvoiceFiscalPeriod
               /// </summary>
               public const string InvoiceFiscalPeriod = "INVFISCPER";

               /// <summary>
               /// Property for InvoiceHomeCurrency
               /// </summary>
               public const string InvoiceHomeCurrency = "INHOMECURR";

               /// <summary>
               /// Property for InvoiceRateType
               /// </summary>
               public const string InvoiceRateType = "INRATETYPE";

               /// <summary>
               /// Property for InvoiceSourceCurrency
               /// </summary>
               public const string InvoiceSourceCurrency = "INSOURCURR";

               /// <summary>
               /// Property for InvoiceRateDate
               /// </summary>
               public const string InvoiceRateDate = "INRATEDATE";

               /// <summary>
               /// Property for InvoiceRate
               /// </summary>
               public const string InvoiceRate = "INRATE";

               /// <summary>
               /// Property for InvoiceSpread
               /// </summary>
               public const string InvoiceSpread = "INSPREAD";

               /// <summary>
               /// Property for InvoiceRateDateMatching
               /// </summary>
               public const string InvoiceRateDateMatching = "INDATEMTCH";

               /// <summary>
               /// Property for InvoiceRateOperator
               /// </summary>
               public const string InvoiceRateOperator = "INRATEREP";

               /// <summary>
               /// Property for InvoiceRateOverrideFlag
               /// </summary>
               public const string InvoiceRateOverrideFlag = "INRATEOVER";

               /// <summary>
               /// Property for CRItemSubtotal
               /// </summary>
               public const string CRItemSubtotal = "CRDTOTAL";

               /// <summary>
               /// Property for CRMiscChargesSubtotal
               /// </summary>
               public const string CRMiscChargesSubtotal = "CRDMTOTAL";

               /// <summary>
               /// Property for ReturnDate
               /// </summary>
               public const string ReturnDate = "RETDATE";

               /// <summary>
               /// Property for CreditDebitNoteDate
               /// </summary>
               public const string CreditDebitNoteDate = "CRDDATE";

               /// <summary>
               /// Property for CreditDebitNoteFiscalYear
               /// </summary>
               public const string CreditDebitNoteFiscalYear = "CRDFISCYR";

               /// <summary>
               /// Property for CreditDebitNoteFiscalPeriod
               /// </summary>
               public const string CreditDebitNoteFiscalPeriod = "CRDFISCPER";

               /// <summary>
               /// Property for NoOfLinesInCreditDebitNote
               /// </summary>
               public const string NoOfLinesInCreditDebitNote = "CRDLINES";

               /// <summary>
               /// Property for CreditDebitNoteTotEstWeight
               /// </summary>
               public const string CreditDebitNoteTotEstWeight = "CRDWEIGHT";

               /// <summary>
               /// Property for NextDetailNumber
               /// </summary>
               public const string NextDetailNumber = "NEXTDTLNUM";

               /// <summary>
               /// Property for CreditDebitNoteStatus
               /// </summary>
               public const string CreditDebitNoteStatus = "CRDSTATUS";

               /// <summary>
               /// Property for CreditDebitNotePrinted
               /// </summary>
               public const string CreditDebitNotePrinted = "CRDPRINTED";

               /// <summary>
               /// Property for CNDNDiscountonMiscCharges
               /// </summary>
               public const string CnDnDiscountonMiscCharges = "CDISONMISC";

               /// <summary>
               /// Property for POSTDATE
               /// </summary>
               public const string PostDate = "POSTDATE";

               /// <summary>
               /// Property for CompletionDate
               /// </summary>
               public const string CompletionDate = "COMPDATE";

               /// <summary>
               /// Property for CreditDebitNoteTotBeforeTax
               /// </summary>
               public const string CreditDebitNoteTotBeforeTax = "CRDNETNOTX";

               /// <summary>
               /// Property for CNDNIncludedTaxTotalAmt
               /// </summary>
               public const string CnDnIncludedTaxTotalAmt = "CRDITAXTOT";

               /// <summary>
               /// Property for CreditDebitNoteItemTotalAmt
               /// </summary>
               public const string CreditDebitNoteItemTotalAmt = "CRDITMTOT";

               /// <summary>
               /// Property for CreditDebitNoteDiscountBase
               /// </summary>
               public const string CreditDebitNoteDiscountBase = "CRDDISCBAS";

               /// <summary>
               /// Property for CreditDebitNoteDiscountPerce
               /// </summary>
               public const string CreditDebitNoteDiscountPerce = "CRDDISCPER";

               /// <summary>
               /// Property for CreditDebitNoteDiscountAmt
               /// </summary>
               public const string CreditDebitNoteDiscountAmt = "CRDDISCAMT";

               /// <summary>
               /// Property for CNDNTotalMiscCharges
               /// </summary>
               public const string CnDnTotalMiscCharges = "CRDMISC";

               /// <summary>
               /// Property for CreditDebitNoteSubtotalAmt
               /// </summary>
               public const string CreditDebitNoteSubtotalAmt = "CRDSUBTOT";

               /// <summary>
               /// Property for CNDNTotalWithCNDiscount
               /// </summary>
               public const string CnDnTotalWithCnDiscount = "CRDNET";

               /// <summary>
               /// Property for CNDNExcludedTaxTotalAmount
               /// </summary>
               public const string CnDnExcludedTaxTotalAmount = "CRDETAXTOT";

               /// <summary>
               /// Property for CreditDebitNoteTotal
               /// </summary>
               public const string CreditDebitNoteTotal = "CRDNETWTX";

               /// <summary>
               /// Property for CreditDebitNoteHomeCurrency
               /// </summary>
               public const string CreditDebitNoteHomeCurrency = "CRHOMECURR";

               /// <summary>
               /// Property for CreditDebitNoteRateType
               /// </summary>
               public const string CreditDebitNoteRateType = "CRRATETYPE";

               /// <summary>
               /// Property for CreditDebitNoteSourceCurr
               /// </summary>
               public const string CreditDebitNoteSourceCurr = "CRSOURCURR";

               /// <summary>
               /// Property for CreditDebitNoteRateDate
               /// </summary>
               public const string CreditDebitNoteRateDate = "CRRATEDATE";

               /// <summary>
               /// Property for CreditDebitNoteRate
               /// </summary>
               public const string CreditDebitNoteRate = "CRRATE";

               /// <summary>
               /// Property for CreditDebitNoteSpread
               /// </summary>
               public const string CreditDebitNoteSpread = "CRSPREAD";

               /// <summary>
               /// Property for CNDNRateDateMatching
               /// </summary>
               public const string CnDnRateDateMatching = "CRDATEMTCH";

               /// <summary>
               /// Property for CreditDebitNoteRateOperator
               /// </summary>
               public const string CreditDebitNoteRateOperator = "CRRATEREP";

               /// <summary>
               /// Property for CNDNRateOverrideFlag
               /// </summary>
               public const string CnDnRateOverrideFlag = "CRRATEOVER";

               /// <summary>
               /// Property for Salesperson1
               /// </summary>
               public const string Salesperson1 = "SALESPER1";

               /// <summary>
               /// Property for Salesperson2
               /// </summary>
               public const string Salesperson2 = "SALESPER2";

               /// <summary>
               /// Property for Salesperson3
               /// </summary>
               public const string Salesperson3 = "SALESPER3";

               /// <summary>
               /// Property for Salesperson4
               /// </summary>
               public const string Salesperson4 = "SALESPER4";

               /// <summary>
               /// Property for Salesperson5
               /// </summary>
               public const string Salesperson5 = "SALESPER5";

               /// <summary>
               /// Property for SalesPercentage1
               /// </summary>
               public const string SalesPercentage1 = "SALESPLT1";

               /// <summary>
               /// Property for SalesPercentage2
               /// </summary>
               public const string SalesPercentage2 = "SALESPLT2";

               /// <summary>
               /// Property for SalesPercentage3
               /// </summary>
               public const string SalesPercentage3 = "SALESPLT3";

               /// <summary>
               /// Property for SalesPercentage4
               /// </summary>
               public const string SalesPercentage4 = "SALESPLT4";

               /// <summary>
               /// Property for SalesPercentage5
               /// </summary>
               public const string SalesPercentage5 = "SALESPLT5";

               /// <summary>
               /// Property for RecalculateTax
               /// </summary>
               public const string RecalculateTax = "RECALCTAX";

               /// <summary>
               /// Property for TaxOverridden
               /// </summary>
               public const string TaxOverridden = "TAXOVERRD";

               /// <summary>
               /// Property for TaxGroup
               /// </summary>
               public const string TaxGroup = "TAXGROUP";

               /// <summary>
               /// Property for TaxAuthority1
               /// </summary>
               public const string TaxAuthority1 = "TAUTH1";

               /// <summary>
               /// Property for TaxAuthority2
               /// </summary>
               public const string TaxAuthority2 = "TAUTH2";

               /// <summary>
               /// Property for TaxAuthority3
               /// </summary>
               public const string TaxAuthority3 = "TAUTH3";

               /// <summary>
               /// Property for TaxAuthority4
               /// </summary>
               public const string TaxAuthority4 = "TAUTH4";

               /// <summary>
               /// Property for TaxAuthority5
               /// </summary>
               public const string TaxAuthority5 = "TAUTH5";

               /// <summary>
               /// Property for TaxClass1
               /// </summary>
               public const string TaxClass1 = "TCLASS1";

               /// <summary>
               /// Property for TaxClass2
               /// </summary>
               public const string TaxClass2 = "TCLASS2";

               /// <summary>
               /// Property for TaxClass3
               /// </summary>
               public const string TaxClass3 = "TCLASS3";

               /// <summary>
               /// Property for TaxClass4
               /// </summary>
               public const string TaxClass4 = "TCLASS4";

               /// <summary>
               /// Property for TaxClass5
               /// </summary>
               public const string TaxClass5 = "TCLASS5";

               /// <summary>
               /// Property for TaxBase1
               /// </summary>
               public const string TaxBase1 = "TBASE1";

               /// <summary>
               /// Property for TaxBase2
               /// </summary>
               public const string TaxBase2 = "TBASE2";

               /// <summary>
               /// Property for TaxBase3
               /// </summary>
               public const string TaxBase3 = "TBASE3";

               /// <summary>
               /// Property for TaxBase4
               /// </summary>
               public const string TaxBase4 = "TBASE4";

               /// <summary>
               /// Property for TaxBase5
               /// </summary>
               public const string TaxBase5 = "TBASE5";

               /// <summary>
               /// Property for ExcludedTaxAmount1
               /// </summary>
               public const string ExcludedTaxAmount1 = "TEAMOUNT1";

               /// <summary>
               /// Property for ExcludedTaxAmount2
               /// </summary>
               public const string ExcludedTaxAmount2 = "TEAMOUNT2";

               /// <summary>
               /// Property for ExcludedTaxAmount3
               /// </summary>
               public const string ExcludedTaxAmount3 = "TEAMOUNT3";

               /// <summary>
               /// Property for ExcludedTaxAmount4
               /// </summary>
               public const string ExcludedTaxAmount4 = "TEAMOUNT4";

               /// <summary>
               /// Property for ExcludedTaxAmount5
               /// </summary>
               public const string ExcludedTaxAmount5 = "TEAMOUNT5";

               /// <summary>
               /// Property for IncludedTaxAmount1
               /// </summary>
               public const string IncludedTaxAmount1 = "TIAMOUNT1";

               /// <summary>
               /// Property for IncludedTaxAmount2
               /// </summary>
               public const string IncludedTaxAmount2 = "TIAMOUNT2";

               /// <summary>
               /// Property for IncludedTaxAmount3
               /// </summary>
               public const string IncludedTaxAmount3 = "TIAMOUNT3";

               /// <summary>
               /// Property for IncludedTaxAmount4
               /// </summary>
               public const string IncludedTaxAmount4 = "TIAMOUNT4";

               /// <summary>
               /// Property for IncludedTaxAmount5
               /// </summary>
               public const string IncludedTaxAmount5 = "TIAMOUNT5";

               /// <summary>
               /// Property for Registration1
               /// </summary>
               public const string Registration1 = "TEXEMPT1";

               /// <summary>
               /// Property for Registration2
               /// </summary>
               public const string Registration2 = "TEXEMPT2";

               /// <summary>
               /// Property for Registration3
               /// </summary>
               public const string Registration3 = "TEXEMPT3";

               /// <summary>
               /// Property for Registration4
               /// </summary>
               public const string Registration4 = "TEXEMPT4";

               /// <summary>
               /// Property for Registration5
               /// </summary>
               public const string Registration5 = "TEXEMPT5";

               /// <summary>
               /// Property for PriceListCodeDescription
               /// </summary>
               public const string PriceListCodeDescription = "PCODDESC";

               /// <summary>
               /// Property for TermsCodeDescription
               /// </summary>
               public const string TermsCodeDescription = "TERMDESC";

               /// <summary>
               /// Property for TaxGroupCodeDescription
               /// </summary>
               public const string TaxGroupCodeDescription = "TXGRPDESC";

               /// <summary>
               /// Property for LocationCodeDescription
               /// </summary>
               public const string LocationCodeDescription = "LOCDESC";

               /// <summary>
               /// Property for SalespersonName1
               /// </summary>
               public const string SalespersonName1 = "SALES1NAME";

               /// <summary>
               /// Property for SalespersonName2
               /// </summary>
               public const string SalespersonName2 = "SALES2NAME";

               /// <summary>
               /// Property for SalespersonName3
               /// </summary>
               public const string SalespersonName3 = "SALES3NAME";

               /// <summary>
               /// Property for SalespersonName4
               /// </summary>
               public const string SalespersonName4 = "SALES4NAME";

               /// <summary>
               /// Property for SalespersonName5
               /// </summary>
               public const string SalespersonName5 = "SALES5NAME";

               /// <summary>
               /// Property for TaxAuthority1Description
               /// </summary>
               public const string TaxAuthority1Description = "TAUTH1DESC";

               /// <summary>
               /// Property for TaxAuthority2Description
               /// </summary>
               public const string TaxAuthority2Description = "TAUTH2DESC";

               /// <summary>
               /// Property for TaxAuthority3Description
               /// </summary>
               public const string TaxAuthority3Description = "TAUTH3DESC";

               /// <summary>
               /// Property for TaxAuthority4Description
               /// </summary>
               public const string TaxAuthority4Description = "TAUTH4DESC";

               /// <summary>
               /// Property for TaxAuthority5Description
               /// </summary>
               public const string TaxAuthority5Description = "TAUTH5DESC";

               /// <summary>
               /// Property for TaxClass1Description
               /// </summary>
               public const string TaxClass1Description = "TCLAS1DESC";

               /// <summary>
               /// Property for TaxClass2Description
               /// </summary>
               public const string TaxClass2Description = "TCLAS2DESC";

               /// <summary>
               /// Property for TaxClass3Description
               /// </summary>
               public const string TaxClass3Description = "TCLAS3DESC";

               /// <summary>
               /// Property for TaxClass4Description
               /// </summary>
               public const string TaxClass4Description = "TCLAS4DESC";

               /// <summary>
               /// Property for TaxClass5Description
               /// </summary>
               public const string TaxClass5Description = "TCLAS5DESC";

               /// <summary>
               /// Property for InvoiceSourceCurrencyDesc
               /// </summary>
               public const string InvoiceSourceCurrencyDesc = "INSRCDESC";

               /// <summary>
               /// Property for InvoiceHomeCurrencyDesc
               /// </summary>
               public const string InvoiceHomeCurrencyDesc = "INHOMDESC";

               /// <summary>
               /// Property for InvoiceRateTypeDescription
               /// </summary>
               public const string InvoiceRateTypeDescription = "INRTTYDESC";

               /// <summary>
               /// Property for CNDNSourceCurrencyDesc
               /// </summary>
               public const string CnDnSourceCurrencyDesc = "CRSRCDESC";

               /// <summary>
               /// Property for CNDNHomeCurrencyDescription
               /// </summary>
               public const string CnDnHomeCurrencyDescription = "CRHOMDESC";

               /// <summary>
               /// Property for CreditDebitNoteRateTypeDesc
               /// </summary>
               public const string CreditDebitNoteRateTypeDesc = "CRRTTYDESC";

               /// <summary>
               /// Property for CreditDebitNoteRunningTotal
               /// </summary>
               public const string CreditDebitNoteRunningTotal = "RUNNINGTOT";

               /// <summary>
               /// Property for TotalTaxAmount1
               /// </summary>
               public const string TotalTaxAmount1 = "TAMOUNT1";

               /// <summary>
               /// Property for TotalTaxAmount2
               /// </summary>
               public const string TotalTaxAmount2 = "TAMOUNT2";

               /// <summary>
               /// Property for TotalTaxAmount3
               /// </summary>
               public const string TotalTaxAmount3 = "TAMOUNT3";

               /// <summary>
               /// Property for TotalTaxAmount4
               /// </summary>
               public const string TotalTaxAmount4 = "TAMOUNT4";

               /// <summary>
               /// Property for TotalTaxAmount5
               /// </summary>
               public const string TotalTaxAmount5 = "TAMOUNT5";

               /// <summary>
               /// Property for TotalTaxAmount
               /// </summary>
               public const string TotalTaxAmount = "CRDTAXTOT";

               /// <summary>
               /// Property for PerformTaxCalculation
               /// </summary>
               public const string PerformTaxCalculation = "GOCALCTAX";

               /// <summary>
               /// Property for PerformForcedTaxCalculation
               /// </summary>
               public const string PerformForcedTaxCalculation = "GOFCALCTAX";

               /// <summary>
               /// Property for PerformDistributionOfManTax
               /// </summary>
               public const string PerformDistributionOfManTax = "GODISTTAX";

               /// <summary>
               /// Property for TaxCalculationInProgress
               /// </summary>
               public const string TaxCalculationInProgress = "TXCALCINPG";

               /// <summary>
               /// Property for AutoTaxCalculationStatus
               /// </summary>
               public const string AutoTaxCalculationStatus = "AUTOTAXCAL";

               /// <summary>
               /// Property for CustomerExists
               /// </summary>
               public const string CustomerExists = "CUSTEXIST";

               /// <summary>
               /// Property for InvoiceExists
               /// </summary>
               public const string InvoiceExists = "INVEXIST";

               /// <summary>
               /// Property for BillToEmail
               /// </summary>
               public const string BillToEmail = "BILEMAIL";

               /// <summary>
               /// Property for BillToContactPhone
               /// </summary>
               public const string BillToContactPhone = "BILPHONEC";

               /// <summary>
               /// Property for BillToContactFax
               /// </summary>
               public const string BillToContactFax = "BILFAXC";

               /// <summary>
               /// Property for BillToContactEmail
               /// </summary>
               public const string BillToContactEmail = "BILEMAILC";

               /// <summary>
               /// Property for Type
               /// </summary>
               public const string Type = "ADJTYPE";

               /// <summary>
               /// Property for ShipmentTrackingNumber
               /// </summary>
               public const string ShipmentTrackingNumber = "SHIPTRACK";

               /// <summary>
               /// Property for ShipViaCode
               /// </summary>
               public const string ShipViaCode = "SHIPVIA";

               /// <summary>
               /// Property for ShipViaCodeDescription
               /// </summary>
               public const string ShipViaCodeDescription = "VIADESC";

               /// <summary>
               /// Property for PostSequenceNumber
               /// </summary>
               public const string PostSequenceNumber = "POSTSEQNUM";

               /// <summary>
               /// Property for ShipToLocationCode
               /// </summary>
               public const string ShipToLocationCode = "SHIPTO";

               /// <summary>
               /// Property for ShipToName
               /// </summary>
               public const string ShipToName = "SHPNAME";

               /// <summary>
               /// Property for ShipToAddressLine1
               /// </summary>
               public const string ShipToAddressLine1 = "SHPADDR1";

               /// <summary>
               /// Property for ShipToAddressLine2
               /// </summary>
               public const string ShipToAddressLine2 = "SHPADDR2";

               /// <summary>
               /// Property for ShipToAddressLine3
               /// </summary>
               public const string ShipToAddressLine3 = "SHPADDR3";

               /// <summary>
               /// Property for ShipToAddressLine4
               /// </summary>
               public const string ShipToAddressLine4 = "SHPADDR4";

               /// <summary>
               /// Property for ShipToCity
               /// </summary>
               public const string ShipToCity = "SHPCITY";

               /// <summary>
               /// Property for ShipToStateProvince
               /// </summary>
               public const string ShipToStateProvince = "SHPSTATE";

               /// <summary>
               /// Property for ShipToZipPostalCode
               /// </summary>
               public const string ShipToZipPostalCode = "SHPZIP";

               /// <summary>
               /// Property for ShipToCountry
               /// </summary>
               public const string ShipToCountry = "SHPCOUNTRY";

               /// <summary>
               /// Property for ShipToPhoneNumber
               /// </summary>
               public const string ShipToPhoneNumber = "SHPPHONE";

               /// <summary>
               /// Property for ShipToFaxNumber
               /// </summary>
               public const string ShipToFaxNumber = "SHPFAX";

               /// <summary>
               /// Property for ShipToContact
               /// </summary>
               public const string ShipToContact = "SHPCONTACT";

               /// <summary>
               /// Property for ShipToEmail
               /// </summary>
               public const string ShipToEmail = "SHPEMAIL";

               /// <summary>
               /// Property for ShipToContactPhone
               /// </summary>
               public const string ShipToContactPhone = "SHPPHONEC";

               /// <summary>
               /// Property for ShipToContactFax
               /// </summary>
               public const string ShipToContactFax = "SHPFAXC";

               /// <summary>
               /// Property for ShipToContactEmail
               /// </summary>
               public const string ShipToContactEmail = "SHPEMAILC";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for InvoiceUniquifier
               /// </summary>
               public const string InvoiceUniquifier = "INVUNIQ";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for PROCESSCMD
               /// </summary>
               public const string ProcessCommand = "PROCESSCMD";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for OECOMMAND
               /// </summary>
               public const string OeCommand = "OECOMMAND";

               /// <summary>
               /// Property for OverCreditLimit
               /// </summary>
               public const string OverCreditLimit = "OVERCREDIT";

               /// <summary>
               /// Property for ApprovedLimit
               /// </summary>
               public const string ApprovedLimit = "APPROVELMT";

               /// <summary>
               /// Property for AuthorizingUserID
               /// </summary>
               public const string AuthorizingUserID = "APPROVEBY";

               /// <summary>
               /// Property for AuthorizingUserPassword
               /// </summary>
               public const string AuthorizingUserPassword = "APPPASSWRD";

               /// <summary>
               /// Property for UserEnteredApprovalAmount
               /// </summary>
               public const string UserEnteredApprovalAmount = "EDAPRVLMT";

               /// <summary>
               /// Property for CheckingCustomerCreditLimit
               /// </summary>
               public const string CheckingCustomerCreditLimit = "SWCHKLIMC";

               /// <summary>
               /// Property for CheckingCustomerAgingLimit
               /// </summary>
               public const string CheckingCustomerAgingLimit = "SWCHKODUEC";

               /// <summary>
               /// Property for CheckingNatAcctCreditLimit
               /// </summary>
               public const string CheckingNatAcctCreditLimit = "SWCHKLIMA";

               /// <summary>
               /// Property for CheckingNatAcctAgingLimit
               /// </summary>
               public const string CheckingNatAcctAgingLimit = "SWCHKODUEA";

               /// <summary>
               /// Property for CustomerIsOverCreditLimit
               /// </summary>
               public const string CustomerIsOverCreditLimit = "SWOVERLIMC";

               /// <summary>
               /// Property for CustomerIsOverAgingLimit
               /// </summary>
               public const string CustomerIsOverAgingLimit = "SWOVERDUEC";

               /// <summary>
               /// Property for NatAcctIsOverCreditLimit
               /// </summary>
               public const string NatAcctIsOverCreditLimit = "SWOVERLIMA";

               /// <summary>
               /// Property for NatAcctIsOverAgingLimit
               /// </summary>
               public const string NatAcctIsOverAgingLimit = "SWOVERDUEA";

               /// <summary>
               /// Property for CustomerCreditLimit
               /// </summary>
               public const string CustomerCreditLimit = "AMTLIMITC";

               /// <summary>
               /// Property for CustomerBalancePosted
               /// </summary>
               public const string CustomerBalancePosted = "AMTBALCUST";

               /// <summary>
               /// Property for CustomerDaysOverdue
               /// </summary>
               public const string CustomerDaysOverdue = "OVDUEDAYSC";

               /// <summary>
               /// Property for CustomerOverdueLimit
               /// </summary>
               public const string CustomerOverdueLimit = "OVDUELMTC";

               /// <summary>
               /// Property for CustomerBalanceOverdue
               /// </summary>
               public const string CustomerBalanceOverdue = "OVDUEBALC";

               /// <summary>
               /// Property for NatAcctCreditLimit
               /// </summary>
               public const string NatAcctCreditLimit = "AMTLIMITA";

               /// <summary>
               /// Property for NatAcctBalance
               /// </summary>
               public const string NatAcctBalance = "AMTBALACCT";

               /// <summary>
               /// Property for NatAcctDaysOverdue
               /// </summary>
               public const string NatAcctDaysOverdue = "OVDUEDAYSA";

               /// <summary>
               /// Property for NatAcctOverdueLimit
               /// </summary>
               public const string NatAcctOverdueLimit = "OVDUELMTA";

               /// <summary>
               /// Property for NatAcctBalanceOverdue
               /// </summary>
               public const string NatAcctBalanceOverdue = "OVDUEBALA";

               /// <summary>
               /// Property for ARPendingTransIncluded
               /// </summary>
               public const string ARPendingTransIncluded = "SWARPEND";

               /// <summary>
               /// Property for OEPendingTransIncluded
               /// </summary>
               public const string OEPendingTransIncluded = "SWOEPEND";

               /// <summary>
               /// Property for OtherPendingTransIncluded
               /// </summary>
               public const string OtherPendingTransIncluded = "SWXXPEND";

               /// <summary>
               /// Property for ARPendingBalance
               /// </summary>
               public const string ARPendingBalance = "AMTARPEND";

               /// <summary>
               /// Property for OEPendingBalance
               /// </summary>
               public const string OEPendingBalance = "AMTOEPEND";

               /// <summary>
               /// Property for OtherPendingBalance
               /// </summary>
               public const string OtherPendingBalance = "AMTXXPEND";

               /// <summary>
               /// Property for CustomerTotalOutstanding
               /// </summary>
               public const string CustomerTotalOutstanding = "AMTTOTCUST";

               /// <summary>
               /// Property for NatAcctTotalOutstanding
               /// </summary>
               public const string NatAcctTotalOutstanding = "AMTTOTACCT";

               /// <summary>
               /// Property for CustomerLimitLeft
               /// </summary>
               public const string CustomerLimitLeft = "AMTLEFTC";

               /// <summary>
               /// Property for NatAcctLimitLeft
               /// </summary>
               public const string NatAcctLimitLeft = "AMTLEFTA";

               /// <summary>
               /// Property for CustomerLimitExceeded
               /// </summary>
               public const string CustomerLimitExceeded = "AMTOVERC";

               /// <summary>
               /// Property for NatAcctLimitExceeded
               /// </summary>
               public const string NatAcctLimitExceeded = "AMTOVERA";

               /// <summary>
               /// Property for LastInvoiceAmount
               /// </summary>
               public const string LastInvoiceAmount = "AMTLASTIVT";

               /// <summary>
               /// Property for LastInvoiceDate
               /// </summary>
               public const string LastInvoiceDate = "DATELASTIV";

               /// <summary>
               /// Property for LastPaymentAmount
               /// </summary>
               public const string LastPaymentAmount = "AMTLASTPYT";

               /// <summary>
               /// Property for LastPaymentDate
               /// </summary>
               public const string LastPaymentDate = "DATELASTPA";

               /// <summary>
               /// Property for DrivenbyUI
               /// </summary>
               public const string DrivenbyUI = "DRIVENBYUI";

               /// <summary>
               /// Property for ItemDetailDiscountTotal
               /// </summary>
               public const string ItemDetailDiscountTotal = "ITEMDISTOT";

               /// <summary>
               /// Property for MiscChargeDetailDiscountTot
               /// </summary>
               public const string MiscChargeDetailDiscountTot = "MISCDISTOT";

               /// <summary>
               /// Property for DetailDiscountTotal
               /// </summary>
               public const string DetailDiscountTotal = "DTLDISCTOT";

               /// <summary>
               /// Property for DetailDiscountPercentage
               /// </summary>
               public const string DetailDiscountPercentage = "DTLDISCPER";

               /// <summary>
               /// Property for DocumentNetOfDetailDisc
               /// </summary>
               public const string DocumentNetOfDetailDisc = "CRDNTDTDIS";

               /// <summary>
               /// Property for AutoCalcTaxReportingAmounts
               /// </summary>
               public const string AutoCalcTaxReportingAmounts = "CTRMETHOD";

               /// <summary>
               /// Property for TaxReportingTRCurrency
               /// </summary>
               public const string TaxReportingTrCurrency = "CTRCURRNCY";

               /// <summary>
               /// Property for TRRateType
               /// </summary>
               public const string TrRateType = "CTRRATTYPE";

               /// <summary>
               /// Property for TRRateDate
               /// </summary>
               public const string TrRateDate = "CTRRATDATE";

               /// <summary>
               /// Property for TRRate
               /// </summary>
               public const string TrRate = "CTRRATE";

               /// <summary>
               /// Property for TRSpread
               /// </summary>
               public const string TrSpread = "CTRSPREAD";

               /// <summary>
               /// Property for TRRateDateMatching
               /// </summary>
               public const string TrRateDateMatching = "CTRDATMTCH";

               /// <summary>
               /// Property for TRRateOperator
               /// </summary>
               public const string TrRateOperator = "CTRRATEOP";

               /// <summary>
               /// Property for TRRateOverrideFlag
               /// </summary>
               public const string TrRateOverrideFlag = "CTRRATOVER";

               /// <summary>
               /// Property for TRExcludedTaxAmount1
               /// </summary>
               public const string TrExcludedTaxAmount1 = "CTREAMNT1";

               /// <summary>
               /// Property for TRExcludedTaxAmount2
               /// </summary>
               public const string TrExcludedTaxAmount2 = "CTREAMNT2";

               /// <summary>
               /// Property for TRExcludedTaxAmount3
               /// </summary>
               public const string TrExcludedTaxAmount3 = "CTREAMNT3";

               /// <summary>
               /// Property for TRExcludedTaxAmount4
               /// </summary>
               public const string TrExcludedTaxAmount4 = "CTREAMNT4";

               /// <summary>
               /// Property for TRExcludedTaxAmount5
               /// </summary>
               public const string TrExcludedTaxAmount5 = "CTREAMNT5";

               /// <summary>
               /// Property for TRIncludedTaxAmount1
               /// </summary>
               public const string TrIncludedTaxAmount1 = "CTRIAMNT1";

               /// <summary>
               /// Property for TRIncludedTaxAmount2
               /// </summary>
               public const string TrIncludedTaxAmount2 = "CTRIAMNT2";

               /// <summary>
               /// Property for TRIncludedTaxAmount3
               /// </summary>
               public const string TrIncludedTaxAmount3 = "CTRIAMNT3";

               /// <summary>
               /// Property for TRIncludedTaxAmount4
               /// </summary>
               public const string TrIncludedTaxAmount4 = "CTRIAMNT4";

               /// <summary>
               /// Property for TRIncludedTaxAmount5
               /// </summary>
               public const string TrIncludedTaxAmount5 = "CTRIAMNT5";

               /// <summary>
               /// Property for TRTaxAmount1
               /// </summary>
               public const string TrTaxAmount1 = "CTRAMOUNT1";

               /// <summary>
               /// Property for TRTaxAmount2
               /// </summary>
               public const string TrTaxAmount2 = "CTRAMOUNT2";

               /// <summary>
               /// Property for TRTaxAmount3
               /// </summary>
               public const string TrTaxAmount3 = "CTRAMOUNT3";

               /// <summary>
               /// Property for TRTaxAmount4
               /// </summary>
               public const string TrTaxAmount4 = "CTRAMOUNT4";

               /// <summary>
               /// Property for TRTaxAmount5
               /// </summary>
               public const string TrTaxAmount5 = "CTRAMOUNT5";

               /// <summary>
               /// Property for TRExcludedTaxTotal
               /// </summary>
               public const string TrExcludedTaxTotal = "CTRETOTAL";

               /// <summary>
               /// Property for TRIncludedTaxTotal
               /// </summary>
               public const string TrIncludedTaxTotal = "CTRITOTAL";

               /// <summary>
               /// Property for TRTaxTotal
               /// </summary>
               public const string TrTaxTotal = "CTRTOTAL";

               /// <summary>
               /// Property for TaxReportingInvoiceTRCurr
               /// </summary>
               public const string TaxReportingInvoiceTrCurr = "ITRCURRNCY";

               /// <summary>
               /// Property for TRInvoiceRateType
               /// </summary>
               public const string TrInvoiceRateType = "ITRRATTYPE";

               /// <summary>
               /// Property for TRInvoiceRateDate
               /// </summary>
               public const string TrInvoiceRateDate = "ITRRATDATE";

               /// <summary>
               /// Property for TRInvoiceRate
               /// </summary>
               public const string TrInvoiceRate = "ITRRATE";

               /// <summary>
               /// Property for TRInvoiceSpread
               /// </summary>
               public const string TrInvoiceSpread = "ITRSPREAD";

               /// <summary>
               /// Property for TRInvoiceRateDateMatching
               /// </summary>
               public const string TrInvoiceRateDateMatching = "ITRDATMTCH";

               /// <summary>
               /// Property for TRInvoiceRateOperator
               /// </summary>
               public const string TrInvoiceRateOperator = "ITRRATEOP";

               /// <summary>
               /// Property for TRInvoiceRateOverrideFlag
               /// </summary>
               public const string TrInvoiceRateOverrideFlag = "ITRRATOVER";

               /// <summary>
               /// Property for TRCurrencyDescription
               /// </summary>
               public const string TrCurrencyDescription = "CTRCURDESC";

               /// <summary>
               /// Property for TRInvoiceCurrencyDescription
               /// </summary>
               public const string TrInvoiceCurrencyDescription = "ITRCURDESC";

               /// <summary>
               /// Property for TRRateTypeDescription
               /// </summary>
               public const string TrRateTypeDescription = "CTRRTYDESC";

               /// <summary>
               /// Property for TRInvoiceRateTypeDescription
               /// </summary>
               public const string TrInvoiceRateTypeDescription = "ITRRTYDESC";

               /// <summary>
               /// Property for TaxVersion
               /// </summary>
               public const string TaxVersion = "TAXVERSION";

               /// <summary>
               /// Property for CNDNDiscountAmountOverride
               /// </summary>
               public const string CnDnDiscountAmountOverride = "DISAMTOVER";

               /// <summary>
               /// Property for DOSConversion
               /// </summary>
               public const string DosConversion = "DOSCONVERT";

               /// <summary>
               /// Property for FromInvoice
               /// </summary>
               public const string FromInvoice = "FROMINV";

               /// <summary>
               /// Property for JobRelated
               /// </summary>
               public const string JobRelated = "HASJOB";

               /// <summary>
               /// Property for JobRelatedDetailLines
               /// </summary>
               public const string JobRelatedDetailLines = "JOBLINES";

               /// <summary>
               /// Property for HasRetainage
               /// </summary>
               public const string HasRetainage = "HASRTG";

               /// <summary>
               /// Property for RetainageAmount
               /// </summary>
               public const string RetainageAmount = "RTGAMOUNT";

               /// <summary>
               /// Property for RetainagePercent
               /// </summary>
               public const string RetainagePercent = "RTGPERCENT";

               /// <summary>
               /// Property for RetainageExchangeRate
               /// </summary>
               public const string RetainageExchangeRate = "RTGRATE";

               /// <summary>
               /// Property for RetainageTaxBase1
               /// </summary>
               public const string RetainageTaxBase1 = "RTGTXBASE1";

               /// <summary>
               /// Property for RetainageTaxBase2
               /// </summary>
               public const string RetainageTaxBase2 = "RTGTXBASE2";

               /// <summary>
               /// Property for RetainageTaxBase3
               /// </summary>
               public const string RetainageTaxBase3 = "RTGTXBASE3";

               /// <summary>
               /// Property for RetainageTaxBase4
               /// </summary>
               public const string RetainageTaxBase4 = "RTGTXBASE4";

               /// <summary>
               /// Property for RetainageTaxBase5
               /// </summary>
               public const string RetainageTaxBase5 = "RTGTXBASE5";

               /// <summary>
               /// Property for RetainageTaxAmount1
               /// </summary>
               public const string RetainageTaxAmount1 = "RTGTXAMT1";

               /// <summary>
               /// Property for RetainageTaxAmount2
               /// </summary>
               public const string RetainageTaxAmount2 = "RTGTXAMT2";

               /// <summary>
               /// Property for RetainageTaxAmount3
               /// </summary>
               public const string RetainageTaxAmount3 = "RTGTXAMT3";

               /// <summary>
               /// Property for RetainageTaxAmount4
               /// </summary>
               public const string RetainageTaxAmount4 = "RTGTXAMT4";

               /// <summary>
               /// Property for RetainageTaxAmount5
               /// </summary>
               public const string RetainageTaxAmount5 = "RTGTXAMT5";

               /// <summary>
               /// Property for CustomerAccountSet
               /// </summary>
               public const string CustomerAccountSet = "CUSACCTSET";

               /// <summary>
               /// Property for CustomerAccountSetDescription
               /// </summary>
               public const string CustomerAccountSetDescription = "CUSACTDESC";

               /// <summary>
               /// Property for EnteredBy
               /// </summary>
               public const string EnteredBy = "ENTEREDBY";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for DATEBUS
               /// </summary>
               public const string DateBus = "DATEBUS";

               /// <summary>
               /// Property for CreditDebitNoteAmountDue
               /// </summary>
               public const string CreditDebitNoteAmountDue = "CRDAMTDUE";

               /// <summary>
               /// Property for TotalRetainageTaxAmount
               /// </summary>
               public const string TotalRetainageTaxAmount = "RTXAMTTOT";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitNote Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CNUniquifier
               /// </summary>
               public const int CnUniquifier = 1;

               /// <summary>
               /// Property Indexer for OrderNumber
               /// </summary>
               public const int OrderNumber = 2;

               /// <summary>
               /// Property Indexer for InvoiceNumber
               /// </summary>
               public const int InvoiceNumber = 3;

               /// <summary>
               /// Property Indexer for CreditDebitNoteNumber
               /// </summary>
               public const int CreditDebitNoteNumber = 4;

               /// <summary>
               /// Property Indexer for ICDayEndTransNumber
               /// </summary>
               public const int ICDayEndTransNumber = 5;

               /// <summary>
               /// Property Indexer for CustomerNumber
               /// </summary>
               public const int CustomerNumber = 6;

               /// <summary>
               /// Property Indexer for BillTo
               /// </summary>
               public const int BillTo = 7;

               /// <summary>
               /// Property Indexer for BillToAddress1
               /// </summary>
               public const int BillToAddress1 = 8;

               /// <summary>
               /// Property Indexer for BillToAddress2
               /// </summary>
               public const int BillToAddress2 = 9;

               /// <summary>
               /// Property Indexer for BillToAddress3
               /// </summary>
               public const int BillToAddress3 = 10;

               /// <summary>
               /// Property Indexer for BillToAddress4
               /// </summary>
               public const int BillToAddress4 = 11;

               /// <summary>
               /// Property Indexer for BillToCity
               /// </summary>
               public const int BillToCity = 12;

               /// <summary>
               /// Property Indexer for BillToState
               /// </summary>
               public const int BillToState = 13;

               /// <summary>
               /// Property Indexer for BillToZipCode
               /// </summary>
               public const int BillToZipCode = 14;

               /// <summary>
               /// Property Indexer for BillToCountry
               /// </summary>
               public const int BillToCountry = 15;

               /// <summary>
               /// Property Indexer for BillToPhone
               /// </summary>
               public const int BillToPhone = 16;

               /// <summary>
               /// Property Indexer for BillToFax
               /// </summary>
               public const int BillToFax = 17;

               /// <summary>
               /// Property Indexer for BillToContact
               /// </summary>
               public const int BillToContact = 18;

               /// <summary>
               /// Property Indexer for CustomerDiscountLevel
               /// </summary>
               public const int CustomerDiscountLevel = 19;

               /// <summary>
               /// Property Indexer for DefaultPriceListCode
               /// </summary>
               public const int DefaultPriceListCode = 20;

               /// <summary>
               /// Property Indexer for PurchaseOrderNumber
               /// </summary>
               public const int PurchaseOrderNumber = 21;

               /// <summary>
               /// Property Indexer for Territory
               /// </summary>
               public const int Territory = 22;

               /// <summary>
               /// Property Indexer for Reference
               /// </summary>
               public const int Reference = 23;

               /// <summary>
               /// Property Indexer for OrderDate
               /// </summary>
               public const int OrderDate = 24;

               /// <summary>
               /// Property Indexer for FreeOnBoardPoint
               /// </summary>
               public const int FreeOnBoardPoint = 25;

               /// <summary>
               /// Property Indexer for TemplateCode
               /// </summary>
               public const int TemplateCode = 26;

               /// <summary>
               /// Property Indexer for DefaultLocationCode
               /// </summary>
               public const int DefaultLocationCode = 27;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 28;

               /// <summary>
               /// Property Indexer for Comment
               /// </summary>
               public const int Comment = 29;

               /// <summary>
               /// Property Indexer for ShipmentDate
               /// </summary>
               public const int ShipmentDate = 30;

               /// <summary>
               /// Property Indexer for InvoiceDate
               /// </summary>
               public const int InvoiceDate = 31;

               /// <summary>
               /// Property Indexer for InvoiceFiscalYear
               /// </summary>
               public const int InvoiceFiscalYear = 32;

               /// <summary>
               /// Property Indexer for InvoiceFiscalPeriod
               /// </summary>
               public const int InvoiceFiscalPeriod = 33;

               /// <summary>
               /// Property Indexer for InvoiceHomeCurrency
               /// </summary>
               public const int InvoiceHomeCurrency = 34;

               /// <summary>
               /// Property Indexer for InvoiceRateType
               /// </summary>
               public const int InvoiceRateType = 35;

               /// <summary>
               /// Property Indexer for InvoiceSourceCurrency
               /// </summary>
               public const int InvoiceSourceCurrency = 36;

               /// <summary>
               /// Property Indexer for InvoiceRateDate
               /// </summary>
               public const int InvoiceRateDate = 37;

               /// <summary>
               /// Property Indexer for InvoiceRate
               /// </summary>
               public const int InvoiceRate = 38;

               /// <summary>
               /// Property Indexer for InvoiceSpread
               /// </summary>
               public const int InvoiceSpread = 39;

               /// <summary>
               /// Property Indexer for InvoiceRateDateMatching
               /// </summary>
               public const int InvoiceRateDateMatching = 40;

               /// <summary>
               /// Property Indexer for InvoiceRateOperator
               /// </summary>
               public const int InvoiceRateOperator = 41;

               /// <summary>
               /// Property Indexer for InvoiceRateOverrideFlag
               /// </summary>
               public const int InvoiceRateOverrideFlag = 42;

               /// <summary>
               /// Property Indexer for CRItemSubtotal
               /// </summary>
               public const int CRItemSubtotal = 43;

               /// <summary>
               /// Property Indexer for CRMiscChargesSubtotal
               /// </summary>
               public const int CRMiscChargesSubtotal = 44;

               /// <summary>
               /// Property Indexer for ReturnDate
               /// </summary>
               public const int ReturnDate = 45;

               /// <summary>
               /// Property Indexer for CreditDebitNoteDate
               /// </summary>
               public const int CreditDebitNoteDate = 46;

               /// <summary>
               /// Property Indexer for CreditDebitNoteFiscalYear
               /// </summary>
               public const int CreditDebitNoteFiscalYear = 47;

               /// <summary>
               /// Property Indexer for CreditDebitNoteFiscalPeriod
               /// </summary>
               public const int CreditDebitNoteFiscalPeriod = 48;

               /// <summary>
               /// Property Indexer for NoOfLinesInCreditDebitNote
               /// </summary>
               public const int NoOfLinesInCreditDebitNote = 49;

               /// <summary>
               /// Property Indexer for CreditDebitNoteTotEstWeight
               /// </summary>
               public const int CreditDebitNoteTotEstWeight = 50;

               /// <summary>
               /// Property Indexer for NextDetailNumber
               /// </summary>
               public const int NextDetailNumber = 51;

               /// <summary>
               /// Property Indexer for CreditDebitNoteStatus
               /// </summary>
               public const int CreditDebitNoteStatus = 52;

               /// <summary>
               /// Property Indexer for CreditDebitNotePrinted
               /// </summary>
               public const int CreditDebitNotePrinted = 53;

               /// <summary>
               /// Property Indexer for CNDNDiscountonMiscCharges
               /// </summary>
               public const int CnDnDiscountonMiscCharges = 54;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for POSTDATE
               /// </summary>
               public const int PostDate = 55;

               /// <summary>
               /// Property Indexer for CompletionDate
               /// </summary>
               public const int CompletionDate = 56;

               /// <summary>
               /// Property Indexer for CreditDebitNoteTotBeforeTax
               /// </summary>
               public const int CreditDebitNoteTotBeforeTax = 57;

               /// <summary>
               /// Property Indexer for CNDNIncludedTaxTotalAmt
               /// </summary>
               public const int CnDnIncludedTaxTotalAmt = 58;

               /// <summary>
               /// Property Indexer for CreditDebitNoteItemTotalAmt
               /// </summary>
               public const int CreditDebitNoteItemTotalAmt = 59;

               /// <summary>
               /// Property Indexer for CreditDebitNoteDiscountBase
               /// </summary>
               public const int CreditDebitNoteDiscountBase = 60;

               /// <summary>
               /// Property Indexer for CreditDebitNoteDiscountPerce
               /// </summary>
               public const int CreditDebitNoteDiscountPerce = 61;

               /// <summary>
               /// Property Indexer for CreditDebitNoteDiscountAmt
               /// </summary>
               public const int CreditDebitNoteDiscountAmt = 62;

               /// <summary>
               /// Property Indexer for CNDNTotalMiscCharges
               /// </summary>
               public const int CnDnTotalMiscCharges = 63;

               /// <summary>
               /// Property Indexer for CreditDebitNoteSubtotalAmt
               /// </summary>
               public const int CreditDebitNoteSubtotalAmt = 64;

               /// <summary>
               /// Property Indexer for CNDNTotalWithCNDiscount
               /// </summary>
               public const int CnDnTotalWithCnDiscount = 65;

               /// <summary>
               /// Property Indexer for CNDNExcludedTaxTotalAmount
               /// </summary>
               public const int CnDnExcludedTaxTotalAmount = 66;

               /// <summary>
               /// Property Indexer for CreditDebitNoteTotal
               /// </summary>
               public const int CreditDebitNoteTotal = 67;

               /// <summary>
               /// Property Indexer for CreditDebitNoteHomeCurrency
               /// </summary>
               public const int CreditDebitNoteHomeCurrency = 68;

               /// <summary>
               /// Property Indexer for CreditDebitNoteRateType
               /// </summary>
               public const int CreditDebitNoteRateType = 69;

               /// <summary>
               /// Property Indexer for CreditDebitNoteSourceCurr
               /// </summary>
               public const int CreditDebitNoteSourceCurr = 70;

               /// <summary>
               /// Property Indexer for CreditDebitNoteRateDate
               /// </summary>
               public const int CreditDebitNoteRateDate = 71;

               /// <summary>
               /// Property Indexer for CreditDebitNoteRate
               /// </summary>
               public const int CreditDebitNoteRate = 72;

               /// <summary>
               /// Property Indexer for CreditDebitNoteSpread
               /// </summary>
               public const int CreditDebitNoteSpread = 73;

               /// <summary>
               /// Property Indexer for CNDNRateDateMatching
               /// </summary>
               public const int CnDnRateDateMatching = 74;

               /// <summary>
               /// Property Indexer for CreditDebitNoteRateOperator
               /// </summary>
               public const int CreditDebitNoteRateOperator = 75;

               /// <summary>
               /// Property Indexer for CNDNRateOverrideFlag
               /// </summary>
               public const int CnDnRateOverrideFlag = 76;

               /// <summary>
               /// Property Indexer for Salesperson1
               /// </summary>
               public const int Salesperson1 = 77;

               /// <summary>
               /// Property Indexer for Salesperson2
               /// </summary>
               public const int Salesperson2 = 78;

               /// <summary>
               /// Property Indexer for Salesperson3
               /// </summary>
               public const int Salesperson3 = 79;

               /// <summary>
               /// Property Indexer for Salesperson4
               /// </summary>
               public const int Salesperson4 = 80;

               /// <summary>
               /// Property Indexer for Salesperson5
               /// </summary>
               public const int Salesperson5 = 81;

               /// <summary>
               /// Property Indexer for SalesPercentage1
               /// </summary>
               public const int SalesPercentage1 = 82;

               /// <summary>
               /// Property Indexer for SalesPercentage2
               /// </summary>
               public const int SalesPercentage2 = 83;

               /// <summary>
               /// Property Indexer for SalesPercentage3
               /// </summary>
               public const int SalesPercentage3 = 84;

               /// <summary>
               /// Property Indexer for SalesPercentage4
               /// </summary>
               public const int SalesPercentage4 = 85;

               /// <summary>
               /// Property Indexer for SalesPercentage5
               /// </summary>
               public const int SalesPercentage5 = 86;

               /// <summary>
               /// Property Indexer for RecalculateTax
               /// </summary>
               public const int RecalculateTax = 87;

               /// <summary>
               /// Property Indexer for TaxOverridden
               /// </summary>
               public const int TaxOverridden = 88;

               /// <summary>
               /// Property Indexer for TaxGroup
               /// </summary>
               public const int TaxGroup = 89;

               /// <summary>
               /// Property Indexer for TaxAuthority1
               /// </summary>
               public const int TaxAuthority1 = 90;

               /// <summary>
               /// Property Indexer for TaxAuthority2
               /// </summary>
               public const int TaxAuthority2 = 91;

               /// <summary>
               /// Property Indexer for TaxAuthority3
               /// </summary>
               public const int TaxAuthority3 = 92;

               /// <summary>
               /// Property Indexer for TaxAuthority4
               /// </summary>
               public const int TaxAuthority4 = 93;

               /// <summary>
               /// Property Indexer for TaxAuthority5
               /// </summary>
               public const int TaxAuthority5 = 94;

               /// <summary>
               /// Property Indexer for TaxClass1
               /// </summary>
               public const int TaxClass1 = 95;

               /// <summary>
               /// Property Indexer for TaxClass2
               /// </summary>
               public const int TaxClass2 = 96;

               /// <summary>
               /// Property Indexer for TaxClass3
               /// </summary>
               public const int TaxClass3 = 97;

               /// <summary>
               /// Property Indexer for TaxClass4
               /// </summary>
               public const int TaxClass4 = 98;

               /// <summary>
               /// Property Indexer for TaxClass5
               /// </summary>
               public const int TaxClass5 = 99;

               /// <summary>
               /// Property Indexer for TaxBase1
               /// </summary>
               public const int TaxBase1 = 100;

               /// <summary>
               /// Property Indexer for TaxBase2
               /// </summary>
               public const int TaxBase2 = 101;

               /// <summary>
               /// Property Indexer for TaxBase3
               /// </summary>
               public const int TaxBase3 = 102;

               /// <summary>
               /// Property Indexer for TaxBase4
               /// </summary>
               public const int TaxBase4 = 103;

               /// <summary>
               /// Property Indexer for TaxBase5
               /// </summary>
               public const int TaxBase5 = 104;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount1
               /// </summary>
               public const int ExcludedTaxAmount1 = 105;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount2
               /// </summary>
               public const int ExcludedTaxAmount2 = 106;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount3
               /// </summary>
               public const int ExcludedTaxAmount3 = 107;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount4
               /// </summary>
               public const int ExcludedTaxAmount4 = 108;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount5
               /// </summary>
               public const int ExcludedTaxAmount5 = 109;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount1
               /// </summary>
               public const int IncludedTaxAmount1 = 110;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount2
               /// </summary>
               public const int IncludedTaxAmount2 = 111;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount3
               /// </summary>
               public const int IncludedTaxAmount3 = 112;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount4
               /// </summary>
               public const int IncludedTaxAmount4 = 113;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount5
               /// </summary>
               public const int IncludedTaxAmount5 = 114;

               /// <summary>
               /// Property Indexer for Registration1
               /// </summary>
               public const int Registration1 = 115;

               /// <summary>
               /// Property Indexer for Registration2
               /// </summary>
               public const int Registration2 = 116;

               /// <summary>
               /// Property Indexer for Registration3
               /// </summary>
               public const int Registration3 = 117;

               /// <summary>
               /// Property Indexer for Registration4
               /// </summary>
               public const int Registration4 = 118;

               /// <summary>
               /// Property Indexer for Registration5
               /// </summary>
               public const int Registration5 = 119;

               /// <summary>
               /// Property Indexer for PriceListCodeDescription
               /// </summary>
               public const int PriceListCodeDescription = 128;

               /// <summary>
               /// Property Indexer for TermsCodeDescription
               /// </summary>
               public const int TermsCodeDescription = 129;

               /// <summary>
               /// Property Indexer for TaxGroupCodeDescription
               /// </summary>
               public const int TaxGroupCodeDescription = 130;

               /// <summary>
               /// Property Indexer for LocationCodeDescription
               /// </summary>
               public const int LocationCodeDescription = 131;

               /// <summary>
               /// Property Indexer for SalespersonName1
               /// </summary>
               public const int SalespersonName1 = 132;

               /// <summary>
               /// Property Indexer for SalespersonName2
               /// </summary>
               public const int SalespersonName2 = 133;

               /// <summary>
               /// Property Indexer for SalespersonName3
               /// </summary>
               public const int SalespersonName3 = 134;

               /// <summary>
               /// Property Indexer for SalespersonName4
               /// </summary>
               public const int SalespersonName4 = 135;

               /// <summary>
               /// Property Indexer for SalespersonName5
               /// </summary>
               public const int SalespersonName5 = 136;

               /// <summary>
               /// Property Indexer for TaxAuthority1Description
               /// </summary>
               public const int TaxAuthority1Description = 137;

               /// <summary>
               /// Property Indexer for TaxAuthority2Description
               /// </summary>
               public const int TaxAuthority2Description = 138;

               /// <summary>
               /// Property Indexer for TaxAuthority3Description
               /// </summary>
               public const int TaxAuthority3Description = 139;

               /// <summary>
               /// Property Indexer for TaxAuthority4Description
               /// </summary>
               public const int TaxAuthority4Description = 140;

               /// <summary>
               /// Property Indexer for TaxAuthority5Description
               /// </summary>
               public const int TaxAuthority5Description = 141;

               /// <summary>
               /// Property Indexer for TaxClass1Description
               /// </summary>
               public const int TaxClass1Description = 142;

               /// <summary>
               /// Property Indexer for TaxClass2Description
               /// </summary>
               public const int TaxClass2Description = 143;

               /// <summary>
               /// Property Indexer for TaxClass3Description
               /// </summary>
               public const int TaxClass3Description = 144;

               /// <summary>
               /// Property Indexer for TaxClass4Description
               /// </summary>
               public const int TaxClass4Description = 145;

               /// <summary>
               /// Property Indexer for TaxClass5Description
               /// </summary>
               public const int TaxClass5Description = 146;

               /// <summary>
               /// Property Indexer for InvoiceSourceCurrencyDesc
               /// </summary>
               public const int InvoiceSourceCurrencyDesc = 147;

               /// <summary>
               /// Property Indexer for InvoiceHomeCurrencyDesc
               /// </summary>
               public const int InvoiceHomeCurrencyDesc = 148;

               /// <summary>
               /// Property Indexer for InvoiceRateTypeDescription
               /// </summary>
               public const int InvoiceRateTypeDescription = 149;

               /// <summary>
               /// Property Indexer for CNDNSourceCurrencyDesc
               /// </summary>
               public const int CnDnSourceCurrencyDesc = 150;

               /// <summary>
               /// Property Indexer for CNDNHomeCurrencyDescription
               /// </summary>
               public const int CnDnHomeCurrencyDescription = 151;

               /// <summary>
               /// Property Indexer for CreditDebitNoteRateTypeDesc
               /// </summary>
               public const int CreditDebitNoteRateTypeDesc = 152;

               /// <summary>
               /// Property Indexer for CreditDebitNoteRunningTotal
               /// </summary>
               public const int CreditDebitNoteRunningTotal = 153;

               /// <summary>
               /// Property Indexer for TotalTaxAmount1
               /// </summary>
               public const int TotalTaxAmount1 = 154;

               /// <summary>
               /// Property Indexer for TotalTaxAmount2
               /// </summary>
               public const int TotalTaxAmount2 = 155;

               /// <summary>
               /// Property Indexer for TotalTaxAmount3
               /// </summary>
               public const int TotalTaxAmount3 = 156;

               /// <summary>
               /// Property Indexer for TotalTaxAmount4
               /// </summary>
               public const int TotalTaxAmount4 = 157;

               /// <summary>
               /// Property Indexer for TotalTaxAmount5
               /// </summary>
               public const int TotalTaxAmount5 = 158;

               /// <summary>
               /// Property Indexer for TotalTaxAmount
               /// </summary>
               public const int TotalTaxAmount = 159;

               /// <summary>
               /// Property Indexer for PerformTaxCalculation
               /// </summary>
               public const int PerformTaxCalculation = 160;

               /// <summary>
               /// Property Indexer for PerformForcedTaxCalculation
               /// </summary>
               public const int PerformForcedTaxCalculation = 161;

               /// <summary>
               /// Property Indexer for PerformDistributionOfManTax
               /// </summary>
               public const int PerformDistributionOfManTax = 162;

               /// <summary>
               /// Property Indexer for TaxCalculationInProgress
               /// </summary>
               public const int TaxCalculationInProgress = 163;

               /// <summary>
               /// Property Indexer for AutoTaxCalculationStatus
               /// </summary>
               public const int AutoTaxCalculationStatus = 164;

               /// <summary>
               /// Property Indexer for CustomerExists
               /// </summary>
               public const int CustomerExists = 175;

               /// <summary>
               /// Property Indexer for InvoiceExists
               /// </summary>
               public const int InvoiceExists = 176;

               /// <summary>
               /// Property Indexer for BillToEmail
               /// </summary>
               public const int BillToEmail = 177;

               /// <summary>
               /// Property Indexer for BillToContactPhone
               /// </summary>
               public const int BillToContactPhone = 178;

               /// <summary>
               /// Property Indexer for BillToContactFax
               /// </summary>
               public const int BillToContactFax = 179;

               /// <summary>
               /// Property Indexer for BillToContactEmail
               /// </summary>
               public const int BillToContactEmail = 180;

               /// <summary>
               /// Property Indexer for Type
               /// </summary>
               public const int Type = 181;

               /// <summary>
               /// Property Indexer for ShipmentTrackingNumber
               /// </summary>
               public const int ShipmentTrackingNumber = 183;

               /// <summary>
               /// Property Indexer for ShipViaCode
               /// </summary>
               public const int ShipViaCode = 184;

               /// <summary>
               /// Property Indexer for ShipViaCodeDescription
               /// </summary>
               public const int ShipViaCodeDescription = 185;

               /// <summary>
               /// Property Indexer for PostSequenceNumber
               /// </summary>
               public const int PostSequenceNumber = 186;

               /// <summary>
               /// Property Indexer for ShipToLocationCode
               /// </summary>
               public const int ShipToLocationCode = 187;

               /// <summary>
               /// Property Indexer for ShipToName
               /// </summary>
               public const int ShipToName = 188;

               /// <summary>
               /// Property Indexer for ShipToAddressLine1
               /// </summary>
               public const int ShipToAddressLine1 = 189;

               /// <summary>
               /// Property Indexer for ShipToAddressLine2
               /// </summary>
               public const int ShipToAddressLine2 = 190;

               /// <summary>
               /// Property Indexer for ShipToAddressLine3
               /// </summary>
               public const int ShipToAddressLine3 = 191;

               /// <summary>
               /// Property Indexer for ShipToAddressLine4
               /// </summary>
               public const int ShipToAddressLine4 = 192;

               /// <summary>
               /// Property Indexer for ShipToCity
               /// </summary>
               public const int ShipToCity = 193;

               /// <summary>
               /// Property Indexer for ShipToStateProvince
               /// </summary>
               public const int ShipToStateProvince = 194;

               /// <summary>
               /// Property Indexer for ShipToZipPostalCode
               /// </summary>
               public const int ShipToZipPostalCode = 195;

               /// <summary>
               /// Property Indexer for ShipToCountry
               /// </summary>
               public const int ShipToCountry = 196;

               /// <summary>
               /// Property Indexer for ShipToPhoneNumber
               /// </summary>
               public const int ShipToPhoneNumber = 197;

               /// <summary>
               /// Property Indexer for ShipToFaxNumber
               /// </summary>
               public const int ShipToFaxNumber = 198;

               /// <summary>
               /// Property Indexer for ShipToContact
               /// </summary>
               public const int ShipToContact = 199;

               /// <summary>
               /// Property Indexer for ShipToEmail
               /// </summary>
               public const int ShipToEmail = 200;

               /// <summary>
               /// Property Indexer for ShipToContactPhone
               /// </summary>
               public const int ShipToContactPhone = 201;

               /// <summary>
               /// Property Indexer for ShipToContactFax
               /// </summary>
               public const int ShipToContactFax = 202;

               /// <summary>
               /// Property Indexer for ShipToContactEmail
               /// </summary>
               public const int ShipToContactEmail = 203;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 204;

               /// <summary>
               /// Property Indexer for InvoiceUniquifier
               /// </summary>
               public const int InvoiceUniquifier = 205;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for PROCESSCMD
               /// </summary>
               public const int ProcessCommand = 206;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for OECOMMAND
               /// </summary>
               public const int OeCommand = 207;

               /// <summary>
               /// Property Indexer for OverCreditLimit
               /// </summary>
               public const int OverCreditLimit = 208;

               /// <summary>
               /// Property Indexer for ApprovedLimit
               /// </summary>
               public const int ApprovedLimit = 209;

               /// <summary>
               /// Property Indexer for AuthorizingUserID
               /// </summary>
               public const int AuthorizingUserID = 210;

               /// <summary>
               /// Property Indexer for AuthorizingUserPassword
               /// </summary>
               public const int AuthorizingUserPassword = 211;

               /// <summary>
               /// Property Indexer for UserEnteredApprovalAmount
               /// </summary>
               public const int UserEnteredApprovalAmount = 212;

               /// <summary>
               /// Property Indexer for CheckingCustomerCreditLimit
               /// </summary>
               public const int CheckingCustomerCreditLimit = 213;

               /// <summary>
               /// Property Indexer for CheckingCustomerAgingLimit
               /// </summary>
               public const int CheckingCustomerAgingLimit = 214;

               /// <summary>
               /// Property Indexer for CheckingNatAcctCreditLimit
               /// </summary>
               public const int CheckingNatAcctCreditLimit = 215;

               /// <summary>
               /// Property Indexer for CheckingNatAcctAgingLimit
               /// </summary>
               public const int CheckingNatAcctAgingLimit = 216;

               /// <summary>
               /// Property Indexer for CustomerIsOverCreditLimit
               /// </summary>
               public const int CustomerIsOverCreditLimit = 217;

               /// <summary>
               /// Property Indexer for CustomerIsOverAgingLimit
               /// </summary>
               public const int CustomerIsOverAgingLimit = 218;

               /// <summary>
               /// Property Indexer for NatAcctIsOverCreditLimit
               /// </summary>
               public const int NatAcctIsOverCreditLimit = 219;

               /// <summary>
               /// Property Indexer for NatAcctIsOverAgingLimit
               /// </summary>
               public const int NatAcctIsOverAgingLimit = 220;

               /// <summary>
               /// Property Indexer for CustomerCreditLimit
               /// </summary>
               public const int CustomerCreditLimit = 221;

               /// <summary>
               /// Property Indexer for CustomerBalancePosted
               /// </summary>
               public const int CustomerBalancePosted = 222;

               /// <summary>
               /// Property Indexer for CustomerDaysOverdue
               /// </summary>
               public const int CustomerDaysOverdue = 223;

               /// <summary>
               /// Property Indexer for CustomerOverdueLimit
               /// </summary>
               public const int CustomerOverdueLimit = 224;

               /// <summary>
               /// Property Indexer for CustomerBalanceOverdue
               /// </summary>
               public const int CustomerBalanceOverdue = 225;

               /// <summary>
               /// Property Indexer for NatAcctCreditLimit
               /// </summary>
               public const int NatAcctCreditLimit = 226;

               /// <summary>
               /// Property Indexer for NatAcctBalance
               /// </summary>
               public const int NatAcctBalance = 227;

               /// <summary>
               /// Property Indexer for NatAcctDaysOverdue
               /// </summary>
               public const int NatAcctDaysOverdue = 228;

               /// <summary>
               /// Property Indexer for NatAcctOverdueLimit
               /// </summary>
               public const int NatAcctOverdueLimit = 229;

               /// <summary>
               /// Property Indexer for NatAcctBalanceOverdue
               /// </summary>
               public const int NatAcctBalanceOverdue = 230;

               /// <summary>
               /// Property Indexer for ARPendingTransIncluded
               /// </summary>
               public const int ARPendingTransIncluded = 231;

               /// <summary>
               /// Property Indexer for OEPendingTransIncluded
               /// </summary>
               public const int OEPendingTransIncluded = 232;

               /// <summary>
               /// Property Indexer for OtherPendingTransIncluded
               /// </summary>
               public const int OtherPendingTransIncluded = 233;

               /// <summary>
               /// Property Indexer for ARPendingBalance
               /// </summary>
               public const int ARPendingBalance = 234;

               /// <summary>
               /// Property Indexer for OEPendingBalance
               /// </summary>
               public const int OEPendingBalance = 235;

               /// <summary>
               /// Property Indexer for OtherPendingBalance
               /// </summary>
               public const int OtherPendingBalance = 236;

               /// <summary>
               /// Property Indexer for CustomerTotalOutstanding
               /// </summary>
               public const int CustomerTotalOutstanding = 237;

               /// <summary>
               /// Property Indexer for NatAcctTotalOutstanding
               /// </summary>
               public const int NatAcctTotalOutstanding = 238;

               /// <summary>
               /// Property Indexer for CustomerLimitLeft
               /// </summary>
               public const int CustomerLimitLeft = 239;

               /// <summary>
               /// Property Indexer for NatAcctLimitLeft
               /// </summary>
               public const int NatAcctLimitLeft = 240;

               /// <summary>
               /// Property Indexer for CustomerLimitExceeded
               /// </summary>
               public const int CustomerLimitExceeded = 241;

               /// <summary>
               /// Property Indexer for NatAcctLimitExceeded
               /// </summary>
               public const int NatAcctLimitExceeded = 242;

               /// <summary>
               /// Property Indexer for LastInvoiceAmount
               /// </summary>
               public const int LastInvoiceAmount = 243;

               /// <summary>
               /// Property Indexer for LastInvoiceDate
               /// </summary>
               public const int LastInvoiceDate = 244;

               /// <summary>
               /// Property Indexer for LastPaymentAmount
               /// </summary>
               public const int LastPaymentAmount = 245;

               /// <summary>
               /// Property Indexer for LastPaymentDate
               /// </summary>
               public const int LastPaymentDate = 246;

               /// <summary>
               /// Property Indexer for DrivenbyUI
               /// </summary>
               public const int DrivenbyUI = 247;

               /// <summary>
               /// Property Indexer for ItemDetailDiscountTotal
               /// </summary>
               public const int ItemDetailDiscountTotal = 248;

               /// <summary>
               /// Property Indexer for MiscChargeDetailDiscountTot
               /// </summary>
               public const int MiscChargeDetailDiscountTot = 249;

               /// <summary>
               /// Property Indexer for DetailDiscountTotal
               /// </summary>
               public const int DetailDiscountTotal = 250;

               /// <summary>
               /// Property Indexer for DetailDiscountPercentage
               /// </summary>
               public const int DetailDiscountPercentage = 251;

               /// <summary>
               /// Property Indexer for DocumentNetOfDetailDisc
               /// </summary>
               public const int DocumentNetOfDetailDisc = 252;

               /// <summary>
               /// Property Indexer for AutoCalcTaxReportingAmounts
               /// </summary>
               public const int AutoCalcTaxReportingAmounts = 253;

               /// <summary>
               /// Property Indexer for TaxReportingTRCurrency
               /// </summary>
               public const int TaxReportingTrCurrency = 254;

               /// <summary>
               /// Property Indexer for TRRateType
               /// </summary>
               public const int TrRateType = 255;

               /// <summary>
               /// Property Indexer for TRRateDate
               /// </summary>
               public const int TrRateDate = 256;

               /// <summary>
               /// Property Indexer for TRRate
               /// </summary>
               public const int TrRate = 257;

               /// <summary>
               /// Property Indexer for TRSpread
               /// </summary>
               public const int TrSpread = 258;

               /// <summary>
               /// Property Indexer for TRRateDateMatching
               /// </summary>
               public const int TrRateDateMatching = 259;

               /// <summary>
               /// Property Indexer for TRRateOperator
               /// </summary>
               public const int TrRateOperator = 260;

               /// <summary>
               /// Property Indexer for TRRateOverrideFlag
               /// </summary>
               public const int TrRateOverrideFlag = 261;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount1
               /// </summary>
               public const int TrExcludedTaxAmount1 = 262;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount2
               /// </summary>
               public const int TrExcludedTaxAmount2 = 263;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount3
               /// </summary>
               public const int TrExcludedTaxAmount3 = 264;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount4
               /// </summary>
               public const int TrExcludedTaxAmount4 = 265;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount5
               /// </summary>
               public const int TrExcludedTaxAmount5 = 266;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount1
               /// </summary>
               public const int TrIncludedTaxAmount1 = 267;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount2
               /// </summary>
               public const int TrIncludedTaxAmount2 = 268;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount3
               /// </summary>
               public const int TrIncludedTaxAmount3 = 269;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount4
               /// </summary>
               public const int TrIncludedTaxAmount4 = 270;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount5
               /// </summary>
               public const int TrIncludedTaxAmount5 = 271;

               /// <summary>
               /// Property Indexer for TRTaxAmount1
               /// </summary>
               public const int TrTaxAmount1 = 272;

               /// <summary>
               /// Property Indexer for TRTaxAmount2
               /// </summary>
               public const int TrTaxAmount2 = 273;

               /// <summary>
               /// Property Indexer for TRTaxAmount3
               /// </summary>
               public const int TrTaxAmount3 = 274;

               /// <summary>
               /// Property Indexer for TRTaxAmount4
               /// </summary>
               public const int TrTaxAmount4 = 275;

               /// <summary>
               /// Property Indexer for TRTaxAmount5
               /// </summary>
               public const int TrTaxAmount5 = 276;

               /// <summary>
               /// Property Indexer for TRExcludedTaxTotal
               /// </summary>
               public const int TrExcludedTaxTotal = 277;

               /// <summary>
               /// Property Indexer for TRIncludedTaxTotal
               /// </summary>
               public const int TrIncludedTaxTotal = 278;

               /// <summary>
               /// Property Indexer for TRTaxTotal
               /// </summary>
               public const int TrTaxTotal = 279;

               /// <summary>
               /// Property Indexer for TaxReportingInvoiceTRCurr
               /// </summary>
               public const int TaxReportingInvoiceTrCurr = 280;

               /// <summary>
               /// Property Indexer for TRInvoiceRateType
               /// </summary>
               public const int TrInvoiceRateType = 281;

               /// <summary>
               /// Property Indexer for TRInvoiceRateDate
               /// </summary>
               public const int TrInvoiceRateDate = 282;

               /// <summary>
               /// Property Indexer for TRInvoiceRate
               /// </summary>
               public const int TrInvoiceRate = 283;

               /// <summary>
               /// Property Indexer for TRInvoiceSpread
               /// </summary>
               public const int TrInvoiceSpread = 284;

               /// <summary>
               /// Property Indexer for TRInvoiceRateDateMatching
               /// </summary>
               public const int TrInvoiceRateDateMatching = 285;

               /// <summary>
               /// Property Indexer for TRInvoiceRateOperator
               /// </summary>
               public const int TrInvoiceRateOperator = 286;

               /// <summary>
               /// Property Indexer for TRInvoiceRateOverrideFlag
               /// </summary>
               public const int TrInvoiceRateOverrideFlag = 287;

               /// <summary>
               /// Property Indexer for TRCurrencyDescription
               /// </summary>
               public const int TrCurrencyDescription = 288;

               /// <summary>
               /// Property Indexer for TRInvoiceCurrencyDescription
               /// </summary>
               public const int TrInvoiceCurrencyDescription = 289;

               /// <summary>
               /// Property Indexer for TRRateTypeDescription
               /// </summary>
               public const int TrRateTypeDescription = 290;

               /// <summary>
               /// Property Indexer for TRInvoiceRateTypeDescription
               /// </summary>
               public const int TrInvoiceRateTypeDescription = 291;

               /// <summary>
               /// Property Indexer for TaxVersion
               /// </summary>
               public const int TaxVersion = 292;

               /// <summary>
               /// Property Indexer for CNDNDiscountAmountOverride
               /// </summary>
               public const int CnDnDiscountAmountOverride = 293;

               /// <summary>
               /// Property Indexer for DOSConversion
               /// </summary>
               public const int DosConversion = 294;

               /// <summary>
               /// Property Indexer for FromInvoice
               /// </summary>
               public const int FromInvoice = 295;

               /// <summary>
               /// Property Indexer for JobRelated
               /// </summary>
               public const int JobRelated = 296;

               /// <summary>
               /// Property Indexer for JobRelatedDetailLines
               /// </summary>
               public const int JobRelatedDetailLines = 297;

               /// <summary>
               /// Property Indexer for HasRetainage
               /// </summary>
               public const int HasRetainage = 298;

               /// <summary>
               /// Property Indexer for RetainageAmount
               /// </summary>
               public const int RetainageAmount = 299;

               /// <summary>
               /// Property Indexer for RetainagePercent
               /// </summary>
               public const int RetainagePercent = 300;

               /// <summary>
               /// Property Indexer for RetainageExchangeRate
               /// </summary>
               public const int RetainageExchangeRate = 301;

               /// <summary>
               /// Property Indexer for RetainageTaxBase1
               /// </summary>
               public const int RetainageTaxBase1 = 302;

               /// <summary>
               /// Property Indexer for RetainageTaxBase2
               /// </summary>
               public const int RetainageTaxBase2 = 303;

               /// <summary>
               /// Property Indexer for RetainageTaxBase3
               /// </summary>
               public const int RetainageTaxBase3 = 304;

               /// <summary>
               /// Property Indexer for RetainageTaxBase4
               /// </summary>
               public const int RetainageTaxBase4 = 305;

               /// <summary>
               /// Property Indexer for RetainageTaxBase5
               /// </summary>
               public const int RetainageTaxBase5 = 306;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount1
               /// </summary>
               public const int RetainageTaxAmount1 = 307;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount2
               /// </summary>
               public const int RetainageTaxAmount2 = 308;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount3
               /// </summary>
               public const int RetainageTaxAmount3 = 309;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount4
               /// </summary>
               public const int RetainageTaxAmount4 = 310;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount5
               /// </summary>
               public const int RetainageTaxAmount5 = 311;

               /// <summary>
               /// Property Indexer for CustomerAccountSet
               /// </summary>
               public const int CustomerAccountSet = 312;

               /// <summary>
               /// Property Indexer for CustomerAccountSetDescription
               /// </summary>
               public const int CustomerAccountSetDescription = 313;

               /// <summary>
               /// Property Indexer for EnteredBy
               /// </summary>
               public const int EnteredBy = 314;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for DATEBUS
               /// </summary>
               public const int DateBus = 315;

               /// <summary>
               /// Property Indexer for CreditDebitNoteAmountDue
               /// </summary>
               public const int CreditDebitNoteAmountDue = 316;

               /// <summary>
               /// Property Indexer for TotalRetainageTaxAmount
               /// </summary>
               public const int TotalRetainageTaxAmount = 317;

          }
          #endregion

          #region Keys

          /// <summary>
          /// Order Keys
          /// </summary>
          public class Keys
          {
              /// <summary>
              /// Credit/Debit Uniquifier Key
              /// </summary>
              public const int CnUniquifier = 0;

              /// <summary>
              /// Credit/Debit Number Key
              /// </summary>
              public const int CreditDebitNoteNumber = 1;
          }

          #endregion

     }
}
