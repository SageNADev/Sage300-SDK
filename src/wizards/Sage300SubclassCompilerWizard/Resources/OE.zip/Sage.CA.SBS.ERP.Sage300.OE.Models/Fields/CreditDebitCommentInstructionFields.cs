// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.


namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
    /// Contains list of CreditDebitCommentInstruction Constants
     /// </summary>
    public partial class CreditDebitCommentInstruction
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "OE0140";

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitCommentInstruction Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CNUniquifier
               /// </summary>
               public const string CnUniquifier = "CRDUNIQ";

               /// <summary>
               /// Property for Uniquifier
               /// </summary>
               public const string Uniquifier = "UNIQUIFIER";

               /// <summary>
               /// Property for DetailNumber
               /// </summary>
               public const string DetailNumber = "DETAILNUM";

               /// <summary>
               /// Property for CommentsInstructionsType
               /// </summary>
               public const string CommentsInstructionsType = "COINTYPE";

               /// <summary>
               /// Property for CommentsInstructions
               /// </summary>
               public const string CommentsInstructions = "COIN";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitCommentInstruction Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CNUniquifier
               /// </summary>
               public const int CnUniquifier = 1;

               /// <summary>
               /// Property Indexer for Uniquifier
               /// </summary>
               public const int Uniquifier = 2;

               /// <summary>
               /// Property Indexer for DetailNumber
               /// </summary>
               public const int DetailNumber = 3;

               /// <summary>
               /// Property Indexer for CommentsInstructionsType
               /// </summary>
               public const int CommentsInstructionsType = 4;

               /// <summary>
               /// Property Indexer for CommentsInstructions
               /// </summary>
               public const int CommentsInstructions = 5;

          }
          #endregion

     }
}
