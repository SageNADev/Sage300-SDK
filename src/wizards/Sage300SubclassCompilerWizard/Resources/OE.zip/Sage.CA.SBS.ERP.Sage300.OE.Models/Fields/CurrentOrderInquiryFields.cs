// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of CurrencyOrderInquiry Constants
	/// </summary>
	public partial class CurrentOrderInquiry
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "OE0194";

		#region Properties

		/// <summary>
		/// Contains list of CurrencyOrderInquiry Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Ordernumber
			/// </summary>
			public const string OrderNumber = "ORDNUMBER";

			/// <summary>
			/// Property for POnumber
			/// </summary>
			public const string PONumber = "PONUMBER";

			/// <summary>
			/// Property for Printstatus
			/// </summary>
			public const string PrintStatus = "PRINTSTAT";

			/// <summary>
			/// Property for Orderdate
			/// </summary>
			public const string OrderDate = "ORDDATE";

			/// <summary>
			/// Property for Expectedshipdate
			/// </summary>
			public const string ExpectedShipDate = "EXPDATE";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for Onhold
			/// </summary>
			public const string OnHold = "ONHOLD";

			/// <summary>
			/// Property for Type
			/// </summary>
			public const string Type = "TYPE";

			/// <summary>
			/// Property for Shipto
			/// </summary>
			public const string ShipTo = "SHIPTO";

			/// <summary>
			/// Property for Shipvia
			/// </summary>
			public const string ShipVia = "SHIPVIA";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "DESC";

			/// <summary>
			/// Property for FOB
			/// </summary>
			public const string Fob = "FOB";

			/// <summary>
			/// Property for Territory
			/// </summary>
			public const string Territory = "TERRITORY";

			/// <summary>
			/// Property for Terms
			/// </summary>
			public const string Terms = "TERMS";

			/// <summary>
			/// Property for Reference
			/// </summary>
			public const string Reference = "REFERENCE";

			/// <summary>
			/// Property for Pricelist
			/// </summary>
			public const string PriceList = "PRICELIST";

			/// <summary>
			/// Property for Taxgroup
			/// </summary>
			public const string TaxGroup = "TAXGROUP";

			/// <summary>
			/// Property for Customernumber
			/// </summary>
			public const string CustomerNumber = "CUSTOMER";

			/// <summary>
			/// Property for Fromordernumber
			/// </summary>
			public const string FromOrderNumber = "FRORDNUM";

			/// <summary>
			/// Property for Toordernumber
			/// </summary>
			public const string ToOrderNumber = "TOORDNUM";

			/// <summary>
			/// Property for Fromorderdate
			/// </summary>
			public const string FromOrderDate = "FRORDDATE";

			/// <summary>
			/// Property for Toorderdate
			/// </summary>
			public const string ToOrderDate = "TOORDDATE";

			/// <summary>
			/// Property for FromExpectedshipdate
			/// </summary>
			public const string FromExpectedShipDate = "FREXPDATE";

			/// <summary>
			/// Property for ToExpectedshipdate
			/// </summary>
			public const string ToExpectedShipDate = "TOEXPDATE";

			/// <summary>
			/// Property for Ordertype
			/// </summary>
			public const string OrderType = "ORDTYPE";

			/// <summary>
			/// Property for OrderStatus
			/// </summary>
			public const string OrderStatus = "ORDSTATUS";

			/// <summary>
			/// Property for Action
			/// </summary>
			public const string Action = "ACTION";

			/// <summary>
			/// Property for CustomerName
			/// </summary>
			public const string CustomerName = "CUSTNAME";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of CurrencyOrderInquiry Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Ordernumber
			/// </summary>
			public const int OrderNumber = 1;

			/// <summary>
			/// Property Indexer for POnumber
			/// </summary>
			public const int PONumber = 2;

			/// <summary>
			/// Property Indexer for Printstatus
			/// </summary>
			public const int PrintStatus = 3;

			/// <summary>
			/// Property Indexer for Orderdate
			/// </summary>
			public const int OrderDate = 4;

			/// <summary>
			/// Property Indexer for Expectedshipdate
			/// </summary>
			public const int ExpectedShipDate = 5;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 6;

			/// <summary>
			/// Property Indexer for Onhold
			/// </summary>
			public const int OnHold = 7;

			/// <summary>
			/// Property Indexer for Type
			/// </summary>
			public const int Type = 8;

			/// <summary>
			/// Property Indexer for Shipto
			/// </summary>
			public const int ShipTo = 9;

			/// <summary>
			/// Property Indexer for Shipvia
			/// </summary>
			public const int ShipVia = 10;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 11;

		
			/// <summary>
			/// Property Indexer for FOB
			/// </summary>
			public const int Fob = 12;

			/// <summary>
			/// Property Indexer for Territory
			/// </summary>
			public const int Territory = 13;

			/// <summary>
			/// Property Indexer for Terms
			/// </summary>
			public const int Terms = 14;

			/// <summary>
			/// Property Indexer for Reference
			/// </summary>
			public const int Reference = 15;

			/// <summary>
			/// Property Indexer for Pricelist
			/// </summary>
			public const int PriceList = 16;

			/// <summary>
			/// Property Indexer for Taxgroup
			/// </summary>
			public const int TaxGroup = 17;

			/// <summary>
			/// Property Indexer for Customernumber
			/// </summary>
			public const int CustomerNumber = 18;

			/// <summary>
			/// Property Indexer for Fromordernumber
			/// </summary>
			public const int FromOrderNumber = 19;

			/// <summary>
			/// Property Indexer for Toordernumber
			/// </summary>
			public const int ToOrderNumber = 20;

			/// <summary>
			/// Property Indexer for Fromorderdate
			/// </summary>
			public const int FromOrderDate = 21;

			/// <summary>
			/// Property Indexer for Toorderdate
			/// </summary>
			public const int ToOrderDate = 22;

			/// <summary>
			/// Property Indexer for FromExpectedshipdate
			/// </summary>
			public const int FromExpectedShipDate = 23;

			/// <summary>
			/// Property Indexer for ToExpectedshipdate
			/// </summary>
			public const int ToExpectedShipDate = 24;

			/// <summary>
			/// Property Indexer for Ordertype
			/// </summary>
			public const int OrderType = 25;

			/// <summary>
			/// Property Indexer for OrderStatus
			/// </summary>
			public const int OrderStatus = 26;

			/// <summary>
			/// Property Indexer for Action
			/// </summary>
			public const int Action = 27;

			/// <summary>
			/// Property Indexer for CustomerName
			/// </summary>
			public const int CustomerName = 28;

		}

		#endregion

	}
}
