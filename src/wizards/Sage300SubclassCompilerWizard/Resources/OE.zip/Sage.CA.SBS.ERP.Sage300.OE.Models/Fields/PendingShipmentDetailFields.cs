// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of PendingShipmentDetail Constants
    /// </summary>
    public partial class PendingShipmentDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0505";

        #region Properties

        /// <summary>
        /// Contains list of PendingShipmentDetail Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for OrderUniquifier
            /// </summary>
            public const string OrderUniquifier = "ORDUNIQ";

            /// <summary>
            /// Property for FromExpectedShipmentDate
            /// </summary>
            public const string FromExpectedShipmentDate = "EXPDATEF";

            /// <summary>
            /// Property for ToExpectedShipmentDate
            /// </summary>
            public const string ToExpectedShipmentDate = "EXPDATET";

            /// <summary>
            /// Property for FromItemNumber
            /// </summary>
            public const string FromItemNumber = "ITEMF";

            /// <summary>
            /// Property for ToItemNumber
            /// </summary>
            public const string ToItemNumber = "ITEMT";

            /// <summary>
            /// Property for FromLocation
            /// </summary>
            public const string FromLocation = "LOCATIONF";

            /// <summary>
            /// Property for ToLocation
            /// </summary>
            public const string ToLocation = "LOCATIONT";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENUM";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEM";

            /// <summary>
            /// Property for ExpectedShipmentDate
            /// </summary>
            public const string ExpectedShipmentDate = "EXPDATE";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for ShipViaCode
            /// </summary>
            public const string ShipViaCode = "SHIPVIA";

            /// <summary>
            /// Property for ShipViaDescription
            /// </summary>
            public const string ShipViaDescription = "VIADESC";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for QuantityOrdered
            /// </summary>
            public const string QuantityOrdered = "QTYORDERED";

            /// <summary>
            /// Property for OrderUnitOfMeasure
            /// </summary>
            public const string OrderUnitOfMeasure = "ORDUNIT";

            /// <summary>
            /// Property for QuantityCommitted
            /// </summary>
            public const string QuantityCommitted = "QTYCOMMIT";

            /// <summary>
            /// Property for QuantityAvailable
            /// </summary>
            public const string QuantityAvailable = "QTYAVAIL";

            /// <summary>
            /// Property for OnPurchaseOrder
            /// </summary>
            public const string OnPurchaseOrder = "ONPO";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DDTLNO";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PendingShipmentDetail Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for OrderUniquifier
            /// </summary>
            public const int OrderUniquifier = 1;

            /// <summary>
            /// Property Indexer for FromExpectedShipmentDate
            /// </summary>
            public const int FromExpectedShipmentDate = 2;

            /// <summary>
            /// Property Indexer for ToExpectedShipmentDate
            /// </summary>
            public const int ToExpectedShipmentDate = 3;

            /// <summary>
            /// Property Indexer for FromItemNumber
            /// </summary>
            public const int FromItemNumber = 4;

            /// <summary>
            /// Property Indexer for ToItemNumber
            /// </summary>
            public const int ToItemNumber = 5;

            /// <summary>
            /// Property Indexer for FromLocation
            /// </summary>
            public const int FromLocation = 6;

            /// <summary>
            /// Property Indexer for ToLocation
            /// </summary>
            public const int ToLocation = 7;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 8;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 9;

            /// <summary>
            /// Property Indexer for ExpectedShipmentDate
            /// </summary>
            public const int ExpectedShipmentDate = 10;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 11;

            /// <summary>
            /// Property Indexer for ShipViaCode
            /// </summary>
            public const int ShipViaCode = 12;

            /// <summary>
            /// Property Indexer for ShipViaDescription
            /// </summary>
            public const int ShipViaDescription = 13;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 14;

            /// <summary>
            /// Property Indexer for QuantityOrdered
            /// </summary>
            public const int QuantityOrdered = 15;

            /// <summary>
            /// Property Indexer for OrderUnitOfMeasure
            /// </summary>
            public const int OrderUnitOfMeasure = 16;

            /// <summary>
            /// Property Indexer for QuantityCommitted
            /// </summary>
            public const int QuantityCommitted = 17;

            /// <summary>
            /// Property Indexer for QuantityAvailable
            /// </summary>
            public const int QuantityAvailable = 18;

            /// <summary>
            /// Property Indexer for OnPurchaseOrder
            /// </summary>
            public const int OnPurchaseOrder = 19;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 20;

        }

        #endregion
    }
}
