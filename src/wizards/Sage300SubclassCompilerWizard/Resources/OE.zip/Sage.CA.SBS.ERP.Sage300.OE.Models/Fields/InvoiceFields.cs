// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of Invoice Constants
     /// </summary>
     public partial class Invoice
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "OE0420";

          #region Properties
          /// <summary>
          /// Contains list of Invoice Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for InvoiceUniquifier
               /// </summary>
               public const string InvoiceUniquifier = "INVUNIQ";

               /// <summary>
               /// Property for OrderNumber
               /// </summary>
               public const string OrderNumber = "ORDNUMBER";

               /// <summary>
               /// Property for ICDayEndTransNumber
               /// </summary>
               public const string ICDayEndTransNumber = "DAYENDNUM";

               /// <summary>
               /// Property for CustomerNumber
               /// </summary>
               public const string CustomerNumber = "CUSTOMER";

               /// <summary>
               /// Property for BillTo
               /// </summary>
               public const string BillTo = "BILNAME";

               /// <summary>
               /// Property for BillToAddress1
               /// </summary>
               public const string BillToAddress1 = "BILADDR1";

               /// <summary>
               /// Property for BillToAddress2
               /// </summary>
               public const string BillToAddress2 = "BILADDR2";

               /// <summary>
               /// Property for BillToAddress3
               /// </summary>
               public const string BillToAddress3 = "BILADDR3";

               /// <summary>
               /// Property for BillToAddress4
               /// </summary>
               public const string BillToAddress4 = "BILADDR4";

               /// <summary>
               /// Property for BillToCity
               /// </summary>
               public const string BillToCity = "BILCITY";

               /// <summary>
               /// Property for BillToState
               /// </summary>
               public const string BillToState = "BILSTATE";

               /// <summary>
               /// Property for BillToZipCode
               /// </summary>
               public const string BillToZipCode = "BILZIP";

               /// <summary>
               /// Property for BillToCountry
               /// </summary>
               public const string BillToCountry = "BILCOUNTRY";

               /// <summary>
               /// Property for BillToPhone
               /// </summary>
               public const string BillToPhone = "BILPHONE";

               /// <summary>
               /// Property for BillToFax
               /// </summary>
               public const string BillToFax = "BILFAX";

               /// <summary>
               /// Property for BillToContact
               /// </summary>
               public const string BillToContact = "BILCONTACT";

               /// <summary>
               /// Property for ShipToAddressCode
               /// </summary>
               public const string ShipToAddressCode = "SHIPTO";

               /// <summary>
               /// Property for ShipTo
               /// </summary>
               public const string ShipTo = "SHPNAME";

               /// <summary>
               /// Property for ShipToAddress1
               /// </summary>
               public const string ShipToAddress1 = "SHPADDR1";

               /// <summary>
               /// Property for ShipToAddress2
               /// </summary>
               public const string ShipToAddress2 = "SHPADDR2";

               /// <summary>
               /// Property for ShipToAddress3
               /// </summary>
               public const string ShipToAddress3 = "SHPADDR3";

               /// <summary>
               /// Property for ShipToAddress4
               /// </summary>
               public const string ShipToAddress4 = "SHPADDR4";

               /// <summary>
               /// Property for ShipToCity
               /// </summary>
               public const string ShipToCity = "SHPCITY";

               /// <summary>
               /// Property for ShipToState
               /// </summary>
               public const string ShipToState = "SHPSTATE";

               /// <summary>
               /// Property for ShipToZipCode
               /// </summary>
               public const string ShipToZipCode = "SHPZIP";

               /// <summary>
               /// Property for ShipToCountry
               /// </summary>
               public const string ShipToCountry = "SHPCOUNTRY";

               /// <summary>
               /// Property for ShipToPhone
               /// </summary>
               public const string ShipToPhone = "SHPPHONE";

               /// <summary>
               /// Property for ShipToFax
               /// </summary>
               public const string ShipToFax = "SHPFAX";

               /// <summary>
               /// Property for ShipToContact
               /// </summary>
               public const string ShipToContact = "SHPCONTACT";

               /// <summary>
               /// Property for CustomerDiscountLevel
               /// </summary>
               public const string CustomerDiscountLevel = "CUSTDISC";

               /// <summary>
               /// Property for PriceListCode
               /// </summary>
               public const string PriceListCode = "PRICELIST";

               /// <summary>
               /// Property for PurchaseOrderNumber
               /// </summary>
               public const string PurchaseOrderNumber = "PONUMBER";

               /// <summary>
               /// Property for Territory
               /// </summary>
               public const string Territory = "TERRITORY";

               /// <summary>
               /// Property for TermsCode
               /// </summary>
               public const string TermsCode = "TERMS";

               /// <summary>
               /// Property for TotalTermsAmountDue
               /// </summary>
               public const string TotalTermsAmountDue = "TERMTTLDUE";

               /// <summary>
               /// Property for TermsRateOverride
               /// </summary>
               public const string TermsRateOverride = "TERMOVERRD";

               /// <summary>
               /// Property for Reference
               /// </summary>
               public const string Reference = "REFERENCE";

               /// <summary>
               /// Property for OrderDate
               /// </summary>
               public const string OrderDate = "ORDDATE";

               /// <summary>
               /// Property for ShipViaCode
               /// </summary>
               public const string ShipViaCode = "SHIPVIA";

               /// <summary>
               /// Property for ShipViaCodeDescription
               /// </summary>
               public const string ShipViaCodeDescription = "VIADESC";

               /// <summary>
               /// Property for FreeOnBoardPoint
               /// </summary>
               public const string FreeOnBoardPoint = "FOB";

               /// <summary>
               /// Property for TemplateCode
               /// </summary>
               public const string TemplateCode = "TEMPLATE";

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for Comment
               /// </summary>
               public const string Comment = "COMMENT";

               /// <summary>
               /// Property for ShipmentDate
               /// </summary>
               public const string ShipmentDate = "SHIPDATE";

               /// <summary>
               /// Property for InvoiceDate
               /// </summary>
               public const string InvoiceDate = "INVDATE";

               /// <summary>
               /// Property for InvoiceFiscalYear
               /// </summary>
               public const string InvoiceFiscalYear = "INVFISCYR";

               /// <summary>
               /// Property for InvoiceFiscalPeriod
               /// </summary>
               public const string InvoiceFiscalPeriod = "INVFISCPER";

               /// <summary>
               /// Property for NumberOfLinesInInvoice
               /// </summary>
               public const string NumberOfLinesInInvoice = "INVLINES";

               /// <summary>
               /// Property for NumberOfLabels
               /// </summary>
               public const string NumberOfLabels = "NUMLABELS";

               /// <summary>
               /// Property for NumberOfTermsPayments
               /// </summary>
               public const string NumberOfTermsPayments = "NUMPAYMENT";

               /// <summary>
               /// Property for TermsPaymentsAsOfDate
               /// </summary>
               public const string TermsPaymentsAsOfDate = "PAYMNTASOF";

               /// <summary>
               /// Property for InvoiceTotalEstimatedWeight
               /// </summary>
               public const string InvoiceTotalEstimatedWeight = "INVWEIGHT";

               /// <summary>
               /// Property for NextDetailNumber
               /// </summary>
               public const string NextDetailNumber = "NEXTDTLNUM";

               /// <summary>
               /// Property for InvoiceStatus
               /// </summary>
               public const string InvoiceStatus = "INVSTATUS";

               /// <summary>
               /// Property for InvoicePrinted
               /// </summary>
               public const string InvoicePrinted = "INVPRINTED";

               /// <summary>
               /// Property for InvoiceDisconMiscCharges
               /// </summary>
               public const string InvoiceDisconMiscCharges = "IDISONMISC";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for POSTDATE
               /// </summary>
               public const string PostingDate = "POSTDATE";

               /// <summary>
               /// Property for CompletionDate
               /// </summary>
               public const string CompletionDate = "COMPDATE";

               /// <summary>
               /// Property for RequiresShippingLabels
               /// </summary>
               public const string RequiresShippingLabels = "SHIPLABEL";

               /// <summary>
               /// Property for ShippingLabelsPrinted
               /// </summary>
               public const string ShippingLabelsPrinted = "LBLPRINTED";

               /// <summary>
               /// Property for InvoiceTotalBeforeTax
               /// </summary>
               public const string InvoiceTotalBeforeTax = "INVNETNOTX";

               /// <summary>
               /// Property for InvoiceIncludedTaxTotAmount
               /// </summary>
               public const string InvoiceIncludedTaxTotAmount = "INVITAXTOT";

               /// <summary>
               /// Property for InvoiceItemTotalAmount
               /// </summary>
               public const string InvoiceItemTotalAmount = "INVITMTOT";

               /// <summary>
               /// Property for InvoiceDiscountBase
               /// </summary>
               public const string InvoiceDiscountBase = "INVDISCBAS";

               /// <summary>
               /// Property for InvoiceDiscountPercentage
               /// </summary>
               public const string InvoiceDiscountPercentage = "INVDISCPER";

               /// <summary>
               /// Property for InvoiceDiscountAmount
               /// </summary>
               public const string InvoiceDiscountAmount = "INVDISCAMT";

               /// <summary>
               /// Property for InvoiceTotalMiscCharges
               /// </summary>
               public const string InvoiceTotalMiscCharges = "INVMISC";

               /// <summary>
               /// Property for InvoiceSubtotalAmount
               /// </summary>
               public const string InvoiceSubtotalAmount = "INVSUBTOT";

               /// <summary>
               /// Property for InvoiceTotalWithInvoiceDisc
               /// </summary>
               public const string InvoiceTotalWithInvoiceDisc = "INVNET";

               /// <summary>
               /// Property for InvoiceExcludedTaxTotAmount
               /// </summary>
               public const string InvoiceExcludedTaxTotAmount = "INVETAXTOT";

               /// <summary>
               /// Property for InvoiceTotalWithTax
               /// </summary>
               public const string InvoiceTotalWithTax = "INVNETWTX";

               /// <summary>
               /// Property for InvoiceHomeCurrency
               /// </summary>
               public const string InvoiceHomeCurrency = "INHOMECURR";

               /// <summary>
               /// Property for InvoiceRateType
               /// </summary>
               public const string InvoiceRateType = "INRATETYPE";

               /// <summary>
               /// Property for InvoiceSourceCurrency
               /// </summary>
               public const string InvoiceSourceCurrency = "INSOURCURR";

               /// <summary>
               /// Property for InvoiceRateDate
               /// </summary>
               public const string InvoiceRateDate = "INRATEDATE";

               /// <summary>
               /// Property for InvoiceRate
               /// </summary>
               public const string InvoiceRate = "INRATE";

               /// <summary>
               /// Property for InvoiceSpread
               /// </summary>
               public const string InvoiceSpread = "INSPREAD";

               /// <summary>
               /// Property for InvoiceRateDateMatching
               /// </summary>
               public const string InvoiceRateDateMatching = "INDATEMTCH";

               /// <summary>
               /// Property for InvoiceRateOperator
               /// </summary>
               public const string InvoiceRateOperator = "INRATEREP";

               /// <summary>
               /// Property for InvoiceRateOverrideFlag
               /// </summary>
               public const string InvoiceRateOverrideFlag = "INRATEOVER";

               /// <summary>
               /// Property for Salesperson1
               /// </summary>
               public const string Salesperson1 = "SALESPER1";

               /// <summary>
               /// Property for Salesperson2
               /// </summary>
               public const string Salesperson2 = "SALESPER2";

               /// <summary>
               /// Property for Salesperson3
               /// </summary>
               public const string Salesperson3 = "SALESPER3";

               /// <summary>
               /// Property for Salesperson4
               /// </summary>
               public const string Salesperson4 = "SALESPER4";

               /// <summary>
               /// Property for Salesperson5
               /// </summary>
               public const string Salesperson5 = "SALESPER5";

               /// <summary>
               /// Property for SalesPercentage1
               /// </summary>
               public const string SalesPercentage1 = "SALESPLT1";

               /// <summary>
               /// Property for SalesPercentage2
               /// </summary>
               public const string SalesPercentage2 = "SALESPLT2";

               /// <summary>
               /// Property for SalesPercentage3
               /// </summary>
               public const string SalesPercentage3 = "SALESPLT3";

               /// <summary>
               /// Property for SalesPercentage4
               /// </summary>
               public const string SalesPercentage4 = "SALESPLT4";

               /// <summary>
               /// Property for SalesPercentage5
               /// </summary>
               public const string SalesPercentage5 = "SALESPLT5";

               /// <summary>
               /// Property for TaxOverridden
               /// </summary>
               public const string TaxOverridden = "TAXOVERRD";

               /// <summary>
               /// Property for TaxGroup
               /// </summary>
               public const string TaxGroup = "TAXGROUP";

               /// <summary>
               /// Property for TaxAuthority1
               /// </summary>
               public const string TaxAuthority1 = "TAUTH1";

               /// <summary>
               /// Property for TaxAuthority2
               /// </summary>
               public const string TaxAuthority2 = "TAUTH2";

               /// <summary>
               /// Property for TaxAuthority3
               /// </summary>
               public const string TaxAuthority3 = "TAUTH3";

               /// <summary>
               /// Property for TaxAuthority4
               /// </summary>
               public const string TaxAuthority4 = "TAUTH4";

               /// <summary>
               /// Property for TaxAuthority5
               /// </summary>
               public const string TaxAuthority5 = "TAUTH5";

               /// <summary>
               /// Property for TaxClass1
               /// </summary>
               public const string TaxClass1 = "TCLASS1";

               /// <summary>
               /// Property for TaxClass2
               /// </summary>
               public const string TaxClass2 = "TCLASS2";

               /// <summary>
               /// Property for TaxClass3
               /// </summary>
               public const string TaxClass3 = "TCLASS3";

               /// <summary>
               /// Property for TaxClass4
               /// </summary>
               public const string TaxClass4 = "TCLASS4";

               /// <summary>
               /// Property for TaxClass5
               /// </summary>
               public const string TaxClass5 = "TCLASS5";

               /// <summary>
               /// Property for TaxBase1
               /// </summary>
               public const string TaxBase1 = "TBASE1";

               /// <summary>
               /// Property for TaxBase2
               /// </summary>
               public const string TaxBase2 = "TBASE2";

               /// <summary>
               /// Property for TaxBase3
               /// </summary>
               public const string TaxBase3 = "TBASE3";

               /// <summary>
               /// Property for TaxBase4
               /// </summary>
               public const string TaxBase4 = "TBASE4";

               /// <summary>
               /// Property for TaxBase5
               /// </summary>
               public const string TaxBase5 = "TBASE5";

               /// <summary>
               /// Property for ExcludedTaxAmount1
               /// </summary>
               public const string ExcludedTaxAmount1 = "TEAMOUNT1";

               /// <summary>
               /// Property for ExcludedTaxAmount2
               /// </summary>
               public const string ExcludedTaxAmount2 = "TEAMOUNT2";

               /// <summary>
               /// Property for ExcludedTaxAmount3
               /// </summary>
               public const string ExcludedTaxAmount3 = "TEAMOUNT3";

               /// <summary>
               /// Property for ExcludedTaxAmount4
               /// </summary>
               public const string ExcludedTaxAmount4 = "TEAMOUNT4";

               /// <summary>
               /// Property for ExcludedTaxAmount5
               /// </summary>
               public const string ExcludedTaxAmount5 = "TEAMOUNT5";

               /// <summary>
               /// Property for IncludedTaxAmount1
               /// </summary>
               public const string IncludedTaxAmount1 = "TIAMOUNT1";

               /// <summary>
               /// Property for IncludedTaxAmount2
               /// </summary>
               public const string IncludedTaxAmount2 = "TIAMOUNT2";

               /// <summary>
               /// Property for IncludedTaxAmount3
               /// </summary>
               public const string IncludedTaxAmount3 = "TIAMOUNT3";

               /// <summary>
               /// Property for IncludedTaxAmount4
               /// </summary>
               public const string IncludedTaxAmount4 = "TIAMOUNT4";

               /// <summary>
               /// Property for IncludedTaxAmount5
               /// </summary>
               public const string IncludedTaxAmount5 = "TIAMOUNT5";

               /// <summary>
               /// Property for Registration1
               /// </summary>
               public const string Registration1 = "TEXEMPT1";

               /// <summary>
               /// Property for Registration2
               /// </summary>
               public const string Registration2 = "TEXEMPT2";

               /// <summary>
               /// Property for Registration3
               /// </summary>
               public const string Registration3 = "TEXEMPT3";

               /// <summary>
               /// Property for Registration4
               /// </summary>
               public const string Registration4 = "TEXEMPT4";

               /// <summary>
               /// Property for Registration5
               /// </summary>
               public const string Registration5 = "TEXEMPT5";

               /// <summary>
               /// Property for PriceListCodeDescription
               /// </summary>
               public const string PriceListCodeDescription = "PCODDESC";

               /// <summary>
               /// Property for TermsCodeDescription
               /// </summary>
               public const string TermsCodeDescription = "TERMDESC";

               /// <summary>
               /// Property for TaxGroupCodeDescription
               /// </summary>
               public const string TaxGroupCodeDescription = "TXGRPDESC";

               /// <summary>
               /// Property for LocationCodeDescription
               /// </summary>
               public const string LocationCodeDescription = "LOCDESC";

               /// <summary>
               /// Property for SalespersonName1
               /// </summary>
               public const string SalespersonName1 = "SALES1NAME";

               /// <summary>
               /// Property for SalespersonName2
               /// </summary>
               public const string SalespersonName2 = "SALES2NAME";

               /// <summary>
               /// Property for SalespersonName3
               /// </summary>
               public const string SalespersonName3 = "SALES3NAME";

               /// <summary>
               /// Property for SalespersonName4
               /// </summary>
               public const string SalespersonName4 = "SALES4NAME";

               /// <summary>
               /// Property for SalespersonName5
               /// </summary>
               public const string SalespersonName5 = "SALES5NAME";

               /// <summary>
               /// Property for TaxAuthority1Description
               /// </summary>
               public const string TaxAuthority1Description = "TAUTH1DESC";

               /// <summary>
               /// Property for TaxAuthority2Description
               /// </summary>
               public const string TaxAuthority2Description = "TAUTH2DESC";

               /// <summary>
               /// Property for TaxAuthority3Description
               /// </summary>
               public const string TaxAuthority3Description = "TAUTH3DESC";

               /// <summary>
               /// Property for TaxAuthority4Description
               /// </summary>
               public const string TaxAuthority4Description = "TAUTH4DESC";

               /// <summary>
               /// Property for TaxAuthority5Description
               /// </summary>
               public const string TaxAuthority5Description = "TAUTH5DESC";

               /// <summary>
               /// Property for TaxClass1Description
               /// </summary>
               public const string TaxClass1Description = "TCLAS1DESC";

               /// <summary>
               /// Property for TaxClass2Description
               /// </summary>
               public const string TaxClass2Description = "TCLAS2DESC";

               /// <summary>
               /// Property for TaxClass3Description
               /// </summary>
               public const string TaxClass3Description = "TCLAS3DESC";

               /// <summary>
               /// Property for TaxClass4Description
               /// </summary>
               public const string TaxClass4Description = "TCLAS4DESC";

               /// <summary>
               /// Property for TaxClass5Description
               /// </summary>
               public const string TaxClass5Description = "TCLAS5DESC";

               /// <summary>
               /// Property for InvoiceSourceCurrencyDesc
               /// </summary>
               public const string InvoiceSourceCurrencyDesc = "INSRCDESC";

               /// <summary>
               /// Property for InvoiceHomeCurrencyDesc
               /// </summary>
               public const string InvoiceHomeCurrencyDesc = "INHOMDESC";

               /// <summary>
               /// Property for InvoiceRateTypeDescription
               /// </summary>
               public const string InvoiceRateTypeDescription = "INRTTYDESC";

               /// <summary>
               /// Property for PaymentSourceCurrencyDesc
               /// </summary>
               public const string PaymentSourceCurrencyDesc = "PASRCDESC";

               /// <summary>
               /// Property for PaymentHomeCurrencyDesc
               /// </summary>
               public const string PaymentHomeCurrencyDesc = "PAHOMDESC";

               /// <summary>
               /// Property for PaymentRateTypeDescription
               /// </summary>
               public const string PaymentRateTypeDescription = "PARTTYDESC";

               /// <summary>
               /// Property for TotalTaxAmount1
               /// </summary>
               public const string TotalTaxAmount1 = "TAMOUNT1";

               /// <summary>
               /// Property for TotalTaxAmount2
               /// </summary>
               public const string TotalTaxAmount2 = "TAMOUNT2";

               /// <summary>
               /// Property for TotalTaxAmount3
               /// </summary>
               public const string TotalTaxAmount3 = "TAMOUNT3";

               /// <summary>
               /// Property for TotalTaxAmount4
               /// </summary>
               public const string TotalTaxAmount4 = "TAMOUNT4";

               /// <summary>
               /// Property for TotalTaxAmount5
               /// </summary>
               public const string TotalTaxAmount5 = "TAMOUNT5";

               /// <summary>
               /// Property for TotalTaxAmount
               /// </summary>
               public const string TotalTaxAmount = "INVTAXTOT";

               /// <summary>
               /// Property for InvoicePaymntInCustomerCurr
               /// </summary>
               public const string InvoicePaymntInCustomerCurr = "INVPAYMENT";

               /// <summary>
               /// Property for InvoicePaymentDiscount
               /// </summary>
               public const string InvoicePaymentDiscount = "INVPAYDISC";

               /// <summary>
               /// Property for InvoiceAmountDue
               /// </summary>
               public const string InvoiceAmountDue = "INVDUE";

               /// <summary>
               /// Property for AutoTaxCalculationStatus
               /// </summary>
               public const string AutoTaxCalculationStatus = "AUTOTAXCAL";

               /// <summary>
               /// Property for OrderPaymentsTotal
               /// </summary>
               public const string OrderPaymentsTotal = "ORDPAYTOT";

               /// <summary>
               /// Property for BillToEmail
               /// </summary>
               public const string BillToEmail = "BILEMAIL";

               /// <summary>
               /// Property for BillToContactPhone
               /// </summary>
               public const string BillToContactPhone = "BILPHONEC";

               /// <summary>
               /// Property for BillToContactFax
               /// </summary>
               public const string BillToContactFax = "BILFAXC";

               /// <summary>
               /// Property for BillToContactEmail
               /// </summary>
               public const string BillToContactEmail = "BILEMAILC";

               /// <summary>
               /// Property for ShipToEmail
               /// </summary>
               public const string ShipToEmail = "SHPEMAIL";

               /// <summary>
               /// Property for ShipToContactPhone
               /// </summary>
               public const string ShipToContactPhone = "SHPPHONEC";

               /// <summary>
               /// Property for ShipToContactFax
               /// </summary>
               public const string ShipToContactFax = "SHPFAXC";

               /// <summary>
               /// Property for ShipToContactEmail
               /// </summary>
               public const string ShipToContactEmail = "SHPEMAILC";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for RECALCTAX
               /// </summary>
               public const string RECALCTAX = "RECALCTAX";

               /// <summary>
               /// Property for DiscountAvailable
               /// </summary>
               public const string DiscountAvailable = "DISCAVAIL";

               /// <summary>
               /// Property for ShipmentHomeCurrency
               /// </summary>
               public const string ShipmentHomeCurrency = "SHHOMECURR";

               /// <summary>
               /// Property for ShipmentRateType
               /// </summary>
               public const string ShipmentRateType = "SHRATETYPE";

               /// <summary>
               /// Property for ShipmentSourceCurrency
               /// </summary>
               public const string ShipmentSourceCurrency = "SHSOURCURR";

               /// <summary>
               /// Property for ShipmentRateDate
               /// </summary>
               public const string ShipmentRateDate = "SHRATEDATE";

               /// <summary>
               /// Property for ShipmentRate
               /// </summary>
               public const string ShipmentRate = "SHRATE";

               /// <summary>
               /// Property for ShipmentSpread
               /// </summary>
               public const string ShipmentSpread = "SHSPREAD";

               /// <summary>
               /// Property for ShipmentRateDateMatching
               /// </summary>
               public const string ShipmentRateDateMatching = "SHDATEMTCH";

               /// <summary>
               /// Property for ShipmentRateOperator
               /// </summary>
               public const string ShipmentRateOperator = "SHRATEREP";

               /// <summary>
               /// Property for ShipmentRateOverrideFlag
               /// </summary>
               public const string ShipmentRateOverrideFlag = "SHRATEOVER";

               /// <summary>
               /// Property for ShipmentNumber
               /// </summary>
               public const string ShipmentNumber = "SHINUMBER";

               /// <summary>
               /// Property for GenerateFromMultipleShipments
               /// </summary>
               public const string GenerateFromMultipleShipments = "MULTISHI";

               /// <summary>
               /// Property for FromHowManyShipments
               /// </summary>
               public const string FromHowManyShipments = "SHIS";

               /// <summary>
               /// Property for InvoiceNumber
               /// </summary>
               public const string InvoiceNumber = "INVNUMBER";

               /// <summary>
               /// Property for PrepaymentBatchNumber
               /// </summary>
               public const string PrepaymentBatchNumber = "REBATCHNUM";

               /// <summary>
               /// Property for PrepaymentBankCode
               /// </summary>
               public const string PrepaymentBankCode = "BANKCODE";

               /// <summary>
               /// Property for PrepaymentReceiptType
               /// </summary>
               public const string PrepaymentReceiptType = "BANKRECTYP";

               /// <summary>
               /// Property for PrepaymentCheckDate
               /// </summary>
               public const string PrepaymentCheckDate = "CHECKDATE";

               /// <summary>
               /// Property for PrepaymentFiscalYear
               /// </summary>
               public const string PrepaymentFiscalYear = "CHKFISCYR";

               /// <summary>
               /// Property for PrepaymentFiscalPeriod
               /// </summary>
               public const string PrepaymentFiscalPeriod = "CHKFISCPER";

               /// <summary>
               /// Property for PrepaymentCheckNumber
               /// </summary>
               public const string PrepaymentCheckNumber = "CHECKNUM";

               /// <summary>
               /// Property for PrepaymentApplyTo
               /// </summary>
               public const string PrepaymentApplyTo = "APPLYTO";

               /// <summary>
               /// Property for PrepaymentInBankCurrency
               /// </summary>
               public const string PrepaymentInBankCurrency = "BANKPAYMNT";

               /// <summary>
               /// Property for PrepaymentHomeCurrency
               /// </summary>
               public const string PrepaymentHomeCurrency = "PAHOMECURR";

               /// <summary>
               /// Property for PrepaymentRateType
               /// </summary>
               public const string PrepaymentRateType = "PARATETYPE";

               /// <summary>
               /// Property for PrepaymentSourceCurrency
               /// </summary>
               public const string PrepaymentSourceCurrency = "PASOURCURR";

               /// <summary>
               /// Property for PrepaymentRateDate
               /// </summary>
               public const string PrepaymentRateDate = "PARATEDATE";

               /// <summary>
               /// Property for PrepaymentRate
               /// </summary>
               public const string PrepaymentRate = "PARATE";

               /// <summary>
               /// Property for PrepaymentSpread
               /// </summary>
               public const string PrepaymentSpread = "PASPREAD";

               /// <summary>
               /// Property for PrepaymentDateMatch
               /// </summary>
               public const string PrepaymentDateMatch = "PADATEMTCH";

               /// <summary>
               /// Property for PrepaymentRateOperator
               /// </summary>
               public const string PrepaymentRateOperator = "PARATEREP";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for GOCALCTAX
               /// </summary>
               public const string GOCALCTAX = "GOCALCTAX";

               /// <summary>
               /// Property for PerformCreditLimitCheck
               /// </summary>
               public const string PerformCreditLimitCheck = "GOCHKCRDT";

               /// <summary>
               /// Property for ShipAll
               /// </summary>
               public const string ShipAll = "GOSHIPALL";

               /// <summary>
               /// Property for DosConvert
               /// </summary>
               public const string DosConvert = "DOSCONVERT";

               /// <summary>
               /// Property for ForceTaxCalculation
               /// </summary>
               public const string ForceTaxCalculation = "GOFCALCTAX";

               /// <summary>
               /// Property for DistributeManualTax
               /// </summary>
               public const string DistributeManualTax = "GODISTTAX";

               /// <summary>
               /// Property for TaxCalculationInProgress
               /// </summary>
               public const string TaxCalculationInProgress = "TXCALCINPG";

               /// <summary>
               /// Property for InvoiceRunningTotal
               /// </summary>
               public const string InvoiceRunningTotal = "RUNNINGTOT";

               /// <summary>
               /// Property for DisplayRateWarning
               /// </summary>
               public const string DisplayRateWarning = "RTWARNMSG";

               /// <summary>
               /// Property for CustomerExists
               /// </summary>
               public const string CustomerExists = "CUSTEXIST";

               /// <summary>
               /// Property for RecalcMultiPaymentDates
               /// </summary>
               public const string RecalcMultiPaymentDates = "GOCALCPYDT";

               /// <summary>
               /// Property for GenerateInvFromSingleShip
               /// </summary>
               public const string GenerateInvFromSingleShip = "INV1SHIPMT";

               /// <summary>
               /// Property for GenerateInvFromMultShips
               /// </summary>
               public const string GenerateInvFromMultShips = "INVSHIPMTS";

               /// <summary>
               /// Property for ShipmentRateTypeDescription
               /// </summary>
               public const string ShipmentRateTypeDescription = "SHRTTYDESC";

               /// <summary>
               /// Property for ShipmentTrackingNumber
               /// </summary>
               public const string ShipmentTrackingNumber = "SHIPTRACK";

               /// <summary>
               /// Property for Allowpartialshipments
               /// </summary>
               public const string Allowpartialshipments = "SWPARTSHIP";

               /// <summary>
               /// Property for OverCreditLimit
               /// </summary>
               public const string OverCreditLimit = "OVERCREDIT";

               /// <summary>
               /// Property for ApprovedLimit
               /// </summary>
               public const string ApprovedLimit = "APPROVELMT";

               /// <summary>
               /// Property for AuthorizingUserID
               /// </summary>
               public const string AuthorizingUserID = "APPROVEBY";

               /// <summary>
               /// Property for AuthorizingUserPassword
               /// </summary>
               public const string AuthorizingUserPassword = "APPPASSWRD";

               /// <summary>
               /// Property for UserCanApproveCreditLift
               /// </summary>
               public const string UserCanApproveCreditLift = "GOAPPROSEC";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for ShipmentUniquifier
               /// </summary>
               public const string ShipmentUniquifier = "SHIUNIQ";

               /// <summary>
               /// Property for ProcessOIPCommand
               /// </summary>
               public const string ProcessOIPCommand = "PROCESSCMD";

               /// <summary>
               /// Property for DocumentDiscountBaseWithTax
               /// </summary>
               public const string DocumentDiscountBaseWithTax = "TERMDBWT";

               /// <summary>
               /// Property for DocumentDiscountBasewoTax
               /// </summary>
               public const string DocumentDiscountBasewoTax = "TERMDBNT";

               /// <summary>
               /// Property for ProcessOECommand
               /// </summary>
               public const string ProcessOECommand = "OECOMMAND";

               /// <summary>
               /// Property for UserEnteredApprovalAmount
               /// </summary>
               public const string UserEnteredApprovalAmount = "EDAPRVLMT";

               /// <summary>
               /// Property for CheckingCustomerCreditLimit
               /// </summary>
               public const string CheckingCustomerCreditLimit = "SWCHKLIMC";

               /// <summary>
               /// Property for CheckingCustomerAgingLimit
               /// </summary>
               public const string CheckingCustomerAgingLimit = "SWCHKODUEC";

               /// <summary>
               /// Property for CheckingNatAcctCreditLimit
               /// </summary>
               public const string CheckingNatAcctCreditLimit = "SWCHKLIMA";

               /// <summary>
               /// Property for CheckingNatAcctAgingLimit
               /// </summary>
               public const string CheckingNatAcctAgingLimit = "SWCHKODUEA";

               /// <summary>
               /// Property for CustomerIsOverCreditLimit
               /// </summary>
               public const string CustomerIsOverCreditLimit = "SWOVERLIMC";

               /// <summary>
               /// Property for CustomerIsOverAgingLimit
               /// </summary>
               public const string CustomerIsOverAgingLimit = "SWOVERDUEC";

               /// <summary>
               /// Property for NatAcctIsOverCreditLimit
               /// </summary>
               public const string NatAcctIsOverCreditLimit = "SWOVERLIMA";

               /// <summary>
               /// Property for NatAcctIsOverAgingLimit
               /// </summary>
               public const string NatAcctIsOverAgingLimit = "SWOVERDUEA";

               /// <summary>
               /// Property for CustomerCreditLimit
               /// </summary>
               public const string CustomerCreditLimit = "AMTLIMITC";

               /// <summary>
               /// Property for CustomerBalancePosted
               /// </summary>
               public const string CustomerBalancePosted = "AMTBALCUST";

               /// <summary>
               /// Property for CustomerDaysOverdue
               /// </summary>
               public const string CustomerDaysOverdue = "OVDUEDAYSC";

               /// <summary>
               /// Property for CustomerOverdueLimit
               /// </summary>
               public const string CustomerOverdueLimit = "OVDUELMTC";

               /// <summary>
               /// Property for CustomerBalanceOverdue
               /// </summary>
               public const string CustomerBalanceOverdue = "OVDUEBALC";

               /// <summary>
               /// Property for NatAcctCreditLimit
               /// </summary>
               public const string NatAcctCreditLimit = "AMTLIMITA";

               /// <summary>
               /// Property for NatAcctBalance
               /// </summary>
               public const string NatAcctBalance = "AMTBALACCT";

               /// <summary>
               /// Property for NatAcctDaysOverdue
               /// </summary>
               public const string NatAcctDaysOverdue = "OVDUEDAYSA";

               /// <summary>
               /// Property for NatAcctOverdueLimit
               /// </summary>
               public const string NatAcctOverdueLimit = "OVDUELMTA";

               /// <summary>
               /// Property for NatAcctBalanceOverdue
               /// </summary>
               public const string NatAcctBalanceOverdue = "OVDUEBALA";

               /// <summary>
               /// Property for ARPendingTransIncluded
               /// </summary>
               public const string ARPendingTransIncluded = "SWARPEND";

               /// <summary>
               /// Property for OEPendingTransIncluded
               /// </summary>
               public const string OEPendingTransIncluded = "SWOEPEND";

               /// <summary>
               /// Property for OtherPendingTransIncluded
               /// </summary>
               public const string OtherPendingTransIncluded = "SWXXPEND";

               /// <summary>
               /// Property for ARPendingBalance
               /// </summary>
               public const string ARPendingBalance = "AMTARPEND";

               /// <summary>
               /// Property for OEPendingBalance
               /// </summary>
               public const string OEPendingBalance = "AMTOEPEND";

               /// <summary>
               /// Property for OtherPendingBalance
               /// </summary>
               public const string OtherPendingBalance = "AMTXXPEND";

               /// <summary>
               /// Property for CustomerTotalOutstanding
               /// </summary>
               public const string CustomerTotalOutstanding = "AMTTOTCUST";

               /// <summary>
               /// Property for NatAcctTotalOutstanding
               /// </summary>
               public const string NatAcctTotalOutstanding = "AMTTOTACCT";

               /// <summary>
               /// Property for CustomerLimitLeft
               /// </summary>
               public const string CustomerLimitLeft = "AMTLEFTC";

               /// <summary>
               /// Property for NatAcctLimitLeft
               /// </summary>
               public const string NatAcctLimitLeft = "AMTLEFTA";

               /// <summary>
               /// Property for CustomerLimitExceeded
               /// </summary>
               public const string CustomerLimitExceeded = "AMTOVERC";

               /// <summary>
               /// Property for NatAcctLimitExceeded
               /// </summary>
               public const string NatAcctLimitExceeded = "AMTOVERA";

               /// <summary>
               /// Property for LastInvoiceAmount
               /// </summary>
               public const string LastInvoiceAmount = "AMTLASTIVT";

               /// <summary>
               /// Property for LastInvoiceDate
               /// </summary>
               public const string LastInvoiceDate = "DATELASTIV";

               /// <summary>
               /// Property for LastPaymentAmount
               /// </summary>
               public const string LastPaymentAmount = "AMTLASTPYT";

               /// <summary>
               /// Property for LastPaymentDate
               /// </summary>
               public const string LastPaymentDate = "DATELASTPA";

               /// <summary>
               /// Property for DrivenbyUI
               /// </summary>
               public const string DrivenbyUI = "DRIVENBYUI";

               /// <summary>
               /// Property for ItemDetailDiscountTotal
               /// </summary>
               public const string ItemDetailDiscountTotal = "ITEMDISTOT";

               /// <summary>
               /// Property for MiscChargeDetailDiscountTot
               /// </summary>
               public const string MiscChargeDetailDiscountTot = "MISCDISTOT";

               /// <summary>
               /// Property for DetailDiscountTotal
               /// </summary>
               public const string DetailDiscountTotal = "DTLDISCTOT";

               /// <summary>
               /// Property for DetailDiscountPercentage
               /// </summary>
               public const string DetailDiscountPercentage = "DTLDISCPER";

               /// <summary>
               /// Property for DocumentNetOfDetailDisc
               /// </summary>
               public const string DocumentNetOfDetailDisc = "INVNTDTDIS";

               /// <summary>
               /// Property for AutoCalcTaxReportingAmounts
               /// </summary>
               public const string AutoCalcTaxReportingAmounts = "ITRMETHOD";

               /// <summary>
               /// Property for TaxReportingTRCurrency
               /// </summary>
               public const string TaxReportingTRCurrency = "ITRCURRNCY";

               /// <summary>
               /// Property for TRRateType
               /// </summary>
               public const string TRRateType = "ITRRATTYPE";

               /// <summary>
               /// Property for TRRateDate
               /// </summary>
               public const string TRRateDate = "ITRRATDATE";

               /// <summary>
               /// Property for TRRate
               /// </summary>
               public const string TRRate = "ITRRATE";

               /// <summary>
               /// Property for TRSpread
               /// </summary>
               public const string TRSpread = "ITRSPREAD";

               /// <summary>
               /// Property for TRRateDateMatching
               /// </summary>
               public const string TRRateDateMatching = "ITRDATMTCH";

               /// <summary>
               /// Property for TRRateOperator
               /// </summary>
               public const string TRRateOperator = "ITRRATEOP";

               /// <summary>
               /// Property for TRRateOverrideFlag
               /// </summary>
               public const string TRRateOverrideFlag = "ITRRATOVER";

               /// <summary>
               /// Property for TRExcludedTaxAmount1
               /// </summary>
               public const string TRExcludedTaxAmount1 = "ITREAMNT1";

               /// <summary>
               /// Property for TRExcludedTaxAmount2
               /// </summary>
               public const string TRExcludedTaxAmount2 = "ITREAMNT2";

               /// <summary>
               /// Property for TRExcludedTaxAmount3
               /// </summary>
               public const string TRExcludedTaxAmount3 = "ITREAMNT3";

               /// <summary>
               /// Property for TRExcludedTaxAmount4
               /// </summary>
               public const string TRExcludedTaxAmount4 = "ITREAMNT4";

               /// <summary>
               /// Property for TRExcludedTaxAmount5
               /// </summary>
               public const string TRExcludedTaxAmount5 = "ITREAMNT5";

               /// <summary>
               /// Property for TRIncludedTaxAmount1
               /// </summary>
               public const string TRIncludedTaxAmount1 = "ITRIAMNT1";

               /// <summary>
               /// Property for TRIncludedTaxAmount2
               /// </summary>
               public const string TRIncludedTaxAmount2 = "ITRIAMNT2";

               /// <summary>
               /// Property for TRIncludedTaxAmount3
               /// </summary>
               public const string TRIncludedTaxAmount3 = "ITRIAMNT3";

               /// <summary>
               /// Property for TRIncludedTaxAmount4
               /// </summary>
               public const string TRIncludedTaxAmount4 = "ITRIAMNT4";

               /// <summary>
               /// Property for TRIncludedTaxAmount5
               /// </summary>
               public const string TRIncludedTaxAmount5 = "ITRIAMNT5";

               /// <summary>
               /// Property for TRTaxAmount1
               /// </summary>
               public const string TRTaxAmount1 = "ITRAMOUNT1";

               /// <summary>
               /// Property for TRTaxAmount2
               /// </summary>
               public const string TRTaxAmount2 = "ITRAMOUNT2";

               /// <summary>
               /// Property for TRTaxAmount3
               /// </summary>
               public const string TRTaxAmount3 = "ITRAMOUNT3";

               /// <summary>
               /// Property for TRTaxAmount4
               /// </summary>
               public const string TRTaxAmount4 = "ITRAMOUNT4";

               /// <summary>
               /// Property for TRTaxAmount5
               /// </summary>
               public const string TRTaxAmount5 = "ITRAMOUNT5";

               /// <summary>
               /// Property for TRExcludedTaxTotal
               /// </summary>
               public const string TRExcludedTaxTotal = "ITRETOTAL";

               /// <summary>
               /// Property for TRIncludedTaxTotal
               /// </summary>
               public const string TRIncludedTaxTotal = "ITRITOTAL";

               /// <summary>
               /// Property for TRTaxTotal
               /// </summary>
               public const string TRTaxTotal = "ITRTOTAL";

               /// <summary>
               /// Property for TaxReportingShipmentTRCurr
               /// </summary>
               public const string TaxReportingShipmentTRCurr = "STRCURRNCY";

               /// <summary>
               /// Property for TRShipmentRateType
               /// </summary>
               public const string TRShipmentRateType = "STRRATTYPE";

               /// <summary>
               /// Property for TRShipmentRateDate
               /// </summary>
               public const string TRShipmentRateDate = "STRRATDATE";

               /// <summary>
               /// Property for TRShipmentRate
               /// </summary>
               public const string TRShipmentRate = "STRRATE";

               /// <summary>
               /// Property for TRShipmentSpread
               /// </summary>
               public const string TRShipmentSpread = "STRSPREAD";

               /// <summary>
               /// Property for TRShipmentRateDateMatching
               /// </summary>
               public const string TRShipmentRateDateMatching = "STRDATMTCH";

               /// <summary>
               /// Property for TRShipmentRateOperator
               /// </summary>
               public const string TRShipmentRateOperator = "STRRATEOP";

               /// <summary>
               /// Property for TRShipmentRateOverrideFlag
               /// </summary>
               public const string TRShipmentRateOverrideFlag = "STRRATOVER";

               /// <summary>
               /// Property for TRShipmentCurrencyDescription
               /// </summary>
               public const string TRShipmentCurrencyDescription = "STRCURDESC";

               /// <summary>
               /// Property for TRInvoiceCurrencyDescription
               /// </summary>
               public const string TRInvoiceCurrencyDescription = "ITRCURDESC";

               /// <summary>
               /// Property for TRShipmentRateTypeDescriptio
               /// </summary>
               public const string TRShipmentRateTypeDescriptio = "STRRTYDESC";

               /// <summary>
               /// Property for TRInvoiceRateTypeDescription
               /// </summary>
               public const string TRInvoiceRateTypeDescription = "ITRRTYDESC";

               /// <summary>
               /// Property for TaxVersion
               /// </summary>
               public const string TaxVersion = "TAXVERSION";

               /// <summary>
               /// Property for PaymentType
               /// </summary>
               public const string PaymentType = "PAYMTYPE";

               /// <summary>
               /// Property for InvoiceDiscountAmountOverride
               /// </summary>
               public const string InvoiceDiscountAmountOverride = "DISAMTOVER";

               /// <summary>
               /// Property for JobRelated
               /// </summary>
               public const string JobRelated = "HASJOB";

               /// <summary>
               /// Property for JobRelatedDetailLines
               /// </summary>
               public const string JobRelatedDetailLines = "JOBLINES";

               /// <summary>
               /// Property for HasRetainage
               /// </summary>
               public const string HasRetainage = "HASRTG";

               /// <summary>
               /// Property for RetainageTerms
               /// </summary>
               public const string RetainageTerms = "RTGTERMS";

               /// <summary>
               /// Property for RetainageAmount
               /// </summary>
               public const string RetainageAmount = "RTGAMOUNT";

               /// <summary>
               /// Property for RetainagePercent
               /// </summary>
               public const string RetainagePercent = "RTGPERCENT";

               /// <summary>
               /// Property for RetainageExchangeRate
               /// </summary>
               public const string RetainageExchangeRate = "RTGRATE";

               /// <summary>
               /// Property for RetainageTaxBase1
               /// </summary>
               public const string RetainageTaxBase1 = "RTGTXBASE1";

               /// <summary>
               /// Property for RetainageTaxBase2
               /// </summary>
               public const string RetainageTaxBase2 = "RTGTXBASE2";

               /// <summary>
               /// Property for RetainageTaxBase3
               /// </summary>
               public const string RetainageTaxBase3 = "RTGTXBASE3";

               /// <summary>
               /// Property for RetainageTaxBase4
               /// </summary>
               public const string RetainageTaxBase4 = "RTGTXBASE4";

               /// <summary>
               /// Property for RetainageTaxBase5
               /// </summary>
               public const string RetainageTaxBase5 = "RTGTXBASE5";

               /// <summary>
               /// Property for RetainageTaxAmount1
               /// </summary>
               public const string RetainageTaxAmount1 = "RTGTXAMT1";

               /// <summary>
               /// Property for RetainageTaxAmount2
               /// </summary>
               public const string RetainageTaxAmount2 = "RTGTXAMT2";

               /// <summary>
               /// Property for RetainageTaxAmount3
               /// </summary>
               public const string RetainageTaxAmount3 = "RTGTXAMT3";

               /// <summary>
               /// Property for RetainageTaxAmount4
               /// </summary>
               public const string RetainageTaxAmount4 = "RTGTXAMT4";

               /// <summary>
               /// Property for RetainageTaxAmount5
               /// </summary>
               public const string RetainageTaxAmount5 = "RTGTXAMT5";

               /// <summary>
               /// Property for RetainageTermsDescription
               /// </summary>
               public const string RetainageTermsDescription = "RTGTERMDSC";

               /// <summary>
               /// Property for CustomerAccountSet
               /// </summary>
               public const string CustomerAccountSet = "CUSACCTSET";

               /// <summary>
               /// Property for CustomerAccountSetDescription
               /// </summary>
               public const string CustomerAccountSetDescription = "CUSACTDESC";

               /// <summary>
               /// Property for EnteredBy
               /// </summary>
               public const string EnteredBy = "ENTEREDBY";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for DATEBUS
               /// </summary>
               public const string DATEBUS = "DATEBUS";

               /// <summary>
               /// Property for ShipmentPaymentsTotal
               /// </summary>
               public const string ShipmentPaymentsTotal = "SHIPAYTOT";

               /// <summary>
               /// Property for PrepaymentDistributedAmount
               /// </summary>
               public const string PrepaymentDistributedAmount = "PAYDISTTOT";

               /// <summary>
               /// Property for PrepaymentUnappliedAmount
               /// </summary>
               public const string PrepaymentUnappliedAmount = "UNAPPLDPAY";

               /// <summary>
               /// Property for TotalRetainageTaxAmount
               /// </summary>
               public const string TotalRetainageTaxAmount = "RTXAMTTOT";

               /// <summary>
               /// Property for SageCRMOpportunityLines
               /// </summary>
               public const string SageCRMOpportunityLines = "OPPOLINES";

               /// <summary>
               /// Property for PreAuthExistsForInvoice
               /// </summary>
               public const string PreAuthExistsForInvoice = "PAUTHEXIST";

               /// <summary>
               /// Property for ExportDeclarationNumber
               /// </summary>
               public const string ExportDeclarationNumber = "EDN";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of Invoice Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for InvoiceUniquifier
               /// </summary>
               public const int InvoiceUniquifier = 1;

               /// <summary>
               /// Property Indexer for OrderNumber
               /// </summary>
               public const int OrderNumber = 2;

               /// <summary>
               /// Property Indexer for ICDayEndTransNumber
               /// </summary>
               public const int ICDayEndTransNumber = 3;

               /// <summary>
               /// Property Indexer for CustomerNumber
               /// </summary>
               public const int CustomerNumber = 4;

               /// <summary>
               /// Property Indexer for BillTo
               /// </summary>
               public const int BillTo = 5;

               /// <summary>
               /// Property Indexer for BillToAddress1
               /// </summary>
               public const int BillToAddress1 = 6;

               /// <summary>
               /// Property Indexer for BillToAddress2
               /// </summary>
               public const int BillToAddress2 = 7;

               /// <summary>
               /// Property Indexer for BillToAddress3
               /// </summary>
               public const int BillToAddress3 = 8;

               /// <summary>
               /// Property Indexer for BillToAddress4
               /// </summary>
               public const int BillToAddress4 = 9;

               /// <summary>
               /// Property Indexer for BillToCity
               /// </summary>
               public const int BillToCity = 10;

               /// <summary>
               /// Property Indexer for BillToState
               /// </summary>
               public const int BillToState = 11;

               /// <summary>
               /// Property Indexer for BillToZipCode
               /// </summary>
               public const int BillToZipCode = 12;

               /// <summary>
               /// Property Indexer for BillToCountry
               /// </summary>
               public const int BillToCountry = 13;

               /// <summary>
               /// Property Indexer for BillToPhone
               /// </summary>
               public const int BillToPhone = 14;

               /// <summary>
               /// Property Indexer for BillToFax
               /// </summary>
               public const int BillToFax = 15;

               /// <summary>
               /// Property Indexer for BillToContact
               /// </summary>
               public const int BillToContact = 16;

               /// <summary>
               /// Property Indexer for ShipToAddressCode
               /// </summary>
               public const int ShipToAddressCode = 17;

               /// <summary>
               /// Property Indexer for ShipTo
               /// </summary>
               public const int ShipTo = 18;

               /// <summary>
               /// Property Indexer for ShipToAddress1
               /// </summary>
               public const int ShipToAddress1 = 19;

               /// <summary>
               /// Property Indexer for ShipToAddress2
               /// </summary>
               public const int ShipToAddress2 = 20;

               /// <summary>
               /// Property Indexer for ShipToAddress3
               /// </summary>
               public const int ShipToAddress3 = 21;

               /// <summary>
               /// Property Indexer for ShipToAddress4
               /// </summary>
               public const int ShipToAddress4 = 22;

               /// <summary>
               /// Property Indexer for ShipToCity
               /// </summary>
               public const int ShipToCity = 23;

               /// <summary>
               /// Property Indexer for ShipToState
               /// </summary>
               public const int ShipToState = 24;

               /// <summary>
               /// Property Indexer for ShipToZipCode
               /// </summary>
               public const int ShipToZipCode = 25;

               /// <summary>
               /// Property Indexer for ShipToCountry
               /// </summary>
               public const int ShipToCountry = 26;

               /// <summary>
               /// Property Indexer for ShipToPhone
               /// </summary>
               public const int ShipToPhone = 27;

               /// <summary>
               /// Property Indexer for ShipToFax
               /// </summary>
               public const int ShipToFax = 28;

               /// <summary>
               /// Property Indexer for ShipToContact
               /// </summary>
               public const int ShipToContact = 29;

               /// <summary>
               /// Property Indexer for CustomerDiscountLevel
               /// </summary>
               public const int CustomerDiscountLevel = 30;

               /// <summary>
               /// Property Indexer for PriceListCode
               /// </summary>
               public const int PriceListCode = 31;

               /// <summary>
               /// Property Indexer for PurchaseOrderNumber
               /// </summary>
               public const int PurchaseOrderNumber = 32;

               /// <summary>
               /// Property Indexer for Territory
               /// </summary>
               public const int Territory = 33;

               /// <summary>
               /// Property Indexer for TermsCode
               /// </summary>
               public const int TermsCode = 34;

               /// <summary>
               /// Property Indexer for TotalTermsAmountDue
               /// </summary>
               public const int TotalTermsAmountDue = 35;

               /// <summary>
               /// Property Indexer for TermsRateOverride
               /// </summary>
               public const int TermsRateOverride = 36;

               /// <summary>
               /// Property Indexer for Reference
               /// </summary>
               public const int Reference = 37;

               /// <summary>
               /// Property Indexer for OrderDate
               /// </summary>
               public const int OrderDate = 38;

               /// <summary>
               /// Property Indexer for ShipViaCode
               /// </summary>
               public const int ShipViaCode = 39;

               /// <summary>
               /// Property Indexer for ShipViaCodeDescription
               /// </summary>
               public const int ShipViaCodeDescription = 40;

               /// <summary>
               /// Property Indexer for FreeOnBoardPoint
               /// </summary>
               public const int FreeOnBoardPoint = 41;

               /// <summary>
               /// Property Indexer for TemplateCode
               /// </summary>
               public const int TemplateCode = 42;

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 43;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 44;

               /// <summary>
               /// Property Indexer for Comment
               /// </summary>
               public const int Comment = 45;

               /// <summary>
               /// Property Indexer for ShipmentDate
               /// </summary>
               public const int ShipmentDate = 46;

               /// <summary>
               /// Property Indexer for InvoiceDate
               /// </summary>
               public const int InvoiceDate = 47;

               /// <summary>
               /// Property Indexer for InvoiceFiscalYear
               /// </summary>
               public const int InvoiceFiscalYear = 48;

               /// <summary>
               /// Property Indexer for InvoiceFiscalPeriod
               /// </summary>
               public const int InvoiceFiscalPeriod = 49;

               /// <summary>
               /// Property Indexer for NumberOfLinesInInvoice
               /// </summary>
               public const int NumberOfLinesInInvoice = 50;

               /// <summary>
               /// Property Indexer for NumberOfLabels
               /// </summary>
               public const int NumberOfLabels = 51;

               /// <summary>
               /// Property Indexer for NumberOfTermsPayments
               /// </summary>
               public const int NumberOfTermsPayments = 52;

               /// <summary>
               /// Property Indexer for TermsPaymentsAsOfDate
               /// </summary>
               public const int TermsPaymentsAsOfDate = 53;

               /// <summary>
               /// Property Indexer for InvoiceTotalEstimatedWeight
               /// </summary>
               public const int InvoiceTotalEstimatedWeight = 54;

               /// <summary>
               /// Property Indexer for NextDetailNumber
               /// </summary>
               public const int NextDetailNumber = 55;

               /// <summary>
               /// Property Indexer for InvoiceStatus
               /// </summary>
               public const int InvoiceStatus = 56;

               /// <summary>
               /// Property Indexer for InvoicePrinted
               /// </summary>
               public const int InvoicePrinted = 57;

               /// <summary>
               /// Property Indexer for InvoiceDisconMiscCharges
               /// </summary>
               public const int InvoiceDisconMiscCharges = 58;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for POSTDATE
               /// </summary>
               public const int PostingDate = 59;

               /// <summary>
               /// Property Indexer for CompletionDate
               /// </summary>
               public const int CompletionDate = 60;

               /// <summary>
               /// Property Indexer for RequiresShippingLabels
               /// </summary>
               public const int RequiresShippingLabels = 61;

               /// <summary>
               /// Property Indexer for ShippingLabelsPrinted
               /// </summary>
               public const int ShippingLabelsPrinted = 62;

               /// <summary>
               /// Property Indexer for InvoiceTotalBeforeTax
               /// </summary>
               public const int InvoiceTotalBeforeTax = 63;

               /// <summary>
               /// Property Indexer for InvoiceIncludedTaxTotAmount
               /// </summary>
               public const int InvoiceIncludedTaxTotAmount = 64;

               /// <summary>
               /// Property Indexer for InvoiceItemTotalAmount
               /// </summary>
               public const int InvoiceItemTotalAmount = 65;

               /// <summary>
               /// Property Indexer for InvoiceDiscountBase
               /// </summary>
               public const int InvoiceDiscountBase = 66;

               /// <summary>
               /// Property Indexer for InvoiceDiscountPercentage
               /// </summary>
               public const int InvoiceDiscountPercentage = 67;

               /// <summary>
               /// Property Indexer for InvoiceDiscountAmount
               /// </summary>
               public const int InvoiceDiscountAmount = 68;

               /// <summary>
               /// Property Indexer for InvoiceTotalMiscCharges
               /// </summary>
               public const int InvoiceTotalMiscCharges = 69;

               /// <summary>
               /// Property Indexer for InvoiceSubtotalAmount
               /// </summary>
               public const int InvoiceSubtotalAmount = 70;

               /// <summary>
               /// Property Indexer for InvoiceTotalWithInvoiceDisc
               /// </summary>
               public const int InvoiceTotalWithInvoiceDisc = 71;

               /// <summary>
               /// Property Indexer for InvoiceExcludedTaxTotAmount
               /// </summary>
               public const int InvoiceExcludedTaxTotAmount = 72;

               /// <summary>
               /// Property Indexer for InvoiceTotalWithTax
               /// </summary>
               public const int InvoiceTotalWithTax = 73;

               /// <summary>
               /// Property Indexer for InvoiceHomeCurrency
               /// </summary>
               public const int InvoiceHomeCurrency = 74;

               /// <summary>
               /// Property Indexer for InvoiceRateType
               /// </summary>
               public const int InvoiceRateType = 75;

               /// <summary>
               /// Property Indexer for InvoiceSourceCurrency
               /// </summary>
               public const int InvoiceSourceCurrency = 76;

               /// <summary>
               /// Property Indexer for InvoiceRateDate
               /// </summary>
               public const int InvoiceRateDate = 77;

               /// <summary>
               /// Property Indexer for InvoiceRate
               /// </summary>
               public const int InvoiceRate = 78;

               /// <summary>
               /// Property Indexer for InvoiceSpread
               /// </summary>
               public const int InvoiceSpread = 79;

               /// <summary>
               /// Property Indexer for InvoiceRateDateMatching
               /// </summary>
               public const int InvoiceRateDateMatching = 80;

               /// <summary>
               /// Property Indexer for InvoiceRateOperator
               /// </summary>
               public const int InvoiceRateOperator = 81;

               /// <summary>
               /// Property Indexer for InvoiceRateOverrideFlag
               /// </summary>
               public const int InvoiceRateOverrideFlag = 82;

               /// <summary>
               /// Property Indexer for Salesperson1
               /// </summary>
               public const int Salesperson1 = 83;

               /// <summary>
               /// Property Indexer for Salesperson2
               /// </summary>
               public const int Salesperson2 = 84;

               /// <summary>
               /// Property Indexer for Salesperson3
               /// </summary>
               public const int Salesperson3 = 85;

               /// <summary>
               /// Property Indexer for Salesperson4
               /// </summary>
               public const int Salesperson4 = 86;

               /// <summary>
               /// Property Indexer for Salesperson5
               /// </summary>
               public const int Salesperson5 = 87;

               /// <summary>
               /// Property Indexer for SalesPercentage1
               /// </summary>
               public const int SalesPercentage1 = 88;

               /// <summary>
               /// Property Indexer for SalesPercentage2
               /// </summary>
               public const int SalesPercentage2 = 89;

               /// <summary>
               /// Property Indexer for SalesPercentage3
               /// </summary>
               public const int SalesPercentage3 = 90;

               /// <summary>
               /// Property Indexer for SalesPercentage4
               /// </summary>
               public const int SalesPercentage4 = 91;

               /// <summary>
               /// Property Indexer for SalesPercentage5
               /// </summary>
               public const int SalesPercentage5 = 92;

               /// <summary>
               /// Property Indexer for TaxOverridden
               /// </summary>
               public const int TaxOverridden = 93;

               /// <summary>
               /// Property Indexer for TaxGroup
               /// </summary>
               public const int TaxGroup = 94;

               /// <summary>
               /// Property Indexer for TaxAuthority1
               /// </summary>
               public const int TaxAuthority1 = 95;

               /// <summary>
               /// Property Indexer for TaxAuthority2
               /// </summary>
               public const int TaxAuthority2 = 96;

               /// <summary>
               /// Property Indexer for TaxAuthority3
               /// </summary>
               public const int TaxAuthority3 = 97;

               /// <summary>
               /// Property Indexer for TaxAuthority4
               /// </summary>
               public const int TaxAuthority4 = 98;

               /// <summary>
               /// Property Indexer for TaxAuthority5
               /// </summary>
               public const int TaxAuthority5 = 99;

               /// <summary>
               /// Property Indexer for TaxClass1
               /// </summary>
               public const int TaxClass1 = 100;

               /// <summary>
               /// Property Indexer for TaxClass2
               /// </summary>
               public const int TaxClass2 = 101;

               /// <summary>
               /// Property Indexer for TaxClass3
               /// </summary>
               public const int TaxClass3 = 102;

               /// <summary>
               /// Property Indexer for TaxClass4
               /// </summary>
               public const int TaxClass4 = 103;

               /// <summary>
               /// Property Indexer for TaxClass5
               /// </summary>
               public const int TaxClass5 = 104;

               /// <summary>
               /// Property Indexer for TaxBase1
               /// </summary>
               public const int TaxBase1 = 105;

               /// <summary>
               /// Property Indexer for TaxBase2
               /// </summary>
               public const int TaxBase2 = 106;

               /// <summary>
               /// Property Indexer for TaxBase3
               /// </summary>
               public const int TaxBase3 = 107;

               /// <summary>
               /// Property Indexer for TaxBase4
               /// </summary>
               public const int TaxBase4 = 108;

               /// <summary>
               /// Property Indexer for TaxBase5
               /// </summary>
               public const int TaxBase5 = 109;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount1
               /// </summary>
               public const int ExcludedTaxAmount1 = 110;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount2
               /// </summary>
               public const int ExcludedTaxAmount2 = 111;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount3
               /// </summary>
               public const int ExcludedTaxAmount3 = 112;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount4
               /// </summary>
               public const int ExcludedTaxAmount4 = 113;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount5
               /// </summary>
               public const int ExcludedTaxAmount5 = 114;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount1
               /// </summary>
               public const int IncludedTaxAmount1 = 115;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount2
               /// </summary>
               public const int IncludedTaxAmount2 = 116;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount3
               /// </summary>
               public const int IncludedTaxAmount3 = 117;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount4
               /// </summary>
               public const int IncludedTaxAmount4 = 118;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount5
               /// </summary>
               public const int IncludedTaxAmount5 = 119;

               /// <summary>
               /// Property Indexer for Registration1
               /// </summary>
               public const int Registration1 = 120;

               /// <summary>
               /// Property Indexer for Registration2
               /// </summary>
               public const int Registration2 = 121;

               /// <summary>
               /// Property Indexer for Registration3
               /// </summary>
               public const int Registration3 = 122;

               /// <summary>
               /// Property Indexer for Registration4
               /// </summary>
               public const int Registration4 = 123;

               /// <summary>
               /// Property Indexer for Registration5
               /// </summary>
               public const int Registration5 = 124;

               /// <summary>
               /// Property Indexer for PriceListCodeDescription
               /// </summary>
               public const int PriceListCodeDescription = 133;

               /// <summary>
               /// Property Indexer for TermsCodeDescription
               /// </summary>
               public const int TermsCodeDescription = 134;

               /// <summary>
               /// Property Indexer for TaxGroupCodeDescription
               /// </summary>
               public const int TaxGroupCodeDescription = 135;

               /// <summary>
               /// Property Indexer for LocationCodeDescription
               /// </summary>
               public const int LocationCodeDescription = 136;

               /// <summary>
               /// Property Indexer for SalespersonName1
               /// </summary>
               public const int SalespersonName1 = 137;

               /// <summary>
               /// Property Indexer for SalespersonName2
               /// </summary>
               public const int SalespersonName2 = 138;

               /// <summary>
               /// Property Indexer for SalespersonName3
               /// </summary>
               public const int SalespersonName3 = 139;

               /// <summary>
               /// Property Indexer for SalespersonName4
               /// </summary>
               public const int SalespersonName4 = 140;

               /// <summary>
               /// Property Indexer for SalespersonName5
               /// </summary>
               public const int SalespersonName5 = 141;

               /// <summary>
               /// Property Indexer for TaxAuthority1Description
               /// </summary>
               public const int TaxAuthority1Description = 142;

               /// <summary>
               /// Property Indexer for TaxAuthority2Description
               /// </summary>
               public const int TaxAuthority2Description = 143;

               /// <summary>
               /// Property Indexer for TaxAuthority3Description
               /// </summary>
               public const int TaxAuthority3Description = 144;

               /// <summary>
               /// Property Indexer for TaxAuthority4Description
               /// </summary>
               public const int TaxAuthority4Description = 145;

               /// <summary>
               /// Property Indexer for TaxAuthority5Description
               /// </summary>
               public const int TaxAuthority5Description = 146;

               /// <summary>
               /// Property Indexer for TaxClass1Description
               /// </summary>
               public const int TaxClass1Description = 147;

               /// <summary>
               /// Property Indexer for TaxClass2Description
               /// </summary>
               public const int TaxClass2Description = 148;

               /// <summary>
               /// Property Indexer for TaxClass3Description
               /// </summary>
               public const int TaxClass3Description = 149;

               /// <summary>
               /// Property Indexer for TaxClass4Description
               /// </summary>
               public const int TaxClass4Description = 150;

               /// <summary>
               /// Property Indexer for TaxClass5Description
               /// </summary>
               public const int TaxClass5Description = 151;

               /// <summary>
               /// Property Indexer for InvoiceSourceCurrencyDesc
               /// </summary>
               public const int InvoiceSourceCurrencyDesc = 152;

               /// <summary>
               /// Property Indexer for InvoiceHomeCurrencyDesc
               /// </summary>
               public const int InvoiceHomeCurrencyDesc = 153;

               /// <summary>
               /// Property Indexer for InvoiceRateTypeDescription
               /// </summary>
               public const int InvoiceRateTypeDescription = 154;

               /// <summary>
               /// Property Indexer for PaymentSourceCurrencyDesc
               /// </summary>
               public const int PaymentSourceCurrencyDesc = 155;

               /// <summary>
               /// Property Indexer for PaymentHomeCurrencyDesc
               /// </summary>
               public const int PaymentHomeCurrencyDesc = 156;

               /// <summary>
               /// Property Indexer for PaymentRateTypeDescription
               /// </summary>
               public const int PaymentRateTypeDescription = 157;

               /// <summary>
               /// Property Indexer for TotalTaxAmount1
               /// </summary>
               public const int TotalTaxAmount1 = 158;

               /// <summary>
               /// Property Indexer for TotalTaxAmount2
               /// </summary>
               public const int TotalTaxAmount2 = 159;

               /// <summary>
               /// Property Indexer for TotalTaxAmount3
               /// </summary>
               public const int TotalTaxAmount3 = 160;

               /// <summary>
               /// Property Indexer for TotalTaxAmount4
               /// </summary>
               public const int TotalTaxAmount4 = 161;

               /// <summary>
               /// Property Indexer for TotalTaxAmount5
               /// </summary>
               public const int TotalTaxAmount5 = 162;

               /// <summary>
               /// Property Indexer for TotalTaxAmount
               /// </summary>
               public const int TotalTaxAmount = 163;

               /// <summary>
               /// Property Indexer for InvoicePaymntInCustomerCurr
               /// </summary>
               public const int InvoicePaymntInCustomerCurr = 164;

               /// <summary>
               /// Property Indexer for InvoicePaymentDiscount
               /// </summary>
               public const int InvoicePaymentDiscount = 165;

               /// <summary>
               /// Property Indexer for InvoiceAmountDue
               /// </summary>
               public const int InvoiceAmountDue = 166;

               /// <summary>
               /// Property Indexer for AutoTaxCalculationStatus
               /// </summary>
               public const int AutoTaxCalculationStatus = 167;

               /// <summary>
               /// Property Indexer for OrderPaymentsTotal
               /// </summary>
               public const int OrderPaymentsTotal = 168;

               /// <summary>
               /// Property Indexer for BillToEmail
               /// </summary>
               public const int BillToEmail = 169;

               /// <summary>
               /// Property Indexer for BillToContactPhone
               /// </summary>
               public const int BillToContactPhone = 170;

               /// <summary>
               /// Property Indexer for BillToContactFax
               /// </summary>
               public const int BillToContactFax = 171;

               /// <summary>
               /// Property Indexer for BillToContactEmail
               /// </summary>
               public const int BillToContactEmail = 172;

               /// <summary>
               /// Property Indexer for ShipToEmail
               /// </summary>
               public const int ShipToEmail = 173;

               /// <summary>
               /// Property Indexer for ShipToContactPhone
               /// </summary>
               public const int ShipToContactPhone = 174;

               /// <summary>
               /// Property Indexer for ShipToContactFax
               /// </summary>
               public const int ShipToContactFax = 175;

               /// <summary>
               /// Property Indexer for ShipToContactEmail
               /// </summary>
               public const int ShipToContactEmail = 176;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for RECALCTAX
               /// </summary>
               public const int RECALCTAX = 177;

               /// <summary>
               /// Property Indexer for DiscountAvailable
               /// </summary>
               public const int DiscountAvailable = 178;

               /// <summary>
               /// Property Indexer for ShipmentHomeCurrency
               /// </summary>
               public const int ShipmentHomeCurrency = 179;

               /// <summary>
               /// Property Indexer for ShipmentRateType
               /// </summary>
               public const int ShipmentRateType = 180;

               /// <summary>
               /// Property Indexer for ShipmentSourceCurrency
               /// </summary>
               public const int ShipmentSourceCurrency = 181;

               /// <summary>
               /// Property Indexer for ShipmentRateDate
               /// </summary>
               public const int ShipmentRateDate = 182;

               /// <summary>
               /// Property Indexer for ShipmentRate
               /// </summary>
               public const int ShipmentRate = 183;

               /// <summary>
               /// Property Indexer for ShipmentSpread
               /// </summary>
               public const int ShipmentSpread = 184;

               /// <summary>
               /// Property Indexer for ShipmentRateDateMatching
               /// </summary>
               public const int ShipmentRateDateMatching = 185;

               /// <summary>
               /// Property Indexer for ShipmentRateOperator
               /// </summary>
               public const int ShipmentRateOperator = 186;

               /// <summary>
               /// Property Indexer for ShipmentRateOverrideFlag
               /// </summary>
               public const int ShipmentRateOverrideFlag = 187;

               /// <summary>
               /// Property Indexer for ShipmentNumber
               /// </summary>
               public const int ShipmentNumber = 188;

               /// <summary>
               /// Property Indexer for GenerateFromMultipleShipments
               /// </summary>
               public const int GenerateFromMultipleShipments = 189;

               /// <summary>
               /// Property Indexer for FromHowManyShipments
               /// </summary>
               public const int FromHowManyShipments = 190;

               /// <summary>
               /// Property Indexer for InvoiceNumber
               /// </summary>
               public const int InvoiceNumber = 191;

               /// <summary>
               /// Property Indexer for PrepaymentBatchNumber
               /// </summary>
               public const int PrepaymentBatchNumber = 192;

               /// <summary>
               /// Property Indexer for PrepaymentBankCode
               /// </summary>
               public const int PrepaymentBankCode = 193;

               /// <summary>
               /// Property Indexer for PrepaymentReceiptType
               /// </summary>
               public const int PrepaymentReceiptType = 194;

               /// <summary>
               /// Property Indexer for PrepaymentCheckDate
               /// </summary>
               public const int PrepaymentCheckDate = 195;

               /// <summary>
               /// Property Indexer for PrepaymentFiscalYear
               /// </summary>
               public const int PrepaymentFiscalYear = 196;

               /// <summary>
               /// Property Indexer for PrepaymentFiscalPeriod
               /// </summary>
               public const int PrepaymentFiscalPeriod = 197;

               /// <summary>
               /// Property Indexer for PrepaymentCheckNumber
               /// </summary>
               public const int PrepaymentCheckNumber = 198;

               /// <summary>
               /// Property Indexer for PrepaymentApplyTo
               /// </summary>
               public const int PrepaymentApplyTo = 199;

               /// <summary>
               /// Property Indexer for PrepaymentInBankCurrency
               /// </summary>
               public const int PrepaymentInBankCurrency = 200;

               /// <summary>
               /// Property Indexer for PrepaymentHomeCurrency
               /// </summary>
               public const int PrepaymentHomeCurrency = 201;

               /// <summary>
               /// Property Indexer for PrepaymentRateType
               /// </summary>
               public const int PrepaymentRateType = 202;

               /// <summary>
               /// Property Indexer for PrepaymentSourceCurrency
               /// </summary>
               public const int PrepaymentSourceCurrency = 203;

               /// <summary>
               /// Property Indexer for PrepaymentRateDate
               /// </summary>
               public const int PrepaymentRateDate = 204;

               /// <summary>
               /// Property Indexer for PrepaymentRate
               /// </summary>
               public const int PrepaymentRate = 205;

               /// <summary>
               /// Property Indexer for PrepaymentSpread
               /// </summary>
               public const int PrepaymentSpread = 206;

               /// <summary>
               /// Property Indexer for PrepaymentDateMatch
               /// </summary>
               public const int PrepaymentDateMatch = 207;

               /// <summary>
               /// Property Indexer for PrepaymentRateOperator
               /// </summary>
               public const int PrepaymentRateOperator = 208;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for GOCALCTAX
               /// </summary>
               public const int GOCALCTAX = 209;

               /// <summary>
               /// Property Indexer for PerformCreditLimitCheck
               /// </summary>
               public const int PerformCreditLimitCheck = 210;

               /// <summary>
               /// Property Indexer for ShipAll
               /// </summary>
               public const int ShipAll = 211;

               /// <summary>
               /// Property Indexer for DosConvert
               /// </summary>
               public const int DosConvert = 212;

               /// <summary>
               /// Property Indexer for ForceTaxCalculation
               /// </summary>
               public const int ForceTaxCalculation = 213;

               /// <summary>
               /// Property Indexer for DistributeManualTax
               /// </summary>
               public const int DistributeManualTax = 214;

               /// <summary>
               /// Property Indexer for TaxCalculationInProgress
               /// </summary>
               public const int TaxCalculationInProgress = 215;

               /// <summary>
               /// Property Indexer for InvoiceRunningTotal
               /// </summary>
               public const int InvoiceRunningTotal = 216;

               /// <summary>
               /// Property Indexer for DisplayRateWarning
               /// </summary>
               public const int DisplayRateWarning = 227;

               /// <summary>
               /// Property Indexer for CustomerExists
               /// </summary>
               public const int CustomerExists = 228;

               /// <summary>
               /// Property Indexer for RecalcMultiPaymentDates
               /// </summary>
               public const int RecalcMultiPaymentDates = 229;

               /// <summary>
               /// Property Indexer for GenerateInvFromSingleShip
               /// </summary>
               public const int GenerateInvFromSingleShip = 230;

               /// <summary>
               /// Property Indexer for GenerateInvFromMultShips
               /// </summary>
               public const int GenerateInvFromMultShips = 231;

               /// <summary>
               /// Property Indexer for ShipmentRateTypeDescription
               /// </summary>
               public const int ShipmentRateTypeDescription = 233;

               /// <summary>
               /// Property Indexer for ShipmentTrackingNumber
               /// </summary>
               public const int ShipmentTrackingNumber = 234;

               /// <summary>
               /// Property Indexer for Allowpartialshipments
               /// </summary>
               public const int Allowpartialshipments = 235;

               /// <summary>
               /// Property Indexer for OverCreditLimit
               /// </summary>
               public const int OverCreditLimit = 236;

               /// <summary>
               /// Property Indexer for ApprovedLimit
               /// </summary>
               public const int ApprovedLimit = 237;

               /// <summary>
               /// Property Indexer for AuthorizingUserID
               /// </summary>
               public const int AuthorizingUserID = 238;

               /// <summary>
               /// Property Indexer for AuthorizingUserPassword
               /// </summary>
               public const int AuthorizingUserPassword = 239;

               /// <summary>
               /// Property Indexer for UserCanApproveCreditLift
               /// </summary>
               public const int UserCanApproveCreditLift = 240;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 241;

               /// <summary>
               /// Property Indexer for ShipmentUniquifier
               /// </summary>
               public const int ShipmentUniquifier = 242;

               /// <summary>
               /// Property Indexer for ProcessOIPCommand
               /// </summary>
               public const int ProcessOIPCommand = 243;

               /// <summary>
               /// Property Indexer for DocumentDiscountBaseWithTax
               /// </summary>
               public const int DocumentDiscountBaseWithTax = 244;

               /// <summary>
               /// Property Indexer for DocumentDiscountBasewoTax
               /// </summary>
               public const int DocumentDiscountBasewoTax = 245;

               /// <summary>
               /// Property Indexer for ProcessOECommand
               /// </summary>
               public const int ProcessOECommand = 246;

               /// <summary>
               /// Property Indexer for UserEnteredApprovalAmount
               /// </summary>
               public const int UserEnteredApprovalAmount = 247;

               /// <summary>
               /// Property Indexer for CheckingCustomerCreditLimit
               /// </summary>
               public const int CheckingCustomerCreditLimit = 248;

               /// <summary>
               /// Property Indexer for CheckingCustomerAgingLimit
               /// </summary>
               public const int CheckingCustomerAgingLimit = 249;

               /// <summary>
               /// Property Indexer for CheckingNatAcctCreditLimit
               /// </summary>
               public const int CheckingNatAcctCreditLimit = 250;

               /// <summary>
               /// Property Indexer for CheckingNatAcctAgingLimit
               /// </summary>
               public const int CheckingNatAcctAgingLimit = 251;

               /// <summary>
               /// Property Indexer for CustomerIsOverCreditLimit
               /// </summary>
               public const int CustomerIsOverCreditLimit = 252;

               /// <summary>
               /// Property Indexer for CustomerIsOverAgingLimit
               /// </summary>
               public const int CustomerIsOverAgingLimit = 253;

               /// <summary>
               /// Property Indexer for NatAcctIsOverCreditLimit
               /// </summary>
               public const int NatAcctIsOverCreditLimit = 254;

               /// <summary>
               /// Property Indexer for NatAcctIsOverAgingLimit
               /// </summary>
               public const int NatAcctIsOverAgingLimit = 255;

               /// <summary>
               /// Property Indexer for CustomerCreditLimit
               /// </summary>
               public const int CustomerCreditLimit = 256;

               /// <summary>
               /// Property Indexer for CustomerBalancePosted
               /// </summary>
               public const int CustomerBalancePosted = 257;

               /// <summary>
               /// Property Indexer for CustomerDaysOverdue
               /// </summary>
               public const int CustomerDaysOverdue = 258;

               /// <summary>
               /// Property Indexer for CustomerOverdueLimit
               /// </summary>
               public const int CustomerOverdueLimit = 259;

               /// <summary>
               /// Property Indexer for CustomerBalanceOverdue
               /// </summary>
               public const int CustomerBalanceOverdue = 260;

               /// <summary>
               /// Property Indexer for NatAcctCreditLimit
               /// </summary>
               public const int NatAcctCreditLimit = 261;

               /// <summary>
               /// Property Indexer for NatAcctBalance
               /// </summary>
               public const int NatAcctBalance = 262;

               /// <summary>
               /// Property Indexer for NatAcctDaysOverdue
               /// </summary>
               public const int NatAcctDaysOverdue = 263;

               /// <summary>
               /// Property Indexer for NatAcctOverdueLimit
               /// </summary>
               public const int NatAcctOverdueLimit = 264;

               /// <summary>
               /// Property Indexer for NatAcctBalanceOverdue
               /// </summary>
               public const int NatAcctBalanceOverdue = 265;

               /// <summary>
               /// Property Indexer for ARPendingTransIncluded
               /// </summary>
               public const int ARPendingTransIncluded = 266;

               /// <summary>
               /// Property Indexer for OEPendingTransIncluded
               /// </summary>
               public const int OEPendingTransIncluded = 267;

               /// <summary>
               /// Property Indexer for OtherPendingTransIncluded
               /// </summary>
               public const int OtherPendingTransIncluded = 268;

               /// <summary>
               /// Property Indexer for ARPendingBalance
               /// </summary>
               public const int ARPendingBalance = 269;

               /// <summary>
               /// Property Indexer for OEPendingBalance
               /// </summary>
               public const int OEPendingBalance = 270;

               /// <summary>
               /// Property Indexer for OtherPendingBalance
               /// </summary>
               public const int OtherPendingBalance = 271;

               /// <summary>
               /// Property Indexer for CustomerTotalOutstanding
               /// </summary>
               public const int CustomerTotalOutstanding = 272;

               /// <summary>
               /// Property Indexer for NatAcctTotalOutstanding
               /// </summary>
               public const int NatAcctTotalOutstanding = 273;

               /// <summary>
               /// Property Indexer for CustomerLimitLeft
               /// </summary>
               public const int CustomerLimitLeft = 274;

               /// <summary>
               /// Property Indexer for NatAcctLimitLeft
               /// </summary>
               public const int NatAcctLimitLeft = 275;

               /// <summary>
               /// Property Indexer for CustomerLimitExceeded
               /// </summary>
               public const int CustomerLimitExceeded = 276;

               /// <summary>
               /// Property Indexer for NatAcctLimitExceeded
               /// </summary>
               public const int NatAcctLimitExceeded = 277;

               /// <summary>
               /// Property Indexer for LastInvoiceAmount
               /// </summary>
               public const int LastInvoiceAmount = 278;

               /// <summary>
               /// Property Indexer for LastInvoiceDate
               /// </summary>
               public const int LastInvoiceDate = 279;

               /// <summary>
               /// Property Indexer for LastPaymentAmount
               /// </summary>
               public const int LastPaymentAmount = 280;

               /// <summary>
               /// Property Indexer for LastPaymentDate
               /// </summary>
               public const int LastPaymentDate = 281;

               /// <summary>
               /// Property Indexer for DrivenbyUI
               /// </summary>
               public const int DrivenbyUI = 282;

               /// <summary>
               /// Property Indexer for ItemDetailDiscountTotal
               /// </summary>
               public const int ItemDetailDiscountTotal = 283;

               /// <summary>
               /// Property Indexer for MiscChargeDetailDiscountTot
               /// </summary>
               public const int MiscChargeDetailDiscountTot = 284;

               /// <summary>
               /// Property Indexer for DetailDiscountTotal
               /// </summary>
               public const int DetailDiscountTotal = 285;

               /// <summary>
               /// Property Indexer for DetailDiscountPercentage
               /// </summary>
               public const int DetailDiscountPercentage = 286;

               /// <summary>
               /// Property Indexer for DocumentNetOfDetailDisc
               /// </summary>
               public const int DocumentNetOfDetailDisc = 287;

               /// <summary>
               /// Property Indexer for AutoCalcTaxReportingAmounts
               /// </summary>
               public const int AutoCalcTaxReportingAmounts = 288;

               /// <summary>
               /// Property Indexer for TaxReportingTRCurrency
               /// </summary>
               public const int TaxReportingTRCurrency = 289;

               /// <summary>
               /// Property Indexer for TRRateType
               /// </summary>
               public const int TRRateType = 290;

               /// <summary>
               /// Property Indexer for TRRateDate
               /// </summary>
               public const int TRRateDate = 291;

               /// <summary>
               /// Property Indexer for TRRate
               /// </summary>
               public const int TRRate = 292;

               /// <summary>
               /// Property Indexer for TRSpread
               /// </summary>
               public const int TRSpread = 293;

               /// <summary>
               /// Property Indexer for TRRateDateMatching
               /// </summary>
               public const int TRRateDateMatching = 294;

               /// <summary>
               /// Property Indexer for TRRateOperator
               /// </summary>
               public const int TRRateOperator = 295;

               /// <summary>
               /// Property Indexer for TRRateOverrideFlag
               /// </summary>
               public const int TRRateOverrideFlag = 296;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount1
               /// </summary>
               public const int TRExcludedTaxAmount1 = 297;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount2
               /// </summary>
               public const int TRExcludedTaxAmount2 = 298;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount3
               /// </summary>
               public const int TRExcludedTaxAmount3 = 299;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount4
               /// </summary>
               public const int TRExcludedTaxAmount4 = 300;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount5
               /// </summary>
               public const int TRExcludedTaxAmount5 = 301;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount1
               /// </summary>
               public const int TRIncludedTaxAmount1 = 302;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount2
               /// </summary>
               public const int TRIncludedTaxAmount2 = 303;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount3
               /// </summary>
               public const int TRIncludedTaxAmount3 = 304;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount4
               /// </summary>
               public const int TRIncludedTaxAmount4 = 305;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount5
               /// </summary>
               public const int TRIncludedTaxAmount5 = 306;

               /// <summary>
               /// Property Indexer for TRTaxAmount1
               /// </summary>
               public const int TRTaxAmount1 = 307;

               /// <summary>
               /// Property Indexer for TRTaxAmount2
               /// </summary>
               public const int TRTaxAmount2 = 308;

               /// <summary>
               /// Property Indexer for TRTaxAmount3
               /// </summary>
               public const int TRTaxAmount3 = 309;

               /// <summary>
               /// Property Indexer for TRTaxAmount4
               /// </summary>
               public const int TRTaxAmount4 = 310;

               /// <summary>
               /// Property Indexer for TRTaxAmount5
               /// </summary>
               public const int TRTaxAmount5 = 311;

               /// <summary>
               /// Property Indexer for TRExcludedTaxTotal
               /// </summary>
               public const int TRExcludedTaxTotal = 312;

               /// <summary>
               /// Property Indexer for TRIncludedTaxTotal
               /// </summary>
               public const int TRIncludedTaxTotal = 313;

               /// <summary>
               /// Property Indexer for TRTaxTotal
               /// </summary>
               public const int TRTaxTotal = 314;

               /// <summary>
               /// Property Indexer for TaxReportingShipmentTRCurr
               /// </summary>
               public const int TaxReportingShipmentTRCurr = 315;

               /// <summary>
               /// Property Indexer for TRShipmentRateType
               /// </summary>
               public const int TRShipmentRateType = 316;

               /// <summary>
               /// Property Indexer for TRShipmentRateDate
               /// </summary>
               public const int TRShipmentRateDate = 317;

               /// <summary>
               /// Property Indexer for TRShipmentRate
               /// </summary>
               public const int TRShipmentRate = 318;

               /// <summary>
               /// Property Indexer for TRShipmentSpread
               /// </summary>
               public const int TRShipmentSpread = 319;

               /// <summary>
               /// Property Indexer for TRShipmentRateDateMatching
               /// </summary>
               public const int TRShipmentRateDateMatching = 320;

               /// <summary>
               /// Property Indexer for TRShipmentRateOperator
               /// </summary>
               public const int TRShipmentRateOperator = 321;

               /// <summary>
               /// Property Indexer for TRShipmentRateOverrideFlag
               /// </summary>
               public const int TRShipmentRateOverrideFlag = 322;

               /// <summary>
               /// Property Indexer for TRShipmentCurrencyDescription
               /// </summary>
               public const int TRShipmentCurrencyDescription = 323;

               /// <summary>
               /// Property Indexer for TRInvoiceCurrencyDescription
               /// </summary>
               public const int TRInvoiceCurrencyDescription = 324;

               /// <summary>
               /// Property Indexer for TRShipmentRateTypeDescriptio
               /// </summary>
               public const int TRShipmentRateTypeDescriptio = 325;

               /// <summary>
               /// Property Indexer for TRInvoiceRateTypeDescription
               /// </summary>
               public const int TRInvoiceRateTypeDescription = 326;

               /// <summary>
               /// Property Indexer for TaxVersion
               /// </summary>
               public const int TaxVersion = 327;

               /// <summary>
               /// Property Indexer for PaymentType
               /// </summary>
               public const int PaymentType = 328;

               /// <summary>
               /// Property Indexer for InvoiceDiscountAmountOverride
               /// </summary>
               public const int InvoiceDiscountAmountOverride = 333;

               /// <summary>
               /// Property Indexer for JobRelated
               /// </summary>
               public const int JobRelated = 334;

               /// <summary>
               /// Property Indexer for JobRelatedDetailLines
               /// </summary>
               public const int JobRelatedDetailLines = 335;

               /// <summary>
               /// Property Indexer for HasRetainage
               /// </summary>
               public const int HasRetainage = 336;

               /// <summary>
               /// Property Indexer for RetainageTerms
               /// </summary>
               public const int RetainageTerms = 337;

               /// <summary>
               /// Property Indexer for RetainageAmount
               /// </summary>
               public const int RetainageAmount = 338;

               /// <summary>
               /// Property Indexer for RetainagePercent
               /// </summary>
               public const int RetainagePercent = 339;

               /// <summary>
               /// Property Indexer for RetainageExchangeRate
               /// </summary>
               public const int RetainageExchangeRate = 340;

               /// <summary>
               /// Property Indexer for RetainageTaxBase1
               /// </summary>
               public const int RetainageTaxBase1 = 341;

               /// <summary>
               /// Property Indexer for RetainageTaxBase2
               /// </summary>
               public const int RetainageTaxBase2 = 342;

               /// <summary>
               /// Property Indexer for RetainageTaxBase3
               /// </summary>
               public const int RetainageTaxBase3 = 343;

               /// <summary>
               /// Property Indexer for RetainageTaxBase4
               /// </summary>
               public const int RetainageTaxBase4 = 344;

               /// <summary>
               /// Property Indexer for RetainageTaxBase5
               /// </summary>
               public const int RetainageTaxBase5 = 345;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount1
               /// </summary>
               public const int RetainageTaxAmount1 = 346;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount2
               /// </summary>
               public const int RetainageTaxAmount2 = 347;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount3
               /// </summary>
               public const int RetainageTaxAmount3 = 348;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount4
               /// </summary>
               public const int RetainageTaxAmount4 = 349;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount5
               /// </summary>
               public const int RetainageTaxAmount5 = 350;

               /// <summary>
               /// Property Indexer for RetainageTermsDescription
               /// </summary>
               public const int RetainageTermsDescription = 351;

               /// <summary>
               /// Property Indexer for CustomerAccountSet
               /// </summary>
               public const int CustomerAccountSet = 352;

               /// <summary>
               /// Property Indexer for CustomerAccountSetDescription
               /// </summary>
               public const int CustomerAccountSetDescription = 353;

               /// <summary>
               /// Property Indexer for EnteredBy
               /// </summary>
               public const int EnteredBy = 354;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for DATEBUS
               /// </summary>
               public const int DATEBUS = 355;

               /// <summary>
               /// Property Indexer for ShipmentPaymentsTotal
               /// </summary>
               public const int ShipmentPaymentsTotal = 356;

               /// <summary>
               /// Property Indexer for PrepaymentDistributedAmount
               /// </summary>
               public const int PrepaymentDistributedAmount = 357;

               /// <summary>
               /// Property Indexer for PrepaymentUnappliedAmount
               /// </summary>
               public const int PrepaymentUnappliedAmount = 358;

               /// <summary>
               /// Property Indexer for TotalRetainageTaxAmount
               /// </summary>
               public const int TotalRetainageTaxAmount = 359;

               /// <summary>
               /// Property Indexer for SageCRMOpportunityLines
               /// </summary>
               public const int SageCRMOpportunityLines = 360;

               /// <summary>
               /// Property Indexer for PreAuthExistsForInvoice
               /// </summary>
               public const int PreAuthExistsForInvoice = 361;

               /// <summary>
               /// Property Indexer for Export Declaration Number
               /// </summary>
               public const int ExportDeclarationNumber = 362;

          }
          #endregion

          #region Keys

          /// <summary>
          /// Order Keys
          /// </summary>
          public class Keys
          {
              /// <summary>
              /// Invoice Number Key
              /// source: OE0420 OEINVH 
              /// </summary>
              public const int InvoiceNumber = 6;
          }

          #endregion

     }
}
