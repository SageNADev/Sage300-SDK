// Copyright © 2017 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of PreauthorizedPaymentDetail Constants
    /// </summary>
    public partial class PreauthorizedPaymentDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "OE0127";


        #region Properties

        /// <summary>
        /// Contains list of PreauthorizedPaymentDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ProcessingCode
            /// </summary>
            public const string ProcessingCode = "YPPROCCODE";

            /// <summary>
            /// Property for OrderNumber
            /// </summary>
            public const string OrderNumber = "ORDNUMBER";

            /// <summary>
            /// Property for ShipmentNumber
            /// </summary>
            public const string ShipmentNumber = "SHINUMBER";

            /// <summary>
            /// Property for OrderDate
            /// </summary>
            public const string OrderDate = "ORDDATE";

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTOMER";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "CUSTNAME";

            /// <summary>
            /// Property for ShipmentUniquifier
            /// </summary>
            public const string ShipmentUniquifier = "SHIUNIQ";

            /// <summary>
            /// Property for OrderUniquifier
            /// </summary>
            public const string OrderUniquifier = "ORDUNIQ";

            /// <summary>
            /// Property for ProcessingStatus
            /// </summary>
            public const string ProcessingStatus = "STATUS";

            /// <summary>
            /// Property for Apply
            /// </summary>
            public const string Apply = "SWAPPLY";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of PreauthorizedPaymentDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ProcessingCode
            /// </summary>
            public const int ProcessingCode = 1;

            /// <summary>
            /// Property Indexer for OrderNumber
            /// </summary>
            public const int OrderNumber = 2;

            /// <summary>
            /// Property Indexer for ShipmentNumber
            /// </summary>
            public const int ShipmentNumber = 3;

            /// <summary>
            /// Property Indexer for OrderDate
            /// </summary>
            public const int OrderDate = 4;

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 5;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 6;

            /// <summary>
            /// Property Indexer for ShipmentUniquifier
            /// </summary>
            public const int ShipmentUniquifier = 7;

            /// <summary>
            /// Property Indexer for OrderUniquifier
            /// </summary>
            public const int OrderUniquifier = 8;

            /// <summary>
            /// Property Indexer for ProcessingStatus
            /// </summary>
            public const int ProcessingStatus = 9;

            /// <summary>
            /// Property Indexer for Apply
            /// </summary>
            public const int Apply = 40;


        }

        #endregion

    }
}