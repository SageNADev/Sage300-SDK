// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of OptionalFieldLocation Constants
     /// </summary>
     public partial class OptionalFieldLocation
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "OE0475";

          #region Properties

          /// <summary>
          /// Contains list of OptionalFieldLocation Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for NumberOfValues
               /// </summary>
               public const string NumberOfValues = "VALUES";
          }

          #endregion

          #region Properties

          /// <summary>
          /// Contains list of OptionalFieldLocation Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 1;

               /// <summary>
               /// Property Indexer for NumberOfValues
               /// </summary>
               public const int NumberOfValues = 2;
          }

          #endregion
     }
}
