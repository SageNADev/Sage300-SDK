// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Contains list of SalesHistory Constants
    /// </summary>
    public partial class SalesHistory1
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "OE0690";

        #region Properties
        /// <summary>
        /// Contains list of SalesHistory Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTOMER";

            /// <summary>
            /// Property for UnformattedItemNumber
            /// </summary>
            public const string UnformattedItemNumber = "ITEM";

            /// <summary>
            /// Property for Year
            /// </summary>
            public const string Year = "YR";

            /// <summary>
            /// Property for Period
            /// </summary>
            public const string Period = "PERIOD";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of SalesHistory Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for UnformattedItemNumber
            /// </summary>
            public const int UnformattedItemNumber = 2;

            /// <summary>
            /// Property Indexer for Year
            /// </summary>
            public const int Year = 3;

            /// <summary>
            /// Property Indexer for Period
            /// </summary>
            public const int Period = 4;
        }
        #endregion

        #region Keys

        public class Keys
        {
            /// <summary>
            /// Keys for UnformattedItemNumber
            /// </summary> 
            public const int UnformattedItemNumber = 0;
        }
        #endregion
    }
}
