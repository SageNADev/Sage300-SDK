// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of OrderPreAuthorization Constants
	/// </summary>
	public partial class OrderPreAuthorization
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string EntityName = "OE0535";

		#region Properties

		/// <summary>
		/// Contains list of OrderPreAuthorization Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for OrderUniquifier
			/// </summary>
			public const string OrderUniquifier = "ORDUNIQ";

			/// <summary>
			/// Property for Customer
			/// </summary>
			public const string Customer = "CUSTOMER";

			/// <summary>
			/// Property for PreauthTransactionID
			/// </summary>
			public const string PreauthTransactionID = "TRANIDPRE";

			/// <summary>
			/// Property for CaptureTransactionID
			/// </summary>
			public const string CaptureTransactionID = "TRANIDCAP";

			/// <summary>
			/// Property for VoidTransactionID
			/// </summary>
			public const string VoidTransactionID = "TRANIDVOID";

			/// <summary>
			/// Property for TransactionStatus
			/// </summary>
			public const string TransactionStatus = "TRANSTATUS";

			/// <summary>
			/// Property for YpProcessCode
			/// </summary>
			public const string YpProcessCode = "YPPROCCODE";

			/// <summary>
			/// Property for BankCode
			/// </summary>
			public const string BankCode = "BANKCODE";

			/// <summary>
			/// Property for PaymentCode
			/// </summary>
			public const string PaymentCode = "PAYMCODE";

			/// <summary>
			/// Property for PaymentType
			/// </summary>
			public const string PaymentType = "PAYMTYPE";

			/// <summary>
			/// Property for PreAuthAmountCurrency
			/// </summary>
			public const string PreAuthAmountCurrency = "PAUTHCURR";

			/// <summary>
			/// Property for SourceCurrency
			/// </summary>
			public const string SourceCurrency = "SOURCURR";

			/// <summary>
			/// Property for RateType
			/// </summary>
			public const string RateType = "RATETYPE";

			/// <summary>
			/// Property for RateDate
			/// </summary>
			public const string RateDate = "RATEDATE";

			/// <summary>
			/// Property for ExchangeRate
			/// </summary>
			public const string ExchangeRate = "RATE";

			/// <summary>
			/// Property for RateSpread
			/// </summary>
			public const string RateSpread = "SPREAD";

			/// <summary>
			/// Property for RateDateMatching
			/// </summary>
			public const string RateDateMatching = "DATEMTCH";

			/// <summary>
			/// Property for RateOperator
			/// </summary>
			public const string RateOperator = "RATEREP";

			/// <summary>
			/// Property for RateOverrideFalg
			/// </summary>
			public const string RateOverrideFalg = "RATEOVER";

			/// <summary>
			/// Property for OrderPosted
			/// </summary>
			public const string OrderPosted = "ORDPOSTED";

			/// <summary>
			/// Property for PreAuthAmount
			/// </summary>
			public const string PreAuthAmount = "PAUTHAMT";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of OrderPreAuthorization Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for OrderUniquifier
			/// </summary>
			public const int OrderUniquifier = 1;

			/// <summary>
			/// Property Indexer for Customer
			/// </summary>
			public const int Customer = 2;

			/// <summary>
			/// Property Indexer for PreauthTransactionID
			/// </summary>
			public const int PreauthTransactionID = 3;

			/// <summary>
			/// Property Indexer for CaptureTransactionID
			/// </summary>
			public const int CaptureTransactionID = 4;

			/// <summary>
			/// Property Indexer for VoidTransactionID
			/// </summary>
			public const int VoidTransactionID = 5;

			/// <summary>
			/// Property Indexer for TransactionStatus
			/// </summary>
			public const int TransactionStatus = 6;

			/// <summary>
			/// Property Indexer for YpProcessCode
			/// </summary>
			public const int YpProcessCode = 7;

			/// <summary>
			/// Property Indexer for BankCode
			/// </summary>
			public const int BankCode = 8;

			/// <summary>
			/// Property Indexer for PaymentCode
			/// </summary>
			public const int PaymentCode = 9;

			/// <summary>
			/// Property Indexer for PaymentType
			/// </summary>
			public const int PaymentType = 10;

			/// <summary>
			/// Property Indexer for PreAuthAmountCurrency
			/// </summary>
			public const int PreAuthAmountCurrency = 11;

			/// <summary>
			/// Property Indexer for SourceCurrency
			/// </summary>
			public const int SourceCurrency = 12;

			/// <summary>
			/// Property Indexer for RateType
			/// </summary>
			public const int RateType = 13;

			/// <summary>
			/// Property Indexer for RateDate
			/// </summary>
			public const int RateDate = 14;

			/// <summary>
			/// Property Indexer for ExchangeRate
			/// </summary>
			public const int ExchangeRate = 15;

			/// <summary>
			/// Property Indexer for RateSpread
			/// </summary>
			public const int RateSpread = 16;

			/// <summary>
			/// Property Indexer for RateDateMatching
			/// </summary>
			public const int RateDateMatching = 17;

			/// <summary>
			/// Property Indexer for RateOperator
			/// </summary>
			public const int RateOperator = 18;

			/// <summary>
			/// Property Indexer for RateOverrideFalg
			/// </summary>
			public const int RateOverrideFalg = 19;

			/// <summary>
			/// Property Indexer for OrderPosted
			/// </summary>
			public const int OrderPosted = 20;

			/// <summary>
			/// Property Indexer for PreAuthAmount
			/// </summary>
			public const int PreAuthAmount = 21;

		}

		#endregion

	}
}
