// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of CreditDebitKittingSerialNo Constants
     /// </summary>
     public partial class CreditDebitKittingSerialNo
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "OE0224";

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitKittingSerialNo Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CNUniquifier
               /// </summary>
               public const string CNUniquifier = "CRDUNIQ";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "LINENUM";

               /// <summary>
               /// Property for ParentComponentNumber
               /// </summary>
               public const string ParentComponentNumber = "PRNCOMPNUM";

               /// <summary>
               /// Property for ComponentLineNumber
               /// </summary>
               public const string ComponentLineNumber = "COMPNUM";

               /// <summary>
               /// Property for SerialNumber
               /// </summary>
               public const string SerialNumber = "SERIALNUMF";

               /// <summary>
               /// Property for DetailNumber
               /// </summary>
               public const string DetailNumber = "DETAILNUM";

               /// <summary>
               /// Property for Cost
               /// </summary>
               public const string Cost = "COST";

               /// <summary>
               /// Property for TransactionQuantity
               /// </summary>
               public const string TransactionQuantity = "QTY";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitKittingSerialNo Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CNUniquifier
               /// </summary>
               public const int CNUniquifier = 1;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 2;

               /// <summary>
               /// Property Indexer for ParentComponentNumber
               /// </summary>
               public const int ParentComponentNumber = 3;

               /// <summary>
               /// Property Indexer for ComponentLineNumber
               /// </summary>
               public const int ComponentLineNumber = 4;

               /// <summary>
               /// Property Indexer for SerialNumber
               /// </summary>
               public const int SerialNumber = 5;

               /// <summary>
               /// Property Indexer for DetailNumber
               /// </summary>
               public const int DetailNumber = 6;

               /// <summary>
               /// Property Indexer for Cost
               /// </summary>
               public const int Cost = 7;

               /// <summary>
               /// Property Indexer for TransactionQuantity
               /// </summary>
               public const int TransactionQuantity = 50;

          }
          #endregion

     }
}
