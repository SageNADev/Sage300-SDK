// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of ShipmentKittingSerialNumber Constants
	/// </summary>
	public partial class ShipmentKittingSerialNumber
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0706";

		#region Properties

		/// <summary>
		/// Contains list of ShipmentKittingSerialNumber Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ShipmentUniquifier
			/// </summary>
			public const string ShipmentUniquifier = "SHIUNIQ";

			/// <summary>
			/// Property for DetailLineNumber
			/// </summary>
			public const string DetailLineNumber = "LINENUM";

			/// <summary>
			/// Property for ParentComponentNumber
			/// </summary>
			public const string ParentComponentNumber = "PRNCOMPNUM";

			/// <summary>
			/// Property for ComponentNumber
			/// </summary>
			public const string ComponentNumber = "COMPNUM";

			/// <summary>
			/// Property for SerialNumber
			/// </summary>
			public const string SerialNumber = "SERIALNUMF";

			/// <summary>
			/// Property for DetailNumber
			/// </summary>
			public const string DetailNumber = "DETAILNUM";

			/// <summary>
			/// Property for Cost
			/// </summary>
			public const string Cost = "COST";

			/// <summary>
			/// Property for TransactionQuantity
			/// </summary>
			public const string TransactionQuantity = "QTY";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ShipmentKittingSerialNumber Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ShipmentUniquifier
			/// </summary>
			public const int ShipmentUniquifier = 1;

			/// <summary>
			/// Property Indexer for DetailLineNumber
			/// </summary>
			public const int DetailLineNumber = 2;

			/// <summary>
			/// Property Indexer for ParentComponentNumber
			/// </summary>
			public const int ParentComponentNumber = 3;

			/// <summary>
			/// Property Indexer for ComponentNumber
			/// </summary>
			public const int ComponentNumber = 4;

			/// <summary>
			/// Property Indexer for SerialNumber
			/// </summary>
			public const int SerialNumber = 5;

			/// <summary>
			/// Property Indexer for DetailNumber
			/// </summary>
			public const int DetailNumber = 6;

			/// <summary>
			/// Property Indexer for Cost
			/// </summary>
			public const int Cost = 7;

			/// <summary>
			/// Property Indexer for TransactionQuantity
			/// </summary>
			public const int TransactionQuantity = 50;

		}

		#endregion

	}
}
