// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of MultipleOrdersToShipment Constants
	/// </summary>
	public partial class MultipleOrdersToShipment
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0694";

		#region Properties

		/// <summary>
		/// Contains list of MultipleOrdersToShipment Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ShipmentUniquifier
			/// </summary>
			public const string ShipmentUniquifier = "SHIUNIQ";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "LINENUM";

			/// <summary>
			/// Property for OrderUniquifier
			/// </summary>
			public const string OrderUniquifier = "ORDUNIQ";

			/// <summary>
			/// Property for OrderNumber
			/// </summary>
			public const string OrderNumber = "ORDNUMBER";

			/// <summary>
			/// Property for PONumber
			/// </summary>
			public const string PONumber = "PONUMBER";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of MultipleOrdersToShipment Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ShipmentUniquifier
			/// </summary>
			public const int ShipmentUniquifier = 1;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 2;

			/// <summary>
			/// Property Indexer for OrderUniquifier
			/// </summary>
			public const int OrderUniquifier = 3;

			/// <summary>
			/// Property Indexer for OrderNumber
			/// </summary>
			public const int OrderNumber = 4;

			/// <summary>
			/// Property Indexer for PONumber
			/// </summary>
			public const int PONumber = 5;

		}

		#endregion

	}
}
