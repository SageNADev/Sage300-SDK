// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of ShipmentDetailSerialNumber Constants
	/// </summary>
	public partial class ShipmentDetailSerialNumber
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0709";
        public const string ImportEntityName = "OE0436";

		#region Properties

		/// <summary>
		/// Contains list of ShipmentDetailSerialNumber Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ShipmentUniquifier
			/// </summary>
			public const string ShipmentUniquifier = "SHIUNIQ";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "LINENUM";

			/// <summary>
			/// Property for SerialNumber
			/// </summary>
			public const string SerialNumber = "SERIALNUMF";

			/// <summary>
			/// Property for DetailNumber
			/// </summary>
			public const string DetailNumber = "DETAILNUM";

			/// <summary>
			/// Property for Cost
			/// </summary>
			public const string Cost = "COST";

			/// <summary>
			/// Property for TransactionQuantity
			/// </summary>
			public const string TransactionQuantity = "QTY";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ShipmentDetailSerialNumber Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ShipmentUniquifier
			/// </summary>
			public const int ShipmentUniquifier = 1;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 2;

			/// <summary>
			/// Property Indexer for SerialNumber
			/// </summary>
			public const int SerialNumber = 3;

			/// <summary>
			/// Property Indexer for DetailNumber
			/// </summary>
			public const int DetailNumber = 4;

			/// <summary>
			/// Property Indexer for Cost
			/// </summary>
			public const int Cost = 5;

			/// <summary>
			/// Property Indexer for TransactionQuantity
			/// </summary>
			public const int TransactionQuantity = 50;

		}

		#endregion

	}
}
