// Copyright © 2016 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.ShipmentPrepayment
{
    /// <summary>
    /// Contains list of Shipment Prepayment Constants
    /// </summary>
    public partial class Prepayment
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "OE0710";


        #region Properties

        /// <summary>
        /// Contains list of Prepayment Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ShipmentUniquifier
            /// </summary>
            public const string ShipmentUniquifier = "SHIUNIQ";

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTOMER";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "CUSTDESC";

            /// <summary>
            /// Property for CustomerCurrency
            /// </summary>
            public const string CustomerCurrency = "CUSTCURN";

            /// <summary>
            /// Property for CustRate
            /// </summary>
            public const string CustRate = "CRATE";

            /// <summary>
            /// Property for CustRateDate
            /// </summary>
            public const string CustRateDate = "CRATEDATE";

            /// <summary>
            /// Property for CustRateType
            /// </summary>
            public const string CustRateType = "CRATETYPE";

            /// <summary>
            /// Property for OperCustCurnToFunc
            /// </summary>
            public const string OperCustCurnToFunc = "CRATEOPER";

            /// <summary>
            /// Property for DocumentTotal
            /// </summary>
            public const string DocumentTotal = "DOCTOTAL";

            /// <summary>
            /// Property for DiscountAvailable
            /// </summary>
            public const string DiscountAvailable = "DISCAVAIL";

            /// <summary>
            /// Property for AmountDue
            /// </summary>
            public const string AmountDue = "AMOUNTDUE";

            /// <summary>
            /// Property for ReceiptBatchNumber
            /// </summary>
            public const string ReceiptBatchNumber = "BATCHNUM";

            /// <summary>
            /// Property for BankCode
            /// </summary>
            public const string BankCode = "BANKCODE";

            /// <summary>
            /// Property for ReceiptType
            /// </summary>
            public const string ReceiptType = "RECPTYPE";

            /// <summary>
            /// Property for CheckReceiptNo
            /// </summary>
            public const string CheckReceiptNo = "CHECKNUM";

            /// <summary>
            /// Property for ReceiptDate
            /// </summary>
            public const string ReceiptDate = "RECPDATE";

            /// <summary>
            /// Property for ReceiptAmount
            /// </summary>
            public const string ReceiptAmount = "RECPAMOUNT";

            /// <summary>
            /// Property for BankCurrency
            /// </summary>
            public const string BankCurrency = "BANKCURN";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for BankRate
            /// </summary>
            public const string BankRate = "BANKRATE";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for PaymentType
            /// </summary>
            public const string PaymentType = "PAYMTYPE";

            /// <summary>
            /// Property for PreauthCurrency
            /// </summary>
            public const string PreauthCurrency = "PAUTHCURR";

            /// <summary>
            /// Property for PreauthTransactionID
            /// </summary>
            public const string PreauthTransactionID = "TRANIDPRE";

            /// <summary>
            /// Property for CaptureTransactionID
            /// </summary>
            public const string CaptureTransactionID = "TRANIDCAP";

            /// <summary>
            /// Property for VoidTransactionID
            /// </summary>
            public const string VoidTransactionID = "TRANIDVOID";

            /// <summary>
            /// Property for PreauthAmount
            /// </summary>
            public const string PreauthAmount = "PAUTHAMT";

            /// <summary>
            /// Property for CreditCardChargeStatus
            /// </summary>
            public const string CreditCardChargeStatus = "CHARGESTTS";

            /// <summary>
            /// Property for YPProcessCode
            /// </summary>
            public const string YPProcessCode = "YPPROCCODE";

            /// <summary>
            /// Property for BatchDescription
            /// </summary>
            public const string BatchDescription = "BATCHDESC";

            /// <summary>
            /// Property for ReceiptDescription
            /// </summary>
            public const string ReceiptDescription = "RECPDESC";

            /// <summary>
            /// Property for BankRateSpread
            /// </summary>
            public const string BankRateSpread = "BANKSPREAD";

            /// <summary>
            /// Property for PrepaymentID
            /// </summary>
            public const string PrepaymentID = "IDPPD";

            /// <summary>
            /// Property for ICDayEndTransNumber
            /// </summary>
            public const string ICDayEndTransNumber = "DAYENDNUM";

            /// <summary>
            /// Property for CapturePreauthorization
            /// </summary>
            public const string CapturePreauthorization = "CPTPREAUTH";

            /// <summary>
            /// Property for OrderUniquifier
            /// </summary>
            public const string OrderUniquifier = "ORDUNIQ";

            /// <summary>
            /// Property for ProcessOnPut
            /// </summary>
            public const string ProcessOnPut = "PROCESSNOW";

            /// <summary>
            /// Property for TransactionID
            /// </summary>
            public const string TransactionID = "TRANSID";

            /// <summary>
            /// Property for XMLString
            /// </summary>
            public const string XMLString = "XMLSTRING";

            /// <summary>
            /// Property for ResponseIndicator
            /// </summary>
            public const string ResponseIndicator = "RESPIND";

            /// <summary>
            /// Property for ResponseCode
            /// </summary>
            public const string ResponseCode = "RESPCD";

            /// <summary>
            /// Property for ResponseMessage
            /// </summary>
            public const string ResponseMessage = "RESPMSG";

            /// <summary>
            /// Property for AuthorizationCode
            /// </summary>
            public const string AuthorizationCode = "AUTHCODE";

            /// <summary>
            /// Property for AVSResult
            /// </summary>
            public const string AVSResult = "AVSRESULT";

            /// <summary>
            /// Property for CVVResult
            /// </summary>
            public const string CVVResult = "CVVRESULT";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for VANReference
            /// </summary>
            public const string VANReference = "VANREF";

            /// <summary>
            /// Property for Last4
            /// </summary>
            public const string Last4 = "LAST4";

            /// <summary>
            /// Property for PaymentDescription
            /// </summary>
            public const string PaymentDescription = "PMTDESC";

            /// <summary>
            /// Property for PaymentTypeID
            /// </summary>
            public const string PaymentTypeID = "PMTTYPEID";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Prepayment Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ShipmentUniquifier
            /// </summary>
            public const int ShipmentUniquifier = 1;

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 2;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 3;

            /// <summary>
            /// Property Indexer for CustomerCurrency
            /// </summary>
            public const int CustomerCurrency = 4;

            /// <summary>
            /// Property Indexer for CustRate
            /// </summary>
            public const int CustRate = 5;

            /// <summary>
            /// Property Indexer for CustRateDate
            /// </summary>
            public const int CustRateDate = 6;

            /// <summary>
            /// Property Indexer for CustRateType
            /// </summary>
            public const int CustRateType = 7;

            /// <summary>
            /// Property Indexer for OperCustCurnToFunc
            /// </summary>
            public const int OperCustCurnToFunc = 8;

            /// <summary>
            /// Property Indexer for DocumentTotal
            /// </summary>
            public const int DocumentTotal = 9;

            /// <summary>
            /// Property Indexer for DiscountAvailable
            /// </summary>
            public const int DiscountAvailable = 10;

            /// <summary>
            /// Property Indexer for AmountDue
            /// </summary>
            public const int AmountDue = 11;

            /// <summary>
            /// Property Indexer for ReceiptBatchNumber
            /// </summary>
            public const int ReceiptBatchNumber = 12;

            /// <summary>
            /// Property Indexer for BankCode
            /// </summary>
            public const int BankCode = 13;

            /// <summary>
            /// Property Indexer for ReceiptType
            /// </summary>
            public const int ReceiptType = 14;

            /// <summary>
            /// Property Indexer for CheckReceiptNo
            /// </summary>
            public const int CheckReceiptNo = 15;

            /// <summary>
            /// Property Indexer for ReceiptDate
            /// </summary>
            public const int ReceiptDate = 16;

            /// <summary>
            /// Property Indexer for ReceiptAmount
            /// </summary>
            public const int ReceiptAmount = 17;

            /// <summary>
            /// Property Indexer for BankCurrency
            /// </summary>
            public const int BankCurrency = 18;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 19;

            /// <summary>
            /// Property Indexer for BankRate
            /// </summary>
            public const int BankRate = 20;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 21;

            /// <summary>
            /// Property Indexer for PaymentType
            /// </summary>
            public const int PaymentType = 22;

            /// <summary>
            /// Property Indexer for PreauthCurrency
            /// </summary>
            public const int PreauthCurrency = 28;

            /// <summary>
            /// Property Indexer for PreauthTransactionID
            /// </summary>
            public const int PreauthTransactionID = 29;

            /// <summary>
            /// Property Indexer for CaptureTransactionID
            /// </summary>
            public const int CaptureTransactionID = 30;

            /// <summary>
            /// Property Indexer for VoidTransactionID
            /// </summary>
            public const int VoidTransactionID = 31;

            /// <summary>
            /// Property Indexer for PreauthAmount
            /// </summary>
            public const int PreauthAmount = 32;

            /// <summary>
            /// Property Indexer for CreditCardChargeStatus
            /// </summary>
            public const int CreditCardChargeStatus = 33;

            /// <summary>
            /// Property Indexer for YPProcessCode
            /// </summary>
            public const int YPProcessCode = 34;

            /// <summary>
            /// Property Indexer for BatchDescription
            /// </summary>
            public const int BatchDescription = 70;

            /// <summary>
            /// Property Indexer for ReceiptDescription
            /// </summary>
            public const int ReceiptDescription = 71;

            /// <summary>
            /// Property Indexer for BankRateSpread
            /// </summary>
            public const int BankRateSpread = 72;

            /// <summary>
            /// Property Indexer for PrepaymentID
            /// </summary>
            public const int PrepaymentID = 73;

            /// <summary>
            /// Property Indexer for ICDayEndTransNumber
            /// </summary>
            public const int ICDayEndTransNumber = 74;

            /// <summary>
            /// Property Indexer for CapturePreauthorization
            /// </summary>
            public const int CapturePreauthorization = 77;

            /// <summary>
            /// Property Indexer for OrderUniquifier
            /// </summary>
            public const int OrderUniquifier = 78;

            /// <summary>
            /// Property Indexer for ProcessOnPut
            /// </summary>
            public const int ProcessOnPut = 79;

            /// <summary>
            /// Property Indexer for TransactionID
            /// </summary>
            public const int TransactionID = 80;

            /// <summary>
            /// Property Indexer for XMLString
            /// </summary>
            public const int XMLString = 81;

            /// <summary>
            /// Property Indexer for ResponseIndicator
            /// </summary>
            public const int ResponseIndicator = 82;

            /// <summary>
            /// Property Indexer for ResponseCode
            /// </summary>
            public const int ResponseCode = 83;

            /// <summary>
            /// Property Indexer for ResponseMessage
            /// </summary>
            public const int ResponseMessage = 84;

            /// <summary>
            /// Property Indexer for AuthorizationCode
            /// </summary>
            public const int AuthorizationCode = 85;

            /// <summary>
            /// Property Indexer for AVSResult
            /// </summary>
            public const int AVSResult = 86;

            /// <summary>
            /// Property Indexer for CVVResult
            /// </summary>
            public const int CVVResult = 87;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 88;

            /// <summary>
            /// Property Indexer for VANReference
            /// </summary>
            public const int VANReference = 89;

            /// <summary>
            /// Property Indexer for Last4
            /// </summary>
            public const int Last4 = 90;

            /// <summary>
            /// Property Indexer for PaymentDescription
            /// </summary>
            public const int PaymentDescription = 91;

            /// <summary>
            /// Property Indexer for PaymentTypeID
            /// </summary>
            public const int PaymentTypeID = 92;


        }

        #endregion

    }
}