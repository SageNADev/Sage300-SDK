// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

using System.Collections.Generic;
namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of ShipmentDetail Constants
	/// </summary>
	public partial class ShipmentDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "OE0691";
        public const string ImportEntityName = "OE0433";


        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"LINETYPE", "LineType"},
					{"ITEM", "Item"},
					{"MISCCHARGE", "MiscellaneousChargesCode"},
					{"DESC", "Description"},
					{"ACCTSET", "ItemAccountSet"},
					{"USERCOSTMD", "UserSpecifiedCostingMethod"},
					{"PRICELIST", "PriceList"},
					{"CATEGORY", "Category"},
					{"LOCATION", "Location"},
					{"PICKSEQ", "PickingSequence"},
					{"EXPDATE", "ShipmentDate"},
					{"STOCKITEM", "StockItem"},
					{"QTYSHIPPED", "QuantityShipped"},
					{"QTYBACKORD", "QuantityBackordered"},
                    {"ORDQTYORD", "OrderQuantityOrdered"},
                    {"ORDQTYCOMM", "OrderQuantityCommitted"},
                    {"ORDQTYSTD", "OrderQuantityShippedtodate"},
					{"SHIUNIT", "ShipmentUnitOfMeasure"},
					{"PRIUNTPRC", "PricingUnitPrice"},
					{"COSUNTCST", "CostingUnitCost"},
					{"EXTSHIMISC", "ExtendedAmount"},
					{"SHIDISC", "ShipmentDiscountAmount"},
                    {"EDCSHIMISC", "ExtendedDiscountedPrice"},
					{"EXTSCOST", "ExtendedShipmentCost"},
					{"UNITWEIGHT", "UnitWeight"},
					{"EXTWEIGHT", "ExtendedWeight"},
					{"COMPLETE", "DetailCompleted"},
					{"FINISHORD", "ShipmentCompletesOrderDetail"},
					{"TCLASS1", "TaxClass1"},
					{"TCLASS2", "TaxClass2"},
					{"TCLASS3", "TaxClass3"},
					{"TCLASS4", "TaxClass4"},
					{"TCLASS5", "TaxClass5"},
					{"TINCLUDED1", "TaxIncluded1"},
					{"TINCLUDED2", "TaxIncluded2"},
					{"TINCLUDED3", "TaxIncluded3"},
					{"TINCLUDED4", "TaxIncluded4"},
					{"TINCLUDED5", "TaxIncluded5"},
					{"TBASE1", "TaxBase1"},
					{"TBASE2", "TaxBase2"},
					{"TBASE3", "TaxBase3"},
					{"TBASE4", "TaxBase4"},
					{"TBASE5", "TaxBase5"},
					{"TAMOUNT1", "TaxAmount1"},
					{"TAMOUNT2", "TaxAmount2"},
					{"TAMOUNT3", "TaxAmount3"},
					{"TAMOUNT4", "TaxAmount4"},
					{"TAMOUNT5", "TaxAmount5"},
					{"COMMINST", "UseCommentsInstructions"},
					{"GLNONSTKCR", "NonstockClearingAccount"},
					{"INDBTABLE", "StoredInDatabaseTable"},
					{"REFRESH", "RefreshOrderQtyatUpdate"},
					{"SHIPTRACK", "ShipmentTrackingNumber"},
					{"SHIPVIA", "ShipViaCode"},
					{"VIADESC", "ShipViaCodeDescription"},
					{"DISCPER", "DiscountPercent"},
					{"MANITEMNO", "ManufacturersItemNumber"},
					{"CUSTITEMNO", "CustomerItemNumber"},
					{"DDTLNO", "KitBOMNumber"},
					{"WEIGHTUNIT", "WeightUnitOfMeasure"},
					{"PRWGHTUNIT", "PricingWeightUOM"},
					{"NEEDPCHECK", "PriceCheckPending"},
					{"CAPPROVEBY", "PriceApprovedBy"},
					{"STRAMOUNT1", "TRTaxAmount1"},
					{"STRAMOUNT2", "TRTaxAmount2"},
					{"STRAMOUNT3", "TRTaxAmount3"},
					{"STRAMOUNT4", "TRTaxAmount4"},
					{"STRAMOUNT5", "TRTaxAmount5"},
					{"CONTRACT", "ContractCode"},
					{"PROJECT", "ProjectCode"},
					{"CCATEGORY", "CategoryCode"},
					{"COSTCLASS", "CostClass"},
					{"BILLTYPE", "BillingType"},
					{"REVBILL", "RevenueBillingAccount"},
					{"COGSWIP", "COGSWIPAccount"},
					{"RTGAMOUNT", "RetainageAmount"},
					{"RTGPERCENT", "RetainagePercent"},
					{"RTGDAYS", "RetainageDays"},
					{"RTGAMTOVR", "RetainageAmountOverride"},
					{"ARITEMNO", "ARItemNumber"},
					{"ARUNIT", "ARItemUnit"},
					{"PAYMNTDIST", "PrepaymentDistributed"},
					{"SERIALQTY", "SerialQuantity"},
					{"LOTQTY", "LotQuantity"},
					{"CAPPRPWORD", "ApprovingUsersPassword"},
                    {"UNITPRICE", "ShipmentUnitPrice"},
				};
            }
        }


		#region Properties

		/// <summary>
		/// Contains list of ShipmentDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ShipmentUniquifier
			/// </summary>
			public const string ShipmentUniquifier = "SHIUNIQ";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "LINENUM";

			/// <summary>
			/// Property for LineType
			/// </summary>
			public const string LineType = "LINETYPE";

			/// <summary>
			/// Property for Item
			/// </summary>
			public const string Item = "ITEM";

			/// <summary>
			/// Property for MiscellaneousChargesCode
			/// </summary>
			public const string MiscellaneousChargesCode = "MISCCHARGE";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "DESC";

			/// <summary>
			/// Property for ItemAccountSet
			/// </summary>
			public const string ItemAccountSet = "ACCTSET";

			/// <summary>
			/// Property for UserSpecifiedCostingMethod
			/// </summary>
			public const string UserSpecifiedCostingMethod = "USERCOSTMD";

			/// <summary>
			/// Property for PriceList
			/// </summary>
			public const string PriceList = "PRICELIST";

			/// <summary>
			/// Property for Category
			/// </summary>
			public const string Category = "CATEGORY";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for PickingSequence
			/// </summary>
			public const string PickingSequence = "PICKSEQ";

			/// <summary>
			/// Property for ShipmentDate
			/// </summary>
			public const string ShipmentDate = "EXPDATE";

			/// <summary>
			/// Property for StockItem
			/// </summary>
			public const string StockItem = "STOCKITEM";

			/// <summary>
			/// Property for OrderQuantityOrdered
			/// </summary>
			public const string OrderQuantityOrdered = "ORDQTYORD";

			/// <summary>
			/// Property for OrderQuantityBackordered
			/// </summary>
			public const string OrderQuantityBackordered = "ORDQTYBKOR";

			/// <summary>
			/// Property for OrderQuantityCommitted
			/// </summary>
			public const string OrderQuantityCommitted = "ORDQTYCOMM";

			/// <summary>
			/// Property for OrderTrueQuantityCommitted
			/// </summary>
			public const string OrderTrueQuantityCommitted = "ORDQTYTCOM";

			/// <summary>
			/// Property for OrderQuantityShippedtodate
			/// </summary>
			public const string OrderQuantityShippedtodate = "ORDQTYSTD";

			/// <summary>
			/// Property for OrderUnitOfMeasure
			/// </summary>
			public const string OrderUnitOfMeasure = "ORDUNIT";

			/// <summary>
			/// Property for OrderUnitConversion
			/// </summary>
			public const string OrderUnitConversion = "ORDUNITCON";

			/// <summary>
			/// Property for CurrentQuantityOutstanding
			/// </summary>
			public const string CurrentQuantityOutstanding = "QTYORDERED";

			/// <summary>
			/// Property for QuantityShipped
			/// </summary>
			public const string QuantityShipped = "QTYSHIPPED";

			/// <summary>
			/// Property for QuantityBackordered
			/// </summary>
			public const string QuantityBackordered = "QTYBACKORD";

			/// <summary>
			/// Property for QuantityCommitted
			/// </summary>
			public const string QuantityCommitted = "QTYCOMMIT";

			/// <summary>
			/// Property for TrueQuantityCommitted
			/// </summary>
			public const string TrueQuantityCommitted = "QTYTRUECOM";

			/// <summary>
			/// Property for ShipmentUnitOfMeasure
			/// </summary>
			public const string ShipmentUnitOfMeasure = "SHIUNIT";

			/// <summary>
			/// Property for ShipmentUnitConversion
			/// </summary>
			public const string ShipmentUnitConversion = "UNITCONV";

			/// <summary>
			/// Property for ShipmentUnitPrice
			/// </summary>
			public const string ShipmentUnitPrice = "UNITPRICE";

			/// <summary>
			/// Property for PriceOverride
			/// </summary>
			public const string PriceOverride = "PRICEOVER";

			/// <summary>
			/// Property for ShipmentUnitCost
			/// </summary>
			public const string ShipmentUnitCost = "UNITCOST";

			/// <summary>
			/// Property for MostRecentUnitCost
			/// </summary>
			public const string MostRecentUnitCost = "MOSTREC";

			/// <summary>
			/// Property for StandardUnitCost
			/// </summary>
			public const string StandardUnitCost = "STDCOST";

			/// <summary>
			/// Property for AlternateUnitCost1
			/// </summary>
			public const string AlternateUnitCost1 = "COST1";

			/// <summary>
			/// Property for AlternateUnitCost2
			/// </summary>
			public const string AlternateUnitCost2 = "COST2";

			/// <summary>
			/// Property for AverageCost
			/// </summary>
			public const string AverageCost = "AVGCOST";

			/// <summary>
			/// Property for LastCost
			/// </summary>
			public const string LastCost = "LASTCOST";

			/// <summary>
			/// Property for UnitPriceNoOfDecimals
			/// </summary>
			public const string UnitPriceNoOfDecimals = "UNITPRCDEC";

			/// <summary>
			/// Property for PricingUnitOfMeasure
			/// </summary>
			public const string PricingUnitOfMeasure = "PRICEUNIT";

			/// <summary>
			/// Property for PricingUnitPrice
			/// </summary>
			public const string PricingUnitPrice = "PRIUNTPRC";

			/// <summary>
			/// Property for PricingUnitConversion
			/// </summary>
			public const string PricingUnitConversion = "PRIUNTCONV";

			/// <summary>
			/// Property for PriceDiscountPercentage
			/// </summary>
			public const string PriceDiscountPercentage = "PRIPERCENT";

			/// <summary>
			/// Property for PriceDiscountAmount
			/// </summary>
			public const string PriceDiscountAmount = "PRIAMOUNT";

			/// <summary>
			/// Property for PricingBaseUnit
			/// </summary>
			public const string PricingBaseUnit = "BASEUNIT";

			/// <summary>
			/// Property for PricingBaseUnitPrice
			/// </summary>
			public const string PricingBaseUnitPrice = "PRIBASPRC";

			/// <summary>
			/// Property for PricingBaseUnitConversion
			/// </summary>
			public const string PricingBaseUnitConversion = "PRIBASCONV";

			/// <summary>
			/// Property for CostingUnitOfMeasure
			/// </summary>
			public const string CostingUnitOfMeasure = "COSTUNIT";

			/// <summary>
			/// Property for CostingUnitCost
			/// </summary>
			public const string CostingUnitCost = "COSUNTCST";

			/// <summary>
			/// Property for CostingUnitConversion
			/// </summary>
			public const string CostingUnitConversion = "COSUNTCONV";

			/// <summary>
			/// Property for ExtendedAmount
			/// </summary>
			public const string ExtendedAmount = "EXTSHIMISC";

			/// <summary>
			/// Property for ShipmentDiscountAmount
			/// </summary>
			public const string ShipmentDiscountAmount = "SHIDISC";

			/// <summary>
			/// Property for ExtendedShipmentCost
			/// </summary>
			public const string ExtendedShipmentCost = "EXTSCOST";

			/// <summary>
			/// Property for ExtendedShippedAmtOverride
			/// </summary>
			public const string ExtendedShippedAmtOverride = "EXTOVER";

			/// <summary>
			/// Property for UnitWeight
			/// </summary>
			public const string UnitWeight = "UNITWEIGHT";

			/// <summary>
			/// Property for ExtendedWeight
			/// </summary>
			public const string ExtendedWeight = "EXTWEIGHT";

			/// <summary>
			/// Property for DetailCompleted
			/// </summary>
			public const string DetailCompleted = "COMPLETE";

			/// <summary>
			/// Property for ShipmentCompletesOrderDetail
			/// </summary>
			public const string ShipmentCompletesOrderDetail = "FINISHORD";

			/// <summary>
			/// Property for RecognizedInItemLocation
			/// </summary>
			public const string RecognizedInItemLocation = "ADDTOILOC";

			/// <summary>
			/// Property for LostSalesAmount
			/// </summary>
			public const string LostSalesAmount = "SALESLOST";

			/// <summary>
			/// Property for TaxAuthority1
			/// </summary>
			public const string TaxAuthority1 = "TAUTH1";

			/// <summary>
			/// Property for TaxAuthority2
			/// </summary>
			public const string TaxAuthority2 = "TAUTH2";

			/// <summary>
			/// Property for TaxAuthority3
			/// </summary>
			public const string TaxAuthority3 = "TAUTH3";

			/// <summary>
			/// Property for TaxAuthority4
			/// </summary>
			public const string TaxAuthority4 = "TAUTH4";

			/// <summary>
			/// Property for TaxAuthority5
			/// </summary>
			public const string TaxAuthority5 = "TAUTH5";

			/// <summary>
			/// Property for TaxClass1
			/// </summary>
			public const string TaxClass1 = "TCLASS1";

			/// <summary>
			/// Property for TaxClass2
			/// </summary>
			public const string TaxClass2 = "TCLASS2";

			/// <summary>
			/// Property for TaxClass3
			/// </summary>
			public const string TaxClass3 = "TCLASS3";

			/// <summary>
			/// Property for TaxClass4
			/// </summary>
			public const string TaxClass4 = "TCLASS4";

			/// <summary>
			/// Property for TaxClass5
			/// </summary>
			public const string TaxClass5 = "TCLASS5";

			/// <summary>
			/// Property for TaxIncluded1
			/// </summary>
			public const string TaxIncluded1 = "TINCLUDED1";

			/// <summary>
			/// Property for TaxIncluded2
			/// </summary>
			public const string TaxIncluded2 = "TINCLUDED2";

			/// <summary>
			/// Property for TaxIncluded3
			/// </summary>
			public const string TaxIncluded3 = "TINCLUDED3";

			/// <summary>
			/// Property for TaxIncluded4
			/// </summary>
			public const string TaxIncluded4 = "TINCLUDED4";

			/// <summary>
			/// Property for TaxIncluded5
			/// </summary>
			public const string TaxIncluded5 = "TINCLUDED5";

			/// <summary>
			/// Property for TaxBase1
			/// </summary>
			public const string TaxBase1 = "TBASE1";

			/// <summary>
			/// Property for TaxBase2
			/// </summary>
			public const string TaxBase2 = "TBASE2";

			/// <summary>
			/// Property for TaxBase3
			/// </summary>
			public const string TaxBase3 = "TBASE3";

			/// <summary>
			/// Property for TaxBase4
			/// </summary>
			public const string TaxBase4 = "TBASE4";

			/// <summary>
			/// Property for TaxBase5
			/// </summary>
			public const string TaxBase5 = "TBASE5";

			/// <summary>
			/// Property for TaxAmount1
			/// </summary>
			public const string TaxAmount1 = "TAMOUNT1";

			/// <summary>
			/// Property for TaxAmount2
			/// </summary>
			public const string TaxAmount2 = "TAMOUNT2";

			/// <summary>
			/// Property for TaxAmount3
			/// </summary>
			public const string TaxAmount3 = "TAMOUNT3";

			/// <summary>
			/// Property for TaxAmount4
			/// </summary>
			public const string TaxAmount4 = "TAMOUNT4";

			/// <summary>
			/// Property for TaxAmount5
			/// </summary>
			public const string TaxAmount5 = "TAMOUNT5";

			/// <summary>
			/// Property for TaxRate1
			/// </summary>
			public const string TaxRate1 = "TRATE1";

			/// <summary>
			/// Property for TaxRate2
			/// </summary>
			public const string TaxRate2 = "TRATE2";

			/// <summary>
			/// Property for TaxRate3
			/// </summary>
			public const string TaxRate3 = "TRATE3";

			/// <summary>
			/// Property for TaxRate4
			/// </summary>
			public const string TaxRate4 = "TRATE4";

			/// <summary>
			/// Property for TaxRate5
			/// </summary>
			public const string TaxRate5 = "TRATE5";

			/// <summary>
			/// Property for DetailNumber
			/// </summary>
			public const string DetailNumber = "DETAILNUM";

			/// <summary>
			/// Property for UseCommentsInstructions
			/// </summary>
			public const string UseCommentsInstructions = "COMMINST";

			/// <summary>
			/// Property for NonstockClearingAccount
			/// </summary>
			public const string NonstockClearingAccount = "GLNONSTKCR";

			/// <summary>
			/// Property for OrderNumber
			/// </summary>
			public const string OrderNumber = "ORDNUMBER";

			/// <summary>
			/// Property for OrderDetailNumber
			/// </summary>
			public const string OrderDetailNumber = "ORDDTLNUM";

			/// <summary>
			/// Property for StoredInDatabaseTable
			/// </summary>
			public const string StoredInDatabaseTable = "INDBTABLE";

			/// <summary>
			/// Property for RefreshOrderQtyatUpdate
			/// </summary>
			public const string RefreshOrderQtyatUpdate = "REFRESH";

			/// <summary>
			/// Property for ShipmentTrackingNumber
			/// </summary>
			public const string ShipmentTrackingNumber = "SHIPTRACK";

			/// <summary>
			/// Property for ShipViaCode
			/// </summary>
			public const string ShipViaCode = "SHIPVIA";

			/// <summary>
			/// Property for ShipViaCodeDescription
			/// </summary>
			public const string ShipViaCodeDescription = "VIADESC";

			/// <summary>
			/// Property for DiscountPercent
			/// </summary>
			public const string DiscountPercent = "DISCPER";

			/// <summary>
			/// Property for ManufacturersItemNumber
			/// </summary>
			public const string ManufacturersItemNumber = "MANITEMNO";

			/// <summary>
			/// Property for CustomerItemNumber
			/// </summary>
			public const string CustomerItemNumber = "CUSTITEMNO";

			/// <summary>
			/// Property for OptionalFields
			/// </summary>
			public const string OptionalFields = "VALUES";

			/// <summary>
			/// Property for KittingBOM
			/// </summary>
			public const string KittingBOM = "DDTLTYPE";

			/// <summary>
			/// Property for KitBOMNumber
			/// </summary>
			public const string KitBOMNumber = "DDTLNO";

			/// <summary>
			/// Property for BOMBuildQty
			/// </summary>
			public const string BOMBuildQty = "BUILDQTY";

			/// <summary>
			/// Property for BOMBuildUnit
			/// </summary>
			public const string BOMBuildUnit = "BUILDUNIT";

			/// <summary>
			/// Property for BOMBuildUnitConversion
			/// </summary>
			public const string BOMBuildUnitConversion = "BLDUNTCONV";

			/// <summary>
			/// Property for NextComponentNumber
			/// </summary>
			public const string NextComponentNumber = "NEXTCMPNUM";

			/// <summary>
			/// Property for ePOSPromotionID
			/// </summary>
			public const string ePOSPromotionID = "EPOSPROMID";

			/// <summary>
			/// Property for PricingBaseWeightUnit
			/// </summary>
			public const string PricingBaseWeightUnit = "BASEWUNIT";

			/// <summary>
			/// Property for WeightUnitOfMeasure
			/// </summary>
			public const string WeightUnitOfMeasure = "WEIGHTUNIT";

			/// <summary>
			/// Property for WeightConversionFactor
			/// </summary>
			public const string WeightConversionFactor = "WEIGHTCONV";

			/// <summary>
			/// Property for PricingWeightUOM
			/// </summary>
			public const string PricingWeightUOM = "PRWGHTUNIT";

			/// <summary>
			/// Property for PricingWeightConversionFactor
			/// </summary>
			public const string PricingWeightConversionFactor = "PRWGHTCONV";

			/// <summary>
			/// Property for PricingBaseWeightConvFactor
			/// </summary>
			public const string PricingBaseWeightConvFactor = "PRIBASWCNV";

			/// <summary>
			/// Property for DefWeightUOMUnitWeight
			/// </summary>
			public const string DefWeightUOMUnitWeight = "DEFUWEIGHT";

			/// <summary>
			/// Property for DefWeightUOMExtUnitWeight
			/// </summary>
			public const string DefWeightUOMExtUnitWeight = "DEFEXTWGHT";

			/// <summary>
			/// Property for PriceBy
			/// </summary>
			public const string PriceBy = "PRPRICEBY";

			/// <summary>
			/// Property for PriceCheckPending
			/// </summary>
			public const string PriceCheckPending = "NEEDPCHECK";

			/// <summary>
			/// Property for PriceApprovedBy
			/// </summary>
			public const string PriceApprovedBy = "CAPPROVEBY";

			/// <summary>
			/// Property for HeaderDiscount
			/// </summary>
			public const string HeaderDiscount = "HDRDISC";

			/// <summary>
			/// Property for TRTaxAmount1
			/// </summary>
			public const string TRTaxAmount1 = "STRAMOUNT1";

			/// <summary>
			/// Property for TRTaxAmount2
			/// </summary>
			public const string TRTaxAmount2 = "STRAMOUNT2";

			/// <summary>
			/// Property for TRTaxAmount3
			/// </summary>
			public const string TRTaxAmount3 = "STRAMOUNT3";

			/// <summary>
			/// Property for TRTaxAmount4
			/// </summary>
			public const string TRTaxAmount4 = "STRAMOUNT4";

			/// <summary>
			/// Property for TRTaxAmount5
			/// </summary>
			public const string TRTaxAmount5 = "STRAMOUNT5";

			/// <summary>
			/// Property for PickingSlipPrinted
			/// </summary>
			public const string PickingSlipPrinted = "PSPRINTED";

			/// <summary>
			/// Property for CostOfGoods
			/// </summary>
			public const string CostOfGoods = "COG";

			/// <summary>
			/// Property for JobRelated
			/// </summary>
			public const string JobRelated = "JOBRELATED";

			/// <summary>
			/// Property for ContractCode
			/// </summary>
			public const string ContractCode = "CONTRACT";

			/// <summary>
			/// Property for ProjectCode
			/// </summary>
			public const string ProjectCode = "PROJECT";

			/// <summary>
			/// Property for CategoryCode
			/// </summary>
			public const string CategoryCode = "CCATEGORY";

			/// <summary>
			/// Property for CostClass
			/// </summary>
			public const string CostClass = "COSTCLASS";

			/// <summary>
			/// Property for ProjectStyle
			/// </summary>
			public const string ProjectStyle = "PROJSTYLE";

			/// <summary>
			/// Property for ProjectType
			/// </summary>
			public const string ProjectType = "PROJTYPE";

			/// <summary>
			/// Property for AccountingMethod
			/// </summary>
			public const string AccountingMethod = "REVREC";

			/// <summary>
			/// Property for BillingType
			/// </summary>
			public const string BillingType = "BILLTYPE";

			/// <summary>
			/// Property for RevenueBillingAccount
			/// </summary>
			public const string RevenueBillingAccount = "REVBILL";

			/// <summary>
			/// Property for COGSWIPAccount
			/// </summary>
			public const string COGSWIPAccount = "COGSWIP";

			/// <summary>
			/// Property for RetainageAmount
			/// </summary>
			public const string RetainageAmount = "RTGAMOUNT";

			/// <summary>
			/// Property for RetainagePercent
			/// </summary>
			public const string RetainagePercent = "RTGPERCENT";

			/// <summary>
			/// Property for RetainageDays
			/// </summary>
			public const string RetainageDays = "RTGDAYS";

			/// <summary>
			/// Property for RetainageAmountOverride
			/// </summary>
			public const string RetainageAmountOverride = "RTGAMTOVR";

			/// <summary>
			/// Property for RetainageTaxBase1
			/// </summary>
			public const string RetainageTaxBase1 = "RTGTXBASE1";

			/// <summary>
			/// Property for RetainageTaxBase2
			/// </summary>
			public const string RetainageTaxBase2 = "RTGTXBASE2";

			/// <summary>
			/// Property for RetainageTaxBase3
			/// </summary>
			public const string RetainageTaxBase3 = "RTGTXBASE3";

			/// <summary>
			/// Property for RetainageTaxBase4
			/// </summary>
			public const string RetainageTaxBase4 = "RTGTXBASE4";

			/// <summary>
			/// Property for RetainageTaxBase5
			/// </summary>
			public const string RetainageTaxBase5 = "RTGTXBASE5";

			/// <summary>
			/// Property for RetainageTaxAmount1
			/// </summary>
			public const string RetainageTaxAmount1 = "RTGTXAMT1";

			/// <summary>
			/// Property for RetainageTaxAmount2
			/// </summary>
			public const string RetainageTaxAmount2 = "RTGTXAMT2";

			/// <summary>
			/// Property for RetainageTaxAmount3
			/// </summary>
			public const string RetainageTaxAmount3 = "RTGTXAMT3";

			/// <summary>
			/// Property for RetainageTaxAmount4
			/// </summary>
			public const string RetainageTaxAmount4 = "RTGTXAMT4";

			/// <summary>
			/// Property for RetainageTaxAmount5
			/// </summary>
			public const string RetainageTaxAmount5 = "RTGTXAMT5";

			/// <summary>
			/// Property for PMTransactionNumber
			/// </summary>
			public const string PMTransactionNumber = "PMTRANSNBR";

			/// <summary>
			/// Property for DefaultOEPrice
			/// </summary>
			public const string DefaultOEPrice = "PRICEOPT";

			/// <summary>
			/// Property for ARItemNumber
			/// </summary>
			public const string ARItemNumber = "ARITEMNO";

			/// <summary>
			/// Property for ARItemUnit
			/// </summary>
			public const string ARItemUnit = "ARUNIT";

			/// <summary>
			/// Property for PrepaymentDistributed
			/// </summary>
			public const string PrepaymentDistributed = "PAYMNTDIST";

			/// <summary>
			/// Property for SerialQuantity
			/// </summary>
			public const string SerialQuantity = "SERIALQTY";

			/// <summary>
			/// Property for LotQuantity
			/// </summary>
			public const string LotQuantity = "LOTQTY";

			/// <summary>
			/// Property for ItemSerializedLotted
			/// </summary>
			public const string ItemSerializedLotted = "SLITEM";

			/// <summary>
			/// Property for SageCRMCompanyID
			/// </summary>
			public const string SageCRMCompanyID = "COMPANYID";

			/// <summary>
			/// Property for SageCRMOpportunityID
			/// </summary>
			public const string SageCRMOpportunityID = "OPPOID";

			/// <summary>
			/// Property for TotalShipmentMostRecentCost
			/// </summary>
			public const string TotalShipmentMostRecentCost = "EXTSMOSTRE";

			/// <summary>
			/// Property for TotalShipmentStandardCost
			/// </summary>
			public const string TotalShipmentStandardCost = "EXTSSTDCOS";

			/// <summary>
			/// Property for TotalShipmentCost1
			/// </summary>
			public const string TotalShipmentCost1 = "EXTSCOST1";

			/// <summary>
			/// Property for TotalShipmentCost2
			/// </summary>
			public const string TotalShipmentCost2 = "EXTSCOST2";

			/// <summary>
			/// Property for TotalShipmentAverageCost
			/// </summary>
			public const string TotalShipmentAverageCost = "EXTSAVGCST";

			/// <summary>
			/// Property for TotalShipmentLastCost
			/// </summary>
			public const string TotalShipmentLastCost = "EXTSLSTCST";

			/// <summary>
			/// Property for PriceListDescription
			/// </summary>
			public const string PriceListDescription = "PCODDESC";

			/// <summary>
			/// Property for CategoryDescription
			/// </summary>
			public const string CategoryDescription = "CATGDESC";

			/// <summary>
			/// Property for LocationDescription
			/// </summary>
			public const string LocationDescription = "LOCDESC";

			/// <summary>
			/// Property for TaxAuthority1Description
			/// </summary>
			public const string TaxAuthority1Description = "TAUTH1DESC";

			/// <summary>
			/// Property for TaxAuthority2Description
			/// </summary>
			public const string TaxAuthority2Description = "TAUTH2DESC";

			/// <summary>
			/// Property for TaxAuthority3Description
			/// </summary>
			public const string TaxAuthority3Description = "TAUTH3DESC";

			/// <summary>
			/// Property for TaxAuthority4Description
			/// </summary>
			public const string TaxAuthority4Description = "TAUTH4DESC";

			/// <summary>
			/// Property for TaxAuthority5Description
			/// </summary>
			public const string TaxAuthority5Description = "TAUTH5DESC";

			/// <summary>
			/// Property for TaxClass1Description
			/// </summary>
			public const string TaxClass1Description = "TCLAS1DESC";

			/// <summary>
			/// Property for TaxClass2Description
			/// </summary>
			public const string TaxClass2Description = "TCLAS2DESC";

			/// <summary>
			/// Property for TaxClass3Description
			/// </summary>
			public const string TaxClass3Description = "TCLAS3DESC";

			/// <summary>
			/// Property for TaxClass4Description
			/// </summary>
			public const string TaxClass4Description = "TCLAS4DESC";

			/// <summary>
			/// Property for TaxClass5Description
			/// </summary>
			public const string TaxClass5Description = "TCLAS5DESC";

			/// <summary>
			/// Property for DrivenbyUI
			/// </summary>
			public const string DrivenbyUI = "DRIVENBYUI";

			/// <summary>
			/// Property for FoundNegativeInventory
			/// </summary>
			public const string FoundNegativeInventory = "NEGINVENT";

			/// <summary>
			/// Property for NegativeInventoryLevelOnDele
			/// </summary>
			public const string NegativeInventoryLevelOnDele = "NEGINVDEL";

			/// <summary>
			/// Property for NonstockClearingAcctDesc
			/// </summary>
			public const string NonstockClearingAcctDesc = "GLNONSTKCD";

			/// <summary>
			/// Property for ExtendedDiscountedPrice
			/// </summary>
			public const string ExtendedDiscountedPrice = "EDCSHIMISC";

			/// <summary>
			/// Property for Action
			/// </summary>
			public const string Action = "ACTION";

			/// <summary>
			/// Property for InterprocessCommID
			/// </summary>
			public const string InterprocessCommID = "IPCID";

			/// <summary>
			/// Property for ForcePopupSNonQtyOrdered
			/// </summary>
			public const string ForcePopupSNonQtyOrdered = "FPOPSNQO";

			/// <summary>
			/// Property for ForcePopupSNonQtyShipped
			/// </summary>
			public const string ForcePopupSNonQtyShipped = "FPOPSNQS";

			/// <summary>
			/// Property for PopupSN
			/// </summary>
			public const string PopupSN = "POPUPSN";

			/// <summary>
			/// Property for CloseSN
			/// </summary>
			public const string CloseSN = "CLOSESN";

			/// <summary>
			/// Property for LTSetID
			/// </summary>
			public const string LTSetID = "LTSETID";

			/// <summary>
			/// Property for ForcePopupLTonQtyOrdered
			/// </summary>
			public const string ForcePopupLTonQtyOrdered = "FPOPLTQO";

			/// <summary>
			/// Property for ForcePopupLTonQtyShipped
			/// </summary>
			public const string ForcePopupLTonQtyShipped = "FPOPLTQS";

			/// <summary>
			/// Property for PopupLT
			/// </summary>
			public const string PopupLT = "POPUPLT";

			/// <summary>
			/// Property for CloseLT
			/// </summary>
			public const string CloseLT = "CLOSELT";

			/// <summary>
			/// Property for OrderUniquifier
			/// </summary>
			public const string OrderUniquifier = "ORDUNIQ";

			/// <summary>
			/// Property for ItemSerialized
			/// </summary>
			public const string ItemSerialized = "SERIALITEM";

			/// <summary>
			/// Property for UnformattedItemNumber
			/// </summary>
			public const string UnformattedItemNumber = "UNFMTITEM";

			/// <summary>
			/// Property for OrderLineNumber
			/// </summary>
			public const string OrderLineNumber = "ORDLINENUM";

			/// <summary>
			/// Property for ProcessCommand
			/// </summary>
			public const string ProcessCommand = "PROCESSCMD";

			/// <summary>
			/// Property for ApprovingUsersPassword
			/// </summary>
			public const string ApprovingUsersPassword = "CAPPRPWORD";

			/// <summary>
			/// Property for PriceApprovalNeeded
			/// </summary>
			public const string PriceApprovalNeeded = "NEEDCAPP";

			/// <summary>
			/// Property for WeightUOMDescription
			/// </summary>
			public const string WeightUOMDescription = "WUOMDESC";

			/// <summary>
			/// Property for ExtendedAmountNetOfTax
			/// </summary>
			public const string ExtendedAmountNetOfTax = "EXTNETPRI";

			/// <summary>
			/// Property for DiscountedExtendedAmount
			/// </summary>
			public const string DiscountedExtendedAmount = "DISSHIMISC";

			/// <summary>
			/// Property for TaxTotal
			/// </summary>
			public const string TaxTotal = "TAXTOTAL";

			/// <summary>
			/// Property for TRTaxTotal
			/// </summary>
			public const string TRTaxTotal = "STRTOTAL";

			/// <summary>
			/// Property for Level1Name
			/// </summary>
			public const string Level1Name = "LVL1NAME";

			/// <summary>
			/// Property for Level2Name
			/// </summary>
			public const string Level2Name = "LVL2NAME";

			/// <summary>
			/// Property for Level3Name
			/// </summary>
			public const string Level3Name = "LVL3NAME";

			/// <summary>
			/// Property for UnformattedContractCode
			/// </summary>
			public const string UnformattedContractCode = "UFMTCONTNO";

			/// <summary>
			/// Property for ExtPriceNetOfDiscIncTax
			/// </summary>
			public const string ExtPriceNetOfDiscIncTax = "NETPRIWTX";

			/// <summary>
			/// Property for DetailAmountDue
			/// </summary>
			public const string DetailAmountDue = "SHIDUE";

			/// <summary>
			/// Property for SerialLotQuantityToProcess
			/// </summary>
			public const string SerialLotQuantityToProcess = "XGENALCQTY";

			/// <summary>
			/// Property for NumberOfLotsToGenerate
			/// </summary>
			public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

			/// <summary>
			/// Property for QuantityperLot
			/// </summary>
			public const string QuantityperLot = "XPERLOTQTY";

			/// <summary>
			/// Property for AllocateFromSerial
			/// </summary>
			public const string AllocateFromSerial = "SALLOCFROM";

			/// <summary>
			/// Property for AllocateFromLot
			/// </summary>
			public const string AllocateFromLot = "LALLOCFROM";

			/// <summary>
			/// Property for SerialLotWindowHandle
			/// </summary>
			public const string SerialLotWindowHandle = "METERHWND";


            /// <summary>
			/// Property Indexer for NonInteractivePriceApproval
			/// </summary>
            public const string NonInteractivePriceApproval = "SETCAPPR";
            
		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ShipmentDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ShipmentUniquifier
			/// </summary>
			public const int ShipmentUniquifier = 1;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 2;

			/// <summary>
			/// Property Indexer for LineType
			/// </summary>
			public const int LineType = 3;

			/// <summary>
			/// Property Indexer for Item
			/// </summary>
			public const int Item = 4;

			/// <summary>
			/// Property Indexer for MiscellaneousChargesCode
			/// </summary>
			public const int MiscellaneousChargesCode = 5;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 6;

			/// <summary>
			/// Property Indexer for ItemAccountSet
			/// </summary>
			public const int ItemAccountSet = 7;

			/// <summary>
			/// Property Indexer for UserSpecifiedCostingMethod
			/// </summary>
			public const int UserSpecifiedCostingMethod = 8;

			/// <summary>
			/// Property Indexer for PriceList
			/// </summary>
			public const int PriceList = 9;

			/// <summary>
			/// Property Indexer for Category
			/// </summary>
			public const int Category = 10;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 11;

			/// <summary>
			/// Property Indexer for PickingSequence
			/// </summary>
			public const int PickingSequence = 12;

			/// <summary>
			/// Property Indexer for ShipmentDate
			/// </summary>
			public const int ShipmentDate = 13;

			/// <summary>
			/// Property Indexer for StockItem
			/// </summary>
			public const int StockItem = 14;

			/// <summary>
			/// Property Indexer for OrderQuantityOrdered
			/// </summary>
			public const int OrderQuantityOrdered = 15;

			/// <summary>
			/// Property Indexer for OrderQuantityBackordered
			/// </summary>
			public const int OrderQuantityBackordered = 16;

			/// <summary>
			/// Property Indexer for OrderQuantityCommitted
			/// </summary>
			public const int OrderQuantityCommitted = 17;

			/// <summary>
			/// Property Indexer for OrderTrueQuantityCommitted
			/// </summary>
			public const int OrderTrueQuantityCommitted = 18;

			/// <summary>
			/// Property Indexer for OrderQuantityShippedtodate
			/// </summary>
			public const int OrderQuantityShippedtodate = 19;

			/// <summary>
			/// Property Indexer for OrderUnitOfMeasure
			/// </summary>
			public const int OrderUnitOfMeasure = 20;

			/// <summary>
			/// Property Indexer for OrderUnitConversion
			/// </summary>
			public const int OrderUnitConversion = 21;

			/// <summary>
			/// Property Indexer for CurrentQuantityOutstanding
			/// </summary>
			public const int CurrentQuantityOutstanding = 22;

			/// <summary>
			/// Property Indexer for QuantityShipped
			/// </summary>
			public const int QuantityShipped = 23;

			/// <summary>
			/// Property Indexer for QuantityBackordered
			/// </summary>
			public const int QuantityBackordered = 24;

			/// <summary>
			/// Property Indexer for QuantityCommitted
			/// </summary>
			public const int QuantityCommitted = 25;

			/// <summary>
			/// Property Indexer for TrueQuantityCommitted
			/// </summary>
			public const int TrueQuantityCommitted = 26;

			/// <summary>
			/// Property Indexer for ShipmentUnitOfMeasure
			/// </summary>
			public const int ShipmentUnitOfMeasure = 27;

			/// <summary>
			/// Property Indexer for ShipmentUnitConversion
			/// </summary>
			public const int ShipmentUnitConversion = 28;

			/// <summary>
			/// Property Indexer for ShipmentUnitPrice
			/// </summary>
			public const int ShipmentUnitPrice = 29;

			/// <summary>
			/// Property Indexer for PriceOverride
			/// </summary>
			public const int PriceOverride = 30;

			/// <summary>
			/// Property Indexer for ShipmentUnitCost
			/// </summary>
			public const int ShipmentUnitCost = 31;

			/// <summary>
			/// Property Indexer for MostRecentUnitCost
			/// </summary>
			public const int MostRecentUnitCost = 32;

			/// <summary>
			/// Property Indexer for StandardUnitCost
			/// </summary>
			public const int StandardUnitCost = 33;

			/// <summary>
			/// Property Indexer for AlternateUnitCost1
			/// </summary>
			public const int AlternateUnitCost1 = 34;

			/// <summary>
			/// Property Indexer for AlternateUnitCost2
			/// </summary>
			public const int AlternateUnitCost2 = 35;

			/// <summary>
			/// Property Indexer for AverageCost
			/// </summary>
			public const int AverageCost = 36;

			/// <summary>
			/// Property Indexer for LastCost
			/// </summary>
			public const int LastCost = 37;

			/// <summary>
			/// Property Indexer for UnitPriceNoOfDecimals
			/// </summary>
			public const int UnitPriceNoOfDecimals = 38;

			/// <summary>
			/// Property Indexer for PricingUnitOfMeasure
			/// </summary>
			public const int PricingUnitOfMeasure = 39;

			/// <summary>
			/// Property Indexer for PricingUnitPrice
			/// </summary>
			public const int PricingUnitPrice = 40;

			/// <summary>
			/// Property Indexer for PricingUnitConversion
			/// </summary>
			public const int PricingUnitConversion = 41;

			/// <summary>
			/// Property Indexer for PriceDiscountPercentage
			/// </summary>
			public const int PriceDiscountPercentage = 42;

			/// <summary>
			/// Property Indexer for PriceDiscountAmount
			/// </summary>
			public const int PriceDiscountAmount = 43;

			/// <summary>
			/// Property Indexer for PricingBaseUnit
			/// </summary>
			public const int PricingBaseUnit = 44;

			/// <summary>
			/// Property Indexer for PricingBaseUnitPrice
			/// </summary>
			public const int PricingBaseUnitPrice = 45;

			/// <summary>
			/// Property Indexer for PricingBaseUnitConversion
			/// </summary>
			public const int PricingBaseUnitConversion = 46;

			/// <summary>
			/// Property Indexer for CostingUnitOfMeasure
			/// </summary>
			public const int CostingUnitOfMeasure = 47;

			/// <summary>
			/// Property Indexer for CostingUnitCost
			/// </summary>
			public const int CostingUnitCost = 48;

			/// <summary>
			/// Property Indexer for CostingUnitConversion
			/// </summary>
			public const int CostingUnitConversion = 49;

			/// <summary>
			/// Property Indexer for ExtendedAmount
			/// </summary>
			public const int ExtendedAmount = 50;

			/// <summary>
			/// Property Indexer for ShipmentDiscountAmount
			/// </summary>
			public const int ShipmentDiscountAmount = 51;

			/// <summary>
			/// Property Indexer for ExtendedShipmentCost
			/// </summary>
			public const int ExtendedShipmentCost = 52;

			/// <summary>
			/// Property Indexer for ExtendedShippedAmtOverride
			/// </summary>
			public const int ExtendedShippedAmtOverride = 53;

			/// <summary>
			/// Property Indexer for UnitWeight
			/// </summary>
			public const int UnitWeight = 54;

			/// <summary>
			/// Property Indexer for ExtendedWeight
			/// </summary>
			public const int ExtendedWeight = 55;

			/// <summary>
			/// Property Indexer for DetailCompleted
			/// </summary>
			public const int DetailCompleted = 56;

			/// <summary>
			/// Property Indexer for ShipmentCompletesOrderDetail
			/// </summary>
			public const int ShipmentCompletesOrderDetail = 57;

			/// <summary>
			/// Property Indexer for RecognizedInItemLocation
			/// </summary>
			public const int RecognizedInItemLocation = 58;

			/// <summary>
			/// Property Indexer for LostSalesAmount
			/// </summary>
			public const int LostSalesAmount = 59;

			/// <summary>
			/// Property Indexer for TaxAuthority1
			/// </summary>
			public const int TaxAuthority1 = 60;

			/// <summary>
			/// Property Indexer for TaxAuthority2
			/// </summary>
			public const int TaxAuthority2 = 61;

			/// <summary>
			/// Property Indexer for TaxAuthority3
			/// </summary>
			public const int TaxAuthority3 = 62;

			/// <summary>
			/// Property Indexer for TaxAuthority4
			/// </summary>
			public const int TaxAuthority4 = 63;

			/// <summary>
			/// Property Indexer for TaxAuthority5
			/// </summary>
			public const int TaxAuthority5 = 64;

			/// <summary>
			/// Property Indexer for TaxClass1
			/// </summary>
			public const int TaxClass1 = 65;

			/// <summary>
			/// Property Indexer for TaxClass2
			/// </summary>
			public const int TaxClass2 = 66;

			/// <summary>
			/// Property Indexer for TaxClass3
			/// </summary>
			public const int TaxClass3 = 67;

			/// <summary>
			/// Property Indexer for TaxClass4
			/// </summary>
			public const int TaxClass4 = 68;

			/// <summary>
			/// Property Indexer for TaxClass5
			/// </summary>
			public const int TaxClass5 = 69;

			/// <summary>
			/// Property Indexer for TaxIncluded1
			/// </summary>
			public const int TaxIncluded1 = 70;

			/// <summary>
			/// Property Indexer for TaxIncluded2
			/// </summary>
			public const int TaxIncluded2 = 71;

			/// <summary>
			/// Property Indexer for TaxIncluded3
			/// </summary>
			public const int TaxIncluded3 = 72;

			/// <summary>
			/// Property Indexer for TaxIncluded4
			/// </summary>
			public const int TaxIncluded4 = 73;

			/// <summary>
			/// Property Indexer for TaxIncluded5
			/// </summary>
			public const int TaxIncluded5 = 74;

			/// <summary>
			/// Property Indexer for TaxBase1
			/// </summary>
			public const int TaxBase1 = 75;

			/// <summary>
			/// Property Indexer for TaxBase2
			/// </summary>
			public const int TaxBase2 = 76;

			/// <summary>
			/// Property Indexer for TaxBase3
			/// </summary>
			public const int TaxBase3 = 77;

			/// <summary>
			/// Property Indexer for TaxBase4
			/// </summary>
			public const int TaxBase4 = 78;

			/// <summary>
			/// Property Indexer for TaxBase5
			/// </summary>
			public const int TaxBase5 = 79;

			/// <summary>
			/// Property Indexer for TaxAmount1
			/// </summary>
			public const int TaxAmount1 = 80;

			/// <summary>
			/// Property Indexer for TaxAmount2
			/// </summary>
			public const int TaxAmount2 = 81;

			/// <summary>
			/// Property Indexer for TaxAmount3
			/// </summary>
			public const int TaxAmount3 = 82;

			/// <summary>
			/// Property Indexer for TaxAmount4
			/// </summary>
			public const int TaxAmount4 = 83;

			/// <summary>
			/// Property Indexer for TaxAmount5
			/// </summary>
			public const int TaxAmount5 = 84;

			/// <summary>
			/// Property Indexer for TaxRate1
			/// </summary>
			public const int TaxRate1 = 85;

			/// <summary>
			/// Property Indexer for TaxRate2
			/// </summary>
			public const int TaxRate2 = 86;

			/// <summary>
			/// Property Indexer for TaxRate3
			/// </summary>
			public const int TaxRate3 = 87;

			/// <summary>
			/// Property Indexer for TaxRate4
			/// </summary>
			public const int TaxRate4 = 88;

			/// <summary>
			/// Property Indexer for TaxRate5
			/// </summary>
			public const int TaxRate5 = 89;

			/// <summary>
			/// Property Indexer for DetailNumber
			/// </summary>
			public const int DetailNumber = 91;

			/// <summary>
			/// Property Indexer for UseCommentsInstructions
			/// </summary>
			public const int UseCommentsInstructions = 93;

			/// <summary>
			/// Property Indexer for NonstockClearingAccount
			/// </summary>
			public const int NonstockClearingAccount = 94;

			/// <summary>
			/// Property Indexer for OrderNumber
			/// </summary>
			public const int OrderNumber = 95;

			/// <summary>
			/// Property Indexer for OrderDetailNumber
			/// </summary>
			public const int OrderDetailNumber = 96;

			/// <summary>
			/// Property Indexer for StoredInDatabaseTable
			/// </summary>
			public const int StoredInDatabaseTable = 97;

			/// <summary>
			/// Property Indexer for RefreshOrderQtyatUpdate
			/// </summary>
			public const int RefreshOrderQtyatUpdate = 98;

			/// <summary>
			/// Property Indexer for ShipmentTrackingNumber
			/// </summary>
			public const int ShipmentTrackingNumber = 99;

			/// <summary>
			/// Property Indexer for ShipViaCode
			/// </summary>
			public const int ShipViaCode = 100;

			/// <summary>
			/// Property Indexer for ShipViaCodeDescription
			/// </summary>
			public const int ShipViaCodeDescription = 101;

			/// <summary>
			/// Property Indexer for DiscountPercent
			/// </summary>
			public const int DiscountPercent = 102;

			/// <summary>
			/// Property Indexer for ManufacturersItemNumber
			/// </summary>
			public const int ManufacturersItemNumber = 103;

			/// <summary>
			/// Property Indexer for CustomerItemNumber
			/// </summary>
			public const int CustomerItemNumber = 104;

			/// <summary>
			/// Property Indexer for OptionalFields
			/// </summary>
			public const int OptionalFields = 105;

			/// <summary>
			/// Property Indexer for KittingBOM
			/// </summary>
			public const int KittingBOM = 106;

			/// <summary>
			/// Property Indexer for KitBOMNumber
			/// </summary>
			public const int KitBOMNumber = 107;

			/// <summary>
			/// Property Indexer for BOMBuildQty
			/// </summary>
			public const int BOMBuildQty = 108;

			/// <summary>
			/// Property Indexer for BOMBuildUnit
			/// </summary>
			public const int BOMBuildUnit = 109;

			/// <summary>
			/// Property Indexer for BOMBuildUnitConversion
			/// </summary>
			public const int BOMBuildUnitConversion = 110;

			/// <summary>
			/// Property Indexer for NextComponentNumber
			/// </summary>
			public const int NextComponentNumber = 111;

			/// <summary>
			/// Property Indexer for ePOSPromotionID
			/// </summary>
			public const int ePOSPromotionID = 112;

			/// <summary>
			/// Property Indexer for PricingBaseWeightUnit
			/// </summary>
			public const int PricingBaseWeightUnit = 113;

			/// <summary>
			/// Property Indexer for WeightUnitOfMeasure
			/// </summary>
			public const int WeightUnitOfMeasure = 114;

			/// <summary>
			/// Property Indexer for WeightConversionFactor
			/// </summary>
			public const int WeightConversionFactor = 115;

			/// <summary>
			/// Property Indexer for PricingWeightUOM
			/// </summary>
			public const int PricingWeightUOM = 116;

			/// <summary>
			/// Property Indexer for PricingWeightConversionFactor
			/// </summary>
			public const int PricingWeightConversionFactor = 117;

			/// <summary>
			/// Property Indexer for PricingBaseWeightConvFactor
			/// </summary>
			public const int PricingBaseWeightConvFactor = 118;

			/// <summary>
			/// Property Indexer for DefWeightUOMUnitWeight
			/// </summary>
			public const int DefWeightUOMUnitWeight = 119;

			/// <summary>
			/// Property Indexer for DefWeightUOMExtUnitWeight
			/// </summary>
			public const int DefWeightUOMExtUnitWeight = 120;

			/// <summary>
			/// Property Indexer for PriceBy
			/// </summary>
			public const int PriceBy = 121;

			/// <summary>
			/// Property Indexer for PriceCheckPending
			/// </summary>
			public const int PriceCheckPending = 122;

			/// <summary>
			/// Property Indexer for PriceApprovedBy
			/// </summary>
			public const int PriceApprovedBy = 123;

			/// <summary>
			/// Property Indexer for HeaderDiscount
			/// </summary>
			public const int HeaderDiscount = 124;

			/// <summary>
			/// Property Indexer for TRTaxAmount1
			/// </summary>
			public const int TRTaxAmount1 = 125;

			/// <summary>
			/// Property Indexer for TRTaxAmount2
			/// </summary>
			public const int TRTaxAmount2 = 126;

			/// <summary>
			/// Property Indexer for TRTaxAmount3
			/// </summary>
			public const int TRTaxAmount3 = 127;

			/// <summary>
			/// Property Indexer for TRTaxAmount4
			/// </summary>
			public const int TRTaxAmount4 = 128;

			/// <summary>
			/// Property Indexer for TRTaxAmount5
			/// </summary>
			public const int TRTaxAmount5 = 129;

			/// <summary>
			/// Property Indexer for PickingSlipPrinted
			/// </summary>
			public const int PickingSlipPrinted = 130;

			/// <summary>
			/// Property Indexer for CostOfGoods
			/// </summary>
			public const int CostOfGoods = 131;

			/// <summary>
			/// Property Indexer for JobRelated
			/// </summary>
			public const int JobRelated = 132;

			/// <summary>
			/// Property Indexer for ContractCode
			/// </summary>
			public const int ContractCode = 133;

			/// <summary>
			/// Property Indexer for ProjectCode
			/// </summary>
			public const int ProjectCode = 134;

			/// <summary>
			/// Property Indexer for CategoryCode
			/// </summary>
			public const int CategoryCode = 135;

			/// <summary>
			/// Property Indexer for CostClass
			/// </summary>
			public const int CostClass = 136;

			/// <summary>
			/// Property Indexer for ProjectStyle
			/// </summary>
			public const int ProjectStyle = 137;

			/// <summary>
			/// Property Indexer for ProjectType
			/// </summary>
			public const int ProjectType = 138;

			/// <summary>
			/// Property Indexer for AccountingMethod
			/// </summary>
			public const int AccountingMethod = 139;

			/// <summary>
			/// Property Indexer for BillingType
			/// </summary>
			public const int BillingType = 140;

			/// <summary>
			/// Property Indexer for RevenueBillingAccount
			/// </summary>
			public const int RevenueBillingAccount = 141;

			/// <summary>
			/// Property Indexer for COGSWIPAccount
			/// </summary>
			public const int COGSWIPAccount = 142;

			/// <summary>
			/// Property Indexer for RetainageAmount
			/// </summary>
			public const int RetainageAmount = 143;

			/// <summary>
			/// Property Indexer for RetainagePercent
			/// </summary>
			public const int RetainagePercent = 144;

			/// <summary>
			/// Property Indexer for RetainageDays
			/// </summary>
			public const int RetainageDays = 145;

			/// <summary>
			/// Property Indexer for RetainageAmountOverride
			/// </summary>
			public const int RetainageAmountOverride = 146;

			/// <summary>
			/// Property Indexer for RetainageTaxBase1
			/// </summary>
			public const int RetainageTaxBase1 = 147;

			/// <summary>
			/// Property Indexer for RetainageTaxBase2
			/// </summary>
			public const int RetainageTaxBase2 = 148;

			/// <summary>
			/// Property Indexer for RetainageTaxBase3
			/// </summary>
			public const int RetainageTaxBase3 = 149;

			/// <summary>
			/// Property Indexer for RetainageTaxBase4
			/// </summary>
			public const int RetainageTaxBase4 = 150;

			/// <summary>
			/// Property Indexer for RetainageTaxBase5
			/// </summary>
			public const int RetainageTaxBase5 = 151;

			/// <summary>
			/// Property Indexer for RetainageTaxAmount1
			/// </summary>
			public const int RetainageTaxAmount1 = 152;

			/// <summary>
			/// Property Indexer for RetainageTaxAmount2
			/// </summary>
			public const int RetainageTaxAmount2 = 153;

			/// <summary>
			/// Property Indexer for RetainageTaxAmount3
			/// </summary>
			public const int RetainageTaxAmount3 = 154;

			/// <summary>
			/// Property Indexer for RetainageTaxAmount4
			/// </summary>
			public const int RetainageTaxAmount4 = 155;

			/// <summary>
			/// Property Indexer for RetainageTaxAmount5
			/// </summary>
			public const int RetainageTaxAmount5 = 156;

			/// <summary>
			/// Property Indexer for PMTransactionNumber
			/// </summary>
			public const int PMTransactionNumber = 157;

			/// <summary>
			/// Property Indexer for DefaultOEPrice
			/// </summary>
			public const int DefaultOEPrice = 158;

			/// <summary>
			/// Property Indexer for ARItemNumber
			/// </summary>
			public const int ARItemNumber = 159;

			/// <summary>
			/// Property Indexer for ARItemUnit
			/// </summary>
			public const int ARItemUnit = 160;

			/// <summary>
			/// Property Indexer for PrepaymentDistributed
			/// </summary>
			public const int PrepaymentDistributed = 161;

			/// <summary>
			/// Property Indexer for SerialQuantity
			/// </summary>
			public const int SerialQuantity = 162;

			/// <summary>
			/// Property Indexer for LotQuantity
			/// </summary>
			public const int LotQuantity = 163;

			/// <summary>
			/// Property Indexer for ItemSerializedLotted
			/// </summary>
			public const int ItemSerializedLotted = 164;

			/// <summary>
			/// Property Indexer for SageCRMCompanyID
			/// </summary>
			public const int SageCRMCompanyID = 165;

			/// <summary>
			/// Property Indexer for SageCRMOpportunityID
			/// </summary>
			public const int SageCRMOpportunityID = 166;

			/// <summary>
			/// Property Indexer for TotalShipmentMostRecentCost
			/// </summary>
			public const int TotalShipmentMostRecentCost = 200;

			/// <summary>
			/// Property Indexer for TotalShipmentStandardCost
			/// </summary>
			public const int TotalShipmentStandardCost = 201;

			/// <summary>
			/// Property Indexer for TotalShipmentCost1
			/// </summary>
			public const int TotalShipmentCost1 = 202;

			/// <summary>
			/// Property Indexer for TotalShipmentCost2
			/// </summary>
			public const int TotalShipmentCost2 = 203;

			/// <summary>
			/// Property Indexer for TotalShipmentAverageCost
			/// </summary>
			public const int TotalShipmentAverageCost = 204;

			/// <summary>
			/// Property Indexer for TotalShipmentLastCost
			/// </summary>
			public const int TotalShipmentLastCost = 205;

			/// <summary>
			/// Property Indexer for PriceListDescription
			/// </summary>
			public const int PriceListDescription = 206;

			/// <summary>
			/// Property Indexer for CategoryDescription
			/// </summary>
			public const int CategoryDescription = 207;

			/// <summary>
			/// Property Indexer for LocationDescription
			/// </summary>
			public const int LocationDescription = 208;

			/// <summary>
			/// Property Indexer for TaxAuthority1Description
			/// </summary>
			public const int TaxAuthority1Description = 209;

			/// <summary>
			/// Property Indexer for TaxAuthority2Description
			/// </summary>
			public const int TaxAuthority2Description = 210;

			/// <summary>
			/// Property Indexer for TaxAuthority3Description
			/// </summary>
			public const int TaxAuthority3Description = 211;

			/// <summary>
			/// Property Indexer for TaxAuthority4Description
			/// </summary>
			public const int TaxAuthority4Description = 212;

			/// <summary>
			/// Property Indexer for TaxAuthority5Description
			/// </summary>
			public const int TaxAuthority5Description = 213;

			/// <summary>
			/// Property Indexer for TaxClass1Description
			/// </summary>
			public const int TaxClass1Description = 214;

			/// <summary>
			/// Property Indexer for TaxClass2Description
			/// </summary>
			public const int TaxClass2Description = 215;

			/// <summary>
			/// Property Indexer for TaxClass3Description
			/// </summary>
			public const int TaxClass3Description = 216;

			/// <summary>
			/// Property Indexer for TaxClass4Description
			/// </summary>
			public const int TaxClass4Description = 217;

			/// <summary>
			/// Property Indexer for TaxClass5Description
			/// </summary>
			public const int TaxClass5Description = 218;

			/// <summary>
			/// Property Indexer for DrivenbyUI
			/// </summary>
			public const int DrivenbyUI = 219;

			/// <summary>
			/// Property Indexer for FoundNegativeInventory
			/// </summary>
			public const int FoundNegativeInventory = 220;

			/// <summary>
			/// Property Indexer for NegativeInventoryLevelOnDele
			/// </summary>
			public const int NegativeInventoryLevelOnDele = 221;

			/// <summary>
			/// Property Indexer for NonstockClearingAcctDesc
			/// </summary>
			public const int NonstockClearingAcctDesc = 222;

			/// <summary>
			/// Property Indexer for ExtendedDiscountedPrice
			/// </summary>
			public const int ExtendedDiscountedPrice = 223;

			/// <summary>
			/// Property Indexer for Action
			/// </summary>
			public const int Action = 224;

			/// <summary>
			/// Property Indexer for InterprocessCommID
			/// </summary>
			public const int InterprocessCommID = 225;

			/// <summary>
			/// Property Indexer for ForcePopupSNonQtyOrdered
			/// </summary>
			public const int ForcePopupSNonQtyOrdered = 226;

			/// <summary>
			/// Property Indexer for ForcePopupSNonQtyShipped
			/// </summary>
			public const int ForcePopupSNonQtyShipped = 227;

			/// <summary>
			/// Property Indexer for PopupSN
			/// </summary>
			public const int PopupSN = 228;

			/// <summary>
			/// Property Indexer for CloseSN
			/// </summary>
			public const int CloseSN = 229;

			/// <summary>
			/// Property Indexer for LTSetID
			/// </summary>
			public const int LTSetID = 230;

			/// <summary>
			/// Property Indexer for ForcePopupLTonQtyOrdered
			/// </summary>
			public const int ForcePopupLTonQtyOrdered = 231;

			/// <summary>
			/// Property Indexer for ForcePopupLTonQtyShipped
			/// </summary>
			public const int ForcePopupLTonQtyShipped = 232;

			/// <summary>
			/// Property Indexer for PopupLT
			/// </summary>
			public const int PopupLT = 233;

			/// <summary>
			/// Property Indexer for CloseLT
			/// </summary>
			public const int CloseLT = 234;

			/// <summary>
			/// Property Indexer for OrderUniquifier
			/// </summary>
			public const int OrderUniquifier = 235;

			/// <summary>
			/// Property Indexer for ItemSerialized
			/// </summary>
			public const int ItemSerialized = 236;

			/// <summary>
			/// Property Indexer for UnformattedItemNumber
			/// </summary>
			public const int UnformattedItemNumber = 237;

			/// <summary>
			/// Property Indexer for OrderLineNumber
			/// </summary>
			public const int OrderLineNumber = 238;

			/// <summary>
			/// Property Indexer for ProcessCommand
			/// </summary>
			public const int ProcessCommand = 239;

			/// <summary>
			/// Property Indexer for ApprovingUsersPassword
			/// </summary>
			public const int ApprovingUsersPassword = 240;

			/// <summary>
			/// Property Indexer for PriceApprovalNeeded
			/// </summary>
			public const int PriceApprovalNeeded = 241;

			/// <summary>
			/// Property Indexer for WeightUOMDescription
			/// </summary>
			public const int WeightUOMDescription = 242;

			/// <summary>
			/// Property Indexer for ExtendedAmountNetOfTax
			/// </summary>
			public const int ExtendedAmountNetOfTax = 243;

			/// <summary>
			/// Property Indexer for DiscountedExtendedAmount
			/// </summary>
			public const int DiscountedExtendedAmount = 244;

			/// <summary>
			/// Property Indexer for TaxTotal
			/// </summary>
			public const int TaxTotal = 245;

			/// <summary>
			/// Property Indexer for TRTaxTotal
			/// </summary>
			public const int TRTaxTotal = 246;

			/// <summary>
			/// Property Indexer for Level1Name
			/// </summary>
			public const int Level1Name = 247;

			/// <summary>
			/// Property Indexer for Level2Name
			/// </summary>
			public const int Level2Name = 248;

			/// <summary>
			/// Property Indexer for Level3Name
			/// </summary>
			public const int Level3Name = 249;

			/// <summary>
			/// Property Indexer for UnformattedContractCode
			/// </summary>
			public const int UnformattedContractCode = 250;

			/// <summary>
			/// Property Indexer for ExtPriceNetOfDiscIncTax
			/// </summary>
			public const int ExtPriceNetOfDiscIncTax = 251;

			/// <summary>
			/// Property Indexer for DetailAmountDue
			/// </summary>
			public const int DetailAmountDue = 252;

			/// <summary>
			/// Property Indexer for SerialLotQuantityToProcess
			/// </summary>
			public const int SerialLotQuantityToProcess = 253;

			/// <summary>
			/// Property Indexer for NumberOfLotsToGenerate
			/// </summary>
			public const int NumberOfLotsToGenerate = 254;

			/// <summary>
			/// Property Indexer for QuantityperLot
			/// </summary>
			public const int QuantityperLot = 255;

			/// <summary>
			/// Property Indexer for AllocateFromSerial
			/// </summary>
			public const int AllocateFromSerial = 256;

			/// <summary>
			/// Property Indexer for AllocateFromLot
			/// </summary>
			public const int AllocateFromLot = 257;

			/// <summary>
			/// Property Indexer for SerialLotWindowHandle
			/// </summary>
			public const int SerialLotWindowHandle = 258;

            /// <summary>
			/// Property Indexer for NonInteractivePriceApproval
			/// </summary>
			public const int NonInteractivePriceApproval = 259;
            
		}

		#endregion

	}
}
