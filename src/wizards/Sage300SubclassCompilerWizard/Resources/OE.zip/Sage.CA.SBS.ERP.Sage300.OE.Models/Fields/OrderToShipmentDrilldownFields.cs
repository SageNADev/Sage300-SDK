// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Contains list of OrderToShipmentDrilldown Constants
	/// </summary>
	public partial class OrderToShipmentDrilldown
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "OE0533";

		#region Properties

		/// <summary>
		/// Contains list of OrderToShipmentDrilldown Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Ordernumber
			/// </summary>
			public const string Ordernumber = "ORDNUMBER";

			/// <summary>
			/// Property for Orderdetaillinenumber
			/// </summary>
			public const string Orderdetaillinenumber = "ORDDTLNUM";

			/// <summary>
			/// Property for Shipmentnumber
			/// </summary>
			public const string Shipmentnumber = "SHINUMBER";

			/// <summary>
			/// Property for Invoicenumber
			/// </summary>
			public const string Invoicenumber = "INVNUMBER";

			/// <summary>
			/// Property for Shipmentuniq
			/// </summary>
			public const string Shipmentuniq = "SHIUNIQ";

			/// <summary>
			/// Property for Detaillinenumber
			/// </summary>
			public const string Detaillinenumber = "DETAILNUM";

			/// <summary>
			/// Property for Action
			/// </summary>
			public const string Action = "ACTION";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of OrderToShipmentDrilldown Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Ordernumber
			/// </summary>
			public const int Ordernumber = 1;

			/// <summary>
			/// Property Indexer for Orderdetaillinenumber
			/// </summary>
			public const int Orderdetaillinenumber = 2;

			/// <summary>
			/// Property Indexer for Shipmentnumber
			/// </summary>
			public const int Shipmentnumber = 3;

			/// <summary>
			/// Property Indexer for Invoicenumber
			/// </summary>
			public const int Invoicenumber = 4;

			/// <summary>
			/// Property Indexer for Shipmentuniq
			/// </summary>
			public const int Shipmentuniq = 5;

			/// <summary>
			/// Property Indexer for Detaillinenumber
			/// </summary>
			public const int Detaillinenumber = 6;

			/// <summary>
			/// Property Indexer for Action
			/// </summary>
			public const int Action = 7;

		}

		#endregion

	}
}
