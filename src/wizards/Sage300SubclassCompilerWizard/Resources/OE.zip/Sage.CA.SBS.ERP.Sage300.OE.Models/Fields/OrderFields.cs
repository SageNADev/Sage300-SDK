// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

using System.Collections.Generic;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Contains list of Order Constants
     /// </summary>
     public partial class Order
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "OE0520";

          #region Properties        

         /// <summary>
          /// Contains list of Order Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for OrderUniquifier
               /// </summary>
               public const string OrderUniquifier = "ORDUNIQ";

               /// <summary>
               /// Property for OrderNumber
               /// </summary>
               public const string OrderNumber = "ORDNUMBER";

               /// <summary>
               /// Property for CustomerNumber
               /// </summary>
               public const string CustomerNumber = "CUSTOMER";

               /// <summary>
               /// Property for CustomerGroupCode
               /// </summary>
               public const string CustomerGroupCode = "CUSTGROUP";

               /// <summary>
               /// Property for BillToName
               /// </summary>
               public const string BillToName = "BILNAME";

               /// <summary>
               /// Property for BillToAddressLine1
               /// </summary>
               public const string BillToAddressLine1 = "BILADDR1";

               /// <summary>
               /// Property for BillToAddressLine2
               /// </summary>
               public const string BillToAddressLine2 = "BILADDR2";

               /// <summary>
               /// Property for BillToAddressLine3
               /// </summary>
               public const string BillToAddressLine3 = "BILADDR3";

               /// <summary>
               /// Property for BillToAddressLine4
               /// </summary>
               public const string BillToAddressLine4 = "BILADDR4";

               /// <summary>
               /// Property for BillToCity
               /// </summary>
               public const string BillToCity = "BILCITY";

               /// <summary>
               /// Property for BillToStateProvince
               /// </summary>
               public const string BillToStateProvince = "BILSTATE";

               /// <summary>
               /// Property for BillToZipPostalCode
               /// </summary>
               public const string BillToZipPostalCode = "BILZIP";

               /// <summary>
               /// Property for BillToCountry
               /// </summary>
               public const string BillToCountry = "BILCOUNTRY";

               /// <summary>
               /// Property for BillToPhoneNumber
               /// </summary>
               public const string BillToPhoneNumber = "BILPHONE";

               /// <summary>
               /// Property for BillToFaxNumber
               /// </summary>
               public const string BillToFaxNumber = "BILFAX";

               /// <summary>
               /// Property for BillToContact
               /// </summary>
               public const string BillToContact = "BILCONTACT";

               /// <summary>
               /// Property for ShipToLocationCode
               /// </summary>
               public const string ShipToLocationCode = "SHIPTO";

               /// <summary>
               /// Property for ShipToName
               /// </summary>
               public const string ShipToName = "SHPNAME";

               /// <summary>
               /// Property for ShipToAddressLine1
               /// </summary>
               public const string ShipToAddressLine1 = "SHPADDR1";

               /// <summary>
               /// Property for ShipToAddressLine2
               /// </summary>
               public const string ShipToAddressLine2 = "SHPADDR2";

               /// <summary>
               /// Property for ShipToAddressLine3
               /// </summary>
               public const string ShipToAddressLine3 = "SHPADDR3";

               /// <summary>
               /// Property for ShipToAddressLine4
               /// </summary>
               public const string ShipToAddressLine4 = "SHPADDR4";

               /// <summary>
               /// Property for ShipToCity
               /// </summary>
               public const string ShipToCity = "SHPCITY";

               /// <summary>
               /// Property for ShipToStateProvince
               /// </summary>
               public const string ShipToStateProvince = "SHPSTATE";

               /// <summary>
               /// Property for ShipToZipPostalCode
               /// </summary>
               public const string ShipToZipPostalCode = "SHPZIP";

               /// <summary>
               /// Property for ShipToCountry
               /// </summary>
               public const string ShipToCountry = "SHPCOUNTRY";

               /// <summary>
               /// Property for ShipToPhoneNumber
               /// </summary>
               public const string ShipToPhoneNumber = "SHPPHONE";

               /// <summary>
               /// Property for ShipToFaxNumber
               /// </summary>
               public const string ShipToFaxNumber = "SHPFAX";

               /// <summary>
               /// Property for ShipToContact
               /// </summary>
               public const string ShipToContact = "SHPCONTACT";

               /// <summary>
               /// Property for CustomerDiscountLevel
               /// </summary>
               public const string CustomerDiscountLevel = "CUSTDISC";

               /// <summary>
               /// Property for DefaultPriceListCode
               /// </summary>
               public const string DefaultPriceListCode = "PRICELIST";

               /// <summary>
               /// Property for PurchaseOrderNumber
               /// </summary>
               public const string PurchaseOrderNumber = "PONUMBER";

               /// <summary>
               /// Property for Territory
               /// </summary>
               public const string Territory = "TERRITORY";

               /// <summary>
               /// Property for TermsCode
               /// </summary>
               public const string TermsCode = "TERMS";

               /// <summary>
               /// Property for TotalTermsAmountDue
               /// </summary>
               public const string TotalTermsAmountDue = "TERMTTLDUE";

               /// <summary>
               /// Property for DiscountAvailable
               /// </summary>
               public const string DiscountAvailable = "DISCAVAIL";

               /// <summary>
               /// Property for TermsRateOverride
               /// </summary>
               public const string TermsRateOverride = "TERMOVERRD";

               /// <summary>
               /// Property for OrderReference
               /// </summary>
               public const string OrderReference = "REFERENCE";

               /// <summary>
               /// Property for OrderType
               /// </summary>
               public const string OrderType = "TYPE";

               /// <summary>
               /// Property for OrderDate
               /// </summary>
               public const string OrderDate = "ORDDATE";

               /// <summary>
               /// Property for ExpectedShipDate
               /// </summary>
               public const string ExpectedShipDate = "EXPDATE";

               /// <summary>
               /// Property for QuoteExpirationDate
               /// </summary>
               public const string QuoteExpirationDate = "QTEXPDATE";

               /// <summary>
               /// Property for OrderFiscalYear
               /// </summary>
               public const string OrderFiscalYear = "ORDFISCYR";

               /// <summary>
               /// Property for OrderFiscalPeriod
               /// </summary>
               public const string OrderFiscalPeriod = "ORDFISCPER";

               /// <summary>
               /// Property for ShipViaCode
               /// </summary>
               public const string ShipViaCode = "SHIPVIA";

               /// <summary>
               /// Property for ShipViaCodeDescription
               /// </summary>
               public const string ShipViaCodeDescription = "VIADESC";

               /// <summary>
               /// Property for LastInvoiceNumber
               /// </summary>
               public const string LastInvoiceNumber = "LASTINVNUM";

               /// <summary>
               /// Property for NumberOfInvoices
               /// </summary>
               public const string NumberOfInvoices = "NUMINVOICE";

               /// <summary>
               /// Property for FreeOnBoardPoint
               /// </summary>
               public const string FreeOnBoardPoint = "FOB";

               /// <summary>
               /// Property for TemplateCode
               /// </summary>
               public const string TemplateCode = "TEMPLATE";

               /// <summary>
               /// Property for DefaultLocationCode
               /// </summary>
               public const string DefaultLocationCode = "LOCATION";

               /// <summary>
               /// Property for OnHold
               /// </summary>
               public const string OnHold = "ONHOLD";

               /// <summary>
               /// Property for OrderDescription
               /// </summary>
               public const string OrderDescription = "DESC";

               /// <summary>
               /// Property for OrderComment
               /// </summary>
               public const string OrderComment = "COMMENT";

               /// <summary>
               /// Property for OrderPrintStatus
               /// </summary>
               public const string OrderPrintStatus = "PRINTSTAT";

               /// <summary>
               /// Property for LastPostingDate
               /// </summary>
               public const string LastPostingDate = "LASTPOST";

               /// <summary>
               /// Property for OrderNoOfPrepayments
               /// </summary>
               public const string OrderNoOfPrepayments = "ORNOPREPAY";

               /// <summary>
               /// Property for OverCreditLimit
               /// </summary>
               public const string OverCreditLimit = "OVERCREDIT";

               /// <summary>
               /// Property for ApprovedLimit
               /// </summary>
               public const string ApprovedLimit = "APPROVELMT";

               /// <summary>
               /// Property for AuthorizingUserID
               /// </summary>
               public const string AuthorizingUserID = "APPROVEBY";

               /// <summary>
               /// Property for RequiresShippingLabels
               /// </summary>
               public const string RequiresShippingLabels = "SHIPLABEL";

               /// <summary>
               /// Property for ShippingLabelsPrinted
               /// </summary>
               public const string ShippingLabelsPrinted = "LBLPRINTED";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for Orhomecurr
               /// </summary>
               public const string Orhomecurr = "ORHOMECURR";

               /// <summary>
               /// Property for ORRATETYPE
               /// </summary>
               public const string OrRateType = "ORRATETYPE";

               /// <summary>
               /// Property for ORSOURCURR
               /// </summary>
               public const string OrSourCurr = "ORSOURCURR";

               /// <summary>
               /// Property for ORRATEDATE
               /// </summary>
               public const string OrRateDate = "ORRATEDATE";

               /// <summary>
               /// Property for ORRATE
               /// </summary>
               public const string OrRate = "ORRATE";

               /// <summary>
               /// Property for ORSPREAD
               /// </summary>
               public const string OrSpread = "ORSPREAD";

               /// <summary>
               /// Property for ORDATEMTCH
               /// </summary>
               public const string OrDateMtch = "ORDATEMTCH";

               /// <summary>
               /// Property for ORRATEREP
               /// </summary>
               public const string OrRateRep = "ORRATEREP";

               /// <summary>
               /// Property for ORRATEOVER
               /// </summary>
               public const string OrRateOver = "ORRATEOVER";

               /// <summary>
               /// Property for TotalAmtItems
               /// </summary>
               public const string TotalAmtItems = "ORDTOTAL";

               /// <summary>
               /// Property for TotalAmtMiscCharges
               /// </summary>
               public const string TotalAmtMiscCharges = "ORDMTOTAL";

               /// <summary>
               /// Property for NumberOfLinesonOrder
               /// </summary>
               public const string NumberOfLinesonOrder = "ORDLINES";

               /// <summary>
               /// Property for NumberOfLabels
               /// </summary>
               public const string NumberOfLabels = "NUMLABELS";

               /// <summary>
               /// Property for PrevPaymentsTotal
               /// </summary>
               public const string PrevPaymentsTotal = "ORDPAYTOT";

               /// <summary>
               /// Property for PrevPaymentDiscTotal
               /// </summary>
               public const string PrevPaymentDiscTotal = "ORDPYDSTOT";

               /// <summary>
               /// Property for Salesperson1
               /// </summary>
               public const string Salesperson1 = "SALESPER1";

               /// <summary>
               /// Property for Salesperson2
               /// </summary>
               public const string Salesperson2 = "SALESPER2";

               /// <summary>
               /// Property for Salesperson3
               /// </summary>
               public const string Salesperson3 = "SALESPER3";

               /// <summary>
               /// Property for Salesperson4
               /// </summary>
               public const string Salesperson4 = "SALESPER4";

               /// <summary>
               /// Property for Salesperson5
               /// </summary>
               public const string Salesperson5 = "SALESPER5";

               /// <summary>
               /// Property for SalesPercentage1
               /// </summary>
               public const string SalesPercentage1 = "SALESPLT1";

               /// <summary>
               /// Property for SalesPercentage2
               /// </summary>
               public const string SalesPercentage2 = "SALESPLT2";

               /// <summary>
               /// Property for SalesPercentage3
               /// </summary>
               public const string SalesPercentage3 = "SALESPLT3";

               /// <summary>
               /// Property for SalesPercentage4
               /// </summary>
               public const string SalesPercentage4 = "SALESPLT4";

               /// <summary>
               /// Property for SalesPercentage5
               /// </summary>
               public const string SalesPercentage5 = "SALESPLT5";

               /// <summary>
               /// Property for RecalculateTax
               /// </summary>
               public const string RecalculateTax = "RECALCTAX";

               /// <summary>
               /// Property for TaxOverridden
               /// </summary>
               public const string TaxOverridden = "TAXOVERRD";

               /// <summary>
               /// Property for TaxGroup
               /// </summary>
               public const string TaxGroup = "TAXGROUP";

               /// <summary>
               /// Property for TaxAuthority1
               /// </summary>
               public const string TaxAuthority1 = "TAUTH1";

               /// <summary>
               /// Property for TaxAuthority2
               /// </summary>
               public const string TaxAuthority2 = "TAUTH2";

               /// <summary>
               /// Property for TaxAuthority3
               /// </summary>
               public const string TaxAuthority3 = "TAUTH3";

               /// <summary>
               /// Property for TaxAuthority4
               /// </summary>
               public const string TaxAuthority4 = "TAUTH4";

               /// <summary>
               /// Property for TaxAuthority5
               /// </summary>
               public const string TaxAuthority5 = "TAUTH5";

               /// <summary>
               /// Property for TaxClass1
               /// </summary>
               public const string TaxClass1 = "TCLASS1";

               /// <summary>
               /// Property for TaxClass2
               /// </summary>
               public const string TaxClass2 = "TCLASS2";

               /// <summary>
               /// Property for TaxClass3
               /// </summary>
               public const string TaxClass3 = "TCLASS3";

               /// <summary>
               /// Property for TaxClass4
               /// </summary>
               public const string TaxClass4 = "TCLASS4";

               /// <summary>
               /// Property for TaxClass5
               /// </summary>
               public const string TaxClass5 = "TCLASS5";

               /// <summary>
               /// Property for TaxBase1
               /// </summary>
               public const string TaxBase1 = "TBASE1";

               /// <summary>
               /// Property for TaxBase2
               /// </summary>
               public const string TaxBase2 = "TBASE2";

               /// <summary>
               /// Property for TaxBase3
               /// </summary>
               public const string TaxBase3 = "TBASE3";

               /// <summary>
               /// Property for TaxBase4
               /// </summary>
               public const string TaxBase4 = "TBASE4";

               /// <summary>
               /// Property for TaxBase5
               /// </summary>
               public const string TaxBase5 = "TBASE5";

               /// <summary>
               /// Property for ExcludedTaxAmount1
               /// </summary>
               public const string ExcludedTaxAmount1 = "TEAMOUNT1";

               /// <summary>
               /// Property for ExcludedTaxAmount2
               /// </summary>
               public const string ExcludedTaxAmount2 = "TEAMOUNT2";

               /// <summary>
               /// Property for ExcludedTaxAmount3
               /// </summary>
               public const string ExcludedTaxAmount3 = "TEAMOUNT3";

               /// <summary>
               /// Property for ExcludedTaxAmount4
               /// </summary>
               public const string ExcludedTaxAmount4 = "TEAMOUNT4";

               /// <summary>
               /// Property for ExcludedTaxAmount5
               /// </summary>
               public const string ExcludedTaxAmount5 = "TEAMOUNT5";

               /// <summary>
               /// Property for IncludedTaxAmount1
               /// </summary>
               public const string IncludedTaxAmount1 = "TIAMOUNT1";

               /// <summary>
               /// Property for IncludedTaxAmount2
               /// </summary>
               public const string IncludedTaxAmount2 = "TIAMOUNT2";

               /// <summary>
               /// Property for IncludedTaxAmount3
               /// </summary>
               public const string IncludedTaxAmount3 = "TIAMOUNT3";

               /// <summary>
               /// Property for IncludedTaxAmount4
               /// </summary>
               public const string IncludedTaxAmount4 = "TIAMOUNT4";

               /// <summary>
               /// Property for IncludedTaxAmount5
               /// </summary>
               public const string IncludedTaxAmount5 = "TIAMOUNT5";

               /// <summary>
               /// Property for Registration1
               /// </summary>
               public const string Registration1 = "TEXEMPT1";

               /// <summary>
               /// Property for Registration2
               /// </summary>
               public const string Registration2 = "TEXEMPT2";

               /// <summary>
               /// Property for Registration3
               /// </summary>
               public const string Registration3 = "TEXEMPT3";

               /// <summary>
               /// Property for Registration4
               /// </summary>
               public const string Registration4 = "TEXEMPT4";

               /// <summary>
               /// Property for Registration5
               /// </summary>
               public const string Registration5 = "TEXEMPT5";

               /// <summary>
               /// Property for OrderCompleted
               /// </summary>
               public const string OrderCompleted = "COMPLETE";

               /// <summary>
               /// Property for OrderCompletionDate
               /// </summary>
               public const string OrderCompletionDate = "COMPDATE";

               /// <summary>
               /// Property for InvoiceNumber
               /// </summary>
               public const string InvoiceNumber = "INVNUMBER";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for Shipdate
               /// </summary>
               public const string Shipdate = "SHIPDATE";

               /// <summary>
               /// Property for InvoiceDate
               /// </summary>
               public const string InvoiceDate = "INVDATE";

               /// <summary>
               /// Property for InvoiceFiscalYear
               /// </summary>
               public const string InvoiceFiscalYear = "INVFISCYR";

               /// <summary>
               /// Property for InvoiceFiscalPeriod
               /// </summary>
               public const string InvoiceFiscalPeriod = "INVFISCPER";

               /// <summary>
               /// Property for NoOfTermsPayments
               /// </summary>
               public const string NoOfTermsPayments = "NUMPAYMENT";

               /// <summary>
               /// Property for TermsPaymentsAsOfDate
               /// </summary>
               public const string TermsPaymentsAsOfDate = "PAYMNTASOF";

               /// <summary>
               /// Property for OrderTotalEstWeight
               /// </summary>
               public const string OrderTotalEstWeight = "INVWEIGHT";

               /// <summary>
               /// Property for NextDetailNumber
               /// </summary>
               public const string NextDetailNumber = "NEXTDTLNUM";

               /// <summary>
               /// Property for PostInvoice
               /// </summary>
               public const string PostInvoice = "POSTINV";

               /// <summary>
               /// Property for InvoiceDiscMiscCharges
               /// </summary>
               public const string InvoiceDiscMiscCharges = "IDISONMISC";

               /// <summary>
               /// Property for InvoiceNoOfPrepayments
               /// </summary>
               public const string InvoiceNoOfPrepayments = "INNOPREPAY";

               /// <summary>
               /// Property for NoLinesQtyShipped
               /// </summary>
               public const string NoLinesQtyShipped = "NOSHIPLINE";

               /// <summary>
               /// Property for NoMiscChargesLines
               /// </summary>
               public const string NoMiscChargesLines = "NOMISCLINE";

               /// <summary>
               /// Property for OrderTotalBeforeTax
               /// </summary>
               public const string OrderTotalBeforeTax = "INVNETNOTX";

               /// <summary>
               /// Property for OrderInclTaxTotal
               /// </summary>
               public const string OrderInclTaxTotal = "INVITAXTOT";

               /// <summary>
               /// Property for OrderItemTotalAmount
               /// </summary>
               public const string OrderItemTotalAmount = "INVITMTOT";

               /// <summary>
               /// Property for OrderDiscountBase
               /// </summary>
               public const string OrderDiscountBase = "INVDISCBAS";

               /// <summary>
               /// Property for OrderDiscountPercentage
               /// </summary>
               public const string OrderDiscountPercentage = "INVDISCPER";

               /// <summary>
               /// Property for OrderDiscountAmount
               /// </summary>
               public const string OrderDiscountAmount = "INVDISCAMT";

               /// <summary>
               /// Property for OrderTotalMiscCharges
               /// </summary>
               public const string OrderTotalMiscCharges = "INVMISC";

               /// <summary>
               /// Property for OrderSubtotalAmount
               /// </summary>
               public const string OrderSubtotalAmount = "INVSUBTOT";

               /// <summary>
               /// Property for OrderTotalWithInvDisc
               /// </summary>
               public const string OrderTotalWithInvDisc = "INVNET";

               /// <summary>
               /// Property for OrderExclTaxTotal
               /// </summary>
               public const string OrderExclTaxTotal = "INVETAXTOT";

               /// <summary>
               /// Property for OrderTotal
               /// </summary>
               public const string OrderTotal = "INVNETWTX";

               /// <summary>
               /// Property for OrderAmountDue
               /// </summary>
               public const string OrderAmountDue = "INVAMTDUE";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for Inhomecurr
               /// </summary>
               public const string Inhomecurr = "INHOMECURR";

               /// <summary>
               /// Property for Inratetype
               /// </summary>
               public const string Inratetype = "INRATETYPE";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for Insourcurr
               /// </summary>
               public const string Insourcurr = "INSOURCURR";

              /// <summary>
               /// Property for InRateDate
               /// </summary>
               public const string InRateDate = "INRATEDATE";

               /// <summary>
               /// Property for INRATE
               /// </summary>
               public const string InRate = "INRATE";

               /// <summary>
               /// Property for Inspread
               /// </summary>
               public const string Inspread = "INSPREAD";

               /// <summary>
               /// Property for Indatemtch
               /// </summary>
               public const string Indatemtch = "INDATEMTCH";

               /// <summary>
               /// Property for Inraterep
               /// </summary>
               public const string Inraterep = "INRATEREP";

               /// <summary>
               /// Property for Inrateover
               /// </summary>
               public const string Inrateover = "INRATEOVER";

               /// <summary>
               /// Property for ReceiptBatchNumber
               /// </summary>
               public const string ReceiptBatchNumber = "REBATCHNUM";

               /// <summary>
               /// Property for BankCode
               /// </summary>
               public const string BankCode = "BANKCODE";

               /// <summary>
               /// Property for ReceiptType
               /// </summary>
               public const string ReceiptType = "BANKRECTYP";

               /// <summary>
               /// Property for CheckDate
               /// </summary>
               public const string CheckDate = "CHECKDATE";

               /// <summary>
               /// Property for CheckFiscalYear
               /// </summary>
               public const string CheckFiscalYear = "CHKFISCYR";

               /// <summary>
               /// Property for CheckFiscalPeriod
               /// </summary>
               public const string CheckFiscalPeriod = "CHKFISCPER";

               /// <summary>
               /// Property for CheckNumber
               /// </summary>
               public const string CheckNumber = "CHECKNUM";

               /// <summary>
               /// Property for PaymentAppliedTo
               /// </summary>
               public const string PaymentAppliedTo = "APPLYTO";

               /// <summary>
               /// Property for PaymentInCustCurrency
               /// </summary>
               public const string PaymentInCustCurrency = "PAYMENT";

               /// <summary>
               /// Property for InvoiceTotalTermsDisc
               /// </summary>
               public const string InvoiceTotalTermsDisc = "INVPAYDISC";

               /// <summary>
               /// Property for PaymentInBankCurrency
               /// </summary>
               public const string PaymentInBankCurrency = "BANKPAYMNT";

               /// <summary>
               /// Property for PaymentHomeCurrency
               /// </summary>
               public const string PaymentHomeCurrency = "PAHOMECURR";

               /// <summary>
               /// Property for PaymentRateType
               /// </summary>
               public const string PaymentRateType = "PARATETYPE";

               /// <summary>
               /// Property for PaymentSourceCurrency
               /// </summary>
               public const string PaymentSourceCurrency = "PASOURCURR";

               /// <summary>
               /// Property for PaymentRateDate
               /// </summary>
               public const string PaymentRateDate = "PARATEDATE";

               /// <summary>
               /// Property for PaymentRate
               /// </summary>
               public const string PaymentRate = "PARATE";

               /// <summary>
               /// Property for PaymentSpread
               /// </summary>
               public const string PaymentSpread = "PASPREAD";

               /// <summary>
               /// Property for PaymentRateDateMatching
               /// </summary>
               public const string PaymentRateDateMatching = "PADATEMTCH";

               /// <summary>
               /// Property for PaymentRateOperator
               /// </summary>
               public const string PaymentRateOperator = "PARATEREP";

               /// <summary>
               /// Property for PriceListCodeDesc
               /// </summary>
               public const string PriceListCodeDesc = "PCODDESC";

               /// <summary>
               /// Property for TermsCodeDescription
               /// </summary>
               public const string TermsCodeDescription = "TERMDESC";

               /// <summary>
               /// Property for TaxGroupCodeDesc
               /// </summary>
               public const string TaxGroupCodeDesc = "TXGRPDESC";

               /// <summary>
               /// Property for LocationCodeDesc
               /// </summary>
               public const string LocationCodeDesc = "LOCDESC";

               /// <summary>
               /// Property for SalespersonName1
               /// </summary>
               public const string SalespersonName1 = "SALES1NAME";

               /// <summary>
               /// Property for SalespersonName2
               /// </summary>
               public const string SalespersonName2 = "SALES2NAME";

               /// <summary>
               /// Property for SalespersonName3
               /// </summary>
               public const string SalespersonName3 = "SALES3NAME";

               /// <summary>
               /// Property for SalespersonName4
               /// </summary>
               public const string SalespersonName4 = "SALES4NAME";

               /// <summary>
               /// Property for SalespersonName5
               /// </summary>
               public const string SalespersonName5 = "SALES5NAME";

               /// <summary>
               /// Property for TaxAuthority1Desc
               /// </summary>
               public const string TaxAuthority1Desc = "TAUTH1DESC";

               /// <summary>
               /// Property for TaxAuthority2Desc
               /// </summary>
               public const string TaxAuthority2Desc = "TAUTH2DESC";

               /// <summary>
               /// Property for TaxAuthority3Desc
               /// </summary>
               public const string TaxAuthority3Desc = "TAUTH3DESC";

               /// <summary>
               /// Property for TaxAuthority4Desc
               /// </summary>
               public const string TaxAuthority4Desc = "TAUTH4DESC";

               /// <summary>
               /// Property for TaxAuthority5Desc
               /// </summary>
               public const string TaxAuthority5Desc = "TAUTH5DESC";

               /// <summary>
               /// Property for TaxClass1Description
               /// </summary>
               public const string TaxClass1Description = "TCLAS1DESC";

               /// <summary>
               /// Property for TaxClass2Description
               /// </summary>
               public const string TaxClass2Description = "TCLAS2DESC";

               /// <summary>
               /// Property for TaxClass3Description
               /// </summary>
               public const string TaxClass3Description = "TCLAS3DESC";

               /// <summary>
               /// Property for TaxClass4Description
               /// </summary>
               public const string TaxClass4Description = "TCLAS4DESC";

               /// <summary>
               /// Property for TaxClass5Description
               /// </summary>
               public const string TaxClass5Description = "TCLAS5DESC";

               /// <summary>
               /// Property for OrderSourceCurrencyDesc
               /// </summary>
               public const string OrderSourceCurrencyDesc = "ORSRCDESC";

               /// <summary>
               /// Property for OrderHomeCurrencyDesc
               /// </summary>
               public const string OrderHomeCurrencyDesc = "ORHOMDESC";

               /// <summary>
               /// Property for OrderRateTypeDescription
               /// </summary>
               public const string OrderRateTypeDescription = "ORRTTYDESC";

               /// <summary>
               /// Property for InvoiceSourceCurrDesc
               /// </summary>
               public const string InvoiceSourceCurrDesc = "INSRCDESC";

               /// <summary>
               /// Property for InvoiceHomeCurrencyDesc
               /// </summary>
               public const string InvoiceHomeCurrencyDesc = "INHOMDESC";

               /// <summary>
               /// Property for InvoiceRateTypeDesc
               /// </summary>
               public const string InvoiceRateTypeDesc = "INRTTYDESC";

               /// <summary>
               /// Property for PaymentSourceCurrDesc
               /// </summary>
               public const string PaymentSourceCurrDesc = "PASRCDESC";

               /// <summary>
               /// Property for PaymentHomeCurrencyDesc
               /// </summary>
               public const string PaymentHomeCurrencyDesc = "PAHOMDESC";

               /// <summary>
               /// Property for PaymentRateTypeDesc
               /// </summary>
               public const string PaymentRateTypeDesc = "PARTTYDESC";

               /// <summary>
               /// Property for TotalTaxAmount1
               /// </summary>
               public const string TotalTaxAmount1 = "TAMOUNT1";

               /// <summary>
               /// Property for TotalTaxAmount2
               /// </summary>
               public const string TotalTaxAmount2 = "TAMOUNT2";

               /// <summary>
               /// Property for TotalTaxAmount3
               /// </summary>
               public const string TotalTaxAmount3 = "TAMOUNT3";

               /// <summary>
               /// Property for TotalTaxAmount4
               /// </summary>
               public const string TotalTaxAmount4 = "TAMOUNT4";

               /// <summary>
               /// Property for TotalTaxAmount5
               /// </summary>
               public const string TotalTaxAmount5 = "TAMOUNT5";

               /// <summary>
               /// Property for TotalTaxAmount
               /// </summary>
               public const string TotalTaxAmount = "INVTAXTOT";

               /// <summary>
               /// Property for AuthorizingUserPassword
               /// </summary>
               public const string AuthorizingUserPassword = "APPPASSWRD";

               /// <summary>
               /// Property for OrderRunningTotal
               /// </summary>
               public const string OrderRunningTotal = "RUNNINGTOT";

               /// <summary>
               /// Property for OrderTotalPayment
               /// </summary>
               public const string OrderTotalPayment = "ORDPAYMENT";

               /// <summary>
               /// Property for OrderTotalPaymentDisc
               /// </summary>
               public const string OrderTotalPaymentDisc = "ORDPAYDISC";

               /// <summary>
               /// Property for AmountDueLessCurrPrepayment
               /// </summary>
               public const string AmountDueLessCurrPrepayment = "AMTDUENODS";

               /// <summary>
               /// Property for PerformTaxCalculation
               /// </summary>
               public const string PerformTaxCalculation = "GOCALCTAX";

               /// <summary>
               /// Property for PerformCreditLimitCheck
               /// </summary>
               public const string PerformCreditLimitCheck = "GOCHKCRDT";

               /// <summary>
               /// Property for OrderSource
               /// </summary>
               public const string OrderSource = "ORDERSOURC";

               /// <summary>
               /// Property for PerformShipAll
               /// </summary>
               public const string PerformShipAll = "GOSHIPALL";

               /// <summary>
               /// Property for DosConversionInProgress
               /// </summary>
               public const string DosConversionInProgress = "DOSCONVERT";

               /// <summary>
               /// Property for PerformForcedTaxCalculation
               /// </summary>
               public const string PerformForcedTaxCalculation = "GOFCALCTAX";

               /// <summary>
               /// Property for PerformManualTaxDistribution
               /// </summary>
               public const string PerformManualTaxDistribution = "GODISTTAX";

               /// <summary>
               /// Property for TaxCalculationInProgress
               /// </summary>
               public const string TaxCalculationInProgress = "TXCALCINPG";

               /// <summary>
               /// Property for AutoTaxCalculationStatus
               /// </summary>
               public const string AutoTaxCalculationStatus = "AUTOTAXCAL";

               /// <summary>
               /// Property for OriginatingQuoteNumber
               /// </summary>
               public const string OriginatingQuoteNumber = "QUONUMBER";

               /// <summary>
               /// Property for DisplayRateWarning
               /// </summary>
               public const string DisplayRateWarning = "RTWARNMSG";

               /// <summary>
               /// Property for CustomerExists
               /// </summary>
               public const string CustomerExists = "CUSTEXIST";

               /// <summary>
               /// Property for InvoiceWillBeProduced
               /// </summary>
               public const string InvoiceWillBeProduced = "INVPRODUCE";

               /// <summary>
               /// Property for SecurityEnabled
               /// </summary>
               public const string SecurityEnabled = "SECENABLED";

               /// <summary>
               /// Property for UserCanApproveCreditLift
               /// </summary>
               public const string UserCanApproveCreditLift = "GOAPPROSEC";

               /// <summary>
               /// Property for RecalcMultiPaymentDates
               /// </summary>
               public const string RecalcMultiPaymentDates = "GOCALCPYDT";

               /// <summary>
               /// Property for BillToEmail
               /// </summary>
               public const string BillToEmail = "BILEMAIL";

               /// <summary>
               /// Property for BillToContactPhone
               /// </summary>
               public const string BillToContactPhone = "BILPHONEC";

               /// <summary>
               /// Property for BillToContactFax
               /// </summary>
               public const string BillToContactFax = "BILFAXC";

               /// <summary>
               /// Property for BillToContactEmail
               /// </summary>
               public const string BillToContactEmail = "BILEMAILC";

               /// <summary>
               /// Property for ShipToEmail
               /// </summary>
               public const string ShipToEmail = "SHPEMAIL";

               /// <summary>
               /// Property for ShipToContactPhone
               /// </summary>
               public const string ShipToContactPhone = "SHPPHONEC";

               /// <summary>
               /// Property for ShipToContactFax
               /// </summary>
               public const string ShipToContactFax = "SHPFAXC";

               /// <summary>
               /// Property for ShipToContactEmail
               /// </summary>
               public const string ShipToContactEmail = "SHPEMAILC";

               /// <summary>
               /// Property for Allowpartialshipments
               /// </summary>
               public const string Allowpartialshipments = "SWPARTSHIP";

               /// <summary>
               /// Property for MultipleQuotes
               /// </summary>
               public const string MultipleQuotes = "MULTIQUO";

               /// <summary>
               /// Property for NumberOfQuotes
               /// </summary>
               public const string NumberOfQuotes = "QUOS";

               /// <summary>
               /// Property for PerformMultipleQuotesToOrder
               /// </summary>
               public const string PerformMultipleQuotesToOrder = "GOQUOTOORD";

               /// <summary>
               /// Property for LastShipmentNumber
               /// </summary>
               public const string LastShipmentNumber = "LASTSHINUM";

               /// <summary>
               /// Property for NumberOfShipments
               /// </summary>
               public const string NumberOfShipments = "NUMSHPMENT";

               /// <summary>
               /// Property for ShipmentTrackingNumber
               /// </summary>
               public const string ShipmentTrackingNumber = "SHIPTRACK";

               /// <summary>
               /// Property for PostSequenceNumber
               /// </summary>
               public const string PostSequenceNumber = "POSTSEQNUM";

               /// <summary>
               /// Property for ShipmentUniquifier
               /// </summary>
               public const string ShipmentUniquifier = "SHIUNIQ";

               /// <summary>
               /// Property for ShipmentNumber
               /// </summary>
               public const string ShipmentNumber = "SHINUMBER";

               /// <summary>
               /// Property for Shidate
               /// </summary>
               public const string Shidate = "SHIDATE";

               /// <summary>
               /// Property for ShipmentHomeCurrency
               /// </summary>
               public const string ShipmentHomeCurrency = "SHHOMECURR";

               /// <summary>
               /// Property for ShipmentRateType
               /// </summary>
               public const string ShipmentRateType = "SHRATETYPE";

               /// <summary>
               /// Property for ShipmentSourceCurrency
               /// </summary>
               public const string ShipmentSourceCurrency = "SHSOURCURR";

               /// <summary>
               /// Property for ShipmentRateDate
               /// </summary>
               public const string ShipmentRateDate = "SHRATEDATE";

               /// <summary>
               /// Property for ShipmentRate
               /// </summary>
               public const string ShipmentRate = "SHRATE";

               /// <summary>
               /// Property for ShipmentSpread
               /// </summary>
               public const string ShipmentSpread = "SHSPREAD";

               /// <summary>
               /// Property for ShipmentDateMatch
               /// </summary>
               public const string ShipmentDateMatch = "SHDATEMTCH";

               /// <summary>
               /// Property for ShipmentRateOperator
               /// </summary>
               public const string ShipmentRateOperator = "SHRATEREP";

               /// <summary>
               /// Property for ShipmentRateOverrideFlag
               /// </summary>
               public const string ShipmentRateOverrideFlag = "SHRATEOVER";

               /// <summary>
               /// Property for ShipmentSourceCurrencyDesc
               /// </summary>
               public const string ShipmentSourceCurrencyDesc = "SHSRCDESC";

               /// <summary>
               /// Property for ShipmentHomeCurrencyDesc
               /// </summary>
               public const string ShipmentHomeCurrencyDesc = "SHHOMDESC";

               /// <summary>
               /// Property for ShipmentRateTypeDescription
               /// </summary>
               public const string ShipmentRateTypeDescription = "SHRTTYDESC";

               /// <summary>
               /// Property for OrderPartiallyShipped
               /// </summary>
               public const string OrderPartiallyShipped = "GOCHKPSHIP";

               /// <summary>
               /// Property for ShipmentTotal
               /// </summary>
               public const string ShipmentTotal = "SHINETWTX";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for PredecessorUniquifier
               /// </summary>
               public const string PredecessorUniquifier = "FRMUNIQ";

               /// <summary>
               /// Property for PredecessorNumber
               /// </summary>
               public const string PredecessorNumber = "FRMNUMBER";

               /// <summary>
               /// Property for ProcessOipCommand
               /// </summary>
               public const string ProcessOipCommand = "PROCESSCMD";

               /// <summary>
               /// Property for ProcessOeCommand
               /// </summary>
               public const string ProcessOeCommand = "OECOMMAND";

               /// <summary>
               /// Property for UserEnteredApprovalAmount
               /// </summary>
               public const string UserEnteredApprovalAmount = "EDAPRVLMT";

               /// <summary>
               /// Property for CheckingCustomerCreditLimit
               /// </summary>
               public const string CheckingCustomerCreditLimit = "SWCHKLIMC";

               /// <summary>
               /// Property for CheckingCustomerAgingLimit
               /// </summary>
               public const string CheckingCustomerAgingLimit = "SWCHKODUEC";

               /// <summary>
               /// Property for CheckingNatAcctCreditLimit
               /// </summary>
               public const string CheckingNatAcctCreditLimit = "SWCHKLIMA";

               /// <summary>
               /// Property for CheckingNatAcctAgingLimit
               /// </summary>
               public const string CheckingNatAcctAgingLimit = "SWCHKODUEA";

               /// <summary>
               /// Property for CustomerIsOverCreditLimit
               /// </summary>
               public const string CustomerIsOverCreditLimit = "SWOVERLIMC";

               /// <summary>
               /// Property for CustomerIsOverAgingLimit
               /// </summary>
               public const string CustomerIsOverAgingLimit = "SWOVERDUEC";

               /// <summary>
               /// Property for NatAcctIsOverCreditLimit
               /// </summary>
               public const string NatAcctIsOverCreditLimit = "SWOVERLIMA";

               /// <summary>
               /// Property for NatAcctIsOverAgingLimit
               /// </summary>
               public const string NatAcctIsOverAgingLimit = "SWOVERDUEA";

               /// <summary>
               /// Property for CustomerCreditLimit
               /// </summary>
               public const string CustomerCreditLimit = "AMTLIMITC";

               /// <summary>
               /// Property for CustomerBalancePosted
               /// </summary>
               public const string CustomerBalancePosted = "AMTBALCUST";

               /// <summary>
               /// Property for CustomerDaysOverdue
               /// </summary>
               public const string CustomerDaysOverdue = "OVDUEDAYSC";

               /// <summary>
               /// Property for CustomerOverdueLimit
               /// </summary>
               public const string CustomerOverdueLimit = "OVDUELMTC";

               /// <summary>
               /// Property for CustomerBalanceOverdue
               /// </summary>
               public const string CustomerBalanceOverdue = "OVDUEBALC";

               /// <summary>
               /// Property for NatAcctCreditLimit
               /// </summary>
               public const string NatAcctCreditLimit = "AMTLIMITA";

               /// <summary>
               /// Property for NatAcctBalance
               /// </summary>
               public const string NatAcctBalance = "AMTBALACCT";

               /// <summary>
               /// Property for NatAcctDaysOverdue
               /// </summary>
               public const string NatAcctDaysOverdue = "OVDUEDAYSA";

               /// <summary>
               /// Property for NatAcctOverdueLimit
               /// </summary>
               public const string NatAcctOverdueLimit = "OVDUELMTA";

               /// <summary>
               /// Property for NatAcctBalanceOverdue
               /// </summary>
               public const string NatAcctBalanceOverdue = "OVDUEBALA";

               /// <summary>
               /// Property for ARPendingTransIncluded
               /// </summary>
               public const string ARPendingTransIncluded = "SWARPEND";

               /// <summary>
               /// Property for OePendingTransIncluded
               /// </summary>
               public const string OePendingTransIncluded = "SWOEPEND";

               /// <summary>
               /// Property for OtherPendingTransIncluded
               /// </summary>
               public const string OtherPendingTransIncluded = "SWXXPEND";

               /// <summary>
               /// Property for ARPendingBalance
               /// </summary>
               public const string ARPendingBalance = "AMTARPEND";

               /// <summary>
               /// Property for OePendingBalance
               /// </summary>
               public const string OePendingBalance = "AMTOEPEND";

               /// <summary>
               /// Property for OtherPendingBalance
               /// </summary>
               public const string OtherPendingBalance = "AMTXXPEND";

               /// <summary>
               /// Property for CustomerTotalOutstanding
               /// </summary>
               public const string CustomerTotalOutstanding = "AMTTOTCUST";

               /// <summary>
               /// Property for NatAcctTotalOutstanding
               /// </summary>
               public const string NatAcctTotalOutstanding = "AMTTOTACCT";

               /// <summary>
               /// Property for CustomerLimitLeft
               /// </summary>
               public const string CustomerLimitLeft = "AMTLEFTC";

               /// <summary>
               /// Property for NatAcctLimitLeft
               /// </summary>
               public const string NatAcctLimitLeft = "AMTLEFTA";

               /// <summary>
               /// Property for CustomerLimitExceeded
               /// </summary>
               public const string CustomerLimitExceeded = "AMTOVERC";

               /// <summary>
               /// Property for NatAcctLimitExceeded
               /// </summary>
               public const string NatAcctLimitExceeded = "AMTOVERA";

               /// <summary>
               /// Property for LastInvoiceAmount
               /// </summary>
               public const string LastInvoiceAmount = "AMTLASTIVT";

               /// <summary>
               /// Property for LastInvoiceDate
               /// </summary>
               public const string LastInvoiceDate = "DATELASTIV";

               /// <summary>
               /// Property for LastPaymentAmount
               /// </summary>
               public const string LastPaymentAmount = "AMTLASTPYT";

               /// <summary>
               /// Property for LastPaymentDate
               /// </summary>
               public const string LastPaymentDate = "DATELASTPA";

               /// <summary>
               /// Property for DrivenbyUI
               /// </summary>
               public const string DrivenbyUI = "DRIVENBYUI";

               /// <summary>
               /// Property for ItemDetailDiscountTotal
               /// </summary>
               public const string ItemDetailDiscountTotal = "ITEMDISTOT";

               /// <summary>
               /// Property for MiscChargeDetailDiscountTot
               /// </summary>
               public const string MiscChargeDetailDiscountTot = "MISCDISTOT";

               /// <summary>
               /// Property for DetailDiscountTotal
               /// </summary>
               public const string DetailDiscountTotal = "DTLDISCTOT";

               /// <summary>
               /// Property for DetailDiscountPercentage
               /// </summary>
               public const string DetailDiscountPercentage = "DTLDISCPER";

               /// <summary>
               /// Property for DocumentNetOfDetailDisc
               /// </summary>
               public const string DocumentNetOfDetailDisc = "INVNTDTDIS";

               /// <summary>
               /// Property for AutoCalcTaxReportingAmounts
               /// </summary>
               public const string AutoCalcTaxReportingAmounts = "OTRMETHOD";

               /// <summary>
               /// Property for TaxReportingTrCurrency
               /// </summary>
               public const string TaxReportingTrCurrency = "OTRCURRNCY";

               /// <summary>
               /// Property for TrRateType
               /// </summary>
               public const string TrRateType = "OTRRATTYPE";

               /// <summary>
               /// Property for TRRateDate
               /// </summary>
               public const string TrRateDate = "OTRRATDATE";

               /// <summary>
               /// Property for TRRate
               /// </summary>
               public const string TrRate = "OTRRATE";

               /// <summary>
               /// Property for TRSpread
               /// </summary>
               public const string TrSpread = "OTRSPREAD";

               /// <summary>
               /// Property for TRRateDateMatching
               /// </summary>
               public const string TrRateDateMatching = "OTRDATMTCH";

               /// <summary>
               /// Property for TRRateOperator
               /// </summary>
               public const string TrRateOperator = "OTRRATEOP";

               /// <summary>
               /// Property for TRRateOverrideFlag
               /// </summary>
               public const string TrRateOverrideFlag = "OTRRATOVER";

               /// <summary>
               /// Property for TRExcludedTaxAmount1
               /// </summary>
               public const string TrExcludedTaxAmount1 = "OTREAMNT1";

               /// <summary>
               /// Property for TRExcludedTaxAmount2
               /// </summary>
               public const string TrExcludedTaxAmount2 = "OTREAMNT2";

               /// <summary>
               /// Property for TRExcludedTaxAmount3
               /// </summary>
               public const string TrExcludedTaxAmount3 = "OTREAMNT3";

               /// <summary>
               /// Property for TRExcludedTaxAmount4
               /// </summary>
               public const string TrExcludedTaxAmount4 = "OTREAMNT4";

               /// <summary>
               /// Property for TRExcludedTaxAmount5
               /// </summary>
               public const string TrExcludedTaxAmount5 = "OTREAMNT5";

               /// <summary>
               /// Property for TRIncludedTaxAmount1
               /// </summary>
               public const string TrIncludedTaxAmount1 = "OTRIAMNT1";

               /// <summary>
               /// Property for TRIncludedTaxAmount2
               /// </summary>
               public const string TrIncludedTaxAmount2 = "OTRIAMNT2";

               /// <summary>
               /// Property for TRIncludedTaxAmount3
               /// </summary>
               public const string TrIncludedTaxAmount3 = "OTRIAMNT3";

               /// <summary>
               /// Property for TRIncludedTaxAmount4
               /// </summary>
               public const string TrIncludedTaxAmount4 = "OTRIAMNT4";

               /// <summary>
               /// Property for TRIncludedTaxAmount5
               /// </summary>
               public const string TrIncludedTaxAmount5 = "OTRIAMNT5";

               /// <summary>
               /// Property for TRTaxAmount1
               /// </summary>
               public const string TrTaxAmount1 = "OTRAMOUNT1";

               /// <summary>
               /// Property for TRTaxAmount2
               /// </summary>
               public const string TrTaxAmount2 = "OTRAMOUNT2";

               /// <summary>
               /// Property for TRTaxAmount3
               /// </summary>
               public const string TrTaxAmount3 = "OTRAMOUNT3";

               /// <summary>
               /// Property for TRTaxAmount4
               /// </summary>
               public const string TrTaxAmount4 = "OTRAMOUNT4";

               /// <summary>
               /// Property for TRTaxAmount5
               /// </summary>
               public const string TrTaxAmount5 = "OTRAMOUNT5";

               /// <summary>
               /// Property for TRExcludedTaxTotal
               /// </summary>
               public const string TrExcludedTaxTotal = "OTRETOTAL";

               /// <summary>
               /// Property for TRIncludedTaxTotal
               /// </summary>
               public const string TrIncludedTaxTotal = "OTRITOTAL";

               /// <summary>
               /// Property for TRTaxTotal
               /// </summary>
               public const string TrTaxTotal = "OTRTOTAL";

               /// <summary>
               /// Property for TaxReportingShipmentTRCurr
               /// </summary>
               public const string TaxReportingShipmentTrCurr = "STRCURRNCY";

               /// <summary>
               /// Property for TRShipmentRateType
               /// </summary>
               public const string TrShipmentRateType = "STRRATTYPE";

               /// <summary>
               /// Property for TRShipmentRateDate
               /// </summary>
               public const string TrShipmentRateDate = "STRRATDATE";

               /// <summary>
               /// Property for TRShipmentRate
               /// </summary>
               public const string TrShipmentRate = "STRRATE";

               /// <summary>
               /// Property for TRShipmentSpread
               /// </summary>
               public const string TrShipmentSpread = "STRSPREAD";

               /// <summary>
               /// Property for TRShipmentRateDateMatching
               /// </summary>
               public const string TrShipmentRateDateMatching = "STRDATMTCH";

               /// <summary>
               /// Property for TRShipmentRateOperator
               /// </summary>
               public const string TrShipmentRateOperator = "STRRATEOP";

               /// <summary>
               /// Property for TRShipmentRateOverrideFlag
               /// </summary>
               public const string TrShipmentRateOverrideFlag = "STRRATOVER";

               /// <summary>
               /// Property for TaxReportingInvoiceTRCurre
               /// </summary>
               public const string TaxReportingInvoiceTrCurre = "ITRCURRNCY";

               /// <summary>
               /// Property for TRInvoiceRateType
               /// </summary>
               public const string TrInvoiceRateType = "ITRRATTYPE";

               /// <summary>
               /// Property for TRInvoiceRateDate
               /// </summary>
               public const string TrInvoiceRateDate = "ITRRATDATE";

               /// <summary>
               /// Property for TRInvoiceRate
               /// </summary>
               public const string TrInvoiceRate = "ITRRATE";

               /// <summary>
               /// Property for TRInvoiceSpread
               /// </summary>
               public const string TrInvoiceSpread = "ITRSPREAD";

               /// <summary>
               /// Property for TRInvoiceRateDateMatching
               /// </summary>
               public const string TrInvoiceRateDateMatching = "ITRDATMTCH";

               /// <summary>
               /// Property for TRInvoiceRateOperator
               /// </summary>
               public const string TrInvoiceRateOperator = "ITRRATEOP";

               /// <summary>
               /// Property for TRInvoiceRateOverrideFlag
               /// </summary>
               public const string TrInvoiceRateOverrideFlag = "ITRRATOVER";

               /// <summary>
               /// Property for TRCurrencyDescription
               /// </summary>
               public const string TrCurrencyDescription = "OTRCURDESC";

               /// <summary>
               /// Property for TRShipmentCurrencyDescription
               /// </summary>
               public const string TrShipmentCurrencyDescription = "STRCURDESC";

               /// <summary>
               /// Property for TRInvoiceCurrencyDescription
               /// </summary>
               public const string TrInvoiceCurrencyDescription = "ITRCURDESC";

               /// <summary>
               /// Property for TRRateTypeDescription
               /// </summary>
               public const string TrRateTypeDescription = "OTRRTYDESC";

               /// <summary>
               /// Property for TRShipmentRateTypeDescriptio
               /// </summary>
               public const string TrShipmentRateTypeDescriptio = "STRRTYDESC";

               /// <summary>
               /// Property for TRInvoiceRateTypeDescription
               /// </summary>
               public const string TrInvoiceRateTypeDescription = "ITRRTYDESC";

               /// <summary>
               /// Property for PaymentType
               /// </summary>
               public const string PaymentType = "PAYMTYPE";

               /// <summary>
               /// Property for PendingPrepaymentAmount
               /// </summary>
               public const string PendingPrepaymentAmount = "PENDPREPAY";

               /// <summary>
               /// Property for OrderDiscountAmountOverride
               /// </summary>
               public const string OrderDiscountAmountOverride = "DISAMTOVER";

               /// <summary>
               /// Property for JobRelated
               /// </summary>
               public const string JobRelated = "HASJOB";

               /// <summary>
               /// Property for JobRelatedDetailLines
               /// </summary>
               public const string JobRelatedDetailLines = "JOBLINES";

               /// <summary>
               /// Property for ProjectInvoicing
               /// </summary>
               public const string ProjectInvoicing = "NONINVABLE";

               /// <summary>
               /// Property for InvoiceableDetailLines
               /// </summary>
               public const string InvoiceableDetailLines = "LNINVABLE";

               /// <summary>
               /// Property for HasRetainage
               /// </summary>
               public const string HasRetainage = "HASRTG";

               /// <summary>
               /// Property for RetainageTerms
               /// </summary>
               public const string RetainageTerms = "RTGTERMS";

               /// <summary>
               /// Property for RetainageExchangeRate
               /// </summary>
               public const string RetainageExchangeRate = "RTGRATE";

               /// <summary>
               /// Property for RetainageTermsDescription
               /// </summary>
               public const string RetainageTermsDescription = "RTGTERMDSC";

               /// <summary>
               /// Property for CustomerAccountSet
               /// </summary>
               public const string CustomerAccountSet = "CUSACCTSET";

               /// <summary>
               /// Property for CustomerAccountSetDescription
               /// </summary>
               public const string CustomerAccountSetDescription = "CUSACTDESC";

               /// <summary>
               /// Property for EnteredBy
               /// </summary>
               public const string EnteredBy = "ENTEREDBY";

               /// <summary>
               /// Property for EPosSegmentLength
               /// </summary>
               public const string EPosSegmentLength = "PFSEGLEN";

               /// <summary>
               /// Property for ShipmentPostingDate
               /// </summary>
               public const string ShipmentPostingDate = "SHIDATEBUS";

               /// <summary>
               /// Property for InvoicePostingDate
               /// </summary>
               public const string InvoicePostingDate = "INVDATEBUS";

               /// <summary>
               /// Property for PrepaymentDistributedAmount
               /// </summary>
               public const string PrepaymentDistributedAmount = "PAYDISTTOT";

               /// <summary>
               /// Property for PrepaymentUnappliedAmount
               /// </summary>
               public const string PrepaymentUnappliedAmount = "UNAPPLDPAY";

               /// <summary>
               /// Property for SageCrmCompanyID
               /// </summary>
               public const string SageCrmCompanyID = "COMPANYID";

               /// <summary>
               /// Property for SageCrmOpportunityID
               /// </summary>
               public const string SageCrmOpportunityID = "OPPOID";

               /// <summary>
               /// Property for SageCrmPersonID
               /// </summary>
               public const string SageCrmPersonID = "PERSONID";

               /// <summary>
               /// Property for IncludeInCrmOpportunityTotal
               /// </summary>
               public const string IncludeInCrmOpportunityTotal = "INCOPPOTOT";

               /// <summary>
               /// Property for QuoteExpired
               /// </summary>
               public const string QuoteExpired = "QTEXPIRED";

               /// <summary>
               /// Property for OrderUniqActivatedFromQuote
               /// </summary>
               public const string OrderUniqActivatedFromQuote = "QUOORDUNIQ";

               /// <summary>
               /// Property for OrderNumberActivatedFromQuot
               /// </summary>
               public const string OrderNumberActivatedFromQuot = "QUOORDNUM";

               /// <summary>
               /// Property for PromotedCustomerNumber
               /// </summary>
               public const string PromotedCustomerNumber = "CUSTPROMOT";

               /// <summary>
               /// Property for PaymentTypeOnOrder
               /// </summary>
               public const string PaymentTypeOnOrder = "PAYMONORD";

               /// <summary>
               /// Property for PaymentCodeOnOrder
               /// </summary>
               public const string PaymentCodeOnOrder = "PAYMCODE";

               /// <summary>
               /// Property for PaymentCardID
               /// </summary>
               public const string PaymentCardID = "IDCARD";

               /// <summary>
               /// Property for OrderHasPreAuthorization
               /// </summary>
               public const string OrderHasPreAuthorization = "HASPREAUTH";

               /// <summary>
               /// Property for OnholdReason
               /// </summary>
               public const string OnholdReason = "HOLDREASON";

               /// <summary>
               /// Property for IncompleteShipExistForOrder
               /// </summary>
               public const string IncompleteShipExistForOrder = "INCOMPSHIP";

               /// <summary>
               /// Property for DateRequested
               /// </summary>
               public const string DateRequested = "REQUESDATE";

               /// <summary>
               /// Property for TransID
               /// </summary>
               public const string TransID = "TRANSID";

               /// <summary>
               /// Property for XmlString
               /// </summary>
               public const string XmlString = "XMLSTRING";

               /// <summary>
               /// Property for RespInd
               /// </summary>
               public const string RespInd = "RESPIND";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of Order Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for OrderUniquifier
               /// </summary>
               public const int OrderUniquifier = 1;

               /// <summary>
               /// Property Indexer for OrderNumber
               /// </summary>
               public const int OrderNumber = 2;

               /// <summary>
               /// Property Indexer for CustomerNumber
               /// </summary>
               public const int CustomerNumber = 3;

               /// <summary>
               /// Property Indexer for CustomerGroupCode
               /// </summary>
               public const int CustomerGroupCode = 4;

               /// <summary>
               /// Property Indexer for BillToName
               /// </summary>
               public const int BillToName = 5;

               /// <summary>
               /// Property Indexer for BillToAddressLine1
               /// </summary>
               public const int BillToAddressLine1 = 6;

               /// <summary>
               /// Property Indexer for BillToAddressLine2
               /// </summary>
               public const int BillToAddressLine2 = 7;

               /// <summary>
               /// Property Indexer for BillToAddressLine3
               /// </summary>
               public const int BillToAddressLine3 = 8;

               /// <summary>
               /// Property Indexer for BillToAddressLine4
               /// </summary>
               public const int BillToAddressLine4 = 9;

               /// <summary>
               /// Property Indexer for BillToCity
               /// </summary>
               public const int BillToCity = 10;

               /// <summary>
               /// Property Indexer for BillToStateProvince
               /// </summary>
               public const int BillToStateProvince = 11;

               /// <summary>
               /// Property Indexer for BillToZipPostalCode
               /// </summary>
               public const int BillToZipPostalCode = 12;

               /// <summary>
               /// Property Indexer for BillToCountry
               /// </summary>
               public const int BillToCountry = 13;

               /// <summary>
               /// Property Indexer for BillToPhoneNumber
               /// </summary>
               public const int BillToPhoneNumber = 14;

               /// <summary>
               /// Property Indexer for BillToFaxNumber
               /// </summary>
               public const int BillToFaxNumber = 15;

               /// <summary>
               /// Property Indexer for BillToContact
               /// </summary>
               public const int BillToContact = 16;

               /// <summary>
               /// Property Indexer for ShipToLocationCode
               /// </summary>
               public const int ShipToLocationCode = 17;

               /// <summary>
               /// Property Indexer for ShipToName
               /// </summary>
               public const int ShipToName = 18;

               /// <summary>
               /// Property Indexer for ShipToAddressLine1
               /// </summary>
               public const int ShipToAddressLine1 = 19;

               /// <summary>
               /// Property Indexer for ShipToAddressLine2
               /// </summary>
               public const int ShipToAddressLine2 = 20;

               /// <summary>
               /// Property Indexer for ShipToAddressLine3
               /// </summary>
               public const int ShipToAddressLine3 = 21;

               /// <summary>
               /// Property Indexer for ShipToAddressLine4
               /// </summary>
               public const int ShipToAddressLine4 = 22;

               /// <summary>
               /// Property Indexer for ShipToCity
               /// </summary>
               public const int ShipToCity = 23;

               /// <summary>
               /// Property Indexer for ShipToStateProvince
               /// </summary>
               public const int ShipToStateProvince = 24;

               /// <summary>
               /// Property Indexer for ShipToZipPostalCode
               /// </summary>
               public const int ShipToZipPostalCode = 25;

               /// <summary>
               /// Property Indexer for ShipToCountry
               /// </summary>
               public const int ShipToCountry = 26;

               /// <summary>
               /// Property Indexer for ShipToPhoneNumber
               /// </summary>
               public const int ShipToPhoneNumber = 27;

               /// <summary>
               /// Property Indexer for ShipToFaxNumber
               /// </summary>
               public const int ShipToFaxNumber = 28;

               /// <summary>
               /// Property Indexer for ShipToContact
               /// </summary>
               public const int ShipToContact = 29;

               /// <summary>
               /// Property Indexer for CustomerDiscountLevel
               /// </summary>
               public const int CustomerDiscountLevel = 30;

               /// <summary>
               /// Property Indexer for DefaultPriceListCode
               /// </summary>
               public const int DefaultPriceListCode = 31;

               /// <summary>
               /// Property Indexer for PurchaseOrderNumber
               /// </summary>
               public const int PurchaseOrderNumber = 32;

               /// <summary>
               /// Property Indexer for Territory
               /// </summary>
               public const int Territory = 33;

               /// <summary>
               /// Property Indexer for TermsCode
               /// </summary>
               public const int TermsCode = 34;

               /// <summary>
               /// Property Indexer for TotalTermsAmountDue
               /// </summary>
               public const int TotalTermsAmountDue = 35;

               /// <summary>
               /// Property Indexer for DiscountAvailable
               /// </summary>
               public const int DiscountAvailable = 36;

               /// <summary>
               /// Property Indexer for TermsRateOverride
               /// </summary>
               public const int TermsRateOverride = 37;

               /// <summary>
               /// Property Indexer for OrderReference
               /// </summary>
               public const int OrderReference = 38;

               /// <summary>
               /// Property Indexer for OrderType
               /// </summary>
               public const int OrderType = 39;

               /// <summary>
               /// Property Indexer for OrderDate
               /// </summary>
               public const int OrderDate = 40;

               /// <summary>
               /// Property Indexer for ExpectedShipDate
               /// </summary>
               public const int ExpectedShipDate = 41;

               /// <summary>
               /// Property Indexer for QuoteExpirationDate
               /// </summary>
               public const int QuoteExpirationDate = 42;

               /// <summary>
               /// Property Indexer for OrderFiscalYear
               /// </summary>
               public const int OrderFiscalYear = 43;

               /// <summary>
               /// Property Indexer for OrderFiscalPeriod
               /// </summary>
               public const int OrderFiscalPeriod = 44;

               /// <summary>
               /// Property Indexer for ShipViaCode
               /// </summary>
               public const int ShipViaCode = 45;

               /// <summary>
               /// Property Indexer for ShipViaCodeDescription
               /// </summary>
               public const int ShipViaCodeDescription = 46;

               /// <summary>
               /// Property Indexer for LastInvoiceNumber
               /// </summary>
               public const int LastInvoiceNumber = 47;

               /// <summary>
               /// Property Indexer for NumberOfInvoices
               /// </summary>
               public const int NumberOfInvoices = 48;

               /// <summary>
               /// Property Indexer for FreeOnBoardPoint
               /// </summary>
               public const int FreeOnBoardPoint = 49;

               /// <summary>
               /// Property Indexer for TemplateCode
               /// </summary>
               public const int TemplateCode = 50;

               /// <summary>
               /// Property Indexer for DefaultLocationCode
               /// </summary>
               public const int DefaultLocationCode = 51;

               /// <summary>
               /// Property Indexer for OnHold
               /// </summary>
               public const int OnHold = 52;

               /// <summary>
               /// Property Indexer for OrderDescription
               /// </summary>
               public const int OrderDescription = 53;

               /// <summary>
               /// Property Indexer for OrderComment
               /// </summary>
               public const int OrderComment = 54;

               /// <summary>
               /// Property Indexer for OrderPrintStatus
               /// </summary>
               public const int OrderPrintStatus = 55;

               /// <summary>
               /// Property Indexer for LastPostingDate
               /// </summary>
               public const int LastPostingDate = 56;

               /// <summary>
               /// Property Indexer for OrderNoOfPrepayments
               /// </summary>
               public const int OrderNoOfPrepayments = 57;

               /// <summary>
               /// Property Indexer for OverCreditLimit
               /// </summary>
               public const int OverCreditLimit = 58;

               /// <summary>
               /// Property Indexer for ApprovedLimit
               /// </summary>
               public const int ApprovedLimit = 59;

               /// <summary>
               /// Property Indexer for AuthorizingUserID
               /// </summary>
               public const int AuthorizingUserID = 60;

               /// <summary>
               /// Property Indexer for RequiresShippingLabels
               /// </summary>
               public const int RequiresShippingLabels = 61;

               /// <summary>
               /// Property Indexer for ShippingLabelsPrinted
               /// </summary>
               public const int ShippingLabelsPrinted = 62;

               /// <summary>
               /// Property Indexer for Orhomecurr
               /// </summary>
               public const int Orhomecurr = 63;

               /// <summary>
               /// Property Indexer for ORRATETYPE
               /// </summary>
               public const int OrRateType = 64;

               /// <summary>
               /// Property Indexer for ORSOURCURR
               /// </summary>
               public const int OrSourCurr = 65;

               /// <summary>
               /// Property Indexer for ORRATEDATE
               /// </summary>
               public const int OrRateDate = 66;

               /// <summary>
               /// Property Indexer for ORRATE
               /// </summary>
               public const int OrRate = 67;

               /// <summary>
               /// Property Indexer for ORSPREAD
               /// </summary>
               public const int OrSpread = 68;

               /// <summary>
               /// Property Indexer for ORDATEMTCH
               /// </summary>
               public const int OrDateMtch = 69;

               /// <summary>
               /// Property Indexer for ORRATEREP
               /// </summary>
               public const int OrRateRep = 70;

               /// <summary>
               /// Property Indexer for ORRATEOVER
               /// </summary>
               public const int OrRateOver = 71;

               /// <summary>
               /// Property Indexer for TotalAmtItems
               /// </summary>
               public const int TotalAmtItems = 72;

               /// <summary>
               /// Property Indexer for TotalAmtMiscCharges
               /// </summary>
               public const int TotalAmtMiscCharges = 73;

               /// <summary>
               /// Property Indexer for NumberOfLinesonOrder
               /// </summary>
               public const int NumberOfLinesonOrder = 74;

               /// <summary>
               /// Property Indexer for NumberOfLabels
               /// </summary>
               public const int NumberOfLabels = 75;

               /// <summary>
               /// Property Indexer for PrevPaymentsTotal
               /// </summary>
               public const int PrevPaymentsTotal = 76;

               /// <summary>
               /// Property Indexer for PrevPaymentDiscTotal
               /// </summary>
               public const int PrevPaymentDiscTotal = 77;

               /// <summary>
               /// Property Indexer for Salesperson1
               /// </summary>
               public const int Salesperson1 = 78;

               /// <summary>
               /// Property Indexer for Salesperson2
               /// </summary>
               public const int Salesperson2 = 79;

               /// <summary>
               /// Property Indexer for Salesperson3
               /// </summary>
               public const int Salesperson3 = 80;

               /// <summary>
               /// Property Indexer for Salesperson4
               /// </summary>
               public const int Salesperson4 = 81;

               /// <summary>
               /// Property Indexer for Salesperson5
               /// </summary>
               public const int Salesperson5 = 82;

               /// <summary>
               /// Property Indexer for SalesPercentage1
               /// </summary>
               public const int SalesPercentage1 = 83;

               /// <summary>
               /// Property Indexer for SalesPercentage2
               /// </summary>
               public const int SalesPercentage2 = 84;

               /// <summary>
               /// Property Indexer for SalesPercentage3
               /// </summary>
               public const int SalesPercentage3 = 85;

               /// <summary>
               /// Property Indexer for SalesPercentage4
               /// </summary>
               public const int SalesPercentage4 = 86;

               /// <summary>
               /// Property Indexer for SalesPercentage5
               /// </summary>
               public const int SalesPercentage5 = 87;

               /// <summary>
               /// Property Indexer for RecalculateTax
               /// </summary>
               public const int RecalculateTax = 88;

               /// <summary>
               /// Property Indexer for TaxOverridden
               /// </summary>
               public const int TaxOverridden = 89;

               /// <summary>
               /// Property Indexer for TaxGroup
               /// </summary>
               public const int TaxGroup = 90;

               /// <summary>
               /// Property Indexer for TaxAuthority1
               /// </summary>
               public const int TaxAuthority1 = 91;

               /// <summary>
               /// Property Indexer for TaxAuthority2
               /// </summary>
               public const int TaxAuthority2 = 92;

               /// <summary>
               /// Property Indexer for TaxAuthority3
               /// </summary>
               public const int TaxAuthority3 = 93;

               /// <summary>
               /// Property Indexer for TaxAuthority4
               /// </summary>
               public const int TaxAuthority4 = 94;

               /// <summary>
               /// Property Indexer for TaxAuthority5
               /// </summary>
               public const int TaxAuthority5 = 95;

               /// <summary>
               /// Property Indexer for TaxClass1
               /// </summary>
               public const int TaxClass1 = 96;

               /// <summary>
               /// Property Indexer for TaxClass2
               /// </summary>
               public const int TaxClass2 = 97;

               /// <summary>
               /// Property Indexer for TaxClass3
               /// </summary>
               public const int TaxClass3 = 98;

               /// <summary>
               /// Property Indexer for TaxClass4
               /// </summary>
               public const int TaxClass4 = 99;

               /// <summary>
               /// Property Indexer for TaxClass5
               /// </summary>
               public const int TaxClass5 = 100;

               /// <summary>
               /// Property Indexer for TaxBase1
               /// </summary>
               public const int TaxBase1 = 101;

               /// <summary>
               /// Property Indexer for TaxBase2
               /// </summary>
               public const int TaxBase2 = 102;

               /// <summary>
               /// Property Indexer for TaxBase3
               /// </summary>
               public const int TaxBase3 = 103;

               /// <summary>
               /// Property Indexer for TaxBase4
               /// </summary>
               public const int TaxBase4 = 104;

               /// <summary>
               /// Property Indexer for TaxBase5
               /// </summary>
               public const int TaxBase5 = 105;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount1
               /// </summary>
               public const int ExcludedTaxAmount1 = 106;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount2
               /// </summary>
               public const int ExcludedTaxAmount2 = 107;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount3
               /// </summary>
               public const int ExcludedTaxAmount3 = 108;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount4
               /// </summary>
               public const int ExcludedTaxAmount4 = 109;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount5
               /// </summary>
               public const int ExcludedTaxAmount5 = 110;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount1
               /// </summary>
               public const int IncludedTaxAmount1 = 111;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount2
               /// </summary>
               public const int IncludedTaxAmount2 = 112;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount3
               /// </summary>
               public const int IncludedTaxAmount3 = 113;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount4
               /// </summary>
               public const int IncludedTaxAmount4 = 114;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount5
               /// </summary>
               public const int IncludedTaxAmount5 = 115;

               /// <summary>
               /// Property Indexer for Registration1
               /// </summary>
               public const int Registration1 = 116;

               /// <summary>
               /// Property Indexer for Registration2
               /// </summary>
               public const int Registration2 = 117;

               /// <summary>
               /// Property Indexer for Registration3
               /// </summary>
               public const int Registration3 = 118;

               /// <summary>
               /// Property Indexer for Registration4
               /// </summary>
               public const int Registration4 = 119;

               /// <summary>
               /// Property Indexer for Registration5
               /// </summary>
               public const int Registration5 = 120;

               /// <summary>
               /// Property Indexer for OrderCompleted
               /// </summary>
               public const int OrderCompleted = 129;

               /// <summary>
               /// Property Indexer for OrderCompletionDate
               /// </summary>
               public const int OrderCompletionDate = 130;

               /// <summary>
               /// Property Indexer for InvoiceNumber
               /// </summary>
               public const int InvoiceNumber = 131;

               /// <summary>
               /// Property Indexer for Shipdate
               /// </summary>
               public const int Shipdate = 132;

               /// <summary>
               /// Property Indexer for InvoiceDate
               /// </summary>
               public const int InvoiceDate = 133;

               /// <summary>
               /// Property Indexer for InvoiceFiscalYear
               /// </summary>
               public const int InvoiceFiscalYear = 134;

               /// <summary>
               /// Property Indexer for InvoiceFiscalPeriod
               /// </summary>
               public const int InvoiceFiscalPeriod = 135;

               /// <summary>
               /// Property Indexer for NoOfTermsPayments
               /// </summary>
               public const int NoOfTermsPayments = 136;

               /// <summary>
               /// Property Indexer for TermsPaymentsAsOfDate
               /// </summary>
               public const int TermsPaymentsAsOfDate = 137;

               /// <summary>
               /// Property Indexer for OrderTotalEstWeight
               /// </summary>
               public const int OrderTotalEstWeight = 138;

               /// <summary>
               /// Property Indexer for NextDetailNumber
               /// </summary>
               public const int NextDetailNumber = 139;

               /// <summary>
               /// Property Indexer for PostInvoice
               /// </summary>
               public const int PostInvoice = 140;

               /// <summary>
               /// Property Indexer for InvoiceDiscMiscCharges
               /// </summary>
               public const int InvoiceDiscMiscCharges = 141;

               /// <summary>
               /// Property Indexer for InvoiceNoOfPrepayments
               /// </summary>
               public const int InvoiceNoOfPrepayments = 142;

               /// <summary>
               /// Property Indexer for NoLinesQtyShipped
               /// </summary>
               public const int NoLinesQtyShipped = 143;

               /// <summary>
               /// Property Indexer for NoMiscChargesLines
               /// </summary>
               public const int NoMiscChargesLines = 144;

               /// <summary>
               /// Property Indexer for OrderTotalBeforeTax
               /// </summary>
               public const int OrderTotalBeforeTax = 145;

               /// <summary>
               /// Property Indexer for OrderInclTaxTotal
               /// </summary>
               public const int OrderInclTaxTotal = 146;

               /// <summary>
               /// Property Indexer for OrderItemTotalAmount
               /// </summary>
               public const int OrderItemTotalAmount = 147;

               /// <summary>
               /// Property Indexer for OrderDiscountBase
               /// </summary>
               public const int OrderDiscountBase = 148;

               /// <summary>
               /// Property Indexer for OrderDiscountPercentage
               /// </summary>
               public const int OrderDiscountPercentage = 149;

               /// <summary>
               /// Property Indexer for OrderDiscountAmount
               /// </summary>
               public const int OrderDiscountAmount = 150;

               /// <summary>
               /// Property Indexer for OrderTotalMiscCharges
               /// </summary>
               public const int OrderTotalMiscCharges = 151;

               /// <summary>
               /// Property Indexer for OrderSubtotalAmount
               /// </summary>
               public const int OrderSubtotalAmount = 152;

               /// <summary>
               /// Property Indexer for OrderTotalWithInvDisc
               /// </summary>
               public const int OrderTotalWithInvDisc = 153;

               /// <summary>
               /// Property Indexer for OrderExclTaxTotal
               /// </summary>
               public const int OrderExclTaxTotal = 154;

               /// <summary>
               /// Property Indexer for OrderTotal
               /// </summary>
               public const int OrderTotal = 155;

               /// <summary>
               /// Property Indexer for OrderAmountDue
               /// </summary>
               public const int OrderAmountDue = 156;

               /// <summary>
               /// Property Indexer for Inhomecurr
               /// </summary>
               public const int Inhomecurr = 157;

               /// <summary>
               /// Property Indexer for Inratetype
               /// </summary>
               public const int Inratetype = 158;

               /// <summary>
               /// Property Indexer for Insourcurr
               /// </summary>
               public const int Insourcurr = 159;

               /// <summary>
               /// Property Indexer for InRateDate
               /// </summary>
               public const int InRateDate = 160;

               /// <summary>
               /// Property Indexer for InRate
               /// </summary>
               public const int InRate = 161;

               /// <summary>
               /// Property Indexer for Inspread
               /// </summary>
               public const int Inspread = 162;

               /// <summary>
               /// Property Indexer for Indatemtch
               /// </summary>
               public const int Indatemtch = 163;

               /// <summary>
               /// Property Indexer for Inraterep
               /// </summary>
               public const int Inraterep = 164;

               /// <summary>
               /// Property Indexer for Inrateover
               /// </summary>
               public const int Inrateover = 165;

               /// <summary>
               /// Property Indexer for ReceiptBatchNumber
               /// </summary>
               public const int ReceiptBatchNumber = 166;

               /// <summary>
               /// Property Indexer for BankCode
               /// </summary>
               public const int BankCode = 167;

               /// <summary>
               /// Property Indexer for ReceiptType
               /// </summary>
               public const int ReceiptType = 168;

               /// <summary>
               /// Property Indexer for CheckDate
               /// </summary>
               public const int CheckDate = 169;

               /// <summary>
               /// Property Indexer for CheckFiscalYear
               /// </summary>
               public const int CheckFiscalYear = 170;

               /// <summary>
               /// Property Indexer for CheckFiscalPeriod
               /// </summary>
               public const int CheckFiscalPeriod = 171;

               /// <summary>
               /// Property Indexer for CheckNumber
               /// </summary>
               public const int CheckNumber = 172;

               /// <summary>
               /// Property Indexer for PaymentAppliedTo
               /// </summary>
               public const int PaymentAppliedTo = 173;

               /// <summary>
               /// Property Indexer for PaymentInCustCurrency
               /// </summary>
               public const int PaymentInCustCurrency = 174;

               /// <summary>
               /// Property Indexer for InvoiceTotalTermsDisc
               /// </summary>
               public const int InvoiceTotalTermsDisc = 175;

               /// <summary>
               /// Property Indexer for PaymentInBankCurrency
               /// </summary>
               public const int PaymentInBankCurrency = 176;

               /// <summary>
               /// Property Indexer for PaymentHomeCurrency
               /// </summary>
               public const int PaymentHomeCurrency = 177;

               /// <summary>
               /// Property Indexer for PaymentRateType
               /// </summary>
               public const int PaymentRateType = 178;

               /// <summary>
               /// Property Indexer for PaymentSourceCurrency
               /// </summary>
               public const int PaymentSourceCurrency = 179;

               /// <summary>
               /// Property Indexer for PaymentRateDate
               /// </summary>
               public const int PaymentRateDate = 180;

               /// <summary>
               /// Property Indexer for PaymentRate
               /// </summary>
               public const int PaymentRate = 181;

               /// <summary>
               /// Property Indexer for PaymentSpread
               /// </summary>
               public const int PaymentSpread = 182;

               /// <summary>
               /// Property Indexer for PaymentRateDateMatching
               /// </summary>
               public const int PaymentRateDateMatching = 183;

               /// <summary>
               /// Property Indexer for PaymentRateOperator
               /// </summary>
               public const int PaymentRateOperator = 184;

               /// <summary>
               /// Property Indexer for PriceListCodeDesc
               /// </summary>
               public const int PriceListCodeDesc = 185;

               /// <summary>
               /// Property Indexer for TermsCodeDescription
               /// </summary>
               public const int TermsCodeDescription = 186;

               /// <summary>
               /// Property Indexer for TaxGroupCodeDesc
               /// </summary>
               public const int TaxGroupCodeDesc = 187;

               /// <summary>
               /// Property Indexer for LocationCodeDesc
               /// </summary>
               public const int LocationCodeDesc = 188;

               /// <summary>
               /// Property Indexer for SalespersonName1
               /// </summary>
               public const int SalespersonName1 = 189;

               /// <summary>
               /// Property Indexer for SalespersonName2
               /// </summary>
               public const int SalespersonName2 = 190;

               /// <summary>
               /// Property Indexer for SalespersonName3
               /// </summary>
               public const int SalespersonName3 = 191;

               /// <summary>
               /// Property Indexer for SalespersonName4
               /// </summary>
               public const int SalespersonName4 = 192;

               /// <summary>
               /// Property Indexer for SalespersonName5
               /// </summary>
               public const int SalespersonName5 = 193;

               /// <summary>
               /// Property Indexer for TaxAuthority1Desc
               /// </summary>
               public const int TaxAuthority1Desc = 194;

               /// <summary>
               /// Property Indexer for TaxAuthority2Desc
               /// </summary>
               public const int TaxAuthority2Desc = 195;

               /// <summary>
               /// Property Indexer for TaxAuthority3Desc
               /// </summary>
               public const int TaxAuthority3Desc = 196;

               /// <summary>
               /// Property Indexer for TaxAuthority4Desc
               /// </summary>
               public const int TaxAuthority4Desc = 197;

               /// <summary>
               /// Property Indexer for TaxAuthority5Desc
               /// </summary>
               public const int TaxAuthority5Desc = 198;

               /// <summary>
               /// Property Indexer for TaxClass1Description
               /// </summary>
               public const int TaxClass1Description = 199;

               /// <summary>
               /// Property Indexer for TaxClass2Description
               /// </summary>
               public const int TaxClass2Description = 200;

               /// <summary>
               /// Property Indexer for TaxClass3Description
               /// </summary>
               public const int TaxClass3Description = 201;

               /// <summary>
               /// Property Indexer for TaxClass4Description
               /// </summary>
               public const int TaxClass4Description = 202;

               /// <summary>
               /// Property Indexer for TaxClass5Description
               /// </summary>
               public const int TaxClass5Description = 203;

               /// <summary>
               /// Property Indexer for OrderSourceCurrencyDesc
               /// </summary>
               public const int OrderSourceCurrencyDesc = 204;

               /// <summary>
               /// Property Indexer for OrderHomeCurrencyDesc
               /// </summary>
               public const int OrderHomeCurrencyDesc = 205;

               /// <summary>
               /// Property Indexer for OrderRateTypeDescription
               /// </summary>
               public const int OrderRateTypeDescription = 206;

               /// <summary>
               /// Property Indexer for InvoiceSourceCurrDesc
               /// </summary>
               public const int InvoiceSourceCurrDesc = 207;

               /// <summary>
               /// Property Indexer for InvoiceHomeCurrencyDesc
               /// </summary>
               public const int InvoiceHomeCurrencyDesc = 208;

               /// <summary>
               /// Property Indexer for InvoiceRateTypeDesc
               /// </summary>
               public const int InvoiceRateTypeDesc = 209;

               /// <summary>
               /// Property Indexer for PaymentSourceCurrDesc
               /// </summary>
               public const int PaymentSourceCurrDesc = 210;

               /// <summary>
               /// Property Indexer for PaymentHomeCurrencyDesc
               /// </summary>
               public const int PaymentHomeCurrencyDesc = 211;

               /// <summary>
               /// Property Indexer for PaymentRateTypeDesc
               /// </summary>
               public const int PaymentRateTypeDesc = 212;

               /// <summary>
               /// Property Indexer for TotalTaxAmount1
               /// </summary>
               public const int TotalTaxAmount1 = 213;

               /// <summary>
               /// Property Indexer for TotalTaxAmount2
               /// </summary>
               public const int TotalTaxAmount2 = 214;

               /// <summary>
               /// Property Indexer for TotalTaxAmount3
               /// </summary>
               public const int TotalTaxAmount3 = 215;

               /// <summary>
               /// Property Indexer for TotalTaxAmount4
               /// </summary>
               public const int TotalTaxAmount4 = 216;

               /// <summary>
               /// Property Indexer for TotalTaxAmount5
               /// </summary>
               public const int TotalTaxAmount5 = 217;

               /// <summary>
               /// Property Indexer for TotalTaxAmount
               /// </summary>
               public const int TotalTaxAmount = 218;

               /// <summary>
               /// Property Indexer for AuthorizingUserPassword
               /// </summary>
               public const int AuthorizingUserPassword = 219;

               /// <summary>
               /// Property Indexer for OrderRunningTotal
               /// </summary>
               public const int OrderRunningTotal = 220;

               /// <summary>
               /// Property Indexer for OrderTotalPayment
               /// </summary>
               public const int OrderTotalPayment = 221;

               /// <summary>
               /// Property Indexer for OrderTotalPaymentDisc
               /// </summary>
               public const int OrderTotalPaymentDisc = 222;

               /// <summary>
               /// Property Indexer for AmountDueLessCurrPrepayment
               /// </summary>
               public const int AmountDueLessCurrPrepayment = 223;

               /// <summary>
               /// Property Indexer for PerformTaxCalculation
               /// </summary>
               public const int PerformTaxCalculation = 224;

               /// <summary>
               /// Property Indexer for PerformCreditLimitCheck
               /// </summary>
               public const int PerformCreditLimitCheck = 225;

               /// <summary>
               /// Property Indexer for OrderSource
               /// </summary>
               public const int OrderSource = 226;

               /// <summary>
               /// Property Indexer for PerformShipAll
               /// </summary>
               public const int PerformShipAll = 227;

               /// <summary>
               /// Property Indexer for DosConversionInProgress
               /// </summary>
               public const int DosConversionInProgress = 228;

               /// <summary>
               /// Property Indexer for PerformForcedTaxCalculation
               /// </summary>
               public const int PerformForcedTaxCalculation = 229;

               /// <summary>
               /// Property Indexer for PerformManualTaxDistribution
               /// </summary>
               public const int PerformManualTaxDistribution = 230;

               /// <summary>
               /// Property Indexer for TaxCalculationInProgress
               /// </summary>
               public const int TaxCalculationInProgress = 231;

               /// <summary>
               /// Property Indexer for AutoTaxCalculationStatus
               /// </summary>
               public const int AutoTaxCalculationStatus = 232;

               /// <summary>
               /// Property Indexer for OriginatingQuoteNumber
               /// </summary>
               public const int OriginatingQuoteNumber = 243;

               /// <summary>
               /// Property Indexer for DisplayRateWarning
               /// </summary>
               public const int DisplayRateWarning = 244;

               /// <summary>
               /// Property Indexer for CustomerExists
               /// </summary>
               public const int CustomerExists = 245;

               /// <summary>
               /// Property Indexer for InvoiceWillBeProduced
               /// </summary>
               public const int InvoiceWillBeProduced = 246;

               /// <summary>
               /// Property Indexer for SecurityEnabled
               /// </summary>
               public const int SecurityEnabled = 247;

               /// <summary>
               /// Property Indexer for UserCanApproveCreditLift
               /// </summary>
               public const int UserCanApproveCreditLift = 248;

               /// <summary>
               /// Property Indexer for RecalcMultiPaymentDates
               /// </summary>
               public const int RecalcMultiPaymentDates = 249;

               /// <summary>
               /// Property Indexer for BillToEmail
               /// </summary>
               public const int BillToEmail = 250;

               /// <summary>
               /// Property Indexer for BillToContactPhone
               /// </summary>
               public const int BillToContactPhone = 251;

               /// <summary>
               /// Property Indexer for BillToContactFax
               /// </summary>
               public const int BillToContactFax = 252;

               /// <summary>
               /// Property Indexer for BillToContactEmail
               /// </summary>
               public const int BillToContactEmail = 253;

               /// <summary>
               /// Property Indexer for ShipToEmail
               /// </summary>
               public const int ShipToEmail = 254;

               /// <summary>
               /// Property Indexer for ShipToContactPhone
               /// </summary>
               public const int ShipToContactPhone = 255;

               /// <summary>
               /// Property Indexer for ShipToContactFax
               /// </summary>
               public const int ShipToContactFax = 256;

               /// <summary>
               /// Property Indexer for ShipToContactEmail
               /// </summary>
               public const int ShipToContactEmail = 257;

               /// <summary>
               /// Property Indexer for Allowpartialshipments
               /// </summary>
               public const int Allowpartialshipments = 258;

               /// <summary>
               /// Property Indexer for MultipleQuotes
               /// </summary>
               public const int MultipleQuotes = 259;

               /// <summary>
               /// Property Indexer for NumberOfQuotes
               /// </summary>
               public const int NumberOfQuotes = 260;

               /// <summary>
               /// Property Indexer for PerformMultipleQuotesToOrder
               /// </summary>
               public const int PerformMultipleQuotesToOrder = 261;

               /// <summary>
               /// Property Indexer for LastShipmentNumber
               /// </summary>
               public const int LastShipmentNumber = 262;

               /// <summary>
               /// Property Indexer for NumberOfShipments
               /// </summary>
               public const int NumberOfShipments = 263;

               /// <summary>
               /// Property Indexer for ShipmentTrackingNumber
               /// </summary>
               public const int ShipmentTrackingNumber = 264;

               /// <summary>
               /// Property Indexer for PostSequenceNumber
               /// </summary>
               public const int PostSequenceNumber = 266;

               /// <summary>
               /// Property Indexer for ShipmentUniquifier
               /// </summary>
               public const int ShipmentUniquifier = 267;

               /// <summary>
               /// Property Indexer for ShipmentNumber
               /// </summary>
               public const int ShipmentNumber = 268;

               /// <summary>
               /// Property Indexer for Shidate
               /// </summary>
               public const int Shidate = 269;

               /// <summary>
               /// Property Indexer for ShipmentHomeCurrency
               /// </summary>
               public const int ShipmentHomeCurrency = 270;

               /// <summary>
               /// Property Indexer for ShipmentRateType
               /// </summary>
               public const int ShipmentRateType = 271;

               /// <summary>
               /// Property Indexer for ShipmentSourceCurrency
               /// </summary>
               public const int ShipmentSourceCurrency = 272;

               /// <summary>
               /// Property Indexer for ShipmentRateDate
               /// </summary>
               public const int ShipmentRateDate = 273;

               /// <summary>
               /// Property Indexer for ShipmentRate
               /// </summary>
               public const int ShipmentRate = 274;

               /// <summary>
               /// Property Indexer for ShipmentSpread
               /// </summary>
               public const int ShipmentSpread = 275;

               /// <summary>
               /// Property Indexer for ShipmentDateMatch
               /// </summary>
               public const int ShipmentDateMatch = 276;

               /// <summary>
               /// Property Indexer for ShipmentRateOperator
               /// </summary>
               public const int ShipmentRateOperator = 277;

               /// <summary>
               /// Property Indexer for ShipmentRateOverrideFlag
               /// </summary>
               public const int ShipmentRateOverrideFlag = 278;

               /// <summary>
               /// Property Indexer for ShipmentSourceCurrencyDesc
               /// </summary>
               public const int ShipmentSourceCurrencyDesc = 279;

               /// <summary>
               /// Property Indexer for ShipmentHomeCurrencyDesc
               /// </summary>
               public const int ShipmentHomeCurrencyDesc = 280;

               /// <summary>
               /// Property Indexer for ShipmentRateTypeDescription
               /// </summary>
               public const int ShipmentRateTypeDescription = 281;

               /// <summary>
               /// Property Indexer for OrderPartiallyShipped
               /// </summary>
               public const int OrderPartiallyShipped = 282;

               /// <summary>
               /// Property Indexer for ShipmentTotal
               /// </summary>
               public const int ShipmentTotal = 283;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 284;

               /// <summary>
               /// Property Indexer for PredecessorUniquifier
               /// </summary>
               public const int PredecessorUniquifier = 285;

               /// <summary>
               /// Property Indexer for PredecessorNumber
               /// </summary>
               public const int PredecessorNumber = 286;

               /// <summary>
               /// Property Indexer for ProcessOipCommand
               /// </summary>
               public const int ProcessOipCommand = 287;

               /// <summary>
               /// Property Indexer for ProcessOeCommand
               /// </summary>
               public const int ProcessOeCommand = 288;

               /// <summary>
               /// Property Indexer for UserEnteredApprovalAmount
               /// </summary>
               public const int UserEnteredApprovalAmount = 289;

               /// <summary>
               /// Property Indexer for CheckingCustomerCreditLimit
               /// </summary>
               public const int CheckingCustomerCreditLimit = 290;

               /// <summary>
               /// Property Indexer for CheckingCustomerAgingLimit
               /// </summary>
               public const int CheckingCustomerAgingLimit = 291;

               /// <summary>
               /// Property Indexer for CheckingNatAcctCreditLimit
               /// </summary>
               public const int CheckingNatAcctCreditLimit = 292;

               /// <summary>
               /// Property Indexer for CheckingNatAcctAgingLimit
               /// </summary>
               public const int CheckingNatAcctAgingLimit = 293;

               /// <summary>
               /// Property Indexer for CustomerIsOverCreditLimit
               /// </summary>
               public const int CustomerIsOverCreditLimit = 294;

               /// <summary>
               /// Property Indexer for CustomerIsOverAgingLimit
               /// </summary>
               public const int CustomerIsOverAgingLimit = 295;

               /// <summary>
               /// Property Indexer for NatAcctIsOverCreditLimit
               /// </summary>
               public const int NatAcctIsOverCreditLimit = 296;

               /// <summary>
               /// Property Indexer for NatAcctIsOverAgingLimit
               /// </summary>
               public const int NatAcctIsOverAgingLimit = 297;

               /// <summary>
               /// Property Indexer for CustomerCreditLimit
               /// </summary>
               public const int CustomerCreditLimit = 298;

               /// <summary>
               /// Property Indexer for CustomerBalancePosted
               /// </summary>
               public const int CustomerBalancePosted = 299;

               /// <summary>
               /// Property Indexer for CustomerDaysOverdue
               /// </summary>
               public const int CustomerDaysOverdue = 300;

               /// <summary>
               /// Property Indexer for CustomerOverdueLimit
               /// </summary>
               public const int CustomerOverdueLimit = 301;

               /// <summary>
               /// Property Indexer for CustomerBalanceOverdue
               /// </summary>
               public const int CustomerBalanceOverdue = 302;

               /// <summary>
               /// Property Indexer for NatAcctCreditLimit
               /// </summary>
               public const int NatAcctCreditLimit = 303;

               /// <summary>
               /// Property Indexer for NatAcctBalance
               /// </summary>
               public const int NatAcctBalance = 304;

               /// <summary>
               /// Property Indexer for NatAcctDaysOverdue
               /// </summary>
               public const int NatAcctDaysOverdue = 305;

               /// <summary>
               /// Property Indexer for NatAcctOverdueLimit
               /// </summary>
               public const int NatAcctOverdueLimit = 306;

               /// <summary>
               /// Property Indexer for NatAcctBalanceOverdue
               /// </summary>
               public const int NatAcctBalanceOverdue = 307;

               /// <summary>
               /// Property Indexer for ARPendingTransIncluded
               /// </summary>
               public const int ARPendingTransIncluded = 308;

               /// <summary>
               /// Property Indexer for OePendingTransIncluded
               /// </summary>
               public const int OePendingTransIncluded = 309;

               /// <summary>
               /// Property Indexer for OtherPendingTransIncluded
               /// </summary>
               public const int OtherPendingTransIncluded = 310;

               /// <summary>
               /// Property Indexer for ARPendingBalance
               /// </summary>
               public const int ARPendingBalance = 311;

               /// <summary>
               /// Property Indexer for OePendingBalance
               /// </summary>
               public const int OePendingBalance = 312;

               /// <summary>
               /// Property Indexer for OtherPendingBalance
               /// </summary>
               public const int OtherPendingBalance = 313;

               /// <summary>
               /// Property Indexer for CustomerTotalOutstanding
               /// </summary>
               public const int CustomerTotalOutstanding = 314;

               /// <summary>
               /// Property Indexer for NatAcctTotalOutstanding
               /// </summary>
               public const int NatAcctTotalOutstanding = 315;

               /// <summary>
               /// Property Indexer for CustomerLimitLeft
               /// </summary>
               public const int CustomerLimitLeft = 316;

               /// <summary>
               /// Property Indexer for NatAcctLimitLeft
               /// </summary>
               public const int NatAcctLimitLeft = 317;

               /// <summary>
               /// Property Indexer for CustomerLimitExceeded
               /// </summary>
               public const int CustomerLimitExceeded = 318;

               /// <summary>
               /// Property Indexer for NatAcctLimitExceeded
               /// </summary>
               public const int NatAcctLimitExceeded = 319;

               /// <summary>
               /// Property Indexer for LastInvoiceAmount
               /// </summary>
               public const int LastInvoiceAmount = 320;

               /// <summary>
               /// Property Indexer for LastInvoiceDate
               /// </summary>
               public const int LastInvoiceDate = 321;

               /// <summary>
               /// Property Indexer for LastPaymentAmount
               /// </summary>
               public const int LastPaymentAmount = 322;

               /// <summary>
               /// Property Indexer for LastPaymentDate
               /// </summary>
               public const int LastPaymentDate = 323;

               /// <summary>
               /// Property Indexer for DrivenbyUI
               /// </summary>
               public const int DrivenbyUI = 324;

               /// <summary>
               /// Property Indexer for ItemDetailDiscountTotal
               /// </summary>
               public const int ItemDetailDiscountTotal = 325;

               /// <summary>
               /// Property Indexer for MiscChargeDetailDiscountTot
               /// </summary>
               public const int MiscChargeDetailDiscountTot = 326;

               /// <summary>
               /// Property Indexer for DetailDiscountTotal
               /// </summary>
               public const int DetailDiscountTotal = 327;

               /// <summary>
               /// Property Indexer for DetailDiscountPercentage
               /// </summary>
               public const int DetailDiscountPercentage = 328;

               /// <summary>
               /// Property Indexer for DocumentNetOfDetailDisc
               /// </summary>
               public const int DocumentNetOfDetailDisc = 329;

               /// <summary>
               /// Property Indexer for AutoCalcTaxReportingAmounts
               /// </summary>
               public const int AutoCalcTaxReportingAmounts = 330;

               /// <summary>
               /// Property Indexer for TaxReportingTrCurrency
               /// </summary>
               public const int TaxReportingTrCurrency = 331;

               /// <summary>
               /// Property Indexer for TrRateType
               /// </summary>
               public const int TrRateType = 332;

               /// <summary>
               /// Property Indexer for TrRateDate
               /// </summary>
               public const int TrRateDate = 333;

               /// <summary>
               /// Property Indexer for TrRate
               /// </summary>
               public const int TrRate = 334;

               /// <summary>
               /// Property Indexer for TrSpread
               /// </summary>
               public const int TrSpread = 335;

               /// <summary>
               /// Property Indexer for TrRateDateMatching
               /// </summary>
               public const int TrRateDateMatching = 336;

               /// <summary>
               /// Property Indexer for TrRateOperator
               /// </summary>
               public const int TrRateOperator = 337;

               /// <summary>
               /// Property Indexer for TrRateOverrideFlag
               /// </summary>
               public const int TrRateOverrideFlag = 338;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount1
               /// </summary>
               public const int TrExcludedTaxAmount1 = 339;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount2
               /// </summary>
               public const int TrExcludedTaxAmount2 = 340;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount3
               /// </summary>
               public const int TrExcludedTaxAmount3 = 341;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount4
               /// </summary>
               public const int TrExcludedTaxAmount4 = 342;

               /// <summary>
               /// Property Indexer for TRExcludedTaxAmount5
               /// </summary>
               public const int TrExcludedTaxAmount5 = 343;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount1
               /// </summary>
               public const int TrIncludedTaxAmount1 = 344;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount2
               /// </summary>
               public const int TrIncludedTaxAmount2 = 345;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount3
               /// </summary>
               public const int TrIncludedTaxAmount3 = 346;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount4
               /// </summary>
               public const int TrIncludedTaxAmount4 = 347;

               /// <summary>
               /// Property Indexer for TRIncludedTaxAmount5
               /// </summary>
               public const int TrIncludedTaxAmount5 = 348;

               /// <summary>
               /// Property Indexer for TRTaxAmount1
               /// </summary>
               public const int TrTaxAmount1 = 349;

               /// <summary>
               /// Property Indexer for TRTaxAmount2
               /// </summary>
               public const int TrTaxAmount2 = 350;

               /// <summary>
               /// Property Indexer for TRTaxAmount3
               /// </summary>
               public const int TrTaxAmount3 = 351;

               /// <summary>
               /// Property Indexer for TRTaxAmount4
               /// </summary>
               public const int TrTaxAmount4 = 352;

               /// <summary>
               /// Property Indexer for TRTaxAmount5
               /// </summary>
               public const int TrTaxAmount5 = 353;

               /// <summary>
               /// Property Indexer for TRExcludedTaxTotal
               /// </summary>
               public const int TrExcludedTaxTotal = 354;

               /// <summary>
               /// Property Indexer for TRIncludedTaxTotal
               /// </summary>
               public const int TrIncludedTaxTotal = 355;

               /// <summary>
               /// Property Indexer for TRTaxTotal
               /// </summary>
               public const int TrTaxTotal = 356;

               /// <summary>
               /// Property Indexer for TaxReportingShipmentTRCurr
               /// </summary>
               public const int TaxReportingShipmentTrCurr = 357;

               /// <summary>
               /// Property Indexer for TRShipmentRateType
               /// </summary>
               public const int TrShipmentRateType = 358;

               /// <summary>
               /// Property Indexer for TRShipmentRateDate
               /// </summary>
               public const int TrShipmentRateDate = 359;

               /// <summary>
               /// Property Indexer for TRShipmentRate
               /// </summary>
               public const int TrShipmentRate = 360;

               /// <summary>
               /// Property Indexer for TrShipmentSpread
               /// </summary>
               public const int TrShipmentSpread = 361;

               /// <summary>
               /// Property Indexer for TrShipmentRateDateMatching
               /// </summary>
               public const int TrShipmentRateDateMatching = 362;

               /// <summary>
               /// Property Indexer for TrShipmentRateOperator
               /// </summary>
               public const int TrShipmentRateOperator = 363;

               /// <summary>
               /// Property Indexer for TrShipmentRateOverrideFlag
               /// </summary>
               public const int TrShipmentRateOverrideFlag = 364;

               /// <summary>
               /// Property Indexer for TaxReportingInvoiceTrCurre
               /// </summary>
               public const int TaxReportingInvoiceTrCurre = 365;

               /// <summary>
               /// Property Indexer for TRInvoiceRateType
               /// </summary>
               public const int TrInvoiceRateType = 366;

               /// <summary>
               /// Property Indexer for TRInvoiceRateDate
               /// </summary>
               public const int TrInvoiceRateDate = 367;

               /// <summary>
               /// Property Indexer for TRInvoiceRate
               /// </summary>
               public const int TrInvoiceRate = 368;

               /// <summary>
               /// Property Indexer for TrInvoiceSpread
               /// </summary>
               public const int TrInvoiceSpread = 369;

               /// <summary>
               /// Property Indexer for TrInvoiceRateDateMatching
               /// </summary>
               public const int TrInvoiceRateDateMatching = 370;

               /// <summary>
               /// Property Indexer for TrInvoiceRateOperator
               /// </summary>
               public const int TrInvoiceRateOperator = 371;

               /// <summary>
               /// Property Indexer for TrInvoiceRateOverrideFlag
               /// </summary>
               public const int TrInvoiceRateOverrideFlag = 372;

               /// <summary>
               /// Property Indexer for TRCurrencyDescription
               /// </summary>
               public const int TrCurrencyDescription = 373;

               /// <summary>
               /// Property Indexer for TrShipmentCurrencyDescription
               /// </summary>
               public const int TrShipmentCurrencyDescription = 374;

               /// <summary>
               /// Property Indexer for TrInvoiceCurrencyDescription
               /// </summary>
               public const int TrInvoiceCurrencyDescription = 375;

               /// <summary>
               /// Property Indexer for TRRateTypeDescription
               /// </summary>
               public const int TrRateTypeDescription = 376;

               /// <summary>
               /// Property Indexer for TRShipmentRateTypeDescriptio
               /// </summary>
               public const int TrShipmentRateTypeDescriptio = 377;

               /// <summary>
               /// Property Indexer for TRInvoiceRateTypeDescription
               /// </summary>
               public const int TrInvoiceRateTypeDescription = 378;

               /// <summary>
               /// Property Indexer for PaymentType
               /// </summary>
               public const int PaymentType = 379;

               /// <summary>
               /// Property Indexer for PendingPrepaymentAmount
               /// </summary>
               public const int PendingPrepaymentAmount = 384;

               /// <summary>
               /// Property Indexer for OrderDiscountAmountOverride
               /// </summary>
               public const int OrderDiscountAmountOverride = 385;

               /// <summary>
               /// Property Indexer for JobRelated
               /// </summary>
               public const int JobRelated = 386;

               /// <summary>
               /// Property Indexer for JobRelatedDetailLines
               /// </summary>
               public const int JobRelatedDetailLines = 387;

               /// <summary>
               /// Property Indexer for ProjectInvoicing
               /// </summary>
               public const int ProjectInvoicing = 388;

               /// <summary>
               /// Property Indexer for InvoiceableDetailLines
               /// </summary>
               public const int InvoiceableDetailLines = 389;

               /// <summary>
               /// Property Indexer for HasRetainage
               /// </summary>
               public const int HasRetainage = 390;

               /// <summary>
               /// Property Indexer for RetainageTerms
               /// </summary>
               public const int RetainageTerms = 391;

               /// <summary>
               /// Property Indexer for RetainageExchangeRate
               /// </summary>
               public const int RetainageExchangeRate = 392;

               /// <summary>
               /// Property Indexer for RetainageTermsDescription
               /// </summary>
               public const int RetainageTermsDescription = 393;

               /// <summary>
               /// Property Indexer for CustomerAccountSet
               /// </summary>
               public const int CustomerAccountSet = 394;

               /// <summary>
               /// Property Indexer for CustomerAccountSetDescription
               /// </summary>
               public const int CustomerAccountSetDescription = 395;

               /// <summary>
               /// Property Indexer for EnteredBy
               /// </summary>
               public const int EnteredBy = 396;

               /// <summary>
               /// Property Indexer for EPosSegmentLength
               /// </summary>
               public const int EPosSegmentLength = 397;

               /// <summary>
               /// Property Indexer for ShipmentPostingDate
               /// </summary>
               public const int ShipmentPostingDate = 398;

               /// <summary>
               /// Property Indexer for InvoicePostingDate
               /// </summary>
               public const int InvoicePostingDate = 399;

               /// <summary>
               /// Property Indexer for PrepaymentDistributedAmount
               /// </summary>
               public const int PrepaymentDistributedAmount = 400;

               /// <summary>
               /// Property Indexer for PrepaymentUnappliedAmount
               /// </summary>
               public const int PrepaymentUnappliedAmount = 401;

               /// <summary>
               /// Property Indexer for SageCrmCompanyID
               /// </summary>
               public const int SageCrmCompanyID = 402;

               /// <summary>
               /// Property Indexer for SageCrmOpportunityID
               /// </summary>
               public const int SageCrmOpportunityID = 403;

               /// <summary>
               /// Property Indexer for SageCrmPersonID
               /// </summary>
               public const int SageCrmPersonID = 404;

               /// <summary>
               /// Property Indexer for IncludeInCrmOpportunityTotal
               /// </summary>
               public const int IncludeInCrmOpportunityTotal = 405;

               /// <summary>
               /// Property Indexer for QuoteExpired
               /// </summary>
               public const int QuoteExpired = 406;

               /// <summary>
               /// Property Indexer for OrderUniqActivatedFromQuote
               /// </summary>
               public const int OrderUniqActivatedFromQuote = 407;

               /// <summary>
               /// Property Indexer for OrderNumberActivatedFromQuot
               /// </summary>
               public const int OrderNumberActivatedFromQuot = 408;

               /// <summary>
               /// Property Indexer for PromotedCustomerNumber
               /// </summary>
               public const int PromotedCustomerNumber = 409;

               /// <summary>
               /// Property Indexer for PaymentTypeOnOrder
               /// </summary>
               public const int PaymentTypeOnOrder = 410;

               /// <summary>
               /// Property Indexer for PaymentCodeOnOrder
               /// </summary>
               public const int PaymentCodeOnOrder = 411;

               /// <summary>
               /// Property Indexer for PaymentCardID
               /// </summary>
               public const int PaymentCardID = 412;

               /// <summary>
               /// Property Indexer for OrderHasPreAuthorization
               /// </summary>
               public const int OrderHasPreAuthorization = 413;

               /// <summary>
               /// Property Indexer for OnholdReason
               /// </summary>
               public const int OnholdReason = 414;

               /// <summary>
               /// Property Indexer for IncompleteShipExistForOrder
               /// </summary>
               public const int IncompleteShipExistForOrder = 415;

               /// <summary>
               /// Property Indexer for DateRequested
               /// </summary>
               public const int DateRequested = 416;

               /// <summary>
               /// Property Indexer for the quick pre-auth/charge transaction ID
               /// </summary>
               public const int TransID = 417;

               /// <summary>
               /// Property Indexer for XML String for Quick Charge/Pre-Authorization
               /// </summary>
               public const int XmlString = 418;

               /// <summary>
               /// Property Indexer for Respond Indicator
               /// </summary>
               public const int ResponseIndicator = 419;

               /// <summary>
               /// Property Indexer for 
               /// </summary>
               public const int ResponseCode = 420;

               /// <summary>
               /// Property Indexer for 
               /// </summary>
               public const int ResponseMessage = 421;

               /// <summary>
               /// Property Indexer for 
               /// </summary>
               public const int AuthorizationCode = 422;

               /// <summary>
               /// Property Indexer for 
               /// </summary>
               public const int AVSResult = 423;

               /// <summary>
               /// Property Indexer for 
               /// </summary>
               public const int CVVResult = 424;

               /// <summary>
               /// Property Indexer for 
               /// </summary>
               public const int Transdate = 425;

               /// <summary>
               /// Property Indexer for 
               /// </summary>
               public const int Vanref = 426;

               /// <summary>
               /// Property Indexer for 
               /// </summary>
               public const int Last4 = 427;

               /// <summary>
               /// Property Indexer for 
               /// </summary>
               public const int PmtDesc = 428;

               /// <summary>
               /// Property Indexer for 
               /// </summary>
               public const int PmtTypeID = 429;
          }
          #endregion

          #region Keys

          /// <summary>
          /// Order Keys
          /// </summary>
          public class Keys
          {
              /// <summary>
              /// Order Uniquifier Key
              /// </summary>
              public const int OrderUniquifier = 0;

              /// <summary>
              /// Order Number Key
              /// </summary>
              public const int OrderNumber = 1;
          }

          #endregion


     }
}
