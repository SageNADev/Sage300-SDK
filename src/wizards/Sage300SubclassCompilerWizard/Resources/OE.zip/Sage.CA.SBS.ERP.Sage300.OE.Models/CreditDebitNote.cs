// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for CreditDebitNote
    /// </summary>
    public partial class CreditDebitNote : ModelBase
    {
        public CreditDebitNote()
        {
            CreditDebitDetails = new EnumerableResponse<CreditDebitDetail>();
            CreditDebitDetailsLotNumber = new EnumerableResponse<CreditDebitDetailLotNumber>();
            CreditDebitDetailSerialNos = new EnumerableResponse<CreditDebitDetailSerialNo>();
            CreditDebitNoteOptionalFields = new EnumerableResponse<CreditDebitNoteOptionalField>();
            CreditDebitDetailOptionalFields = new EnumerableResponse<CreditDebitDetailOptionalField>();
            CreditDebitKittingDetails = new EnumerableResponse<CreditDebitKittingDetail>();
            CreditDebitKittingSerialNos = new EnumerableResponse<CreditDebitKittingSerialNo>();
            CreditDebitKittingDetailsLot = new EnumerableResponse<CreditDebitKittingDetailLot>();
            CreditDebitBomDetails = new EnumerableResponse<CreditDebitBomDetail>();
            CreditDebitTaxDetails = new EnumerableResponse<CreditDebitTaxDetail>();
        }

        /// <summary>
        /// Gets or sets CNUniquifier
        /// </summary>
        [Key]
        [Display(Name = "CNUniquifier", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CnUniquifier, Id = Index.CnUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CnUniquifier { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [Display(Name = "OrderNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [Display(Name = "InvoiceNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteNumber
        /// </summary>
        [Display(Name = "CreditDebitNoteNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [ViewField(Name = Fields.CreditDebitNoteNumber, Id = Index.CreditDebitNoteNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string CreditDebitNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets ICDayEndTransNumber
        /// </summary>
        [Display(Name = "ICDayEndTransNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ICDayEndTransNumber, Id = Index.ICDayEndTransNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ICDayEndTransNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        [GridColumn(IsDrillDown = true)]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets BillTo
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillTo", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillTo, Id = Index.BillTo, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillTo { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToAddress1, Id = Index.BillToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToAddress2, Id = Index.BillToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToAddress3, Id = Index.BillToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToAddress4, Id = Index.BillToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets BillToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToCity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToCity, Id = Index.BillToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCity { get; set; }

        /// <summary>
        /// Gets or sets BillToState
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToState", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToState, Id = Index.BillToState, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToState { get; set; }

        /// <summary>
        /// Gets or sets BillToZipCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToZipCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToZipCode, Id = Index.BillToZipCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string BillToZipCode { get; set; }

        /// <summary>
        /// Gets or sets BillToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToCountry", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToCountry, Id = Index.BillToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCountry { get; set; }

        /// <summary>
        /// Gets or sets BillToPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditDebitNoteNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.BillToPhone, Id = Index.BillToPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToPhone { get; set; }

        /// <summary>
        /// Gets or sets BillToFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToFax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToFax, Id = Index.BillToFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToFax { get; set; }

        /// <summary>
        /// Gets or sets BillToContact
        /// </summary>
        [Display(Name = "BillToContact", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContact, Id = Index.BillToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToContact { get; set; }

        /// <summary>
        /// Gets or sets CustomerDiscountLevel
        /// </summary>
        [Display(Name = "CustomerDiscountLevel", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerDiscountLevel, Id = Index.CustomerDiscountLevel, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerDiscountLevel CustomerDiscountLevel { get; set; }

        /// <summary>
        /// Gets or sets DefaultPriceListCode
        /// </summary>
        [Display(Name = "DefaultPriceListCode", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultPriceListCode, Id = Index.DefaultPriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultPriceListCode { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [Display(Name = "PurchaseOrderNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets Territory
        /// </summary>
        [Display(Name = "Territory", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Territory, Id = Index.Territory, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Territory { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [Display(Name = "Reference", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets OrderDate
        /// </summary>
        [Display(Name = "OrderDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets FreeOnBoardPoint
        /// </summary>
        [Display(Name = "FreeOnBoardPoint", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FreeOnBoardPoint, Id = Index.FreeOnBoardPoint, FieldType = EntityFieldType.Char, Size = 60)]
        public string FreeOnBoardPoint { get; set; }

        /// <summary>
        /// Gets or sets TemplateCode
        /// </summary>
        [Display(Name = "TemplateCode", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TemplateCode { get; set; }

        /// <summary>
        /// Gets or sets DefaultLocationCode
        /// </summary>
        [Display(Name = "DefaultLocationCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultLocationCode, Id = Index.DefaultLocationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultLocationCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [Display(Name = "Comment", ResourceType = typeof(OECommonResx))]
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDate
        /// </summary>
        [Display(Name = "ShipmentDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentDate, Id = Index.ShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDate
        /// </summary>
        [Display(Name = "InvoiceDate", ResourceType = typeof(OECommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.InvoiceDate, Id = Index.InvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceFiscalYear
        /// </summary>
        [Display(Name = "InvoiceFiscalYear", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceFiscalYear, Id = Index.InvoiceFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string InvoiceFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets InvoiceFiscalPeriod
        /// </summary>
        [Display(Name = "InvoiceFiscalPeriod", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoiceFiscalPeriod, Id = Index.InvoiceFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoiceFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets InvoiceHomeCurrency
        /// </summary>
        [Display(Name = "InvoiceHomeCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceHomeCurrency, Id = Index.InvoiceHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string InvoiceHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateType
        /// </summary>
        [Display(Name = "InvoiceRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceRateType, Id = Index.InvoiceRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string InvoiceRateType { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSourceCurrency
        /// </summary>
        [Display(Name = "InvoiceSourceCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceSourceCurrency, Id = Index.InvoiceSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string InvoiceSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateDate
        /// </summary>
        [Display(Name = "InvoiceRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceRateDate, Id = Index.InvoiceRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoiceRateDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRate
        /// </summary>
        [Display(Name = "InvoiceRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceRate, Id = Index.InvoiceRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal InvoiceRate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSpread
        /// </summary>
        [Display(Name = "InvoiceSpread", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceSpread, Id = Index.InvoiceSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal InvoiceSpread { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateDateMatching
        /// </summary>
        [Display(Name = "InvoiceRateDateMatching", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceRateDateMatching, Id = Index.InvoiceRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoiceRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateOperator
        /// </summary>
        [Display(Name = "InvoiceRateOperator", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceRateOperator, Id = Index.InvoiceRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoiceRateOperator { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateOverrideFlag
        /// </summary>
        [Display(Name = "InvoiceRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceRateOverrideFlag, Id = Index.InvoiceRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InvoiceRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets CRItemSubtotal
        /// </summary>
        [Display(Name = "CRItemSubtotal", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CRItemSubtotal, Id = Index.CRItemSubtotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CRItemSubtotal { get; set; }

        /// <summary>
        /// Gets or sets CRMiscChargesSubtotal
        /// </summary>
        [Display(Name = "CRMiscChargesSubtotal", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CRMiscChargesSubtotal, Id = Index.CRMiscChargesSubtotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CRMiscChargesSubtotal { get; set; }

        /// <summary>
        /// Gets or sets ReturnDate
        /// </summary>
        [Display(Name = "ReturnDate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.ReturnDate, Id = Index.ReturnDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReturnDate { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteDate
        /// </summary>      
        /// <value>Credit Debit Note Date.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Date", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditDebitNoteDate, Id = Index.CreditDebitNoteDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CreditDebitNoteDate { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteFiscalYear
        /// </summary>
        [Display(Name = "CreditDebitNoteFiscalYear", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditDebitNoteFiscalYear, Id = Index.CreditDebitNoteFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string CreditDebitNoteFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteFiscalPeriod
        /// </summary>
        [Display(Name = "CreditDebitNoteFiscalPeriod", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteFiscalPeriod, Id = Index.CreditDebitNoteFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public CreditDebitNoteFiscalPeriod CreditDebitNoteFiscalPeriod { get; set; }


        /// <summary>
        /// Gets or Sets Fiscal Year Period
        /// </summary>
        public string FiscalYearPeriod { get; set; }


        /// <summary>
        /// Gets or sets NoOfLinesInCreditDebitNote
        /// </summary>
        [Display(Name = "NoOfLinesInCreditDebitNote", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.NoOfLinesInCreditDebitNote, Id = Index.NoOfLinesInCreditDebitNote, FieldType = EntityFieldType.Int, Size = 2)]
        public int NoOfLinesInCreditDebitNote { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteTotEstWeight
        /// </summary>
        [Display(Name = "CreditDebitNoteTotEstWeight", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteTotEstWeight, Id = Index.CreditDebitNoteTotEstWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal CreditDebitNoteTotEstWeight { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteStatus
        /// </summary>
        [Display(Name = "CreditDebitNoteStatus", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteStatus, Id = Index.CreditDebitNoteStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public CreditDebitNoteStatus CreditDebitNoteStatus { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNotePrinted
        /// </summary>
        [Display(Name = "CreditDebitNotePrinted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNotePrinted, Id = Index.CreditDebitNotePrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public CreditDebitNotePrinted CreditDebitNotePrinted { get; set; }

        /// <summary>
        /// Gets or sets CNDNDiscountonMiscCharges
        /// </summary>
        [Display(Name = "CNDNDiscountonMiscCharges", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CnDnDiscountonMiscCharges, Id = Index.CnDnDiscountonMiscCharges, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CnDnDiscountonMiscCharges { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets POSTDATE
        /// </summary>
        [Display(Name = "PostDate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PostDate, Id = Index.PostDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostDate { get; set; }

        /// <summary>
        /// Gets or sets CompletionDate
        /// </summary>
        [Display(Name = "CompletionDate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CompletionDate, Id = Index.CompletionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CompletionDate { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteTotBeforeTax
        /// </summary>
        [Display(Name = "CreditDebitNoteTotBeforeTax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteTotBeforeTax, Id = Index.CreditDebitNoteTotBeforeTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditDebitNoteTotBeforeTax { get; set; }

        /// <summary>
        /// Gets or sets CNDNIncludedTaxTotalAmt
        /// </summary>
        [Display(Name = "CNDNIncludedTaxTotalAmt", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CnDnIncludedTaxTotalAmt, Id = Index.CnDnIncludedTaxTotalAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CnDnIncludedTaxTotalAmt { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteItemTotalAmt
        /// </summary>
        [Display(Name = "CreditDebitNoteItemTotalAmt", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteItemTotalAmt, Id = Index.CreditDebitNoteItemTotalAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditDebitNoteItemTotalAmt { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteDiscountBase
        /// </summary>
        [Display(Name = "CreditDebitNoteDiscountBase", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteDiscountBase, Id = Index.CreditDebitNoteDiscountBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditDebitNoteDiscountBase { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteDiscountPerce
        /// </summary>
        [Display(Name = "CreditDebitNoteDiscountPerce", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteDiscountPerce, Id = Index.CreditDebitNoteDiscountPerce, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CreditDebitNoteDiscountPerce { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteDiscountAmt
        /// </summary>
        [Display(Name = "CreditDebitNoteDiscountAmt", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteDiscountAmt, Id = Index.CreditDebitNoteDiscountAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditDebitNoteDiscountAmt { get; set; }

        /// <summary>
        /// Gets or sets CNDNTotalMiscCharges
        /// </summary>
        [Display(Name = "CNDNTotalMiscCharges", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CnDnTotalMiscCharges, Id = Index.CnDnTotalMiscCharges, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CnDnTotalMiscCharges { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteSubtotalAmt
        /// </summary>
        [Display(Name = "CreditDebitNoteSubtotalAmt", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [GridColumn]
        [ViewField(Name = Fields.CreditDebitNoteSubtotalAmt, Id = Index.CreditDebitNoteSubtotalAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditDebitNoteSubtotalAmt { get; set; }

        /// <summary>
        /// Gets or sets CNDNTotalWithCNDiscount
        /// </summary>
        [Display(Name = "CNDNTotalWithCNDiscount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CnDnTotalWithCnDiscount, Id = Index.CnDnTotalWithCnDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CnDnTotalWithCnDiscount { get; set; }

        /// <summary>
        /// Gets or sets CNDNExcludedTaxTotalAmount
        /// </summary>
        [Display(Name = "CNDNExcludedTaxTotalAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CnDnExcludedTaxTotalAmount, Id = Index.CnDnExcludedTaxTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CnDnExcludedTaxTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteTotal
        /// </summary>
        [Display(Name = "CreditDebitNoteTotal", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [GridColumn]
        [ViewField(Name = Fields.CreditDebitNoteTotal, Id = Index.CreditDebitNoteTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditDebitNoteTotal { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteHomeCurrency
        /// </summary>
        [Display(Name = "CreditDebitNoteHomeCurrency", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditDebitNoteHomeCurrency, Id = Index.CreditDebitNoteHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CreditDebitNoteHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteRateType
        /// </summary>
        [Display(Name = "CreditNoteRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.CreditDebitNoteRateType, Id = Index.CreditDebitNoteRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CreditDebitNoteRateType { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteSourceCurr
        /// </summary>
        [Display(Name = "CreditDebitNoteSourceCurr", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditDebitNoteSourceCurr, Id = Index.CreditDebitNoteSourceCurr, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CreditDebitNoteSourceCurr { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteRateDate
        /// </summary>
        [Display(Name = "CreditNoteRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditDebitNoteRateDate, Id = Index.CreditDebitNoteRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CreditDebitNoteRateDate { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteRate
        /// </summary>
        [Display(Name = "CreditDebitNoteRate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteRate, Id = Index.CreditDebitNoteRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CreditDebitNoteRate { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteSpread
        /// </summary>
        [Display(Name = "CreditDebitNoteSpread", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteSpread, Id = Index.CreditDebitNoteSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CreditDebitNoteSpread { get; set; }

        /// <summary>
        /// Gets or sets CNDNRateDateMatching
        /// </summary>
        [Display(Name = "CNDNRateDateMatching", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CnDnRateDateMatching, Id = Index.CnDnRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int CnDnRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteRateOperator
        /// </summary>
        [Display(Name = "CreditDebitNoteRateOperator", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteRateOperator, Id = Index.CreditDebitNoteRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreditDebitNoteRateOperator { get; set; }

        /// <summary>
        /// Gets or sets CNDNRateOverrideFlag
        /// </summary>
        [Display(Name = "CNDNRateOverrideFlag", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CnDnRateOverrideFlag, Id = Index.CnDnRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CnDnRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1
        /// </summary>
        [Display(Name = "Salesperson1", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2
        /// </summary>
        [Display(Name = "Salesperson2", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3
        /// </summary>
        [Display(Name = "Salesperson3", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4
        /// </summary>
        [Display(Name = "Salesperson4", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5
        /// </summary>
        [Display(Name = "Salesperson5", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage1
        /// </summary>
        [Display(Name = "SalesPercentage1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPercentage1, Id = Index.SalesPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage2
        /// </summary>
        [Display(Name = "SalesPercentage2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPercentage2, Id = Index.SalesPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage3
        /// </summary>
        [Display(Name = "SalesPercentage3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPercentage3, Id = Index.SalesPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage4
        /// </summary>
        [Display(Name = "SalesPercentage4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPercentage4, Id = Index.SalesPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage5
        /// </summary>
        [Display(Name = "SalesPercentage5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPercentage5, Id = Index.SalesPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets RecalculateTax
        /// </summary>
        [Display(Name = "RecalculateTax", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RecalculateTax, Id = Index.RecalculateTax, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RecalculateTax { get; set; }

        /// <summary>
        /// Gets or sets TaxOverridden
        /// </summary>
        [Display(Name = "TaxOverridden", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxOverridden, Id = Index.TaxOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [Display(Name = "TaxGroup", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [Display(Name = "TaxAuthority1", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [Display(Name = "TaxAuthority2", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [Display(Name = "TaxAuthority3", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [Display(Name = "TaxAuthority4", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [Display(Name = "TaxAuthority5", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount1
        /// </summary>
        [Display(Name = "ExcludedTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount1, Id = Index.ExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount2
        /// </summary>
        [Display(Name = "ExcludedTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount2, Id = Index.ExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount3
        /// </summary>
        [Display(Name = "ExcludedTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount3, Id = Index.ExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount4
        /// </summary>
        [Display(Name = "ExcludedTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount4, Id = Index.ExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount5
        /// </summary>
        [Display(Name = "ExcludedTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount5, Id = Index.ExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount1
        /// </summary>
        [Display(Name = "IncludedTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount1, Id = Index.IncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount2
        /// </summary>
        [Display(Name = "IncludedTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount2, Id = Index.IncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount3
        /// </summary>
        [Display(Name = "IncludedTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount3, Id = Index.IncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount4
        /// </summary>
        [Display(Name = "IncludedTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount4, Id = Index.IncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount5
        /// </summary>
        [Display(Name = "IncludedTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount5, Id = Index.IncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets Registration1
        /// </summary>
        [Display(Name = "Registration1", ResourceType = typeof(OECommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration1, Id = Index.Registration1, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration1 { get; set; }

        /// <summary>
        /// Gets or sets Registration2
        /// </summary>
        [Display(Name = "Registration2", ResourceType = typeof(OECommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration2, Id = Index.Registration2, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration2 { get; set; }

        /// <summary>
        /// Gets or sets Registration3
        /// </summary>
        [Display(Name = "Registration3", ResourceType = typeof(OECommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration3, Id = Index.Registration3, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration3 { get; set; }

        /// <summary>
        /// Gets or sets Registration4
        /// </summary>
        [Display(Name = "Registration4", ResourceType = typeof(OECommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration4, Id = Index.Registration4, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration4 { get; set; }

        /// <summary>
        /// Gets or sets Registration5
        /// </summary>
        [Display(Name = "Registration5", ResourceType = typeof(OECommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration5, Id = Index.Registration5, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration5 { get; set; }

        /// <summary>
        /// Gets or sets PriceListCodeDescription
        /// </summary>
        [Display(Name = "PriceListCodeDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PriceListCodeDescription, Id = Index.PriceListCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string PriceListCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets TermsCodeDescription
        /// </summary>
        [Display(Name = "TermsCodeDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TermsCodeDescription, Id = Index.TermsCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TermsCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupCodeDescription
        /// </summary>
        [Display(Name = "TaxGroupCodeDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroupCodeDescription, Id = Index.TaxGroupCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets LocationCodeDescription
        /// </summary>
        [Display(Name = "LocationCodeDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LocationCodeDescription, Id = Index.LocationCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName1
        /// </summary>
        [Display(Name = "SalespersonName1", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName1, Id = Index.SalespersonName1, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName1 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName2
        /// </summary>
        [Display(Name = "SalespersonName2", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName2, Id = Index.SalespersonName2, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName2 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName3
        /// </summary>
        [Display(Name = "SalespersonName3", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName3, Id = Index.SalespersonName3, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName3 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName4
        /// </summary>
        [Display(Name = "SalespersonName4", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName4, Id = Index.SalespersonName4, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName4 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName5
        /// </summary>
        [Display(Name = "SalespersonName5", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName5, Id = Index.SalespersonName5, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1Description
        /// </summary>
        [Display(Name = "TaxAuthority1Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1Description, Id = Index.TaxAuthority1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2Description
        /// </summary>
        [Display(Name = "TaxAuthority2Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2Description, Id = Index.TaxAuthority2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3Description
        /// </summary>
        [Display(Name = "TaxAuthority3Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3Description, Id = Index.TaxAuthority3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4Description
        /// </summary>
        [Display(Name = "TaxAuthority4Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4Description, Id = Index.TaxAuthority4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5Description
        /// </summary>
        [Display(Name = "TaxAuthority5Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5Description, Id = Index.TaxAuthority5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority5Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [Display(Name = "TaxClass1Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [Display(Name = "TaxClass2Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [Display(Name = "TaxClass3Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [Display(Name = "TaxClass4Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [Display(Name = "TaxClass5Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSourceCurrencyDesc
        /// </summary>
        [Display(Name = "InvoiceSourceCurrencyDesc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceSourceCurrencyDesc, Id = Index.InvoiceSourceCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceSourceCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets InvoiceHomeCurrencyDesc
        /// </summary>
        [Display(Name = "InvoiceHomeCurrencyDesc", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceHomeCurrencyDesc, Id = Index.InvoiceHomeCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceHomeCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateTypeDescription
        /// </summary>
        [Display(Name = "InvoiceRateTypeDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceRateTypeDescription, Id = Index.InvoiceRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets CNDNSourceCurrencyDesc
        /// </summary>
        [Display(Name = "CNDNSourceCurrencyDesc", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CnDnSourceCurrencyDesc, Id = Index.CnDnSourceCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string CnDnSourceCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets CNDNHomeCurrencyDescription
        /// </summary>
        [Display(Name = "CNDNHomeCurrencyDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CnDnHomeCurrencyDescription, Id = Index.CnDnHomeCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CnDnHomeCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteRateTypeDesc
        /// </summary>
        [Display(Name = "CreditDebitNoteRateTypeDesc", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditDebitNoteRateTypeDesc, Id = Index.CreditDebitNoteRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string CreditDebitNoteRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteRunningTotal
        /// </summary>
        [Display(Name = "CreditDebitNoteRunningTotal", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteRunningTotal, Id = Index.CreditDebitNoteRunningTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditDebitNoteRunningTotal { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount1
        /// </summary>
        [Display(Name = "TotalTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount1, Id = Index.TotalTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount2
        /// </summary>
        [Display(Name = "TotalTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount2, Id = Index.TotalTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount3
        /// </summary>
        [Display(Name = "TotalTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount3, Id = Index.TotalTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount4
        /// </summary>
        [Display(Name = "TotalTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount4, Id = Index.TotalTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount5
        /// </summary>
        [Display(Name = "TotalTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount5, Id = Index.TotalTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount
        /// </summary>
        [Display(Name = "TotalTaxAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalTaxAmount, Id = Index.TotalTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets PerformTaxCalculation
        /// </summary>
        [Display(Name = "PerformTaxCalculation", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PerformTaxCalculation, Id = Index.PerformTaxCalculation, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformTaxCalculation { get; set; }

        /// <summary>
        /// Gets or sets PerformForcedTaxCalculation
        /// </summary>
        [Display(Name = "PerformForcedTaxCalculation", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PerformForcedTaxCalculation, Id = Index.PerformForcedTaxCalculation, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformForcedTaxCalculation { get; set; }

        /// <summary>
        /// Gets or sets PerformDistributionOfManTax
        /// </summary>
        [Display(Name = "PerformDistributionOfManTax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PerformDistributionOfManTax, Id = Index.PerformDistributionOfManTax, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformDistributionOfManTax { get; set; }

        /// <summary>
        /// Gets or sets TaxCalculationInProgress
        /// </summary>
        [Display(Name = "TaxCalculationInProgress", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxCalculationInProgress, Id = Index.TaxCalculationInProgress, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxCalculationInProgress { get; set; }

        /// <summary>
        /// Gets or sets AutoTaxCalculationStatus
        /// </summary>
        [Display(Name = "AutoTaxCalculationStatus", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.AutoTaxCalculationStatus, Id = Index.AutoTaxCalculationStatus, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AutoTaxCalculationStatus { get; set; }

        /// <summary>
        /// Gets or sets CustomerExists
        /// </summary>
        [Display(Name = "CustomerExists", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerExists, Id = Index.CustomerExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerExists { get; set; }

        /// <summary>
        /// Gets or sets InvoiceExists
        /// </summary>
        [Display(Name = "InvoiceExists", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoiceExists, Id = Index.InvoiceExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InvoiceExists { get; set; }

        /// <summary>
        /// Gets or sets BillToEmail
        /// </summary>
        [Display(Name = "BillToEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToEmail, Id = Index.BillToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToEmail { get; set; }

        /// <summary>
        /// Gets or sets BillToContactPhone
        /// </summary>
        [Display(Name = "BillToContactPhone", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContactPhone, Id = Index.BillToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets BillToContactFax
        /// </summary>
        [Display(Name = "BillToContactFax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContactFax, Id = Index.BillToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactFax { get; set; }

        /// <summary>
        /// Gets or sets BillToContactEmail
        /// </summary>
        [Display(Name = "BillToContactEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContactEmail, Id = Index.BillToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public CreditDebitNoteType Type { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTrackingNumber
        /// </summary>
        [Display(Name = "ShipmentTrackingNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentTrackingNumber, Id = Index.ShipmentTrackingNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string ShipmentTrackingNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCode
        /// </summary>
        [Display(Name = "ShipViaCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCodeDescription
        /// </summary>
        [Display(Name = "ShipViaCodeDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipViaCodeDescription, Id = Index.ShipViaCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets PostSequenceNumber
        /// </summary>
        [Display(Name = "PostSequenceNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PostSequenceNumber, Id = Index.PostSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long PostSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocationCode
        /// </summary>
        [Display(Name = "ShipToLocationCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToLocationCode, Id = Index.ShipToLocationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipToLocationCode { get; set; }

        /// <summary>
        /// Gets or sets ShipToName
        /// </summary>
        [Display(Name = "ShipToName", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToName, Id = Index.ShipToName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToName { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine1
        /// </summary>
        [Display(Name = "ShipToAddressLine1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddressLine1, Id = Index.ShipToAddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine2
        /// </summary>
        [Display(Name = "ShipToAddressLine2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddressLine2, Id = Index.ShipToAddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine3
        /// </summary>
        [Display(Name = "ShipToAddressLine3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddressLine3, Id = Index.ShipToAddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine4
        /// </summary>
        [Display(Name = "ShipToAddressLine4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddressLine4, Id = Index.ShipToAddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets ShipToCity
        /// </summary>
        [Display(Name = "ShipToCity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToCity, Id = Index.ShipToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCity { get; set; }

        /// <summary>
        /// Gets or sets ShipToStateProvince
        /// </summary>
        [Display(Name = "ShipToStateProvince", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToStateProvince, Id = Index.ShipToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets ShipToZipPostalCode
        /// </summary>
        [Display(Name = "ShipToZIPPostalCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToZipPostalCode, Id = Index.ShipToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ShipToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets ShipToCountry
        /// </summary>
        [Display(Name = "ShipToCountry", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToCountry, Id = Index.ShipToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCountry { get; set; }

        /// <summary>
        /// Gets or sets ShipToPhoneNumber
        /// </summary>
        [Display(Name = "ShipToPhoneNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToPhoneNumber, Id = Index.ShipToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToFaxNumber
        /// </summary>
        [Display(Name = "ShipToFaxNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToFaxNumber, Id = Index.ShipToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToContact
        /// </summary>
        [Display(Name = "ShipToContact", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContact, Id = Index.ShipToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToContact { get; set; }

        /// <summary>
        /// Gets or sets ShipToEmail
        /// </summary>
        [Display(Name = "ShipToEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToEmail, Id = Index.ShipToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactPhone
        /// </summary>
        [Display(Name = "ShipToContactPhone", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactPhone, Id = Index.ShipToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactFax
        /// </summary>
        [Display(Name = "ShipToContactFax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactFax, Id = Index.ShipToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactFax { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactEmail
        /// </summary>
        [Display(Name = "ShipToContactEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactEmail, Id = Index.ShipToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets InvoiceUniquifier
        /// </summary>
        [Display(Name = "InvoiceUniquifier", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal InvoiceUniquifier { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PROCESSCMD
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OECOMMAND
        /// </summary>
        [Display(Name = "OECommand", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.OeCommand, Id = Index.OeCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public OeCommand OeCommand { get; set; }

        /// <summary>
        /// Gets or sets OverCreditLimit
        /// </summary>
        [Display(Name = "OverCreditLimit", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.OverCreditLimit, Id = Index.OverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets ApprovedLimit
        /// </summary>
        [Display(Name = "ApprovedLimit", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ApprovedLimit, Id = Index.ApprovedLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ApprovedLimit { get; set; }

        /// <summary>
        /// Gets or sets AuthorizingUserID
        /// </summary>
        [Display(Name = "AuthorizingUserID", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AuthorizingUserID, Id = Index.AuthorizingUserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string AuthorizingUserID { get; set; }

        /// <summary>
        /// Gets or sets AuthorizingUserPassword
        /// </summary>
        [Display(Name = "AuthorizingUserPassword", ResourceType = typeof(OECommonResx))]
        [StringLength(64, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AuthorizingUserPassword, Id = Index.AuthorizingUserPassword, FieldType = EntityFieldType.Char, Size = 64)]
        public string AuthorizingUserPassword { get; set; }

        /// <summary>
        /// Gets or sets UserEnteredApprovalAmount
        /// </summary>
        [Display(Name = "UserEnteredApprovalAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.UserEnteredApprovalAmount, Id = Index.UserEnteredApprovalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UserEnteredApprovalAmount { get; set; }

        /// <summary>
        /// Gets or sets CheckingCustomerCreditLimit
        /// </summary>CheckingCustomerCreditLimit
        [Display(Name = "CheckingCustomerCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingCustomerCreditLimit, Id = Index.CheckingCustomerCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingCustomerCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingCustomerAgingLimit
        /// </summary>
        [Display(Name = "CheckingCustomerAgingLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingCustomerAgingLimit, Id = Index.CheckingCustomerAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingCustomerAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingNatAcctCreditLimit
        /// </summary>
        [Display(Name = "CheckingNatAcctCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingNatAcctCreditLimit, Id = Index.CheckingNatAcctCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingNatAcctCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingNatAcctAgingLimit
        /// </summary>
        [Display(Name = "CheckingNatAcctAgingLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingNatAcctAgingLimit, Id = Index.CheckingNatAcctAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingNatAcctAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerIsOverCreditLimit
        /// </summary>
        [Display(Name = "CustomerIsOverCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerIsOverCreditLimit, Id = Index.CustomerIsOverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerIsOverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerIsOverAgingLimit
        /// </summary>
        [Display(Name = "CustomerIsOverAgingLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerIsOverAgingLimit, Id = Index.CustomerIsOverAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerIsOverAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctIsOverCreditLimit
        /// </summary>
        [Display(Name = "NatAcctIsOverCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctIsOverCreditLimit, Id = Index.NatAcctIsOverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool NatAcctIsOverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctIsOverAgingLimit
        /// </summary>
        [Display(Name = "NatAcctIsOverAgingLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctIsOverAgingLimit, Id = Index.NatAcctIsOverAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool NatAcctIsOverAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerCreditLimit
        /// </summary>
        [Display(Name = "CustomerCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerCreditLimit, Id = Index.CustomerCreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerBalancePosted
        /// </summary>
        [Display(Name = "CustomerBalancePosted", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerBalancePosted, Id = Index.CustomerBalancePosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerBalancePosted { get; set; }

        /// <summary>
        /// Gets or sets CustomerDaysOverdue
        /// </summary>
        [Display(Name = "CustomerDaysOverdue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerDaysOverdue, Id = Index.CustomerDaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerDaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets CustomerOverdueLimit
        /// </summary>
        [Display(Name = "CustomerOverdueLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerOverdueLimit, Id = Index.CustomerOverdueLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerOverdueLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerBalanceOverdue
        /// </summary>
        [Display(Name = "CustomerBalanceOverdue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerBalanceOverdue, Id = Index.CustomerBalanceOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerBalanceOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctCreditLimit
        /// </summary>
        [Display(Name = "NatAcctCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctCreditLimit, Id = Index.NatAcctCreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctBalance
        /// </summary>
        [Display(Name = "NatAcctBalance", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctBalance, Id = Index.NatAcctBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctBalance { get; set; }

        /// <summary>
        /// Gets or sets NatAcctDaysOverdue
        /// </summary>
        [Display(Name = "NatAcctDaysOverdue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctDaysOverdue, Id = Index.NatAcctDaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int NatAcctDaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctOverdueLimit
        /// </summary>
        [Display(Name = "NatAcctOverdueLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctOverdueLimit, Id = Index.NatAcctOverdueLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctOverdueLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctBalanceOverdue
        /// </summary>
        [Display(Name = "NatAcctBalanceOverdue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctBalanceOverdue, Id = Index.NatAcctBalanceOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctBalanceOverdue { get; set; }

        /// <summary>
        /// Gets or sets ARPendingTransIncluded
        /// </summary>
        [Display(Name = "ARPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ARPendingTransIncluded, Id = Index.ARPendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ARPendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets OePendingTransIncluded
        /// </summary>
        [Display(Name = "OEPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        public bool OePendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets OtherPendingTransIncluded
        /// </summary>
        [Display(Name = "OtherPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OtherPendingTransIncluded, Id = Index.OtherPendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OtherPendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets ARPendingBalance
        /// </summary>
        [Display(Name = "ARPendingBalance", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ARPendingBalance, Id = Index.ARPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ARPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets OePendingBalance
        /// </summary>
        [Display(Name = "OEPendingBalance", ResourceType = typeof(OECommonResx))]
        public decimal OePendingBalance { get; set; }

        /// <summary>
        /// Gets or sets OtherPendingBalance
        /// </summary>
        [Display(Name = "OtherPendingBalance", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OtherPendingBalance, Id = Index.OtherPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OtherPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets CustomerTotalOutstanding
        /// </summary>
        [Display(Name = "CustomerTotalOutstanding", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerTotalOutstanding, Id = Index.CustomerTotalOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTotalOutstanding { get; set; }

        /// <summary>
        /// Gets or sets NatAcctTotalOutstanding
        /// </summary>
        [Display(Name = "NatAcctTotalOutstanding", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctTotalOutstanding, Id = Index.NatAcctTotalOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctTotalOutstanding { get; set; }

        /// <summary>
        /// Gets or sets CustomerLimitLeft
        /// </summary>
        [Display(Name = "CustomerLimitLeft", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerLimitLeft, Id = Index.CustomerLimitLeft, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerLimitLeft { get; set; }

        /// <summary>
        /// Gets or sets NatAcctLimitLeft
        /// </summary>
        [Display(Name = "NatAcctLimitLeft", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctLimitLeft, Id = Index.NatAcctLimitLeft, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctLimitLeft { get; set; }

        /// <summary>
        /// Gets or sets CustomerLimitExceeded
        /// </summary>
        [Display(Name = "CustomerLimitExceeded", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerLimitExceeded, Id = Index.CustomerLimitExceeded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerLimitExceeded { get; set; }

        /// <summary>
        /// Gets or sets NatAcctLimitExceeded
        /// </summary>
        [Display(Name = "NatAcctLimitExceeded", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NatAcctLimitExceeded, Id = Index.NatAcctLimitExceeded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctLimitExceeded { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceAmount
        /// </summary>
        [Display(Name = "LastInvoiceAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LastInvoiceAmount, Id = Index.LastInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceDate
        /// </summary>
        [Display(Name = "LastInvoiceDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastInvoiceDate, Id = Index.LastInvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets LastPaymentAmount
        /// </summary>
        [Display(Name = "LastPaymentAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LastPaymentAmount, Id = Index.LastPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets LastPaymentDate
        /// </summary>
        [Display(Name = "LastPaymentDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastPaymentDate, Id = Index.LastPaymentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPaymentDate { get; set; }

        /// <summary>
        /// Gets or sets DrivenbyUI
        /// </summary>
        [Display(Name = "DrivenbyUI", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DrivenbyUI, Id = Index.DrivenbyUI, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DrivenbyUI { get; set; }

        /// <summary>
        /// Gets or sets ItemDetailDiscountTotal
        /// </summary>
        [Display(Name = "ItemDetailDiscountTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ItemDetailDiscountTotal, Id = Index.ItemDetailDiscountTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ItemDetailDiscountTotal { get; set; }

        /// <summary>
        /// Gets or sets MiscChargeDetailDiscountTot
        /// </summary>
        [Display(Name = "MiscChargeDetailDiscountTot", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.MiscChargeDetailDiscountTot, Id = Index.MiscChargeDetailDiscountTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MiscChargeDetailDiscountTot { get; set; }

        /// <summary>
        /// Gets or sets DetailDiscountTotal
        /// </summary>
        [Display(Name = "DetailDiscountTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DetailDiscountTotal, Id = Index.DetailDiscountTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DetailDiscountTotal { get; set; }

        /// <summary>
        /// Gets or sets DetailDiscountPercentage
        /// </summary>
        [Display(Name = "DetailDiscountPercentage", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DetailDiscountPercentage, Id = Index.DetailDiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DetailDiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets DocumentNetOfDetailDisc
        /// </summary>
        [Display(Name = "DocumentNetOfDetailDisc", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DocumentNetOfDetailDisc, Id = Index.DocumentNetOfDetailDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentNetOfDetailDisc { get; set; }

        /// <summary>
        /// Gets or sets AutoCalcTaxReportingAmounts
        /// </summary>
        [Display(Name = "AutoCalcTaxReportingAmounts", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.AutoCalcTaxReportingAmounts, Id = Index.AutoCalcTaxReportingAmounts, FieldType = EntityFieldType.Int, Size = 2)]
        public int AutoCalcTaxReportingAmounts { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTrCurrency
        /// </summary>
        [Display(Name = "TaxReportingTRCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingTrCurrency, Id = Index.TaxReportingTrCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingTrCurrency { get; set; }

        /// <summary>
        /// Gets or sets TrRateType
        /// </summary>
        [Display(Name = "TRRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TrRateType, Id = Index.TrRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TrRateType { get; set; }

        /// <summary>
        /// Gets or sets TrRateDate
        /// </summary>
        [Display(Name = "TRRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TrRateDate, Id = Index.TrRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TrRateDate { get; set; }

        /// <summary>
        /// Gets or sets TrRate
        /// </summary>
        [Display(Name = "TRRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrRate, Id = Index.TrRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TrRate { get; set; }

        /// <summary>
        /// Gets or sets TrSpread
        /// </summary>
        [Display(Name = "TRSpread", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrSpread, Id = Index.TrSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TrSpread { get; set; }

        /// <summary>
        /// Gets or sets TrRateDateMatching
        /// </summary>
        [Display(Name = "TRRateDateMatching", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrRateDateMatching, Id = Index.TrRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int TrRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets TrRateOperator
        /// </summary>
        [Display(Name = "TRRateOperator", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrRateOperator, Id = Index.TrRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TrRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TrRateOverrideFlag
        /// </summary>
        [Display(Name = "TRRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrRateOverrideFlag, Id = Index.TrRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TrRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets TrExcludedTaxAmount1
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrExcludedTaxAmount1, Id = Index.TrExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TrExcludedTaxAmount2
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrExcludedTaxAmount2, Id = Index.TrExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TrExcludedTaxAmount3
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrExcludedTaxAmount3, Id = Index.TrExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TrExcludedTaxAmount4
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrExcludedTaxAmount4, Id = Index.TrExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TrExcludedTaxAmount5
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrExcludedTaxAmount5, Id = Index.TrExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TrIncludedTaxAmount1
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxAmount1, Id = Index.TrIncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TrIncludedTaxAmount2
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxAmount2, Id = Index.TrIncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TrIncludedTaxAmount3
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxAmount3, Id = Index.TrIncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TrIncludedTaxAmount4
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxAmount4, Id = Index.TrIncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TrIncludedTaxAmount5
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxAmount5, Id = Index.TrIncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TrTaxAmount1
        /// </summary>
        [Display(Name = "TRTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount1, Id = Index.TrTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TrTaxAmount2
        /// </summary>
        [Display(Name = "TRTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount2, Id = Index.TrTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TrTaxAmount3
        /// </summary>
        [Display(Name = "TRTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount3, Id = Index.TrTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TrTaxAmount4
        /// </summary>
        [Display(Name = "TRTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount4, Id = Index.TrTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TrTaxAmount5
        /// </summary>
        [Display(Name = "TRTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount5, Id = Index.TrTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TrExcludedTaxTotal
        /// </summary>
        [Display(Name = "TRExcludedTaxTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrExcludedTaxTotal, Id = Index.TrExcludedTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TrIncludedTaxTotal
        /// </summary>
        [Display(Name = "TRIncludedTaxTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxTotal, Id = Index.TrIncludedTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TrTaxTotal
        /// </summary>
        [Display(Name = "TRTaxTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxTotal, Id = Index.TrTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingInvoiceTrCurr
        /// </summary>
        [Display(Name = "TaxReportingInvoiceTRCurre", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingInvoiceTrCurr, Id = Index.TaxReportingInvoiceTrCurr, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingInvoiceTrCurr { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceRateType
        /// </summary>
        [Display(Name = "TRInvoiceRateType", ResourceType = typeof(OECommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TrInvoiceRateType, Id = Index.TrInvoiceRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TrInvoiceRateType { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceRateDate
        /// </summary>
        [Display(Name = "TRInvoiceRateDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TrInvoiceRateDate, Id = Index.TrInvoiceRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TrInvoiceRateDate { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceRate
        /// </summary>
        [Display(Name = "TRInvoiceRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceRate, Id = Index.TrInvoiceRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TrInvoiceRate { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceSpread
        /// </summary>
        [Display(Name = "TRInvoiceSpread", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceSpread, Id = Index.TrInvoiceSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TrInvoiceSpread { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceRateDateMatching
        /// </summary>
        [Display(Name = "TRInvoiceRateDateMatching", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceRateDateMatching, Id = Index.TrInvoiceRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int TrInvoiceRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceRateOperator
        /// </summary>
        [Display(Name = "TRInvoiceRateOperator", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceRateOperator, Id = Index.TrInvoiceRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TrInvoiceRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceRateOverrideFlag
        /// </summary>
        [Display(Name = "TRInvoiceRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceRateOverrideFlag, Id = Index.TrInvoiceRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TrInvoiceRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets TrCurrencyDescription
        /// </summary>
        [Display(Name = "TRCurrencyDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TrCurrencyDescription, Id = Index.TrCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TrCurrencyDescription { get; set; }


        /// <summary>
        /// Gets or sets TrInvoiceCurrencyDescription
        /// </summary>
        [Display(Name = "TRInvoiceCurrencyDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TrInvoiceCurrencyDescription, Id = Index.TrInvoiceCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TrInvoiceCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TrRateTypeDescription
        /// </summary>
        [Display(Name = "TRRateTypeDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TrRateTypeDescription, Id = Index.TrRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TrRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceRateTypeDescription
        /// </summary>
        [Display(Name = "TRInvoiceRateTypeDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TrInvoiceRateTypeDescription, Id = Index.TrInvoiceRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TrInvoiceRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxVersion
        /// </summary>
        [Display(Name = "TaxVersion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxVersion, Id = Index.TaxVersion, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxVersion { get; set; }

        /// <summary>
        /// Gets or sets CnDnDiscountAmountOverride
        /// </summary>
        [Display(Name = "CNDNDiscountAmountOverride", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CnDnDiscountAmountOverride, Id = Index.CnDnDiscountAmountOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CnDnDiscountAmountOverride { get; set; }

        /// <summary>
        /// Gets or sets DOSConversion
        /// </summary>
        [Display(Name = "DOSConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DosConversion, Id = Index.DosConversion, FieldType = EntityFieldType.Bool, Size = 2)]
        public DosConvert DosConversion { get; set; }

        /// <summary>
        /// Gets or sets FromInvoice
        /// </summary>
        [Display(Name = "FromInvoice", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FromInvoice, Id = Index.FromInvoice, FieldType = EntityFieldType.Bool, Size = 2)]
        public FromInvoice FromInvoice { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowedType JobRelated { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedDetailLines
        /// </summary>
        [Display(Name = "JobRelatedDetailLines", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.JobRelatedDetailLines, Id = Index.JobRelatedDetailLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedDetailLines { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasRetainage HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainagePercent
        /// </summary>
        [Display(Name = "RetainagePercent", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainagePercent, Id = Index.RetainagePercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal RetainagePercent { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate
        /// </summary>
        [Display(Name = "RetainageExchangeRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1
        /// </summary>
        [Display(Name = "RetainageTaxBase1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2
        /// </summary>
        [Display(Name = "RetainageTaxBase2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3
        /// </summary>   
        [Display(Name = "RetainageTaxBase3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4
        /// </summary>
        [Display(Name = "RetainageTaxBase4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5
        /// </summary>
        [Display(Name = "RetainageTaxBase5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount1, Id = Index.RetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount2, Id = Index.RetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount3, Id = Index.RetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount4, Id = Index.RetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount5, Id = Index.RetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets CustomerAccountSet
        /// </summary>
        [Display(Name = "CustomerAccountSet", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerAccountSet, Id = Index.CustomerAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CustomerAccountSet { get; set; }

        /// <summary>
        /// Gets or sets CustomerAccountSetDescription
        /// </summary>
        [Display(Name = "CustomerAccountSetDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerAccountSetDescription, Id = Index.CustomerAccountSetDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerAccountSetDescription { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [Display(Name = "EnteredBy", ResourceType = typeof(OECommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        [IgnoreExportImport]
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        [IgnoreExportImport]
        public short SessionWarnDays { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets DATEBUS
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateBus", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateBus, Id = Index.DateBus, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateBus { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteAmountDue
        /// </summary>
        [Display(Name = "CreditDebitNoteAmountDue", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteAmountDue, Id = Index.CreditDebitNoteAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditDebitNoteAmountDue { get; set; }

        /// <summary>
        /// Gets or sets TotalRetainageTaxAmount
        /// </summary>
        [Display(Name = "TotalRetainageTaxAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TotalRetainageTaxAmount, Id = Index.TotalRetainageTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRetainageTaxAmount { get; set; }


        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitKittingDetail> CreditDebitKittingDetails { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitKittingSerialNo> CreditDebitKittingSerialNos { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitKittingDetailLot> CreditDebitKittingDetailsLot { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitBomDetail> CreditDebitBomDetails { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitDetail> CreditDebitDetails { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitNoteOptionalField> CreditDebitNoteOptionalFields { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitDetailOptionalField> CreditDebitDetailOptionalFields { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitTaxDetail> CreditDebitTaxDetails { get; set; }

        [IgnoreExportImport]
        public PreCreditCheckStatus PreCreditCheckStatus { get; set; }
   
        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitDetailLotNumber> CreditDebitDetailsLotNumber { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitDetailSerialNo> CreditDebitDetailSerialNos { get; set; }

        #region Properties for finder
        /// <summary>
        /// Gets the Customer Discount Level string.
        /// </summary>
        public string CustomerDiscountLevelString
        {
            get { return EnumUtility.GetStringValue(CustomerDiscountLevel); }
        }

        /// <summary>
        /// Gets the Has Retainage string.
        /// </summary>
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Gets the Credit/Debit Note Fiscal Period string.
        /// </summary>
        public string CreditDebitNoteFiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(CreditDebitNoteFiscalPeriod); }
        }

        /// <summary>
        /// Gets the Credit/Debit Note Status string.
        /// </summary>
        public string CreditDebitNoteStatusString
        {
            get { return EnumUtility.GetStringValue(CreditDebitNoteStatus); }
        }

        /// <summary>
        /// Gets the Credit/Debit Note Printed string.
        /// </summary>
        public string CreditDebitNotePrintedString
        {
            get { return EnumUtility.GetStringValue(CreditDebitNotePrinted); }
        }

        /// <summary>
        /// Gets the Type String.
        /// </summary>
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets the Process Command string.
        /// </summary>
        public string ProcessCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// Gets the Oe Command string.
        /// </summary>
        public string OeCommandString
        {
            get { return EnumUtility.GetStringValue(OeCommand); }
        }

        /// <summary>
        /// Gets the Dos Conversion string.
        /// </summary>
        public string DosConversionString
        {
            get { return EnumUtility.GetStringValue(DosConversion); }
        }

        /// <summary>
        /// Gets the From Invoice string.
        /// </summary>
        public string FromInvoiceString
        {
            get { return EnumUtility.GetStringValue(FromInvoice); }
        }

        ///// <summary>
        ///// Gets the Job Related string.
        ///// </summary>
        //public string JobRelatedString
        //{
        //    get { return EnumUtility.GetStringValue(JobRelated); }
        //}

        /// <summary>
        /// Gets the Retainage Exchange Rate string.
        /// </summary>
        public string RetainageExchangeRateString
        {
            get { return EnumUtility.GetStringValue(RetainageExchangeRate); }
        }
        #endregion

        /// <summary>
        /// Gets or sets Is New Record
        /// </summary>
        [IgnoreExportImport]
        public bool IsNewRecord { get; set; }

        /// <summary>
        /// Optional field Tab loaded flag
        /// </summary>
        [IgnoreExportImport]
        public bool IsOptinalFieldLoaded { get; set; }

        [IgnoreExportImport]
        public CommentsInstructionsType CommentsInstructionsType { get; set; }

        /// <summary>
        /// Property for Format Phone Number Value 
        /// </summary>
        [IgnoreExportImport]
        public bool FormatPhoneNumberValue { get; set; }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "InvoiceRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        public string InvoiceRateOverrideFlagString
        {
            get
            {
                if (InvoiceRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "RecalculateTax", ResourceType = typeof(OECommonResx))]
        public string RecalculateTaxString
        {
            get
            {
                if (RecalculateTax)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "TaxOverridden", ResourceType = typeof(OECommonResx))]
        public string TaxOverriddenString
        {
            get
            {
                if (TaxOverridden)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "OverCreditLimit", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public string OverCreditLimitString
        {
            get
            {
                if (OverCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "PerformTaxCalculation", ResourceType = typeof(OECommonResx))]
        public string PerformTaxCalculationString
        {
            get
            {
                if (PerformTaxCalculation)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "PerformForcedTaxCalculation", ResourceType = typeof(OECommonResx))]
        public string PerformForcedTaxCalculationString
        {
            get
            {
                if (PerformForcedTaxCalculation)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "PerformDistributionOfManTax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public string PerformDistributionOfManTaxString
        {
            get
            {
                if (PerformDistributionOfManTax)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "TaxCalculationInProgress", ResourceType = typeof(OECommonResx))]
        public string TaxCalculationInProgressString
        {
            get
            {
                if (TaxCalculationInProgress)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "AutoTaxCalculationStatus", ResourceType = typeof(OECommonResx))]
        public string AutoTaxCalculationStatusString
        {
            get
            {
                if (AutoTaxCalculationStatus)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CustomerExists", ResourceType = typeof(OECommonResx))]
        public string CustomerExistsString
        {
            get
            {
                if (CustomerExists)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "InvoiceExists", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public string InvoiceExistsString
        {
            get
            {
                if (InvoiceExists)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CheckingCustomerCreditLimit", ResourceType = typeof(OECommonResx))]
        public string CheckingCustomerCreditLimitString
        {
            get
            {
                if (CheckingCustomerCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CheckingCustomerAgingLimit", ResourceType = typeof(OECommonResx))]
        public string CheckingCustomerAgingLimitString
        {
            get
            {
                if (CheckingCustomerAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CheckingNatAcctCreditLimit", ResourceType = typeof(OECommonResx))]
        public string CheckingNatAcctCreditLimitString
        {
            get
            {
                if (CheckingNatAcctCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CheckingNatAcctAgingLimit", ResourceType = typeof(OECommonResx))]
        public string CheckingNatAcctAgingLimitString
        {
            get
            {
                if (CheckingNatAcctAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CustomerIsOverCreditLimit", ResourceType = typeof(OECommonResx))]
        public string CustomerIsOverCreditLimitString
        {
            get
            {
                if (CustomerIsOverCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CustomerIsOverAgingLimit", ResourceType = typeof(OECommonResx))]
        public string CustomerIsOverAgingLimitString
        {
            get
            {
                if (CustomerIsOverAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "NatAcctIsOverCreditLimit", ResourceType = typeof(OECommonResx))]
        public string NatAcctIsOverCreditLimitString
        {
            get
            {
                if (NatAcctIsOverCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "NatAcctIsOverAgingLimit", ResourceType = typeof(OECommonResx))]
        public string NatAcctIsOverAgingLimitString
        {
            get
            {
                if (NatAcctIsOverAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ARPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        public string ARPendingTransIncludedString
        {
            get
            {
                if (ARPendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "OEPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        public string OEPendingTransIncludedString
        {
            get
            {
                if (OePendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "OtherPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        public string OtherPendingTransIncludedString
        {
            get
            {
                if (OtherPendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "DrivenbyUI", ResourceType = typeof(OECommonResx))]
        public string DrivenbyUIString
        {
            get
            {
                if (DrivenbyUI)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "TrInvoiceRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        public string TrInvoiceRateOverrideFlagString
        {
            get
            {
                if (TrInvoiceRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CnDnDiscountAmountOverride", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public string CnDnDiscountAmountOverrideString
        {
            get
            {
                if (CnDnDiscountAmountOverride)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(OECommonResx))]
        public string JobRelatedString
        {
            get
            {
                return EnumUtility.GetStringValue(JobRelated);
            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CnDnDiscountonMiscCharges", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public string CnDnDiscountonMiscChargesString
        {
            get
            {
                if (CnDnDiscountonMiscCharges)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "CnDnRateOverrideFlag", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public string CnDnRateOverrideFlagString
        {
            get
            {
                if (CnDnRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        /// <summary>
        /// Gets or sets FunctionalCreditDebitNoteTotal. This property is used in AR-Customer Inquiry screen. This will hold the equivalent value of Credit Debit Note total for function currency.
        /// </summary>
        [IgnoreExportImport]
        public decimal FunctionalCreditDebitNoteTotal
        {
            get
            {
                if (CreditDebitNoteRate != 0)
                {
                    if (CreditDebitNoteRateOperator == 1)
                    {
                        return CreditDebitNoteTotal * CreditDebitNoteRate;
                    }
                    return CreditDebitNoteTotal / CreditDebitNoteRate;
                }
                return CreditDebitNoteTotal;

            }
        }
    }


}
