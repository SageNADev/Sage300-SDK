// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Partial class for OrderPreAuthorization
	/// </summary>
	public partial class OrderPreAuthorization : ModelBase
	{
		/// <summary>
		/// Gets or sets OrderUniquifier
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "OrderUniquifier", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal OrderUniquifier { get; set; }

		/// <summary>
		/// Gets or sets Customer
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Customer", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.Customer, Id = Index.Customer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string Customer { get; set; }

		/// <summary>
		/// Gets or sets PreauthTransactionID
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PreauthTransactionID", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.PreauthTransactionID, Id = Index.PreauthTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
		public string PreauthTransactionID { get; set; }

		/// <summary>
		/// Gets or sets CaptureTransactionID
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "CaptureTransactionID", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.CaptureTransactionID, Id = Index.CaptureTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
		public string CaptureTransactionID { get; set; }

		/// <summary>
		/// Gets or sets VoidTransactionID
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
	    [Display(Name = "VoidTransactionID", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.VoidTransactionID, Id = Index.VoidTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
		public string VoidTransactionID { get; set; }

		/// <summary>
		/// Gets or sets TransactionStatus
		/// </summary>
        [Display(Name = "TransactionStatus", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.TransactionStatus, Id = Index.TransactionStatus, FieldType = EntityFieldType.Int, Size = 2)]
		public TransactionStatus TransactionStatus { get; set; }

		/// <summary>
		/// Gets or sets YpProcessCode
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "YPProcessCode", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.YpProcessCode, Id = Index.YpProcessCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string YpProcessCode { get; set; }

		/// <summary>
		/// Gets or sets BankCode
		/// </summary>
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "BankCode", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
		public string BankCode { get; set; }

		/// <summary>
		/// Gets or sets PaymentCode
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "PaymentCode", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string PaymentCode { get; set; }

		/// <summary>
		/// Gets or sets PaymentType
		/// </summary>
		[Display(Name = "PaymentType", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
		public int PaymentType { get; set; }

		/// <summary>
		/// Gets or sets PreAuthAmountCurrency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "PreauthCurrency", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.PreAuthAmountCurrency, Id = Index.PreAuthAmountCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string PreAuthAmountCurrency { get; set; }

		/// <summary>
		/// Gets or sets SourceCurrency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		//[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.SourceCurrency, Id = Index.SourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string SourceCurrency { get; set; }

		/// <summary>
		/// Gets or sets RateType
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "RateType", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string RateType { get; set; }

		/// <summary>
		/// Gets or sets RateDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "RateDate", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime RateDate { get; set; }

		/// <summary>
		/// Gets or sets ExchangeRate
		/// </summary>
		//[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal ExchangeRate { get; set; }

		/// <summary>
		/// Gets or sets RateSpread
		/// </summary>
		//[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal RateSpread { get; set; }

		/// <summary>
		/// Gets or sets RateDateMatching
		/// </summary>
		//[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.RateDateMatching, Id = Index.RateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
		public int RateDateMatching { get; set; }

		/// <summary>
		/// Gets or sets RateOperator
		/// </summary>
		//[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
		public int RateOperator { get; set; }

		/// <summary>
		/// Gets or sets RateOverrideFalg
		/// </summary>
		//[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.RateOverrideFalg, Id = Index.RateOverrideFalg, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool RateOverrideFalg { get; set; }

		/// <summary>
		/// Gets or sets OrderPosted
		/// </summary>
		[Display(Name = "Posted", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.OrderPosted, Id = Index.OrderPosted, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool OrderPosted { get; set; }

		/// <summary>
		/// Gets or sets PreAuthAmount
		/// </summary>
	    [Display(Name = "PreAuthAmount", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PreAuthAmount, Id = Index.PreAuthAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal PreAuthAmount { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets TransactionStatus string value
		/// </summary>
		public string TransactionStatusString
		{
			get { return EnumUtility.GetStringValue(TransactionStatus); }
		}

		#endregion
	}
}
