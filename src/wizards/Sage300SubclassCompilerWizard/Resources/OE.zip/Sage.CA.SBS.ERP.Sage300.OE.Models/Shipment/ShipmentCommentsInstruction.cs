// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for ShipmentCommentsInstruction
    /// </summary>
    public partial class ShipmentCommentsInstruction : ModelBase
    {
        /// <summary>
        /// Gets or sets ShipmentUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentUniquifier", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipmentUniquifier, Id = Index.ShipmentUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ShipmentUniquifier { get; set; }

        /// <summary>
        /// Gets or sets Uniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Uniquifier", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Uniquifier, Id = Index.Uniquifier, FieldType = EntityFieldType.Int, Size = 2)]
        public int Uniquifier { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets CommentsInstructionsType
        /// </summary>
        [Display(Name = "CommentsInstructionsType", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.CommentsInstructionsType, Id = Index.CommentsInstructionsType, FieldType = EntityFieldType.Int, Size = 2)]
        public CommentsInstructionsType CommentsInstructionsType { get; set; }

        /// <summary>
        /// Gets or sets CommentsInstructions
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommentsInstructions", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.CommentsInstructions, Id = Index.CommentsInstructions, FieldType = EntityFieldType.Char, Size = 80)]
        public string CommentsInstructions { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets CommentsInstructionsType string value
        /// </summary>
        [IgnoreExportImport]
        public string CommentsInstructionsTypeString
        {
            get { return EnumUtility.GetStringValue(CommentsInstructionsType); }
        }

        #endregion
    }
}
