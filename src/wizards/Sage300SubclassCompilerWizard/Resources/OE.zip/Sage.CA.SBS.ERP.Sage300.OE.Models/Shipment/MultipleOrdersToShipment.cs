// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for MultipleOrdersToShipment
    /// </summary>
    public partial class MultipleOrdersToShipment : ModelBase
    {
        /// <summary>
        /// Gets or sets ShipmentUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentUniquifier", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipmentUniquifier, Id = Index.ShipmentUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ShipmentUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderUniquifier
        /// </summary>
        [Display(Name = "OrderUniquifier", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal OrderUniquifier { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PONumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string PONumber { get; set; }

        #region UI Strings

        #endregion
    }
}
