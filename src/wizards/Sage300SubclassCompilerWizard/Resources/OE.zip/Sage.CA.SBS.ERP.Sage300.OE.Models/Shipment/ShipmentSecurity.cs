// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved.

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Shipment Entry security Class.
    /// </summary>
    public class ShipmentSecurity
    {
        #region Properties Added for Security

        /// <summary>
        /// Gets or sets HasInquiryRightsOeshhd
        /// </summary>
        [IgnoreExportImport]
        public bool HasOEUpdateRights { get; set; }

        /// <summary>
        /// Gets or sets HasOEImportRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasOEImportRights { get; set; }

        /// <summary>
        /// Gets or sets HasOEExportRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasOEExportRights { get; set; }

        /// <summary>
        /// Gets or sets HasInquiryRightsOeshhd
        /// </summary>
        [IgnoreExportImport]
        public bool HasInquiryRightsSeshhd { get; set; }

        /// <summary>
        /// Gets or sets bCanAddARCustomer
        /// </summary>
        [IgnoreExportImport]
        public bool CanAddARCustomer { get; set; }

        /// <summary>
        /// Gets or sets HasOnHoldRemovalRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasOnHoldRemovalRights { get; set; }

        /// <summary>
        /// Gets or sets HasAddModifyRightsArbta
        /// </summary>
        [IgnoreExportImport]
        public bool HasAddModifyRightsArbta { get; set; }
        /// <summary>
        /// Gets or sets CanPrintTransList
        /// </summary>
        [IgnoreExportImport]
        public bool CanPrintTransList { get; set; }

        /// <summary>
        /// Gets or sets HasShipmentRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasShipmentRights { get; set; }

        /// <summary>
        /// Gets or sets HasInvoiceRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasInvoiceRights { get; set; }

        /// <summary>
        /// Gets or sets HasOFTransRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasOFTransRights { get; set; }

        /// <summary>
        /// Gets or sets HasYPTransactionRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasYPTransactionRights { get; set; }

        /// <summary>
        /// Gets or sets HasPOCreateRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasPOCreateRights { get; set; }

        /// <summary>
        /// Gets or sets HasPrintOrder
        /// </summary>
        [IgnoreExportImport]
        public bool HasPrintOrder { get; set; }

        /// <summary>
        /// Gets or sets HasPrintPickingSlip
        /// </summary>
        [IgnoreExportImport]
        public bool HasPrintPickingSlip { get; set; }

        /// <summary>
        /// Gets or sets HasPrintInvoice
        /// </summary>
        [IgnoreExportImport]
        public bool HasPrintInvoice { get; set; }

        /// <summary>
        /// Gets or sets HasQuotesPrintRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasQuotesPrintRights { get; set; }


        /// <summary>
        /// Gets or sets HasItemCostInquiryRight
        /// </summary>
        [IgnoreExportImport]
        public bool HasItemCostInquiryRight { get; set; }

        /// <summary>
        /// Gets or sets Optional Field active (whether or not we have an optional fields 
        /// license)
        /// </summary>
        [IgnoreExportImport]
        public bool OptionalFieldActive { get; set; }

        /// <summary>
        /// Gets or sets PriceCheckApproval right
        /// license)
        /// </summary>
        [IgnoreExportImport]
        public bool PriceCheckApproval { get; set; }

        /// <summary>
        /// Gets or sets HasICLocationDocumentRights
        /// license)
        /// </summary>
        [IgnoreExportImport]
        public bool HasICLocationDocumentRights { get; set; }
        
        #endregion
    }
}
