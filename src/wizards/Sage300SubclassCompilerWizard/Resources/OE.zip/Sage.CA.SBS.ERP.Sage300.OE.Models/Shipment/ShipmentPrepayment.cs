// Copyright © 2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.ShipmentPrepayment
{
    /// <summary>
    /// Partial class for Shipment Prepayment
    /// </summary>
    public partial class Prepayment : ModelBase
    {
        /// <summary>
        /// True if prepayment exists; otherwise false
        /// </summary>
        public bool PrepaymentExists { get; set; }

        /// <summary>
        /// True if pre-authorization exists; otherwise false
        /// </summary>
        public bool PreAuthorizationExists { get; set; }

        /// <summary>
        /// Gets or sets ShipmentUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentUniquifier", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipmentUniquifier, Id = Index.ShipmentUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ShipmentUniquifier { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerCurrency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustomerCurrency { get; set; }

        /// <summary>
        /// Gets or sets CustRate
        /// </summary>
        [Display(Name = "CustRate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustRate, Id = Index.CustRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CustRate { get; set; }

        /// <summary>
        /// Gets or sets CustRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustRateDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustRateDate, Id = Index.CustRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CustRateDate { get; set; }

        /// <summary>
        /// Gets or sets CustRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustRateType", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustRateType, Id = Index.CustRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CustRateType { get; set; }

        /// <summary>
        /// Gets or sets OperCustCurnToFunc
        /// </summary>
        [Display(Name = "OperCustCurnToFunc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OperCustCurnToFunc, Id = Index.OperCustCurnToFunc, FieldType = EntityFieldType.Int, Size = 2)]
        public int OperCustCurnToFunc { get; set; }

        /// <summary>
        /// Gets or sets DocumentTotal
        /// </summary>
        [Display(Name = "DocumentTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DocumentTotal, Id = Index.DocumentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentTotal { get; set; }

        /// <summary>
        /// Gets or sets DiscountAvailable
        /// </summary>
        [Display(Name = "DiscountAvailable", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DiscountAvailable, Id = Index.DiscountAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAvailable { get; set; }

        /// <summary>
        /// Gets or sets AmountDue
        /// </summary>
        [Display(Name = "AmountDue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.AmountDue, Id = Index.AmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDue { get; set; }

        /// <summary>
        /// Gets or sets ReceiptBatchNumber
        /// </summary>
        [Display(Name = "ReceiptBatchNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ReceiptBatchNumber, Id = Index.ReceiptBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal ReceiptBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets BankCode
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets ReceiptType
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ReceiptType, Id = Index.ReceiptType, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ReceiptType { get; set; }

        /// <summary>
        /// Gets or sets CheckReceiptNo
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckReceiptNo", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckReceiptNo, Id = Index.CheckReceiptNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string CheckReceiptNo { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ReceiptDate, Id = Index.ReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReceiptDate { get; set; }

        /// <summary>
        /// Gets or sets ReceiptAmount
        /// </summary>
        [Display(Name = "ReceiptAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ReceiptAmount, Id = Index.ReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets BankCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCurrency", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BankCurrency, Id = Index.BankCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BankCurrency { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets BankRate
        /// </summary>
        [Display(Name = "BankRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.BankRate, Id = Index.BankRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BankRate { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets PaymentType
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets PreauthCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PreauthCurrency", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PreauthCurrency, Id = Index.PreauthCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string PreauthCurrency { get; set; }

        /// <summary>
        /// Gets or sets PreauthTransactionID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PreauthTransactionID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PreauthTransactionID, Id = Index.PreauthTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
        public string PreauthTransactionID { get; set; }

        /// <summary>
        /// Gets or sets CaptureTransactionID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CaptureTransactionID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CaptureTransactionID, Id = Index.CaptureTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
        public string CaptureTransactionID { get; set; }

        /// <summary>
        /// Gets or sets VoidTransactionID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VoidTransactionID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.VoidTransactionID, Id = Index.VoidTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
        public string VoidTransactionID { get; set; }

        /// <summary>
        /// Gets or sets PreauthAmount
        /// </summary>
        [Display(Name = "PreAuthAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PreauthAmount, Id = Index.PreauthAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PreauthAmount { get; set; }

        /// <summary>
        /// Gets or sets CreditCardChargeStatus
        /// </summary>
        [Display(Name = "CreditCardChargeStatus", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CreditCardChargeStatus, Id = Index.CreditCardChargeStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public CreditCardChargeStatus CreditCardChargeStatus { get; set; }

        /// <summary>
        /// Gets or sets YPProcessCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "YPProcessCode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.YPProcessCode, Id = Index.YPProcessCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string YPProcessCode { get; set; }

        /// <summary>
        /// Gets or sets BatchDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BatchDescription, Id = Index.BatchDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string BatchDescription { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ReceiptDescription, Id = Index.ReceiptDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReceiptDescription { get; set; }

        /// <summary>
        /// Gets or sets BankRateSpread
        /// </summary>
        [Display(Name = "BankRateSpread", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BankRateSpread, Id = Index.BankRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BankRateSpread { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentID
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PrepaymentID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PrepaymentID, Id = Index.PrepaymentID, FieldType = EntityFieldType.Char, Size = 22)]
        public string PrepaymentID { get; set; }

        /// <summary>
        /// Gets or sets ICDayEndTransNumber
        /// </summary>
        [Display(Name = "ICDayEndTransNumber", ResourceType = typeof(ShipmentEntryResx))]
        [ViewField(Name = Fields.ICDayEndTransNumber, Id = Index.ICDayEndTransNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ICDayEndTransNumber { get; set; }

        /// <summary>
        /// Gets or sets CapturePreauthorization
        /// </summary>
        [Display(Name = "CapturePreauthorization", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CapturePreauthorization, Id = Index.CapturePreauthorization, FieldType = EntityFieldType.Bool, Size = 2)]
        public CapturePreauthorization CapturePreauthorization { get; set; }

        /// <summary>
        /// Gets or sets OrderUniquifier
        /// </summary>
        [Display(Name = "OrderUniquifier", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal OrderUniquifier { get; set; }

        ///// <summary>
        ///// Gets or sets ProcessOnPut
        ///// </summary>
        //[Display(Name = "ProcessOnPut", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.ProcessOnPut, Id = Index.ProcessOnPut, FieldType = EntityFieldType.Int, Size = 2)]
        //public ProcessOnPut ProcessOnPut { get; set; }

        ///// <summary>
        ///// Gets or sets TransactionID
        ///// </summary>
        //[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "TransactionID", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.TransactionID, Id = Index.TransactionID, FieldType = EntityFieldType.Char, Size = 36)]
        //public string TransactionID { get; set; }

        ///// <summary>
        ///// Gets or sets XMLString
        ///// </summary>
        //[StringLength(20000, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "XMLString", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.XMLString, Id = Index.XMLString, FieldType = EntityFieldType.Char, Size = 20000)]
        //public string XMLString { get; set; }

        ///// <summary>
        ///// Gets or sets ResponseIndicator
        ///// </summary>
        //[StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "ResponseIndicator", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.ResponseIndicator, Id = Index.ResponseIndicator, FieldType = EntityFieldType.Char, Size = 1)]
        //public string ResponseIndicator { get; set; }

        ///// <summary>
        ///// Gets or sets ResponseCode
        ///// </summary>
        //[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "ResponseCode", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.ResponseCode, Id = Index.ResponseCode, FieldType = EntityFieldType.Char, Size = 6)]
        //public string ResponseCode { get; set; }

        ///// <summary>
        ///// Gets or sets ResponseMessage
        ///// </summary>
        //[StringLength(32, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "ResponseMessage", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.ResponseMessage, Id = Index.ResponseMessage, FieldType = EntityFieldType.Char, Size = 32)]
        //public string ResponseMessage { get; set; }

        ///// <summary>
        ///// Gets or sets AuthorizationCode
        ///// </summary>
        //[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "AuthorizationCode", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.AuthorizationCode, Id = Index.AuthorizationCode, FieldType = EntityFieldType.Char, Size = 6)]
        //public string AuthorizationCode { get; set; }

        ///// <summary>
        ///// Gets or sets AVSResult
        ///// </summary>
        //[StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "AVSResult", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.AVSResult, Id = Index.AVSResult, FieldType = EntityFieldType.Char, Size = 1)]
        //public string AVSResult { get; set; }

        ///// <summary>
        ///// Gets or sets CVVResult
        ///// </summary>
        //[StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "CVVResult", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.CVVResult, Id = Index.CVVResult, FieldType = EntityFieldType.Char, Size = 1)]
        //public string CVVResult { get; set; }

        ///// <summary>
        ///// Gets or sets TransactionDate
        ///// </summary>
        //[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "TransactionDate", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Char, Size = 22)]
        //public string TransactionDate { get; set; }

        ///// <summary>
        ///// Gets or sets VANReference
        ///// </summary>
        //[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "VANReference", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.VANReference, Id = Index.VANReference, FieldType = EntityFieldType.Char, Size = 16)]
        //public string VANReference { get; set; }

        ///// <summary>
        ///// Gets or sets Last4
        ///// </summary>
        //[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Last4", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.Last4, Id = Index.Last4, FieldType = EntityFieldType.Char, Size = 16)]
        //public string Last4 { get; set; }

        ///// <summary>
        ///// Gets or sets PaymentDescription
        ///// </summary>
        //[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "PaymentDescription", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.PaymentDescription, Id = Index.PaymentDescription, FieldType = EntityFieldType.Char, Size = 30)]
        //public string PaymentDescription { get; set; }

        ///// <summary>
        ///// Gets or sets PaymentTypeID
        ///// </summary>
        //[StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "PaymentTypeID", ResourceType = typeof (ShipmentPrepaymentResx))]
        //[ViewField(Name = Fields.PaymentTypeID, Id = Index.PaymentTypeID, FieldType = EntityFieldType.Char, Size = 1)]
        //public string PaymentTypeID { get; set; }

    }
}
