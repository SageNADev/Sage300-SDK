// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Partial class for InvoiceOptionalField
     /// </summary>
     public partial class InvoiceOptionalField : ModelBase
     {
          /// <summary>
          /// Gets or sets InvoiceUniquifier
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "InvoiceUniquifier", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal InvoiceUniquifier { get; set; }

          /// <summary>
          /// Gets or sets OptionalField
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "OptionalField", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string OptionalField { get; set; }

          /// <summary>
          /// Gets or sets Value
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Value", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
          public string Value { get; set; }

          /// <summary>
          /// Gets or sets Type
          /// </summary>
          [Display(Name = "Type", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
          public Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Type Type { get; set; }

          /// <summary>
          /// Gets or sets Length
          /// </summary>
          [Display(Name = "Length", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
          public int Length { get; set; }

          /// <summary>
          /// Gets or sets Decimals
          /// </summary>
          [Display(Name = "Decimals", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
          public int Decimals { get; set; }

          /// <summary>
          /// Gets or sets AllowBlank
          /// </summary>
          [Display(Name = "AllowBlank", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
          public AllowBlank AllowBlank { get; set; }

          /// <summary>
          /// Gets or sets Validate
          /// </summary>
          [Display(Name = "Validate", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
          public Validate Validate { get; set; }

          /// <summary>
          /// Gets or sets ValueSet
          /// </summary>
          [Display(Name = "ValueSet", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
          public ValueSet ValueSet { get; set; }

          /// <summary>
          /// Gets or sets TypedValueFieldIndex
          /// </summary>
          [Display(Name = "TypedValueFieldIndex", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
          public long TypedValueFieldIndex { get; set; }

          /// <summary>
          /// Gets or sets TextValue
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "TextValue", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
          public string TextValue { get; set; }

          /// <summary>
          /// Gets or sets AmountValue
          /// </summary>
          [Display(Name = "AmountValue", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal AmountValue { get; set; }

          /// <summary>
          /// Gets or sets NumberValue
          /// </summary>
          [Display(Name = "NumberValue", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal NumberValue { get; set; }

          /// <summary>
          /// Gets or sets IntegerValue
          /// </summary>
          [Display(Name = "IntegerValue", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
          public long IntegerValue { get; set; }

          /// <summary>
          /// Gets or sets YesNoValue
          /// </summary>
          [Display(Name = "YesOrNoValue", ResourceType = typeof(OECommonResx))]
          public YesNoValue YesOrNoValue { get; set; }

          /// <summary>
          /// Gets or sets DateValue
          /// </summary>
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "DateValue", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime? DateValue { get; set; }

          /// <summary>
          /// Gets or sets TimeValue
          /// </summary>
          [Display(Name = "TimeValue", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
          public DateTime TimeValue { get; set; }

          /// <summary>
          /// Gets or sets OptionalFieldDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "OptionalFieldDescription", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string OptionalFieldDescription { get; set; }

          /// <summary>
          /// Gets or sets ValueDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ValueDescription", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string ValueDescription { get; set; }

          /// <summary>
          /// Gets or sets the sequential line number for the optional fields items
          /// </summary>
          [IgnoreExportImport]
          public long SerialNumber { get; set; }

     }
}
