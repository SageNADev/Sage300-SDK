// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for OrderDetail
    /// </summary>

    public partial class OrderDetail : ModelBase
    {
        public OrderDetail()
        {
            OrderDetailOptionalFields = new EnumerableResponse<OrderDetailOptionalField> { Items = new List<OrderDetailOptionalField>() };
            OrderBOMDetails = new EnumerableResponse<OrderBOMDetail> { Items = new List<OrderBOMDetail>() };
            OrderDetailSerialNumbers = new EnumerableResponse<OrderDetailSerialNumber> { Items = new List<OrderDetailSerialNumber>() };
            OrderDetailLotNumbers = new EnumerableResponse<OrderDetailLotNumber> { Items = new List<OrderDetailLotNumber>() };
            commentInstructions = new EnumerableResponse<OrderComment> { Items = new List<OrderComment>() };

            Attributes = new Dictionary<string, object>();
        }

        /// <summary>
        /// Get or Set Attributes
        /// </summary>
        [IgnoreExportImport]
        public IDictionary<string, object> Attributes { get; set; }

        /// <summary>
        /// Gets or sets OrderUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderUniquifier", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal OrderUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets SequenceNo
        /// </summary>
        [IgnoreExportImport]
        public int SequenceNo { get; set; }

        /// <summary>
        /// Gets or sets LineType
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
        public LineType LineType { get; set; }

        /// <summary>
        /// Gets or sets Item
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Item", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Item, Id = Index.Item, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string Item { get; set; }

        /// <summary>
        /// Gets or sets MiscellaneousChargesCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscellaneousChargesCode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.MiscellaneousChargesCode, Id = Index.MiscellaneousChargesCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string MiscellaneousChargesCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ItemAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemAccountSet", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ItemAccountSet, Id = Index.ItemAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ItemAccountSet { get; set; }

        /// <summary>
        /// Gets or sets UserSpecifiedCostingMethod
        /// </summary>
        [Display(Name = "UserSpecifiedCostingMethod", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.UserSpecifiedCostingMethod, Id = Index.UserSpecifiedCostingMethod, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UserSpecifiedCostingMethod { get; set; }

        /// <summary>
        /// Gets or sets PriceList
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceList", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceList { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets PickingSequence
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PickingSequence", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PickingSequence, Id = Index.PickingSequence, FieldType = EntityFieldType.Char, Size = 10)]
        public string PickingSequence { get; set; }

        /// <summary>
        /// Gets or sets ExpectedShipmentDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpectedShipDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExpectedShipmentDate, Id = Index.ExpectedShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ExpectedShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        [Display(Name = "StockItem", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StockItem { get; set; }

        /// <summary>
        /// Gets or sets QuantityOrdered
        /// </summary>
        [Display(Name = "QtyOrdered", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantityOrdered, Id = Index.QuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets QuantityShipped
        /// </summary>
        [Display(Name = "QtyShipped", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantityShipped, Id = Index.QuantityShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityShipped { get; set; }

        /// <summary>
        /// Gets or sets QuantityBackordered
        /// </summary>
        [Display(Name = "QtyBO", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantityBackordered, Id = Index.QuantityBackordered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityBackordered { get; set; }

        /// <summary>
        /// Gets or sets QuantityShippedtodate
        /// </summary>
        [Display(Name = "ShippedToDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantityShippedtodate, Id = Index.QuantityShippedtodate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityShippedtodate { get; set; }

        /// <summary>
        /// Gets or sets OriginalQuantityOrdered
        /// </summary>
        [Display(Name = "OrigOrder", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OriginalQuantityOrdered, Id = Index.OriginalQuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal OriginalQuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets POQuantityOrdered
        /// </summary>
        [Display(Name = "POQuantityOrdered", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.POQuantityOrdered, Id = Index.POQuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal POQuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderUOM", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderUnitOfMeasure, Id = Index.OrderUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string OrderUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitConversion
        /// </summary>
        [Display(Name = "OrderUnitConversion", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderUnitConversion, Id = Index.OrderUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OrderUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitPrice
        /// </summary>
        [Display(Name = "UnitPrice", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderUnitPrice, Id = Index.OrderUnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OrderUnitPrice { get; set; }

        /// <summary>
        /// Gets or sets PriceOverride
        /// </summary>
        [Display(Name = "PriceOverride", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PriceOverride, Id = Index.PriceOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public PriceOverride PriceOverride { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderUnitCost, Id = Index.OrderUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? OrderUnitCost { get; set; }

        /// <summary>
        /// Gets or sets MostRecentUnitCost
        /// </summary>
        [Display(Name = "MostRecentUnitCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.MostRecentUnitCost, Id = Index.MostRecentUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? MostRecentUnitCost { get; set; }

        /// <summary>
        /// Gets or sets StandardUnitCost
        /// </summary>
        [Display(Name = "StandardUnitCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.StandardUnitCost, Id = Index.StandardUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? StandardUnitCost { get; set; }

        /// <summary>
        /// Gets or sets AlternateUnitCost1
        /// </summary>
        [Display(Name = "AlternateUnitCost1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.AlternateUnitCost1, Id = Index.AlternateUnitCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? AlternateUnitCost1 { get; set; }

        /// <summary>
        /// Gets or sets AlternateUnitCost2
        /// </summary>
        [Display(Name = "AlternateUnitCost2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.AlternateUnitCost2, Id = Index.AlternateUnitCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? AlternateUnitCost2 { get; set; }

        /// <summary>
        /// Gets or sets UnitPriceNoOfDecimals
        /// </summary>
        [Display(Name = "UnitPriceNoOfDecimals", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.UnitPriceNoOfDecimals, Id = Index.UnitPriceNoOfDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int UnitPriceNoOfDecimals { get; set; }

        /// <summary>
        /// Gets or sets PricingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingUnitOfMeasure", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PricingUnitOfMeasure, Id = Index.PricingUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string PricingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets PricingUnitPrice
        /// </summary>
        [Display(Name = "PricingUnitPrice", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PricingUnitPrice, Id = Index.PricingUnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingUnitPrice { get; set; }

        /// <summary>
        /// Gets or sets PricingUnitConversion
        /// </summary>
        [Display(Name = "PricingUnitConversion", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PricingUnitConversion, Id = Index.PricingUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets PriceDiscountPercentage
        /// </summary>
        [Display(Name = "PriceDiscountPercentage", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PriceDiscountPercentage, Id = Index.PriceDiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PriceDiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets PriceDiscountAmount
        /// </summary>
        [Display(Name = "PriceDiscountAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PriceDiscountAmount, Id = Index.PriceDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PriceDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PricingBaseUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingBaseUnit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PricingBaseUnit, Id = Index.PricingBaseUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string PricingBaseUnit { get; set; }

        /// <summary>
        /// Gets or sets PricingBaseUnitPrice
        /// </summary>
        [Display(Name = "PricingBaseUnitPrice", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PricingBaseUnitPrice, Id = Index.PricingBaseUnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingBaseUnitPrice { get; set; }

        /// <summary>
        /// Gets or sets PricingBaseUnitConversion
        /// </summary>
        [Display(Name = "PricingBaseUnitConversion", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PricingBaseUnitConversion, Id = Index.PricingBaseUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingBaseUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostingUOM", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CostingUnitOfMeasure, Id = Index.CostingUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string CostingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitCost
        /// </summary>
        [Display(Name = "CostingUnitCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CostingUnitCost, Id = Index.CostingUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? CostingUnitCost { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitConversion
        /// </summary>
        [Display(Name = "CostingUnitConversion", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CostingUnitConversion, Id = Index.CostingUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? CostingUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets ExtendedOrderAmount
        /// </summary>
        [Display(Name = "ExtendedOrderAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExtendedOrderAmount, Id = Index.ExtendedOrderAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedOrderAmount { get; set; }

        /// <summary>
        /// Gets or sets ExtendedOrderCost
        /// </summary>
        [Display(Name = "ExtendedOrderCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExtendedOrderCost, Id = Index.ExtendedOrderCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? ExtendedOrderCost { get; set; }

        /// <summary>
        /// Gets or sets ExtendedAmount
        /// </summary>
        [Display(Name = "ExtendedAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExtendedAmount, Id = Index.ExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedAmount { get; set; }

        /// <summary>
        /// Gets or sets OrderDiscountAmount
        /// </summary>
        [Display(Name = "OrderDiscountAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderDiscountAmount, Id = Index.OrderDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets ExtendedDetailCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExtendedDetailCost, Id = Index.ExtendedDetailCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? ExtendedDetailCost { get; set; }

        /// <summary>
        /// Gets or sets ExtendedShippedAmtOverride
        /// </summary>
        [Display(Name = "ExtendedShippedAmtOverride", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExtendedShippedAmtOverride, Id = Index.ExtendedShippedAmtOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ExtendedShippedAmtOverride { get; set; }

        /// <summary>
        /// Gets or sets UnitWeight
        /// </summary>
        [Display(Name = "UnitWeight", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.UnitWeight, Id = Index.UnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal UnitWeight { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [Display(Name = "ExtendedWeight", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets DetailCompleted
        /// </summary>
        [Display(Name = "Completed", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DetailCompleted, Id = Index.DetailCompleted, FieldType = EntityFieldType.Int, Size = 2)]
        public DetailCompleted DetailCompleted { get; set; }

        /// <summary>
        /// Gets or sets RecognizedInItemLocation
        /// </summary>
        [Display(Name = "RecognizedInItemLocation", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.RecognizedInItemLocation, Id = Index.RecognizedInItemLocation, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RecognizedInItemLocation { get; set; }

        /// <summary>
        /// Gets or sets LostSalesAmount
        /// </summary>
        [Display(Name = "LostSalesAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.LostSalesAmount, Id = Index.LostSalesAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LostSalesAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1
        /// </summary>
        [Display(Name = "TaxRate1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2
        /// </summary>
        [Display(Name = "TaxRate2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3
        /// </summary>
        [Display(Name = "TaxRate3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4
        /// </summary>
        [Display(Name = "TaxRate4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5
        /// </summary>
        [Display(Name = "TaxRate5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets UseCommentsInstructions
        /// </summary>
        [Display(Name = "UseCommentsInstructions", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.UseCommentsInstructions, Id = Index.UseCommentsInstructions, FieldType = EntityFieldType.Bool, Size = 2)]
        public UseCommentsInstructions UseCommentsInstructions { get; set; }

        /// <summary>
        /// Gets or sets TotalOrderMostRecentCost
        /// </summary>
        [Display(Name = "TotalOrderMostRecentCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalOrderMostRecentCost, Id = Index.TotalOrderMostRecentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalOrderMostRecentCost { get; set; }

        /// <summary>
        /// Gets or sets TotalOrderStandardCost
        /// </summary>
        [Display(Name = "TotalOrderStandardCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalOrderStandardCost, Id = Index.TotalOrderStandardCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalOrderStandardCost { get; set; }

        /// <summary>
        /// Gets or sets TotalOrderCost1
        /// </summary>
        [Display(Name = "TotalOrderCost1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalOrderCost1, Id = Index.TotalOrderCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalOrderCost1 { get; set; }

        /// <summary>
        /// Gets or sets TotalOrderCost2
        /// </summary>
        [Display(Name = "TotalOrderCost2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalOrderCost2, Id = Index.TotalOrderCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalOrderCost2 { get; set; }

        /// <summary>
        /// Gets or sets TotalInvoiceMostRecentCost
        /// </summary>
        [Display(Name = "TotalInvoiceMostRecentCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalInvoiceMostRecentCost, Id = Index.TotalInvoiceMostRecentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalInvoiceMostRecentCost { get; set; }

        /// <summary>
        /// Gets or sets TotalInvoiceStandardCost
        /// </summary>
        [Display(Name = "TotalInvoiceStandardCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalInvoiceStandardCost, Id = Index.TotalInvoiceStandardCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalInvoiceStandardCost { get; set; }

        /// <summary>
        /// Gets or sets TotalInvoiceCost1
        /// </summary>
        [Display(Name = "TotalInvoiceCost1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalInvoiceCost1, Id = Index.TotalInvoiceCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalInvoiceCost1 { get; set; }

        /// <summary>
        /// Gets or sets TotalInvoiceCost2
        /// </summary>
        [Display(Name = "TotalInvoiceCost2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalInvoiceCost2, Id = Index.TotalInvoiceCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalInvoiceCost2 { get; set; }

        /// <summary>
        /// Gets or sets PriceListDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceListDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PriceListDescription, Id = Index.PriceListDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string PriceListDescription { get; set; }

        /// <summary>
        /// Gets or sets CategoryDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CategoryDescription, Id = Index.CategoryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CategoryDescription { get; set; }

        /// <summary>
        /// Gets or sets LocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.LocationDescription, Id = Index.LocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1Desc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1Description, Id = Index.TaxAuthority1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2Desc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2Description, Id = Index.TaxAuthority2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3Desc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority3Description, Id = Index.TaxAuthority3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4Desc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4Description, Id = Index.TaxAuthority4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5Desc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5Description, Id = Index.TaxAuthority5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority5Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass1Description", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass2Description", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass3Description", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass4Description", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass5Description", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets DrivenbyUI
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.DrivenbyUI, Id = Index.DrivenbyUI, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DrivenbyUI { get; set; } = true;

        /// <summary>
        /// Gets or sets FoundNegativeInventory
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.FoundNegativeInventory, Id = Index.FoundNegativeInventory, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FoundNegativeInventory { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDateOverride
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.SetCreditApproval, Id = Index.SetCreditApproval, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SetCreditApproval { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearingAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLNonStkClearingAcct", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NonstockClearingAccount, Id = Index.NonstockClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string NonstockClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearingAcctDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NonstockClearingAcctDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NonstockClearingAcctDesc, Id = Index.NonstockClearingAcctDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string NonstockClearingAcctDesc { get; set; }

        /// <summary>
        /// Gets or sets InterprocessCommID
        /// </summary>
        [Display(Name = "InterprocessCommID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InterprocessCommID, Id = Index.InterprocessCommID, FieldType = EntityFieldType.Long, Size = 4)]
        public long InterprocessCommID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSNonQtyOrdered
        /// </summary>
        [Display(Name = "ForcePopupSNonQtyOrdered", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ForcePopupSNonQtyOrdered, Id = Index.ForcePopupSNonQtyOrdered, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupSNonQtyOrdered ForcePopupSNonQtyOrdered { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSNonQtyShipped
        /// </summary>
        [Display(Name = "ForcePopupSNonQtyShipped", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ForcePopupSNonQtyShipped, Id = Index.ForcePopupSNonQtyShipped, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupSNonQtyShipped ForcePopupSNonQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets PopupSn
        /// </summary>
        [Display(Name = "PopupSN", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PopupSn, Id = Index.PopupSn, FieldType = EntityFieldType.Int, Size = 2)]
        public PopupSN PopupSn { get; set; }

        /// <summary>
        /// Gets or sets CloseSn
        /// </summary>
        [Display(Name = "CloseSN", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CloseSn, Id = Index.CloseSn, FieldType = EntityFieldType.Bool, Size = 2)]
        public CloseSN CloseSn { get; set; }

        /// <summary>
        /// Gets or sets LtSetID
        /// </summary>
        [Display(Name = "LTSetID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.LtSetID, Id = Index.LtSetID, FieldType = EntityFieldType.Long, Size = 4)]
        public long LtSetID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLTonQtyOrdered
        /// </summary>
        [Display(Name = "ForcePopupLTonQtyOrdered", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ForcePopupLTonQtyOrdered, Id = Index.ForcePopupLTonQtyOrdered, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupLTonQtyOrdered ForcePopupLTonQtyOrdered { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLTonQtyShipped
        /// </summary>
        [Display(Name = "ForcePopupLTonQtyShipped", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ForcePopupLTonQtyShipped, Id = Index.ForcePopupLTonQtyShipped, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupLTonQtyShipped ForcePopupLTonQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets PopupLt
        /// </summary>
        [Display(Name = "PopupLT", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PopupLt, Id = Index.PopupLt, FieldType = EntityFieldType.Int, Size = 2)]
        public PopupLT PopupLt { get; set; }

        /// <summary>
        /// Gets or sets CloseLt
        /// </summary>
        [Display(Name = "CloseLT", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CloseLt, Id = Index.CloseLt, FieldType = EntityFieldType.Bool, Size = 2)]
        public CloseLT CloseLt { get; set; }

        /// <summary>
        /// Gets or sets AverageUnitCost
        /// </summary>
        [Display(Name = "AverageUnitCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.AverageUnitCost, Id = Index.AverageUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? AverageUnitCost { get; set; }

        /// <summary>
        /// Gets or sets LastUnitCost
        /// </summary>
        [Display(Name = "LastUnitCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.LastUnitCost, Id = Index.LastUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? LastUnitCost { get; set; }

        /// <summary>
        /// Gets or sets TotalOrderAverageCost
        /// </summary>
        [Display(Name = "TotalOrderAverageCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalOrderAverageCost, Id = Index.TotalOrderAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalOrderAverageCost { get; set; }

        /// <summary>
        /// Gets or sets TotalOrderLastCost
        /// </summary>
        [Display(Name = "TotalOrderLastCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalOrderLastCost, Id = Index.TotalOrderLastCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalOrderLastCost { get; set; }

        /// <summary>
        /// Gets or sets TotalInvoiceAverageCost
        /// </summary>
        [Display(Name = "TotalInvoiceAverageCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalInvoiceAverageCost, Id = Index.TotalInvoiceAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalInvoiceAverageCost { get; set; }

        /// <summary>
        /// Gets or sets TotalInvoiceLastCost
        /// </summary>
        [Display(Name = "TotalInvoiceLastCost", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalInvoiceLastCost, Id = Index.TotalInvoiceLastCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? TotalInvoiceLastCost { get; set; }

        /// <summary>
        /// Gets or sets CopyThisDetailLine
        /// </summary>
        [Display(Name = "CopyDetail", ResourceType = typeof(CopyOrdersResx))]
        [ViewField(Name = Fields.CopyThisDetailLine, Id = Index.CopyThisDetailLine, FieldType = EntityFieldType.Bool, Size = 2)]
        public CopyThisDetailLine CopyThisDetailLine { get; set; }

        /// <summary>
        /// Gets or sets QuoteNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "QuoteNUMBER", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.QuoteNumber, Id = Index.QuoteNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string QuoteNumber { get; set; }

        /// <summary>
        /// Gets or sets QuoteDetailLineNumber
        /// </summary>
        [Display(Name = "QuoteDetailLineNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.QuoteDetailLineNumber, Id = Index.QuoteDetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int QuoteDetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTrackingNumber
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentTrackingNo", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipmentTrackingNumber, Id = Index.ShipmentTrackingNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string ShipmentTrackingNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipVia", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipViaDescription", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipViaCodeDescription, Id = Index.ShipViaCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets DiscountPercent
        /// </summary>
        [Display(Name = "DiscountPercent", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DiscountPercent, Id = Index.DiscountPercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountPercent { get; set; }

        /// <summary>
        /// Gets or sets ExtendedDiscountedPrice
        /// </summary>
        [Display(Name = "ExtendedDiscountedPrice", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExtendedDiscountedPrice, Id = Index.ExtendedDiscountedPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedDiscountedPrice { get; set; }

        /// <summary>
        /// Gets or sets QuantityCommitted
        /// </summary>
        [Display(Name = "QtyCommitted", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantityCommitted, Id = Index.QuantityCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityCommitted { get; set; }

        /// <summary>
        /// Gets or sets ManufacturersItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ManufacturersItemNo", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ManufacturersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerItemNo", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerItemNumber, Id = Index.CustomerItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string CustomerItemNumber { get; set; }

        /// <summary>
        /// Gets or sets TrueQuantityCommitted
        /// </summary>
        [Display(Name = "TrueQuantityCommitted", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrueQuantityCommitted, Id = Index.TrueQuantityCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TrueQuantityCommitted { get; set; }

        /// <summary>
        /// Gets or sets ItemSerialized
        /// </summary>
        [Display(Name = "ItemSerialized", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ItemSerialized, Id = Index.ItemSerialized, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ItemSerialized { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }
        /// <summary>
        /// Gets or Sets OptionalFieldString
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
        public string OptionalFieldString { get; set; }

        /// <summary>
        /// Gets or sets KittingBOM
        /// </summary>
        [Display(Name = "KittingBOM", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.KittingBOM, Id = Index.KittingBOM, FieldType = EntityFieldType.Int, Size = 2)]
        public KittingBOM KittingBOM { get; set; }

        /// <summary>
        /// Gets or sets KitBOMNumber
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "KitBOM", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.KitBOMNumber, Id = Index.KitBOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string KitBOMNumber { get; set; }

        /// <summary>
        /// Gets or sets BOMBuildQty
        /// </summary>
        [Display(Name = "BOMBuildQty", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BOMBuildQty, Id = Index.BOMBuildQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal BOMBuildQty { get; set; }

        /// <summary>
        /// Gets or sets BOMBuildUnit
        /// </summary>
        [Display(Name = "BOMBuildUnit", ResourceType = typeof(OrderEntryResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BOMBuildUnit, Id = Index.BOMBuildUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string BOMBuildUnit { get; set; }

        /// <summary>
        /// Gets or sets BOMBuildUnitConversion
        /// </summary>
        [Display(Name = "BOMBuildUnitConversion", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BOMBuildUnitConversion, Id = Index.BOMBuildUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BOMBuildUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets PredecessorNumber
        /// </summary>
        [Display(Name = "PredecessorNumber", ResourceType = typeof(OrderEntryResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PredecessorNumber, Id = Index.PredecessorNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PredecessorNumber { get; set; }

        /// <summary>
        /// Gets or sets PredecessorUniquifier
        /// </summary>
        [Display(Name = "PredecessorUniquifier", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PredecessorUniquifier, Id = Index.PredecessorUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PredecessorUniquifier { get; set; }

        /// <summary>
        /// Gets or sets PredecessorLineNumber
        /// </summary>
        [Display(Name = "PredecessorLineNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PredecessorLineNumber, Id = Index.PredecessorLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int PredecessorLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets NextComponentNumber
        /// </summary>
        [Display(Name = "NextComponentNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NextComponentNumber, Id = Index.NextComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets EposPromotionID
        /// </summary>
        [Display(Name = "ePOSPromotionID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.EposPromotionID, Id = Index.EposPromotionID, FieldType = EntityFieldType.Int, Size = 2)]
        public int EposPromotionID { get; set; }

        /// <summary>
        /// Gets or sets ShipmentUniquifier
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ShipmentUniquifier, Id = Index.ShipmentUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ShipmentUniquifier { get; set; }

        /// <summary>
        /// Gets or sets PricingBaseWeightUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingBaseWeightUnit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PricingBaseWeightUnit, Id = Index.PricingBaseWeightUnit, FieldType = EntityFieldType.Char, Size = 10)]
        public string PricingBaseWeightUnit { get; set; }

        /// <summary>
        /// Gets or sets OrderWeightUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderWeightUOM", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderWeightUOM, Id = Index.OrderWeightUOM, FieldType = EntityFieldType.Char, Size = 10)]
        public string OrderWeightUOM { get; set; }

        /// <summary>
        /// Gets or sets OrderWeightConversionFactor
        /// </summary>
        [Display(Name = "OrderWeightConversionFactor", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderWeightConversionFactor, Id = Index.OrderWeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OrderWeightConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets PricingWeightUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingWeightUOM", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PricingWeightUOM, Id = Index.PricingWeightUOM, FieldType = EntityFieldType.Char, Size = 10)]
        public string PricingWeightUOM { get; set; }

        /// <summary>
        /// Gets or sets PricingWeightConversionFactor
        /// </summary>
        [Display(Name = "PricingWeightConversionFactor", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PricingWeightConversionFactor, Id = Index.PricingWeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingWeightConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets PricingBaseWeightConvFactor
        /// </summary>
        [Display(Name = "PricingBaseWeightConvFactor", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PricingBaseWeightConvFactor, Id = Index.PricingBaseWeightConvFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingBaseWeightConvFactor { get; set; }

        /// <summary>
        /// Gets or sets DefWeightUOMUnitWeight
        /// </summary>
        [Display(Name = "DefWeightUOMUnitWeight", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DefWeightUOMUnitWeight, Id = Index.DefWeightUOMUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal DefWeightUOMUnitWeight { get; set; }

        /// <summary>
        /// Gets or sets DefWeightUOMExtUnitWeight
        /// </summary>
        [Display(Name = "DefWeightUOMExtUnitWeight", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DefWeightUOMExtUnitWeight, Id = Index.DefWeightUOMExtUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal DefWeightUOMExtUnitWeight { get; set; }

        /// <summary>
        /// Gets or sets PriceBy
        /// </summary>
        [Display(Name = "PriceBy", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PriceBy, Id = Index.PriceBy, FieldType = EntityFieldType.Int, Size = 2)]
        public PriceBy PriceBy { get; set; }

        /// <summary>
        /// Gets or sets PriceCheckPending
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PriceCheckPending, Id = Index.PriceCheckPending, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PriceCheckPending { get; set; }

        /// <summary>
        /// Gets or sets PriceApprovedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceApprovedBy", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PriceApprovedBy, Id = Index.PriceApprovedBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string PriceApprovedBy { get; set; }

        /// <summary>
        /// Gets or sets ApprovingUsersPassword
        /// </summary>
        [StringLength(64, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ApprovingUsersPassword, Id = Index.ApprovingUsersPassword, FieldType = EntityFieldType.Char, Size = 64)]
        public string ApprovingUsersPassword { get; set; }

        /// <summary>
        /// Gets or sets PriceApprovalNeeded
        /// </summary>
        [Display(Name = "PriceApproval", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PriceApprovalNeeded, Id = Index.PriceApprovalNeeded, FieldType = EntityFieldType.Bool, Size = 2)]
        public PriceApprovalNeeded PriceApprovalNeeded { get; set; }

        /// <summary>
        /// Gets or sets WeightUOMDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WeightUOMDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.WeightUOMDescription, Id = Index.WeightUOMDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string WeightUOMDescription { get; set; }

        /// <summary>
        /// Gets or sets HeaderDiscount
        /// </summary>
        [Display(Name = "HeaderDiscount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.HeaderDiscount, Id = Index.HeaderDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HeaderDiscount { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount1
        /// </summary>
        [Display(Name = "TRTaxAmount1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TRTaxAmount1, Id = Index.TRTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount2
        /// </summary>
        [Display(Name = "TRTaxAmount2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TRTaxAmount2, Id = Index.TRTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount3
        /// </summary>
        [Display(Name = "TRTaxAmount3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TRTaxAmount3, Id = Index.TRTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount4
        /// </summary>
        [Display(Name = "TRTaxAmount4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TRTaxAmount4, Id = Index.TRTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount5
        /// </summary>
        [Display(Name = "TRTaxAmount5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TRTaxAmount5, Id = Index.TRTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets ExtendedAmountNetOfTax
        /// </summary>
        [Display(Name = "ExtendedAmountNetOfTax", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExtendedAmountNetOfTax, Id = Index.ExtendedAmountNetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedAmountNetOfTax { get; set; }

        /// <summary>
        /// Gets or sets DiscountedExtendedAmount
        /// </summary>
        [Display(Name = "DiscountedExtendedAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DiscountedExtendedAmount, Id = Index.DiscountedExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountedExtendedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal
        /// </summary>
        [Display(Name = "TaxTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TRTaxTotal
        /// </summary>
        [Display(Name = "TRTaxTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TRTaxTotal, Id = Index.TRTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets PickingSlipPrinted
        /// </summary>
        [Display(Name = "PickingSlipPrinted", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PickingSlipPrinted, Id = Index.PickingSlipPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PickingSlipPrinted { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool JobRelated { get; set; }

        /// <summary>
        /// Gets or sets ContractCode
        /// </summary>
        [Display(Name = "ContractCode", ResourceType = typeof(OrderEntryResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets ProjectStyle
        /// </summary>
        [Display(Name = "ProjectStyle", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectStyle ProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets RevenueBillingAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueBillingAccount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.RevenueBillingAccount, Id = Index.RevenueBillingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RevenueBillingAccount { get; set; }

        /// <summary>
        /// Gets or sets CogswipAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "COGSWIPAccount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CogswipAccount, Id = Index.CogswipAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CogswipAccount { get; set; }

        /// <summary>
        /// Gets or sets RetainagePercent
        /// </summary>
        [Display(Name = "RetainagePercent", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.RetainagePercent, Id = Index.RetainagePercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal RetainagePercent { get; set; }

        /// <summary>
        /// Gets or sets RetainageDays
        /// </summary>
        [Display(Name = "RetainageDays", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.RetainageDays, Id = Index.RetainageDays, FieldType = EntityFieldType.Int, Size = 2)]
        public int RetainageDays { get; set; }

        /// <summary>
        /// Gets or sets DefaultOEPrice
        /// </summary>
        [Display(Name = "DefaultOEPrice", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DefaultOEPrice, Id = Index.DefaultOEPrice, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultOEPrice DefaultOEPrice { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [Display(Name = "ARItemNumber", ResourceType = typeof(OrderEntryResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ARItemUnit
        /// </summary>
        [Display(Name = "ARItemUnit", ResourceType = typeof(OrderEntryResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ARItemUnit, Id = Index.ARItemUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string ARItemUnit { get; set; }

        /// <summary>
        /// Gets or sets Level1Name
        /// </summary>
        [Display(Name = "Level1Name", ResourceType = typeof(OrderEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Level1Name, Id = Index.Level1Name, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level1Name { get; set; }

        /// <summary>
        /// Gets or sets Level2Name
        /// </summary>
        [Display(Name = "Level2Name", ResourceType = typeof(OrderEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Level2Name, Id = Index.Level2Name, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level2Name { get; set; }

        /// <summary>
        /// Gets or sets Level3Name
        /// </summary>
        [Display(Name = "Level3Name", ResourceType = typeof(OrderEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Level3Name, Id = Index.Level3Name, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level3Name { get; set; }

        /// <summary>
        /// Gets or sets UnformattedContractCode
        /// </summary>
        [Display(Name = "UnformattedContractCode", ResourceType = typeof(OrderEntryResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnformattedContractCode, Id = Index.UnformattedContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string UnformattedContractCode { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentDistributed
        /// </summary>
        [Display(Name = "PrepaymentDistributed", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PrepaymentDistributed, Id = Index.PrepaymentDistributed, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrepaymentDistributed { get; set; }

        /// <summary>
        /// Gets or sets ExtPriceNetOfDiscIncTax
        /// </summary>
        [Display(Name = "ExtPriceNetOfDiscIncTax", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExtPriceNetOfDiscIncTax, Id = Index.ExtPriceNetOfDiscIncTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtPriceNetOfDiscIncTax { get; set; }

        /// <summary>
        /// Gets or sets SerialQuantity
        /// </summary>
        [Display(Name = "SerialQuantity", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SerialQuantity, Id = Index.SerialQuantity, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialQuantity { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets SerialQtyShipped
        /// </summary>
        [Display(Name = "SerialQtyShipped", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SerialQtyShipped, Id = Index.SerialQtyShipped, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets LotQtyShipped
        /// </summary>
        [Display(Name = "LotQtyShipped", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.LotQtyShipped, Id = Index.LotQtyShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets SerialLotQuantityToProcess
        /// </summary>
        [Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SerialLotQuantityToProcess { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate
        /// </summary>
        [Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets QuantityperLot
        /// </summary>
        [Display(Name = "QuantityperLot", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityperLot { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromSerial
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromSerial", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromSerial { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromLot
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromLot", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromLot { get; set; }

        /// <summary>
        /// Gets or sets ItemSerializedLotted
        /// </summary>
        [Display(Name = "ItemSerializedLotted", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ItemSerializedLotted, Id = Index.ItemSerializedLotted, FieldType = EntityFieldType.Int, Size = 2)]
        public ItemSerializedLotted ItemSerializedLotted { get; set; }

        /// <summary>
        /// Gets or sets SerialLotWindowHandle
        /// </summary>
        [Display(Name = "SerialLotWindowHandle", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialLotWindowHandle { get; set; }

        /// <summary>
        /// Gets or sets UseSimplePriceChecking
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.UseSimplePriceChecking, Id = Index.UseSimplePriceChecking, FieldType = EntityFieldType.Int, Size = 2)]
        public int UseSimplePriceChecking { get; set; }
        /// <summary>
        /// Gets or sets AlternateItemNumber
        /// </summary>
        [Display(Name = "AlternateItemNumber", ResourceType = typeof(OrderEntryResx))]
        public string AlternateItemNumber { get; set; }

        /// <summary>
        /// Gets or sets AlternateItemSetNumber
        /// </summary>
        [Display(Name = "AlternateItemSetNumber", ResourceType = typeof(OrderEntryResx))]
        public long AlternateItemSetNumber { get; set; }

        /// <summary>
        /// Gets or sets DateRequested
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateRequested", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DateRequested, Id = Index.DateRequested, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateRequested { get; set; }

        #region Newly Added Properties

        /// <summary>
        /// Gets or Sets OrderDetailOptionalFields
        /// </summary>
        public EnumerableResponse<OrderDetailOptionalField> OrderDetailOptionalFields { get; set; }

        /// <summary>
        /// Gets or Sets OrderBOMDetails
        /// </summary>
        public EnumerableResponse<OrderBOMDetail> OrderBOMDetails { get; set; }

        /// <summary>
        /// Gets or Sets OrderDetailSerialNumbers
        /// </summary>
        public EnumerableResponse<OrderDetailSerialNumber> OrderDetailSerialNumbers { get; set; }

        /// <summary>
        /// Gets or Sets OrderDetailLotNumbers
        /// </summary>
        public EnumerableResponse<OrderDetailLotNumber> OrderDetailLotNumbers { get; set; }

        /// <summary>
        /// Gets or Sets commentInstructions
        /// </summary>
        public EnumerableResponse<OrderComment> commentInstructions { get; set; }

        /// <summary>
        /// Display only for comment string
        /// </summary>
        [IgnoreExportImport]
        [StringLength(20000, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommentsInstructions", ResourceType = typeof(OECommonResx))]
        public string CombinedComment { get; set; }

        /// <summary>
        /// Display only for instruction string
        /// </summary>
        [IgnoreExportImport]
        [StringLength(20000, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommentsInstructions", ResourceType = typeof(OECommonResx))]
        public string CombinedInstruction { get; set; }

        /// <summary>
        /// Dirty flag for CombinedComment field
        /// </summary>
        [IgnoreExportImport]
        public bool hasCombinedCommentChanged { get; set; }

        /// <summary>
        /// Dirty flag for CombinedInstruction field
        /// </summary>
        [IgnoreExportImport]
        public bool hasCombinedInstructionChanged { get; set; }

        [IgnoreExportImport]
        public decimal ExtendedPrice
        {
            get
            {
                return OrderUnitPrice * QuantityOrdered;
            }
        }

        #endregion
    }
}
