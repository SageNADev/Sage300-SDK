// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for PrepaymentApplyTo
     /// </summary>
     public enum PrepaymentApplyTo
     {
          /// <summary>
          /// Gets or sets InvoiceNo
          /// </summary>
          InvoiceNo = 2,
          /// <summary>
          /// Gets or sets OrderNo
          /// </summary>
          OrderNo = 4,
          /// <summary>
          /// Gets or sets ShipmentNo
          /// </summary>
          ShipmentNo = 9,
     }
}
