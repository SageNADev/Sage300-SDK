﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    public enum OEOrderPrintStatus
    {
        /// <summary>
        /// Gets or sets 
        /// </summary>
        Unknown = 1,
        /// <summary>
        /// Gets or sets Quoteprinted
        /// </summary>
        [EnumValue("QuotePrinted", typeof(OECommonResx), 2)]
        QuotePrinted = 2,

        /// <summary>
        /// Gets or sets Pickingslipprinted
        /// </summary>
        [EnumValue("PickingSlipPrinted", typeof(OECommonResx), 3)]
        PickingSlipPrinted = 3,

        /// <summary>
        /// Gets or sets Internet
        /// </summary>
        [EnumValue("Internet", typeof(OECommonResx), 4)]
        Internet = 0,

        /// <summary>
        /// Gets or sets ElectronicCommerce
        /// </summary>
        [EnumValue("ElectronicCommerce", typeof(OECommonResx), 5)]
        ElectronicCommerce = -1,
    }
}
