// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for PriceBy
    /// </summary>
    public enum PriceBy
    {
        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [EnumValue("Quantity", typeof(OECommonResx))]
        Quantity = 1,
        /// <summary>
        /// Gets or sets Weight
        /// </summary>
        [EnumValue("Weight", typeof(Resources.Forms.CreditDebitNoteEntryResx))]
        Weight = 2,
    }
}
