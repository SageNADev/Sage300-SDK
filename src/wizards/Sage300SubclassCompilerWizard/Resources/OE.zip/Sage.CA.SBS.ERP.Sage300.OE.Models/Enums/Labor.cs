// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for Labor
     /// </summary>
     public enum Labor
     {
          /// <summary>
          /// Gets or sets NotApplicable
          /// </summary>
          NotApplicable = 99,
     }
}
