// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for Database Type
    /// </summary>
    public enum DataBaseType
    {
        /// <summary>
        /// Gets or sets Data Base Type Btrv
        /// </summary>
        Btrv = 0,

        /// <summary>
        /// Gets or sets ata Base Type Oracle
        /// </summary>
        Oracle = 4,
    }
}
