﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    ///  Enum for Currency
    /// </summary>
    public enum Currency
    {
        /// <summary>
        /// Gets or sets CustomerCurrency
        /// </summary>
        [EnumValue("CustomerCurrency", typeof(OECommonResx))]
        CustomerCurrency = 0,

        /// <summary>
        /// Gets or sets FunctionalCurrency
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(OECommonResx))]
        FunctionalCurrency = 1,
    }
}
