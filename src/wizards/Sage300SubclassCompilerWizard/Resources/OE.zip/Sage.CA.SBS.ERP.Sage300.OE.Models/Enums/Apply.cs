// Copyright © 2017 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for Apply
    /// </summary>
    public enum Apply
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>
        [EnumValue("No", typeof(PreauthorizedPaymentDetailResx))]
        No = 0,

        /// <summary>
        /// Gets or sets Yes
        /// </summary>
        [EnumValue("Yes", typeof(PreauthorizedPaymentDetailResx))]
        Yes = 1

    }
}