﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for SelectedBy
    /// </summary>
    public enum SelectedBy
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [EnumValue("CustomerNumber", typeof(OECommonResx))]
        CustomerNumber = 0,

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [EnumValue("ItemNumber", typeof(OECommonResx))]
        ItemNumber = 1,

    }
}
