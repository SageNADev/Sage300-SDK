﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    public enum TransactionSetting
    {
        /// <summary>
        /// Gets or sets NotApplicable 
        /// </summary>	
        [EnumValue("NotApplicable", typeof(CommonResx))]
        NotApplicable = 99,

        /// <summary>
        /// Gets or sets No 
        /// </summary>	
        [EnumValue("No", typeof(CommonResx))]
        No = 0,

        /// <summary>
        /// Gets or sets Yes 
        /// </summary>	
        [EnumValue("Yes", typeof(CommonResx))]
        Yes = 1,
    }
}
