// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for CreditDebitNoteStatus
    /// </summary>
    public enum CreditDebitNoteStatus
    {
        /// <summary>
        /// Gets or sets Documentshippednotcosted
        /// </summary>
        [EnumValue("DocumentShippedNotCosted", typeof(CreditDebitNoteEntryResx), 1)]
        DocumentShippedNotCosted = 1,
        /// <summary>
        /// Gets or sets Documentcosted
        /// </summary>
        [EnumValue("DocumentCosted", typeof(CreditDebitNoteEntryResx), 2)]
        DocumentCosted = 2,
    }
}
