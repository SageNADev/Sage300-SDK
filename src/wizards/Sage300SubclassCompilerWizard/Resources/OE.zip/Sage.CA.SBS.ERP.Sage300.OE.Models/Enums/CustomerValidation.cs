﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    public enum CustomerValidation
    {
        /// <summary>
        /// From Customer
        /// </summary>
        FromCustomer=1,

        /// <summary>
        /// To Customer
        /// </summary>
        ToCustomer =2,

        /// <summary>
        /// Tax Group
        /// </summary>
        TaxGroup=3,

        /// <summary>
        /// Price List
        /// </summary>
        PriceList=4
    }
}
