// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.
#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for DeferredARPosting
     /// </summary>
     public enum DeferredARPosting
     {
          /// <summary>
          /// Gets or sets DuringDayEndProcessing
          /// </summary>
          [EnumValue("DuringDayEnd", typeof(Resources.Forms.GLIntegrationResx), 1)] 
          DuringDayEndProcessing = 0,
          /// <summary>
          /// Gets or sets OnRequestUsingCreateBatchIcon
          /// </summary>
          [EnumValue("OnRequestUsingCreateBatchIcon", typeof(Resources.Forms.GLIntegrationResx), 2)] 
          OnRequestUsingCreateBatchIcon = 1,
     }
}
