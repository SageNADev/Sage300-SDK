﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    public enum PrepaymentMode
    {
        /// <summary>
        /// Gets or sets Capture
        /// </summary>
        Capture=1,

        /// <summary>
        /// Gets or sets Void
        /// </summary>
        Void=2,

        /// <summary>
        /// Gets or sets Sale
        /// </summary>
        Sale=3,

        /// <summary>
        /// Gets or sets VoidSale
        /// </summary>
        VoidSale=4

    }
}
