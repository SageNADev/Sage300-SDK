// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for LineType
     /// </summary>
     public enum LineType
     {
          /// <summary>
          /// Gets or sets Item
          /// </summary>
          [EnumValue("Item", typeof(CreditDebitNoteEntryResx))]
          Item = 1,
          /// <summary>
          /// Gets or sets Miscellaneous
          /// </summary>
          [EnumValue("Miscellaneous", typeof(CreditDebitNoteEntryResx))]
          Miscellaneous = 2,
     }
}
