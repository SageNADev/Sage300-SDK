// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for OrderType
    /// </summary>
    public enum OrderType
    {
        /// <summary>
        /// Gets or sets Active
        /// </summary>
        [EnumValue("Active", typeof(OECommonResx), 1)]
        Active = 1,
        /// <summary>
        /// Gets or sets Future
        /// </summary>
        [EnumValue("Future", typeof(OECommonResx), 2)]
        Future = 2,
        /// <summary>
        /// Gets or sets Standing
        /// </summary>
        [EnumValue("Standing", typeof(OECommonResx), 3)]
        Standing = 3,
        /// <summary>
        /// Gets or sets Quote
        /// </summary>
        [EnumValue("Quote", typeof(OECommonResx), 4)]
        Quote = 4
    }
}
