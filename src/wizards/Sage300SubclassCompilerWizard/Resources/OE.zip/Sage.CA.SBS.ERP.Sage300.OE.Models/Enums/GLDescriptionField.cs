// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for GLDescriptionField
     /// </summary>
     public enum GLDescriptionField
     {
          /// <summary>
          /// Gets or sets DocumentNumber
          /// </summary>
          DocumentNumber = 1,
          /// <summary>
          /// Gets or sets ReferenceNumber
          /// </summary>
          ReferenceNumber = 2,
          /// <summary>
          /// Gets or sets SourceCodeDayEndNumberEntryNumber
          /// </summary>
          SourceCodeDayEndNumberEntryNumber = 3,
          /// <summary>
          /// Gets or sets HeaderDescription
          /// </summary>
          HeaderDescription = 4,
          /// <summary>
          /// Gets or sets CustomerVendorNumber
          /// </summary>
          CustomerVendorNumber = 5,
          /// <summary>
          /// Gets or sets CustomerVendorName
          /// </summary>
          CustomerVendorName = 6,
     }
}
