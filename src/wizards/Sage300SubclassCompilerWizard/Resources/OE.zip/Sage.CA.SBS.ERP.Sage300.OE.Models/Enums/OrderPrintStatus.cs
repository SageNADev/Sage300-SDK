// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for OrderPrintStatus
     /// </summary>
     public enum OrderPrintStatus
     {
          /// <summary>
          /// Gets or sets 
          /// </summary>
         [EnumValue("Posted", typeof(OECommonResx), 1)] 
         Posted = 1,
          /// <summary>
          /// Gets or sets Quoteprinted
          /// </summary>
          [EnumValue("QuotePrinted", typeof(OECommonResx), 1)]
         QuotePrinted = 2,
          /// <summary>
          /// Gets or sets Pickingslipprinted
          /// </summary>
         [EnumValue("PickingSlipPrinted", typeof(OECommonResx), 3)]  
         PickingSlipPrinted = 3,
          /// <summary>
          /// Gets or sets Internet
          /// </summary>
         [EnumValue("Internet", typeof(OECommonResx), 0)]  
         Internet = 0,
          /// <summary>
          /// Gets or sets ElectronicCommerce
          /// </summary>
         [EnumValue("ElectronicCommerce", typeof(OECommonResx), -1)]  
         ElectronicCommerce = -1,
         /// <summary>
         /// Gets or sets OrderConfirmationPrinted
         /// </summary>
         [EnumValue("OrderConfirmationPrinted", typeof(OECommonResx), 1)]
         OrderConfirmationPrinted = 1,
     }
}
