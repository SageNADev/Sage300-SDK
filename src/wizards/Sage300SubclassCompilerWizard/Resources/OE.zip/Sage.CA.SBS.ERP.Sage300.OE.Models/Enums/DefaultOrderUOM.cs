// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Using

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for DefaultOrderUOM
    /// </summary>
    // ReSharper disable once InconsistentNaming
    public enum DefaultOrderUOM
    {
        /// <summary>
        /// Gets or sets StockingUnit
        /// </summary>
        [EnumValue("StockingUnit", typeof(OptionsResx), 1)]
        StockingUnit = 1,

        /// <summary>
        /// Gets or sets PricingUnit
        /// </summary>
        [EnumValue("PricingUnit", typeof(OptionsResx), 2)]
        PricingUnit = 2,
    }
}
