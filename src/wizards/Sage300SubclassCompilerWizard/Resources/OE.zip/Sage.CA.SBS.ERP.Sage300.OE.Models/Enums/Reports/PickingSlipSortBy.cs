﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for Picking Slip Select By Method
    /// </summary>
    public enum PickingSlipSortBy
    {
        /// <summary>
        /// Gets or sets Picking Sequence
        /// </summary>
        [EnumValue("PickingSequence", typeof(PickingSlipsResx))]
        PickingSequence = 0,

        /// <summary>
        /// Gets or sets Item Number
        /// </summary>	
        [EnumValue("ItemNumber", typeof(OECommonResx))]
        ItemNumber = 1,

        /// <summary>
        /// Gets or sets Line Number
        /// </summary>	
        [EnumValue("LineNumber", typeof(OECommonResx))]
        LineNumber = 2,
    }
}
