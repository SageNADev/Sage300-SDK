﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for Picking Slip Select By Method
    /// </summary>
    public enum PickingSlipSelectBy
    {
        /// <summary>
        /// Gets or sets Order Number
        /// </summary>
        [EnumValue("OrderNumber", typeof(OECommonResx))]
        OrderNumber = 0,

        /// <summary>
        /// Gets or sets Shipment Number
        /// </summary>	
        [EnumValue("ShipmentNumber", typeof(OECommonResx))]
        ShipmentNumber = 1,
    }
}
