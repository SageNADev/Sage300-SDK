﻿
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    public enum SalesHistoryReportType
    {
        /// <summary>
        /// Detail
        /// </summary>
        [EnumValue("Detail", typeof(OECommonResx))]
        Detail = 1,

        /// <summary>
        /// Summary
        /// </summary>
        [EnumValue("Summary", typeof(OECommonResx))]
        Summary = 2,

        /// <summary>
        /// Summary
        /// </summary>
        [EnumValue("Totals", typeof(OECommonResx))]
        Totals = 3
    }
}
