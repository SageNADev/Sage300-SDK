﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for SelectItem
    /// </summary>
    public enum SelectItem
    {
        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [EnumValue("InvoiceNumber", typeof(OECommonResx))]
        InvoiceNumber = 0,

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [EnumValue("OrderNumber", typeof(OECommonResx))]
        OrderNumber = 1,

        /// <summary>
        /// Gets or sets ShipmentNumber
        /// </summary>
        [EnumValue("ShipmentNumber", typeof(OECommonResx))]
        ShipmentNumber = 2


    }
}
