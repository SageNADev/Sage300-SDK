﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// SortBy Type enum
    /// </summary>
    [Flags]
    public enum SortsBy
    {
        /// <summary>
        /// Document Number
        /// </summary>
        [EnumValue("DocumentNumber", typeof(OECommonResx))]
        DocumentNumber = 0,
     
        /// <summary>
        /// Document Date
        /// </summary>
        [EnumValue("DocumentDate", typeof(OECommonResx))]
        DocumentDate = 1,

        /// <summary>
        ///Customer Number
        /// </summary>
        [EnumValue("CustomerNumber", typeof(OECommonResx))]
        CustomerNumber = 2,
    }
}
