﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// SortBy Type enum
    /// </summary>
    public enum SortByOrderAction
    {
        /// <summary>
        /// Order Number
        /// </summary>
        [EnumValue("OrderNumber", typeof (OECommonResx))] 
        OrderNumber = 1,

        /// <summary>
        ///Customer Number
        /// </summary>
        [EnumValue("CustomerNumber", typeof (OECommonResx))] 
        CustomerNumber = 2,

        /// <summary>
        /// Currency
        /// </summary>
        [EnumValue("PrimarySalesperson", typeof(OECommonResx))]
        PrimarySalesPerson = 3,
    }
}
