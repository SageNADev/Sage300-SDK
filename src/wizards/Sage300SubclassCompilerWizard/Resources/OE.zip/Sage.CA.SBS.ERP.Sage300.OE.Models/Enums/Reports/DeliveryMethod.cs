﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    public enum DeliveryMethod
    {
        /// <summary>
        /// Gets or sets PrintDestination
        /// </summary>
        [EnumValue("PrintDestination", typeof(OECommonResx), 1)]
        PrintDestination = 0,

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [EnumValue("Customer", typeof(OECommonResx), 2)]
        Customer = 1,
    }
}
