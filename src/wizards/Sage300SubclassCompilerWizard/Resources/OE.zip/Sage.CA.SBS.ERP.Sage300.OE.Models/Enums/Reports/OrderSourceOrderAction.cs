﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Order Action Report
    /// </summary>
    public enum OrderSourceOrderAction
    {
        /// <summary>
        /// All Sources
        /// </summary>	
        [EnumValue("TxtOrdSourceAllSource", typeof(OrderActionReportResx))]
        AllSources = 1,

        /// <summary>
        /// Entered
        /// </summary>
        [EnumValue("Entered", typeof(OECommonResx))]
        Entered = 2,
        /// <summary>
        /// Internet
        /// </summary>
        [EnumValue("Internet", typeof(OECommonResx))]
        Internet = 3,
        
    }
}
