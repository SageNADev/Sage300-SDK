﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// UseQuote Enum
    /// </summary>
    public enum UseDocument
    {
        /// <summary>
        /// Gets or sets Credit Note
        /// </summary>
        [EnumValue("CreditNote1", typeof(OECommonResx), 1)]
        CreditNote = 1,

        /// <summary>
        /// Gets or sets Debit Note
        /// </summary>
        [EnumValue("DebitNote", typeof(OECommonResx), 2)]
        DebitNote = 2,
    }
}
