﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Order Confirmation Report Formats
    /// </summary>
    public enum OrderConfirmationReportType
    {
        /// <summary>
        /// Gets or sets OECONF01
        /// </summary>
        [EnumValue("OrderConfirmationReport1", typeof(OrderConfirmationsResx), 1)]
        OECONF01 = 0,

        /// <summary>
        /// Gets or sets OECONF02
        /// </summary>
        [EnumValue("OrderConfirmationReport2", typeof(OrderConfirmationsResx), 2)]
        OECONF02 = 1,
    }
}
