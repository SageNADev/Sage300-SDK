﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// SortBy Type enum
    /// </summary>
     [Flags]
    public enum SortBy
    {
        /// <summary>
        /// Order Number
        /// </summary>
        [EnumValue("OrderNumber", typeof (OECommonResx))] 
        OrderNumber = 0,

        /// <summary>
        ///Customer Number
        /// </summary>
        [EnumValue("CustomerNumber", typeof (OECommonResx))] 
        CustomerNumber = 1,

        /// <summary>
        /// Currency
        /// </summary>
        [EnumValue("Currency", typeof (OECommonResx))] 
        Currency = 2,
    }
}
