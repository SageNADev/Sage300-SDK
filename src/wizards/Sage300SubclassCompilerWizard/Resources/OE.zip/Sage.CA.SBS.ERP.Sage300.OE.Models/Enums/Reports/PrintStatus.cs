﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Names Space

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report
{
    public enum PrintStatus
    {
        /// <summary>
        /// AllStatuses
        /// </summary>
        [EnumValue("TxtPrintAllStatus", typeof(OrderActionReportResx))]
        AllStatuses = 1,

        /// <summary>
        /// Gets or sets Posted
        /// </summary>
        [EnumValue("Posted", typeof(OECommonResx))]
        Posted = 2,

        /// <summary>
        /// Confirmation Printed
        /// </summary>
        [EnumValue("ConfirmationPrinted", typeof(OECommonResx))]
        ConfirmationPrinted = 3,

        /// <summary>
        /// Picking Slip Printed
        /// </summary>
        [EnumValue("PickingSlipPrinted", typeof(OECommonResx))]
        PickingSlipPrinted = 4
        
    }
}
