﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region 


using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Print Amount In
    /// </summary>
    public enum PrintAmountIn
    {
        /// <summary>
        /// Gets or sets Customer Currency 
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(OECommonResx))]
        FunctionalCurrency = 1,

        /// <summary>
        /// Gets or sets Functional Currency 
        /// </summary>
        [EnumValue("CustomerCurrency", typeof(OECommonResx))]
        CustomerCurrency = 2
    }
}

