﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// SortBy Type enum
    /// </summary>
    [Flags]
    public enum SalesHistorySortBy
    {
        /// <summary>
        /// Document Number
        /// </summary>
        [EnumValue("CustomerNumber", typeof(OECommonResx))]
        CustomerNumber = 0,
     
        /// <summary>
        /// Document Date
        /// </summary>
        [EnumValue("ItemNumber", typeof(OECommonResx))]
        ItemNumber = 1,

        /// <summary>
        ///Customer Number
        /// </summary>
        [EnumValue("PrimarySalesperson", typeof(OECommonResx))]
        PrimarySalesPerson = 2,
    }
}
