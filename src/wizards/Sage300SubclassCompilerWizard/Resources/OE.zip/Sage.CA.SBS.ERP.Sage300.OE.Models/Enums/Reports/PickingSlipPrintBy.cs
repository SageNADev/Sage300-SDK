﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for Picking Slip Select By Method
    /// </summary>
    public enum PickingSlipPrintBy
    {
        /// <summary>
        /// Gets or sets Order Number
        /// </summary>
        [EnumValue("HeaderLocation", typeof(PickingSlipsResx))]
        HeaderLocation = 0,

        /// <summary>
        /// Gets or sets Shipment Number
        /// </summary>	
        [EnumValue("DetailLocations", typeof(PickingSlipsResx))]
        DetailLocations = 1,
    }
}
