﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Invoice Report Formats
    /// </summary>
    public enum InvoiceReportType
    {
        /// <summary>
        /// Gets or sets OEINV01
        /// </summary>
        [EnumValue("InvoiceReport1", typeof(InvoicesResx), 1)]
        OEINV01 = 0,

        /// <summary>
        /// Gets or sets OEINV02
        /// </summary>
        [EnumValue("InvoiceReport2", typeof(InvoicesResx), 2)]
        OEINV02 = 1,

        /* Below report formats are not working and so commented */
        ///// <summary>
        ///// Gets or sets OEINV03
        ///// </summary>
        //[EnumValue("InvoiceReport3", typeof(InvoicesResx), 3)]
        //OEINV03 = 2,

        ///// <summary>
        ///// Gets or sets OEINV04
        ///// </summary>
        //[EnumValue("InvoiceReport4", typeof(InvoicesResx), 4)]
        //OEINV04 = 3,

        ///// <summary>
        ///// Gets or sets OEINV05
        ///// </summary>
        //[EnumValue("InvoiceReport5", typeof(InvoicesResx), 5)]
        //OEINV05 = 4,
    }
}
