
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion 

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
	/// <summary>
    /// Enum for Functional Or Vendor Currency 
    /// </summary>
	public enum FuncOrVendorCurrency 
	{
			/// <summary>
		/// Gets or sets VendorCurrency 
		/// </summary>	
        [EnumValue("VendorCurrency", typeof(OECommonResx))]
        VendorCurrency = 0,
		/// <summary>
		/// Gets or sets FunctionalCurrency 
		/// </summary>	
        [EnumValue("FunctionalCurrency", typeof(OECommonResx))]
        FunctionalCurrency = 1,
	}
}
