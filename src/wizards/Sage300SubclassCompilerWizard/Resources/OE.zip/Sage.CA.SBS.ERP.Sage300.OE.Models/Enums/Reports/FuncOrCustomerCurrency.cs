﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region 


using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for FuncOrCustomerCurrency.
    /// </summary>
    public enum FuncOrCustomerCurrency
    {
        ///   <summary>
        /// Gets or sets Functional Currency 
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(OECommonResx))]
        FunctionalCurrency = 0,

        /// <summary>
        /// Gets or sets Customer Currency 
        /// </summary>
        [EnumValue("CustomerCurrency", typeof(OECommonResx))]
        CustomerCurrency = 1
    }
}

