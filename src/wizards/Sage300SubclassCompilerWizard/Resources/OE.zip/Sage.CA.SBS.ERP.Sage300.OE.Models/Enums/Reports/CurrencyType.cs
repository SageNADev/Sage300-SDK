﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Currency Type
    /// </summary>
    public enum CurrencyType
    {
        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(OECommonResx), 1)]
        FunctionalCurrency = 0,

        /// <summary>
        /// Gets or sets Customer Currency
        /// </summary>
        [EnumValue("CustomerCurrency", typeof(OECommonResx), 2)]
        CustomerCurrency = 1,

    }
}
