﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */



#region Names Space

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report
{
    public enum PrintType
    {

        /// <summary>
        /// The orders
        /// </summary>
        [EnumValue("ValCboprintOrders", typeof(TransactionListReportResx))]
        Orders = 0,

        /// <summary>
        /// The shipments
        /// </summary>
        [EnumValue("Shipments", typeof(OECommonResx))]
        Shipments = 1,

        /// <summary>
        /// The invoices
        /// </summary>
        [EnumValue("Invoices", typeof(OECommonResx))]
        Invoices = 2,

        /// <summary>
        /// The credit debit notes
        /// </summary>
        [EnumValue("CreditDebitNotes", typeof(OECommonResx))]
        CreditDebitNotes = 3
        
    }
}
