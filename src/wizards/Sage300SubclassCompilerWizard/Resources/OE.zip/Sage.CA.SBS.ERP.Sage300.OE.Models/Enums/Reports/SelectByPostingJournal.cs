﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Action Invoice Method
    /// </summary>
    public enum SelectByPostingJournal
    {
        /// <summary>
        /// Gets or sets Shipment Number
        /// </summary>	
        [EnumValue("Shipments", typeof(OECommonResx))]
        ShipmentNumber = 0,

        /// <summary>
        /// Gets or sets Invoices
        /// </summary>
        Invoices = 1,

        /// <summary>
        /// Gets or sets CreditDebitNotes
        /// </summary>
        [EnumValue("CreditDebitNotes", typeof(OECommonResx))]
        CreditDebitNotes = 2
    }
}
