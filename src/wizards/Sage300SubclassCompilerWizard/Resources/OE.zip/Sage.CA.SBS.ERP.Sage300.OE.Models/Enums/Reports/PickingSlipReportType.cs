﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Picking Slip Report Formats
    /// </summary>
    public enum PickingSlipReportType
    {
        /// <summary>
        /// Gets or sets OEPICKORDER1
        /// </summary>
        [EnumValue("PickingSlipReport1", typeof(PickingSlipsResx), 1)]
        OEPICKORDER1 = 0,

        /// <summary>
        /// Gets or sets OEPICKORDER2
        /// </summary>
        [EnumValue("PickingSlipReport2", typeof(PickingSlipsResx), 2)]
        OEPICKORDER2 = 1,

        /// <summary>
        /// Gets or sets OECONF03
        /// </summary>
        [EnumValue("PickingSlipReport3", typeof(PickingSlipsResx), 3)]
        OEPICKSHIPMENT1 = 2,

        /// <summary>
        /// Gets or sets OECONF03
        /// </summary>
        [EnumValue("PickingSlipReport4", typeof(PickingSlipsResx), 4)]
        OEPICKSHIPMENT2 = 3,

    }
}
