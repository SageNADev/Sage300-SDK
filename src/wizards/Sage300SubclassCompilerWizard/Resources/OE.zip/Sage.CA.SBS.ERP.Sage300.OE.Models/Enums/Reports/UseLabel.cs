﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Use Label Enum
    /// </summary>
    public enum UseLabel
    {
        /// <summary>
        /// Gets or sets PORET01
        /// </summary>
        [EnumValue("OELABEL", typeof(ShippingLabelsResx),1)]
        OELABEL = 0,

        /// <summary>
        /// Gets or sets PORET02
        /// </summary>
        [EnumValue("OELABELD", typeof(ShippingLabelsResx),2)]
        OELABELD = 1,
    }
}
