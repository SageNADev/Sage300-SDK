﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion


// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Action Invoice Method
    /// </summary>
    public enum SalesHistorySelectBy
    {
        /// <summary>
        /// Gets or sets Shipment Number
        /// </summary>	
        [EnumValue("DocumentDate", typeof(OECommonResx))]
        DocumentDate = 1,

        /// <summary>
        /// Gets or sets Order Number
        /// </summary>
        [EnumValue("YearPeriod", typeof(OECommonResx))]
        YearPeriod = 2
        
    }
}
