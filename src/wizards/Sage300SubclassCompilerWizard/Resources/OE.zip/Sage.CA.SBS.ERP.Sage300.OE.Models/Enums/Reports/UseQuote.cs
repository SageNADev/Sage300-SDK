﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// UseQuote Enum
    /// </summary>
    public enum UseQuote
    {
        /// <summary>
        /// Gets or sets OEQUOT01
        /// </summary>
        [EnumValue("OEQUOT01", typeof(QuotesResx), 1)]
         OEQUOT01= 0,

        /// <summary>
         /// Gets or sets OEQUOT02
        /// </summary>
        [EnumValue("OEQUOT02", typeof(QuotesResx), 2)]
         OEQUOT02 = 1,
    }
}
