﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for Letter And Label Report Delivery Method
    /// </summary>
    public enum ThenBy
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>	
        [EnumValue("None", typeof(CommonResx))]
        None = 1,

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [EnumValue("CustomerNumber", typeof(OECommonResx))]
        CustomerNumber = 2,

        /// <summary>
        /// Gets or sets PrimarySalesPerson
        /// </summary>
        [EnumValue("PrimarySalesperson", typeof(OECommonResx))]
        PrimarySalesPerson = 3
    }
}
