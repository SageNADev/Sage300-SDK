﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Order Action Report
    /// </summary>
    public enum OrderTypeOrderAction
    {
        /// <summary>
        /// All Orders
        /// </summary>	
        [EnumValue("TxtOrdTypeAllOrders", typeof(OrderActionReportResx))]
        AllOrders = 1,

        /// <summary>
        /// Orders Never Shipped
        /// </summary>
        [EnumValue("TxtOrdTypeNeverShipped", typeof(OrderActionReportResx))]
        OrdersNeverShipped = 2,

        /// <summary>
        /// Orders Partially Shipped
        /// </summary>
        [EnumValue("TxtOrdTypePartShipped", typeof(OrderActionReportResx))]
        OrdersPartiallyShipped = 3,

        /// <summary>
        /// Orders Never Or Partially Shipped
        /// </summary>
        [EnumValue("TxtOrdTypeNeverOrPart", typeof(OrderActionReportResx))]
        OrdersNeverOrPartiallyShipped = 4,
        
        /// <summary>
        /// Orders On Hold
        /// </summary>
        [EnumValue("TxtOrdTypeOnHold", typeof(OrderActionReportResx))]
        OrdersOnHold = 5
    }
}
