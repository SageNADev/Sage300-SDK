﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Order Confirmation Report Delivery Types
    /// </summary>
    public enum DeliveryType
    {
        /// <summary>
        /// Gets or Sets Email
        /// </summary>
        Email = 1,

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [EnumValue("Customer", typeof(OECommonResx), 2)]
        Customer = 2,

        /// <summary>
        /// Gets or sets PrintDestination
        /// </summary>
        [EnumValue("PrintDestination", typeof (OECommonResx), 1)]
        PrintDestination = 3,
    }
}
