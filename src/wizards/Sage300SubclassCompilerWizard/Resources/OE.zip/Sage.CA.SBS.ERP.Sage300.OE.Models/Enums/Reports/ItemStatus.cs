﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Names Space

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report
{
    public enum ItemStatus
    {
        /// <summary>
        /// Completed with No Shipments
        /// </summary>
        [EnumValue("TxtItemUnshipped", typeof(OrderActionReportResx))]
        CompletedwithNoShipments = 1,

        /// <summary>
        /// Incomplete Orders
        /// </summary>
        [EnumValue("TxtItemToBeShipped", typeof(OrderActionReportResx))]
        IncompleteOrders = 2,

        /// <summary>
        /// Some Items Available for Shipment
        /// </summary>
        [EnumValue("TxtItemPartShippable", typeof(OrderActionReportResx))]
        SomeItemsAvailableforShipment = 3,

        /// <summary>
        /// All Items Available for Shipment
        /// </summary>
        [EnumValue("TxtItemTotalShippable", typeof(OrderActionReportResx))]
        AllItemsAvailableforShipment = 4,

        /// <summary>
        /// Items Out of Stock
        /// </summary>
        [EnumValue("TxtItemOutOfStock", typeof(OrderActionReportResx))]
        ItemsOutofStock = 5
       
    }
}
