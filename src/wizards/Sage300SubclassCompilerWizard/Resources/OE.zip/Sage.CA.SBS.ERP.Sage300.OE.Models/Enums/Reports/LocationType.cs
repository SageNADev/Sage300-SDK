 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
	/// <summary>
    /// Enum for LocationType 
    /// </summary>
	public enum LocationType 
	{
		/// <summary>
		/// Gets or sets Physical 
		/// </summary>
        [EnumValue("Type_Physical", typeof(EnumerationsResx))]	
        Physical = 0,

		/// <summary>
		/// Gets or sets Logical 
		/// </summary>	
        [EnumValue("Type_Logical", typeof(EnumerationsResx))]
        Logical = 1,
	}
}
