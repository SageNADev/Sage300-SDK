﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Report
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// SortBy Type enum
    /// </summary>
    public enum TransactionListSortBy
    {
        /// <summary>
        /// Order Number
        /// </summary>
        [EnumValue("OrderNumber", typeof(OECommonResx))]
        OrderNumber = 0,

        /// <summary>
        /// The shipment number
        /// </summary>
        [EnumValue("ShipmentNumber", typeof(OECommonResx))]
        ShipmentNumber = 1,
        
        /// <summary>
        /// The invoice number
        /// </summary>
        [EnumValue("InvoiceNumber", typeof(OECommonResx))]
        InvoiceNumber = 2,

        /// <summary>
        /// The credit debit note number
        /// </summary>
        [EnumValue("CreditDebitNoteNumber", typeof(OECommonResx))]
        CreditDebitNoteNumber = 3,

        /// <summary>
        ///Customer Number
        /// </summary>
        [EnumValue("CustomerNumber", typeof(OECommonResx))]
        CustomerNumber = 4,
    }

}
