﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Action Invoice Method
    /// </summary>
    public enum SortByPostingJournal
    {
        /// <summary>
        /// Gets or sets DayEndNumber
        /// </summary>	
        [EnumValue("DayEndNumber", typeof(OECommonResx))]
        DayEndNumber = 0,

        /// <summary>
        /// Gets or sets Invoices
        /// </summary>
        [EnumValue("TransactionDate", typeof(OECommonResx))]
        TransactionDate = 1,

        /// <summary>
        /// Gets or sets CreditDebitNotes
        /// </summary>
        [EnumValue("CustomerNumber", typeof(OECommonResx))]
        CustomerNumber = 2,

        /// <summary>
        /// Gets or sets CreditDebitNotes
        /// </summary>
        [EnumValue("TransactionNumber", typeof(OECommonResx))]
        DocumentNumber = 3
        
    }
}
