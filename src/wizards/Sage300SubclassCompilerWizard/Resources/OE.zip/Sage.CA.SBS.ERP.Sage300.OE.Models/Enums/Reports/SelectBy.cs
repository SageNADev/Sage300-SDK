﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for Action Invoice Method
    /// </summary>
    public enum SelectBy
    {
        /// <summary>
        /// Gets or sets Shipment Number
        /// </summary>	
        [EnumValue("ShipmentNumber", typeof(OECommonResx))]
        ShipmentNumber = 1,

        /// <summary>
        /// Gets or sets Order Number
        /// </summary>
        [EnumValue("OrderNumber", typeof(OECommonResx))]
        OrderNumber = 2
        
    }
}
