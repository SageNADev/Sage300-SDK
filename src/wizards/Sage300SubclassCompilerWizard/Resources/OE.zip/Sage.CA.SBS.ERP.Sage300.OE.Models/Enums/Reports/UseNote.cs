﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Reports
{
    /// <summary>
    /// UseQuote Enum
    /// </summary>
    public enum UseNote
    {
        /// <summary>
        /// Gets or sets OEQUOT01
        /// </summary>
        [EnumValue("OECRN01", typeof(CreditDebitNotesResx), 1)]
        OECRN01 = 0,

        /// <summary>
        /// Gets or sets OEQUOT02
        /// </summary>
        [EnumValue("OECRN02", typeof(CreditDebitNotesResx), 2)]
        OECRN02 = 1,
    }
}
