﻿// Copyright © 2017 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for ProcessingStatus
    /// </summary>
    public enum ProcessingStatus
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(PreauthorizedPaymentDetailResx))]
        None = 0,

        /// <summary>
        /// Gets or sets CaptureSuccessful
        /// </summary>
        [EnumValue("CaptureSuccessful", typeof(PreauthorizedPaymentDetailResx))]
        CaptureSuccessful = 1,

        /// <summary>
        /// Gets or sets CardDeclined
        /// </summary>
        [EnumValue("CardDeclined", typeof(PreauthorizedPaymentDetailResx))]
        CardDeclined = 2,

        /// <summary>
        /// Gets or sets CardError
        /// </summary>
        [EnumValue("CardError", typeof(PreauthorizedPaymentDetailResx))]
        CardError = 3,

        /// <summary>
        /// Gets or sets ErrorProcessingCapture
        /// </summary>
        [EnumValue("ErrorProcessingCapture", typeof(PreauthorizedPaymentDetailResx))]
        ErrorProcessingCapture = 4,

        /// <summary>
        /// Gets or sets InvoiceSuccessful
        /// </summary>
        [EnumValue("InvoiceSuccessful", typeof(PreauthorizedPaymentDetailResx))]
        InvoiceSuccessful = 5,

        /// <summary>
        /// Gets or sets ErrorCreatingInvoice
        /// </summary>
        [EnumValue("ErrorCreatingInvoice", typeof(PreauthorizedPaymentDetailResx))]
        ErrorCreatingInvoice = 6,

        /// <summary>
        /// Gets or sets PreAuthorizationNotFound
        /// </summary>
        [EnumValue("PreAuthorizationNotFound", typeof(PreauthorizedPaymentDetailResx))]
        PreAuthorizationNotFound = 7,

        /// <summary>
        /// Gets or sets LockedByOtherUser
        /// </summary>
        [EnumValue("LockedByOtherUser", typeof(PreauthorizedPaymentDetailResx))]
        LockedByOtherUser = 8

    }
}