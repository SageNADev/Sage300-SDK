// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for InvoiceStatus
     /// </summary>
     public enum InvoiceStatus
     {
          /// <summary>
          /// Gets or sets Documentshippednotcosted
          /// </summary>
          Documentshippednotcosted = 1,
          /// <summary>
          /// Gets or sets Documentcosted
          /// </summary>
          Documentcosted = 2,
     }
}
