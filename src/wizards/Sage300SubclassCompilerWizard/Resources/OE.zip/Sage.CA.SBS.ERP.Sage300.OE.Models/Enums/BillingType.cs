// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for BillingType
     /// </summary>
     public enum BillingType
     {
          /// <summary>
          /// Gets or sets 
          /// </summary>
          // = 0,
          /// <summary>
          /// Gets or sets Nonbillable
          /// </summary>
          Nonbillable = 1,
          /// <summary>
          /// Gets or sets Billable
          /// </summary>
          Billable = 2,
          /// <summary>
          /// Gets or sets NoCharge
          /// </summary>
          NoCharge = 3,
     }
}
