// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for DefaultOEPrice
     /// </summary>
     public enum DefaultOEPrice
     {
          /// <summary>
          /// Gets or sets 
          /// </summary>
           //= 0,
          /// <summary>
          /// Gets or sets BillingRate
          /// </summary>
          BillingRate = 1,
          /// <summary>
          /// Gets or sets UseCustomerPriceList
          /// </summary>
          UseCustomerPriceList = 2,
          /// <summary>
          /// Gets or sets UseSpecifiedPriceList
          /// </summary>
          UseSpecifiedPriceList = 3,
     }
}
