// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for JobRelated
    /// </summary>
    public enum JobRelated
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>
         [EnumValue("False", typeof(OECommonResx), 0)]
        False = 0,
        /// <summary>
        /// Gets or sets Yes
        /// </summary>
        [EnumValue("True", typeof(OECommonResx), 1)]
        True = 1,
    }
}
