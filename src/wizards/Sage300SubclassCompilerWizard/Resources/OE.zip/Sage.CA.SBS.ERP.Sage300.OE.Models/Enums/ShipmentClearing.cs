// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for ShipmentClearing
     /// </summary>
     public enum ShipmentClearing
     {
          /// <summary>
          /// Gets or sets NotApplicable
          /// </summary>
          NotApplicable = 99,
     }
}
