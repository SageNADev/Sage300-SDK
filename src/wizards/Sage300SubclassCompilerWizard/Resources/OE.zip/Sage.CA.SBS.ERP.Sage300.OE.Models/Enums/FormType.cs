// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for FormType
    /// </summary>
    public enum FormType
    {
        /// <summary>
        /// Gets or sets PreCheck
        /// </summary>
        PreCheck = 0,

        /// <summary>
        /// Gets or sets Credit Approval
        /// </summary>
        CreditApproval = 1
    }
}
