// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Using

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for CreateInvoiceWhenQtyShipped
     /// </summary>
     public enum CreateInvoiceWhenQtyShipped
     {
         /// <summary>
         /// Gets or sets No
         /// </summary>
         [EnumValue("No", typeof(CommonResx), 1)]
         False = 1,

         /// <summary>
         /// Gets or sets Yes
         /// </summary>
         [EnumValue("Yes", typeof(CommonResx), 2)]
         True = 0,
     }
}
