// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for Source Transaction Type
     /// </summary>
     public enum SourceTransactionType
     {
          /// <summary>
          /// Gets or sets Shipment
          /// </summary>
          [EnumValue("Shipment", typeof(GLIntegrationResx), 1)] 
          Shipment = 0,
          /// <summary>
          /// Gets or sets Shipment Detail
          /// </summary>
          [EnumValue("ShipmentDetail", typeof(GLIntegrationResx), 2)] 
          ShipmentDetail = 1,
          /// <summary>
          /// Gets or sets Invoice
          /// </summary>
          [EnumValue("Invoice", typeof(OECommonResx), 3)] 
          Invoice = 2,
          /// <summary>
          /// Gets or sets Invoice Detail
          /// </summary>
          [EnumValue("InvoiceDetail", typeof(GLIntegrationResx), 4)] 
          InvoiceDetail = 3,
          /// <summary>
          /// Gets or sets Credit/Debit Note
          /// </summary>
          [EnumValue("CreditDebitNote", typeof(GLIntegrationResx), 5)]
          CreditDebitNote = 4,
          /// <summary>
          /// Gets or sets Credit/Debit Note Detail
          /// </summary>
          [EnumValue("CreditDebitNoteDetail", typeof(GLIntegrationResx), 6)]
          CreditDebitNoteDetail = 5,
     }
}
