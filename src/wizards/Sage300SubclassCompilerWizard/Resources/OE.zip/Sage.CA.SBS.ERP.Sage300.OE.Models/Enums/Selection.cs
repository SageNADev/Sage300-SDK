// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
	/// <summary>
	/// Enum for Selection
	/// </summary>
	public enum Selection
	{
		/// <summary>
		/// Gets or sets Base
		/// </summary>
        [EnumValue("Base", typeof(OECommonResx))]
		Base1 = 1,

		/// <summary>
		/// Gets or sets Base
		/// </summary>
        [EnumValue("Base", typeof(OECommonResx))]
		Base2 = 2,

		/// <summary>
		/// Gets or sets Base
		/// </summary>
        [EnumValue("Base", typeof(OECommonResx))]
		Base3 = 3,

		/// <summary>
		/// Gets or sets Base
		/// </summary>
        [EnumValue("Base", typeof(OECommonResx))]
		Base4 = 4,

		/// <summary>
		/// Gets or sets Base
		/// </summary>
        [EnumValue("Base", typeof(OECommonResx))]
		Base5 = 5,

		/// <summary>
		/// Gets or sets Base
		/// </summary>
        [EnumValue("Base", typeof(OECommonResx))]
		Base6 = 6,

		/// <summary>
		/// Gets or sets Sale
		/// </summary>
        [EnumValue("Sale", typeof(OECommonResx))]
		Sale = 7,

		/// <summary>
		/// Gets or sets Contract
		/// </summary>
        [EnumValue("Contract", typeof(OECommonResx))]
		Contract = 8
	}
}
