// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
	/// <summary>
	/// Enum for TransactionStatus
	/// </summary>
	public enum TransactionStatus
	{
		/// <summary>
		/// Gets or sets None
		/// </summary>
		[EnumValue("None", typeof(CommonResx))]
		None = 0,

		/// <summary>
		/// Gets or sets PreauthPending
		/// </summary>
		[EnumValue("PreauthPending", typeof(EnumerationsResx))]
		PreauthPending = 1,

		/// <summary>
		/// Gets or sets CapturePending
		/// </summary>
        [EnumValue("CapturePending", typeof(EnumerationsResx))]
		CapturePending = 2,

		/// <summary>
		/// Gets or sets VoidPending
		/// </summary>
		[EnumValue("VoidPending", typeof(EnumerationsResx))]
		VoidPending = 3,

		/// <summary>
		/// Gets or sets Success
		/// </summary>
		[EnumValue("Success", typeof(EnumerationsResx))]
		Success = 4,

		/// <summary>
		/// Gets or sets Captured
		/// </summary>
		[EnumValue("Captured", typeof(EnumerationsResx))]
		Captured = 5,

		/// <summary>
		/// Gets or sets Voided
		/// </summary>
		[EnumValue("Voided", typeof(EnumerationsResx))]
		Voided = 6,

		/// <summary>
		/// Gets or sets CardDeclined
		/// </summary>
        [EnumValue("CardDeclined", typeof(EnumerationsResx))]
		CardDeclined = 7,

		/// <summary>
		/// Gets or sets CardError
		/// </summary>
        [EnumValue("CardError", typeof(EnumerationsResx))]
		CardError = 8
	}
}
