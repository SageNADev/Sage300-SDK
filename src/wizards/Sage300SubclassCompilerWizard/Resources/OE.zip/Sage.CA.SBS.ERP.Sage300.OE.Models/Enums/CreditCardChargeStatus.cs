// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
	/// <summary>
	/// Enum for CreditCardChargeStatus
	/// </summary>
	public enum CreditCardChargeStatus
	{
		/// <summary>
		/// Gets or sets None
		/// </summary>
		[EnumValue("None", typeof(CommonResx))]
		None = 0,

		/// <summary>
		/// Gets or sets Charged
		/// </summary>
		[EnumValue("Charged", typeof(OrderEntryResx))]
		Charged = 1,

		/// <summary>
		/// Gets or sets Voided
		/// </summary>
        [EnumValue("Voided", typeof(OrderEntryResx))]
		Voided = 2,

		/// <summary>
		/// Gets or sets Pending
		/// </summary>
        [EnumValue("Pending", typeof(OrderEntryResx))]
		Pending = 3,

		/// <summary>
		/// Gets or sets CardDeclined
		/// </summary>
        [EnumValue("CardDeclined", typeof(OrderEntryResx))]
		CardDeclined = 4,

		/// <summary>
		/// Gets or sets CardError
		/// </summary>
        [EnumValue("CardError", typeof(OrderEntryResx))]
		CardError = 5
	}
}
