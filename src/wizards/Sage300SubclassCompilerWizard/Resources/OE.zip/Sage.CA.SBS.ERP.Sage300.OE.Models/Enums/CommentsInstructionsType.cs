// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for CommentsInstructionsType
     /// </summary>
     public enum CommentsInstructionsType
     {
          /// <summary>
          /// Gets or sets Comment
          /// </summary>
          [EnumValue("Comment", typeof(OECommonResx))]
          Comment = 1,
          /// <summary>
          /// Gets or sets Instruction
          /// </summary>
          [EnumValue("Instruction", typeof(OECommonResx))]
          Instruction = 2,
     }
}
