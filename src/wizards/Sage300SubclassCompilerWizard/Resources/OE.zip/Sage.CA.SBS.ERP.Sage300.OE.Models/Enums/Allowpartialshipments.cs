// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for Allowpartialshipments
     /// </summary>
     public enum Allowpartialshipments
     {
          /// <summary>
          /// Gets or sets No
          /// </summary>
          [EnumValue("No", typeof(CommonResx), 0)]   
         No = 0,
          /// <summary>
          /// Gets or sets Yes
          /// </summary>
         [EnumValue("Yes", typeof(OECommonResx), 1)]  
         Yes = 1,
     }
}
