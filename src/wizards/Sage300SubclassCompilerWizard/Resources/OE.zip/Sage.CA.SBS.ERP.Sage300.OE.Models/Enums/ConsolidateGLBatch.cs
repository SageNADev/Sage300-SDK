// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for ConsolidateGLBatch
     /// </summary>
     public enum ConsolidateGLBatch
     {
          /// <summary>
          /// Gets or sets DoNotConsolidate
          /// </summary>
          [EnumValue("DoNotConsolidate", typeof(GLIntegrationResx), 1)]
          DoNotConsolidate = 1,
          /// <summary>
          /// Gets or sets ConsolidateTransactionDetailsbyAccount
          /// </summary>
          [EnumValue("ConsolidateTransactionByAccount", typeof(GLIntegrationResx), 2)]
          ConsolidateTransactionDetailsbyAccount = 9,
          /// <summary>
          /// Gets or sets ConsolidatebyAccountAndFiscalPeriod
          /// </summary>
          [EnumValue("ConsolidateAccountFiscalPeriod", typeof(GLIntegrationResx), 3)]
          ConsolidatebyAccountAndFiscalPeriod = 2,
          /// <summary>
          /// Gets or sets ConsolidatebyAccount,FiscalPeriod,AndSource
          /// </summary>
          [EnumValue("ConsolidateAccountFiscalSource", typeof(GLIntegrationResx), 4)]
          ConsolidatebyAccountFiscalPeriodAndSource = 3,
     }
}
