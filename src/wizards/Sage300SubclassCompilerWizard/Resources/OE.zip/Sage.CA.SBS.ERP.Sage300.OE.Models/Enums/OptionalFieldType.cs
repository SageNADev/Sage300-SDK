﻿
// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Name spaces

using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enumeration for OptionalField Type
    /// </summary>
    public enum OptionalFieldType
    {
        /// <summary>
        /// The text
        /// </summary>
        [EnumValue("OptionalFieldType_Text", typeof(EnumerationsResx))]
        Text = 1,

        /// <summary>
        /// The amount
        /// </summary>
        [EnumValue("OptionalFieldType_Amount", typeof(EnumerationsResx))]
        Amount = 100,

        /// <summary>
        /// The number
        /// </summary>
        [EnumValue("OptionalFieldType_Number", typeof(EnumerationsResx))]
        Number = 6,

        /// <summary>
        /// The integer
        /// </summary>
        [EnumValue("OptionalFieldType_Integer", typeof(EnumerationsResx))]
        Integer = 8,

        /// <summary>
        /// The yes no
        /// </summary>
        [EnumValue("OptionalFieldType_YesNo", typeof(EnumerationsResx))]
        YesNo = 9,

        /// <summary>
        /// The date
        /// </summary>
        [EnumValue("OptionalFieldType_Date", typeof(EnumerationsResx))]
        Date = 3,

        /// <summary>
        /// The time
        /// </summary>
        [EnumValue("OptionalFieldType_Time", typeof(EnumerationsResx))]
        Time = 4
    }
}
