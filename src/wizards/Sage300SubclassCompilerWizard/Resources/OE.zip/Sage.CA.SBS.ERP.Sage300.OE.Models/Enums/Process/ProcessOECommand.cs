// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for ProcessOECommand
     /// </summary>
     public enum ProcessOECommand
     {
          /// <summary>
          /// Gets or sets NoAction
          /// </summary>
         [EnumValue("NoAction", typeof(OECommonResx), 0)]
          NoAction = 0,
          /// <summary>
          /// Gets or sets CalculateTax
          /// </summary>
         [EnumValue("CalculateTax", typeof(OECommonResx), 1)] 
         CalculateTax = 1,
          /// <summary>
          /// Gets or sets ForceCalculateTax
          /// </summary>
         [EnumValue("ForceCalculateTax", typeof(OECommonResx), 2)] 
         ForceCalculateTax = 2,
          /// <summary>
          /// Gets or sets DistributeManualTax
          /// </summary>
         [EnumValue("DistributeManualTax", typeof(OECommonResx), 3)] 
         DistributeManualTax = 3,
          /// <summary>
          /// Gets or sets CheckCustomerCreditLimit
          /// </summary>
         [EnumValue("CheckCustomerCreditLimit", typeof(OECommonResx), 4)] 
         CheckCustomerCreditLimit = 4,
          /// <summary>
          /// Gets or sets PreCheckCustomerCreditLimit
          /// </summary>
         [EnumValue("PreCheckCustomerCreditLimit", typeof(OECommonResx), 5)] 
         PreCheckCustomerCreditLimit = 5,
          /// <summary>
          /// Gets or sets ValidateCreditCheckApprovalAuthority
          /// </summary>
         [EnumValue("ValidateCreditCheckApprovalAuthority", typeof(OECommonResx), 6)] 
         ValidateCreditCheckApprovalAuthority = 6,
          /// <summary>
          /// Gets or sets ValidateCreditPreCheckApprovalAuthority
          /// </summary>
         [EnumValue("ValidateCreditPreCheckApprovalAuthority", typeof(OECommonResx), 7)] 
         ValidateCreditPreCheckApprovalAuthority = 7,
          /// <summary>
          /// Gets or sets ShipAll
          /// </summary>
         [EnumValue("ShipAll", typeof(OECommonResx), 8)] 
         ShipAll = 8,
          /// <summary>
          /// Gets or sets RecalculatePaymentScheduleDates
          /// </summary>
         [EnumValue("RecalculatePaymentScheduleDates", typeof(OECommonResx), 9)] 
         RecalculatePaymentScheduleDates = 9,
          /// <summary>
          /// Gets or sets CheckPartialShipment
          /// </summary>
         [EnumValue("CheckPartialShipment", typeof(OECommonResx), 10)] 
         CheckPartialShipment = 10,
          /// <summary>
          /// Gets or sets CreateOrderFromQuotes
          /// </summary>
         [EnumValue("CreateOrderFromQuotes", typeof(OECommonResx), 11)]
         CreateOrderFromQuotes = 11,
          /// <summary>
          /// Gets or sets DeriveTaxReportingRate
          /// </summary>
         [EnumValue("DeriveTaxReportingRate", typeof(OECommonResx), 16)] 
         DeriveTaxReportingRate = 16,
          /// <summary>
          /// Gets or sets CalculateShipmentAmountDue
          /// </summary>
         [EnumValue("CalculateShipmentAmountDue", typeof(OECommonResx), 18)] 
         CalculateShipmentAmountDue = 18,
          /// <summary>
          /// Gets or sets CheckJobRelatedQuoteDetails
          /// </summary>
         [EnumValue("CheckJobRelatedQuoteDetails", typeof(OECommonResx), 19)] 
         CheckJobRelatedQuoteDetails = 19,
          /// <summary>
          /// Gets or sets ValidateJobRelatedPrepayment
          /// </summary>
         [EnumValue("ValidateJobRelatedPrepayment", typeof(OECommonResx), 20)] 
         ValidateJobRelatedPrepayment = 20,
          /// <summary>
          /// Gets or sets DistributePrepaymentToJobDetails
          /// </summary>
         [EnumValue("DistributePrepaymentToJobDetails", typeof(OECommonResx), 21)] 
         DistributePrepaymentToJobDetails = 21,
          /// <summary>
          /// Gets or sets CreateSageCRMAddress
          /// </summary>
         [EnumValue("CreateSageCRMAddress", typeof(OECommonResx), 23)] 
         CreateSageCRMAddress = 23,
          /// <summary>
          /// Gets or sets SetlockForCreditCardTransaction
          /// </summary>
         [EnumValue("SetlockForCreditCardTransaction", typeof(OECommonResx), 24)] 
         SetlockForCreditCardTransaction = 24,
          /// <summary>
          /// Gets or sets FindIncompleteShipmentForaGivenOrder
          /// </summary>
         [EnumValue("FindIncompleteShipmentForaGivenOrder", typeof(OECommonResx), 25)] 
         FindIncompleteShipmentForaGivenOrder = 25,
          /// <summary>
          /// Gets or sets SetlockForeditingadocumentthathasbeenpreauthorized
          /// </summary>
         [EnumValue("SetlockForeditingadocumentthathasbeenpreauthorized", typeof(OECommonResx), 26)] 
         SetlockForeditingadocumentthathasbeenpreauthorized = 26,

         UserHasApprovalAuthWeb=27,

         PreCheckHasApprovalAuthWeb=28,

         /// <summary>
         /// Perform quick pre-authorization of credit card
         /// </summary>
         [EnumValue("QuickPreAuthorize", typeof(OECommonResx), 29)]
         QuickPreAuthorize = 29,

         /// <summary>
         /// Perform quick pre-authorization of credit card for CNA2, Part 1 -  the request XML
         /// </summary>
         [EnumValue("QuickPreAuthorizeCNA2Part1", typeof(OECommonResx), 30)]
         QuickPreAuthorizeCNA2Part1 = 30,

         /// <summary>
         /// Perform quick pre-authorization of credit card for CNA2, Part 2 -  the respond XML
         /// </summary>
         [EnumValue("QuickPreAuthorizeCNA2Part2", typeof(OECommonResx), 31)]
         QuickPreAuthorizeCNA2Part2 = 31,

         UpdateLocationFromHeader = 32,
         UpdateShipDateFromHeader = 33,
     }
}
