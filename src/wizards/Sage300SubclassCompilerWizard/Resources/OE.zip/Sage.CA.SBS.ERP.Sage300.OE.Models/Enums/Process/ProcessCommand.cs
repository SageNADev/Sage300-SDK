// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for ProcessCommand
     /// </summary>
     public enum ProcessCommand
     {
         /// <summary>
         /// Gets or sets NothingToProcess
         /// </summary>
         [EnumValue("NothingToProcess", typeof(OECommonResx), 0)]
         NothingToProcess = 0,
         /// <summary>
         /// Gets or sets InsertOptionalFields
         /// </summary>
         [EnumValue("InsertOptionalFields", typeof(OECommonResx), 1)]
         InsertOptionalFields = 1,
         /// <summary>
         /// Gets or sets DefaultAndTranferOptionalFields
         /// </summary>
         [EnumValue("DefaultAndTranferOptionalFields", typeof(OECommonResx), 2)]
         DefaultAndTranferOptionalFields = 2,
         /// <summary>
         /// Gets or sets DefaultOptFieldsDuringRecordGeneration
         /// </summary>
         [EnumValue("DefaultOptFieldsDuringRecordGeneration", typeof(OECommonResx), 3)]
         DefaultOptFieldsDuringRecordGeneration = 3,
         /// <summary>
         /// Gets or sets RemoveOptionalFields
         /// </summary>
         [EnumValue("RemoveOptionalFields", typeof(OECommonResx), 4)]
         RemoveOptionalFields = 4,
         /// <summary>
         /// Gets or sets TransferOptFieldsFromStandingDocument
         /// </summary>
         [EnumValue("TransferOptFieldsFromStandingDocument", typeof(OECommonResx), 5)]
         TransferOptFieldsFromStandingDocument = 5,
         /// <summary>
         /// Gets or sets AutogenerateSerials
         /// </summary>
         [EnumValue("AutogenerateSerials", typeof(OECommonResx), 21)]
         AutogenerateSerials = 21,
         /// <summary>
         /// Gets or sets AutogenerateLots
         /// </summary>
         [EnumValue("AutogenerateLots", typeof(OECommonResx), 22)]
         AutogenerateLots = 22,
         /// <summary>
         /// Gets or sets AutoallocateSerials
         /// </summary>
         [EnumValue("AutoallocateSerials", typeof(OECommonResx), 23)]
         AutoallocateSerials = 23,
         /// <summary>
         /// Gets or sets AutoallocateLots
         /// </summary>
         [EnumValue("AutoallocateLots", typeof(OECommonResx), 24)]
         AutoallocateLots = 24,
         /// <summary>
         /// Gets or sets ClearSerials
         /// </summary>
         [EnumValue("ClearSerials", typeof(OECommonResx), 25)]
         ClearSerials = 25,
         /// <summary>
         /// Gets or sets ClearLots
         /// </summary>
         [EnumValue("ClearLots", typeof(OECommonResx), 26)]
         ClearLots = 26,
         /// <summary>
         /// Gets or sets AutoassignSerials
         /// </summary>
         [EnumValue("AutoassignSerials", typeof(OECommonResx), 27)]
         AutoassignSerials = 27,
         /// <summary>
         /// Gets or sets AutoassignLots
         /// </summary>
         [EnumValue("AutoassignLots", typeof(OECommonResx), 28)]
         AutoassignLots = 28,
         /// <summary>
         /// Gets or sets CreateListOfExistingSerialsLots
         /// </summary>
         [EnumValue("CreateListOfExistingSerialsLots", typeof(OECommonResx), 29)]
         CreateListOfExistingSerialsLots = 29,
         /// <summary>
         /// Gets or sets PostSerialsLotsToICInventory
         /// </summary>
         [EnumValue("PostSerialsLotsToICInventory", typeof(OECommonResx), 31)]
         PostSerialsLotsToICInventory = 31,
         /// <summary>
         /// Gets or sets VerifySerialsLots
         /// </summary>
         [EnumValue("VerifySerialsLots", typeof(OECommonResx), 32)]
         VerifySerialsLots = 32,
     }
}
