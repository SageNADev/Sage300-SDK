// Copyright © 2017 Sage Software, Inc 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessCommand
    /// </summary>
    public enum ProcessCPICommand
    {
        /// <summary>
        /// Gets or sets NoOperation
        /// </summary>
        [EnumValue("NoOperation", typeof(CapturePaymentsWithInvoiceResx))]
        NoOperation = 0,

        /// <summary>
        /// Gets or sets GenerateResultsTable
        /// </summary>
        [EnumValue("GenerateResultsTable", typeof(CapturePaymentsWithInvoiceResx))]
        GenerateResultsTable = 1,

        /// <summary>
        /// Gets or sets ClearResultsTable
        /// </summary>
        [EnumValue("ClearResultsTable", typeof(CapturePaymentsWithInvoiceResx))]
        ClearResultsTable = 2,

        /// <summary>
        /// Gets or sets DeselectAllResults
        /// </summary>
        [EnumValue("DeselectAllResults", typeof(CapturePaymentsWithInvoiceResx))]
        DeselectAllResults = 3,

        /// <summary>
        /// Gets or sets SelectAllResults
        /// </summary>
        [EnumValue("SelectAllResults", typeof(CapturePaymentsWithInvoiceResx))]
        SelectAllResults = 4,

        /// <summary>
        /// Gets or sets CaptureSelectedOrders
        /// </summary>
        [EnumValue("CaptureSelectedOrders", typeof(CapturePaymentsWithInvoiceResx))]
        CaptureSelectedOrders = 5,

        /// <summary>
        /// Gets or sets CapturePayments
        /// </summary>
        [EnumValue("CapturePayment", typeof(CapturePaymentsWithInvoiceResx))]
        CapturePayment = 6,

        /// <summary>
        /// Gets or sets CapturePaymentsPart1
        /// </summary>
        [EnumValue("CapturePaymentPart1", typeof(CapturePaymentsWithInvoiceResx))]
        CapturePaymentPart1 = 7,

        /// <summary>
        /// Gets or sets CapturePaymentsPart2
        /// </summary>
        [EnumValue("CapturePaymentPart2", typeof(CapturePaymentsWithInvoiceResx))]
        CapturePaymentPart2 = 8,

        /// <summary>
        /// Gets or sets UnlockOrderAndShipment
        /// </summary>
        [EnumValue("UnlockOrderAndShipment", typeof(CapturePaymentsWithInvoiceResx))]
        UnlockOrderAndShipment = 9,

        /// <summary>
        /// Gets or sets UnlockArBatchReceipt
        /// </summary>
        [EnumValue("UnlockArBatchReceipt", typeof(CapturePaymentsWithInvoiceResx))]
        UnlockArBatchReceipt = 10,

        /// <summary>
        /// Gets or sets PostCapturePayment
        /// </summary>
        [EnumValue("PostCapturePayment", typeof(CapturePaymentsWithInvoiceResx))]
        PostCapturePayment = 11

    }
}