// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessNow
    /// </summary>
    public enum ProcessNow
    {
        /// <summary>
        /// Gets or sets QuickCharge
        /// </summary>
        //         [EnumValue("QuickCharge", typeof(OECommonResx))]
        QuickCharge = 1,

        // <summary>
        /// Perform quick pre-charge of credit card for CNA2, Part 1 -  the request XML
        /// </summary>
        //       [EnumValue("QuickChargePrepaymentCNA2Part1", typeof(OECommonResx), 11)]
        QuickChargePrepaymentCNA2Part1 = 11,

        /// <summary>
        /// Perform quick charge of credit card for CNA2, Part 2 -  the respond XML
        /// </summary>
        //     [EnumValue("QuickChargePrepaymentCNA2Part2", typeof(OECommonResx), 12)]
        QuickChargePrepaymentCNA2Part2 = 12,
    }
}
