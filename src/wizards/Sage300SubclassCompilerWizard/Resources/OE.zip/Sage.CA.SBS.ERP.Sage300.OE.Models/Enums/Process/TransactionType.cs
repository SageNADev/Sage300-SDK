// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for TransactionType
     /// </summary>
     public enum TransactionType
     {
          /// <summary>
          /// Gets or sets Invoice
          /// </summary>
          Invoice = 1,
          /// <summary>
          /// Gets or sets CreditNote
          /// </summary>
          CreditNote = 2,
          /// <summary>
          /// Gets or sets Shipment
          /// </summary>
          Shipment = 3,
          /// <summary>
          /// Gets or sets DebitNote
          /// </summary>
          DebitNote = 4,
          /// <summary>
          /// Gets or sets Order
          /// </summary>
          Order = 5,
     }
}
