// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for FlagOperation
     /// </summary>
     public enum FlagOperation
     {
          /// <summary>
          /// Gets or sets NoOperation
          /// </summary>
          NoOperation = 1,
          /// <summary>
          /// Gets or sets PostingJournalsPrinted
          /// </summary>
          PostingJournalsPrinted = 2,
          /// <summary>
          /// Gets or sets OrderConfirmationsPrinted
          /// </summary>
          OrderConfirmationsPrinted = 3,
          /// <summary>
          /// Gets or sets OrderPickingSlipsPrinted
          /// </summary>
          OrderPickingSlipsPrinted = 4,
          /// <summary>
          /// Gets or sets OrderLabelsPrinted
          /// </summary>
          OrderLabelsPrinted = 5,
          /// <summary>
          /// Gets or sets InvoiceLabelsPrinted
          /// </summary>
          InvoiceLabelsPrinted = 6,
          /// <summary>
          /// Gets or sets InvoicesPrinted
          /// </summary>
          InvoicesPrinted = 7,
          /// <summary>
          /// Gets or sets CreditNotesPrinted
          /// </summary>
          CreditNotesPrinted = 8,
          /// <summary>
          /// Gets or sets QuotesPrinted
          /// </summary>
          QuotesPrinted = 9,
          /// <summary>
          /// Gets or sets ShipmentsPickingSlipsPrinted
          /// </summary>
          ShipmentsPickingSlipsPrinted = 10,
          /// <summary>
          /// Gets or sets ShipmentLabelsPrinted
          /// </summary>
          ShipmentLabelsPrinted = 11,
          /// <summary>
          /// Gets or sets DebitNotesPrinted
          /// </summary>
          DebitNotesPrinted = 12,
          /// <summary>
          /// Gets or sets PreprocessOrderHeaderPickingSlips
          /// </summary>
          PreprocessOrderHeaderPickingSlips = 13,
          /// <summary>
          /// Gets or sets PreprocessOrderDetailsPickingSlips
          /// </summary>
          PreprocessOrderDetailsPickingSlips = 14,
          /// <summary>
          /// Gets or sets PreprocessShipmentHeaderPickingSlips
          /// </summary>
          PreprocessShipmentHeaderPickingSlips = 15,
          /// <summary>
          /// Gets or sets PreprocessShipmentDetailsPickingSlips
          /// </summary>
          PreprocessShipmentDetailsPickingSlips = 16,
     }
}
