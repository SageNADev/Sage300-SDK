// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for ReturnType
     /// </summary>
     public enum ReturnType
     {
          /// <summary>
          /// Gets or sets ItemsReturnedToInventory
          /// </summary>
          [EnumValue("ItemsReturnedToInventory", typeof(CreditDebitNoteEntryResx))]
          ItemsReturnedToInventory = 1,
          /// <summary>
          /// Gets or sets DamagedItems
          /// </summary>
          [EnumValue("DamagedItems", typeof(CreditDebitNoteEntryResx))]
          DamagedItems = 2,
          /// <summary>
          /// Gets or sets PriceAdjustment
          /// </summary>
          [EnumValue("PriceAdjustment", typeof(CreditDebitNoteEntryResx))]
          PriceAdjustment = 3,
     }
}
