// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
	/// <summary>
	/// Enum for SubjectToPaymentDiscount
	/// </summary>
	public enum SubjectToPaymentDiscount
	{
		/// <summary>
		/// Gets or sets No
		/// </summary>
		[EnumValue("No", typeof(CommonResx))]
		No = 0,

		/// <summary>
		/// Gets or sets Yes
		/// </summary>
		[EnumValue("Yes", typeof(CommonResx))]
		Yes = 1
	}
}
