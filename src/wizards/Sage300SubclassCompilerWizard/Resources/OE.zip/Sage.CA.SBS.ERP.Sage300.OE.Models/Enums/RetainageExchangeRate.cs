// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for RetainageExchangeRate
     /// </summary>
     public enum RetainageExchangeRate
     {
          /// <summary>
          /// Gets or sets UseOriginalDocumentExchangeRate
          /// </summary>
         [EnumValue("UseOriginalDocumentExchangeRate", typeof(OECommonResx), 0)] 
         UseOriginalDocumentExchangeRate = 0,
          /// <summary>
          /// Gets or sets UseCurrentExchangeRate
          /// </summary>
         [EnumValue("UseCurrentExchangeRate", typeof(OECommonResx), 1)] 
         UseCurrentExchangeRate = 1,
     }
}
