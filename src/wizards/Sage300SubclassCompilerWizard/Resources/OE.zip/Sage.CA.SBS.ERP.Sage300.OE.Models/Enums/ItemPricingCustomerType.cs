﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for DefaultCustomerType
    /// </summary>
    public enum ItemPricingCustomerType
    {
        /// <summary>
        /// Gets or sets Base
        /// </summary>
        [EnumValue("Base", typeof(OECommonResx))]
        Base = 0,
        /// <summary>
        /// Gets or sets A
        /// </summary>
        [EnumValue("A", typeof(OECommonResx))]
        A = 1,
        /// <summary>
        /// Gets or sets B
        /// </summary>
        [EnumValue("B", typeof(OECommonResx))]
        B = 2,
        /// <summary>
        /// Gets or sets C
        /// </summary>
        [EnumValue("C", typeof(OECommonResx))]
        C = 3,
        /// <summary>
        /// Gets or sets D
        /// </summary>
        [EnumValue("D", typeof(OECommonResx))]
        D = 4,
        /// <summary>
        /// Gets or sets E
        /// </summary>
        [EnumValue("E", typeof(OECommonResx))]
        E = 5,

        /// <summary>
        /// get or set Sale
        /// </summary>
        [EnumValue("Sale", typeof(OECommonResx))]
        Sale = 6,

        /// <summary>
        /// The contract
        /// </summary>
        [EnumValue("Contract", typeof(OECommonResx))]
        Contract = 7,
    }
}
