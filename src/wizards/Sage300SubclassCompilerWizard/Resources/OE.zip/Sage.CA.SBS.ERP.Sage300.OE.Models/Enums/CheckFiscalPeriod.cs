// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for CheckFiscalPeriod
     /// </summary>
     public enum CheckFiscalPeriod
     {
          /// <summary>
          /// Gets or sets Num1
          /// </summary>
          [EnumValue("Num1", typeof(OECommonResx), 1)]
          Num1 = 1,
          /// <summary>
          /// Gets or sets Num2
          /// </summary>
          [EnumValue("Num2", typeof(OECommonResx), 2)]
          Num2 = 2,
          /// <summary>
          /// Gets or sets Num3
          /// </summary>
          [EnumValue("Num3", typeof(OECommonResx), 3)]
          Num3 = 3,
          /// <summary>
          /// Gets or sets Num4
          /// </summary>
          [EnumValue("Num4", typeof(OECommonResx), 4)]
          Num4 = 4,
          /// <summary>
          /// Gets or sets Num5
          /// </summary>
          [EnumValue("Num5", typeof(OECommonResx), 5)]
          Num5 = 5,
          /// <summary>
          /// Gets or sets Num6
          /// </summary>
          [EnumValue("Num6", typeof(OECommonResx), 6)]
          Num6 = 6,
          /// <summary>
          /// Gets or sets Num7
          /// </summary>
          [EnumValue("Num7", typeof(OECommonResx), 7)]
          Num7 = 7,
          /// <summary>
          /// Gets or sets Num8
          /// </summary>
          [EnumValue("Num8", typeof(OECommonResx), 8)]
          Num8 = 8,
          /// <summary>
          /// Gets or sets Num9
          /// </summary>
          [EnumValue("Num9", typeof(OECommonResx), 9)]
          Num9 = 9,
          /// <summary>
          /// Gets or sets Num10
          /// </summary>
          [EnumValue("Num10", typeof(OECommonResx), 10)]
          Num10 = 10,
          /// <summary>
          /// Gets or sets Num11
          /// </summary>
          [EnumValue("Num11", typeof(OECommonResx), 11)]
          Num11 = 11,
          /// <summary>
          /// Gets or sets Num12
          /// </summary>
          [EnumValue("Num12", typeof(OECommonResx), 12)]
          Num12 = 12,
     }
}
