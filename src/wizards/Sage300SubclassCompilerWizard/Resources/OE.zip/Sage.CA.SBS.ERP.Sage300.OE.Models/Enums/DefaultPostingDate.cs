// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for DefaultPostingDate
    /// </summary>
    public enum DefaultPostingDate
    {
        /// <summary>
        /// Gets or sets DocumentDate
        /// </summary>
        [EnumValue("DocumentDate", typeof(OECommonResx), 1)]
        DocumentDate = 1,

        /// <summary>
        /// Gets or sets SessionDate
        /// </summary>
        [EnumValue("SessionDate", typeof(CommonResx), 2)]
        SessionDate = 2,
    }
}
