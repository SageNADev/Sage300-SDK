// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
	/// <summary>
	/// Enum for OrderStatus
	/// </summary>
	public enum OrderStatusOther
	{
		/// <summary>
		/// Gets or sets All
		/// </summary>
        [EnumValue("All", typeof(CommonResx), 0)]
		All = 0,

		/// <summary>
		/// Gets or sets Posted
		/// </summary>
        [EnumValue("Posted", typeof(CommonResx))]
		Posted = 1,

		/// <summary>
		/// Gets or sets QuoteConfirmationPrinted
		/// </summary>
        [EnumValue("ConfirmationPrinted", typeof(OECommonResx))]
		QuoteConfirmationPrinted = 2,

		/// <summary>
		/// Gets or sets PickingSlipPrinted
		/// </summary>
        [EnumValue("PickingSlipPrinted", typeof(OECommonResx))]
		PickingSlipPrinted = 3,

		/// <summary>
		/// Gets or sets NeverInvoiced
		/// </summary>
        [EnumValue("NeverInvoiced", typeof(CurrentOrderInquiryResx))]
		NeverInvoiced = 4,

		/// <summary>
		/// Gets or sets PartiallyInvoiced
		/// </summary>
        [EnumValue("PartiallyInvoiced", typeof(CurrentOrderInquiryResx))]
		PartiallyInvoiced = 5,

		/// <summary>
		/// Gets or sets NeverShipped
		/// </summary>
        [EnumValue("NeverShipped", typeof(CurrentOrderInquiryResx))]
		NeverShipped = 6,

		/// <summary>
		/// Gets or sets PartiallyShipped
		/// </summary>
        [EnumValue("PartiallyShipped", typeof(CurrentOrderInquiryResx))]
		PartiallyShipped = 7,

		/// <summary>
		/// Gets or sets Completed
		/// </summary>
        [EnumValue("Completed", typeof(OECommonResx))]
		Completed = 8,

		/// <summary>
		/// Gets or sets OnHold
		/// </summary>
        [EnumValue("OnHold", typeof(OECommonResx))]
		OnHold = 9
	}
}
