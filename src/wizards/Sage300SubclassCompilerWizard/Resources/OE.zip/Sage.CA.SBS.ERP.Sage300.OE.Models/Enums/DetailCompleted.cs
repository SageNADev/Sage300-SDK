// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for DetailCompleted
    /// </summary>
    public enum DetailCompleted
    {
        /// <summary>
        /// Gets or sets Notcompleted
        /// </summary>
        Notcompleted = 0,

        /// <summary>
        /// Gets or sets CompletedNotInDatabase
        /// </summary>
        CompletedNotInDatabase = 1,

        /// <summary>
        /// Gets or sets Completed
        /// </summary>
        Completed = 2,

        /// <summary>
        /// Gets or sets Processedbydayend
        /// </summary>
        Processedbydayend = 3,
    }
}
