// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for MessageType
    /// </summary>
    public enum MessageType
    {
        /// <summary>
        /// Gets or sets Order Confirmation 
        /// </summary>	
        [EnumValue("OrderConfirmation", typeof(EmailMessageResx), 0)]
        OrderConfirmation = 0,

        /// <summary>
        /// Gets or sets Quote 
        /// </summary>	
        [EnumValue("Quote", typeof(OECommonResx), 1)]
        Quote = 1,

        /// <summary>
        /// Gets or sets Invoice 
        /// </summary>	
        [EnumValue("Invoice", typeof(OECommonResx), 2)]
        Invoice = 2,

        /// <summary>
        /// Gets or sets Credit Debit Note 
        /// </summary>	
        [EnumValue("CreditNote", typeof(OECommonResx), 3)]
        CreditDebitNote = 3,
    }
}
