// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for YesNoValue
     /// </summary>
     public enum YesNoValue
     {
          /// <summary>
          /// Gets or sets No
          /// </summary>
         [EnumValue("No", typeof(CommonResx))]
         No = 1,
          /// <summary>
          /// Gets or sets Yes
          /// </summary>
         [EnumValue("Yes", typeof(CommonResx))]
         Yes = 0,
     }
}
