// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for CloseLT
     /// </summary>
     public enum CloseLT
     {
          /// <summary>
          /// Gets or sets No
          /// </summary>
          [EnumValue("No", typeof(CommonResx), 0)]
          False = 0,
          /// <summary>
          /// Gets or sets Yes
          /// </summary>
          [EnumValue("Yes", typeof(CommonResx), 1)]
          True = 1,
     }
}
