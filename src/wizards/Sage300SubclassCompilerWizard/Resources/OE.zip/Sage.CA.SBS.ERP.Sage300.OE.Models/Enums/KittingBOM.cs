// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for KittingBOM
    /// </summary>
    public enum KittingBOM
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("None", typeof(CommonResx))]
        None = 0,

        /// <summary>
        /// Gets or sets Kitting
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Kitting = 1,

        /// <summary>
        /// Gets or sets BOM
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        BOM = 2
    }
}
