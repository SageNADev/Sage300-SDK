// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for CustomerDiscountLevel
     /// </summary>
     public enum CustomerDiscountLevel
     {
          /// <summary>
          /// Gets or sets Base
          /// </summary>
         [EnumValue("Base", typeof(OECommonResx), 0)]  
         Base = 0,
          /// <summary>
          /// Gets or sets A
          /// </summary>
         [EnumValue("A", typeof(OECommonResx), 1)]  
         A = 1,
          /// <summary>
          /// Gets or sets B
          /// </summary>
         [EnumValue("B", typeof(OECommonResx), 2)]  
         B = 2,
          /// <summary>
          /// Gets or sets C
          /// </summary>
         [EnumValue("C", typeof(OECommonResx), 3)]  
         C = 3,
          /// <summary>
          /// Gets or sets D
          /// </summary>
         [EnumValue("D", typeof(OECommonResx), 4)]  
         D = 4,
          /// <summary>
          /// Gets or sets E
          /// </summary>
         [EnumValue("E", typeof(OECommonResx), 5)]  
         E = 5,
     }
}
