// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for OrderSource
     /// </summary>
     public enum OrderSource
     {
          /// <summary>
          /// Gets or sets Entered
          /// </summary>
          [EnumValue("Entered", typeof(OECommonResx), 0)]
          Entered = 0,
          /// <summary>
          /// Gets or sets Internet
          /// </summary>
          [EnumValue("Internet", typeof(OECommonResx), 1)]
          Internet = 1,
          /// <summary>
          /// Gets or sets ElectronicCommerce
          /// </summary>
          [EnumValue("ElectronicCommerce", typeof(OECommonResx), 2)]
          ElectronicCommerce = 2,
          /// <summary>
          /// Gets or sets ePOS
          /// </summary>
          [EnumValue("ePOS", typeof(OECommonResx), 3)]
          ePOS = 3,
     }
}
