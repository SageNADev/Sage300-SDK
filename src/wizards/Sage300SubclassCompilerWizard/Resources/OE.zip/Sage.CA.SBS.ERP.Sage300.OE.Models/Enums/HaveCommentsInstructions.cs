// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Specifies whether the detail line has comments and/or instructions.
     /// </summary>
     public enum HaveCommentsInstructions
     {
          /// <summary>
          /// Specifies that the detail line does not have comments and/or instructions.
          /// </summary>
          [EnumValue("No", typeof(CommonResx))]
          No = 0,
          /// <summary>
          /// Specifies that the detail line has comments and/or instructions.
          /// </summary>
          [EnumValue("Yes", typeof(CommonResx))]
          Yes = 1,
     }
}
