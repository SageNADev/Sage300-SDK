﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    public enum PreAuthorizationStatus
    {       
        /// <summary>
        /// Show PopUp
        /// </summary>
        ShowPopup = 0,

        /// <summary>
        /// Gets or sets DifferentCurrency
        /// </summary>
        DifferentCustomerCurrency = 1,
            
        /// <summary>
        /// Gets or sets CustomerDoesNotExist
        /// </summary>
        CustomerDoesNotExist = 2,

        /// <summary>
        /// Gets or sets ShipmentsCreatedError
        /// </summary>
        ShipmentsCreatedError = 3,

        /// <summary>
        /// Gets or sets OrderTypeError
        /// </summary>
        OrderTypeError=4,

        /// <summary>
        /// Gets or sets CannotCalculateTax
        /// </summary>
        CannotCalculateTax=5,

        /// <summary>
        /// Gets or Sets OnHoldWithPreauthMessage
        /// </summary>
        OnHoldWithPreauthMessage=6,

        /// <summary>
        /// 
        /// </summary>
        NotAllowCapturePreauthWithIncompleteShipment=7,

        NoShipWithPreauthMessage=8
    }
}
