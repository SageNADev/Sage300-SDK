// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.


#region Using

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for ApplyCNToinvoicethatwascre
    /// </summary>
    // ReSharper disable once InconsistentNaming
    public enum ApplyCNToinvoicethatwascre
    {
        /// <summary>
        /// Gets or sets Ignore
        /// </summary>
        [EnumValue("Ignore", typeof(OptionsResx), 1)]
        Ignore = 0,
        /// <summary>
        /// Gets or sets Warning
        /// </summary>
        [EnumValue("Warning", typeof(CommonResx), 2)]
        Warning = 1,
        /// <summary>
        /// Gets or sets Error
        /// </summary>
        [EnumValue("Error", typeof(CommonResx), 3)]
        Error = 2,
    }
}
