// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;


namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for TransType
     /// </summary>
     public enum TransType
     {
          /// <summary>
          /// Gets or sets Invoice
          /// </summary>
          [EnumValue("Invoice", typeof(OECommonResx))]
          Invoice = 1,
          /// <summary>
          /// Gets or sets CreditNote
          /// </summary>
          [EnumValue("CreditNote1", typeof(OECommonResx))]
          CreditNote = 2,
          /// <summary>
          /// Gets or sets DebitNote
          /// </summary>
          [EnumValue("DebitNote", typeof(OECommonResx))]
          DebitNote = 4,
     }
}
