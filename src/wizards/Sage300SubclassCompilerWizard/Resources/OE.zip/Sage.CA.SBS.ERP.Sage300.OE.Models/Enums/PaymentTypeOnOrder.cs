// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for PaymentTypeOnOrder
     /// </summary>
     public enum PaymentTypeOnOrder
     {
          /// <summary>
          /// Gets or sets None
          /// </summary>
          [EnumValue("None", typeof(OECommonResx), 0)] 
         None = 0,
          /// <summary>
          /// Gets or sets Cash
          /// </summary>
          [EnumValue("Cash", typeof(OECommonResx), 1)]
          Cash = 1,
          /// <summary>
          /// Gets or sets Check
          /// </summary>
          [EnumValue("Check", typeof(OECommonResx), 2)]
          Check = 2,
          /// <summary>
          /// Gets or sets CreditCard
          /// </summary>
          [EnumValue("CreditCard", typeof(OECommonResx), 3)]
          CreditCard = 3,
          /// <summary>
          /// Gets or sets Other
          /// </summary>
          [EnumValue("Other", typeof(CommonResx), 4)]
          Other = 4,
          /// <summary>
          /// Gets or sets SPSCreditCard
          /// </summary>
          [EnumValue("SPSCreditCard", typeof(OECommonResx), 5)]
          SPSCreditCard = 5,
     }
}
