// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for DefaultOrderWeightUOM
    /// </summary>
    // ReSharper disable once InconsistentNaming
    public enum DefaultOrderWeightUOM
    {
        /// <summary>
        /// Gets or sets ItemWeightUnit
        /// </summary>
        [EnumValue("ItemWeightUnit", typeof(OptionsResx), 1)]
        ItemWeightUnit = 1,

        /// <summary>
        /// Gets or sets PricingWeightUnit
        /// </summary>
        [EnumValue("PricingWeightUnit", typeof(OptionsResx), 2)]
        PricingWeightUnit = 2,
    }
}
