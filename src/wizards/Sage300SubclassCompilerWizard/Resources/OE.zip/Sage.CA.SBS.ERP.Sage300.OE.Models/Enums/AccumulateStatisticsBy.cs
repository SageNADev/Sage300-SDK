// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Using

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for AccumulateStatisticsBy
    /// </summary>
    public enum AccumulateStatisticsBy
    {
        /// <summary>
        /// Gets or sets CalendarYear
        /// </summary>
        [EnumValue("CalendarYear", typeof(OptionsResx), 1)]
        CalendarYear = 1,

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [EnumValue("FiscalYear", typeof(CommonResx), 2)]
        FiscalYear = 2,
    }
}
