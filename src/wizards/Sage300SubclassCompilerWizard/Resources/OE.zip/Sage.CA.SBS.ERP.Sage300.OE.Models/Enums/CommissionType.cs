// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Using

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for CommissionType
    /// </summary>
    public enum CommissionType
    {
        /// <summary>
        /// Gets or sets Sales
        /// </summary>      
        [EnumValue("Sales", typeof(OptionsResx), 1)]
        Sales = 1,

        /// <summary>
        /// Gets or sets Margin
        /// </summary>
        [EnumValue("Margin", typeof(OptionsResx), 2)]
        Margin = 2,
    }
}
