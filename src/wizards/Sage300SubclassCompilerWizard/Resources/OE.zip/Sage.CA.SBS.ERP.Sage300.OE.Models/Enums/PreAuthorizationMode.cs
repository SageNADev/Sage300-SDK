﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    public enum PreAuthorizationMode
    {
        /// <summary>
        /// Gets or sets PreAuthorization
        /// </summary>
        PreAuthorization=1,

        /// <summary>
        /// Gets or sets Void
        /// </summary>
        Void=2,
    }
}
