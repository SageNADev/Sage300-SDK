// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for PaymentAppliedTo
     /// </summary>
     public enum PaymentAppliedTo
     {
          /// <summary>
          /// Gets or sets InvoiceNo
          /// </summary>
         [EnumValue("InvoiceNumber", typeof(OECommonResx), 2)]
         InvoiceNo = 2,
          /// <summary>
          /// Gets or sets OrderNo
          /// </summary>
         [EnumValue("OrderNumber", typeof(OECommonResx), 2)]
         OrderNo = 4,
          /// <summary>
          /// Gets or sets ShipmentNo
          /// </summary>
         [EnumValue("ShipmentNumber", typeof(OECommonResx), 2)]
         ShipmentNo = 9,
     }
}
