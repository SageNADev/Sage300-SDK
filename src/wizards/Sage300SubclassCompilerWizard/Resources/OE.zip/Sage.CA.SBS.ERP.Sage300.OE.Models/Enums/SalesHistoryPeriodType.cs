// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.


#region Using

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion


namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for SalesHistoryPeriodType
    /// </summary>
    public enum SalesHistoryPeriodType
    {
        /// <summary>
        /// Gets or sets Weekly
        /// </summary>
        [EnumValue("Weekly", typeof(OptionsResx), 1)]
        Weekly = 2,

        /// <summary>
        /// Gets or sets SevenDays
        /// </summary>
        [EnumValue("SevenDays", typeof(OptionsResx), 2)]
        SevenDays = 1,

        /// <summary>
        /// Gets or sets Monthly
        /// </summary>
        [EnumValue("Monthly", typeof(OptionsResx), 3)]
        Monthly = 3,
    }
}
