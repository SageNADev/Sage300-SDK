// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for OrderCompleted
     /// </summary>
     public enum OrderCompleted
     {
          /// <summary>
          /// Gets or sets IncompleteNotIncluded
          /// </summary>
          [EnumValue("IncompleteNotIncluded", typeof(OECommonResx), 1)]
          IncompleteNotIncluded = 1,
          /// <summary>
          /// Gets or sets IncompleteIncluded
          /// </summary>
          [EnumValue("IncompleteIncluded", typeof(OECommonResx), 2)]
          IncompleteIncluded = 2,
          /// <summary>
          /// Gets or sets CompleteNotIncluded
          /// </summary>
          [EnumValue("CompleteNotIncluded", typeof(OECommonResx), 3)]
          CompleteNotIncluded = 3,
          /// <summary>
          /// Gets or sets CompleteIncluded
          /// </summary>
          [EnumValue("CompleteIncluded", typeof(OECommonResx), 4)]
          CompleteIncluded = 4,
          /// <summary>
          /// Gets or sets CompleteDayEnd
          /// </summary>
          [EnumValue("CompleteDayEnd", typeof(OECommonResx), 5)]
          CompleteDayEnd = 5,
     }
}
