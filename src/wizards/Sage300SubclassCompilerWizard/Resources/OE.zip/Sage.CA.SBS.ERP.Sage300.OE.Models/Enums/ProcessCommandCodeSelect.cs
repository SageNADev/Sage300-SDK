/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for the Process Command Code Select
    /// </summary>
    public enum ProcessCommandCodeSelect
    {
        /// <summary>
        /// Gets or sets the Insert Optional Fields 
        /// </summary>	
        [EnumValue("InsertOptionalFields", typeof(EnumerationsResx))]
        InsertOptionalFields = 1,
    }
}
