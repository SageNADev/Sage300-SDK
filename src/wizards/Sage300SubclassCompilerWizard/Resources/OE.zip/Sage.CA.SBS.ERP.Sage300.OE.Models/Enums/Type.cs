// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for Type
     /// </summary>
     public enum Type
     {
          /// <summary>
          /// Gets or sets Text
          /// </summary>
          [EnumValue("Text", typeof(OptionalFieldsResx))] 
          Text = 1,
          /// <summary>
          /// Gets or sets Amount
          /// </summary>
         [EnumValue("Amount", typeof(CommonResx))]  
         Amount = 100,
          /// <summary>
          /// Gets or sets Number
          /// </summary>
         [EnumValue("Number", typeof(OptionalFieldsResx))]  
         Number = 6,
          /// <summary>
          /// Gets or sets Integer
          /// </summary>
         [EnumValue("Integer", typeof(OptionalFieldsResx))]  
         Integer = 8,
          /// <summary>
          /// Gets or sets YesNo
          /// </summary>
         [EnumValue("YesNo", typeof(OptionalFieldsResx))]  
         YesNo = 9,
          /// <summary>
          /// Gets or sets Date
          /// </summary>
         [EnumValue("Date", typeof(CommonResx))]  
         Date = 3,
          /// <summary>
          /// Gets or sets Time
          /// </summary>
         [EnumValue("Time", typeof(OptionalFieldsResx))]
         Time = 4,
     }
}
