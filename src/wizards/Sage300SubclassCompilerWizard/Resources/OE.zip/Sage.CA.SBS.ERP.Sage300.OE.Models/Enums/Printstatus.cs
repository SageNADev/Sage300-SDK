// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
	/// <summary>
	/// Enum for Printstatus
	/// </summary>
	public enum PrintStatus
	{
        /// <summary>
        /// Gets or sets All
        /// </summary>
        [EnumValue("All", typeof(CommonResx), 0)]
        All = 0,

        /// <summary>
        /// Gets or sets Posted
        /// </summary>
        [EnumValue("Posted", typeof(CommonResx))]
        Posted = 1,

		/// <summary>
		/// Gets or sets Quoteprinted
		/// </summary>
        [EnumValue("QuotePrinted", typeof(OECommonResx))]
		QuotePrinted = 2,

		/// <summary>
		/// Gets or sets Pickingslipprinted
		/// </summary>
        [EnumValue("PickingSlipPrinted", typeof(OECommonResx))]
		PickingSlipPrinted = 3,

        /// <summary>
        /// Gets or sets Pickingslipprinted
        /// </summary>
        [EnumValue("OrderConfirmationPrinted", typeof(OECommonResx))]
        OrderConfirmationPrinted = -2,
	 
	}
}
