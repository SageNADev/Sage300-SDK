// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for BillingType
     /// </summary>
    public enum PreCreditCheckStatus
     {
          /// <summary>
          /// Gets or sets 
          /// </summary>
          // = 0,
          /// <summary>
         /// Gets or sets ShowPopup
          /// </summary>
          ShowPopup = 0,
          /// <summary>
          /// Gets or sets NewCustomer
          /// </summary>
          NewCustomer = 1,
          /// <summary>
          /// Gets or sets NoNationalAccount
          /// </summary>
        NoNationalAccount = 2,
        /// <summary>
        /// Gets or sets NoCustomerandNationalAccountCreditCheck
        /// </summary>
        NoCustomerandNationalAccountCreditCheck=3,
        /// <summary>
        /// Customer Passes Credit Check
        /// </summary>
        CustomerPassesCreditCheck =4,
        
     }
}
