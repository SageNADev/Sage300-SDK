﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for Separator
    /// </summary>
    public enum Separator
    {
        /// <summary>
        /// Gets or sets *Asterisk 
        /// </summary>
        [EnumValue("SymbolAsterisk", typeof(CommonResx), 1)]
        Asterisk = 0,

        /// <summary>
        /// Gets or sets Hyphen 
        /// </summary>	
        [EnumValue("SymbolHyphen", typeof(CommonResx), 2)]
        Hyphen = 1,

        /// <summary>
        /// Gets or sets OrForwardSlash 
        /// </summary>
        [EnumValue("SymbolForwardSlash", typeof(CommonResx), 3)]
        ForwardSlash = 2,

        /// <summary>
        /// Gets or sets \BackSlash 
        /// </summary>	
        [EnumValue("SymbolBackslash", typeof(CommonResx), 4)]
        BackSlash = 3,

        /// <summary>
        /// Gets or sets Period 
        /// </summary>
        [EnumValue("SymbolPeriod", typeof(CommonResx), 5)]
        Period = 4,

        /// <summary>
        /// Gets or sets {LeftParenthesis 
        /// </summary>
        [EnumValue("SymbolLeftParenthesis", typeof(CommonResx), 6)]
        LeftParenthesis = 5,

        /// <summary>
        /// Gets or sets }RightParenthesis 
        /// </summary>	
        [EnumValue("SymbolRightParenthesis", typeof(CommonResx), 7)]
        RightParenthesis = 6,

        /// <summary>
        /// Gets or sets #NumberSign 
        /// </summary>
        [EnumValue("SymbolNumberSign", typeof(CommonResx), 8)]
        NumberSign = 7,

        /// <summary>
        /// Gets or sets Space 
        /// </summary>
        [EnumValue("SymbolSpace", typeof(CommonResx), 9)]
        Space = 8
    }
}
