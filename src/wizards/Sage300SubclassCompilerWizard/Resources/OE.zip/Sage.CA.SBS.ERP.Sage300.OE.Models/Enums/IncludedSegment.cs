// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
     /// <summary>
     /// Enum for Included Segment
     /// </summary>
     public enum IncludedSegment
     {
          /// <summary>
          /// Gets or sets None
          /// </summary>
          [EnumValue("None", typeof(CommonResx), 1)] 
          None = 0,

          /// <summary>
          /// Gets or sets Contact Name
          /// </summary>
          [EnumValue("ContactName", typeof(CommonResx), 1)] 
          ContactName = 8,

          /// <summary>
          /// Gets or sets Customer Name
          /// </summary>
          [EnumValue("CustomerName", typeof(OECommonResx), 1)]
          CustomerName = 7,

          /// <summary>
          /// Gets or sets Customer Number
          /// </summary>
          [EnumValue("CustomerNumber", typeof(OECommonResx), 1)]
          CustomerNumber = 6,

          /// <summary>
          /// Gets or sets Day End Number
          /// </summary>
          [EnumValue("DayEndNumber", typeof(OECommonResx), 1)] 
          DayEndNumber = 1,

          /// <summary>
          /// Gets or sets Description
          /// </summary>
          [EnumValue("Description", typeof(Resources.Forms.GLIntegrationResx), 1)]
          Description = 11,

          /// <summary>
          /// Gets or sets Entry Number
          /// </summary>
          [EnumValue("EntryNumber", typeof(OECommonResx), 1)]
          EntryNumber = 3,

          /// <summary>
          /// Gets or sets Order Number
          /// </summary>
          [EnumValue("OrderNumber", typeof(OECommonResx), 1)]
          OrderNumber = 9,

          /// <summary>
          /// Gets or sets Reference
          /// </summary>
          [EnumValue("Reference", typeof(OECommonResx), 1)]
          Reference = 12,

          /// <summary>
          /// Gets or sets Shipment Number
          /// </summary>
          [EnumValue("ShipmentNumber", typeof(OECommonResx), 1)]
          ShipmentNumber = 5,

          /// <summary>
          /// Gets or sets Ship To Location
          /// </summary>
          [EnumValue("ShipToLocation", typeof(OECommonResx), 1)]
          ShipToLocation = 13,

          /// <summary>
          /// Gets or sets Ship Via
          /// </summary>
          [EnumValue("ShipVia", typeof(OECommonResx), 1)]
          ShipVia = 14,

          /// <summary>
          /// Gets or sets Ship Via Description
          /// </summary>
          [EnumValue("ShipViaDescription", typeof(OECommonResx), 1)]
          ShipViaDescription = 15,

          /// <summary>
          /// Gets or sets Source Code
          /// </summary>
          [EnumValue("SourceCode", typeof(Resources.Forms.GLIntegrationResx), 1)]
          SourceCode = 2,
     }
}
