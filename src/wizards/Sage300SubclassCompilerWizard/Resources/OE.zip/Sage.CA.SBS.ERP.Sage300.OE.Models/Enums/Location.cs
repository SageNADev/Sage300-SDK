// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Enums
{
    /// <summary>
    /// Enum for Location
    /// </summary>
    public enum Location
    {
        /// <summary>
        /// Gets or sets MiscellaneousCharges
        /// </summary>
        [EnumValue("MiscellaneousCharges", typeof(OptionalFieldsResx))]
        MiscellaneousCharges = 0,
        /// <summary>
        /// Gets or sets Orders
        /// </summary>
        [EnumValue("Orders", typeof(OptionalFieldsResx))]
        Orders = 1,
        /// <summary>
        /// Gets or sets OrderDetails
        /// </summary>
        [EnumValue("OrderDetails", typeof(OptionalFieldsResx))]
        OrderDetails = 2,
        /// <summary>
        /// Gets or sets Shipments
        /// </summary>
        [EnumValue("Shipments", typeof(OptionalFieldsResx))]
        Shipments = 3,
        /// <summary>
        /// Gets or sets ShipmentDetails
        /// </summary>
        [EnumValue("ShipmentDetails", typeof(OptionalFieldsResx))]
        ShipmentDetails = 4,
        /// <summary>
        /// Gets or sets Invoices
        /// </summary>
        [EnumValue("Invoices", typeof(OECommonResx))]
        Invoices = 5,
        /// <summary>
        /// Gets or sets InvoiceDetails
        /// </summary>
        [EnumValue("InvoiceDetails", typeof(OptionalFieldsResx))]
        InvoiceDetails = 6,
        /// <summary>
        /// Gets or sets CreditDebitNotes
        /// </summary>
        [EnumValue("CreditDebitNotes", typeof(OptionalFieldsResx))]
        CreditDebitNotes = 7,
        /// <summary>
        /// Gets or sets CreditDebitNoteDetails
        /// </summary>
        [EnumValue("CreditDebitNoteDetails", typeof(OptionalFieldsResx))]
        CreditDebitNoteDetails = 8,
    }
}
