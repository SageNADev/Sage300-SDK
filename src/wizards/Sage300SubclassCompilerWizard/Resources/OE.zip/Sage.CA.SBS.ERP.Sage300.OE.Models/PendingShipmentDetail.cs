// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Model class for PendingShipmentDetail
    /// </summary>
    public partial class PendingShipmentDetail : ModelBase
    {
        /// <summary>
        /// Pending Shipment Detail
        /// </summary>
        public PendingShipmentDetail()
        {
            PendingShipmentDetails = new EnumerableResponse<PendingShipmentDetail>();
        }

        /// <summary>
        /// Gets or sets OrderUniquifier
        /// </summary>
        [Key]
        [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal OrderUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets FromExpectedShipmentDate
        /// </summary>
        [ViewField(Name = Fields.FromExpectedShipmentDate, Id = Index.FromExpectedShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FromExpectedShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets ToExpectedShipmentDate
        /// </summary>
        [ViewField(Name = Fields.ToExpectedShipmentDate, Id = Index.ToExpectedShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ToExpectedShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets FromItemNumber
        /// </summary>
        [ViewField(Name = Fields.FromItemNumber, Id = Index.FromItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string FromItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ToItemNumber
        /// </summary>
        [ViewField(Name = Fields.ToItemNumber, Id = Index.ToItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string ToItemNumber { get; set; }

        /// <summary>
        /// Gets or sets FromLocation
        /// </summary>
        [ViewField(Name = Fields.FromLocation, Id = Index.FromLocation, FieldType = EntityFieldType.Char, Size = 6)]
        public string FromLocation { get; set; }

        /// <summary>
        /// Gets or sets ToLocation
        /// </summary>
        [ViewField(Name = Fields.ToLocation, Id = Index.ToLocation, FieldType = EntityFieldType.Char, Size = 6)]
        public string ToLocation { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ExpectedShipmentDate
        /// </summary>
        [ViewField(Name = Fields.ExpectedShipmentDate, Id = Index.ExpectedShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpectedShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6)]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCode
        /// </summary>
        [ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaDescription
        /// </summary>
        [ViewField(Name = Fields.ShipViaDescription, Id = Index.ShipViaDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaDescription { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets QuantityOrdered
        /// </summary>
        [ViewField(Name = Fields.QuantityOrdered, Id = Index.QuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitOfMeasure
        /// </summary>
        [ViewField(Name = Fields.OrderUnitOfMeasure, Id = Index.OrderUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string OrderUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets QuantityCommitted
        /// </summary>
        [ViewField(Name = Fields.QuantityCommitted, Id = Index.QuantityCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityCommitted { get; set; }

        /// <summary>
        /// Gets or sets QuantityAvailable
        /// </summary>
        [ViewField(Name = Fields.QuantityAvailable, Id = Index.QuantityAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityAvailable { get; set; }

        /// <summary>
        /// Gets or sets OnPurchaseOrder
        /// </summary>
        [ViewField(Name = Fields.OnPurchaseOrder, Id = Index.OnPurchaseOrder, FieldType = EntityFieldType.Bool, Size = 2)]
        public OnPurchaseOrder OnPurchaseOrder { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderDescription
        /// </summary>
        public string OrderDescription { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets SalesPersonInquiryDetails
        /// </summary>
        public EnumerableResponse<PendingShipmentDetail> PendingShipmentDetails { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets OnPurchaseOrder string value
        /// </summary>
        public string OnPurchaseOrderString
        {
            get { return EnumUtility.GetStringValue(OnPurchaseOrder); }
        }

        #endregion
    }
}
