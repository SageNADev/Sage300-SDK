// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Partial class for ItemPricing
	/// </summary>
	public partial class ItemPricing : ModelBase
	{
		/// <summary>
		/// Gets or sets Currency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string Currency { get; set; }

		/// <summary>
		/// Gets or sets Item
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Item, Id = Index.Item, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string Item { get; set; }

		/// <summary>
		/// Gets or sets PriceList
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string PriceList { get; set; }

		/// <summary>
		/// Gets or sets Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string Description { get; set; }

		/// <summary>
		/// Gets or sets Location
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string Location { get; set; }

		/// <summary>
		/// Gets or sets OrderQuantity
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OrderQuantity, Id = Index.OrderQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal OrderQuantity { get; set; }

		/// <summary>
		/// Gets or sets OrderUOM
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OrderUOM, Id = Index.OrderUOM, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string OrderUOM { get; set; }

		/// <summary>
		/// Gets or sets OrderDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime OrderDate { get; set; }

		/// <summary>
		/// Gets or sets TaxGroup
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string TaxGroup { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority1
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string TaxAuthority1 { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority2
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string TaxAuthority2 { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority3
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string TaxAuthority3 { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority4
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string TaxAuthority4 { get; set; }

		/// <summary>
		/// Gets or sets TaxAuthority5
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string TaxAuthority5 { get; set; }

		/// <summary>
		/// Gets or sets ItemTaxClass1
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemTaxClass1, Id = Index.ItemTaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
		public int ItemTaxClass1 { get; set; }

		/// <summary>
		/// Gets or sets ItemTaxClass2
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemTaxClass2, Id = Index.ItemTaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
		public int ItemTaxClass2 { get; set; }

		/// <summary>
		/// Gets or sets ItemTaxClass3
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemTaxClass3, Id = Index.ItemTaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
		public int ItemTaxClass3 { get; set; }

		/// <summary>
		/// Gets or sets ItemTaxClass4
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemTaxClass4, Id = Index.ItemTaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
		public int ItemTaxClass4 { get; set; }

		/// <summary>
		/// Gets or sets ItemTaxClass5
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemTaxClass5, Id = Index.ItemTaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
		public int ItemTaxClass5 { get; set; }

		/// <summary>
		/// Gets or sets ItemTaxIncluded1
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemTaxIncluded1, Id = Index.ItemTaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
		public int ItemTaxIncluded1 { get; set; }

		/// <summary>
		/// Gets or sets ItemTaxIncluded2
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemTaxIncluded2, Id = Index.ItemTaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
		public int ItemTaxIncluded2 { get; set; }

		/// <summary>
		/// Gets or sets ItemTaxIncluded3
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemTaxIncluded3, Id = Index.ItemTaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
		public int ItemTaxIncluded3 { get; set; }

		/// <summary>
		/// Gets or sets ItemTaxIncluded4
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemTaxIncluded4, Id = Index.ItemTaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
		public int ItemTaxIncluded4 { get; set; }

		/// <summary>
		/// Gets or sets ItemTaxIncluded5
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ItemTaxIncluded5, Id = Index.ItemTaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
		public int ItemTaxIncluded5 { get; set; }

		/// <summary>
		/// Gets or sets CustomerTaxClass1
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustomerTaxClass1, Id = Index.CustomerTaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
		public int CustomerTaxClass1 { get; set; }

		/// <summary>
		/// Gets or sets CustomerTaxClass2
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustomerTaxClass2, Id = Index.CustomerTaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
		public int CustomerTaxClass2 { get; set; }

		/// <summary>
		/// Gets or sets CustomerTaxClass3
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustomerTaxClass3, Id = Index.CustomerTaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
		public int CustomerTaxClass3 { get; set; }

		/// <summary>
		/// Gets or sets CustomerTaxClass4
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustomerTaxClass4, Id = Index.CustomerTaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
		public int CustomerTaxClass4 { get; set; }

		/// <summary>
		/// Gets or sets CustomerTaxClass5
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustomerTaxClass5, Id = Index.CustomerTaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
		public int CustomerTaxClass5 { get; set; }

		/// <summary>
		/// Gets or sets BasePrice
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BasePrice, Id = Index.BasePrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal BasePrice { get; set; }

		/// <summary>
		/// Gets or sets StandardCost
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.StandardCost, Id = Index.StandardCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal StandardCost { get; set; }

		/// <summary>
		/// Gets or sets MostRecentCost
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.MostRecentCost, Id = Index.MostRecentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal MostRecentCost { get; set; }

		/// <summary>
		/// Gets or sets Cost1
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Cost1, Id = Index.Cost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal Cost1 { get; set; }

		/// <summary>
		/// Gets or sets Cost2
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Cost2, Id = Index.Cost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal Cost2 { get; set; }

		/// <summary>
		/// Gets or sets BaseUnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BaseUnitOfMeasure, Id = Index.BaseUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string BaseUnitOfMeasure { get; set; }

		/// <summary>
		/// Gets or sets BaseConversionFactor
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BaseConversionFactor, Id = Index.BaseConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal BaseConversionFactor { get; set; }

		/// <summary>
		/// Gets or sets PriceType
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PriceType, Id = Index.PriceType, FieldType = EntityFieldType.Int, Size = 2)]
		public int PriceType { get; set; }

		/// <summary>
		/// Gets or sets PriceBase
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PriceBase, Id = Index.PriceBase, FieldType = EntityFieldType.Int, Size = 2)]
		public int PriceBase { get; set; }

		/// <summary>
		/// Gets or sets PriceFormat
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PriceFormat, Id = Index.PriceFormat, FieldType = EntityFieldType.Int, Size = 2)]
		public int PriceFormat { get; set; }

		/// <summary>
		/// Gets or sets Selection
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Selection, Id = Index.Selection, FieldType = EntityFieldType.Int, Size = 2)]
		public Selection Selection { get; set; }

		/// <summary>
		/// Gets or sets KeyPrice
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.KeyPrice, Id = Index.KeyPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal KeyPrice { get; set; }

		/// <summary>
		/// Gets or sets KeyUnit
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.KeyUnit, Id = Index.KeyUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string KeyUnit { get; set; }

		/// <summary>
		/// Gets or sets Quantity
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal Quantity { get; set; }

		/// <summary>
		/// Gets or sets CustomerType
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.CustomerType, Id = Index.CustomerType, FieldType = EntityFieldType.Int, Size = 2)]
        public ItemPricingCustomerType CustomerType { get; set; }

		/// <summary>
		/// Gets or sets Percentage
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Percentage, Id = Index.Percentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
		public decimal Percentage { get; set; }

		/// <summary>
		/// Gets or sets Amount
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal Amount { get; set; }

		/// <summary>
		/// Gets or sets UnitPrice
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.UnitPrice, Id = Index.UnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal UnitPrice { get; set; }

		/// <summary>
		/// Gets or sets PricingUOM
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PricingUOM, Id = Index.PricingUOM, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string PricingUOM { get; set; }

		/// <summary>
		/// Gets or sets PriceConversionFactor
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PriceConversionFactor, Id = Index.PriceConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal PriceConversionFactor { get; set; }

		/// <summary>
		/// Gets or sets UnitPriceOrderUOM
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.UnitPriceOrderUOM, Id = Index.UnitPriceOrderUOM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal UnitPriceOrderUOM { get; set; }

		/// <summary>
		/// Gets or sets PriceDecimals
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PriceDecimals, Id = Index.PriceDecimals, FieldType = EntityFieldType.Int, Size = 2)]
		public int PriceDecimals { get; set; }

		/// <summary>
		/// Gets or sets CustomerNumber
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12)]
		public string CustomerNumber { get; set; }

		/// <summary>
		/// Gets or sets Category
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6)]
		public string Category { get; set; }

		/// <summary>
		/// Gets or sets StockingUnit
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.StockingUnit, Id = Index.StockingUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string StockingUnit { get; set; }

		/// <summary>
		/// Gets or sets KeyOrderUnit
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.KeyOrderUnit, Id = Index.KeyOrderUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string KeyOrderUnit { get; set; }

		/// <summary>
		/// Gets or sets ShowErrors
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ShowErrors, Id = Index.ShowErrors, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool ShowErrors { get; set; }

		/// <summary>
		/// Gets or sets AverageCost
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.AverageCost, Id = Index.AverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal AverageCost { get; set; }

		/// <summary>
		/// Gets or sets LastCost
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.LastCost, Id = Index.LastCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal LastCost { get; set; }

		/// <summary>
		/// Gets or sets OrderWeight
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OrderWeight, Id = Index.OrderWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal OrderWeight { get; set; }

		/// <summary>
		/// Gets or sets Weight
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Weight, Id = Index.Weight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal Weight { get; set; }

		/// <summary>
		/// Gets or sets OrderWeightUOM
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OrderWeightUOM, Id = Index.OrderWeightUOM, FieldType = EntityFieldType.Char, Size = 10)]
		public string OrderWeightUOM { get; set; }

		/// <summary>
		/// Gets or sets BaseWeightUOM
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BaseWeightUOM, Id = Index.BaseWeightUOM, FieldType = EntityFieldType.Char, Size = 10)]
		public string BaseWeightUOM { get; set; }

		/// <summary>
		/// Gets or sets BaseWeightConversionFactor
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BaseWeightConversionFactor, Id = Index.BaseWeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal BaseWeightConversionFactor { get; set; }

		/// <summary>
		/// Gets or sets KeyWeightUnit
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.KeyWeightUnit, Id = Index.KeyWeightUnit, FieldType = EntityFieldType.Char, Size = 10)]
		public string KeyWeightUnit { get; set; }

		/// <summary>
		/// Gets or sets PricingWeightUOM
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PricingWeightUOM, Id = Index.PricingWeightUOM, FieldType = EntityFieldType.Char, Size = 10)]
		public string PricingWeightUOM { get; set; }

		/// <summary>
		/// Gets or sets PriceWeightConversionFactor
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PriceWeightConversionFactor, Id = Index.PriceWeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal PriceWeightConversionFactor { get; set; }

		/// <summary>
		/// Gets or sets DefaultWeightUOM
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.DefaultWeightUOM, Id = Index.DefaultWeightUOM, FieldType = EntityFieldType.Char, Size = 10)]
		public string DefaultWeightUOM { get; set; }

		/// <summary>
		/// Gets or sets KeyOrderWeightUnit
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.KeyOrderWeightUnit, Id = Index.KeyOrderWeightUnit, FieldType = EntityFieldType.Char, Size = 10)]
		public string KeyOrderWeightUnit { get; set; }

		/// <summary>
		/// Gets or sets PriceBy
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PriceBy, Id = Index.PriceBy, FieldType = EntityFieldType.Int, Size = 2)]
		public PriceBy PriceBy { get; set; }

		/// <summary>
		/// Gets or sets SetTaxIncluded
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.SetTaxIncluded, Id = Index.SetTaxIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool SetTaxIncluded { get; set; }

		/// <summary>
		/// Gets or sets ProcessCommand
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
		public int ProcessCommand { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets Selection string value
		/// </summary>
		public string SelectionString
		{
			get { return EnumUtility.GetStringValue(Selection); }
		}

		/// <summary>
		/// Gets CustomerType string value
		/// </summary>
		public string CustomerTypeString
		{
			get { return EnumUtility.GetStringValue(CustomerType); }
		}

		/// <summary>
		/// Gets PriceBy string value
		/// </summary>
		public string PriceByString
		{
			get { return EnumUtility.GetStringValue(PriceBy); }
		}

		#endregion
	}
}
