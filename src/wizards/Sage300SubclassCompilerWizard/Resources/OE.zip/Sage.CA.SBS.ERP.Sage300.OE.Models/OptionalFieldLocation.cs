// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for OptionalFieldLocation
    /// </summary>
    public partial class OptionalFieldLocation : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the Optional Field Header/> class.
        /// </summary>
        public OptionalFieldLocation()
        {
            OptionalFieldDetails = new EnumerableResponse<OptionalFieldDetail>();
        }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Location Location { get; set; }

        /// <summary>
        /// Gets or sets NumberOfValues
        /// </summary>
        [Display(Name = "NumberOfValues", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.NumberOfValues, Id = Index.NumberOfValues, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfValues { get; set; }

        /// <summary>
        /// Gets or sets Optional Field details list
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<OptionalFieldDetail> OptionalFieldDetails { get; set; }
    }
}
