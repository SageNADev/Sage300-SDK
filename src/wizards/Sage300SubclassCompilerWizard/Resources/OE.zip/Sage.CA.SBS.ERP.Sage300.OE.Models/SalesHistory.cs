// Copyright (c) 1994-2015 Sage Software, Inc. All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for SalesHistory Items
    /// </summary>
    public partial class SalesHistory : ModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Year
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4)]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Int, Size = 2)]
        public int Period { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        // It is required to assign Home Currency of OE Options
        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string FunctionalCurrency { get; set; }

        // It is required to display the Decimal values
        /// <summary>
        /// Gets or Sets the Currency Decimal
        /// </summary>
        [IgnoreExportImport]
        public string CurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets QuantitySold
        /// </summary>
        [Display(Name = "QuantitySold", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantitySold, Id = Index.QuantitySold, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantitySold { get; set; }

        /// <summary>
        /// Gets or sets FuncSalesAmount
        /// </summary>
        [Display(Name = "FuncSalesAmount", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.FuncSalesAmount, Id = Index.FuncSalesAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncSalesAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceSalesAmount
        /// </summary>
        [Display(Name = "SrceSalesAmount", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.SrceSalesAmount, Id = Index.SrceSalesAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceSalesAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCostOfSales
        /// </summary>
        [Display(Name = "FuncCostOfSales", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.FuncCostOfSales, Id = Index.FuncCostOfSales, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCostOfSales { get; set; }

        /// <summary>
        /// Gets or sets SrceCostOfSales
        /// </summary>
        [Display(Name = "SrceCostOfSales", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.SrceCostOfSales, Id = Index.SrceCostOfSales, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceCostOfSales { get; set; }

        /// <summary>
        /// Gets or sets SalesCount
        /// </summary>
        [Display(Name = "SalesCount", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.SalesCount, Id = Index.SalesCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int SalesCount { get; set; }

        /// <summary>
        /// Gets or sets ReturnsCount
        /// </summary>
        [Display(Name = "ReturnsCount", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.ReturnsCount, Id = Index.ReturnsCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReturnsCount { get; set; }

        /// <summary>
        /// Gets or sets FuncReturnAmount
        /// </summary>
        [Display(Name = "FuncReturnAmount", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.FuncReturnAmount, Id = Index.FuncReturnAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncReturnAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceReturnAmount
        /// </summary>
        [Display(Name = "SrceReturnAmount", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.SrceReturnAmount, Id = Index.SrceReturnAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceReturnAmount { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets FuncProfitMargin
        /// </summary>
        [Display(Name = "FuncProfitMargin", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.FuncProfitMargin, Id = Index.FuncProfitMargin, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal FuncProfitMargin { get; set; }

        /// <summary>
        /// Gets or sets SrceProfitMargin
        /// </summary>
        [Display(Name = "FuncProfitMargin", ResourceType = typeof(SalesHistoryResx))]
        [ViewField(Name = Fields.SrceProfitMargin, Id = Index.SrceProfitMargin, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SrceProfitMargin { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        #region Extra Properties

        /// <summary>
        /// Has IC Inquire Rights
        /// </summary>
        [IgnoreExportImport]
        public bool HasICCostInquiryRights { get; set; }

        /// <summary>
        /// Gets or sets From Year
        /// </summary>
        [IgnoreExportImport]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets To Year
        /// </summary>
        [IgnoreExportImport]
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or sets From Period
        /// </summary>
        [IgnoreExportImport]
        public int FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets To Period
        /// </summary>
        [IgnoreExportImport]
        public int ToPeriod { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        /// <value>Type</value>
        [IgnoreExportImport]
        [Display(Name = "SelectBy", ResourceType = typeof(SalesHistoryResx))]
        public SelectedBy SelectBy { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        /// <value>Type</value>
        [IgnoreExportImport]
        public Enums.Currency CurrencyType { get; set; }

        #endregion
    }
}
