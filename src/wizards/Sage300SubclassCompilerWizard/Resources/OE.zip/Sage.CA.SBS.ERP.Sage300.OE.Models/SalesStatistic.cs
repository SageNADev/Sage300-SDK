// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for SalesStatistic
    /// </summary>
    public partial class SalesStatistic : ModelBase
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SalesStatistic()
        {
            SalesList = new EnumerableResponse<Sales>();
            InvoicesAndCreditDebitNotesList = new EnumerableResponse<InvoicesAndCreditDebitNotes>();
        }

        /// <summary>
        /// Gets or sets Year
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Int, Size = 2)]
        public string Period { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof (OECommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOrders
        /// </summary>	
        [Display(Name = "AUINoOfOrdersCap", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.NumberOfOrders, Id = Index.NumberOfOrders, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfOrders { get; set; }

        /// <summary>
        /// Gets or sets NetQuantitySold
        /// </summary>		
        [Display(Name = "AUINetQtySoldCap", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.NetQuantitySold, Id = Index.NetQuantitySold, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NetQuantitySold { get; set; }

        /// <summary>
        /// Gets or sets NetSalesAmountFunc
        /// </summary>	
        [Display(Name = "NetSalesAmountFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.NetSalesAmountFunc, Id = Index.NetSalesAmountFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetSalesAmountFunc { get; set; }

        /// <summary>
        /// Gets or sets NetSalesAmountSrce
        /// </summary>
        [Display(Name = "NetSalesAmountSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.NetSalesAmountSrce, Id = Index.NetSalesAmountSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetSalesAmountSrce { get; set; }

        /// <summary>
        /// Gets or sets NetInvoiceAmountFunc
        /// </summary>		
        [Display(Name = "NetInvoiceAmountFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.NetInvoiceAmountFunc, Id = Index.NetInvoiceAmountFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetInvoiceAmountFunc { get; set; }

        /// <summary>
        /// Gets or sets NetInvoiceAmountSrce
        /// </summary>		
        [Display(Name = "NetInvoiceAmountSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.NetInvoiceAmountSrce, Id = Index.NetInvoiceAmountSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetInvoiceAmountSrce { get; set; }

        /// <summary>
        /// Gets or sets CostOfSalesFunc
        /// </summary>		
        [Display(Name = "CostOfSalesFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.CostOfSalesFunc, Id = Index.CostOfSalesFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostOfSalesFunc { get; set; }

        /// <summary>
        /// Gets or sets CostOfSalesSrce
        /// </summary>		
        [Display(Name = "CostOfSalesSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.CostOfSalesSrce, Id = Index.CostOfSalesSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostOfSalesSrce { get; set; }

        /// <summary>
        /// Gets or sets NumberOfInvoices
        /// </summary>	
        [Display(Name = "NumberOfInvoices", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.NumberOfInvoices, Id = Index.NumberOfInvoices, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfInvoices { get; set; }

        /// <summary>
        /// Gets or sets AverageInvoiceFunc
        /// </summary>	
        [Display(Name = "AverageInvoiceFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.AverageInvoiceFunc, Id = Index.AverageInvoiceFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AverageInvoiceFunc { get; set; }

        /// <summary>
        /// Gets or sets AverageInvoiceSrce
        /// </summary>	
        [Display(Name = "AverageInvoiceSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.AverageInvoiceSrce, Id = Index.AverageInvoiceSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AverageInvoiceSrce { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceFunc
        /// </summary>	
        [Display(Name = "LargestInvoiceFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.LargestInvoiceFunc, Id = Index.LargestInvoiceFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvoiceFunc { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceSrce
        /// </summary>		
        [Display(Name = "LargestInvoiceSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.LargestInvoiceSrce, Id = Index.LargestInvoiceSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvoiceSrce { get; set; }

        /// <summary>
        /// Gets or sets CustomerLargestInvoice
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CustomerLargestInvoice", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.CustomerLargestInvoice, Id = Index.CustomerLargestInvoice, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerLargestInvoice { get; set; }

        /// <summary>
        /// Gets or sets SmallestInvoiceFunc
        /// </summary>
        [Display(Name = "SmallestInvoiceFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SmallestInvoiceFunc, Id = Index.SmallestInvoiceFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SmallestInvoiceFunc { get; set; }

        /// <summary>
        /// Gets or sets SmallestInvoiceSrce
        /// </summary>		
        [Display(Name = "SmallestInvoiceSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SmallestInvoiceSrce, Id = Index.SmallestInvoiceSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SmallestInvoiceSrce { get; set; }

        /// <summary>
        /// Gets or sets CustomerSmallestInvoice
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CustomerSmallestInvoice", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.CustomerSmallestInvoice, Id = Index.CustomerSmallestInvoice, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerSmallestInvoice { get; set; }

        /// <summary>
        /// Gets or sets NumberOfCreditNotes
        /// </summary>	
        [Display(Name = "NumberOfCreditNotes", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.NumberOfCreditNotes, Id = Index.NumberOfCreditNotes, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfCreditNotes { get; set; }

        /// <summary>
        /// Gets or sets AverageCreditNoteFunc
        /// </summary>		
        [Display(Name = "AverageCreditNoteFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.AverageCreditNoteFunc, Id = Index.AverageCreditNoteFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AverageCreditNoteFunc { get; set; }

        /// <summary>
        /// Gets or sets AverageCreditNoteSrce
        /// </summary>		
        [Display(Name = "AverageCreditNoteSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.AverageCreditNoteSrce, Id = Index.AverageCreditNoteSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AverageCreditNoteSrce { get; set; }

        /// <summary>
        /// Gets or sets LargestCreditNoteFunc
        /// </summary>	
        [Display(Name = "LargestCreditNoteFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.LargestCreditNoteFunc, Id = Index.LargestCreditNoteFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestCreditNoteFunc { get; set; }

        /// <summary>
        /// Gets or sets LargestCreditNoteSrce
        /// </summary>		
        [Display(Name = "LargestCreditNoteSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.LargestCreditNoteSrce, Id = Index.LargestCreditNoteSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestCreditNoteSrce { get; set; }

        /// <summary>
        /// Gets or sets CustomerLargestCreditNote
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CustomerLargestCreditNote", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.CustomerLargestCreditNote, Id = Index.CustomerLargestCreditNote, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerLargestCreditNote { get; set; }

        /// <summary>
        /// Gets or sets SmallestCreditNoteFunc
        /// </summary>	
        [Display(Name = "SmallestCreditNoteFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SmallestCreditNoteFunc, Id = Index.SmallestCreditNoteFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SmallestCreditNoteFunc { get; set; }

        /// <summary>
        /// Gets or sets SmallestCreditNoteSrce
        /// </summary>	
        [Display(Name = "SmallestCreditNoteSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SmallestCreditNoteSrce, Id = Index.SmallestCreditNoteSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SmallestCreditNoteSrce { get; set; }

        /// <summary>
        /// Gets or sets TotalSalesLostFunc
        /// </summary>		
        [Display(Name = "TotalSalesLostFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.TotalSalesLostFunc, Id = Index.TotalSalesLostFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalSalesLostFunc { get; set; }

        /// <summary>
        /// Gets or sets TotalSalesLostSrce
        /// </summary>		
        [Display(Name = "TotalSalesLostSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.TotalSalesLostSrce, Id = Index.TotalSalesLostSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalSalesLostSrce { get; set; }

        /// <summary>
        /// Gets or sets CustomerSmallestCreditNote
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CustomerSmallestCreditNote", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.CustomerSmallestCreditNote, Id = Index.CustomerSmallestCreditNote, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerSmallestCreditNote { get; set; }

        /// <summary>
        /// Gets or sets MarginSrce
        /// </summary>	
        [Display(Name = "MarginSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.MarginSrce, Id = Index.MarginSrce, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal MarginSrce { get; set; }

        /// <summary>
        /// Gets or sets MarginFunc
        /// </summary>		
        [Display(Name = "MarginFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.MarginFunc, Id = Index.MarginFunc, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal MarginFunc { get; set; }

        /// <summary>
        /// Gets or sets AverageSalesLostSrce
        /// </summary>		
        [Display(Name = "AverageSalesLostSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.AverageSalesLostSrce, Id = Index.AverageSalesLostSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AverageSalesLostSrce { get; set; }

        /// <summary>
        /// Gets or sets AverageSalesLostFunc
        /// </summary>		
        [Display(Name = "AverageSalesLostFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.AverageSalesLostFunc, Id = Index.AverageSalesLostFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AverageSalesLostFunc { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDebitNotes
        /// </summary>		
        [Display(Name = "NumberOfDebitNotes", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.NumberOfDebitNotes, Id = Index.NumberOfDebitNotes, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets AverageDebitNoteFunc
        /// </summary>		
        [Display(Name = "AverageDebitNoteFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.AverageDebitNoteFunc, Id = Index.AverageDebitNoteFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AverageDebitNoteFunc { get; set; }

        /// <summary>
        /// Gets or sets AverageDebitNoteSrce
        /// </summary>		
        [Display(Name = "AverageDebitNoteSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.AverageDebitNoteSrce, Id = Index.AverageDebitNoteSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AverageDebitNoteSrce { get; set; }

        /// <summary>
        /// Gets or sets LargestDebitNoteFunc
        /// </summary>	
        [Display(Name = "LargestDebitNoteFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.LargestDebitNoteFunc, Id = Index.LargestDebitNoteFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestDebitNoteFunc { get; set; }

        /// <summary>
        /// Gets or sets LargestDebitNoteSrce
        /// </summary>		
        [Display(Name = "LargestDebitNoteSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.LargestDebitNoteSrce, Id = Index.LargestDebitNoteSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestDebitNoteSrce { get; set; }

        /// <summary>
        /// Gets or sets CustomerLargestDebitNote
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CustomerLargestDebitNote", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.CustomerLargestDebitNote, Id = Index.CustomerLargestDebitNote, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerLargestDebitNote { get; set; }

        /// <summary>
        /// Gets or sets SmallestDebitNoteFunc
        /// </summary>	
        [Display(Name = "SmallestDebitNoteFunc", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SmallestDebitNoteFunc, Id = Index.SmallestDebitNoteFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SmallestDebitNoteFunc { get; set; }

        /// <summary>
        /// Gets or sets SmallestDebitNoteSrce
        /// </summary>		
        [Display(Name = "SmallestDebitNoteSrce", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SmallestDebitNoteSrce, Id = Index.SmallestDebitNoteSrce, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SmallestDebitNoteSrce { get; set; }

        /// <summary>
        /// Gets or sets CustomerSmallestDebitNote
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CustomerSmallestDebitNote", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.CustomerSmallestDebitNote, Id = Index.CustomerSmallestDebitNote, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerSmallestDebitNote { get; set; }
       
        /// <summary>
        /// Sales List
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<Sales> SalesList { get; set; }

        /// <summary>
        /// InvoicesAndCreditDebitNotesList
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<InvoicesAndCreditDebitNotes> InvoicesAndCreditDebitNotesList { get; set; }

        /// <summary>
       /// Gets or Sets IsMulticurrency.
       /// </summary>
       [IgnoreExportImport]
       public bool IsMulticurrency { get; set; }
    }
 
    /// <summary>
    /// Class for Sales Grid
    /// </summary>
    public class Sales : ModelBase
    {
        /// <summary>
        /// Sales Grid Header
        /// </summary>
        public string SalesHeader { get; set; }

        /// <summary>
        /// Customer Currency 
        /// </summary>
        [Display(Name = "CustomerCurrency", ResourceType = typeof (OECommonResx))]
        public string CustomerCurrencyAmount { get; set; }

        /// <summary>
        /// Functional Currency Amount
        /// </summary>
        [Display(Name = "FunctionalCurrency", ResourceType = typeof (CommonResx))]
        public string FunctionalCurrencyAmount { get; set; }
    }

    /// <summary>
    /// Class for InvoicesAndCreditDebitNotes Grid
    /// </summary>
    public class InvoicesAndCreditDebitNotes : ModelBase
    {
        /// <summary>
        /// Sales Grid Header
        /// </summary>      
        public string InvoicesHeader { get; set; }

        /// <summary>
        /// Customer Currency 
        /// </summary>
        [Display(Name = "AUIInvoicesCustCurrCap", ResourceType = typeof (SalesStatisticsResx))]
        public string InvoiceCustomerCurrencyAmount { get; set; }

        /// <summary>
        /// Customer Currency 
        /// </summary>
        [Display(Name = "AUIInvoicesFuncCurrCap", ResourceType = typeof (SalesStatisticsResx))]
        public string InvoiceFunctionalCurrencyAmount { get; set; }

        /// <summary>
        /// Customer Currency 
        /// </summary>
        [Display(Name = "AUICreditNoteCustCurrCap", ResourceType = typeof (SalesStatisticsResx))]
        public string CreditNotesCustomerCurrencyAmount { get; set; }

        /// <summary>
        /// Customer Currency 
        /// </summary>
        [Display(Name = "AUICreditNoteFuncCurrCap", ResourceType = typeof (SalesStatisticsResx))]
        public string CreditNotesFunctionalCurrencyAmount { get; set; }

        /// <summary>
        /// Customer Currency 
        /// </summary>
        [Display(Name = "AUIDebitNoteCustCurrCap", ResourceType = typeof (SalesStatisticsResx))]
        public string DebitNotesCustomerCurrencyAmount { get; set; }

        /// <summary>
        /// Customer Currency 
        /// </summary>
        [Display(Name = "AUIDebitNoteFuncCurrCap", ResourceType = typeof (SalesStatisticsResx))]
        public string DebitNotesFunctionalCurrencyAmount { get; set; }
    }
   
}
