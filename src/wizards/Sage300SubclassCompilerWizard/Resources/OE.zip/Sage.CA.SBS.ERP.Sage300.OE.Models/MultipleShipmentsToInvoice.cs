// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Partial class for MultipleShipmentsToInvoice
	/// </summary>
	public partial class MultipleShipmentsToInvoice : ModelBase
	{
		/// <summary>
		/// Gets or sets InvoiceUniquifier
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceUniquifier", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal InvoiceUniquifier { get; set; }

		/// <summary>
		/// Gets or sets LineNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int LineNumber { get; set; }

		/// <summary>
		/// Gets or sets ShipmentUniquifier
		/// </summary>
        [Display(Name = "ShipmentUniquifier", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ShipmentUniquifier, Id = Index.ShipmentUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal ShipmentUniquifier { get; set; }

		/// <summary>
		/// Gets or sets ShipmentNumber
		/// </summary>
        [Display(Name = "ShipmentNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string ShipmentNumber { get; set; }

		/// <summary>
		/// Gets or sets PONumber
		/// </summary>		
        [Display(Name = "PONumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22)]
		public string PONumber { get; set; }

		#region UI Strings

		#endregion
	}
}
