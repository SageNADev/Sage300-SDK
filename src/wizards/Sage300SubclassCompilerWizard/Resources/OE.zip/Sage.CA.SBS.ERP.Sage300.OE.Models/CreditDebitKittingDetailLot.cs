// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for CreditDebitKittingDetailLot
    /// </summary>
    public partial class CreditDebitKittingDetailLot : ModelBase
    {
        /// <summary>
        /// Gets or sets CreditNoteUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditNoteUniquifier, Id = Index.CreditNoteUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CreditNoteUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ParentComponentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ParentComponentNumber, Id = Index.ParentComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ParentComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ComponentNumber, Id = Index.ComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string LotNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets ExpirationDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets QuantityInStockingUOM
        /// </summary>
        public decimal QuantityInStockingUom { get; set; }

        /// <summary>
        /// Gets or sets TransactionQuantity
        /// </summary>
        [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TransactionQuantity { get; set; }

        /// <summary>
        /// Gets or sets InvQtyInStockingUOM
        /// </summary>
        public decimal InvQtyInStockingUom { get; set; }

        /// <summary>
        /// Gets or sets Cost
        /// </summary>
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Cost { get; set; }

    }
}
