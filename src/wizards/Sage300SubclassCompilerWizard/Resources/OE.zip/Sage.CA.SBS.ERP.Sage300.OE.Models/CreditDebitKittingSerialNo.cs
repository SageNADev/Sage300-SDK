// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for CreditDebitKittingSerialNo
    /// </summary>
    public partial class CreditDebitKittingSerialNo : ModelBase
    {
        /// <summary>
        /// Gets or sets CNUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal CnUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ParentComponentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ParentComponentNumber, Id = Index.ParentComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ParentComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentLineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ComponentLineNumber, Id = Index.ComponentLineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ComponentLineNumber { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets Cost
        /// </summary>
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets TransactionQuantity
        /// </summary>
        [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionQuantity { get; set; }

    }
}
