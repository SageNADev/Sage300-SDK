// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for Invoice
    /// </summary>
    public partial class Invoice : ModelBase
    {
        public Invoice()
        {
            InvoiceSecurity = new InvoiceSecurity();

            InvoiceDetails = new EnumerableResponse<InvoiceDetail>();
            InvoiceOptionalFields = new EnumerableResponse<InvoiceOptionalField> { Items = new List<InvoiceOptionalField>() };
            InvoicePaymentSchedule = new InvoicePaymentSchedule();
            MultipleShipments = new EnumerableResponse<MultipleShipmentsToInvoice>();
            InvoiceKittingDetails = new EnumerableResponse<InvoiceKittingDetail>();
        }

        /// <summary>
        /// Gets or sets InvoiceUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal InvoiceUniquifier { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets ICDayEndTransNumber
        /// </summary>
        [ViewField(Name = Fields.ICDayEndTransNumber, Id = Index.ICDayEndTransNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ICDayEndTransNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets BillTo
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillTo, Id = Index.BillTo, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillTo { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToAddress1, Id = Index.BillToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToAddress2, Id = Index.BillToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToAddress3, Id = Index.BillToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToAddress4, Id = Index.BillToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets BillToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToCity, Id = Index.BillToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCity { get; set; }

        /// <summary>
        /// Gets or sets BillToState
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToState, Id = Index.BillToState, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToState { get; set; }

        /// <summary>
        /// Gets or sets BillToZipCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToZipCode, Id = Index.BillToZipCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string BillToZipCode { get; set; }

        /// <summary>
        /// Gets or sets BillToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToCountry, Id = Index.BillToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCountry { get; set; }

        /// <summary>
        /// Gets or sets BillToPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToPhone, Id = Index.BillToPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToPhone { get; set; }

        /// <summary>
        /// Gets or sets BillToFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToFax, Id = Index.BillToFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToFax { get; set; }

        /// <summary>
        /// Gets or sets BillToContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContact, Id = Index.BillToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToContact { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressCode
        /// </summary>
        [Display(Name = "ShiptoLocation", ResourceType = typeof(OrderEntryResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddressCode, Id = Index.ShipToAddressCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipToAddressCode { get; set; }

        /// <summary>
        /// Gets or sets ShipTo
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipTo, Id = Index.ShipTo, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipTo { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddress1, Id = Index.ShipToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddress2, Id = Index.ShipToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddress3, Id = Index.ShipToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddress4, Id = Index.ShipToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets ShipToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToCity, Id = Index.ShipToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCity { get; set; }

        /// <summary>
        /// Gets or sets ShipToState
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToState, Id = Index.ShipToState, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToState { get; set; }

        /// <summary>
        /// Gets or sets ShipToZipCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToZipCode, Id = Index.ShipToZipCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ShipToZipCode { get; set; }

        /// <summary>
        /// Gets or sets ShipToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToCountry, Id = Index.ShipToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCountry { get; set; }

        /// <summary>
        /// Gets or sets ShipToPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToPhone, Id = Index.ShipToPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToPhone { get; set; }

        /// <summary>
        /// Gets or sets ShipToFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToFax, Id = Index.ShipToFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToFax { get; set; }

        /// <summary>
        /// Gets or sets ShipToContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContact, Id = Index.ShipToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToContact { get; set; }

        /// <summary>
        /// Gets or sets CustomerDiscountLevel
        /// </summary>
        [ViewField(Name = Fields.CustomerDiscountLevel, Id = Index.CustomerDiscountLevel, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerDiscountLevel CustomerDiscountLevel { get; set; }

        /// <summary>
        /// Gets or sets PriceListCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PriceListCode, Id = Index.PriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceListCode { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets Territory
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Territory, Id = Index.Territory, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Territory { get; set; }

        /// <summary>
        /// Gets or sets TermsCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets TotalTermsAmountDue
        /// </summary>
        [ViewField(Name = Fields.TotalTermsAmountDue, Id = Index.TotalTermsAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTermsAmountDue { get; set; }

        /// <summary>
        /// Gets or sets TermsRateOverride
        /// </summary>
        [ViewField(Name = Fields.TermsRateOverride, Id = Index.TermsRateOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TermsRateOverride { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets OrderDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipViaCodeDescription, Id = Index.ShipViaCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets FreeOnBoardPoint
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FreeOnBoardPoint, Id = Index.FreeOnBoardPoint, FieldType = EntityFieldType.Char, Size = 60)]
        public string FreeOnBoardPoint { get; set; }

        /// <summary>
        /// Gets or sets TemplateCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TemplateCode { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentDate, Id = Index.ShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDate
        /// </summary>
        [Display(Name = "InvoiceDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
           ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceDate, Id = Index.InvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceFiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceFiscalYear, Id = Index.InvoiceFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string InvoiceFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets InvoiceFiscalPeriod
        /// </summary>
        [ViewField(Name = Fields.InvoiceFiscalPeriod, Id = Index.InvoiceFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public InvoiceFiscalPeriod InvoiceFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLinesInInvoice
        /// </summary>
        [ViewField(Name = Fields.NumberOfLinesInInvoice, Id = Index.NumberOfLinesInInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfLinesInInvoice { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLabels
        /// </summary>
        [ViewField(Name = Fields.NumberOfLabels, Id = Index.NumberOfLabels, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfLabels { get; set; }

        /// <summary>
        /// Gets or sets NumberOfTermsPayments
        /// </summary>
        [ViewField(Name = Fields.NumberOfTermsPayments, Id = Index.NumberOfTermsPayments, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberOfTermsPayments { get; set; }

        /// <summary>
        /// Gets or sets TermsPaymentsAsOfDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TermsPaymentsAsOfDate, Id = Index.TermsPaymentsAsOfDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TermsPaymentsAsOfDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceTotalEstimatedWeight
        /// </summary>
        [ViewField(Name = Fields.InvoiceTotalEstimatedWeight, Id = Index.InvoiceTotalEstimatedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal InvoiceTotalEstimatedWeight { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoiceStatus
        /// </summary>
        [ViewField(Name = Fields.InvoiceStatus, Id = Index.InvoiceStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public InvoiceStatus InvoiceStatus { get; set; }

        /// <summary>
        /// Gets or sets InvoicePrinted
        /// </summary>
        [ViewField(Name = Fields.InvoicePrinted, Id = Index.InvoicePrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public InvoicePrinted InvoicePrinted { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDisconMiscCharges
        /// </summary>
        [ViewField(Name = Fields.InvoiceDisconMiscCharges, Id = Index.InvoiceDisconMiscCharges, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InvoiceDisconMiscCharges { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets POSTDATE
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets CompletionDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CompletionDate, Id = Index.CompletionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CompletionDate { get; set; }

        /// <summary>
        /// Gets or sets RequiresShippingLabels
        /// </summary>
        [ViewField(Name = Fields.RequiresShippingLabels, Id = Index.RequiresShippingLabels, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RequiresShippingLabels { get; set; }

        /// <summary>
        /// Gets or sets ShippingLabelsPrinted
        /// </summary>
        [ViewField(Name = Fields.ShippingLabelsPrinted, Id = Index.ShippingLabelsPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ShippingLabelsPrinted { get; set; }

        /// <summary>
        /// Gets or sets InvoiceTotalBeforeTax
        /// </summary>
        [ViewField(Name = Fields.InvoiceTotalBeforeTax, Id = Index.InvoiceTotalBeforeTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceTotalBeforeTax { get; set; }

        /// <summary>
        /// Gets or sets InvoiceIncludedTaxTotAmount
        /// </summary>
        [ViewField(Name = Fields.InvoiceIncludedTaxTotAmount, Id = Index.InvoiceIncludedTaxTotAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceIncludedTaxTotAmount { get; set; }

        /// <summary>
        /// Gets or sets InvoiceItemTotalAmount
        /// </summary>
        [ViewField(Name = Fields.InvoiceItemTotalAmount, Id = Index.InvoiceItemTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceItemTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDiscountBase
        /// </summary>
        [ViewField(Name = Fields.InvoiceDiscountBase, Id = Index.InvoiceDiscountBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceDiscountBase { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDiscountPercentage
        /// </summary>
        [ViewField(Name = Fields.InvoiceDiscountPercentage, Id = Index.InvoiceDiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal InvoiceDiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDiscountAmount
        /// </summary>
        [ViewField(Name = Fields.InvoiceDiscountAmount, Id = Index.InvoiceDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets InvoiceTotalMiscCharges
        /// </summary>
        [ViewField(Name = Fields.InvoiceTotalMiscCharges, Id = Index.InvoiceTotalMiscCharges, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceTotalMiscCharges { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSubtotalAmount
        /// </summary>
        [ViewField(Name = Fields.InvoiceSubtotalAmount, Id = Index.InvoiceSubtotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceSubtotalAmount { get; set; }

        /// <summary>
        /// Gets or sets InvoiceTotalWithInvoiceDisc
        /// </summary>
        [ViewField(Name = Fields.InvoiceTotalWithInvoiceDisc, Id = Index.InvoiceTotalWithInvoiceDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceTotalWithInvoiceDisc { get; set; }

        /// <summary>
        /// Gets or sets InvoiceExcludedTaxTotAmount
        /// </summary>
        [ViewField(Name = Fields.InvoiceExcludedTaxTotAmount, Id = Index.InvoiceExcludedTaxTotAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceExcludedTaxTotAmount { get; set; }

        /// <summary>
        /// Gets or sets InvoiceTotalWithTax
        /// </summary>
        [ViewField(Name = Fields.InvoiceTotalWithTax, Id = Index.InvoiceTotalWithTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceTotalWithTax { get; set; }

        /// <summary>
        /// Gets or sets InvoiceHomeCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceHomeCurrency, Id = Index.InvoiceHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string InvoiceHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceRateType, Id = Index.InvoiceRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string InvoiceRateType { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSourceCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceSourceCurrency, Id = Index.InvoiceSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string InvoiceSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceRateDate, Id = Index.InvoiceRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoiceRateDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRate
        /// </summary>
        [ViewField(Name = Fields.InvoiceRate, Id = Index.InvoiceRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal InvoiceRate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSpread
        /// </summary>
        [ViewField(Name = Fields.InvoiceSpread, Id = Index.InvoiceSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal InvoiceSpread { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateDateMatching
        /// </summary>
        [ViewField(Name = Fields.InvoiceRateDateMatching, Id = Index.InvoiceRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoiceRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateOperator
        /// </summary>
        [ViewField(Name = Fields.InvoiceRateOperator, Id = Index.InvoiceRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoiceRateOperator { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateOverrideFlag
        /// </summary>
        [ViewField(Name = Fields.InvoiceRateOverrideFlag, Id = Index.InvoiceRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InvoiceRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage1
        /// </summary>
        [ViewField(Name = Fields.SalesPercentage1, Id = Index.SalesPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage2
        /// </summary>
        [ViewField(Name = Fields.SalesPercentage2, Id = Index.SalesPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage3
        /// </summary>
        [ViewField(Name = Fields.SalesPercentage3, Id = Index.SalesPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage4
        /// </summary>
        [ViewField(Name = Fields.SalesPercentage4, Id = Index.SalesPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage5
        /// </summary>
        [ViewField(Name = Fields.SalesPercentage5, Id = Index.SalesPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets TaxOverridden
        /// </summary>
        [ViewField(Name = Fields.TaxOverridden, Id = Index.TaxOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount1
        /// </summary>
        [ViewField(Name = Fields.ExcludedTaxAmount1, Id = Index.ExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount2
        /// </summary>
        [ViewField(Name = Fields.ExcludedTaxAmount2, Id = Index.ExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount3
        /// </summary>
        [ViewField(Name = Fields.ExcludedTaxAmount3, Id = Index.ExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount4
        /// </summary>
        [ViewField(Name = Fields.ExcludedTaxAmount4, Id = Index.ExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount5
        /// </summary>
        [ViewField(Name = Fields.ExcludedTaxAmount5, Id = Index.ExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount1
        /// </summary>
        [ViewField(Name = Fields.IncludedTaxAmount1, Id = Index.IncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount2
        /// </summary>
        [ViewField(Name = Fields.IncludedTaxAmount2, Id = Index.IncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount3
        /// </summary>
        [ViewField(Name = Fields.IncludedTaxAmount3, Id = Index.IncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount4
        /// </summary>
        [ViewField(Name = Fields.IncludedTaxAmount4, Id = Index.IncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount5
        /// </summary>
        [ViewField(Name = Fields.IncludedTaxAmount5, Id = Index.IncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets Registration1
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration1, Id = Index.Registration1, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration1 { get; set; }

        /// <summary>
        /// Gets or sets Registration2
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration2, Id = Index.Registration2, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration2 { get; set; }

        /// <summary>
        /// Gets or sets Registration3
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration3, Id = Index.Registration3, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration3 { get; set; }

        /// <summary>
        /// Gets or sets Registration4
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration4, Id = Index.Registration4, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration4 { get; set; }

        /// <summary>
        /// Gets or sets Registration5
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Registration5, Id = Index.Registration5, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration5 { get; set; }

        /// <summary>
        /// Gets or sets PriceListCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PriceListCodeDescription, Id = Index.PriceListCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string PriceListCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets TermsCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TermsCodeDescription, Id = Index.TermsCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TermsCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroupCodeDescription, Id = Index.TaxGroupCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets LocationCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LocationCodeDescription, Id = Index.LocationCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName1, Id = Index.SalespersonName1, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName1 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName2, Id = Index.SalespersonName2, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName2 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName3, Id = Index.SalespersonName3, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName3 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName4, Id = Index.SalespersonName4, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName4 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName5
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalespersonName5, Id = Index.SalespersonName5, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1Description, Id = Index.TaxAuthority1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2Description, Id = Index.TaxAuthority2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3Description, Id = Index.TaxAuthority3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4Description, Id = Index.TaxAuthority4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5Description, Id = Index.TaxAuthority5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority5Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSourceCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceSourceCurrencyDesc, Id = Index.InvoiceSourceCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceSourceCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets InvoiceHomeCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceHomeCurrencyDesc, Id = Index.InvoiceHomeCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceHomeCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceRateTypeDescription, Id = Index.InvoiceRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets PaymentSourceCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentSourceCurrencyDesc, Id = Index.PaymentSourceCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentSourceCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets PaymentHomeCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentHomeCurrencyDesc, Id = Index.PaymentHomeCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentHomeCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets PaymentRateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentRateTypeDescription, Id = Index.PaymentRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount1
        /// </summary>
        [ViewField(Name = Fields.TotalTaxAmount1, Id = Index.TotalTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount2
        /// </summary>
        [ViewField(Name = Fields.TotalTaxAmount2, Id = Index.TotalTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount3
        /// </summary>
        [ViewField(Name = Fields.TotalTaxAmount3, Id = Index.TotalTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount4
        /// </summary>
        [ViewField(Name = Fields.TotalTaxAmount4, Id = Index.TotalTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount5
        /// </summary>
        [ViewField(Name = Fields.TotalTaxAmount5, Id = Index.TotalTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount
        /// </summary>
        [ViewField(Name = Fields.TotalTaxAmount, Id = Index.TotalTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets InvoicePaymntInCustomerCurr
        /// </summary>
        [ViewField(Name = Fields.InvoicePaymntInCustomerCurr, Id = Index.InvoicePaymntInCustomerCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoicePaymntInCustomerCurr { get; set; }

        /// <summary>
        /// Gets or sets InvoicePaymentDiscount
        /// </summary>
        [ViewField(Name = Fields.InvoicePaymentDiscount, Id = Index.InvoicePaymentDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoicePaymentDiscount { get; set; }

        /// <summary>
        /// Gets or sets InvoiceAmountDue
        /// </summary>
        [ViewField(Name = Fields.InvoiceAmountDue, Id = Index.InvoiceAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceAmountDue { get; set; }

        /// <summary>
        /// Gets or sets AutoTaxCalculationStatus
        /// </summary>
        [ViewField(Name = Fields.AutoTaxCalculationStatus, Id = Index.AutoTaxCalculationStatus, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AutoTaxCalculationStatus { get; set; }

        /// <summary>
        /// Gets or sets OrderPaymentsTotal
        /// </summary>
        [ViewField(Name = Fields.OrderPaymentsTotal, Id = Index.OrderPaymentsTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderPaymentsTotal { get; set; }

        /// <summary>
        /// Gets or sets BillToEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToEmail, Id = Index.BillToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToEmail { get; set; }

        /// <summary>
        /// Gets or sets BillToContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContactPhone, Id = Index.BillToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets BillToContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContactFax, Id = Index.BillToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactFax { get; set; }

        /// <summary>
        /// Gets or sets BillToContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToContactEmail, Id = Index.BillToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToEmail, Id = Index.ShipToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactPhone, Id = Index.ShipToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactFax, Id = Index.ShipToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactFax { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactEmail, Id = Index.ShipToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToContactEmail { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RECALCTAX
        /// </summary>
        [ViewField(Name = Fields.RECALCTAX, Id = Index.RECALCTAX, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RECALCTAX { get; set; }

        /// <summary>
        /// Gets or sets DiscountAvailable
        /// </summary>
        [ViewField(Name = Fields.DiscountAvailable, Id = Index.DiscountAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAvailable { get; set; }

        /// <summary>
        /// Gets or sets ShipmentHomeCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentHomeCurrency, Id = Index.ShipmentHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ShipmentHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentRateType, Id = Index.ShipmentRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ShipmentRateType { get; set; }

        /// <summary>
        /// Gets or sets ShipmentSourceCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentSourceCurrency, Id = Index.ShipmentSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ShipmentSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentRateDate, Id = Index.ShipmentRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipmentRateDate { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRate
        /// </summary>
        [ViewField(Name = Fields.ShipmentRate, Id = Index.ShipmentRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ShipmentRate { get; set; }

        /// <summary>
        /// Gets or sets ShipmentSpread
        /// </summary>
        [ViewField(Name = Fields.ShipmentSpread, Id = Index.ShipmentSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ShipmentSpread { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateDateMatching
        /// </summary>
        [ViewField(Name = Fields.ShipmentRateDateMatching, Id = Index.ShipmentRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateOperator
        /// </summary>
        [ViewField(Name = Fields.ShipmentRateOperator, Id = Index.ShipmentRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentRateOperator { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateOverrideFlag
        /// </summary>
        [ViewField(Name = Fields.ShipmentRateOverrideFlag, Id = Index.ShipmentRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ShipmentRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber
        /// </summary>
        [Display(Name = "ShipmentNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets GenerateFromMultipleShipments
        /// </summary>
        [ViewField(Name = Fields.GenerateFromMultipleShipments, Id = Index.GenerateFromMultipleShipments, FieldType = EntityFieldType.Bool, Size = 2)]
        public GenerateFromMultipleShipments GenerateFromMultipleShipments { get; set; }

        /// <summary>
        /// Gets or sets FromHowManyShipments
        /// </summary>
        [ViewField(Name = Fields.FromHowManyShipments, Id = Index.FromHowManyShipments, FieldType = EntityFieldType.Int, Size = 2)]
        public int FromHowManyShipments { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentBatchNumber
        /// </summary>
        [ViewField(Name = Fields.PrepaymentBatchNumber, Id = Index.PrepaymentBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PrepaymentBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentBankCode
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentBankCode, Id = Index.PrepaymentBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string PrepaymentBankCode { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentReceiptType
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentReceiptType, Id = Index.PrepaymentReceiptType, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string PrepaymentReceiptType { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentCheckDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentCheckDate, Id = Index.PrepaymentCheckDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PrepaymentCheckDate { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentFiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentFiscalYear, Id = Index.PrepaymentFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string PrepaymentFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentFiscalPeriod
        /// </summary>
        [ViewField(Name = Fields.PrepaymentFiscalPeriod, Id = Index.PrepaymentFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int PrepaymentFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentCheckNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentCheckNumber, Id = Index.PrepaymentCheckNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string PrepaymentCheckNumber { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentApplyTo
        /// </summary>
        [ViewField(Name = Fields.PrepaymentApplyTo, Id = Index.PrepaymentApplyTo, FieldType = EntityFieldType.Int, Size = 2)]
        public PrepaymentApplyTo PrepaymentApplyTo { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentInBankCurrency
        /// </summary>
        [ViewField(Name = Fields.PrepaymentInBankCurrency, Id = Index.PrepaymentInBankCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrepaymentInBankCurrency { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentHomeCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentHomeCurrency, Id = Index.PrepaymentHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string PrepaymentHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentRateType, Id = Index.PrepaymentRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PrepaymentRateType { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentSourceCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentSourceCurrency, Id = Index.PrepaymentSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string PrepaymentSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentRateDate, Id = Index.PrepaymentRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PrepaymentRateDate { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentRate
        /// </summary>
        [ViewField(Name = Fields.PrepaymentRate, Id = Index.PrepaymentRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PrepaymentRate { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentSpread
        /// </summary>
        [ViewField(Name = Fields.PrepaymentSpread, Id = Index.PrepaymentSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PrepaymentSpread { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentDateMatch
        /// </summary>
        [ViewField(Name = Fields.PrepaymentDateMatch, Id = Index.PrepaymentDateMatch, FieldType = EntityFieldType.Int, Size = 2)]
        public int PrepaymentDateMatch { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentRateOperator
        /// </summary>
        [ViewField(Name = Fields.PrepaymentRateOperator, Id = Index.PrepaymentRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int PrepaymentRateOperator { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets GOCALCTAX
        /// </summary>
        [ViewField(Name = Fields.GOCALCTAX, Id = Index.GOCALCTAX, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool GOCALCTAX { get; set; }

        /// <summary>
        /// Gets or sets PerformCreditLimitCheck
        /// </summary>
        [ViewField(Name = Fields.PerformCreditLimitCheck, Id = Index.PerformCreditLimitCheck, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformCreditLimitCheck { get; set; }

        /// <summary>
        /// Gets or sets ShipAll
        /// </summary>
        [ViewField(Name = Fields.ShipAll, Id = Index.ShipAll, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ShipAll { get; set; }

        /// <summary>
        /// Gets or sets DosConvert
        /// </summary>
        [ViewField(Name = Fields.DosConvert, Id = Index.DosConvert, FieldType = EntityFieldType.Bool, Size = 2)]
        public DosConvert DosConvert { get; set; }

        /// <summary>
        /// Gets or sets ForceTaxCalculation
        /// </summary>
        [ViewField(Name = Fields.ForceTaxCalculation, Id = Index.ForceTaxCalculation, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForceTaxCalculation { get; set; }

        /// <summary>
        /// Gets or sets DistributeManualTax
        /// </summary>
        [ViewField(Name = Fields.DistributeManualTax, Id = Index.DistributeManualTax, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DistributeManualTax { get; set; }

        /// <summary>
        /// Gets or sets TaxCalculationInProgress
        /// </summary>
        [ViewField(Name = Fields.TaxCalculationInProgress, Id = Index.TaxCalculationInProgress, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxCalculationInProgress { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRunningTotal
        /// </summary>
        [ViewField(Name = Fields.InvoiceRunningTotal, Id = Index.InvoiceRunningTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceRunningTotal { get; set; }

        /// <summary>
        /// Gets or sets DisplayRateWarning
        /// </summary>
        [ViewField(Name = Fields.DisplayRateWarning, Id = Index.DisplayRateWarning, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DisplayRateWarning { get; set; }

        /// <summary>
        /// Gets or sets CustomerExists
        /// </summary>
        [ViewField(Name = Fields.CustomerExists, Id = Index.CustomerExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerExists { get; set; }

        /// <summary>
        /// Gets or sets RecalcMultiPaymentDates
        /// </summary>
        [ViewField(Name = Fields.RecalcMultiPaymentDates, Id = Index.RecalcMultiPaymentDates, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RecalcMultiPaymentDates { get; set; }

        /// <summary>
        /// Gets or sets GenerateInvFromSingleShip
        /// </summary>
        [ViewField(Name = Fields.GenerateInvFromSingleShip, Id = Index.GenerateInvFromSingleShip, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool GenerateInvFromSingleShip { get; set; }

        /// <summary>
        /// Gets or sets GenerateInvFromMultShips
        /// </summary>
        [ViewField(Name = Fields.GenerateInvFromMultShips, Id = Index.GenerateInvFromMultShips, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool GenerateInvFromMultShips { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentRateTypeDescription, Id = Index.ShipmentRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipmentRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTrackingNumber
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentTrackingNumber, Id = Index.ShipmentTrackingNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string ShipmentTrackingNumber { get; set; }

        /// <summary>
        /// Gets or sets Allowpartialshipments
        /// </summary>
        [ViewField(Name = Fields.Allowpartialshipments, Id = Index.Allowpartialshipments, FieldType = EntityFieldType.Int, Size = 2)]
        public Allowpartialshipments Allowpartialshipments { get; set; }

        /// <summary>
        /// Gets or sets OverCreditLimit
        /// </summary>
        [ViewField(Name = Fields.OverCreditLimit, Id = Index.OverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets ApprovedLimit
        /// </summary>
        [ViewField(Name = Fields.ApprovedLimit, Id = Index.ApprovedLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ApprovedLimit { get; set; }

        /// <summary>
        /// Gets or sets AuthorizingUserID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AuthorizingUserID, Id = Index.AuthorizingUserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string AuthorizingUserID { get; set; }

        /// <summary>
        /// Gets or sets AuthorizingUserPassword
        /// </summary>
        [StringLength(64, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AuthorizingUserPassword, Id = Index.AuthorizingUserPassword, FieldType = EntityFieldType.Char, Size = 64)]
        public string AuthorizingUserPassword { get; set; }

        /// <summary>
        /// Gets or sets UserCanApproveCreditLift
        /// </summary>
        [ViewField(Name = Fields.UserCanApproveCreditLift, Id = Index.UserCanApproveCreditLift, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UserCanApproveCreditLift { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ShipmentUniquifier
        /// </summary>
        [ViewField(Name = Fields.ShipmentUniquifier, Id = Index.ShipmentUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ShipmentUniquifier { get; set; }

        /// <summary>
        /// Gets or sets ProcessOIPCommand
        /// </summary>
        [ViewField(Name = Fields.ProcessOIPCommand, Id = Index.ProcessOIPCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessOIPCommand ProcessOIPCommand { get; set; }

        /// <summary>
        /// Gets or sets DocumentDiscountBaseWithTax
        /// </summary>
        [ViewField(Name = Fields.DocumentDiscountBaseWithTax, Id = Index.DocumentDiscountBaseWithTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentDiscountBaseWithTax { get; set; }

        /// <summary>
        /// Gets or sets DocumentDiscountBasewoTax
        /// </summary>
        [ViewField(Name = Fields.DocumentDiscountBasewoTax, Id = Index.DocumentDiscountBasewoTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentDiscountBasewoTax { get; set; }

        /// <summary>
        /// Gets or sets ProcessOECommand
        /// </summary>
        [ViewField(Name = Fields.ProcessOECommand, Id = Index.ProcessOECommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessOECommand ProcessOECommand { get; set; }

        /// <summary>
        /// Gets or sets UserEnteredApprovalAmount
        /// </summary>
        [ViewField(Name = Fields.UserEnteredApprovalAmount, Id = Index.UserEnteredApprovalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UserEnteredApprovalAmount { get; set; }

        /// <summary>
        /// Gets or sets CheckingCustomerCreditLimit
        /// </summary>
        [ViewField(Name = Fields.CheckingCustomerCreditLimit, Id = Index.CheckingCustomerCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingCustomerCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingCustomerAgingLimit
        /// </summary>
        [ViewField(Name = Fields.CheckingCustomerAgingLimit, Id = Index.CheckingCustomerAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingCustomerAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingNatAcctCreditLimit
        /// </summary>
        [ViewField(Name = Fields.CheckingNatAcctCreditLimit, Id = Index.CheckingNatAcctCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingNatAcctCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingNatAcctAgingLimit
        /// </summary>
        [ViewField(Name = Fields.CheckingNatAcctAgingLimit, Id = Index.CheckingNatAcctAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingNatAcctAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerIsOverCreditLimit
        /// </summary>
        [ViewField(Name = Fields.CustomerIsOverCreditLimit, Id = Index.CustomerIsOverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerIsOverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerIsOverAgingLimit
        /// </summary>
        [ViewField(Name = Fields.CustomerIsOverAgingLimit, Id = Index.CustomerIsOverAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerIsOverAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctIsOverCreditLimit
        /// </summary>
        [ViewField(Name = Fields.NatAcctIsOverCreditLimit, Id = Index.NatAcctIsOverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool NatAcctIsOverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctIsOverAgingLimit
        /// </summary>
        [ViewField(Name = Fields.NatAcctIsOverAgingLimit, Id = Index.NatAcctIsOverAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool NatAcctIsOverAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerCreditLimit
        /// </summary>
        [ViewField(Name = Fields.CustomerCreditLimit, Id = Index.CustomerCreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets PreCreditCheckStatus
        /// </summary>
        [IgnoreExportImport]
        public PreCreditCheckStatus PreCreditCheckStatus { get; set; }

        /// <summary>
        /// Gets or sets ProceedPreCreditCheckStatus
        /// </summary>
        [IgnoreExportImport]
        public bool ProceedPreCreditCheckStatus { get; set; }

        /// <summary>
        /// Gets or sets CustomerBalancePosted
        /// </summary>
        [ViewField(Name = Fields.CustomerBalancePosted, Id = Index.CustomerBalancePosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerBalancePosted { get; set; }

        /// <summary>
        /// Gets or sets CustomerDaysOverdue
        /// </summary>
        [ViewField(Name = Fields.CustomerDaysOverdue, Id = Index.CustomerDaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerDaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets CustomerOverdueLimit
        /// </summary>
        [ViewField(Name = Fields.CustomerOverdueLimit, Id = Index.CustomerOverdueLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerOverdueLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerBalanceOverdue
        /// </summary>
        [ViewField(Name = Fields.CustomerBalanceOverdue, Id = Index.CustomerBalanceOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerBalanceOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctCreditLimit
        /// </summary>
        [ViewField(Name = Fields.NatAcctCreditLimit, Id = Index.NatAcctCreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctBalance
        /// </summary>
        [ViewField(Name = Fields.NatAcctBalance, Id = Index.NatAcctBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctBalance { get; set; }

        /// <summary>
        /// Gets or sets NatAcctDaysOverdue
        /// </summary>
        [ViewField(Name = Fields.NatAcctDaysOverdue, Id = Index.NatAcctDaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int NatAcctDaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctOverdueLimit
        /// </summary>
        [ViewField(Name = Fields.NatAcctOverdueLimit, Id = Index.NatAcctOverdueLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctOverdueLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctBalanceOverdue
        /// </summary>
        [ViewField(Name = Fields.NatAcctBalanceOverdue, Id = Index.NatAcctBalanceOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctBalanceOverdue { get; set; }

        /// <summary>
        /// Gets or sets ARPendingTransIncluded
        /// </summary>
        [ViewField(Name = Fields.ARPendingTransIncluded, Id = Index.ARPendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ARPendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets OEPendingTransIncluded
        /// </summary>
        [ViewField(Name = Fields.OEPendingTransIncluded, Id = Index.OEPendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OEPendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets OtherPendingTransIncluded
        /// </summary>
        [ViewField(Name = Fields.OtherPendingTransIncluded, Id = Index.OtherPendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OtherPendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets ARPendingBalance
        /// </summary>
        [ViewField(Name = Fields.ARPendingBalance, Id = Index.ARPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ARPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets OEPendingBalance
        /// </summary>
        [ViewField(Name = Fields.OEPendingBalance, Id = Index.OEPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OEPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets OtherPendingBalance
        /// </summary>
        [ViewField(Name = Fields.OtherPendingBalance, Id = Index.OtherPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OtherPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets CustomerTotalOutstanding
        /// </summary>
        [ViewField(Name = Fields.CustomerTotalOutstanding, Id = Index.CustomerTotalOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTotalOutstanding { get; set; }

        /// <summary>
        /// Gets or sets NatAcctTotalOutstanding
        /// </summary>
        [ViewField(Name = Fields.NatAcctTotalOutstanding, Id = Index.NatAcctTotalOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctTotalOutstanding { get; set; }

        /// <summary>
        /// Gets or sets CustomerLimitLeft
        /// </summary>
        [ViewField(Name = Fields.CustomerLimitLeft, Id = Index.CustomerLimitLeft, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerLimitLeft { get; set; }

        /// <summary>
        /// Gets or sets NatAcctLimitLeft
        /// </summary>
        [ViewField(Name = Fields.NatAcctLimitLeft, Id = Index.NatAcctLimitLeft, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctLimitLeft { get; set; }

        /// <summary>
        /// Gets or sets CustomerLimitExceeded
        /// </summary>
        [ViewField(Name = Fields.CustomerLimitExceeded, Id = Index.CustomerLimitExceeded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerLimitExceeded { get; set; }

        /// <summary>
        /// Gets or sets NatAcctLimitExceeded
        /// </summary>
        [ViewField(Name = Fields.NatAcctLimitExceeded, Id = Index.NatAcctLimitExceeded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctLimitExceeded { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceAmount
        /// </summary>
        [ViewField(Name = Fields.LastInvoiceAmount, Id = Index.LastInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastInvoiceDate, Id = Index.LastInvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets LastPaymentAmount
        /// </summary>
        [ViewField(Name = Fields.LastPaymentAmount, Id = Index.LastPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets LastPaymentDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastPaymentDate, Id = Index.LastPaymentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPaymentDate { get; set; }

        /// <summary>
        /// Gets or sets DrivenbyUI
        /// </summary>
        [ViewField(Name = Fields.DrivenbyUI, Id = Index.DrivenbyUI, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DrivenbyUI { get; set; }

        /// <summary>
        /// Gets or sets ItemDetailDiscountTotal
        /// </summary>
        [ViewField(Name = Fields.ItemDetailDiscountTotal, Id = Index.ItemDetailDiscountTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ItemDetailDiscountTotal { get; set; }

        /// <summary>
        /// Gets or sets MiscChargeDetailDiscountTot
        /// </summary>
        [ViewField(Name = Fields.MiscChargeDetailDiscountTot, Id = Index.MiscChargeDetailDiscountTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MiscChargeDetailDiscountTot { get; set; }

        /// <summary>
        /// Gets or sets DetailDiscountTotal
        /// </summary>
        [ViewField(Name = Fields.DetailDiscountTotal, Id = Index.DetailDiscountTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DetailDiscountTotal { get; set; }

        /// <summary>
        /// Gets or sets DetailDiscountPercentage
        /// </summary>
        [ViewField(Name = Fields.DetailDiscountPercentage, Id = Index.DetailDiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DetailDiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets DocumentNetOfDetailDisc
        /// </summary>
        [ViewField(Name = Fields.DocumentNetOfDetailDisc, Id = Index.DocumentNetOfDetailDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentNetOfDetailDisc { get; set; }

        /// <summary>
        /// Gets or sets AutoCalcTaxReportingAmounts
        /// </summary>
        [ViewField(Name = Fields.AutoCalcTaxReportingAmounts, Id = Index.AutoCalcTaxReportingAmounts, FieldType = EntityFieldType.Int, Size = 2)]
        public int AutoCalcTaxReportingAmounts { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTRCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingTRCurrency, Id = Index.TaxReportingTRCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingTRCurrency { get; set; }

        /// <summary>
        /// Gets or sets TRRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRRateType, Id = Index.TRRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TRRateType { get; set; }

        /// <summary>
        /// Gets or sets TRRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRRateDate, Id = Index.TRRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TRRateDate { get; set; }

        /// <summary>
        /// Gets or sets TRRate
        /// </summary>
        [ViewField(Name = Fields.TRRate, Id = Index.TRRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TRRate { get; set; }

        /// <summary>
        /// Gets or sets TRSpread
        /// </summary>
        [ViewField(Name = Fields.TRSpread, Id = Index.TRSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TRSpread { get; set; }

        /// <summary>
        /// Gets or sets TRRateDateMatching
        /// </summary>
        [ViewField(Name = Fields.TRRateDateMatching, Id = Index.TRRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int TRRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets TRRateOperator
        /// </summary>
        [ViewField(Name = Fields.TRRateOperator, Id = Index.TRRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TRRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TRRateOverrideFlag
        /// </summary>
        [ViewField(Name = Fields.TRRateOverrideFlag, Id = Index.TRRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TRRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount1
        /// </summary>
        [ViewField(Name = Fields.TRExcludedTaxAmount1, Id = Index.TRExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount2
        /// </summary>
        [ViewField(Name = Fields.TRExcludedTaxAmount2, Id = Index.TRExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount3
        /// </summary>
        [ViewField(Name = Fields.TRExcludedTaxAmount3, Id = Index.TRExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount4
        /// </summary>
        [ViewField(Name = Fields.TRExcludedTaxAmount4, Id = Index.TRExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount5
        /// </summary>
        [ViewField(Name = Fields.TRExcludedTaxAmount5, Id = Index.TRExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount1
        /// </summary>
        [ViewField(Name = Fields.TRIncludedTaxAmount1, Id = Index.TRIncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount2
        /// </summary>
        [ViewField(Name = Fields.TRIncludedTaxAmount2, Id = Index.TRIncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount3
        /// </summary>
        [ViewField(Name = Fields.TRIncludedTaxAmount3, Id = Index.TRIncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount4
        /// </summary>
        [ViewField(Name = Fields.TRIncludedTaxAmount4, Id = Index.TRIncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount5
        /// </summary>
        [ViewField(Name = Fields.TRIncludedTaxAmount5, Id = Index.TRIncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount1
        /// </summary>
        [ViewField(Name = Fields.TRTaxAmount1, Id = Index.TRTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount2
        /// </summary>
        [ViewField(Name = Fields.TRTaxAmount2, Id = Index.TRTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount3
        /// </summary>
        [ViewField(Name = Fields.TRTaxAmount3, Id = Index.TRTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount4
        /// </summary>
        [ViewField(Name = Fields.TRTaxAmount4, Id = Index.TRTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount5
        /// </summary>
        [ViewField(Name = Fields.TRTaxAmount5, Id = Index.TRTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxTotal
        /// </summary>
        [ViewField(Name = Fields.TRExcludedTaxTotal, Id = Index.TRExcludedTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRExcludedTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxTotal
        /// </summary>
        [ViewField(Name = Fields.TRIncludedTaxTotal, Id = Index.TRIncludedTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRIncludedTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TRTaxTotal
        /// </summary>
        [ViewField(Name = Fields.TRTaxTotal, Id = Index.TRTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingShipmentTRCurr
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingShipmentTRCurr, Id = Index.TaxReportingShipmentTRCurr, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingShipmentTRCurr { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRShipmentRateType, Id = Index.TRShipmentRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TRShipmentRateType { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRShipmentRateDate, Id = Index.TRShipmentRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TRShipmentRateDate { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRate
        /// </summary>
        [ViewField(Name = Fields.TRShipmentRate, Id = Index.TRShipmentRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TRShipmentRate { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentSpread
        /// </summary>
        [ViewField(Name = Fields.TRShipmentSpread, Id = Index.TRShipmentSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TRShipmentSpread { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRateDateMatching
        /// </summary>
        [ViewField(Name = Fields.TRShipmentRateDateMatching, Id = Index.TRShipmentRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int TRShipmentRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRateOperator
        /// </summary>
        [ViewField(Name = Fields.TRShipmentRateOperator, Id = Index.TRShipmentRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TRShipmentRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRateOverrideFlag
        /// </summary>
        [ViewField(Name = Fields.TRShipmentRateOverrideFlag, Id = Index.TRShipmentRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TRShipmentRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentCurrencyDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRShipmentCurrencyDescription, Id = Index.TRShipmentCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TRShipmentCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceCurrencyDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRInvoiceCurrencyDescription, Id = Index.TRInvoiceCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TRInvoiceCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRateTypeDescriptio
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRShipmentRateTypeDescriptio, Id = Index.TRShipmentRateTypeDescriptio, FieldType = EntityFieldType.Char, Size = 60)]
        public string TRShipmentRateTypeDescriptio { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRInvoiceRateTypeDescription, Id = Index.TRInvoiceRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TRInvoiceRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxVersion
        /// </summary>
        [ViewField(Name = Fields.TaxVersion, Id = Index.TaxVersion, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxVersion { get; set; }

        /// <summary>
        /// Gets or sets PaymentType
        /// </summary>
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDiscountAmountOverride
        /// </summary>
        [ViewField(Name = Fields.InvoiceDiscountAmountOverride, Id = Index.InvoiceDiscountAmountOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InvoiceDiscountAmountOverride { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedDetailLines
        /// </summary>
        [ViewField(Name = Fields.JobRelatedDetailLines, Id = Index.JobRelatedDetailLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedDetailLines { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage
        /// </summary>
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasRetainage HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageTerms
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageTerms, Id = Index.RetainageTerms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTerms { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainagePercent
        /// </summary>
        [ViewField(Name = Fields.RetainagePercent, Id = Index.RetainagePercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal RetainagePercent { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate
        /// </summary>
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1
        /// </summary>
        [ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2
        /// </summary>
        [ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3
        /// </summary>
        [ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4
        /// </summary>
        [ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5
        /// </summary>
        [ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1
        /// </summary>
        [ViewField(Name = Fields.RetainageTaxAmount1, Id = Index.RetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2
        /// </summary>
        [ViewField(Name = Fields.RetainageTaxAmount2, Id = Index.RetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3
        /// </summary>
        [ViewField(Name = Fields.RetainageTaxAmount3, Id = Index.RetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4
        /// </summary>
        [ViewField(Name = Fields.RetainageTaxAmount4, Id = Index.RetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5
        /// </summary>
        [ViewField(Name = Fields.RetainageTaxAmount5, Id = Index.RetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageTermsDescription, Id = Index.RetainageTermsDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RetainageTermsDescription { get; set; }

        /// <summary>
        /// Gets or sets CustomerAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerAccountSet, Id = Index.CustomerAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CustomerAccountSet { get; set; }

        /// <summary>
        /// Gets or sets CustomerAccountSetDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerAccountSetDescription, Id = Index.CustomerAccountSetDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerAccountSetDescription { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets Export Declaration Number 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExportDeclarationNumber", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.ExportDeclarationNumber, Id = Index.ExportDeclarationNumber, FieldType = EntityFieldType.Char, Size = 30)]
        public string ExportDeclarationNumber { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets DATEBUS
        /// </summary>
        [Display(Name = "PostingDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DATEBUS, Id = Index.DATEBUS, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DATEBUS { get; set; }

        /// <summary>
        /// Gets or sets ShipmentPaymentsTotal
        /// </summary>
        [ViewField(Name = Fields.ShipmentPaymentsTotal, Id = Index.ShipmentPaymentsTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentPaymentsTotal { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentDistributedAmount
        /// </summary>
        [ViewField(Name = Fields.PrepaymentDistributedAmount, Id = Index.PrepaymentDistributedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrepaymentDistributedAmount { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentUnappliedAmount
        /// </summary>
        [ViewField(Name = Fields.PrepaymentUnappliedAmount, Id = Index.PrepaymentUnappliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrepaymentUnappliedAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalRetainageTaxAmount
        /// </summary>
        [ViewField(Name = Fields.TotalRetainageTaxAmount, Id = Index.TotalRetainageTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRetainageTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets SageCRMOpportunityLines
        /// </summary>
        [ViewField(Name = Fields.SageCRMOpportunityLines, Id = Index.SageCRMOpportunityLines, FieldType = EntityFieldType.Int, Size = 2)]
        public int SageCRMOpportunityLines { get; set; }

        /// <summary>
        /// Gets or Sets InvoicePrinted
        /// </summary>
        public string InvoicePrintedString
        {
            get
            {
                return EnumUtility.GetStringValue(InvoicePrinted);
            }
        }

        /// <summary>
        /// Gets or Sets InvoicePrinted
        /// </summary>
        public string InvoiceFiscalPeriodString
        {
            get
            {
                return EnumUtility.GetStringValue(InvoiceFiscalPeriod);
            }
        }

        /// <summary>
        /// Gets or sets PreAuthExistsForInvoice
        /// </summary>
        [ViewField(Name = Fields.PreAuthExistsForInvoice, Id = Index.PreAuthExistsForInvoice, FieldType = EntityFieldType.Bool, Size = 2)]
        public PreAuthExistsForInvoice PreAuthExistsForInvoice { get; set; }

        [Display(Name = "TermsRateOverride", ResourceType = typeof(InvoiceEntryResx))]
        public string TermsRateOverrideString
        {
            get
            {
                if (TermsRateOverride)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "InvoiceDisconMiscCharges", ResourceType = typeof(InvoiceEntryResx))]
        public string InvoiceDisconMiscChargesString
        {
            get
            {
                if (InvoiceDisconMiscCharges)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "RequiresShippingLabels", ResourceType = typeof(InvoiceEntryResx))]
        public string RequiresShippingLabelsString
        {
            get
            {
                if (RequiresShippingLabels)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "ShippingLabelsPrinted", ResourceType = typeof(InvoiceEntryResx))]
        public string ShippingLabelsPrintedString
        {
            get
            {
                if (ShippingLabelsPrinted)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "InvoiceRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        public string InvoiceRateOverrideFlagString
        {
            get
            {
                if (InvoiceRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "TaxOverridden", ResourceType = typeof(OECommonResx))]
        public string TaxOverriddenString
        {
            get
            {
                if (TaxOverridden)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "AutoTaxCalculationStatus", ResourceType = typeof(OECommonResx))]
        public string AutoTaxCalculationStatusString
        {
            get
            {
                if (AutoTaxCalculationStatus)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "RECALCTAX", ResourceType = typeof(InvoiceEntryResx))]
        public string RECALCTAXString
        {
            get
            {
                if (RECALCTAX)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "ShipmentRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        public string ShipmentRateOverrideFlagString
        {
            get
            {
                if (ShipmentRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "GOCALCTAX", ResourceType = typeof(InvoiceEntryResx))]
        public string GOCALCTAXString
        {
            get
            {
                if (GOCALCTAX)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "PerformCreditLimitCheck", ResourceType = typeof(OECommonResx))]
        public string PerformCreditLimitCheckString
        {
            get
            {
                if (PerformCreditLimitCheck)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }


        [Display(Name = "ShipAll", ResourceType = typeof(OECommonResx))]
        public string ShipAllString
        {
            get
            {
                if (ShipAll)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "ForceTaxCalculation", ResourceType = typeof(InvoiceEntryResx))]
        public string ForceTaxCalculationString
        {
            get
            {
                if (ForceTaxCalculation)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "TaxCalculationInProgress", ResourceType = typeof(OECommonResx))]
        public string TaxCalculationInProgressString
        {
            get
            {
                if (TaxCalculationInProgress)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "DisplayRateWarning", ResourceType = typeof(OECommonResx))]
        public string DisplayRateWarningString
        {
            get
            {
                if (DisplayRateWarning)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "CustomerExists", ResourceType = typeof(OECommonResx))]
        public string CustomerExistsString
        {
            get
            {
                if (CustomerExists)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "RecalcMultiPaymentDates", ResourceType = typeof(InvoiceEntryResx))]
        public string RecalcMultiPaymentDatesString
        {
            get
            {
                if (RecalcMultiPaymentDates)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }


        [Display(Name = "GenerateInvFromSingleShip", ResourceType = typeof(InvoiceEntryResx))]
        public string GenerateInvFromSingleShipString
        {
            get
            {
                if (GenerateInvFromSingleShip)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "GenerateInvFromMultShips", ResourceType = typeof(InvoiceEntryResx))]
        public string GenerateInvFromMultShipsString
        {
            get
            {
                if (GenerateInvFromMultShips)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }


        [Display(Name = "OverCreditLimit", ResourceType = typeof(OECommonResx))]
        public string OverCreditLimitString
        {
            get
            {
                if (OverCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "UserCanApproveCreditLift", ResourceType = typeof(OECommonResx))]
        public string UserCanApproveCreditLiftString
        {
            get
            {
                if (UserCanApproveCreditLift)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "CheckingCustomerCreditLimit", ResourceType = typeof(OECommonResx))]
        public string CheckingCustomerCreditLimitString
        {
            get
            {
                if (CheckingCustomerCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "CheckingCustomerAgingLimit", ResourceType = typeof(OECommonResx))]
        public string CheckingCustomerAgingLimitString
        {
            get
            {
                if (CheckingCustomerAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "CheckingNatAcctCreditLimit", ResourceType = typeof(OECommonResx))]
        public string CheckingNatAcctCreditLimitString
        {
            get
            {
                if (CheckingNatAcctCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }


        [Display(Name = "CheckingNatAcctAgingLimit", ResourceType = typeof(OECommonResx))]
        public string CheckingNatAcctAgingLimitString
        {
            get
            {
                if (CheckingNatAcctAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "CustomerIsOverCreditLimit", ResourceType = typeof(OECommonResx))]
        public string CustomerIsOverCreditLimitString
        {
            get
            {
                if (CustomerIsOverCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "CustomerIsOverAgingLimit", ResourceType = typeof(OECommonResx))]
        public string CustomerIsOverAgingLimitString
        {
            get
            {
                if (CustomerIsOverAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "NatAcctIsOverCreditLimit", ResourceType = typeof(OECommonResx))]
        public string NatAcctIsOverCreditLimitString
        {
            get
            {
                if (NatAcctIsOverCreditLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "NatAcctIsOverAgingLimit", ResourceType = typeof(OECommonResx))]
        public string NatAcctIsOverAgingLimitString
        {
            get
            {
                if (NatAcctIsOverAgingLimit)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "ARPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        public string ARPendingTransIncludedString
        {
            get
            {
                if (ARPendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "OEPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        public string OEPendingTransIncludedString
        {
            get
            {
                if (OEPendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "OtherPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        public string OtherPendingTransIncludedString
        {
            get
            {
                if (OtherPendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "DrivenbyUI", ResourceType = typeof(OECommonResx))]
        public string DrivenbyUIString
        {
            get
            {
                if (DrivenbyUI)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "TRRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        public string TRRateOverrideFlagString
        {
            get
            {
                if (TRRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        [Display(Name = "TRShipmentRateOverrideFlag", ResourceType = typeof(InvoiceEntryResx))]
        public string TRShipmentRateOverrideFlagString
        {
            get
            {
                if (TRShipmentRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [Display(Name = "InvoiceDiscountAmountOverride", ResourceType = typeof(InvoiceEntryResx))]
        public string InvoiceDiscountAmountOverrideString
        {
            get
            {
                if (InvoiceDiscountAmountOverride)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }

        [IgnoreExportImport]
        public EnumerableResponse<InvoiceDetail> InvoiceDetails { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<InvoiceOptionalField> InvoiceOptionalFields { get; set; }

        [IgnoreExportImport]
        public InvoicePaymentSchedule InvoicePaymentSchedule { get; set; }

        [IgnoreExportImport]
        public EnumerableResponse<MultipleShipmentsToInvoice> MultipleShipments { get; set; }

        /// <summary>
        /// Gets or sets InvoiceKittingDetails
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<InvoiceKittingDetail> InvoiceKittingDetails { get; set; }

        /// <summary>
        /// Gets or sets FunctionalInvoiceTotalWithTax. This property is used in AR-Customer Inquiry screen. This will hold the equivalent value of Invoice Total With Tax for function currency.
        /// </summary>
        [IgnoreExportImport]
        public decimal FunctionalInvoiceTotalWithTax
        {
            get
            {
                if (InvoiceRate != 0)
                {
                    if (InvoiceRateOperator == 1)
                    {
                        return InvoiceTotalWithTax * InvoiceRate;
                    }
                    return InvoiceTotalWithTax / InvoiceRate;
                }
                return InvoiceTotalWithTax;

            }
        }

        #region Properties Added for Security

        /// <summary>
        /// Gets or Sets InvoiceSecurity
        /// </summary>
        [IgnoreExportImport]
        public InvoiceSecurity InvoiceSecurity { get; set; }

        #endregion

    }
}
