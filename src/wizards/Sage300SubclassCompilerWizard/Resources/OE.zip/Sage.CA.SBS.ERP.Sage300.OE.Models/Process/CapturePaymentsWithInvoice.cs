// Copyright © 2017 Sage Software, Inc

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Process
{
    /// <summary>
    /// Partial class for CapturePaymentsWithInvoice
    /// </summary>
    public partial class CapturePaymentsWithInvoice : ModelBase
    {
        private const char Z = 'Z';

        private const int OrderLength = 22;
        private const int ShipmentLength = 22;
        private const int ProcessingCodeLength = 12;

        public CapturePaymentsWithInvoice()
        {
            IsPrintInvoice = true;
            IsPrintReceipts = true;
            ToOrderNumber = CommonUtil.Repeat(Z, OrderLength);
            ToShipmentNumber = CommonUtil.Repeat(Z, ShipmentLength);
            ToProcessingCode = CommonUtil.Repeat(Z, ProcessingCodeLength);
            PreauthorizedPaymentDetails = new EnumerableResponse<PreauthorizedPaymentDetail>();
        }
        /// <summary>
        /// Gets or sets BatchDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDate", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public DateTime BatchDate { get; set; }

        /// <summary>
        /// Gets or sets FromOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromOrderNumber", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public string FromOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets ToOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToOrderNumber", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public string ToOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets FromShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromShipmentNumber", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public string FromShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets ToShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToShipmentNumber", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public string ToShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets FromProcessingCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromProcessingCode", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public string FromProcessingCode { get; set; }

        /// <summary>
        /// Gets or sets ToProcessingCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToProcessingCode", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public string ToProcessingCode { get; set; }

        /// <summary>
        /// Gets or sets FirstGeneratedOEInvoiceNumbe
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FirstGeneratedOEInvoiceNumbe", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public string FirstGeneratedOEInvoiceNumbe { get; set; }

        /// <summary>
        /// Gets or sets LastGeneratedOEInvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastGeneratedOEInvoiceNumber", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public string LastGeneratedOEInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets FirstGeneratedARBatchNumber
        /// </summary>
        [Display(Name = "FirstGeneratedARBatchNumber", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public decimal FirstGeneratedARBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets LastGeneratedARBatchNumber
        /// </summary>
        [Display(Name = "LastGeneratedARBatchNumber", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public decimal LastGeneratedARBatchNumber { get; set; }

        /// <summary>
        /// Gets and sets PreauthorizedPaymentDetails
        /// </summary>
        public EnumerableResponse<PreauthorizedPaymentDetail> PreauthorizedPaymentDetails { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof (CapturePaymentsWithInvoiceResx))]
        public ProcessCPICommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets RESPIND
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ResponseIndicator { get; set; }

        /// <summary>
        /// Gets or sets RESPCD
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ResponseCode { get; set; }

        /// <summary>
        /// Gets or sets RESPMSG
        /// </summary>
        [StringLength(32, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ResponseMessage { get; set; }

        /// <summary>
        /// Gets or sets AUTHCODE
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string AuthenticationCode { get; set; }

        /// <summary>
        /// Gets or sets AVSRESULT
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string AvsResult { get; set; }

        /// <summary>
        /// Gets or sets CVVRESULT
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CvvResult { get; set; }

        /// <summary>
        /// Gets or sets TRANSDATE
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets VANREF
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string VanRef { get; set; }

        /// <summary>
        /// Gets or sets LAST4
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Last4 { get; set; }

        /// <summary>
        /// Gets or sets PMTDESC
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string PaymentDec { get; set; }

        /// <summary>
        /// Gets or sets PMTTYPEID
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string PaymentTypeId { get; set; }

        /// <summary>
        /// Gets and sets IsPrintReceipts
        /// </summary>
        public bool IsPrintReceipts { get; set; }

        /// <summary>
        /// Gets and sets IsPrintReceipts
        /// </summary>
        public bool IsPrintInvoice { get; set; }

        /// <summary>
        /// Gets and sets if ApplyNone button was pressed.
        /// </summary>
        public bool IsApplyNone { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ProcessCommand string value
        /// </summary>
        public string ProcessCommandString
        {
         get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        #endregion
    }
}