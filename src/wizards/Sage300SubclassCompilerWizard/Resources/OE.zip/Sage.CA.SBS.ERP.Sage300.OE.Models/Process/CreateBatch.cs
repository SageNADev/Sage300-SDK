// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Process
{
     /// <summary>
     /// Partial class for CreateBatch
     /// </summary>
     public partial class CreateBatch : ModelBase
     {
          /// <summary>
          /// Gets or sets CreateGLBatchUptoSequence
          /// </summary>
          [ViewField(Name = Fields.CreateGLBatchUptoSequence, Id = Index.CreateGLBatchUptoSequence, FieldType = EntityFieldType.Long, Size = 4)]
          public long CreateGLBatchUptoSequence {get; set;}

          /// <summary>
          /// Gets or sets TransactionsCreated
          /// </summary>
          [ViewField(Name = Fields.TransactionsCreated, Id = Index.TransactionsCreated, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool TransactionsCreated {get; set;}

          /// <summary>
          /// Gets or sets PostGLBatch
          /// </summary>
          [ViewField(Name = Fields.PostGLBatch, Id = Index.PostGLBatch, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool PostGLBatch {get; set;}

          /// <summary>
          /// Gets or sets PostARBatch
          /// </summary>
          [ViewField(Name = Fields.PostARBatch, Id = Index.PostARBatch, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool PostARBatch {get; set;}
     }
}
