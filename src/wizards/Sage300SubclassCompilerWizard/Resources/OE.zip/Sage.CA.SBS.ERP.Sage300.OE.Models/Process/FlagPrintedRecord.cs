// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Process
{
    /// <summary>
    /// Partial class for FlagPrintedRecord
    /// </summary>
    public partial class FlagPrintedRecord : ModelBase
    {

        #region Model Properties

        /// <summary>
        /// Gets or sets FlagOperation
        /// </summary>
        [ViewField(Name = Fields.FlagOperation, Id = Index.FlagOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public FlagOperation FlagOperation { get; set; }

        /// <summary>
        /// Gets or sets FromDayEndNumber
        /// </summary>
        [ViewField(Name = Fields.FromDayEndNumber, Id = Index.FromDayEndNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long FromDayEndNumber { get; set; }

        /// <summary>
        /// Gets or sets ToDayEndNumber
        /// </summary>
        [ViewField(Name = Fields.ToDayEndNumber, Id = Index.ToDayEndNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ToDayEndNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets SetLabelsPrinted
        /// </summary>
        [ViewField(Name = Fields.SetLabelsPrinted, Id = Index.SetLabelsPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SetLabelsPrinted { get; set; }

        /// <summary>
        /// Gets or sets SetLabelsRequiredFlag
        /// </summary>
        [ViewField(Name = Fields.SetLabelsRequiredFlag, Id = Index.SetLabelsRequiredFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SetLabelsRequiredFlag { get; set; }

        /// <summary>
        /// Gets or sets FromOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromOrderNumber, Id = Index.FromOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string FromOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets ToOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToOrderNumber, Id = Index.ToOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ToOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets FromInvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromInvoiceNumber, Id = Index.FromInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string FromInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets ToInvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToInvoiceNumber, Id = Index.ToInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ToInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets FromCreditDebitNoteNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromCreditDebitNoteNumber, Id = Index.FromCreditDebitNoteNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string FromCreditDebitNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets ToCreditDebitNoteNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToCreditDebitNoteNumber, Id = Index.ToCreditDebitNoteNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ToCreditDebitNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets FromLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromLocation, Id = Index.FromLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FromLocation { get; set; }

        /// <summary>
        /// Gets or sets ToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToLocation, Id = Index.ToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ToLocation { get; set; }

        /// <summary>
        /// Gets or sets DisplayFormsPrintedMessageFl
        /// </summary>
        [ViewField(Name = Fields.DisplayFormsPrintedMessageFl, Id = Index.DisplayFormsPrintedMessageFl, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DisplayFormsPrintedMessageFl { get; set; }

        /// <summary>
        /// Gets or sets FromShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromShipmentNumber, Id = Index.FromShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string FromShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets ToShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToShipmentNumber, Id = Index.ToShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ToShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets PrintPickingSlipsSessionHand
        /// </summary>
        [ViewField(Name = Fields.PrintPickingSlipsSessionHand, Id = Index.PrintPickingSlipsSessionHand, FieldType = EntityFieldType.Long, Size = 4)]
        public long PrintPickingSlipsSessionHand { get; set; }

        /// <summary>
        /// Gets or sets Reprint
        /// </summary>
        [ViewField(Name = Fields.Reprint, Id = Index.Reprint, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Reprint { get; set; }

        #endregion
    }
}
