// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Process
{
    /// <summary>
    /// Partial class for ClearHistory
    /// </summary>
    public partial class ClearHistory : ModelBase
    {
        /// <summary>
        /// Gets or sets ClearOrderHistory
        /// </summary>
       [Display(Name = "ClearTransactionHistory", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ClearOrderHistory, Id = Index.ClearOrderHistory, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ClearOrderHistory { get; set; }

        /// <summary>
        /// Gets or sets ThroughOrderHistoryDate
        /// </summary>
        [Display(Name = "Date", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ThroughOrderHistoryDate, Id = Index.ThroughOrderHistoryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ThroughOrderHistoryDate { get; set; }

        /// <summary>
        /// Gets or sets ClearSalesHistory
        /// </summary>
        [Display(Name = "ClearSalesHistory", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ClearSalesHistory, Id = Index.ClearSalesHistory, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ClearSalesHistory { get; set; }

        /// <summary>
        /// Gets or sets SalesHistoryYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SalesHistoryYear, Id = Index.SalesHistoryYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string SalesHistoryYear { get; set; }

        /// <summary>
        /// Gets or sets SalesHistoryPeriod
        /// </summary>
        [ViewField(Name = Fields.SalesHistoryPeriod, Id = Index.SalesHistoryPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int SalesHistoryPeriod { get; set; }

        /// <summary>
        /// Gets or sets ByCustomerorItem
        /// </summary>
        [ViewField(Name = Fields.ByCustomerorItem, Id = Index.ByCustomerorItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public SelectedBy ByCustomerorItem { get; set; }

        /// <summary>
        /// Gets or sets FromCustomer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromCustomer, Id = Index.FromCustomer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string FromCustomer { get; set; }

        /// <summary>
        /// Gets or sets ToCustomer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToCustomer, Id = Index.ToCustomer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ToCustomer { get; set; }

        /// <summary>
        /// Gets or sets FromItem
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromItem, Id = Index.FromItem, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string FromItem { get; set; }

        /// <summary>
        /// Gets or sets ToItem
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToItem, Id = Index.ToItem, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ToItem { get; set; }

        /// <summary>
        /// Gets or sets ClearStatistics
        /// </summary>
        [Display(Name = "ClearSalesStatistics", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ClearStatistics, Id = Index.ClearStatistics, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ClearStatistics { get; set; }

        /// <summary>
        /// Gets or sets StatisticsYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StatisticsYear, Id = Index.StatisticsYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string StatisticsYear { get; set; }

        /// <summary>
        /// Gets or sets StatisticsPeriod
        /// </summary>
        [ViewField(Name = Fields.StatisticsPeriod, Id = Index.StatisticsPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int StatisticsPeriod { get; set; }

        /// <summary>
        /// Gets or sets ClearSalespersonCommission
        /// </summary>
        [Display(Name = "ClearSalespersonCommissions", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ClearSalespersonCommission, Id = Index.ClearSalespersonCommission, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ClearSalespersonCommission { get; set; }

        /// <summary>
        /// Gets or sets FromSalesperson
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSalesperson, Id = Index.FromSalesperson, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string FromSalesperson { get; set; }

        /// <summary>
        /// Gets or sets ToSalesperson
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSalesperson, Id = Index.ToSalesperson, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string ToSalesperson { get; set; }

        /// <summary>
        /// Gets or sets ClearPrintedPostingJournals
        /// </summary>
        [Display(Name = "ClearPrintedPostingJournals", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ClearPrintedPostingJournals, Id = Index.ClearPrintedPostingJournals, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ClearPrintedPostingJournals { get; set; }

        /// <summary>
        /// Gets or sets ThroughDayEndNo
        /// </summary>
        [ViewField(Name = Fields.ThroughDayEndNo, Id = Index.ThroughDayEndNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long ThroughDayEndNo { get; set; }

        /// <summary>
        /// Gets or sets Invoices
        /// </summary>
        [Display(Name = "Invoices", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Invoices, Id = Index.Invoices, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Invoices { get; set; }

        /// <summary>
        /// Gets or sets CreditNotes
        /// </summary>
        [Display(Name = "CreditDebitNotes", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CreditNotes, Id = Index.CreditNotes, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CreditNotes { get; set; }

        /// <summary>
        /// Gets or sets Shipments
        /// </summary>
        [Display(Name = "Shipment", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Shipments, Id = Index.Shipments, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Shipments { get; set; }

        
    }
}
