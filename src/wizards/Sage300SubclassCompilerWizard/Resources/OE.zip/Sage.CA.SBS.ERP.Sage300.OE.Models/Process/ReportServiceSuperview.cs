// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Process
{
    /// <summary>
    /// Partial class for ReportService
    /// </summary>
    public partial class ReportServiceSuperview : ModelBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or sets Operation
        /// </summary>
        [ViewField(Name = Fields.Operation, Id = Index.Operation, FieldType = EntityFieldType.Int, Size = 2)]
        public int Operation { get; set; }

        /// <summary>
        /// Gets or sets TempFileName
        /// </summary>
        [StringLength(260, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TempFileName, Id = Index.TempFileName, FieldType = EntityFieldType.Char, Size = 260)]
        public string TempFileName { get; set; }

        /// <summary>
        /// Gets or sets TempFileName2
        /// </summary>
        [StringLength(260, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TempFileName2, Id = Index.TempFileName2, FieldType = EntityFieldType.Char, Size = 260)]
        public string TempFileName2 { get; set; }

        #endregion
    }
}
