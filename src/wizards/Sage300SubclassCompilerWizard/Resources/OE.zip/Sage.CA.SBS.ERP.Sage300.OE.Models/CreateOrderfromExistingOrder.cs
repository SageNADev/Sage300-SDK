// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for Create Order from Existing Order 
    /// </summary>
    public partial class CreateOrderfromExistingOrder : ModelBase
    {
        /// <summary>
        /// Constructor method.
        /// </summary>
        public CreateOrderfromExistingOrder()
        {
            OrderDetails = new EnumerableResponse<OrderDetail>();
            OrderOptionalFields = new EnumerableResponse<OrderOptionalField>();
            OrderDetailOptionalFields = new EnumerableResponse<OrderDetailOptionalField>();
            OrderKittingDetails = new EnumerableResponse<OrderKittingDetail>();
        }

        /// <summary>
        /// Gets or sets FromCustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromCustomerNumber", ResourceType = typeof(OECommonResx))]
        [Key]
        [ViewField(Name = Fields.FromCustomerNumber, Id = Index.FromCustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string FromCustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ToCustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToCustomerNumber", ResourceType = typeof(OECommonResx))]
        [Key]
        [ViewField(Name = Fields.ToCustomerNumber, Id = Index.ToCustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ToCustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets FromOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromOrderNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.FromOrderNumber, Id = Index.FromOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string FromOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets ToOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToOrderNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ToOrderNumber, Id = Index.ToOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ToOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PriceList
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceList", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceList { get; set; }

        /// <summary>
        /// Gets or sets PriceListDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
         [ViewField(Name = Fields.PriceListDescription, Id = Index.PriceListDescription, FieldType = EntityFieldType.Char, Size = 60)]
         public string PriceListDescription { get; set; }

        /// <summary>
        /// Gets or sets ActionPerformed
        /// </summary>
        [ViewField(Name = Fields.ActionPerformed, Id = Index.ActionPerformed, FieldType = EntityFieldType.Int, Size = 2)]
        public int ActionPerformed { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroupDescription", ResourceType = typeof(CopyOrdersResx))]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxGroupCurrency, Id = Index.TaxGroupCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string TaxGroupCurrency { get; set; }

        /// <summary>
        /// Gets or sets FromCustomerCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.FromCustomerCurrency, Id = Index.FromCustomerCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string FromCustomerCurrency { get; set; }

        /// <summary>
        /// Gets or sets ToCustomerCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ToCustomerCurrency, Id = Index.ToCustomerCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string ToCustomerCurrency { get; set; }

        /// <summary>
        /// Gets or sets FromCustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromCustomerName, Id = Index.FromCustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string FromCustomerName { get; set; }

        /// <summary>
        /// Gets or sets ToCustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToCustomerName, Id = Index.ToCustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ToCustomerName { get; set; }

        /// <summary>
        /// Gets or sets OrderType
        /// </summary>
        [ViewField(Name = Fields.OrderType, Id = Index.OrderType, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderType OrderType { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets ProjectInvoicing
        /// </summary>
        [ViewField(Name = Fields.ProjectInvoicing, Id = Index.ProjectInvoicing, FieldType = EntityFieldType.Bool, Size = 2)]
        public ProjectInvoicing ProjectInvoicing { get; set; }

        #region User Entered

        /// <summary>
        /// Gets or sets OrderDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderDate", ResourceType = typeof(OECommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets ExpirationDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpirationDate", ResourceType = typeof(OECommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary> 
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(OECommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets OnHold
        /// </summary>
        public bool OnHold { get; set; }      

        /// <summary>
        /// Gets or sets OrderType
        /// </summary>
        [Display(Name = "OrderType", ResourceType = typeof(OECommonResx))]
        public OrderType CopyOrderType { get; set; }

        /// <summary>
        /// Gets or sets OrderDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderDescription", ResourceType = typeof(CopyOrdersResx))]
        public string OrderDescription { get; set; }

        /// <summary>
        /// Gets or sets OrderReference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(OECommonResx))]
        public string OrderReference { get; set; }

        /// <summary>
        /// Order Details
        /// </summary>
        public EnumerableResponse<OrderDetail> OrderDetails { get; set; }

        /// <summary>
        /// Order Optional fields
        /// </summary>
        public EnumerableResponse<OrderOptionalField> OrderOptionalFields { get; set; }

        /// <summary>
        /// Order Unique Identifier
        /// </summary>
        public decimal OrderUniquifier { get; set; }

        /// <summary>
        /// Order Detail Optional fields
        /// </summary>
        public EnumerableResponse<OrderDetailOptionalField> OrderDetailOptionalFields { get; set; }

        /// <summary>
        /// Order Kitting Details
        /// </summary>
        public EnumerableResponse<OrderKittingDetail> OrderKittingDetails { get; set; }

        /// <summary>
        /// Current Line Number
        /// </summary>
        public int LineNumber { get; set; }

        /// <summary>
        /// Source Currency
        /// </summary>
        public string SourceCurrency { get; set; }
        #endregion
    }
}
