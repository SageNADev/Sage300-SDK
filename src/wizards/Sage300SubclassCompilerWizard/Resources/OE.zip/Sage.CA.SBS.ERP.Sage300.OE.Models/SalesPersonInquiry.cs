// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for SalesPersonInquiry
    /// </summary>
    public partial class SalesPersonInquiry : ModelBase
    {
        #region Constructor

        public SalesPersonInquiry()
        {
            SalesPersonInquiryDetails = new EnumerableResponse<SalesPersonInquiry>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets PrimarySalesperson
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PrimarySalesperson", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.SalesPerson, Id = Index.SalesPerson, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string SalesPerson { get; set; }

        /// <summary>
        /// Gets or sets Year
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period
        /// </summary> 
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Int, Size = 2)]
        public int Period { get; set; }

        /// <summary>
        /// Gets or sets DocDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DocDate, Id = Index.DocDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocDate { get; set; }

        /// <summary>
        /// Gets or sets DocNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DocNumber, Id = Index.DocNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocNumber { get; set; }

        /// <summary>
        /// Gets or sets DocType
        /// </summary> 
        [Display(Name = "DocumentType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DocType, Id = Index.DocType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransType DocType { get; set; }

        /// <summary>
        /// Gets or sets OrderDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets CustCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustCurrency, Id = Index.CustCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustCurrency { get; set; }

        /// <summary>
        /// Gets or sets ShipDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipDate, Id = Index.ShipDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipDate { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PurchaseOrderNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets DocFuncAmount
        /// </summary> 
        [Display(Name = "FunctionalDocumentAmount", ResourceType = typeof(SalesPersonInquiryResx))]
        [ViewField(Name = Fields.DocFuncAmount, Id = Index.DocFuncAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocFuncAmount { get; set; }

        /// <summary>
        /// Gets or sets DocSrcAmount
        /// </summary> 
        [Display(Name = "SourceDocumentAmount", ResourceType = typeof(SalesPersonInquiryResx))]
        [ViewField(Name = Fields.DocSrcAmount, Id = Index.DocSrcAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocSrcAmount { get; set; }

        /// <summary>
        /// Gets or sets PrintDataPipeInvoice
        /// </summary> 
        [ViewField(Name = Fields.PrintDataPipeInvoice, Id = Index.PrintDataPipeInvoice, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PrintDataPipeInvoice { get; set; }

        /// <summary>
        /// Gets or sets SalesPersonInquiryDetails
        /// </summary>
        public EnumerableResponse<SalesPersonInquiry> SalesPersonInquiryDetails { get; set; }

        #endregion

        #region UI Strings

        /// <summary>
        /// Gets DocType string value
        /// </summary>
        public string DocTypeString
        {
            get { return EnumUtility.GetStringValue(DocType); }
        }

        #endregion

        #region Extra Properties
        // Added extra parameters, required for the Sales Person Inquiry Details

        /// <summary>
        /// Gets or sets From Year
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromYear", ResourceType = typeof(OECommonResx))]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets To Year
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToYear", ResourceType = typeof(OECommonResx))]
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or sets From Period
        /// </summary>
        public int FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets To Period
        /// </summary>
        public int ToPeriod { get; set; }

        /// <summary>
        /// Customer currency decimal precision
        /// </summary>
        public string CustomerCurrencyDecimal { get; set; }

        /// <summary>
        /// To get the decimal fraction for Quantity
        /// </summary>
        public string QuantityDecimal { get; set; }

        #endregion
    }
}
