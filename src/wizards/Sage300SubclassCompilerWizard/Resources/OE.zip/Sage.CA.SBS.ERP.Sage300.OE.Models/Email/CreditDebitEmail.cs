﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Email;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Reports;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Email
{
    /// <summary>
    /// A simple symbol for the <see cref="EmailOption"/> for a list of <see cref="CreditDebitReport"/>
    /// </summary>
    public class CreditDebitEmail : ReportsEmailOption<CreditDebitReport>
    {
    }
}