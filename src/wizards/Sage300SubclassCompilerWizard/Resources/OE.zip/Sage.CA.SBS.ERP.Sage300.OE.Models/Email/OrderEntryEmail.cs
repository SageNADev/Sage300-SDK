﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.OE.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Email;
using System.Collections.Generic; 

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models.Email
{
    /// <summary>
    /// Class for Order Entry Email Report
    /// </summary>
    public class OrderEntryEmail : EmailOption
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public OrderEntryEmail()
        {
            Reports = new List<OrderConfirmationReport>();
            QuoteReports = new List<QuoteReport>();
            InvoiceReports=new List<InvoiceReport>();
            CreditDebitReports = new List<CreditDebitReport>();
        }
		
        /// <summary>
        /// Gets or Sets Order Confirmation Reports
        /// </summary>
        public List<OrderConfirmationReport> Reports { get; set; }

        /// <summary>
        /// Gets or Sets Quote Reports
        /// </summary>
        public List<QuoteReport> QuoteReports { get; set; }

        /// <summary>
        /// Gets or Sets Invoice Reports
        /// </summary>
        public List<InvoiceReport> InvoiceReports { get; set; }

        /// <summary>
        /// Gets or Sets CreditDebit Reports
        /// </summary>
        public List<CreditDebitReport> CreditDebitReports { get; set; }
    }
}
