// Copyright (c) 1994-2015 Sage Software, Inc. All rights reserved.

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for OE Option
    /// </summary>
    public partial class Options : ModelBase
    {
        /// <summary>
        /// constructor for OE Options
        /// </summary>
        public Options()
        {

            DeferredARPostingList = new List<Dictionary<string, object>>();
        }

        /// <summary>
        /// Gets or sets DummyKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DummyKey, Id = Index.DummyKey, FieldType = EntityFieldType.Int, Size = 2)]
        public int DummyKey { get; set; }

        /// <summary>
        /// Gets or sets Phone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Phone, Id = Index.Phone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string Phone { get; set; }

        /// <summary>
        /// Gets or sets Fax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Fax, Id = Index.Fax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string Fax { get; set; }

        /// <summary>
        /// Gets or sets ContactName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets DayEndPending
        /// </summary>
        [ViewField(Name = Fields.DayEndPending, Id = Index.DayEndPending, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DayEndPending { get; set; }

        /// <summary>
        /// Gets or sets DirectPrintingonInvoices
        /// </summary>
        [ViewField(Name = Fields.DirectPrintingonInvoices, Id = Index.DirectPrintingonInvoices, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DirectPrintingonInvoices { get; set; }

        /// <summary>
        /// Gets or sets KeepOrderHistory
        /// </summary>
        [ViewField(Name = Fields.KeepOrderHistory, Id = Index.KeepOrderHistory, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool KeepOrderHistory { get; set; }

        /// <summary>
        /// Gets or sets TrackCommissions
        /// </summary>
        [ViewField(Name = Fields.TrackCommissions, Id = Index.TrackCommissions, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TrackCommissions { get; set; }

        /// <summary>
        /// Gets or sets CommissionType
        /// </summary>
        [ViewField(Name = Fields.CommissionType, Id = Index.CommissionType, FieldType = EntityFieldType.Int, Size = 2)]
        public CommissionType CommissionType { get; set; }

        /// <summary>
        /// Gets or sets CalculateBackorderQuantities
        /// </summary>
        [ViewField(Name = Fields.CalculateBackorderQuantities, Id = Index.CalculateBackorderQuantities, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CalculateBackorderQuantities { get; set; }

        /// <summary>
        /// Gets or sets AllowQtyShippedonOrders
        /// </summary>
        [ViewField(Name = Fields.AllowQtyShippedonOrders, Id = Index.AllowQtyShippedonOrders, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowQtyShippedonOrders { get; set; }

        /// <summary>
        /// Gets or sets AccumulateStatistics
        /// </summary>
        [ViewField(Name = Fields.AccumulateStatistics, Id = Index.AccumulateStatistics, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AccumulateStatistics { get; set; }

        /// <summary>
        /// Gets or sets AllowEditStatistics
        /// </summary>
        [ViewField(Name = Fields.AllowEditStatistics, Id = Index.AllowEditStatistics, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowEditStatistics { get; set; }

        /// <summary>
        /// Gets or sets AccumulateStatisticsBy
        /// </summary>
        [ViewField(Name = Fields.AccumulateStatisticsBy, Id = Index.AccumulateStatisticsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public AccumulateStatisticsBy AccumulateStatisticsBy { get; set; }

        /// <summary>
        /// Gets or sets StatisticsPeriodBy
        /// </summary>
        [ViewField(Name = Fields.StatisticsPeriodBy, Id = Index.StatisticsPeriodBy, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsPeriodBy StatisticsPeriodBy { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod1
        /// </summary>
        [Range(typeof(int), "1", "999", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AgingPeriod1, Id = Index.AgingPeriod1, FieldType = EntityFieldType.Int, Size = 2)]
        public int AgingPeriod1 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod2
        /// </summary>
        [Range(typeof(int), "1", "999", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AgingPeriod2, Id = Index.AgingPeriod2, FieldType = EntityFieldType.Int, Size = 2)]
        public int AgingPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod3
        /// </summary>
        [Range(typeof(int), "1", "999", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AgingPeriod3, Id = Index.AgingPeriod3, FieldType = EntityFieldType.Int, Size = 2)]
        public int AgingPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets DefaultRateType
        /// </summary>

        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultRateType, Id = Index.DefaultRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string DefaultRateType { get; set; }

        /// <summary>
        /// Gets or sets AccumulateSalesHistory
        /// </summary>
        [ViewField(Name = Fields.AccumulateSalesHistory, Id = Index.AccumulateSalesHistory, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AccumulateSalesHistory { get; set; }

        /// <summary>
        /// Gets or sets AccumulateSalesHistoryBy
        /// </summary>
        [ViewField(Name = Fields.AccumulateSalesHistoryBy, Id = Index.AccumulateSalesHistoryBy, FieldType = EntityFieldType.Int, Size = 2)]
        public AccumulateStatisticsBy AccumulateSalesHistoryBy { get; set; }

        /// <summary>
        /// Gets or sets SalesHistoryPeriodBy
        /// </summary>
        [ViewField(Name = Fields.SalesHistoryPeriodBy, Id = Index.SalesHistoryPeriodBy, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsPeriodBy SalesHistoryPeriodBy { get; set; }

        /// <summary>
        /// Gets or sets DefaultTemplateCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultTemplateCode, Id = Index.DefaultTemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultTemplateCode { get; set; }

        /// <summary>
        /// Gets or sets OrderNumberLength
        /// </summary>
        [Range(typeof(int), "1", "22", ErrorMessageResourceName = "DocLengthMessage", ErrorMessageResourceType = typeof(CommonResx))]
        [Display(Name = "Order", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderNumberLength, Id = Index.OrderNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrderNumberLength { get; set; }

        /// <summary>
        /// Gets or sets OrderNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderNumberPrefix, Id = Index.OrderNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string OrderNumberPrefix { get; set; }


        /// <summary>
        /// Gets or sets ORDBODYD
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.ORDBODYD, Id = Index.ORDBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string ORDBODYD { get; set; }

        /// <summary>
        /// Gets or sets NextOrderUniquifierKey
        /// </summary>
        [ViewField(Name = Fields.NextOrderUniquifierKey, Id = Index.NextOrderUniquifierKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextOrderUniquifierKey { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumberLength
        /// </summary>
        [Range(typeof(int), "1", "22", ErrorMessageResourceName = "DocLengthMessage", ErrorMessageResourceType = typeof(CommonResx))]
        [Display(Name = "Invoice", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceNumberLength, Id = Index.InvoiceNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoiceNumberLength { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InvoiceNumberPrefix, Id = Index.InvoiceNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string InvoiceNumberPrefix { get; set; }


        /// <summary>
        /// Gets or sets INVBODYD
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.INVBODYD, Id = Index.INVBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%20D")]
        public string INVBODYD { get; set; }

        /// <summary>
        /// Gets or sets CreditNoteNumberLength
        /// </summary>
        [Range(typeof(int), "1", "22", ErrorMessageResourceName = "DocLengthMessage", ErrorMessageResourceType = typeof(CommonResx))]
        [Display(Name = "CreditNote1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CreditNoteNumberLength, Id = Index.CreditNoteNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreditNoteNumberLength { get; set; }

        /// <summary>
        /// Gets or sets CreditNoteNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditNoteNumberPrefix, Id = Index.CreditNoteNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string CreditNoteNumberPrefix { get; set; }


        /// <summary>
        /// Gets or sets CRDBODYD
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.CRDBODYD, Id = Index.CRDBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%20D")]
        public string CRDBODYD { get; set; }

        /// <summary>
        /// Gets or sets NextCreditNoteUniquifierKey
        /// </summary>
        [ViewField(Name = Fields.NextCreditNoteUniquifierKey, Id = Index.NextCreditNoteUniquifierKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextCreditNoteUniquifierKey { get; set; }

        /// <summary>
        /// Gets or sets DayEndBrowseNumber
        /// </summary>
        [ViewField(Name = Fields.DayEndBrowseNumber, Id = Index.DayEndBrowseNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DayEndBrowseNumber { get; set; }

        /// <summary>
        /// Gets or sets QuoteNumberLength
        /// </summary>
        [Range(typeof(int), "1", "22", ErrorMessageResourceName = "DocLengthMessage", ErrorMessageResourceType = typeof(CommonResx))]
        [Display(Name = "Quote", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuoteNumberLength, Id = Index.QuoteNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int QuoteNumberLength { get; set; }

        /// <summary>
        /// Gets or sets QuoteNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.QuoteNumberPrefix, Id = Index.QuoteNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string QuoteNumberPrefix { get; set; }


        /// <summary>
        /// Gets or sets QUOBODYD
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.QUOBODYD, Id = Index.QUOBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%20D")]
        public string QUOBODYD { get; set; }

        /// <summary>
        /// Gets or sets DefaultOrderUOM
        /// </summary>
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.DefaultOrderUOM, Id = Index.DefaultOrderUOM, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultOrderUOM DefaultOrderUOM { get; set; }

        /// <summary>
        /// Gets or sets AllowpostTononexistcustomer
        /// </summary>
        [ViewField(Name = Fields.AllowpostTononexistcustomer, Id = Index.AllowpostTononexistcustomer, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowpostTononexistcustomer { get; set; }

        /// <summary>
        /// Gets or sets Defaultquoteexpiringdays
        /// </summary>
        [Display(Name = "DefaultQuoteExpDays", ResourceType = typeof(OptionsResx))]
        [Range(typeof(int), "1", "999", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Defaultquoteexpiringdays, Id = Index.Defaultquoteexpiringdays, FieldType = EntityFieldType.Int, Size = 2)]
        public int Defaultquoteexpiringdays { get; set; }

        /// <summary>
        /// Gets or sets DebitNoteNumberLength
        /// </summary>
        [Range(typeof(int), "1", "22", ErrorMessageResourceName = "DocLengthMessage", ErrorMessageResourceType = typeof(CommonResx))]
        [Display(Name = "DebitNote", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DebitNoteNumberLength, Id = Index.DebitNoteNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int DebitNoteNumberLength { get; set; }

        /// <summary>
        /// Gets or sets DebitNoteNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DebitNoteNumberPrefix, Id = Index.DebitNoteNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string DebitNoteNumberPrefix { get; set; }


        /// <summary>
        /// Gets or sets DBNBODYD
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.DBNBODYD, Id = Index.DBNBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%20D")]
        public string DBNBODYD { get; set; }

        /// <summary>
        /// Gets or sets NextInvoiceUniquifierKey
        /// </summary>
        [ViewField(Name = Fields.NextInvoiceUniquifierKey, Id = Index.NextInvoiceUniquifierKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextInvoiceUniquifierKey { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumberLength
        /// </summary>
        [Range(typeof(int), "1", "22", ErrorMessageResourceName = "DocLengthMessage", ErrorMessageResourceType = typeof(CommonResx))]
        [Display(Name = "Shipments", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipmentNumberLength, Id = Index.ShipmentNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentNumberPrefix, Id = Index.ShipmentNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipmentNumberPrefix { get; set; }


        /// <summary>
        /// Gets or sets SHIBODYD
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.SHIBODYD, Id = Index.SHIBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%20D")]
        public string SHIBODYD { get; set; }

        /// <summary>
        /// Gets or sets NextShipmentUniquifierKey
        /// </summary>
        [ViewField(Name = Fields.NextShipmentUniquifierKey, Id = Index.NextShipmentUniquifierKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextShipmentUniquifierKey { get; set; }

        /// <summary>
        /// Gets or sets DeferredGLPosting
        /// </summary>
        [ViewField(Name = Fields.DeferredGLPosting, Id = Index.DeferredGLPosting, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DeferredGLPosting { get; set; }

        /// <summary>
        /// Gets or sets GLTransCreatedThruDayEnd
        /// </summary>
        [ViewField(Name = Fields.GLTransCreatedThruDayEnd, Id = Index.GLTransCreatedThruDayEnd, FieldType = EntityFieldType.Long, Size = 4)]
        public long GLTransCreatedThruDayEnd { get; set; }

        /// <summary>
        /// Gets or sets AppendToGLBatch
        /// </summary>
        [ViewField(Name = Fields.AppendToGLBatch, Id = Index.AppendToGLBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public AppendToGLBatch AppendToGLBatch { get; set; }

        /// <summary>
        /// Gets or sets ConsolidateGLBatch
        /// </summary>
        [ViewField(Name = Fields.ConsolidateGLBatch, Id = Index.ConsolidateGLBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public ConsolidateGLBatch ConsolidateGLBatch { get; set; }

        /// <summary>
        /// Gets or sets GLReferenceField
        /// </summary>
        [ViewField(Name = Fields.GLReferenceField, Id = Index.GLReferenceField, FieldType = EntityFieldType.Int, Size = 2)]
        public GLReferenceField GLReferenceField { get; set; }

        /// <summary>
        /// Gets or sets GLDescriptionField
        /// </summary>
        [ViewField(Name = Fields.GLDescriptionField, Id = Index.GLDescriptionField, FieldType = EntityFieldType.Int, Size = 2)]
        public GLDescriptionField GLDescriptionField { get; set; }

        /// <summary>
        /// Gets or sets DefaultQtyOrderedToCommitte
        /// </summary>
        [ViewField(Name = Fields.DefaultQtyOrderedToCommitte, Id = Index.DefaultQtyOrderedToCommitte, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DefaultQtyOrderedToCommitte { get; set; }

        /// <summary>
        /// Gets or sets CreateInvoiceWhenQtyShipped
        /// </summary>
        [ViewField(Name = Fields.CreateInvoiceWhenQtyShipped, Id = Index.CreateInvoiceWhenQtyShipped, FieldType = EntityFieldType.Bool, Size = 2)]
        public CreateInvoiceWhenQtyShipped CreateInvoiceWhenQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets ApplyCNToinvoicethatwascre
        /// </summary>
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.ApplyCNToinvoicethatwascre, Id = Index.ApplyCNToinvoicethatwascre, FieldType = EntityFieldType.Int, Size = 2)]
        public ApplyCNToinvoicethatwascre ApplyCNToinvoicethatwascre { get; set; }

        /// <summary>
        /// Gets or sets IncludePendingARTransactions
        /// </summary>
        [ViewField(Name = Fields.IncludePendingARTransactions, Id = Index.IncludePendingARTransactions, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IncludePendingARTransactions { get; set; }

        /// <summary>
        /// Gets or sets IncludePendingOETransactions
        /// </summary>
        [ViewField(Name = Fields.IncludePendingOETransactions, Id = Index.IncludePendingOETransactions, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IncludePendingOETransactions { get; set; }

        /// <summary>
        /// Gets or sets IncludeOtherPendingTransactio
        /// </summary>
        [ViewField(Name = Fields.IncludeOtherPendingTransactio, Id = Index.IncludeOtherPendingTransactio, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IncludeOtherPendingTransactio { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCalculationMethod
        /// </summary>
        [ViewField(Name = Fields.TaxReportingCalculationMethod, Id = Index.TaxReportingCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingCalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets DefaultOrderWeightUOM
        /// </summary>
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.DefaultOrderWeightUOM, Id = Index.DefaultOrderWeightUOM, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultOrderWeightUOM DefaultOrderWeightUOM { get; set; }

        /// <summary>
        /// Gets or sets DeferredARPosting
        /// </summary>
        [ViewField(Name = Fields.DeferredARPosting, Id = Index.DeferredARPosting, FieldType = EntityFieldType.Int, Size = 2)]
        public DeferredARPosting DeferredARPosting { get; set; }

        /// <summary>
        /// Gets or sets OEShipments
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OEShipments, Id = Index.OEShipments, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string OEShipments { get; set; }

        /// <summary>
        /// Gets or sets OEInvoices
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OEInvoices, Id = Index.OEInvoices, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string OEInvoices { get; set; }

        /// <summary>
        /// Gets or sets OECreditNotes
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OECreditNotes, Id = Index.OECreditNotes, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string OECreditNotes { get; set; }

        /// <summary>
        /// Gets or sets OEDebitNotes
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OEDebitNotes, Id = Index.OEDebitNotes, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string OEDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets OEConsolidatedEntry
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OEConsolidatedEntry, Id = Index.OEConsolidatedEntry, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string OEConsolidatedEntry { get; set; }

        /// <summary>
        /// Gets or sets DefaultPostingDate
        /// </summary>
        [ViewField(Name = Fields.DefaultPostingDate, Id = Index.DefaultPostingDate, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultPostingDate DefaultPostingDate { get; set; }

        /// <summary>
        /// Gets or sets ClearExpiredQuotes
        /// </summary>
        [ViewField(Name = Fields.ClearExpiredQuotes, Id = Index.ClearExpiredQuotes, FieldType = EntityFieldType.Bool, Size = 2)]
        public ClearExpiredQuotes ClearExpiredQuotes { get; set; }

        /// <summary>
        /// Gets or sets ClearExpiredQuotesDays
        /// </summary>
        [Range(typeof(int), "0", "999", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ClearExpiredQuotesDays, Id = Index.ClearExpiredQuotesDays, FieldType = EntityFieldType.Int, Size = 2)]
        public int ClearExpiredQuotesDays { get; set; }

        /// <summary>
        /// Gets or sets StatisticalPeriodType
        /// </summary>
        [ViewField(Name = Fields.StatisticalPeriodType, Id = Index.StatisticalPeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticalPeriodType StatisticalPeriodType { get; set; }

        /// <summary>
        /// Gets or sets StatisticalPeriodLength
        /// </summary>
        [ViewField(Name = Fields.StatisticalPeriodLength, Id = Index.StatisticalPeriodLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int StatisticalPeriodLength { get; set; }

        /// <summary>
        /// Gets or sets StatisticalPeriods
        /// </summary>
        [ViewField(Name = Fields.StatisticalPeriods, Id = Index.StatisticalPeriods, FieldType = EntityFieldType.Int, Size = 2)]
        public int StatisticalPeriods { get; set; }

        /// <summary>
        /// Gets or sets SalesHistoryPeriodType
        /// </summary>
        [ViewField(Name = Fields.SalesHistoryPeriodType, Id = Index.SalesHistoryPeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public SalesHistoryPeriodType SalesHistoryPeriodType { get; set; }

        /// <summary>
        /// Gets or sets SalesHistoryPeriodLength
        /// </summary>
        [ViewField(Name = Fields.SalesHistoryPeriodLength, Id = Index.SalesHistoryPeriodLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int SalesHistoryPeriodLength { get; set; }

        /// <summary>
        /// Gets or sets SalesHistoryPeriods
        /// </summary>
        [ViewField(Name = Fields.SalesHistoryPeriods, Id = Index.SalesHistoryPeriods, FieldType = EntityFieldType.Int, Size = 2)]
        public int SalesHistoryPeriods { get; set; }

        /// <summary>
        /// Gets or sets DefaultOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOrderNumber, Id = Index.DefaultOrderNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultOrderNumber { get; set; }

      
        /// <summary>
        /// Gets or sets ORDVALUE
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.ORDVALUE, Id = Index.ORDVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string ORDVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultInvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultInvoiceNumber, Id = Index.DefaultInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultInvoiceNumber { get; set; }

      
        /// <summary>
        /// Gets or sets INVVALUE
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.INVVALUE, Id = Index.INVVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string INVVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultCreditNoteNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultCreditNoteNumber, Id = Index.DefaultCreditNoteNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultCreditNoteNumber { get; set; }

      
        /// <summary>
        /// Gets or sets CRDVALUE
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.CRDVALUE, Id = Index.CRDVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string CRDVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultQuoteNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultQuoteNumber, Id = Index.DefaultQuoteNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultQuoteNumber { get; set; }


        /// <summary>
        /// Gets or sets QUOVALUE
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.QUOVALUE, Id = Index.QUOVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string QUOVALUE { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.HomeCurrency, Id = Index.HomeCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets DatabaseDriverID
        /// </summary>
        [ViewField(Name = Fields.DatabaseDriverID, Id = Index.DatabaseDriverID, FieldType = EntityFieldType.Int, Size = 2)]
        public int DatabaseDriverID { get; set; }

        /// <summary>
        /// Gets or sets DefaultDebitNoteNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultDebitNoteNumber, Id = Index.DefaultDebitNoteNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultDebitNoteNumber { get; set; }

      
        /// <summary>
        /// Gets or sets DBNVALUE
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.DBNVALUE, Id = Index.DBNVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string DBNVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultShipmentNumber, Id = Index.DefaultShipmentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultShipmentNumber { get; set; }


        /// <summary>
        /// Gets or sets SHIVALUE
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.SHIVALUE, Id = Index.SHIVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string SHIVALUE { get; set; }

        /// <summary>
        /// Gets or sets NextDayEndPostingSeq
        /// </summary>
        [ViewField(Name = Fields.NextDayEndPostingSeq, Id = Index.NextDayEndPostingSeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextDayEndPostingSeq { get; set; }

        /// <summary>
        /// Gets or sets Action
        /// </summary>
        [ViewField(Name = Fields.Action, Id = Index.Action, FieldType = EntityFieldType.Int, Size = 2)]
        public int Action { get; set; }

        /// <summary>
        /// Gets or sets CurrentSalesHistoryYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrentSalesHistoryYear, Id = Index.CurrentSalesHistoryYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string CurrentSalesHistoryYear { get; set; }

        /// <summary>
        /// Gets or sets CurrentSalesHistoryPeriod
        /// </summary>
        [ViewField(Name = Fields.CurrentSalesHistoryPeriod, Id = Index.CurrentSalesHistoryPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int CurrentSalesHistoryPeriod { get; set; }

        /// <summary>
        /// Gets or sets CurrentSalesStatisticsYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrentSalesStatisticsYear, Id = Index.CurrentSalesStatisticsYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string CurrentSalesStatisticsYear { get; set; }

        /// <summary>
        /// Gets or sets CurrentSalesStatisticsPeriod
        /// </summary>
        [ViewField(Name = Fields.CurrentSalesStatisticsPeriod, Id = Index.CurrentSalesStatisticsPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int CurrentSalesStatisticsPeriod { get; set; }

        /// <summary>
        /// Gets or sets RequireInvoicingatShipping
        /// </summary>
        [ViewField(Name = Fields.RequireInvoicingatShipping, Id = Index.RequireInvoicingatShipping, FieldType = EntityFieldType.Int, Size = 2)]
        public RequireInvoicingatShipping RequireInvoicingatShipping { get; set; }

        #region UI Properties

        /// <summary>
        /// Gets CommissionType string value
        /// </summary>
        public string CommissionTypeString
        {
            get { return EnumUtility.GetStringValue(CommissionType); }
        }

        /// <summary>
        /// Gets AccumulateStatisticsBy string value
        /// </summary>
        public string AccumulateStatisticsByString
        {
            get { return EnumUtility.GetStringValue(AccumulateStatisticsBy); }
        }

        /// <summary>
        /// Gets StatisticsPeriodBy string value
        /// </summary>
        public string StatisticsPeriodByString
        {
            get { return EnumUtility.GetStringValue(StatisticsPeriodBy); }
        }

        /// <summary>
        /// Gets AccumulateSalesHistoryBy string value
        /// </summary>
        public string AccumulateSalesHistoryByString
        {
            get { return EnumUtility.GetStringValue(AccumulateSalesHistoryBy); }
        }

        /// <summary>
        /// Gets SalesHistoryPeriodBy string value
        /// </summary>
        public string SalesHistoryPeriodByString
        {
            get { return EnumUtility.GetStringValue(SalesHistoryPeriodBy); }
        }

        /// <summary>
        /// Gets DefaultOrderUOM string value
        /// </summary>
        // ReSharper disable once InconsistentNaming
        public string DefaultOrderUOMString
        {
            get { return EnumUtility.GetStringValue(DefaultOrderUOM); }
        }

        /// <summary>
        /// Gets AppendToGLBatch string value
        /// </summary>
        public string AppendToGLBatchString
        {
            get { return EnumUtility.GetStringValue(AppendToGLBatch); }
        }

        /// <summary>
        /// Gets ConsolidateGLBatch string value
        /// </summary>
        public string ConsolidateGLBatchString
        {
            get { return EnumUtility.GetStringValue(ConsolidateGLBatch); }
        }

        /// <summary>
        /// Gets GLReferenceField string value
        /// </summary>
        public string GLReferenceFieldString
        {
            get { return EnumUtility.GetStringValue(GLReferenceField); }
        }

        /// <summary>
        /// Gets GLDescriptionField string value
        /// </summary>
        public string GLDescriptionFieldString
        {
            get { return EnumUtility.GetStringValue(GLDescriptionField); }
        }

        /// <summary>
        /// Gets CreateInvoiceWhenQtyShipped string value
        /// </summary>
        public string CreateInvoiceWhenQtyShippedString
        {
            get { return EnumUtility.GetStringValue(CreateInvoiceWhenQtyShipped); }
        }

        /// <summary>
        /// Gets ApplyCNToinvoicethatwascre string value
        /// </summary>
        // ReSharper disable once InconsistentNaming
        public string ApplyCNToinvoicethatwascreString
        {
            get { return EnumUtility.GetStringValue(ApplyCNToinvoicethatwascre); }
        }

        /// <summary>
        /// Gets DefaultOrderWeightUOM string value
        /// </summary>
        // ReSharper disable once InconsistentNaming
        public string DefaultOrderWeightUOMString
        {
            get { return EnumUtility.GetStringValue(DefaultOrderWeightUOM); }
        }

        /// <summary>
        /// Gets DeferredARPosting string value
        /// </summary>
        public string DeferredARPostingString
        {
            get { return EnumUtility.GetStringValue(DeferredARPosting); }
        }

        /// <summary>
        /// Gets DefaultPostingDate string value
        /// </summary>
        public string DefaultPostingDateString
        {
            get { return EnumUtility.GetStringValue(DefaultPostingDate); }
        }

        /// <summary>
        /// Gets ClearExpiredQuotes string value
        /// </summary>
        public string ClearExpiredQuotesString
        {
            get { return EnumUtility.GetStringValue(ClearExpiredQuotes); }
        }

        /// <summary>
        /// Gets StatisticalPeriodType string value
        /// </summary>
        public string StatisticalPeriodTypeString
        {
            get { return EnumUtility.GetStringValue(StatisticalPeriodType); }
        }

        /// <summary>
        /// Gets SalesHistoryPeriodType string value
        /// </summary>
        public string SalesHistoryPeriodTypeString
        {
            get { return EnumUtility.GetStringValue(SalesHistoryPeriodType); }
        }

        /// <summary>
        /// Gets RequireInvoicingatShipping string value
        /// </summary>
        public string RequireInvoicingatShippingString
        {
            get { return EnumUtility.GetStringValue(RequireInvoicingatShipping); }
        }

        /// <summary>
        /// Get or Set Deferred A/R Posting List
        /// </summary>
        public List<Dictionary<string, object>> DeferredARPostingList { get; set; }

        /// <summary>
        /// gets boolean property for  IsTaxReportingCalculationMethod based on TaxReportingCalculationMethod, int value.
        /// </summary>
        public bool IsTaxReportingCalculationMethod { get; set; }  // Used to place the Int property into bool which used as checkbox on screen.

        /// <summary>
        /// gets boolean property for  IsClearExpiredQuotes based on ClearExpiredQuotes, Enum Values
        /// </summary>
        public bool IsClearExpiredQuotes { get; set; }

        #endregion

        #region CompanyProfile

        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        public CompanyProfile CompanyProfile { get; set; }

        #endregion
    }
}
