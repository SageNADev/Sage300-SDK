// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Partial class for OrderCommentsInstruction
     /// </summary>
     public partial class OrderCommentsInstruction : ModelBase
     {
          /// <summary>
          /// Gets or sets OrderUniquifier
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          public decimal OrderUniquifier {get; set;}

          /// <summary>
          /// Gets or sets Uniquifier
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          public int Uniquifier {get; set;}

          /// <summary>
          /// Gets or sets DetailNumber
          /// </summary>
          public int DetailNumber {get; set;}

          /// <summary>
          /// Gets or sets CommentsInstructionsType
          /// </summary>
          public CommentsInstructionsType CommentsInstructionsType {get; set;}

          /// <summary>
          /// Gets or sets CommentsInstructions
          /// </summary>
          [StringLength(80, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string CommentsInstructions {get; set;}

          /// <summary>
          /// Gets or sets Invoiced
          /// </summary>
          public bool Invoiced {get; set;}

     }
}
