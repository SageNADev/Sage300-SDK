// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for MiscellaneousChargeTaxe
    /// </summary>
    public partial class MiscellaneousChargeTax : ModelBase
    {
        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets MiscellaneousChargeCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscChargeCode", ResourceType = typeof(MiscellaneousChargesResx))]
        [ViewField(Name = Fields.MiscellaneousChargeCode, Id = Index.MiscellaneousChargeCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string MiscellaneousChargeCode { get; set; }

        /// <summary>
        /// Gets or sets Authority
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Authority", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Authority, Id = Index.Authority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Authority { get; set; }

        /// <summary>
        /// Gets or sets SalesTaxClass
        /// </summary>
        [Display(Name = "SalesTaxClass", ResourceType = typeof(MiscellaneousChargesResx))]
        [ViewField(Name = Fields.SalesTaxClass, Id = Index.SalesTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
        public int SalesTaxClass { get; set; }

        /// <summary>
        /// Gets or sets AuthorityDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AuthorityDescription", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.AuthorityDescription, Id = Index.AuthorityDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string AuthorityDescription { get; set; }

        /// <summary>
        /// Gets or sets ClassDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ClassDescription", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ClassDescription, Id = Index.ClassDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ClassDescription { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }

    }
}
