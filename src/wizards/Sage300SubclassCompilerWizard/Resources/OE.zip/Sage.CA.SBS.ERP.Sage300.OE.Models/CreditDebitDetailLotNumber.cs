// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for CreditDebitDetailLotNumber
    /// </summary>
    public partial class CreditDebitDetailLotNumber : ModelBase
    {
        /// <summary>
        /// Gets or sets CreditNoteUniquifier
        /// </summary>
        [Key]
        [Display(Name = "CreditNoteUniquifier", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditNoteUniquifier, Id = Index.CreditNoteUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CreditNoteUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Display(Name = "LineNumber", ResourceType = typeof(OECommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [Key]
        [Display(Name = "LotNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string LotNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets ExpirationDate
        /// </summary>
        [Display(Name = "ExpirationDate", ResourceType = typeof(OECommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets QuantityInStockingUOM
        /// </summary>
        [Display(Name = "QuantityInStockingUom", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public decimal QuantityInStockingUom { get; set; }

        /// <summary>
        /// Gets or sets TransactionQuantity
        /// </summary>
        [Display(Name = "TransactionQuantity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TransactionQuantity { get; set; }

        /// <summary>
        /// Gets or sets InvQtyInStockingUOM
        /// </summary>
        [Display(Name = "InvQtyInStockingUom", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public decimal InvQtyInStockingUom { get; set; }

        /// <summary>
        /// Gets or sets Cost
        /// </summary>
        [Display(Name = "Cost", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Cost { get; set; }

    }
}
