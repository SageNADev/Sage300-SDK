// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for CreditDebitBOMDetail
    /// </summary>
    public partial class CreditDebitBomDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets CNUniquifier
        /// </summary>
        [Key]
        [Display(Name = "CNUniquifier", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal CnUniquifier { get; set; }

        /// <summary>
        /// Gets or sets DetailLineNumber
        /// </summary>
        [Key]
        [Display(Name = "DetailLineNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DetailLineNumber, Id = Index.DetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ParentComponentNumber
        /// </summary>
        [Key]
        [Display(Name = "ParentComponentNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ParentComponentNumber, Id = Index.ParentComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ParentComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentNumber
        /// </summary>
        [Key]
        [Display(Name = "ComponentNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ComponentNumber, Id = Index.ComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentItemNo
        /// </summary>
        [Display(Name = "ComponentItemNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ComponentItemNo, Id = Index.ComponentItemNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ComponentItemNo { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ComponentQuantity
        /// </summary>
        [Display(Name = "ComponentQuantity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ComponentQuantity, Id = Index.ComponentQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ComponentQuantity { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(OECommonResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturned
        /// </summary>
        [Display(Name = "QtyReturned", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantityReturned, Id = Index.QuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets ComponentsBOMNumber
        /// </summary>
        [Display(Name = "CompBomNo", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ComponentsBomNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentsBOMBuildQty
        /// </summary>
        [Display(Name = "ComponentsBOMBuildQty", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public decimal ComponentsBomBuildQty { get; set; }

        /// <summary>
        /// Gets or sets ComponentsBOMBuildUnit
        /// </summary>
        [Display(Name = "ComponentsBOMBuildUnit", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ComponentsBomBuildUnit { get; set; }

        /// <summary>
        /// Gets or sets ComponentsBOMBuildUnitConv
        /// </summary>
        [Display(Name = "ComponentsBOMBuildUnitConv", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public decimal ComponentsBomBuildUnitConv { get; set; }

        /// <summary>
        /// Gets or sets UnitConversion
        /// </summary>
        [Display(Name = "UnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnitConversion, Id = Index.UnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitConversion { get; set; }

    }
}
