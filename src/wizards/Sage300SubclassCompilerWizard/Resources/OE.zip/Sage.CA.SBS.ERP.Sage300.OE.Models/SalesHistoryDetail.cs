// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for SalesHistoryDetail Items
    /// </summary>
    public partial class SalesHistoryDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ITEM
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Year
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Int, Size = 2)]
        public int Period { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustCurrency, Id = Index.CustCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustCurrency { get; set; }

        // It is required to display the Decimal values
        /// <summary>
        /// Gets or Sets the Currency Decimal
        /// </summary>
        public string CurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets TransDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TransDate, Id = Index.TransDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransDate { get; set; }

        /// <summary>
        /// Gets or sets DayEndNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DayEndNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DayEndNumber, Id = Index.DayEndNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DayEndNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VlsEntryNo", ResourceType = typeof(SalesHistoryDetailResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets TransNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VlsTransNo", ResourceType = typeof(SalesHistoryDetailResx))]
        [ViewField(Name = Fields.TransNumber, Id = Index.TransNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string TransNumber { get; set; }

        /// <summary>
        /// Gets or sets TransType
        /// </summary>
        [Display(Name = "VlsTransType", ResourceType = typeof(SalesHistoryDetailResx))]
        [ViewField(Name = Fields.TransType, Id = Index.TransType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransType TransType { get; set; }

        /// <summary>
        /// To get the string of TransType property
        /// </summary>
        /// <value>The type string</value>
        [Display(Name = "VlsTransType", ResourceType = typeof(SalesHistoryDetailResx))]
        public string TransTypeString
        {
            get { return EnumUtility.GetStringValue(TransType); }
        }

        /// <summary>
        /// Gets or sets OrderDate
        /// </summary>
        [Display(Name = "OrderDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipDate
        /// </summary>
        [Display(Name = "ShipmentDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipDate, Id = Index.ShipDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipDate { get; set; }

        /// <summary>
        /// Gets or sets Salesperson
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SalespersonCode", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Salesperson, Id = Index.Salesperson, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson { get; set; }

        /// <summary>
        /// Gets or sets Territory
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Territory", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Territory, Id = Index.Territory, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Territory { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets QuantitySold
        /// </summary>
        [Display(Name = "QuantitySold", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantitySold, Id = Index.QuantitySold, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantitySold { get; set; }

        /// <summary>
        /// Gets or sets FuncCostOfSales
        /// </summary>
        [ViewField(Name = Fields.FuncCostOfSales, Id = Index.FuncCostOfSales, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCostOfSales { get; set; }

        /// <summary>
        /// Gets or sets SrceCostOfSales
        /// </summary>
        [ViewField(Name = Fields.SrceCostOfSales, Id = Index.SrceCostOfSales, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceCostOfSales { get; set; }

        /// <summary>
        /// Gets or sets FuncSalesAmount
        /// </summary>
        [ViewField(Name = Fields.FuncSalesAmount, Id = Index.FuncSalesAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncSalesAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceSalesAmount
        /// </summary>
        [ViewField(Name = Fields.SrceSalesAmount, Id = Index.SrceSalesAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceSalesAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncReturnAmount
        /// </summary>
        [ViewField(Name = Fields.FuncReturnAmount, Id = Index.FuncReturnAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncReturnAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceReturnAmount
        /// </summary>
        [ViewField(Name = Fields.SrceReturnAmount, Id = Index.SrceReturnAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceReturnAmount { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAmount
        /// </summary>
        [ViewField(Name = Fields.FunctionalAmount, Id = Index.FunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets SourceAmount
        /// </summary>
        [ViewField(Name = Fields.SourceAmount, Id = Index.SourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalDiscountAmount
        /// </summary>
        [ViewField(Name = Fields.FunctionalDiscountAmount, Id = Index.FunctionalDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets SourceDiscountAmount
        /// </summary>
        [ViewField(Name = Fields.SourceDiscountAmount, Id = Index.SourceDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDetailNumber
        /// </summary>
        [ViewField(Name = Fields.ShipmentDetailNumber, Id = Index.ShipmentDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets ITEMFMT
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string FormattedItemNumber { get; set; }

        #region Extra Properties

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        public string ItemDescription { get; set; }

        #endregion

    }
}
