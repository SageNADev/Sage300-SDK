// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Partial class for InvoiceDetailLotNumber
	/// </summary>
	public partial class InvoiceDetailLotNumber : ModelBase
	{
		/// <summary>
		/// Gets or sets InvoiceUniquifier
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "InvoiceUniquifier", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal InvoiceUniquifier { get; set; }

		/// <summary>
		/// Gets or sets LineNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "LineNumber", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int LineNumber { get; set; }

		/// <summary>
		/// Gets or sets LotNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "LotNumber", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
		public string LotNumber { get; set; }

		/// <summary>
		/// Gets or sets DetailNumber
		/// </summary>
		[Display(Name = "DetailNumber", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int DetailNumber { get; set; }

		/// <summary>
		/// Gets or sets ExpirationDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ExpirationDate", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ExpirationDate { get; set; }

		/// <summary>
		/// Gets or sets QuantityInStockingUOM
		/// </summary>
		[Display(Name = "QuantityInStockingUOM", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.QuantityInStockingUOM, Id = Index.QuantityInStockingUOM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityInStockingUOM { get; set; }

		/// <summary>
		/// Gets or sets TransactionQuantity
		/// </summary>
		[Display(Name = "TransactionQuantity", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal TransactionQuantity { get; set; }

		/// <summary>
		/// Gets or sets Cost
		/// </summary>
		[Display(Name = "Cost", ResourceType = typeof (OECommonResx))]
		[ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal Cost { get; set; }

		#region UI Strings

		#endregion
	}
}
