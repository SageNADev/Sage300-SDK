// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Partial class for CreditDebitDetailSerialNo
     /// </summary>
     public partial class CreditDebitDetailSerialNo : ModelBase
     {
          /// <summary>
          /// Gets or sets CreditNoteUniquifier
          /// </summary>
          [Key]
          [Display(Name = "CreditNoteUniquifier", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.CreditNoteUniquifier, Id = Index.CreditNoteUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CreditNoteUniquifier {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [Key]
          [Display(Name = "LineNumber", ResourceType = typeof(OECommonResx))]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int LineNumber {get; set;}

          /// <summary>
          /// Gets or sets SerialNumber
          /// </summary>
          [Key]
          [Display(Name = "SerialNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
          public string SerialNumber {get; set;}

          /// <summary>
          /// Gets or sets DetailNumber
          /// </summary>
          [Display(Name = "DetailNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int DetailNumber {get; set;}

          /// <summary>
          /// Gets or sets Cost
          /// </summary>
          [Display(Name = "Cost", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal Cost {get; set;}

          /// <summary>
          /// Gets or sets TransactionQuantity
          /// </summary>
          [Display(Name = "TransactionQuantity", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Long, Size = 4)]
          public long TransactionQuantity {get; set;}

     }
}
