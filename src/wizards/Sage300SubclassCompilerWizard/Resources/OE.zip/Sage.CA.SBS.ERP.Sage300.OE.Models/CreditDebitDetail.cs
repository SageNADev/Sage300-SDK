// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for CreditDebitDetail
    /// </summary>
    public partial class CreditDebitDetail : ModelBase
    {
        public CreditDebitDetail()
        {
            CrdDbnCommentsInstructions = new EnumerableResponse<CreditDebitCommentInstruction>();
            CreditDebitKittingDetail = new EnumerableResponse<CreditDebitKittingDetail>();
            CommonKittingDetail = new EnumerableResponse<CommonKittingDetail>();
        }

        [IgnoreExportImport]
        public IDictionary<string, object> Attributes { get; set; }

        /// <summary>
        /// Gets or sets CNUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CNUniquifier", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CnUniquifier, Id = Index.CnUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CnUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        public int SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets LineType
        /// </summary>
        [Display(Name = "LineType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
        public LineType LineType { get; set; }

        /// <summary>
        /// Gets or sets Item
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Item", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.Item, Id = Index.Item, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string Item { get; set; }

        /// <summary>
        /// Gets or sets MiscellaneousChargesCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiscellaneousChargesCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.MiscellaneousChargesCode, Id = Index.MiscellaneousChargesCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string MiscellaneousChargesCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ItemAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemAccountSet", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ItemAccountSet, Id = Index.ItemAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ItemAccountSet { get; set; }

        /// <summary>
        /// Gets or sets UserSpecifiedCostingMethod
        /// </summary>
        [Display(Name = "UserSpecifiedCostingMethod", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UserSpecifiedCostingMethod, Id = Index.UserSpecifiedCostingMethod, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UserSpecifiedCostingMethod { get; set; }

        /// <summary>
        /// Gets or sets PriceList
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceList", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceList { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets PickingSequence
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PickingSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PickingSequence, Id = Index.PickingSequence, FieldType = EntityFieldType.Char, Size = 10)]
        public string PickingSequence { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        [Display(Name = "StockItem", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StockItem { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturned
        /// </summary>
        [Display(Name = "QtyReturned", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantityReturned, Id = Index.QuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets QuantityShipped
        /// </summary>
        [Display(Name = "QtyShipped", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantityShipped, Id = Index.QuantityShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityShipped { get; set; }

        /// <summary>
        /// Gets or sets QuantityBackordered
        /// </summary>
        [Display(Name = "QtyBO", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.QuantityBackordered, Id = Index.QuantityBackordered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityBackordered { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditDebitNoteUom", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteUom, Id = Index.CreditDebitNoteUom, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string CreditDebitNoteUom { get; set; }

        /// <summary>
        /// Gets or sets UnitConversion
        /// </summary>
        [Display(Name = "UnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnitConversion, Id = Index.UnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitConversion { get; set; }

        /// <summary>
        /// Gets or sets UnitPrice
        /// </summary>
        [Display(Name = "UnitPrice", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.UnitPrice, Id = Index.UnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// Gets or sets PriceOverride
        /// </summary>
        [Display(Name = "PriceOverride", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PriceOverride, Id = Index.PriceOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PriceOverride { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets MostRecentUnitCost
        /// </summary>
        [Display(Name = "MostRecentUnitCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.MostRecentUnitCost, Id = Index.MostRecentUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal MostRecentUnitCost { get; set; }

        /// <summary>
        /// Gets or sets StandardUnitCost
        /// </summary>
        [Display(Name = "StandardUnitCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.StandardUnitCost, Id = Index.StandardUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal StandardUnitCost { get; set; }

        /// <summary>
        /// Gets or sets AlternateUnitCost1
        /// </summary>
        [Display(Name = "AlternateUnitCost1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AlternateUnitCost1, Id = Index.AlternateUnitCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AlternateUnitCost1 { get; set; }

        /// <summary>
        /// Gets or sets AlternateUnitCost2
        /// </summary>
        [Display(Name = "AlternateUnitCost2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AlternateUnitCost2, Id = Index.AlternateUnitCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AlternateUnitCost2 { get; set; }

        /// <summary>
        /// Gets or sets UnitPriceNoOfDecimals
        /// </summary>
        [Display(Name = "UnitPriceNoOfDecimals", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnitPriceNoOfDecimals, Id = Index.UnitPriceNoOfDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int UnitPriceNoOfDecimals { get; set; }

        /// <summary>
        /// Gets or sets PricingUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingUnit", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PricingUnit, Id = Index.PricingUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string PricingUnit { get; set; }

        /// <summary>
        /// Gets or sets PricingUnitPrice
        /// </summary>
        [Display(Name = "PricingUnitPrice", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PricingUnitPrice, Id = Index.PricingUnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingUnitPrice { get; set; }

        /// <summary>
        /// Gets or sets PricingUnitConversion
        /// </summary>
        [Display(Name = "PricingUnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PricingUnitConversion, Id = Index.PricingUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets PriceDiscountPercentage
        /// </summary>
        [Display(Name = "PriceDiscountPercentage", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PriceDiscountPercentage, Id = Index.PriceDiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PriceDiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets PriceDiscountAmount
        /// </summary>
        [Display(Name = "PriceDiscountAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PriceDiscountAmount, Id = Index.PriceDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PriceDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PricingBaseUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingBaseUnit", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PricingBaseUnit, Id = Index.PricingBaseUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string PricingBaseUnit { get; set; }

        /// <summary>
        /// Gets or sets PricingBaseUnitPrice
        /// </summary>
        [Display(Name = "PricingBaseUnitPrice", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PricingBaseUnitPrice, Id = Index.PricingBaseUnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingBaseUnitPrice { get; set; }

        /// <summary>
        /// Gets or sets PricingBaseUnitConversion
        /// </summary>
        [Display(Name = "PricingBaseUnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PricingBaseUnitConversion, Id = Index.PricingBaseUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingBaseUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets CostingUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostingUnit", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CostingUnit, Id = Index.CostingUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string CostingUnit { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitCost
        /// </summary>
        [Display(Name = "CostingUnitCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CostingUnitCost, Id = Index.CostingUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal CostingUnitCost { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitConversion
        /// </summary>
        [Display(Name = "CostingUnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CostingUnitConversion, Id = Index.CostingUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal CostingUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets ExtendedDetailCost
        /// </summary>
        [Display(Name = "ExtendedDetailCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtendedDetailCost, Id = Index.ExtendedDetailCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedDetailCost { get; set; }

        /// <summary>
        /// Gets or sets ExtendedAmountMiscCharge
        /// </summary>
        [Display(Name = "ExtendedAmountMiscCharge", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtendedAmountMiscCharge, Id = Index.ExtendedAmountMiscCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedAmountMiscCharge { get; set; }

        /// <summary>
        /// Gets or sets CreditNoteDiscountAmount
        /// </summary>
        [Display(Name = "CreditNoteDiscountAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditNoteDiscountAmount, Id = Index.CreditNoteDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditNoteDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets ExtendedAmountOverride
        /// </summary>
        [Display(Name = "ExtendedAmountOverride", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtendedAmountOverride, Id = Index.ExtendedAmountOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ExtendedAmountOverride { get; set; }

        /// <summary>
        /// Gets or sets InvoiceExtendedCost
        /// </summary>
        [Display(Name = "InvoiceExtendedCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoiceExtendedCost, Id = Index.InvoiceExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets UnitWeight
        /// </summary>
        [Display(Name = "UnitWeight", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.UnitWeight, Id = Index.UnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal UnitWeight { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [Display(Name = "ExtendedWeight", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets ReturnType
        /// </summary>
        [Display(Name = "ReturnType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ReturnType, Id = Index.ReturnType, FieldType = EntityFieldType.Int, Size = 2)]
        public ReturnType ReturnType { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1
        /// </summary>
        [Display(Name = "TaxRate1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2
        /// </summary>
        [Display(Name = "TaxRate2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3
        /// </summary>
        [Display(Name = "TaxRate3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4
        /// </summary>
        [Display(Name = "TaxRate4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5
        /// </summary>
        [Display(Name = "TaxRate5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets HaveCommentsInstructions
        /// </summary>
        [Display(Name = "HaveCommentsInstructions", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.HaveCommentsInstructions, Id = Index.HaveCommentsInstructions, FieldType = EntityFieldType.Bool, Size = 2)]
        public HaveCommentsInstructions HaveCommentsInstructions { get; set; }

        /// <summary>
        /// Rate operation enum
        /// </summary>
        public string HaveCommentsInstructionsString
        {
            get { return EnumUtility.GetStringValue(HaveCommentsInstructions); }
        }

        /// <summary>
        /// Gets or sets TotalCRMostRecentCost
        /// </summary>
        [Display(Name = "TotalCrMostRecentCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TotalCrMostRecentCost, Id = Index.TotalCrMostRecentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCrMostRecentCost { get; set; }

        /// <summary>
        /// Gets or sets TotalCRStandardCost
        /// </summary>
        [Display(Name = "TotalCrStandardCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TotalCrStandardCost, Id = Index.TotalCrStandardCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCrStandardCost { get; set; }

        /// <summary>
        /// Gets or sets TotalCRCost1
        /// </summary>
        [Display(Name = "TotalCrCost1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TotalCrCost1, Id = Index.TotalCrCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCrCost1 { get; set; }

        /// <summary>
        /// Gets or sets TotalCRCost2
        /// </summary>
        [Display(Name = "TotalCrCost2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TotalCrCost2, Id = Index.TotalCrCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCrCost2 { get; set; }

        /// <summary>
        /// Gets or sets PriceListDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceListDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PriceListDescription, Id = Index.PriceListDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string PriceListDescription { get; set; }

        /// <summary>
        /// Gets or sets CategoryDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CategoryDescription, Id = Index.CategoryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CategoryDescription { get; set; }

        /// <summary>
        /// Gets or sets LocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LocationDescription, Id = Index.LocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1Desc", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority1Description, Id = Index.TaxAuthority1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2Desc", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority2Description, Id = Index.TaxAuthority2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3Desc", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority3Description, Id = Index.TaxAuthority3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4Desc", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority4Description, Id = Index.TaxAuthority4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5Desc", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxAuthority5Description, Id = Index.TaxAuthority5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority5Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass1Description", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass2Description", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass3Description", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass4Description", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass5Description", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets DrivenbyUI
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.DrivenbyUi, Id = Index.DrivenbyUi, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DrivenbyUi { get; set; }

        /// <summary>
        /// Gets or sets FoundNegativeInventory
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.FoundNegativeInventory, Id = Index.FoundNegativeInventory, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FoundNegativeInventory { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearingAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLNonStkClearingAcct", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.NonstockClearingAccount, Id = Index.NonstockClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string NonstockClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearingAcctDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NonstockClearingAcctDesc", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.NonstockClearingAcctDesc, Id = Index.NonstockClearingAcctDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string NonstockClearingAcctDesc { get; set; }

        /// <summary>
        /// Gets or sets InterprocessCommID
        /// </summary>
        [Display(Name = "InterprocessCommId", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InterprocessCommId, Id = Index.InterprocessCommId, FieldType = EntityFieldType.Long, Size = 4)]
        public long InterprocessCommId { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSN
        /// </summary>
        [Display(Name = "ForcePopupSn", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ForcePopupSn, Id = Index.ForcePopupSn, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupSN ForcePopupSn { get; set; }

        /// <summary>
        /// Gets or sets PopupSN
        /// </summary>
        [Display(Name = "PopupSn", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PopupSn, Id = Index.PopupSn, FieldType = EntityFieldType.Int, Size = 2)]
        public PopupSN PopupSn { get; set; }

        /// <summary>
        /// Gets or sets CloseSN
        /// </summary>
        ///  - CDN
        [Display(Name = "CloseSn", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CloseSn, Id = Index.CloseSn, FieldType = EntityFieldType.Bool, Size = 2)]
        public CloseSN CloseSn { get; set; }

        /// <summary>
        /// Gets or sets LTSetID
        /// </summary>
        [Display(Name = "LtSetId", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LtSetId, Id = Index.LtSetId, FieldType = EntityFieldType.Long, Size = 4)]
        public long LtSetId { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLT
        /// </summary>
        [Display(Name = "ForcePopupLt", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ForcePopupLt, Id = Index.ForcePopupLt, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupLT ForcePopupLt { get; set; }

        /// <summary>
        /// Gets or sets PopupLT
        /// </summary>
        [Display(Name = "PopupLt", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PopupLt, Id = Index.PopupLt, FieldType = EntityFieldType.Int, Size = 2)]
        public PopupLT PopupLt { get; set; }

        /// <summary>
        /// Gets or sets CloseLT
        /// </summary>
        [Display(Name = "CloseLt", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CloseLt, Id = Index.CloseLt, FieldType = EntityFieldType.Bool, Size = 2)]
        public CloseLT CloseLt { get; set; }

        /// <summary>
        /// Gets or sets AverageUnitCost
        /// </summary>
        [Display(Name = "AverageUnitCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AverageUnitCost, Id = Index.AverageUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AverageUnitCost { get; set; }

        /// <summary>
        /// Gets or sets LastUnitCost
        /// </summary>
        [Display(Name = "LastUnitCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LastUnitCost, Id = Index.LastUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal LastUnitCost { get; set; }

        /// <summary>
        /// Gets or sets TotalCRAverageCost
        /// </summary>
        [Display(Name = "TotalCrAverageCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TotalCrAverageCost, Id = Index.TotalCrAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCrAverageCost { get; set; }

        /// <summary>
        /// Gets or sets TotalCRLastCost
        /// </summary>
        [Display(Name = "TotalCrLastCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TotalCrLastCost, Id = Index.TotalCrLastCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCrLastCost { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTrackingNumber
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentTrackingNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipmentTrackingNumber, Id = Index.ShipmentTrackingNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string ShipmentTrackingNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipViaCode", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipViaCodesDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipViaCodeDescription, Id = Index.ShipViaCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets DiscountPercent
        /// </summary>
        [Display(Name = "DiscountPercent", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DiscountPercent, Id = Index.DiscountPercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountPercent { get; set; }

        /// <summary>
        /// Gets or sets ExtendedDiscountedPrice
        /// </summary>
        [Display(Name = "ExtendedDiscountedPrice", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtendedDiscountedPrice, Id = Index.ExtendedDiscountedPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedDiscountedPrice { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipmentDate, Id = Index.ShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceCurrentQtyOutstanding
        /// </summary>
        [Display(Name = "InvoiceCurrentQtyOutstanding", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoiceCurrentQtyOutstanding, Id = Index.InvoiceCurrentQtyOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal InvoiceCurrentQtyOutstanding { get; set; }

        /// <summary>
        /// Gets or sets InvoiceUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceUnitOfMeasure", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoiceUnitOfMeasure, Id = Index.InvoiceUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string InvoiceUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets InvoiceUnitConversion
        /// </summary>
        [Display(Name = "InvoiceUnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoiceUnitConversion, Id = Index.InvoiceUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal InvoiceUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets OrderQuantityOrdered
        /// </summary>
        [Display(Name = "OrderQuantityOrdered", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.OrderQuantityOrdered, Id = Index.OrderQuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal OrderQuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets OrderQuantityBackordered
        /// </summary>
        [Display(Name = "OrderQuantityBackordered", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.OrderQuantityBackordered, Id = Index.OrderQuantityBackordered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal OrderQuantityBackordered { get; set; }

        /// <summary>
        /// Gets or sets OrderQuantityCommitted
        /// </summary>
        [Display(Name = "OrderQuantityCommitted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.OrderQuantityCommitted, Id = Index.OrderQuantityCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal OrderQuantityCommitted { get; set; }

        /// <summary>
        /// Gets or sets OrderQuantityShippedtodate
        /// </summary>
        [Display(Name = "OrderQuantityShippedtodate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.OrderQuantityShippedtodate, Id = Index.OrderQuantityShippedtodate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal OrderQuantityShippedtodate { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderUnitOfMeasure", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.OrderUnitOfMeasure, Id = Index.OrderUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string OrderUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitConversion
        /// </summary>
        [Display(Name = "OrderUnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.OrderUnitConversion, Id = Index.OrderUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OrderUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets ManufacturersItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ManufacturersItemNo", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ManufacturersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerItemNo", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerItemNumber, Id = Index.CustomerItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string CustomerItemNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoicesShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoicesShipmentNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoicesShipmentNumber, Id = Index.InvoicesShipmentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string InvoicesShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoicesShipmentDetailNumber
        /// </summary>
        [Display(Name = "InvoicesShipmentDetailNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoicesShipmentDetailNumber, Id = Index.InvoicesShipmentDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoicesShipmentDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets KittingBOM
        /// </summary>
        [Display(Name = "KittingBom", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.KittingBom, Id = Index.KittingBom, FieldType = EntityFieldType.Int, Size = 2)]
        public KittingBOM KittingBom { get; set; }

        /// <summary>
        /// Gets or sets KitBOMNumber
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "KitBomNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.KitBomNumber, Id = Index.KitBomNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string KitBomNumber { get; set; }

        /// <summary>
        /// Gets or sets BOMBuildQty
        /// </summary>
        [Display(Name = "BOMBuildQty", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BomBuildQty, Id = Index.BomBuildQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal BomBuildQty { get; set; }

        /// <summary>
        /// Gets or sets BOMBuildUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BOMBuildUnit", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BomBuildUnit, Id = Index.BomBuildUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string BomBuildUnit { get; set; }

        /// <summary>
        /// Gets or sets BOMBuildUnitConversion
        /// </summary>
        [Display(Name = "BOMBuildUnitConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BomBuildUnitConversion, Id = Index.BomBuildUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BomBuildUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoiceUniquifier
        /// </summary>
        [Display(Name = "InvoiceUniquifier", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal InvoiceUniquifier { get; set; }

        /// <summary>
        /// Gets or sets InvoiceLineNumber
        /// </summary>
        [Display(Name = "InvoiceLineNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoiceLineNumber, Id = Index.InvoiceLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoiceLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets NextComponentNumber
        /// </summary>
        [Display(Name = "NextComponentNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.NextComponentNumber, Id = Index.NextComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets ePOSPromotionID
        /// </summary>
        [Display(Name = "EPosPromotionId", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public int EPosPromotionId { get; set; }

        /// <summary>
        /// Gets or sets PricingBaseWeightUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingBaseWeightUnit", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PricingBaseWeightUnit, Id = Index.PricingBaseWeightUnit, FieldType = EntityFieldType.Char, Size = 10)]
        public string PricingBaseWeightUnit { get; set; }

        /// <summary>
        /// Gets or sets WeightUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WeightUnitofMeasure", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.WeightUnitOfMeasure, Id = Index.WeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string WeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets WeightConversionFactor
        /// </summary> CDN
        [Display(Name = "WeightConversionFactor", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.WeightConversionFactor, Id = Index.WeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal WeightConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets PricingWeightUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingWeightUom", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PricingWeightUom, Id = Index.PricingWeightUom, FieldType = EntityFieldType.Char, Size = 10)]
        public string PricingWeightUom { get; set; }

        /// <summary>
        /// Gets or sets PricingWeightConversionFactor
        /// </summary>
        [Display(Name = "PricingWeightConversionFactor", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PricingWeightConversionFactor, Id = Index.PricingWeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingWeightConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets PricingBaseWeightConvFactor
        /// </summary>
        [Display(Name = "PricingBaseWeightConvFactor", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PricingBaseWeightConvFactor, Id = Index.PricingBaseWeightConvFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PricingBaseWeightConvFactor { get; set; }

        /// <summary>
        /// Gets or sets DefWeightUOMUnitWeight
        /// </summary>
        [Display(Name = "DefWeightUomUnitWeight", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DefWeightUomUnitWeight, Id = Index.DefWeightUomUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal DefWeightUomUnitWeight { get; set; }

        /// <summary>
        /// Gets or sets DefWeightUOMExtUnitWeight
        /// </summary>
        [Display(Name = "DefWeightUomExtUnitWeight", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DefWeightUomExtUnitWeight, Id = Index.DefWeightUomExtUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal DefWeightUomExtUnitWeight { get; set; }

        /// <summary>
        /// Gets or sets PriceBy
        /// </summary>
        [Display(Name = "PriceBy", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PriceBy, Id = Index.PriceBy, FieldType = EntityFieldType.Int, Size = 2)]
        public PriceBy PriceBy { get; set; }

        /// <summary>
        /// Gets or sets PriceCheckPending
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PriceCheckPending, Id = Index.PriceCheckPending, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PriceCheckPending { get; set; }

        /// <summary>
        /// Gets or sets PriceApprovedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceApprovedBy", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PriceApprovedBy, Id = Index.PriceApprovedBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string PriceApprovedBy { get; set; }

        /// <summary>
        /// Gets or sets ApprovingUsersPassword
        /// </summary>
        [IgnoreExportImport]
        [StringLength(64, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ApprovingUsersPassword, Id = Index.ApprovingUsersPassword, FieldType = EntityFieldType.Char, Size = 64)]
        public string ApprovingUsersPassword { get; set; }

        /// <summary>
        /// Gets or sets PriceApprovalNeeded
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PriceApprovalNeeded, Id = Index.PriceApprovalNeeded, FieldType = EntityFieldType.Bool, Size = 2)]
        public PriceApprovalNeeded PriceApprovalNeeded { get; set; }

        /// <summary>
        /// Gets or sets WeightUOMDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WeightUOMDescription", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.WeightUomDescription, Id = Index.WeightUomDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string WeightUomDescription { get; set; }

        /// <summary>
        /// Gets or sets HeaderDiscount
        /// </summary>
        [Display(Name = "HeaderDiscount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.HeaderDiscount, Id = Index.HeaderDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HeaderDiscount { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount1
        /// </summary>
        [Display(Name = "TRTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount1, Id = Index.TrTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount2
        /// </summary>
        [Display(Name = "TRTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount2, Id = Index.TrTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount3
        /// </summary>
        [Display(Name = "TRTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount3, Id = Index.TrTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount4
        /// </summary>
        [Display(Name = "TRTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount4, Id = Index.TrTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount5
        /// </summary>
        [Display(Name = "TRTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount5, Id = Index.TrTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets ExtendedAmountNetOfTax
        /// </summary>
        [Display(Name = "ExtendedAmountNetOfTax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtendedAmountNetOfTax, Id = Index.ExtendedAmountNetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedAmountNetOfTax { get; set; }

        /// <summary>
        /// Gets or sets DiscountedExtendedAmount
        /// </summary>
        [Display(Name = "DiscountedExtendedAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DiscountedExtendedAmount, Id = Index.DiscountedExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountedExtendedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal
        /// </summary>
        [Display(Name = "TaxTotal", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TRTaxTotal
        /// </summary>
        [Display(Name = "TRTaxTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxTotal, Id = Index.TrTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets CostOfGoods
        /// </summary>
        [Display(Name = "CostOfGoods", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CostOfGoods, Id = Index.CostOfGoods, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostOfGoods { get; set; }

        /// <summary>
        /// Gets or sets RecordCosted
        /// </summary>
        [Display(Name = "RecordCosted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RecordCosted, Id = Index.RecordCosted, FieldType = EntityFieldType.Bool, Size = 2)]
        public RecordCosted RecordCosted { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool JobRelated { get; set; }

        /// <summary>
        /// Gets or sets ContractCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets ProjectStyle
        /// </summary>
        [Display(Name = "ProjectStyle", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectStyle ProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        //ProjectType - CDN
        [Display(Name = "ProjectType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets RevenueBillingAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueBillingAccount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RevenueBillingAccount, Id = Index.RevenueBillingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RevenueBillingAccount { get; set; }

        /// <summary>
        /// Gets or sets COGSWIPAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WipCOGSAcct", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CogSwipAccount, Id = Index.CogSwipAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CogSwipAccount { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainagePercent
        /// </summary>
        [Display(Name = "RetainagePercent", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainagePercent, Id = Index.RetainagePercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal RetainagePercent { get; set; }

        /// <summary>
        /// Gets or sets RetainageDays
        /// </summary>
        [Display(Name = "RetainageDays", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageDays, Id = Index.RetainageDays, FieldType = EntityFieldType.Int, Size = 2)]
        public int RetainageDays { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageDueDate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageDueDate, Id = Index.RetainageDueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RetainageDueDate { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDateOverride
        /// </summary>
        [Display(Name = "RetainageDueDateOverride", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageDueDateOverride, Id = Index.RetainageDueDateOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RetainageDueDateOverride { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmountOverride
        /// </summary>
        [Display(Name = "RetainageAmountOverride", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageAmountOverride, Id = Index.RetainageAmountOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RetainageAmountOverride { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1
        /// </summary>
        [Display(Name = "RetainageTaxBase1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2
        /// </summary>
        [Display(Name = "RetainageTaxBase2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3
        /// </summary>
        [Display(Name = "RetainageTaxBase3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4
        /// </summary>
        [Display(Name = "RetainageTaxBase4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5
        /// </summary>
        [Display(Name = "RetainageTaxBase5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount1, Id = Index.RetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount2, Id = Index.RetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount3, Id = Index.RetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount4, Id = Index.RetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTaxAmount5, Id = Index.RetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOEPrice
        /// </summary>
        [Display(Name = "Default_OE_Price", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public DefaultOEPrice DefaultOePrice { get; set; }

        /// <summary>
        /// Gets or sets Level1Name
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Level1Name", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.Level1Name, Id = Index.Level1Name, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level1Name { get; set; }

        /// <summary>
        /// Gets or sets Level2Name
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Level2Name", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.Level2Name, Id = Index.Level2Name, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level2Name { get; set; }

        /// <summary>
        /// Gets or sets Level3Name
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Level3Name", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.Level3Name, Id = Index.Level3Name, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level3Name { get; set; }

        /// <summary>
        /// Gets or sets UnformattedContractCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedContractCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnformattedContractCode, Id = Index.UnformattedContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string UnformattedContractCode { get; set; }

        /// <summary>
        /// Gets or sets SerialQuantity
        /// </summary>
        [Display(Name = "SerialQuantity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.SerialQuantity, Id = Index.SerialQuantity, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialQuantity { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets SerialLotQuantityToProcess
        /// </summary>
        [Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SerialLotQuantityToProcess { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate
        /// </summary>
        [Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets QuantityperLot
        /// </summary>
        [Display(Name = "QuantityPerLot", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityperLot { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromSerial
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromSerial", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromSerial { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromLot
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromLot", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromLot { get; set; }

        /// <summary>
        /// Gets or sets ItemSerializedLotted
        /// </summary>
        [Display(Name = "ItemSerializedLotted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ItemSerializedLotted, Id = Index.ItemSerializedLotted, FieldType = EntityFieldType.Int, Size = 2)]
        public ItemSerializedLotted ItemSerializedLotted { get; set; }

        /// <summary>
        /// Gets or sets SerialLotWindowHandle
        /// </summary>
        [Display(Name = "SerialLotWindowHandle", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialLotWindowHandle { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDateOverride
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.SetCreditApproval, Id = Index.SetCreditApproval, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SetCreditApproval { get; set; }

        /// <summary>
        /// Gets or sets AlternateItemNumber
        /// </summary>
        [IgnoreExportImport]
        public string AlternateItemNumber { get; set; }

        /// <summary>
        /// Gets or sets AlternateItemSetNumber
        /// </summary>
        [IgnoreExportImport]
        public long AlternateItemSetNumber { get; set; }

        /// <summary>
        /// Sets true if Manufacturer itemnumber maps with more ic item.
        /// </summary>
        [IgnoreExportImport]
        public bool MultipleManufacturerItemNoExists { get; set; }

        /// <summary>
        /// Gets or sets the OptionalFieldString
        /// </summary>
        [IgnoreExportImport]
        public string OptionalFieldString { get; set; }
        /// <summary>
        /// Comments and instructions
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitCommentInstruction> CrdDbnCommentsInstructions { get; set; }
        /// <summary>
        /// Kitting details
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitKittingDetail> CreditDebitKittingDetail { get; set; }
        /// <summary>
        /// Common kitting items
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CommonKittingDetail> CommonKittingDetail { get; set; }
    }
}
