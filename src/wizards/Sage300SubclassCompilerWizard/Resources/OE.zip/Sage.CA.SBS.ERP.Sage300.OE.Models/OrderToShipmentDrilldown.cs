// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Partial class for OrderToShipmentDrilldown
	/// </summary>
	public partial class OrderToShipmentDrilldown : ModelBase
	{
		/// <summary>
		/// Gets or sets Ordernumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
       
		[ViewField(Name = Fields.Ordernumber, Id = Index.Ordernumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string Ordernumber { get; set; }

		/// <summary>
		/// Gets or sets Orderdetaillinenumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.Orderdetaillinenumber, Id = Index.Orderdetaillinenumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int Orderdetaillinenumber { get; set; }

		/// <summary>
		/// Gets or sets Shipmentnumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumber", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.Shipmentnumber, Id = Index.Shipmentnumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string Shipmentnumber { get; set; }

		/// <summary>
		/// Gets or sets Invoicenumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
        [Display(Name = "InvoiceNumber", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.Invoicenumber, Id = Index.Invoicenumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string Invoicenumber { get; set; }

		/// <summary>
		/// Gets or sets Shipmentuniq
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.Shipmentuniq, Id = Index.Shipmentuniq, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal Shipmentuniq { get; set; }

		/// <summary>
		/// Gets or sets Detaillinenumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		
		[ViewField(Name = Fields.Detaillinenumber, Id = Index.Detaillinenumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int Detaillinenumber { get; set; }

		/// <summary>
		/// Gets or sets Action
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Action, Id = Index.Action, FieldType = EntityFieldType.Int, Size = 2)]
		public int Action { get; set; }

		#region UI Strings

		#endregion
	}
}
