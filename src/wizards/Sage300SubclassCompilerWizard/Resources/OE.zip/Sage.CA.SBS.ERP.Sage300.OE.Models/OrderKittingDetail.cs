// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for OrderKittingDetail
    /// </summary>
    public partial class OrderKittingDetail : ModelBase
    {
        public OrderKittingDetail()
        {
            OrderKittingSerialNumbers = new EnumerableResponse<OrderKittingSerialNumber>();
            OrderKittingDetailLotNumbers = new EnumerableResponse<OrderKittingDetailLotNumber>();
        }

        [IgnoreExportImport]
        public int SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal OrderUniquifier { get; set; }

        /// <summary>
        /// Gets or sets DetailLineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DetailLineNumber, Id = Index.DetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ParentComponentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ParentComponentNumber, Id = Index.ParentComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ParentComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ComponentNumber, Id = Index.ComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentItem
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ComponentItem, Id = Index.ComponentItem, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ComponentItem { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ItemAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ItemAccountSet, Id = Index.ItemAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ItemAccountSet { get; set; }

        /// <summary>
        /// Gets or sets UserSpecifiedCostingMethod
        /// </summary>
        [ViewField(Name = Fields.UserSpecifiedCostingMethod, Id = Index.UserSpecifiedCostingMethod, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UserSpecifiedCostingMethod { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets PickingSequence
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.PickingSequence, Id = Index.PickingSequence, FieldType = EntityFieldType.Char, Size = 10)]
        public string PickingSequence { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StockItem { get; set; }

        /// <summary>
        /// Gets or sets KittingQuantity
        /// </summary>
        [ViewField(Name = Fields.KittingQuantity, Id = Index.KittingQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal KittingQuantity { get; set; }

        /// <summary>
        /// Gets or sets ParentQuantityOrdered
        /// </summary>
        [ViewField(Name = Fields.ParentQuantityOrdered, Id = Index.ParentQuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ParentQuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets ParentQuantityShipped
        /// </summary>
        [ViewField(Name = Fields.ParentQuantityShipped, Id = Index.ParentQuantityShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ParentQuantityShipped { get; set; }

        /// <summary>
        /// Gets or sets ParentUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ParentUnitOfMeasure, Id = Index.ParentUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string ParentUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets ParentUnitConversion
        /// </summary>
        [ViewField(Name = Fields.ParentUnitConversion, Id = Index.ParentUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ParentUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets QuantityOrdered
        /// </summary>
        [ViewField(Name = Fields.QuantityOrdered, Id = Index.QuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets QuantityShipped
        /// </summary>
        [ViewField(Name = Fields.QuantityShipped, Id = Index.QuantityShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityShipped { get; set; }

        /// <summary>
        /// Gets or sets POQuantityOrdered
        /// </summary>
        [ViewField(Name = Fields.POQuantityOrdered, Id = Index.POQuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal POQuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitConversion
        /// </summary>
        [ViewField(Name = Fields.OrderUnitConversion, Id = Index.OrderUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OrderUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitCost
        /// </summary>
        [ViewField(Name = Fields.OrderUnitCost, Id = Index.OrderUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? OrderUnitCost { get; set; }

        /// <summary>
        /// Gets or sets MostRecentUnitCost
        /// </summary>
        [ViewField(Name = Fields.MostRecentUnitCost, Id = Index.MostRecentUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? MostRecentUnitCost { get; set; }

        /// <summary>
        /// Gets or sets StandardUnitCost
        /// </summary>
        [ViewField(Name = Fields.StandardUnitCost, Id = Index.StandardUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? StandardUnitCost { get; set; }

        /// <summary>
        /// Gets or sets AlternateUnitCost1
        /// </summary>
        [ViewField(Name = Fields.AlternateUnitCost1, Id = Index.AlternateUnitCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? AlternateUnitCost1 { get; set; }

        /// <summary>
        /// Gets or sets AlternateUnitCost2
        /// </summary>
        [ViewField(Name = Fields.AlternateUnitCost2, Id = Index.AlternateUnitCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? AlternateUnitCost2 { get; set; }

        /// <summary>
        /// Gets or sets AverageUnitCost
        /// </summary>
        [ViewField(Name = Fields.AverageUnitCost, Id = Index.AverageUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? AverageUnitCost { get; set; }

        /// <summary>
        /// Gets or sets LastUnitCost
        /// </summary>
        [ViewField(Name = Fields.LastUnitCost, Id = Index.LastUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? LastUnitCost { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.CostingUnitOfMeasure, Id = Index.CostingUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string CostingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitCost
        /// </summary>
        [ViewField(Name = Fields.CostingUnitCost, Id = Index.CostingUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? CostingUnitCost { get; set; }

        /// <summary>
        /// Gets or sets CostingUnitConversion
        /// </summary>
        [ViewField(Name = Fields.CostingUnitConversion, Id = Index.CostingUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? CostingUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets ExtendedOrderCost
        /// </summary>
        [ViewField(Name = Fields.ExtendedOrderCost, Id = Index.ExtendedOrderCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? ExtendedOrderCost { get; set; }

        /// <summary>
        /// Gets or sets UnitWeight
        /// </summary>
        [ViewField(Name = Fields.UnitWeight, Id = Index.UnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal UnitWeight { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearingAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.NonstockClearingAccount, Id = Index.NonstockClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string NonstockClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets WeightUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.WeightUnitOfMeasure, Id = Index.WeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string WeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets WeightConversionFactor
        /// </summary>
        [ViewField(Name = Fields.WeightConversionFactor, Id = Index.WeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal WeightConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets ParentWeightConversionFactor
        /// </summary>
        [ViewField(Name = Fields.ParentWeightConversionFactor, Id = Index.ParentWeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ParentWeightConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets ParentWeightUOMUnitWeight
        /// </summary>
        [ViewField(Name = Fields.ParentWeightUOMUnitWeight, Id = Index.ParentWeightUOMUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ParentWeightUOMUnitWeight { get; set; }

        /// <summary>
        /// Gets or sets ParentWUOMExtendedUnitWeight
        /// </summary>
        [ViewField(Name = Fields.ParentWUOMExtendedUnitWeight, Id = Index.ParentWUOMExtendedUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ParentWUOMExtendedUnitWeight { get; set; }

        /// <summary>
        /// Gets or sets KitNo
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.KitNo, Id = Index.KitNo, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string KitNo { get; set; }

        /// <summary>
        /// Gets or sets SerialQuantity
        /// </summary>
        [ViewField(Name = Fields.SerialQuantity, Id = Index.SerialQuantity, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialQuantity { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets SerialQtyShipped
        /// </summary>
        [ViewField(Name = Fields.SerialQtyShipped, Id = Index.SerialQtyShipped, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets LotQtyShipped
        /// </summary>
        [ViewField(Name = Fields.LotQtyShipped, Id = Index.LotQtyShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets ItemSerializedLotted
        /// </summary>
        [ViewField(Name = Fields.ItemSerializedLotted, Id = Index.ItemSerializedLotted, FieldType = EntityFieldType.Int, Size = 2)]
        public ItemSerializedLotted ItemSerializedLotted { get; set; }

        /// <summary>
        /// Gets or sets ComponentUnitCost
        /// </summary>
        [ViewField(Name = Fields.ComponentUnitCost, Id = Index.ComponentUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? ComponentUnitCost { get; set; }

        /// <summary>
        /// Gets or sets MostRecentComponentCost
        /// </summary>
        [ViewField(Name = Fields.MostRecentComponentCost, Id = Index.MostRecentComponentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? MostRecentComponentCost { get; set; }

        /// <summary>
        /// Gets or sets StandardComponentCost
        /// </summary>
        [ViewField(Name = Fields.StandardComponentCost, Id = Index.StandardComponentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? StandardComponentCost { get; set; }

        /// <summary>
        /// Gets or sets AlternateComponentCost1
        /// </summary>
        [ViewField(Name = Fields.AlternateComponentCost1, Id = Index.AlternateComponentCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? AlternateComponentCost1 { get; set; }

        /// <summary>
        /// Gets or sets AlternateComponentCost2
        /// </summary>
        [ViewField(Name = Fields.AlternateComponentCost2, Id = Index.AlternateComponentCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? AlternateComponentCost2 { get; set; }

        /// <summary>
        /// Gets or sets AverageComponentCost
        /// </summary>
        [ViewField(Name = Fields.AverageComponentCost, Id = Index.AverageComponentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? AverageComponentCost { get; set; }

        /// <summary>
        /// Gets or sets LastComponentCost
        /// </summary>
        [ViewField(Name = Fields.LastComponentCost, Id = Index.LastComponentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? LastComponentCost { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearingAcctDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.NonstockClearingAcctDesc, Id = Index.NonstockClearingAcctDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string NonstockClearingAcctDesc { get; set; }

        /// <summary>
        /// Gets or sets InterprocessCommID
        /// </summary>
        [ViewField(Name = Fields.InterprocessCommID, Id = Index.InterprocessCommID, FieldType = EntityFieldType.Long, Size = 4)]
        public long InterprocessCommID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSNonQtyOrdered
        /// </summary>
        [ViewField(Name = Fields.ForcePopupSNonQtyOrdered, Id = Index.ForcePopupSNonQtyOrdered, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupSNonQtyOrdered ForcePopupSNonQtyOrdered { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSNonQtyShipped
        /// </summary>
        [ViewField(Name = Fields.ForcePopupSNonQtyShipped, Id = Index.ForcePopupSNonQtyShipped, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupSNonQtyShipped ForcePopupSNonQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets PopupSN
        /// </summary>
        [ViewField(Name = Fields.PopupSN, Id = Index.PopupSN, FieldType = EntityFieldType.Int, Size = 2)]
        public PopupSN PopupSN { get; set; }

        /// <summary>
        /// Gets or sets CloseSN
        /// </summary>
        [ViewField(Name = Fields.CloseSN, Id = Index.CloseSN, FieldType = EntityFieldType.Bool, Size = 2)]
        public CloseSN CloseSN { get; set; }

        /// <summary>
        /// Gets or sets LTSetID
        /// </summary>
        [ViewField(Name = Fields.LTSetID, Id = Index.LTSetID, FieldType = EntityFieldType.Long, Size = 4)]
        public long LTSetID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLTonQtyOrdered
        /// </summary>
        [ViewField(Name = Fields.ForcePopupLTonQtyOrdered, Id = Index.ForcePopupLTonQtyOrdered, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupLTonQtyOrdered ForcePopupLTonQtyOrdered { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLTonQtyShipped
        /// </summary>
        [ViewField(Name = Fields.ForcePopupLTonQtyShipped, Id = Index.ForcePopupLTonQtyShipped, FieldType = EntityFieldType.Bool, Size = 2)]
        public ForcePopupLTonQtyShipped ForcePopupLTonQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets PopupLT
        /// </summary>
        [ViewField(Name = Fields.PopupLT, Id = Index.PopupLT, FieldType = EntityFieldType.Int, Size = 2)]
        public PopupLT PopupLT { get; set; }

        /// <summary>
        /// Gets or sets CloseLT
        /// </summary>
        [ViewField(Name = Fields.CloseLT, Id = Index.CloseLT, FieldType = EntityFieldType.Bool, Size = 2)]
        public CloseLT CloseLT { get; set; }

        /// <summary>
        /// Gets or sets ComponentSerialized
        /// </summary>
        [ViewField(Name = Fields.ComponentSerialized, Id = Index.ComponentSerialized, FieldType = EntityFieldType.Bool, Size = 2)]
        public ComponentSerialized ComponentSerialized { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentLotted
        /// </summary>
        [ViewField(Name = Fields.ComponentLotted, Id = Index.ComponentLotted, FieldType = EntityFieldType.Bool, Size = 2)]
        public ComponentLotted ComponentLotted { get; set; }

        /// <summary>
        /// Gets or sets WeightUOMDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.WeightUomDescription, Id = Index.WeightUomDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string WeightUomDescription { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets SerialLotQuantityToProcess
        /// </summary>
        [ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SerialLotQuantityToProcess { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate
        /// </summary>
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets QuantityperLot
        /// </summary>
        [ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityperLot { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromSerial
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromSerial { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromLot
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromLot { get; set; }

        /// <summary>
        /// Gets or sets SerialLotWindowHandle
        /// </summary>
        [ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialLotWindowHandle { get; set; }

        #region Newly Added Properties

        public EnumerableResponse<OrderKittingSerialNumber> OrderKittingSerialNumbers { get; set; }
        public EnumerableResponse<OrderKittingDetailLotNumber> OrderKittingDetailLotNumbers { get; set; }

        #endregion
    }
}
