// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for Order
    /// </summary>
    public partial class Order : ModelBase
    {
        /// <summary>
        /// Order class Constructor
        /// </summary>
        public Order()
        {
            OrderDetail = new OrderDetail();
            OrderPrepayment = new OrderPrepayment();
            OrderSecurity = new OrderSecurity();

            OrderDetails = new EnumerableResponse<OrderDetail> { Items = new List<OrderDetail>() };
            OrderComments = new EnumerableResponse<OrderComment> { Items = new List<OrderComment>() };
            OrderPaymentSchedules = new EnumerableResponse<OrderPaymentSchedule> { Items = new List<OrderPaymentSchedule>() };
            OrderfromQuotes = new EnumerableResponse<OrderfromQuote> { Items = new List<OrderfromQuote>() };
            OrderOptionalFields = new EnumerableResponse<OrderOptionalField> { Items = new List<OrderOptionalField>() };
            OrderKittingDetails = new EnumerableResponse<OrderKittingDetail> { Items = new List<OrderKittingDetail>() };
        }

        /// <summary>
        /// Gets or sets OrderUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderUniquifier", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal OrderUniquifier { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary> 
        [Key]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(OECommonResx))]
        [GridColumn(IsDrillDown = true)]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerGroupCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerGroupcode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerGroupCode, Id = Index.CustomerGroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string CustomerGroupCode { get; set; }

        /// <summary>
        /// Gets or sets BillToName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToName", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.BillToName, Id = Index.BillToName, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToName { get; set; }

        /// <summary>
        /// Gets or sets BillToAddressLine1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToAddressLine1, Id = Index.BillToAddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddressLine2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToAddressLine2, Id = Index.BillToAddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddressLine3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToAddressLine3, Id = Index.BillToAddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddressLine4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToAddressLine4, Id = Index.BillToAddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets BillToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BilltoCity", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToCity, Id = Index.BillToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCity { get; set; }

        /// <summary>
        /// Gets or sets BillToStateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToState", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToStateProvince, Id = Index.BillToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets BillToZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToZip", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToZipPostalCode, Id = Index.BillToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string BillToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets BillToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BilltoCountry", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToCountry, Id = Index.BillToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCountry { get; set; }

        /// <summary>
        /// Gets or sets BillToPhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BilltoPhone", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToPhoneNumber, Id = Index.BillToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets BillToFaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BilltoFax", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToFaxNumber, Id = Index.BillToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets BillToContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BilltoContact", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BillToContact, Id = Index.BillToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToContact { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoLocation", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToLocationCode, Id = Index.ShipToLocationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipToLocationCode { get; set; }

        /// <summary>
        /// Gets or sets ShipToName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToName", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipToName, Id = Index.ShipToName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToName { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoAddress1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToAddressLine1, Id = Index.ShipToAddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoAddress2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToAddressLine2, Id = Index.ShipToAddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoAddress3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToAddressLine3, Id = Index.ShipToAddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddressLine4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoAddress4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToAddressLine4, Id = Index.ShipToAddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets ShipToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoCity", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToCity, Id = Index.ShipToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCity { get; set; }

        /// <summary>
        /// Gets or sets ShipToStateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoState", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToStateProvince, Id = Index.ShipToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets ShipToZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoZip", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToZipPostalCode, Id = Index.ShipToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ShipToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets ShipToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoCountry", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToCountry, Id = Index.ShipToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCountry { get; set; }

        /// <summary>
        /// Gets or sets ShipToPhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoPhone", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToPhoneNumber, Id = Index.ShipToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToFaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoFax", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToFaxNumber, Id = Index.ShipToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiptoContact", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToContact, Id = Index.ShipToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToContact { get; set; }

        /// <summary>
        /// Gets or sets CustomerDiscountLevel
        /// </summary>
        [Display(Name = "CustomerDiscount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerDiscountLevel, Id = Index.CustomerDiscountLevel, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerDiscountLevel CustomerDiscountLevel { get; set; }

        /// <summary>
        /// Gets or sets DefaultPriceListCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultPriceListCode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DefaultPriceListCode, Id = Index.DefaultPriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultPriceListCode { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets Territory
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Territory", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Territory, Id = Index.Territory, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Territory { get; set; }

        /// <summary>
        /// Gets or sets TermsCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TermsCode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets TotalTermsAmountDue
        /// </summary>
        [Display(Name = "TotalTermsAmountDue", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalTermsAmountDue, Id = Index.TotalTermsAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTermsAmountDue { get; set; }

        /// <summary>
        /// Gets or sets DiscountAvailable
        /// </summary>
        [Display(Name = "DiscountAvailable", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DiscountAvailable, Id = Index.DiscountAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAvailable { get; set; }

        /// <summary>
        /// Gets or sets TermsRateOverride
        /// </summary>
        [Display(Name = "TermsRateOverride", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TermsRateOverride, Id = Index.TermsRateOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TermsRateOverride { get; set; }

        /// <summary>
        /// Gets or sets OrderReference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(OECommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.OrderReference, Id = Index.OrderReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string OrderReference { get; set; }

        /// <summary>
        /// Gets or sets OrderType
        /// </summary>
        [Display(Name = "OrderType", ResourceType = typeof(OECommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.OrderType, Id = Index.OrderType, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderType OrderType { get; set; }

        /// <summary>
        /// Gets or sets OrderDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderDate", ResourceType = typeof(OECommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets ExpectedShipDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpShipDate", ResourceType = typeof(OECommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.ExpectedShipDate, Id = Index.ExpectedShipDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ExpectedShipDate { get; set; }

        /// <summary>
        /// Gets or sets QuoteExpirationDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "QuoteExpirationDate", ResourceType = typeof(OrderEntryResx))]
        [GridColumn]
        [ViewField(Name = Fields.QuoteExpirationDate, Id = Index.QuoteExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? QuoteExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets OrderFiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderFiscalYear", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderFiscalYear, Id = Index.OrderFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string OrderFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets OrderFiscalPeriod
        /// </summary>
        [Display(Name = "OrderFiscalPeriod", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderFiscalPeriod, Id = Index.OrderFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderFiscalPeriod OrderFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipViaCode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipViaCodeDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipViaCodeDescription, Id = Index.ShipViaCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastInvoiceNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.LastInvoiceNumber, Id = Index.LastInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string LastInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfInvoices
        /// </summary>
        [Display(Name = "NumberOfInvoices", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NumberOfInvoices, Id = Index.NumberOfInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfInvoices { get; set; }

        /// <summary>
        /// Gets or sets FreeOnBoardPoint
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FreeOnBoardPoint", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.FreeOnBoardPoint, Id = Index.FreeOnBoardPoint, FieldType = EntityFieldType.Char, Size = 60)]
        public string FreeOnBoardPoint { get; set; }

        /// <summary>
        /// Gets or sets TemplateCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TemplateCode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TemplateCode { get; set; }

        /// <summary>
        /// Gets or sets DefaultLocationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultLocationCode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DefaultLocationCode, Id = Index.DefaultLocationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultLocationCode { get; set; }

        /// <summary>
        /// Gets or sets OnHold
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(OECommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OnHold { get; set; }

        /// <summary>
        /// Gets or sets OrderDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderDescription", ResourceType = typeof(CopyOrdersResx))]
        [GridColumn]
        [ViewField(Name = Fields.OrderDescription, Id = Index.OrderDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OrderDescription { get; set; }

        /// <summary>
        /// Gets or sets OrderComment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderComment", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderComment, Id = Index.OrderComment, FieldType = EntityFieldType.Char, Size = 250)]
        public string OrderComment { get; set; }

        /// <summary>
        /// Gets or sets OrderPrintStatus
        /// </summary>
        [Display(Name = "OrderPrintStatus", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderPrintStatus, Id = Index.OrderPrintStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public OEOrderPrintStatus OrderPrintStatus { get; set; }

        /// <summary>
        /// Gets or sets LastPostingDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPostingDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.LastPostingDate, Id = Index.LastPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPostingDate { get; set; }

        /// <summary>
        /// Gets or sets OrderNoOfPrepayments
        /// </summary>
        [Display(Name = "OrderNoOfPrepayments", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderNoOfPrepayments, Id = Index.OrderNoOfPrepayments, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrderNoOfPrepayments { get; set; }

        /// <summary>
        /// Gets or sets OverCreditLimit
        /// </summary>
        [Display(Name = "OverCreditLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OverCreditLimit, Id = Index.OverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets ApprovedLimit
        /// </summary>

        [Display(Name = "ApprovedLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ApprovedLimit, Id = Index.ApprovedLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ApprovedLimit { get; set; }

        /// <summary>
        /// Gets or sets AuthorizingUserID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AuthorizingUserID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.AuthorizingUserID, Id = Index.AuthorizingUserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string AuthorizingUserID { get; set; }

        /// <summary>
        /// Gets or sets RequiresShippingLabels
        /// </summary>

        [Display(Name = "RequiresShippingLabels", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.RequiresShippingLabels, Id = Index.RequiresShippingLabels, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RequiresShippingLabels { get; set; }

        /// <summary>
        /// Gets or sets ShippingLabelsPrinted
        /// </summary>

        [Display(Name = "ShippingLabelsPrinted", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShippingLabelsPrinted, Id = Index.ShippingLabelsPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ShippingLabelsPrinted { get; set; }

        /// <summary>
        /// Gets or sets Orhomecurr
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [Display(Name = "Orhomecurr", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Orhomecurr, Id = Index.Orhomecurr, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Orhomecurr { get; set; }

        /// <summary>
        /// Gets or sets OrRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Orratetype", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrRateType, Id = Index.OrRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string OrRateType { get; set; }

        /// <summary>
        /// Gets or sets OrSourCurr
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Orsourcurr", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrSourCurr, Id = Index.OrSourCurr, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string OrSourCurr { get; set; }

        /// <summary>
        /// Gets or sets OrRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Orratedate", ResourceType = typeof(OrderEntryResx))]
        [GridColumn]
        [ViewField(Name = Fields.OrRateDate, Id = Index.OrRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrRateDate { get; set; }

        /// <summary>
        /// Gets or sets OrRate
        /// </summary>
        [Display(Name = "Orrate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrRate, Id = Index.OrRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal OrRate { get; set; }

        /// <summary>
        /// Gets or sets OrSpread
        /// </summary>
        [Display(Name = "Orspread", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrSpread, Id = Index.OrSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal OrSpread { get; set; }

        /// <summary>
        /// Gets or sets OrDateMtch
        /// </summary>
        [Display(Name = "Ordatemtch", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrDateMtch, Id = Index.OrDateMtch, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrDateMtch { get; set; }

        /// <summary>
        /// Gets or sets OrRateRep
        /// </summary>
        [Display(Name = "Orraterep", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrRateRep, Id = Index.OrRateRep, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrRateRep { get; set; }

        /// <summary>
        /// Gets or sets OrRateOver
        /// </summary>
        [Display(Name = "Orrateover", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrRateOver, Id = Index.OrRateOver, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OrRateOver { get; set; }

        /// <summary>
        /// Gets or sets TotalAmtItems
        /// </summary>
        [Display(Name = "TotalAmtItems", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalAmtItems, Id = Index.TotalAmtItems, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAmtItems { get; set; }

        /// <summary>
        /// Gets or sets TotalAmtMiscCharges
        /// </summary>
        [Display(Name = "TotalAmtMiscCharges", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalAmtMiscCharges, Id = Index.TotalAmtMiscCharges, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAmtMiscCharges { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLinesonOrder
        /// </summary>
        [Display(Name = "NumberOfLinesonOrder", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NumberOfLinesonOrder, Id = Index.NumberOfLinesonOrder, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfLinesonOrder { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLabels
        /// </summary>
        [Display(Name = "NumberOfLabels", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NumberOfLabels, Id = Index.NumberOfLabels, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfLabels { get; set; }

        /// <summary>
        /// Gets or sets PrevPaymentsTotal
        /// </summary>
        [Display(Name = "PrevPaymentsTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PrevPaymentsTotal, Id = Index.PrevPaymentsTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrevPaymentsTotal { get; set; }

        /// <summary>
        /// Gets or sets PrevPaymentDiscTotal
        /// </summary>
        [Display(Name = "PrevPaymentDiscTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PrevPaymentDiscTotal, Id = Index.PrevPaymentDiscTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrevPaymentDiscTotal { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage1
        /// </summary>
        [Display(Name = "SalesPercentage1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SalesPercentage1, Id = Index.SalesPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage2
        /// </summary>
        [Display(Name = "SalesPercentage2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SalesPercentage2, Id = Index.SalesPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage3
        /// </summary>
        [Display(Name = "SalesPercentage3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SalesPercentage3, Id = Index.SalesPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage4
        /// </summary>
        [Display(Name = "SalesPercentage4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SalesPercentage4, Id = Index.SalesPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesPercentage5
        /// </summary>
        [Display(Name = "SalesPercentage5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SalesPercentage5, Id = Index.SalesPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets RecalculateTax
        /// </summary>
        [Display(Name = "RecalculateTax", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.RecalculateTax, Id = Index.RecalculateTax, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RecalculateTax { get; set; }

        /// <summary>
        /// Gets or sets TaxOverridden
        /// </summary>
        [Display(Name = "TaxOverridden", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxOverridden, Id = Index.TaxOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount1
        /// </summary>
        [Display(Name = "ExcludedTaxAmount1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount1, Id = Index.ExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount2
        /// </summary>
        [Display(Name = "ExcludedTaxAmount2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount2, Id = Index.ExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount3
        /// </summary>
        [Display(Name = "ExcludedTaxAmount3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount3, Id = Index.ExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount4
        /// </summary>
        [Display(Name = "ExcludedTaxAmount4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount4, Id = Index.ExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount5
        /// </summary>
        [Display(Name = "ExcludedTaxAmount5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount5, Id = Index.ExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount1
        /// </summary>
        [Display(Name = "IncludedTaxAmount1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount1, Id = Index.IncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount2
        /// </summary>
        [Display(Name = "IncludedTaxAmount2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount2, Id = Index.IncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount3
        /// </summary>
        [Display(Name = "IncludedTaxAmount3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount3, Id = Index.IncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount4
        /// </summary>
        [Display(Name = "IncludedTaxAmount4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount4, Id = Index.IncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount5
        /// </summary>
        [Display(Name = "IncludedTaxAmount5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount5, Id = Index.IncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets Registration1
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Registration1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Registration1, Id = Index.Registration1, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration1 { get; set; }

        /// <summary>
        /// Gets or sets Registration2
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Registration2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Registration2, Id = Index.Registration2, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration2 { get; set; }

        /// <summary>
        /// Gets or sets Registration3
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Registration3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Registration3, Id = Index.Registration3, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration3 { get; set; }

        /// <summary>
        /// Gets or sets Registration4
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Registration4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Registration4, Id = Index.Registration4, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration4 { get; set; }

        /// <summary>
        /// Gets or sets Registration5
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Registration5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Registration5, Id = Index.Registration5, FieldType = EntityFieldType.Char, Size = 20)]
        public string Registration5 { get; set; }

        /// <summary>
        /// Gets or sets OrderCompleted
        /// </summary>
        [Display(Name = "OrderCompleted", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderCompleted, Id = Index.OrderCompleted, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderCompleted OrderCompleted { get; set; }

        /// <summary>
        /// Gets or sets OrderCompletionDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderCompletionDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderCompletionDate, Id = Index.OrderCompletionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrderCompletionDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceNumber", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets Shipdate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Shipdate, Id = Index.Shipdate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Shipdate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InvoiceDate, Id = Index.InvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceFiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceFiscalYear", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InvoiceFiscalYear, Id = Index.InvoiceFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string InvoiceFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets InvoiceFiscalPeriod
        /// </summary>
        [Display(Name = "InvoiceFiscalPeriod", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InvoiceFiscalPeriod, Id = Index.InvoiceFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public InvoiceFiscalPeriod InvoiceFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets NoOfTermsPayments
        /// </summary>
        [Display(Name = "NoOfTermsPayments", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NoOfTermsPayments, Id = Index.NoOfTermsPayments, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NoOfTermsPayments { get; set; }

        /// <summary>
        /// Gets or sets TermsPaymentsAsOfDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TermsPaymentsAsOfDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TermsPaymentsAsOfDate, Id = Index.TermsPaymentsAsOfDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TermsPaymentsAsOfDate { get; set; }

        /// <summary>
        /// Gets or sets OrderTotalEstWeight
        /// </summary>
        [Display(Name = "OrderTotalEstWeight", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderTotalEstWeight, Id = Index.OrderTotalEstWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal OrderTotalEstWeight { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets PostInvoice
        /// </summary>
        [Display(Name = "PostInvoiceS", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PostInvoice, Id = Index.PostInvoice, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PostInvoice { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDiscMiscCharges
        /// </summary>
        [Display(Name = "InvoiceDiscMiscCharges", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InvoiceDiscMiscCharges, Id = Index.InvoiceDiscMiscCharges, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InvoiceDiscMiscCharges { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNoOfPrepayments
        /// </summary>
        [Display(Name = "InvoiceNoOfPrepayments", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InvoiceNoOfPrepayments, Id = Index.InvoiceNoOfPrepayments, FieldType = EntityFieldType.Int, Size = 2)]
        public int InvoiceNoOfPrepayments { get; set; }

        /// <summary>
        /// Gets or sets NoLinesQtyShipped
        /// </summary>
        [Display(Name = "NoLinesQtyShipped", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NoLinesQtyShipped, Id = Index.NoLinesQtyShipped, FieldType = EntityFieldType.Int, Size = 2)]
        public int NoLinesQtyShipped { get; set; }

        /// <summary>
        /// Gets or sets NoMiscChargesLines
        /// </summary>
        [Display(Name = "NoMiscChargesLines", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NoMiscChargesLines, Id = Index.NoMiscChargesLines, FieldType = EntityFieldType.Int, Size = 2)]
        public int NoMiscChargesLines { get; set; }

        /// <summary>
        /// Gets or sets OrderTotalBeforeTax
        /// </summary>
        [Display(Name = "OrderTotalBeforeTax", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderTotalBeforeTax, Id = Index.OrderTotalBeforeTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderTotalBeforeTax { get; set; }

        /// <summary>
        /// Gets or sets OrderInclTaxTotal
        /// </summary>
        [Display(Name = "OrderInclTaxTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderInclTaxTotal, Id = Index.OrderInclTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderInclTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets OrderItemTotalAmount
        /// </summary>
        [Display(Name = "OrderItemTotalAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderItemTotalAmount, Id = Index.OrderItemTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderItemTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets OrderDiscountBase
        /// </summary>
        [Display(Name = "OrderDiscountBase", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderDiscountBase, Id = Index.OrderDiscountBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderDiscountBase { get; set; }

        /// <summary>
        /// Gets or sets OrderDiscountPercentage
        /// </summary>
        [Display(Name = "OrderDiscountPercentage", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderDiscountPercentage, Id = Index.OrderDiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal OrderDiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets OrderDiscountAmount
        /// </summary>
        [Display(Name = "OrderDiscountAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderDiscountAmount, Id = Index.OrderDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets OrderTotalMiscCharges
        /// </summary>
        [Display(Name = "OrderTotalMiscCharges", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderTotalMiscCharges, Id = Index.OrderTotalMiscCharges, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderTotalMiscCharges { get; set; }

        /// <summary>
        /// Gets or sets OrderSubtotalAmount
        /// </summary>
        [Display(Name = "OrderSubtotalAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderSubtotalAmount, Id = Index.OrderSubtotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderSubtotalAmount { get; set; }

        /// <summary>
        /// Gets or sets OrderTotalWithInvDisc
        /// </summary>
        [Display(Name = "OrderTotalWithInvDisc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderTotalWithInvDisc, Id = Index.OrderTotalWithInvDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderTotalWithInvDisc { get; set; }

        /// <summary>
        /// Gets or sets OrderExclTaxTotal
        /// </summary>
        [Display(Name = "OrderExclTaxTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderExclTaxTotal, Id = Index.OrderExclTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderExclTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets OrderTotal
        /// </summary>
        [Display(Name = "OrderTotal", ResourceType = typeof(OECommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.OrderTotal, Id = Index.OrderTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderTotal { get; set; }

        /// <summary>
        /// Gets or sets OrderAmountDue
        /// </summary>
        [Display(Name = "OrderAmountDue", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderAmountDue, Id = Index.OrderAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderAmountDue { get; set; }

        /// <summary>
        /// Gets or sets Inhomecurr
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Inhomecurr", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Inhomecurr, Id = Index.Inhomecurr, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Inhomecurr { get; set; }

        /// <summary>
        /// Gets or sets Inratetype
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Inratetype", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Inratetype, Id = Index.Inratetype, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string Inratetype { get; set; }

        /// <summary>
        /// Gets or sets Insourcurr
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Insourcurr", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Insourcurr, Id = Index.Insourcurr, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Insourcurr { get; set; }

        /// <summary>
        /// Gets or sets InRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Inratedate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InRateDate, Id = Index.InRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InRateDate { get; set; }

        /// <summary>
        /// Gets or sets InRate
        /// </summary>
        [Display(Name = "Inrate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InRate, Id = Index.InRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal InRate { get; set; }

        /// <summary>
        /// Gets or sets Inspread
        /// </summary>
        [Display(Name = "Inspread", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Inspread, Id = Index.Inspread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal Inspread { get; set; }

        /// <summary>
        /// Gets or sets Indatemtch
        /// </summary>
        [Display(Name = "Indatemtch", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Indatemtch, Id = Index.Indatemtch, FieldType = EntityFieldType.Int, Size = 2)]
        public int Indatemtch { get; set; }

        /// <summary>
        /// Gets or sets Inraterep
        /// </summary>
        [Display(Name = "Inraterep", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Inraterep, Id = Index.Inraterep, FieldType = EntityFieldType.Int, Size = 2)]
        public int Inraterep { get; set; }

        /// <summary>
        /// Gets or sets Inrateover
        /// </summary>
        [Display(Name = "Inrateover", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Inrateover, Id = Index.Inrateover, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Inrateover { get; set; }

        /// <summary>
        /// Gets or sets ReceiptBatchNumber
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReceiptBatchNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ReceiptBatchNumber, Id = Index.ReceiptBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal ReceiptBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets BankCode
        /// </summary>
        [IgnoreExportImport]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets ReceiptType
        /// </summary>
        [IgnoreExportImport]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptType", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ReceiptType, Id = Index.ReceiptType, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ReceiptType { get; set; }

        /// <summary>
        /// Gets or sets CheckDate
        /// </summary>
        [IgnoreExportImport]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CheckDate, Id = Index.CheckDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CheckDate { get; set; }

        /// <summary>
        /// Gets or sets CheckFiscalYear
        /// </summary>
        [IgnoreExportImport]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckFiscalYear", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CheckFiscalYear, Id = Index.CheckFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4d")]
        public string CheckFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets CheckFiscalPeriod
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CheckFiscalPeriod", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CheckFiscalPeriod, Id = Index.CheckFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckFiscalPeriod CheckFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber
        /// </summary>
        [IgnoreExportImport]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentAppliedTo
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentAppliedTo", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentAppliedTo, Id = Index.PaymentAppliedTo, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentAppliedTo PaymentAppliedTo { get; set; }

        /// <summary>
        /// Gets or sets PaymentInCustCurrency
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentInCustCurrency", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentInCustCurrency, Id = Index.PaymentInCustCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentInCustCurrency { get; set; }

        /// <summary>
        /// Gets or sets InvoiceTotalTermsDisc
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "InvoiceTotalTermsDisc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InvoiceTotalTermsDisc, Id = Index.InvoiceTotalTermsDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceTotalTermsDisc { get; set; }

        /// <summary>
        /// Gets or sets PaymentInBankCurrency
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentInBankCurrency", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentInBankCurrency, Id = Index.PaymentInBankCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentInBankCurrency { get; set; }

        /// <summary>
        /// Gets or sets PaymentHomeCurrency
        /// </summary>
        [IgnoreExportImport]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentHomeCurrency", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentHomeCurrency, Id = Index.PaymentHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string PaymentHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets PaymentRateType
        /// </summary>
        [IgnoreExportImport]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentRateType", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentRateType, Id = Index.PaymentRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PaymentRateType { get; set; }

        /// <summary>
        /// Gets or sets PaymentSourceCurrency
        /// </summary>
        [IgnoreExportImport]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentSourceCurrency", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentSourceCurrency, Id = Index.PaymentSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string PaymentSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets PaymentRateDate
        /// </summary>
        [IgnoreExportImport]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentRateDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentRateDate, Id = Index.PaymentRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PaymentRateDate { get; set; }

        /// <summary>
        /// Gets or sets PaymentRate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentRate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentRate, Id = Index.PaymentRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PaymentRate { get; set; }

        /// <summary>
        /// Gets or sets PaymentSpread
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentSpread", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentSpread, Id = Index.PaymentSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PaymentSpread { get; set; }

        /// <summary>
        /// Gets or sets PaymentRateDateMatching
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentRateDateMatching", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentRateDateMatching, Id = Index.PaymentRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int PaymentRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets PaymentRateOperator
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentRateOperator", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentRateOperator, Id = Index.PaymentRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int PaymentRateOperator { get; set; }


        /// <summary>
        /// Gets or sets PriceListCodeDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceListCodeDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PriceListCodeDesc, Id = Index.PriceListCodeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PriceListCodeDesc { get; set; }

        /// <summary>
        /// Gets or sets TermsCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TermsCodeDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TermsCodeDescription, Id = Index.TermsCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TermsCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupCodeDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroupCodeDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxGroupCodeDesc, Id = Index.TaxGroupCodeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupCodeDesc { get; set; }

        /// <summary>
        /// Gets or sets LocationCodeDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.LocationCodeDesc, Id = Index.LocationCodeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationCodeDesc { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SalespersonName1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SalespersonName1, Id = Index.SalespersonName1, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName1 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SalespersonName2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SalespersonName2, Id = Index.SalespersonName2, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName2 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SalespersonName3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SalespersonName3, Id = Index.SalespersonName3, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName3 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SalespersonName4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SalespersonName4, Id = Index.SalespersonName4, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName4 { get; set; }

        /// <summary>
        /// Gets or sets SalespersonName5
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SalespersonName5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SalespersonName5, Id = Index.SalespersonName5, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalespersonName5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1Desc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1Desc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1Desc, Id = Index.TaxAuthority1Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority1Desc { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2Desc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2Desc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2Desc, Id = Index.TaxAuthority2Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority2Desc { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3Desc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3Desc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority3Desc, Id = Index.TaxAuthority3Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority3Desc { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4Desc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4Desc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4Desc, Id = Index.TaxAuthority4Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority4Desc { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5Desc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5Desc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5Desc, Id = Index.TaxAuthority5Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority5Desc { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass1Description", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass2Description", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass3Description", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass4Description", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass5Description", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets OrderSourceCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderSourceCurrencyDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderSourceCurrencyDesc, Id = Index.OrderSourceCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string OrderSourceCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets OrderHomeCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderHomeCurrencyDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderHomeCurrencyDesc, Id = Index.OrderHomeCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string OrderHomeCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets OrderRateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderRateTypeDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderRateTypeDescription, Id = Index.OrderRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OrderRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSourceCurrDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceSourceCurrDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InvoiceSourceCurrDesc, Id = Index.InvoiceSourceCurrDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceSourceCurrDesc { get; set; }

        /// <summary>
        /// Gets or sets InvoiceHomeCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceHomeCurrencyDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InvoiceHomeCurrencyDesc, Id = Index.InvoiceHomeCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceHomeCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets InvoiceRateTypeDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceRateTypeDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InvoiceRateTypeDesc, Id = Index.InvoiceRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets PaymentSourceCurrDesc
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentSourceCurrDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentSourceCurrDesc, Id = Index.PaymentSourceCurrDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentSourceCurrDesc { get; set; }

        /// <summary>
        /// Gets or sets PaymentHomeCurrencyDesc
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentHomeCurrencyDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentHomeCurrencyDesc, Id = Index.PaymentHomeCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentHomeCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets PaymentRateTypeDesc
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentRateTypeDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentRateTypeDesc, Id = Index.PaymentRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount1
        /// </summary>
        [Display(Name = "TotalTaxAmount1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalTaxAmount1, Id = Index.TotalTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount2
        /// </summary>
        [Display(Name = "TotalTaxAmount2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalTaxAmount2, Id = Index.TotalTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount3
        /// </summary>
        [Display(Name = "TotalTaxAmount3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalTaxAmount3, Id = Index.TotalTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount4
        /// </summary>
        [Display(Name = "TotalTaxAmount4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalTaxAmount4, Id = Index.TotalTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount5
        /// </summary>
        [Display(Name = "TotalTaxAmount5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalTaxAmount5, Id = Index.TotalTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TotalTaxAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TotalTaxAmount, Id = Index.TotalTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets AuthorizingUserPassword
        /// </summary>
        [IgnoreExportImport]
        [StringLength(64, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AuthorizingUserPassword", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.AuthorizingUserPassword, Id = Index.AuthorizingUserPassword, FieldType = EntityFieldType.Char, Size = 64)]
        public string AuthorizingUserPassword { get; set; }

        /// <summary>
        /// Gets or sets OrderRunningTotal
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OrderRunningTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderRunningTotal, Id = Index.OrderRunningTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderRunningTotal { get; set; }

        /// <summary>
        /// Gets or sets OrderTotalPayment
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OrderTotalPayment", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderTotalPayment, Id = Index.OrderTotalPayment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderTotalPayment { get; set; }

        /// <summary>
        /// Gets or sets OrderTotalPaymentDisc
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OrderTotalPaymentDisc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderTotalPaymentDisc, Id = Index.OrderTotalPaymentDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrderTotalPaymentDisc { get; set; }

        /// <summary>
        /// Gets or sets AmountDueLessCurrPrepayment
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "AmountDueLessCurrPrepayment", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.AmountDueLessCurrPrepayment, Id = Index.AmountDueLessCurrPrepayment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDueLessCurrPrepayment { get; set; }

        /// <summary>
        /// Gets or sets PerformTaxCalculation
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PerformTaxCalculation", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PerformTaxCalculation, Id = Index.PerformTaxCalculation, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformTaxCalculation { get; set; }

        /// <summary>
        /// Gets or sets PerformCreditLimitCheck
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PerformCreditLimitCheck", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PerformCreditLimitCheck, Id = Index.PerformCreditLimitCheck, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformCreditLimitCheck { get; set; }

        /// <summary>
        /// Gets or sets OrderSource
        /// </summary>
        [Display(Name = "OrderSource", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderSource, Id = Index.OrderSource, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderSource OrderSource { get; set; }

        /// <summary>
        /// Gets or sets PerformShipAll
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PerformShipAll", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PerformShipAll, Id = Index.PerformShipAll, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformShipAll { get; set; }

        /// <summary>
        /// Gets or sets DOSConversionInProgress
        /// </summary>
        [Display(Name = "DosConversionInProgress", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DosConversionInProgress, Id = Index.DosConversionInProgress, FieldType = EntityFieldType.Bool, Size = 2)]
        public DOSConversionInProgress DosConversionInProgress { get; set; }

        /// <summary>
        /// Gets or sets PerformForcedTaxCalculation
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PerformForcedTaxCalculation", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PerformForcedTaxCalculation, Id = Index.PerformForcedTaxCalculation, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformForcedTaxCalculation { get; set; }

        /// <summary>
        /// Gets or sets PerformManualTaxDistribution
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PerformManualTaxDistribution", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PerformManualTaxDistribution, Id = Index.PerformManualTaxDistribution, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformManualTaxDistribution { get; set; }

        /// <summary>
        /// Gets or sets TaxCalculationInProgress
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxCalculationInProgress", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TaxCalculationInProgress, Id = Index.TaxCalculationInProgress, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxCalculationInProgress { get; set; }

        /// <summary>
        /// Gets or sets AutoTaxCalculationStatus
        /// </summary>
        [Display(Name = "AutoTaxCalculationStatus", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.AutoTaxCalculationStatus, Id = Index.AutoTaxCalculationStatus, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AutoTaxCalculationStatus { get; set; }

        /// <summary>
        /// Gets or sets OriginatingQuoteNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginatingQuoteNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OriginatingQuoteNumber, Id = Index.OriginatingQuoteNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginatingQuoteNumber { get; set; }

        /// <summary>
        /// Gets or sets DisplayRateWarning
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DisplayRateWarning", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DisplayRateWarning, Id = Index.DisplayRateWarning, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DisplayRateWarning { get; set; }

        /// <summary>
        /// Gets or sets CustomerExists
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CustomerExists", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerExists, Id = Index.CustomerExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerExists { get; set; }

        /// <summary>
        /// Gets or sets InvoiceWillBeProduced
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "InvoiceWillBeProduced", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.InvoiceWillBeProduced, Id = Index.InvoiceWillBeProduced, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InvoiceWillBeProduced { get; set; }

        /// <summary>
        /// Gets or sets SecurityEnabled
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "SecurityEnabled", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SecurityEnabled, Id = Index.SecurityEnabled, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SecurityEnabled { get; set; }

        /// <summary>
        /// Gets or sets UserCanApproveCreditLift
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "UserCanApproveCreditLift", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.UserCanApproveCreditLift, Id = Index.UserCanApproveCreditLift, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UserCanApproveCreditLift { get; set; }

        /// <summary>
        /// Gets or sets RecalcMultiPaymentDates
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RecalcMultiPaymentDates", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.RecalcMultiPaymentDates, Id = Index.RecalcMultiPaymentDates, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RecalcMultiPaymentDates { get; set; }

        /// <summary>
        /// Gets or sets BillToEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToEmail", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.BillToEmail, Id = Index.BillToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToEmail { get; set; }

        /// <summary>
        /// Gets or sets BillToContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactPhone", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.BillToContactPhone, Id = Index.BillToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets BillToContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactFax", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.BillToContactFax, Id = Index.BillToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactFax { get; set; }

        /// <summary>
        /// Gets or sets BillToContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactEmail", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.BillToContactEmail, Id = Index.BillToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToEmail", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToEmail, Id = Index.ShipToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContactPhone", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToContactPhone, Id = Index.ShipToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContactFax", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToContactFax, Id = Index.ShipToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactFax { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContactEmail", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipToContactEmail, Id = Index.ShipToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets Allowpartialshipments
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Allowpartialshipments", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Allowpartialshipments, Id = Index.Allowpartialshipments, FieldType = EntityFieldType.Int, Size = 2)]
        public Allowpartialshipments Allowpartialshipments { get; set; }

        /// <summary>
        /// Gets or sets MultipleQuotes
        /// </summary>
        [Display(Name = "MultipleQuotes", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.MultipleQuotes, Id = Index.MultipleQuotes, FieldType = EntityFieldType.Bool, Size = 2)]
        public MultipleQuotes MultipleQuotes { get; set; }

        /// <summary>
        /// Gets or sets NumberOfQuotes
        /// </summary>
        [Display(Name = "NumberOfQuotes", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NumberOfQuotes, Id = Index.NumberOfQuotes, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfQuotes { get; set; }

        /// <summary>
        /// Gets or sets PerformMultipleQuotesToOrder
        /// </summary>
        [Display(Name = "PerformMultipleQuotesToOrder", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PerformMultipleQuotesToOrder, Id = Index.PerformMultipleQuotesToOrder, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PerformMultipleQuotesToOrder { get; set; }

        /// <summary>
        /// Gets or sets LastShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastShipmentNo1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.LastShipmentNumber, Id = Index.LastShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string LastShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfShipments
        /// </summary>
        [Display(Name = "NumberOfShipments", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NumberOfShipments, Id = Index.NumberOfShipments, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfShipments { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTrackingNumber
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentTrackingNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentTrackingNumber, Id = Index.ShipmentTrackingNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string ShipmentTrackingNumber { get; set; }

        /// <summary>
        /// Gets or sets PostSequenceNumber
        /// </summary>
        [Display(Name = "PostSequenceNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PostSequenceNumber, Id = Index.PostSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long PostSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentUniquifier
        /// </summary>
        [Display(Name = "ShipmentUniquifier", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentUniquifier, Id = Index.ShipmentUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ShipmentUniquifier { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber
        /// </summary>
        [IgnoreExportImport]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumber", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Shidate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Shidate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.Shidate, Id = Index.Shidate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Shidate { get; set; }

        /// <summary>
        /// Gets or sets ShipmentHomeCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentHomeCurrency", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentHomeCurrency, Id = Index.ShipmentHomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ShipmentHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentRateType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipmentRateType, Id = Index.ShipmentRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ShipmentRateType { get; set; }

        /// <summary>
        /// Gets or sets ShipmentSourceCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentSourceCurrency", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentSourceCurrency, Id = Index.ShipmentSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ShipmentSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentRateDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipmentRateDate, Id = Index.ShipmentRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipmentRateDate { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRate
        /// </summary>
        [Display(Name = "ShipmentRate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentRate, Id = Index.ShipmentRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ShipmentRate { get; set; }

        /// <summary>
        /// Gets or sets ShipmentSpread
        /// </summary>
        [Display(Name = "ShipmentSpread", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentSpread, Id = Index.ShipmentSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ShipmentSpread { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDateMatch
        /// </summary>
        [Display(Name = "ShipmentDateMatch", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentDateMatch, Id = Index.ShipmentDateMatch, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentDateMatch { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateOperator
        /// </summary>
        [Display(Name = "ShipmentRateOperator", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentRateOperator, Id = Index.ShipmentRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentRateOperator { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateOverrideFlag
        /// </summary>
        [Display(Name = "ShipmentRateOverrideFlag", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentRateOverrideFlag, Id = Index.ShipmentRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ShipmentRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets ShipmentSourceCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentSourceCurrencyDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentSourceCurrencyDesc, Id = Index.ShipmentSourceCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipmentSourceCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets ShipmentHomeCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentHomeCurrencyDesc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentHomeCurrencyDesc, Id = Index.ShipmentHomeCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipmentHomeCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets ShipmentRateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentRateTypeDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentRateTypeDescription, Id = Index.ShipmentRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipmentRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets OrderPartiallyShipped
        /// </summary>
        [Display(Name = "OrderPartiallyShipped", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderPartiallyShipped, Id = Index.OrderPartiallyShipped, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OrderPartiallyShipped { get; set; }

        /// <summary>
        /// Gets or sets ShipmentTotal
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ShipmentTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ShipmentTotal, Id = Index.ShipmentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ShipmentTotal { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets PredecessorUniquifier
        /// </summary>
        [Display(Name = "PredecessorUniquifier", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PredecessorUniquifier, Id = Index.PredecessorUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PredecessorUniquifier { get; set; }

        /// <summary>
        /// Gets or sets PredecessorNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PredecessorNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PredecessorNumber, Id = Index.PredecessorNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PredecessorNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessOipCommand
        /// </summary>
        [Display(Name = "ProcessOipCommand", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ProcessOipCommand, Id = Index.ProcessOipCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessOIPCommand ProcessOipCommand { get; set; }

        /// <summary>
        /// Gets or sets ProcessOeCommand
        /// </summary>
        [Display(Name = "ProcessOeCommand", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ProcessOeCommand, Id = Index.ProcessOeCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessOECommand ProcessOeCommand { get; set; }

        /// <summary>
        /// Gets or sets UserEnteredApprovalAmount
        /// </summary>
        [Display(Name = "UserEnteredApprovalAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.UserEnteredApprovalAmount, Id = Index.UserEnteredApprovalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UserEnteredApprovalAmount { get; set; }

        /// <summary>
        /// Gets or sets CheckingCustomerCreditLimit
        /// </summary>
        [Display(Name = "CheckingCustomerCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingCustomerCreditLimit, Id = Index.CheckingCustomerCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingCustomerCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingCustomerAgingLimit
        /// </summary>
        [Display(Name = "CheckingCustomerAgingLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingCustomerAgingLimit, Id = Index.CheckingCustomerAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingCustomerAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingNatAcctCreditLimit
        /// </summary>
        [Display(Name = "CheckingNatAcctCreditLimit", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CheckingNatAcctCreditLimit, Id = Index.CheckingNatAcctCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingNatAcctCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckingNatAcctAgingLimit
        /// </summary>
        [Display(Name = "CheckingNatAcctAgingLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CheckingNatAcctAgingLimit, Id = Index.CheckingNatAcctAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckingNatAcctAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerIsOverCreditLimit
        /// </summary>
        [Display(Name = "CustomerIsOverCreditLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerIsOverCreditLimit, Id = Index.CustomerIsOverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerIsOverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerIsOverAgingLimit
        /// </summary>
        [Display(Name = "CustomerIsOverAgingLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerIsOverAgingLimit, Id = Index.CustomerIsOverAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CustomerIsOverAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctIsOverCreditLimit
        /// </summary>
        [Display(Name = "NatAcctIsOverCreditLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NatAcctIsOverCreditLimit, Id = Index.NatAcctIsOverCreditLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool NatAcctIsOverCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctIsOverAgingLimit
        /// </summary>
        [Display(Name = "NatAcctIsOverAgingLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NatAcctIsOverAgingLimit, Id = Index.NatAcctIsOverAgingLimit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool NatAcctIsOverAgingLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerCreditLimit
        /// </summary>
        [Display(Name = "CustomerCreditLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerCreditLimit, Id = Index.CustomerCreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerBalancePosted
        /// </summary>
        [Display(Name = "CustomerBalancePosted", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerBalancePosted, Id = Index.CustomerBalancePosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerBalancePosted { get; set; }

        /// <summary>
        /// Gets or sets CustomerDaysOverdue
        /// </summary>
        [Display(Name = "CustomerDaysOverdue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerDaysOverdue, Id = Index.CustomerDaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerDaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets CustomerOverdueLimit
        /// </summary>
        [Display(Name = "CustomerOverdueLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerOverdueLimit, Id = Index.CustomerOverdueLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerOverdueLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerBalanceOverdue
        /// </summary>
        [Display(Name = "CustomerBalanceOverdue", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CustomerBalanceOverdue, Id = Index.CustomerBalanceOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerBalanceOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctCreditLimit
        /// </summary>
        [Display(Name = "NatAcctCreditLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NatAcctCreditLimit, Id = Index.NatAcctCreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctBalance
        /// </summary>
        [Display(Name = "NatAcctBalance", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NatAcctBalance, Id = Index.NatAcctBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctBalance { get; set; }

        /// <summary>
        /// Gets or sets NatAcctDaysOverdue
        /// </summary>
        [Display(Name = "NatAcctDaysOverdue", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NatAcctDaysOverdue, Id = Index.NatAcctDaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int NatAcctDaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctOverdueLimit
        /// </summary>
        [Display(Name = "NatAcctOverdueLimit", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NatAcctOverdueLimit, Id = Index.NatAcctOverdueLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctOverdueLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctBalanceOverdue
        /// </summary>
        [Display(Name = "NatAcctBalanceOverdue", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NatAcctBalanceOverdue, Id = Index.NatAcctBalanceOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctBalanceOverdue { get; set; }

        /// <summary>
        /// Gets or sets ARPendingTransIncluded
        /// </summary>
        [Display(Name = "ARPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ARPendingTransIncluded, Id = Index.ARPendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ARPendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets OePendingTransIncluded
        /// </summary>
        [Display(Name = "OePendingTransIncluded", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OePendingTransIncluded, Id = Index.OePendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OePendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets OtherPendingTransIncluded
        /// </summary>
        [Display(Name = "OtherPendingTransIncluded", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OtherPendingTransIncluded, Id = Index.OtherPendingTransIncluded, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OtherPendingTransIncluded { get; set; }

        /// <summary>
        /// Gets or sets ARPendingBalance
        /// </summary>
        [Display(Name = "ARPendingBalance", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ARPendingBalance, Id = Index.ARPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ARPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets OePendingBalance
        /// </summary>
        [Display(Name = "OePendingBalance", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OePendingBalance, Id = Index.OePendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OePendingBalance { get; set; }

        /// <summary>
        /// Gets or sets OtherPendingBalance
        /// </summary>
        [Display(Name = "AmtTxxPend", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.OtherPendingBalance, Id = Index.OtherPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OtherPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets CustomerTotalOutstanding
        /// </summary>
        [Display(Name = "CustomerTotalOutstanding", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerTotalOutstanding, Id = Index.CustomerTotalOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTotalOutstanding { get; set; }

        /// <summary>
        /// Gets or sets NatAcctTotalOutstanding
        /// </summary>
        [Display(Name = "NatAcctTotalOutstanding", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NatAcctTotalOutstanding, Id = Index.NatAcctTotalOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctTotalOutstanding { get; set; }

        /// <summary>
        /// Gets or sets CustomerLimitLeft
        /// </summary>
        [Display(Name = "CustomerLimitLeft", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerLimitLeft, Id = Index.CustomerLimitLeft, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerLimitLeft { get; set; }

        /// <summary>
        /// Gets or sets NatAcctLimitLeft
        /// </summary>
        [Display(Name = "NatAcctLimitLeft", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NatAcctLimitLeft, Id = Index.NatAcctLimitLeft, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctLimitLeft { get; set; }

        /// <summary>
        /// Gets or sets CustomerLimitExceeded
        /// </summary>
        [Display(Name = "CustomerLimitExceeded", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerLimitExceeded, Id = Index.CustomerLimitExceeded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerLimitExceeded { get; set; }

        /// <summary>
        /// Gets or sets NatAcctLimitExceeded
        /// </summary>
        [Display(Name = "NatAcctLimitExceeded", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.NatAcctLimitExceeded, Id = Index.NatAcctLimitExceeded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctLimitExceeded { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceAmount
        /// </summary>
        [Display(Name = "LastInvoiceAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LastInvoiceAmount, Id = Index.LastInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastInvoiceDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LastInvoiceDate, Id = Index.LastInvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets LastPaymentAmount
        /// </summary>
        [Display(Name = "LastPaymentAmount", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LastPaymentAmount, Id = Index.LastPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets LastPaymentDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPaymentDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.LastPaymentDate, Id = Index.LastPaymentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPaymentDate { get; set; }

        /// <summary>
        /// Gets or sets DrivenbyUI
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DrivenbyUI", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DrivenbyUI, Id = Index.DrivenbyUI, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DrivenbyUI { get; set; }

        /// <summary>
        /// Gets or sets ItemDetailDiscountTotal
        /// </summary>
        [Display(Name = "ItemDetailDiscountTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.ItemDetailDiscountTotal, Id = Index.ItemDetailDiscountTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ItemDetailDiscountTotal { get; set; }

        /// <summary>
        /// Gets or sets MiscChargeDetailDiscountTot
        /// </summary>
        [Display(Name = "MiscChargeDetailDiscountTot", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.MiscChargeDetailDiscountTot, Id = Index.MiscChargeDetailDiscountTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MiscChargeDetailDiscountTot { get; set; }

        /// <summary>
        /// Gets or sets DetailDiscountTotal
        /// </summary>
        [Display(Name = "DetailDiscountTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DetailDiscountTotal, Id = Index.DetailDiscountTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DetailDiscountTotal { get; set; }

        /// <summary>
        /// Gets or sets DetailDiscountPercentage
        /// </summary>
        [Display(Name = "DetailDiscountPercentage", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DetailDiscountPercentage, Id = Index.DetailDiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DetailDiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets DocumentNetOfDetailDisc
        /// </summary>
        [Display(Name = "DocumentNetOfDetailDisc", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DocumentNetOfDetailDisc, Id = Index.DocumentNetOfDetailDisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentNetOfDetailDisc { get; set; }

        /// <summary>
        /// Gets or sets AutoCalcTaxReportingAmounts
        /// </summary>
        [Display(Name = "AutoCalcTaxReportingAmounts", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.AutoCalcTaxReportingAmounts, Id = Index.AutoCalcTaxReportingAmounts, FieldType = EntityFieldType.Int, Size = 2)]
        public int AutoCalcTaxReportingAmounts { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTrCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingTrCurrency", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxReportingTrCurrency, Id = Index.TaxReportingTrCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingTrCurrency { get; set; }

        /// <summary>
        /// Gets or sets TrRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TrRateType", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrRateType, Id = Index.TrRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TrRateType { get; set; }

        /// <summary>
        /// Gets or sets TrRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TrRateDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrRateDate, Id = Index.TrRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TrRateDate { get; set; }

        /// <summary>
        /// Gets or sets TrRate
        /// </summary>
        [Display(Name = "TrRate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrRate, Id = Index.TrRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TrRate { get; set; }

        /// <summary>
        /// Gets or sets TRSpread
        /// </summary>
        [Display(Name = "TrSpread", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrSpread, Id = Index.TrSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TrSpread { get; set; }

        /// <summary>
        /// Gets or sets TrRateDateMatching
        /// </summary>
        [Display(Name = "TrRateDateMatching", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrRateDateMatching, Id = Index.TrRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int TrRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets TrRateOperator
        /// </summary>
        [Display(Name = "TrRateOperator", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrRateOperator, Id = Index.TrRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TrRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TrRateOverrideFlag
        /// </summary>
        [Display(Name = "TrRateOverrideFlag", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrRateOverrideFlag, Id = Index.TrRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TrRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount1
        /// </summary>
        [Display(Name = "TrExcludedTaxAmount1", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrExcludedTaxAmount1, Id = Index.TrExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount2
        /// </summary>
        [Display(Name = "TrExcludedTaxAmount2", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrExcludedTaxAmount2, Id = Index.TrExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount3
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount3", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrExcludedTaxAmount3, Id = Index.TrExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount4
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount4", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrExcludedTaxAmount4, Id = Index.TrExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxAmount5
        /// </summary>
        [Display(Name = "TRExcludedTaxAmount5", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrExcludedTaxAmount5, Id = Index.TrExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount1
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxAmount1, Id = Index.TrIncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount2
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxAmount2, Id = Index.TrIncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount3
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxAmount3, Id = Index.TrIncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount4
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxAmount4, Id = Index.TrIncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxAmount5
        /// </summary>
        [Display(Name = "TRIncludedTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxAmount5, Id = Index.TrIncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount1
        /// </summary>
        [Display(Name = "TRTaxAmount1", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount1, Id = Index.TrTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount2
        /// </summary>
        [Display(Name = "TRTaxAmount2", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount2, Id = Index.TrTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount3
        /// </summary>
        [Display(Name = "TRTaxAmount3", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount3, Id = Index.TrTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount4
        /// </summary>
        [Display(Name = "TRTaxAmount4", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount4, Id = Index.TrTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TRTaxAmount5
        /// </summary>
        [Display(Name = "TRTaxAmount5", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxAmount5, Id = Index.TrTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TRExcludedTaxTotal
        /// </summary>
        [Display(Name = "TRExcludedTaxTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrExcludedTaxTotal, Id = Index.TrExcludedTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrExcludedTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TRIncludedTaxTotal
        /// </summary>
        [Display(Name = "TRIncludedTaxTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrIncludedTaxTotal, Id = Index.TrIncludedTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrIncludedTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TRTaxTotal
        /// </summary>
        [Display(Name = "TRTaxTotal", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrTaxTotal, Id = Index.TrTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TrTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingShipmentTRCurr
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingShipmentTRCurr", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxReportingShipmentTrCurr, Id = Index.TaxReportingShipmentTrCurr, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingShipmentTrCurr { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRShipmentRateType", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrShipmentRateType, Id = Index.TrShipmentRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TrShipmentRateType { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRShipmentRateDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrShipmentRateDate, Id = Index.TrShipmentRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TrShipmentRateDate { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRate
        /// </summary>
        [Display(Name = "TRShipmentRate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrShipmentRate, Id = Index.TrShipmentRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TrShipmentRate { get; set; }

        /// <summary>
        /// Gets or sets TrShipmentSpread
        /// </summary>
        [Display(Name = "TRShipmentSpread", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrShipmentSpread, Id = Index.TrShipmentSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TrShipmentSpread { get; set; }

        /// <summary>
        /// Gets or sets TrShipmentRateDateMatching
        /// </summary>
        [Display(Name = "TRShipmentRateDateMatching", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrShipmentRateDateMatching, Id = Index.TrShipmentRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int TrShipmentRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets TrShipmentRateOperator
        /// </summary>
        [Display(Name = "TRShipmentRateOperator", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrShipmentRateOperator, Id = Index.TrShipmentRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TrShipmentRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TrShipmentRateOverrideFlag
        /// </summary>
        [Display(Name = "TRShipmentRateOverrideFlag", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrShipmentRateOverrideFlag, Id = Index.TrShipmentRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TrShipmentRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingInvoiceTrCurre
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingInvoiceTRCurre", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TaxReportingInvoiceTrCurre, Id = Index.TaxReportingInvoiceTrCurre, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingInvoiceTrCurre { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRInvoiceRateType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceRateType, Id = Index.TrInvoiceRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TrInvoiceRateType { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRInvoiceRateDate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrInvoiceRateDate, Id = Index.TrInvoiceRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TrInvoiceRateDate { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRate
        /// </summary>
        [Display(Name = "TRInvoiceRate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceRate, Id = Index.TrInvoiceRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TrInvoiceRate { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceSpread
        /// </summary>
        [Display(Name = "TRInvoiceSpread", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceSpread, Id = Index.TrInvoiceSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TrInvoiceSpread { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceRateDateMatching
        /// </summary>
        [Display(Name = "TRInvoiceRateDateMatching", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceRateDateMatching, Id = Index.TrInvoiceRateDateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public int TrInvoiceRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceRateOperator
        /// </summary>
        [Display(Name = "TRInvoiceRateOperator", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceRateOperator, Id = Index.TrInvoiceRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TrInvoiceRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceRateOverrideFlag
        /// </summary>
        [Display(Name = "TRInvoiceRateOverrideFlag", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceRateOverrideFlag, Id = Index.TrInvoiceRateOverrideFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TrInvoiceRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets TRCurrencyDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRCurrencyDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrCurrencyDescription, Id = Index.TrCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TrCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TrShipmentCurrencyDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRShipmentCurrencyDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrShipmentCurrencyDescription, Id = Index.TrShipmentCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TrShipmentCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TrInvoiceCurrencyDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRInvoiceCurrencyDescription", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceCurrencyDescription, Id = Index.TrInvoiceCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TrInvoiceCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TRRateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRRateTypeDescription", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrRateTypeDescription, Id = Index.TrRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TrRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets TRShipmentRateTypeDescriptio
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRShipmentRateTypeDescriptio", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.TrShipmentRateTypeDescriptio, Id = Index.TrShipmentRateTypeDescriptio, FieldType = EntityFieldType.Char, Size = 60)]
        public string TrShipmentRateTypeDescriptio { get; set; }

        /// <summary>
        /// Gets or sets TRInvoiceRateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TRInvoiceRateTypeDescription", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.TrInvoiceRateTypeDescription, Id = Index.TrInvoiceRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TrInvoiceRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets PaymentType
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentType", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets PendingPrepaymentAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PendingPrepaymentAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PendingPrepaymentAmount, Id = Index.PendingPrepaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingPrepaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets OrderDiscountAmountOverride
        /// </summary>
        [Display(Name = "OrderDiscountAmountOverride", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderDiscountAmountOverride, Id = Index.OrderDiscountAmountOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OrderDiscountAmountOverride { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedDetailLines
        /// </summary>
        [Display(Name = "JobRelatedDetailLines", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.JobRelatedDetailLines, Id = Index.JobRelatedDetailLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedDetailLines { get; set; }

        /// <summary>
        /// Gets or sets ProjectInvoicing
        /// </summary>
        [Display(Name = "ProjectInvoicing", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ProjectInvoicing, Id = Index.ProjectInvoicing, FieldType = EntityFieldType.Bool, Size = 2)]
        public ProjectInvoicing ProjectInvoicing { get; set; }

        /// <summary>
        /// Gets or sets InvoiceableDetailLines
        /// </summary>
        [Display(Name = "InvoiceableDetailLines", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoiceableDetailLines, Id = Index.InvoiceableDetailLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long InvoiceableDetailLines { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasRetainage HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageTerms
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageTerms", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.RetainageTerms, Id = Index.RetainageTerms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTerms { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate
        /// </summary>
        [Display(Name = "RetainageExchangeRate", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageTermsDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.RetainageTermsDescription, Id = Index.RetainageTermsDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RetainageTermsDescription { get; set; }

        /// <summary>
        /// Gets or sets CustomerAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerAccountSet", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerAccountSet, Id = Index.CustomerAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CustomerAccountSet { get; set; }

        /// <summary>
        /// Gets or sets CustomerAccountSetDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerAccountSetDescription", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.CustomerAccountSetDescription, Id = Index.CustomerAccountSetDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerAccountSetDescription { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets EPosSegmentLength
        /// </summary>
        [Display(Name = "ePOSSegmentLength", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.EPosSegmentLength, Id = Index.EPosSegmentLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int EPosSegmentLength { get; set; }

        /// <summary>
        /// Gets or sets ShipmentPostingDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipPostingDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.ShipmentPostingDate, Id = Index.ShipmentPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipmentPostingDate { get; set; }

        /// <summary>
        /// Gets or sets InvoicePostingDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoicePostingDate", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.InvoicePostingDate, Id = Index.InvoicePostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InvoicePostingDate { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentDistributedAmount
        /// </summary>
        [Display(Name = "PrepaymentDistributedAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PrepaymentDistributedAmount, Id = Index.PrepaymentDistributedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrepaymentDistributedAmount { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentUnappliedAmount
        /// </summary>
        [Display(Name = "PrepaymentUnappliedAmount", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PrepaymentUnappliedAmount, Id = Index.PrepaymentUnappliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrepaymentUnappliedAmount { get; set; }

        /// <summary>
        /// Gets or sets SageCrmCompanyID
        /// </summary>
        [Display(Name = "SageCRMCompanyID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SageCrmCompanyID, Id = Index.SageCrmCompanyID, FieldType = EntityFieldType.Long, Size = 4)]
        public long SageCrmCompanyID { get; set; }

        /// <summary>
        /// Gets or sets SageCrmOpportunityID
        /// </summary>
        [Display(Name = "SageCRMOpportunityID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SageCrmOpportunityID, Id = Index.SageCrmOpportunityID, FieldType = EntityFieldType.Long, Size = 4)]
        public long SageCrmOpportunityID { get; set; }

        /// <summary>
        /// Gets or sets SageCrmPersonID
        /// </summary>
        [Display(Name = "SageCRMPersonID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.SageCrmPersonID, Id = Index.SageCrmPersonID, FieldType = EntityFieldType.Long, Size = 4)]
        public long SageCrmPersonID { get; set; }

        /// <summary>
        /// Gets or sets IncludeInCrmOpportunityTotal
        /// </summary>
        [Display(Name = "IncludeInCRMOpportunityTotal", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.IncludeInCrmOpportunityTotal, Id = Index.IncludeInCrmOpportunityTotal, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IncludeInCrmOpportunityTotal { get; set; }

        /// <summary>
        /// Gets or sets QuoteExpired
        /// </summary>
        [Display(Name = "QuoteExpired", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.QuoteExpired, Id = Index.QuoteExpired, FieldType = EntityFieldType.Bool, Size = 2)]
        public QuoteExpired QuoteExpired { get; set; }

        /// <summary>
        /// Gets or sets OrderUniqActivatedFromQuote
        /// </summary>
        [Display(Name = "OrderUniqActivatedFromQuote", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderUniqActivatedFromQuote, Id = Index.OrderUniqActivatedFromQuote, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal OrderUniqActivatedFromQuote { get; set; }

        /// <summary>
        /// Gets or sets OrderNumberActivatedFromQuot
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumberActivatedFromQuot", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderNumberActivatedFromQuot, Id = Index.OrderNumberActivatedFromQuot, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumberActivatedFromQuot { get; set; }

        /// <summary>
        /// Gets or sets PromotedCustomerNumber
        /// </summary>
        [IgnoreExportImport]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PromotedCustomerNumber", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PromotedCustomerNumber, Id = Index.PromotedCustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string PromotedCustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentTypeOnOrder
        /// </summary>
        [Display(Name = "PaymentTypeOnOrder", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentTypeOnOrder, Id = Index.PaymentTypeOnOrder, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentTypeOnOrder PaymentTypeOnOrder { get; set; }

        /// <summary>
        /// Gets or sets PaymentCodeOnOrder
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentCodeOnOrder", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentCodeOnOrder, Id = Index.PaymentCodeOnOrder, FieldType = EntityFieldType.Char, Size = 12)]
        public string PaymentCodeOnOrder { get; set; }

        /// <summary>
        /// Gets or sets PaymentCardID
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentCardID", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.PaymentCardID, Id = Index.PaymentCardID, FieldType = EntityFieldType.Char, Size = 12)]
        public string PaymentCardID { get; set; }

        /// <summary>
        /// Gets or sets OrderHasPreAuthorization
        /// </summary>
        [Display(Name = "OrderHasPreAuthorization", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OrderHasPreAuthorization, Id = Index.OrderHasPreAuthorization, FieldType = EntityFieldType.Bool, Size = 2)]
        public OrderHasPreAuthorization OrderHasPreAuthorization { get; set; }

        /// <summary>
        /// Gets or sets OnholdReason
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OnholdReason", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.OnholdReason, Id = Index.OnholdReason, FieldType = EntityFieldType.Char, Size = 60)]
        public string OnholdReason { get; set; }

        /// <summary>
        /// Gets or sets IncompleteShipExistForOrder
        /// </summary>
        [Display(Name = "IncompleteShipExistForOrder", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.IncompleteShipExistForOrder, Id = Index.IncompleteShipExistForOrder, FieldType = EntityFieldType.Bool, Size = 2)]
        public IncompleteShipExistForOrder IncompleteShipExistForOrder { get; set; }

        /// <summary>
        /// Gets or sets DateRequested
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateRequested", ResourceType = typeof(OrderEntryResx))]
        [ViewField(Name = Fields.DateRequested, Id = Index.DateRequested, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateRequested { get; set; }

        #region Newly Added Properties
        /// <summary>
        /// Gets or sets OrderDetail
        /// </summary>
        [IgnoreExportImport]
        public OrderDetail OrderDetail { get; set; }

        /// <summary>
        /// Gets or sets OrderPrepayment
        /// </summary>
        [IgnoreExportImport]
        public OrderPrepayment OrderPrepayment { get; set; }

        /// <summary>
        /// Gets or sets OrderDetails
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<OrderDetail> OrderDetails { get; set; }

        /// <summary>
        /// Gets or sets OrderComments
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<OrderComment> OrderComments { get; set; }

        /// <summary>
        /// Gets or sets OrderPaymentSchedules
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<OrderPaymentSchedule> OrderPaymentSchedules { get; set; }

        /// <summary>
        /// Gets or sets OrderfromQuotes
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<OrderfromQuote> OrderfromQuotes { get; set; }

        /// <summary>
        /// Gets or sets OrderfromQuotes
        /// </summary>
        [IgnoreExportImport]
        public bool IsPromotedFromQuotes { get; set; }

        /// <summary>
        /// Gets or sets OrderOptionalFields
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<OrderOptionalField> OrderOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets OrderKittingDetails
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<OrderKittingDetail> OrderKittingDetails { get; set; }

        /// <summary>
        /// Gets or sets PreCreditCheckStatus
        /// </summary>
        [IgnoreExportImport]
        public PreCreditCheckStatus PreCreditCheckStatus { get; set; }

        /// <summary>
        /// Gets or sets PreAuthorizationStatus
        /// </summary>
        [IgnoreExportImport]
        public PreAuthorizationStatus PreAuthorizationStatus { get; set; }

        /// <summary>
        /// Gets or sets ProceedPreCreditCheckStatus
        /// </summary>
        [IgnoreExportImport]
        public bool ProceedPreCreditCheckStatus { get; set; }

        /// <summary>
        /// Gets or sets FunctionalOrderTotal. This property is used in AR-Customer Inquiry screen. This will hold the equivalent value of order total for function currency.
        /// </summary>
        [IgnoreExportImport]
        public decimal FunctionalOrderTotal
        {
            get
            {
                if (OrRate != 0)
                {
                    if (OrRateRep == 1)
                    {
                        return OrderTotal * OrRate;
                    }
                    return OrderTotal / OrRate;
                }
                return OrderTotal;

            }
        }
        #endregion

        #region Properties Added for Security

        /// <summary>
        /// Gets or Sets OrderSecurity
        /// </summary>
        [IgnoreExportImport]
        public OrderSecurity OrderSecurity { get; set; }

        #endregion

        #region Properties for finder

        /// <summary>
        /// Gets the order string.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OrderType", ResourceType = typeof(OECommonResx))]
        public string OrderString
        {
            get { return EnumUtility.GetStringValue(OrderType); }
        }

        /// <summary>
        /// Gets the OnHold string.
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string OnHoldString
        {
            get
            {
                if (OnHold)
                {
                    return EnumUtility.GetStringValue(Enums.OnHold.Yes);
                }
                return EnumUtility.GetStringValue(Enums.OnHold.No);

            }
        }

        /// <summary>
        /// Gets the Order Source string.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OrderSource", ResourceType = typeof(OECommonResx))]
        public string OrderSourceString
        {
            get { return EnumUtility.GetStringValue(OrderSource); }
        }

        /// <summary>
        /// Gets the Order Print string.
        /// </summary>
        [IgnoreExportImport]
        //[Display(Name = "OrderPrintStatus", ResourceType = typeof(OrderEntryResx))]
        public string OrderPrintStatusString { get; set;
            //get { return EnumUtility.GetStringValue(OrderPrintStatus); }
        }

        /// <summary>
        /// Gets the Order Source string.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OrderCompleted", ResourceType = typeof(OrderEntryResx))]
        public string OrderCompletedString
        {
            get { return EnumUtility.GetStringValue(OrderCompleted); }
        }

        /// <summary>
        /// Gets the Customer Discount String.
        /// </summary>
        /// [Display(Name = "CustomerDiscountLevel", ResourceType = typeof (OrderEntryResx))]
        [IgnoreExportImport]
        public string CustomerDiscountString
        {
            get { return EnumUtility.GetStringValue(CustomerDiscountLevel); }
        }

        /// <summary>
        /// Gets the Order Fiscal Period String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OrderFiscalPeriod", ResourceType = typeof(OrderEntryResx))]
        public string OrderFiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(OrderFiscalPeriod); }
        }

        /// <summary>
        /// Gets the Invoice Fiscal Period String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "InvoiceFiscalPeriod", ResourceType = typeof(OrderEntryResx))]
        public string InvoiceFiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(InvoiceFiscalPeriod); }
        }

        /// <summary>
        /// Gets the Check Fiscal Period String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CheckFiscalPeriod", ResourceType = typeof(OrderEntryResx))]
        public string CheckFiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(CheckFiscalPeriod); }
        }

        /// <summary>
        /// Gets the Payment Applied To String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentAppliedTo", ResourceType = typeof(OrderEntryResx))]
        public string PaymentAppliedToString
        {
            get { return EnumUtility.GetStringValue(PaymentAppliedTo); }
        }

        /// <summary>
        /// Gets the Allow partial shipments String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Allowpartialshipments", ResourceType = typeof(OrderEntryResx))]
        public string AllowpartialshipmentsString
        {
            get { return EnumUtility.GetStringValue(Allowpartialshipments); }
        }

        /// <summary>
        /// Gets the Multiple Quotes String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "MultipleQuotes", ResourceType = typeof(OrderEntryResx))]
        public string MultipleQuotesString
        {
            get { return EnumUtility.GetStringValue(MultipleQuotes); }
        }

        /// <summary>
        /// Gets the Payment Type String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentType", ResourceType = typeof(OrderEntryResx))]
        public string PaymentTypeString
        {
            get { return EnumUtility.GetStringValue(PaymentType); }
        }

        /// <summary>
        /// Gets the Job Related String.
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(OrderEntryResx))]
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets the Project Invoicing String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ProjectInvoicing", ResourceType = typeof(OrderEntryResx))]
        public string ProjectInvoicingString
        {
            get { return EnumUtility.GetStringValue(ProjectInvoicing); }
        }

        /// <summary>
        /// Gets the Has Retainage String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "HasRetainage", ResourceType = typeof(OECommonResx))]
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Gets the Retainage Exchange String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageExchangeRate", ResourceType = typeof(OrderEntryResx))]
        public string RetainageExchangeString
        {
            get { return EnumUtility.GetStringValue(RetainageExchangeRate); }
        }

        /// <summary>
        /// Gets the Quote Expired String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "QuoteExpired", ResourceType = typeof(OrderEntryResx))]
        public string QuoteExpiredString
        {
            get { return EnumUtility.GetStringValue(QuoteExpired); }
        }

        /// <summary>
        /// Gets the Payment Type On Order String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentTypeOnOrder", ResourceType = typeof(OrderEntryResx))]
        public string PaymentTypeOnOrderString
        {
            get { return EnumUtility.GetStringValue(PaymentTypeOnOrder); }
        }

        /// <summary>
        /// Gets the Order Has Pre Authorize String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OrderHasPreAuthorization", ResourceType = typeof(OrderEntryResx))]
        public string OrderHasPreAuthorizeString
        {
            get { return EnumUtility.GetStringValue(OrderHasPreAuthorization); }
        }

        /// <summary>
        /// Gets the Incomplete Ship Exist String.
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IncompleteShipExistForOrder", ResourceType = typeof(OrderEntryResx))]
        public string IncompleteShipExistString
        {
            get { return EnumUtility.GetStringValue(IncompleteShipExistForOrder); }
        }

        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TermsRateOverride", ResourceType = typeof(OrderEntryResx))]
        public string TermsRateOverrideString
        {
            get
            {
                if (TermsRateOverride)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the ShipmentRateOverrideFlag String.
        /// </summary>
        [Display(Name = "ShipmentRateOverrideFlag", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string ShipmentRateOverrideFlagString
        {
            get
            {
                if (ShipmentRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the TrRateOverrideFlag String.
        /// </summary>
        [Display(Name = "TrRateOverrideFlag", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string TrRateOverrideFlagString
        {
            get
            {
                if (TrRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the TrShipmentRateOverrideFlag String.
        /// </summary>
        [Display(Name = "TRShipmentRateOverrideFlag", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string TrShipmentRateOverrideFlagString
        {
            get
            {
                if (TrShipmentRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the TrInvoiceRateOverrideFlag String.
        /// </summary>
        [Display(Name = "TRInvoiceRateOverrideFlag", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string TrInvoiceRateOverrideFlagString
        {
            get
            {
                if (TrInvoiceRateOverrideFlag)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the OverCreditLimit String.
        /// </summary>
        [Display(Name = "OverCreditLimit", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string OverCreditLimitString
        {
            get
            {
                if (OverCreditLimit)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the RequiresShippingLabels String.
        /// </summary>
        [Display(Name = "RequiresShippingLabels", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string RequiresShippingLabelsString
        {
            get
            {
                if (RequiresShippingLabels)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the ShippingLabelsPrinted String.
        /// </summary>
        [Display(Name = "ShippingLabelsPrinted", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string ShippingLabelsPrintedString
        {
            get
            {
                if (ShippingLabelsPrinted)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the RecalculateTax String.
        /// </summary>
        [Display(Name = "RecalculateTax", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string RecalculateTaxString
        {
            get
            {
                if (RecalculateTax)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the TaxOverridden String.
        /// </summary>
        [Display(Name = "TaxOverridden", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string TaxOverriddenString
        {
            get
            {
                if (TaxOverridden)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the PostInvoice String.
        /// </summary>
        [Display(Name = "PostInvoiceS", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string PostInvoiceString
        {
            get
            {
                if (PostInvoice)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the InvoiceDiscMiscCharges String.
        /// </summary>
        [Display(Name = "InvoiceDiscMiscCharges", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string InvoiceDiscMiscChargesString
        {
            get
            {
                if (InvoiceDiscMiscCharges)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the PerformTaxCalculation String.
        /// </summary>
        [Display(Name = "PerformTaxCalculation", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string PerformTaxCalculationString
        {
            get
            {
                if (PerformTaxCalculation)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the PerformCreditLimitCheck String.
        /// </summary>
        [Display(Name = "PerformCreditLimitCheck", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string PerformCreditLimitCheckString
        {
            get
            {
                if (PerformCreditLimitCheck)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the PerformShipAll String.
        /// </summary>
        [Display(Name = "PerformShipAll", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string PerformShipAllString
        {
            get
            {
                if (PerformShipAll)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the PerformForcedTaxCalculation String.
        /// </summary>
        [Display(Name = "PerformForcedTaxCalculation", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string PerformForcedTaxCalculationString
        {
            get
            {
                if (PerformForcedTaxCalculation)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the PerformManualTaxDistribution String.
        /// </summary>
        [Display(Name = "PerformManualTaxDistribution", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string PerformManualTaxDistributionString
        {
            get
            {
                if (PerformManualTaxDistribution)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the TaxCalculationInProgress String.
        /// </summary>
        [Display(Name = "TaxCalculationInProgress", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string TaxCalculationInProgressString
        {
            get
            {
                if (TaxCalculationInProgress)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the AutoTaxCalculationStatus String.
        /// </summary>
        [Display(Name = "AutoTaxCalculationStatus", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string AutoTaxCalculationStatusString
        {
            get
            {
                if (AutoTaxCalculationStatus)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the DisplayRateWarning String.
        /// </summary>
        [Display(Name = "DisplayRateWarning", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string DisplayRateWarningString
        {
            get
            {
                if (DisplayRateWarning)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the CustomerExists String.
        /// </summary>
        [Display(Name = "CustomerExists", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CustomerExistsString
        {
            get
            {
                if (CustomerExists)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the InvoiceWillBeProduced String.
        /// </summary>
        [Display(Name = "InvoiceWillBeProduced", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string InvoiceWillBeProducedString
        {
            get
            {
                if (InvoiceWillBeProduced)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the SecurityEnabled String.
        /// </summary>
        [Display(Name = "SecurityEnabled", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string SecurityEnabledsString
        {
            get
            {
                if (SecurityEnabled)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the UserCanApproveCreditLift String.
        /// </summary>
        [Display(Name = "UserCanApproveCreditLift", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string UserCanApproveCreditLiftString
        {
            get
            {
                if (UserCanApproveCreditLift)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the RecalcMultiPaymentDates String.
        /// </summary>
        [Display(Name = "RecalcMultiPaymentDates", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string RecalcMultiPaymentDatesString
        {
            get
            {
                if (RecalcMultiPaymentDates)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the PerformMultipleQuotesToOrder String.
        /// </summary>
        [Display(Name = "PerformMultipleQuotesToOrder", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string PerformMultipleQuotesToOrderString
        {
            get
            {
                if (PerformMultipleQuotesToOrder)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the OrderPartiallyShipped String.
        /// </summary>
        [Display(Name = "OrderPartiallyShipped", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string OrderPartiallyShippedrString
        {
            get
            {
                if (OrderPartiallyShipped)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the CheckingCustomerCreditLimit String.
        /// </summary>
        [Display(Name = "CheckingCustomerCreditLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CheckingCustomerCreditLimitString
        {
            get
            {
                if (CheckingCustomerCreditLimit)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the CheckingCustomerAgingLimit String.
        /// </summary>
        [Display(Name = "CheckingCustomerAgingLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CheckingCustomerAgingLimitString
        {
            get
            {
                if (CheckingCustomerAgingLimit)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the CheckingNatAcctCreditLimit String.
        /// </summary>
        [Display(Name = "CheckingNatAcctCreditLimit", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string CheckingNatAcctCreditLimitString
        {
            get
            {
                if (CheckingNatAcctCreditLimit)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the CheckingNatAcctAgingLimit String.
        /// </summary>
        [Display(Name = "CheckingNatAcctAgingLimit", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string CheckingNatAcctAgingLimitString
        {
            get
            {
                if (CheckingNatAcctAgingLimit)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the CustomerIsOverCreditLimit String.
        /// </summary>
        [Display(Name = "CustomerIsOverCreditLimit", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string CustomerIsOverCreditLimitString
        {
            get
            {
                if (CustomerIsOverCreditLimit)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the CustomerIsOverAgingLimit String.
        /// </summary>
        [Display(Name = "CustomerIsOverAgingLimit", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string CustomerIsOverAgingLimitString
        {
            get
            {
                if (CustomerIsOverAgingLimit)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the NatAcctIsOverCreditLimit String.
        /// </summary>
        [Display(Name = "NatAcctIsOverCreditLimit", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string NatAcctIsOverCreditLimitString
        {
            get
            {
                if (NatAcctIsOverCreditLimit)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the NatAcctIsOverAgingLimit String.
        /// </summary>
        [Display(Name = "NatAcctIsOverAgingLimit", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string NatAcctIsOverAgingLimitString
        {
            get
            {
                if (NatAcctIsOverAgingLimit)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the ARPendingTransIncluded String.
        /// </summary>
        [Display(Name = "ARPendingTransIncluded", ResourceType = typeof(OECommonResx))]
        [IgnoreExportImport]
        public string ARPendingTransIncludedString
        {
            get
            {
                if (ARPendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the OtherPendingTransIncluded String.
        /// </summary>
        [Display(Name = "OtherPendingTransIncluded", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string OtherPendingTransIncludedString
        {
            get
            {
                if (OtherPendingTransIncluded)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the DrivenbyUI String.
        /// </summary>
        [Display(Name = "DrivenbyUI", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string DrivenbyUIString
        {
            get
            {
                if (DrivenbyUI)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the OrderDiscountAmountOverride String.
        /// </summary>
        [Display(Name = "OrderDiscountAmountOverride", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string OrderDiscountAmountOverrideString
        {
            get
            {
                if (OrderDiscountAmountOverride)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        /// <summary>
        /// Gets the IncludeInCrmOpportunityTotal String.
        /// </summary>
        [Display(Name = "IncludeInCRMOpportunityTotal", ResourceType = typeof(OrderEntryResx))]
        [IgnoreExportImport]
        public string IncludeInCrmOpportunityTotalString
        {
            get
            {
                if (IncludeInCrmOpportunityTotal)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);

            }
        }

        #endregion
    }
}
