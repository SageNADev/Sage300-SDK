// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for OptionalField
    /// </summary>
    public partial class OptionalFieldDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Location Location { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets DefaultValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultValue, Id = Index.DefaultValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultValue { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public Validate Validate { get; set; }

        /// <summary>
        /// Gets or sets AutoInsert
        /// </summary>
        [Display(Name = "AutoInsert", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AutoInsert, Id = Index.AutoInsert, FieldType = EntityFieldType.Int, Size = 2)]
        public AutoInsert AutoInsert { get; set; }

        /// <summary>
        /// Gets or sets InventoryControl
        /// </summary>
        [Display(Name = "InventoryControl", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.InventoryControl, Id = Index.InventoryControl, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting InventoryControl { get; set; }

        /// <summary>
        /// Gets or sets ShipmentClearing
        /// </summary>
        [Display(Name = "ShipmentClearing", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ShipmentClearing, Id = Index.ShipmentClearing, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting ShipmentClearing { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearing
        /// </summary>
        [Display(Name = "NonStockClearingSetting", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.NonstockClearing, Id = Index.NonstockClearing, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting NonstockClearing { get; set; }

        /// <summary>
        /// Gets or sets CostVariance
        /// </summary>
        [Display(Name = "CostVariance", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.CostVariance, Id = Index.CostVariance, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting CostVariance { get; set; }

        /// <summary>
        /// Gets or sets ARInvoicesOptionalFields
        /// </summary>
        [Display(Name = "ARInvoicesOptionalFields", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ARInvoicesOptionalFields, Id = Index.ARInvoicesOptionalFields, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting ARInvoicesOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets SalesShipmentClearingCOGS
        /// </summary>
        [Display(Name = "SalesShipmentClearingCOGS", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.SalesShipmentClearingCOGS, Id = Index.SalesShipmentClearingCOGS, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting SalesShipmentClearingCOGS { get; set; }

        /// <summary>
        /// Gets or sets MiscellaneousCharges
        /// </summary>
        [Display(Name = "MiscellaneousCharges", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.MiscellaneousCharges, Id = Index.MiscellaneousCharges, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting MiscellaneousCharges { get; set; }

        /// <summary>
        /// Gets or sets Returns
        /// </summary>
        [Display(Name = "Returns", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Returns, Id = Index.Returns, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting Returns { get; set; }

        /// <summary>
        /// Gets or sets DamagedGoods
        /// </summary>
        [Display(Name = "DamagedGoods", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DamagedGoods, Id = Index.DamagedGoods, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting DamagedGoods { get; set; }

        /// <summary>
        /// Gets or sets Required
        /// </summary>
        [Display(Name = "RequiredLegend", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Required, Id = Index.Required, FieldType = EntityFieldType.Int, Size = 2)]
        public Required Required { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets ExternalCostTransactions
        /// </summary>
        [Display(Name = "ExternalCostTransactions", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ExternalCostTransactions, Id = Index.ExternalCostTransactions, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting ExternalCostTransactions { get; set; }

        /// <summary>
        /// Gets or sets Labor
        /// </summary>
        [Display(Name = "Labor", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Labor, Id = Index.Labor, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting Labor { get; set; }

        /// <summary>
        /// Gets or sets Overhead
        /// </summary>
        [Display(Name = "Overhead", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Overhead, Id = Index.Overhead, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting Overhead { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteClearing
        /// </summary>
        [Display(Name = "CreditDebitClearing", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.CreditDebitNoteClearing, Id = Index.CreditDebitNoteClearing, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting CreditDebitNoteClearing { get; set; }

        /// <summary>
        /// Gets or sets TypedDefaultValueFieldIndex
        /// </summary>
        [Display(Name = "TypedDefaultValueFieldIndex", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TypedDefaultValueFieldIndex, Id = Index.TypedDefaultValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedDefaultValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets DefaultTextValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultTextValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTextValue, Id = Index.DefaultTextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultTextValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultMoneyValue
        /// </summary>
        [Display(Name = "DefaultMoneyValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultAmountValue, Id = Index.DefaultAmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DefaultAmountValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultNumberValue
        /// </summary>
        [Display(Name = "DefaultNumberValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultNumberValue, Id = Index.DefaultNumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DefaultNumberValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultIntegerValue
        /// </summary>
        [Display(Name = "DefaultIntegerValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultIntegerValue, Id = Index.DefaultIntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long DefaultIntegerValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultYesNoValue
        /// </summary>
        [Display(Name = "DefaultYesNoValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultYesNoValue, Id = Index.DefaultYesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public DefaultYesNoValue DefaultYesNoValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultDateValue
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultDateValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultDateValue, Id = Index.DefaultDateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DefaultDateValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultTimeValue
        /// </summary>
        [Display(Name = "DefaultTimeValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTimeValue, Id = Index.DefaultTimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime DefaultTimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(CS.Resources.Forms.OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultValueDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValueDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultValueDescription, Id = Index.DefaultValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultValueDescription { get; set; }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets the Location string.
        /// </summary>
        public string LocationString
        {
            get { return EnumUtility.GetStringValue(Location); }
        }

        /// <summary>
        /// Gets the AllowBlank string.
        /// </summary>
        public string AllowBlankString
        {
            get { return EnumUtility.GetStringValue(AllowBlank); }
        }

        /// <summary>
        /// Gets the Validate string.
        /// </summary>
        public string ValidateString
        {
            get { return EnumUtility.GetStringValue(Validate); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string AutoInsertString
        {
            get { return EnumUtility.GetStringValue(AutoInsert); }
        }


        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string InventoryControlString
        {
            get { return EnumUtility.GetStringValue(InventoryControl); }
        }


        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string ShipmentClearingString
        {
            get { return EnumUtility.GetStringValue(ShipmentClearing); }
        }


        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string NonstockClearingString
        {
            get { return EnumUtility.GetStringValue(NonstockClearing); }
        }


        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string CostVarianceString
        {
            get { return EnumUtility.GetStringValue(CostVariance); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string ARInvoicesOptionalFieldsString
        {
            get { return EnumUtility.GetStringValue(ARInvoicesOptionalFields); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string SalesShipmentClearingCOGSString
        {
            get { return EnumUtility.GetStringValue(SalesShipmentClearingCOGS); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string MiscellaneousChargesString
        {
            get { return EnumUtility.GetStringValue(MiscellaneousCharges); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string ReturnsString
        {
            get { return EnumUtility.GetStringValue(Returns); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string DamagedGoodsString
        {
            get { return EnumUtility.GetStringValue(DamagedGoods); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string RequiredString
        {
            get { return EnumUtility.GetStringValue(Required); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string ValueSetString
        {
            get { return EnumUtility.GetStringValue(ValueSet); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string ExternalCostTransactionsString
        {
            get { return EnumUtility.GetStringValue(ExternalCostTransactions); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string LaborString
        {
            get { return EnumUtility.GetStringValue(Labor); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string OverheadString
        {
            get { return EnumUtility.GetStringValue(Overhead); }
        }

        /// <summary>
        /// Gets the Type string.
        /// </summary>
        public string CreditDebitNoteClearingString
        {
            get { return EnumUtility.GetStringValue(CreditDebitNoteClearing); }
        }


        /// <summary>
        /// Gets or Sets Multi Currency
        /// </summary>
        [IgnoreExportImport]
        public bool MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Serial Number
        /// </summary>
        /// <value>The serial number.</value>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFieldsValue DefaultOptionField { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFields DefaultOptionFieldValue { get; set; }

        /// <summary>
        /// Gets or sets InventoryControl
        /// </summary>
        [IgnoreExportImport]
        public bool IsInventoryControl
        {
            get
            {
                return InventoryControl == TransactionSetting.Yes;
            }
            set
            {

                InventoryControl = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets ShipmentClearing
        /// </summary>
        [IgnoreExportImport]
        public bool IsShipmentClearing
        {
            get
            {
                return ShipmentClearing == TransactionSetting.Yes;
            }
            set
            {

                ShipmentClearing = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets NonstockClearing
        /// </summary>
        [IgnoreExportImport]
        public bool IsNonstockClearing
        {
            get
            {
                return NonstockClearing == TransactionSetting.Yes;
            }
            set
            {

                NonstockClearing = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets CostVariance
        /// </summary>
        [IgnoreExportImport]
        public bool IsCostVariance
        {
            get
            {
                return CostVariance == TransactionSetting.Yes;
            }
            set
            {

                CostVariance = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets ARInvoicesOptionalFields
        /// </summary>
        [IgnoreExportImport]
        public bool IsARInvoicesOptionalFields
        {
            get
            {
                return ARInvoicesOptionalFields == TransactionSetting.Yes;
            }
            set
            {

                ARInvoicesOptionalFields = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets SalesShipmentClearingCOGS
        /// </summary>
        [IgnoreExportImport]
        public bool IsSalesShipmentClearingCOGS
        {
            get
            {
                return SalesShipmentClearingCOGS == TransactionSetting.Yes;
            }
            set
            {

                SalesShipmentClearingCOGS = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets MiscellaneousCharges
        /// </summary>
        [IgnoreExportImport]
        public bool IsMiscellaneousCharges
        {
            get
            {
                return MiscellaneousCharges == TransactionSetting.Yes;
            }
            set
            {

                MiscellaneousCharges = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets Returns
        /// </summary>
        [IgnoreExportImport]
        public bool IsReturns
        {
            get
            {
                return Returns == TransactionSetting.Yes;
            }
            set
            {

                Returns = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets DamagedGoods
        /// </summary>
        [IgnoreExportImport]
        public bool IsDamagedGoods
        {
            get
            {
                return DamagedGoods == TransactionSetting.Yes;
            }
            set
            {

                DamagedGoods = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets ExternalCostTransactions
        /// </summary>
        [IgnoreExportImport]
        public bool IsExternalCostTransactions
        {
            get
            {
                return ExternalCostTransactions == TransactionSetting.Yes;
            }
            set
            {

                ExternalCostTransactions = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets Labor
        /// </summary>
        [IgnoreExportImport]
        public bool IsLabor
        {
            get
            {
                return Labor == TransactionSetting.Yes;
            }
            set
            {

                Labor = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets Overhead
        /// </summary>
        [IgnoreExportImport]
        public bool IsOverhead
        {
            get
            {
                return Overhead == TransactionSetting.Yes;
            }
            set
            {

                Overhead = value ? TransactionSetting.Yes : TransactionSetting.No;
            }
        }

        /// <summary>
        /// Gets or sets CreditDebitNoteClearing
        /// </summary>
        [IgnoreExportImport]
        public bool IsCreditDebitNoteClearing
        {
            get
            {
                return CreditDebitNoteClearing == TransactionSetting.Yes;
            }
            set
            {

                CreditDebitNoteClearing = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }
    }
}
