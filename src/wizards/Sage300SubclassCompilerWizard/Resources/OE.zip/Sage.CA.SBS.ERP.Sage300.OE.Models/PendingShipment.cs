// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Model class for PendingShipment
    /// </summary>
    public partial class PendingShipment : ModelBase
    {
        /// <summary>
        /// Gets or sets OrderUniquifier
        /// </summary>
        [Key]
        [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal OrderUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets OrderType
        /// </summary>
        [ViewField(Name = Fields.OrderType, Id = Index.OrderType, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderTypeInquiry OrderType { get; set; }

        /// <summary>
        /// Gets or sets OrderDate
        /// </summary>
        [ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets ExpectedShipmentDate
        /// </summary>
        [ViewField(Name = Fields.ExpectedShipmentDate, Id = Index.ExpectedShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpectedShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets DESC
        /// </summary>
        [ViewField(Name = Fields.Desc, Id = Index.Desc, FieldType = EntityFieldType.Char, Size = 60)]
        public string Desc { get; set; }

        /// <summary>
        /// Gets or sets KittingBOM
        /// </summary>
        [ViewField(Name = Fields.KittingBom, Id = Index.KittingBom, FieldType = EntityFieldType.Int, Size = 2)]
        public KittingBOM KittingBom { get; set; }

        /// <summary>
        /// Gets or sets ComponentItem
        /// </summary>
        [ViewField(Name = Fields.ComponentItem, Id = Index.ComponentItem, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ComponentItem { get; set; }

        /// <summary>
        /// Gets or sets COMPDESC
        /// </summary>
        [ViewField(Name = Fields.Compdesc, Id = Index.Compdesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string Compdesc { get; set; }

        /// <summary>
        /// Gets or sets OrderDescription
        /// </summary>
        [ViewField(Name = Fields.OrderDescription, Id = Index.OrderDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OrderDescription { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets OrderType string value
        /// </summary>
        public string OrderTypeString
        {
            get { return EnumUtility.GetStringValue(OrderType); }
        }

        /// <summary>
        /// Gets or Sets FromItemNumber
        /// </summary>
        public string FromItemNumber { get; set; }

        /// <summary>
        /// Gets or Sets ToItemNumber
        /// </summary>
        public string ToItemNumber { get; set; }

        /// <summary>
        /// Gets or Sets FromLocation
        /// </summary>
        public string FromLocation { get; set; }

        /// <summary>
        /// Gets or Sets ToLocation
        /// </summary>
        public string ToLocation { get; set; }

        /// <summary>
        /// Gets or sets FromExpectedShipmentDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpectedShipmentDate", ResourceType = typeof(PendingShipmentsInquiryResx))]
        public DateTime? FromExpectedShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets ToExpectedShipmentDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpectedShipmentDate", ResourceType = typeof(PendingShipmentsInquiryResx))]
        public DateTime ToExpectedShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets FromCustomerNumber
        /// </summary>
        public string FromCustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ToCustomerNumber
        /// </summary>
        public string ToCustomerNumber { get; set; }

        #endregion
    }
}
