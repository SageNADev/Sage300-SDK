// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Partial class for OrderKittingDetailLotNumber
     /// </summary>
     public partial class OrderKittingDetailLotNumber : ModelBase
     {
          /// <summary>
          /// Gets or sets OrderUniquifier
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal OrderUniquifier {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int LineNumber {get; set;}

          /// <summary>
          /// Gets or sets ParentComponentNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ParentComponentNumber, Id = Index.ParentComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
          public long ParentComponentNumber {get; set;}

          /// <summary>
          /// Gets or sets ComponentNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ComponentNumber, Id = Index.ComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
          public long ComponentNumber {get; set;}

          /// <summary>
          /// Gets or sets LotNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
          public string LotNumber {get; set;}

          /// <summary>
          /// Gets or sets DetailNumber
          /// </summary>
          [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int DetailNumber {get; set;}

          /// <summary>
          /// Gets or sets ExpirationDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime ExpirationDate {get; set;}

          /// <summary>
          /// Gets or sets QuantityInStockingUOM
          /// </summary>
          [ViewField(Name = Fields.QuantityInStockingUOM, Id = Index.QuantityInStockingUOM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityInStockingUOM {get; set;}

          /// <summary>
          /// Gets or sets TransactionQuantity
          /// </summary>
          [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal TransactionQuantity {get; set;}

          /// <summary>
          /// Gets or sets QtyShippedInStockingUOM
          /// </summary>
          [ViewField(Name = Fields.QtyShippedInStockingUOM, Id = Index.QtyShippedInStockingUOM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QtyShippedInStockingUOM {get; set;}

          /// <summary>
          /// Gets or sets QuantityShipped
          /// </summary>
          [ViewField(Name = Fields.QuantityShipped, Id = Index.QuantityShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityShipped {get; set;}

     }
}
