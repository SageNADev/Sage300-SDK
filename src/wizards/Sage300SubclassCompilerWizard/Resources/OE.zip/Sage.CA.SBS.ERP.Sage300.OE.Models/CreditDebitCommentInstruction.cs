// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for CreditDebitCommentInstruction
    /// </summary>
    public partial class CreditDebitCommentInstruction : ModelBase
    {
        /// <summary>
        /// Gets or sets CNUniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CNUniquifier", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CnUniquifier, Id = Index.CnUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CnUniquifier { get; set; }

        /// <summary>
        /// Gets or sets Uniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Uniquifier", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.Uniquifier, Id = Index.Uniquifier, FieldType = EntityFieldType.Int, Size = 2)]
        public int Uniquifier { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets CommentsInstructionsType
        /// </summary>
        [Display(Name = "CommentsInstructionsType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CommentsInstructionsType, Id = Index.CommentsInstructionsType, FieldType = EntityFieldType.Int, Size = 2)]
        public CommentsInstructionsType CommentsInstructionsType { get; set; }

        /// <summary>
        /// Gets or sets CommentsInstructions
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommentsInstructions", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.CommentsInstructions, Id = Index.CommentsInstructions, FieldType = EntityFieldType.Char, Size = 80)]
        public string CommentsInstructions { get; set; }

        public int SerialNumber { get; set; }
    }
}
