// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// The InvoiceCommentsInstruction model. 
    /// </summary>
    public partial class InvoiceCommentsInstruction : ModelBase
    {
        /// <summary>
        /// Gets or sets InvoiceUniquifier, the parent Invoice's unique key.
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceUniquifier", ResourceType = typeof(InvoiceEntryResx))]
        [ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal InvoiceUniquifier { get; set; }

        /// <summary>
        /// Gets or sets LineUniquifier, the detail line portion of the composite key. 
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineUniquifier", ResourceType = typeof(InvoiceEntryResx))]
        [ViewField(Name = Fields.LineUniquifier, Id = Index.LineUniquifier, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineUniquifier { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber, the key of the Comments/Instructions line.
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(InvoiceEntryResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets CommentsInstructionsType, the CommentsInstructionsType enumeration denoting the type of this line's contents (Comment or Instruction).
        /// </summary>
        [Display(Name = "CommentsInstructionsType", ResourceType = typeof(InvoiceEntryResx))]
        [ViewField(Name = Fields.CommentsInstructionsType, Id = Index.CommentsInstructionsType, FieldType = EntityFieldType.Int, Size = 2)]
        public CommentsInstructionsType CommentsInstructionsType { get; set; }

        /// <summary>
        /// Gets or sets CommentsInstructions, the content payload value. 
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommentsInstructions", ResourceType = typeof(InvoiceEntryResx))]
        [ViewField(Name = Fields.CommentsInstructions, Id = Index.CommentsInstructions, FieldType = EntityFieldType.Char, Size = 80)]
        public string CommentsInstructions { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets CommentsInstructionsType string value
        /// </summary>
        public string CommentsInstructionsTypeString
        {
            get { return EnumUtility.GetStringValue(CommentsInstructionsType); }
        }

        #endregion
    }
}
