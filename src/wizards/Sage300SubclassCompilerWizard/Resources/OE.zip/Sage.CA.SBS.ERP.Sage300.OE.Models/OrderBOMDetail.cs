// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Partial class for OrderBOMDetail
     /// </summary>
     public partial class OrderBOMDetail : ModelBase
     {
          /// <summary>
          /// Gets or sets OrderUniquifier
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal OrderUniquifier {get; set;}

          /// <summary>
          /// Gets or sets DetailLineNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DetailLineNumber, Id = Index.DetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int DetailLineNumber {get; set;}

          /// <summary>
          /// Gets or sets ParentComponentNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ParentComponentNumber, Id = Index.ParentComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
          public long ParentComponentNumber {get; set;}

          /// <summary>
          /// Gets or sets ComponentNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ComponentNumber, Id = Index.ComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
          public long ComponentNumber {get; set;}

          /// <summary>
          /// Gets or sets ComponentItemNumber
          /// </summary>
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ComponentItemNumber, Id = Index.ComponentItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
          public string ComponentItemNumber {get; set;}

          /// <summary>
          /// Gets or sets Description
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
          public string Description {get; set;}

          /// <summary>
          /// Gets or sets ComponentQuantity
          /// </summary>
          [ViewField(Name = Fields.ComponentQuantity, Id = Index.ComponentQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal ComponentQuantity {get; set;}

          /// <summary>
          /// Gets or sets UnitOfMeasure
          /// </summary>
          [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
          public string UnitOfMeasure {get; set;}

          /// <summary>
          /// Gets or sets QuantityOrdered
          /// </summary>
          [ViewField(Name = Fields.QuantityOrdered, Id = Index.QuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityOrdered {get; set;}

          /// <summary>
          /// Gets or sets QuantityShipped
          /// </summary>
          [ViewField(Name = Fields.QuantityShipped, Id = Index.QuantityShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityShipped {get; set;}

          /// <summary>
          /// Gets or sets ComponentsBOMNumber
          /// </summary>
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ComponentsBOMNumber, Id = Index.ComponentsBOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
          public string ComponentsBOMNumber {get; set;}

          /// <summary>
          /// Gets or sets ComponentsBOMBuildQty
          /// </summary>
          [ViewField(Name = Fields.ComponentsBOMBuildQty, Id = Index.ComponentsBOMBuildQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal ComponentsBOMBuildQty {get; set;}

          /// <summary>
          /// Gets or sets ComponentsBOMBuildUnit
          /// </summary>
          [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ComponentsBOMBuildUnit, Id = Index.ComponentsBOMBuildUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
          public string ComponentsBOMBuildUnit {get; set;}

          /// <summary>
          /// Gets or sets ComponentsBOMBuildUnitConv
          /// </summary>
          [ViewField(Name = Fields.ComponentsBOMBuildUnitConv, Id = Index.ComponentsBOMBuildUnitConv, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal ComponentsBOMBuildUnitConv {get; set;}

          /// <summary>
          /// Gets or sets UnitConversion
          /// </summary>
          [ViewField(Name = Fields.UnitConversion, Id = Index.UnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal UnitConversion {get; set;}

     }
}
