// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Partial class for OrderPrepayment
	/// </summary>
	public partial class OrderPrepayment : ModelBase
	{
		/// <summary>
		/// Gets or sets OrderUniquifier
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderUniquifier", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal OrderUniquifier { get; set; }

		/// <summary>
		/// Gets or sets CustomerNumber
		/// </summary>
        [Display(Name = "CustomerNumber", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string CustomerNumber { get; set; }

		/// <summary>
		/// Gets or sets CustomerName
		/// </summary>
		[Display(Name = "CustomerName", ResourceType = typeof (OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
		public string CustomerName { get; set; }

		/// <summary>
		/// Gets or sets CustomerCurrency
		/// </summary>
        [Display(Name = "CustomerCurrency", ResourceType = typeof(OECommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string CustomerCurrency { get; set; }

		/// <summary>
		/// Gets or sets CustRate
		/// </summary>
        [Display(Name = "CustRate", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.CustRate, Id = Index.CustRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal CustRate { get; set; }

		/// <summary>
		/// Gets or sets CustRateDate
		/// </summary>
        [Display(Name = "CustRateDate", ResourceType = typeof(OrderEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CustRateDate, Id = Index.CustRateDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime CustRateDate { get; set; }

		/// <summary>
		/// Gets or sets CustRateType
		/// </summary>
        [Display(Name = "CustRateType", ResourceType = typeof(OrderEntryResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CustRateType, Id = Index.CustRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string CustRateType { get; set; }

		/// <summary>
		/// Gets or sets OperCustCurnToFunc
		/// </summary>
        [Display(Name = "OperCustCurnToFunc", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.OperCustCurnToFunc, Id = Index.OperCustCurnToFunc, FieldType = EntityFieldType.Int, Size = 2)]
		public int OperCustCurnToFunc { get; set; }

		/// <summary>
		/// Gets or sets DocumentTotal
		/// </summary>
        [Display(Name = "DocumentTotal", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.DocumentTotal, Id = Index.DocumentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DocumentTotal { get; set; }

		/// <summary>
		/// Gets or sets DiscountAvailable
		/// </summary>
        [Display(Name = "DiscountAvailable", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.DiscountAvailable, Id = Index.DiscountAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DiscountAvailable { get; set; }

		/// <summary>
		/// Gets or sets AmountDue
		/// </summary>
        [Display(Name = "AmountDue", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.AmountDue, Id = Index.AmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal AmountDue { get; set; }

		/// <summary>
		/// Gets or sets ReceiptBatchNumber
		/// </summary>
        [Display(Name = "ReceiptBatchNumber", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ReceiptBatchNumber, Id = Index.ReceiptBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
		public decimal ReceiptBatchNumber { get; set; }

		/// <summary>
		/// Gets or sets BankCode
		/// </summary>
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
		public string BankCode { get; set; }

		/// <summary>
		/// Gets or sets ReceiptType
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptType", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ReceiptType, Id = Index.ReceiptType, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string ReceiptType { get; set; }

		/// <summary>
		/// Gets or sets CheckReceiptNo
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckReceiptNo", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.CheckReceiptNo, Id = Index.CheckReceiptNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string CheckReceiptNo { get; set; }

		/// <summary>
		/// Gets or sets ReceiptDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptDate", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ReceiptDate, Id = Index.ReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ReceiptDate { get; set; }

		/// <summary>
		/// Gets or sets ReceiptAmount
		/// </summary>
        [Display(Name = "ReceiptAmount", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.ReceiptAmount, Id = Index.ReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal ReceiptAmount { get; set; }

		/// <summary>
		/// Gets or sets BankCurrency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCurrency", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.BankCurrency, Id = Index.BankCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string BankCurrency { get; set; }

		/// <summary>
		/// Gets or sets RateType
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string RateType { get; set; }

		/// <summary>
		/// Gets or sets BankRate
		/// </summary>
        [Display(Name = "BankRate", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.BankRate, Id = Index.BankRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal BankRate { get; set; }

		/// <summary>
		/// Gets or sets RateDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime RateDate { get; set; }

		/// <summary>
		/// Gets or sets BatchDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDescription", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.BatchDescription, Id = Index.BatchDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string BatchDescription { get; set; }

		/// <summary>
		/// Gets or sets ReceiptDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptDescription", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.ReceiptDescription, Id = Index.ReceiptDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string ReceiptDescription { get; set; }

		/// <summary>
		/// Gets or sets BankRateSpread
		/// </summary>
        [Display(Name = "BankRateSpread", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.BankRateSpread, Id = Index.BankRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal BankRateSpread { get; set; }

		/// <summary>
		/// Gets or sets PrepaymentID
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PrepaymentID", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.PrepaymentID, Id = Index.PrepaymentID, FieldType = EntityFieldType.Char, Size = 22)]
		public string PrepaymentID { get; set; }

		/// <summary>
		/// Gets or sets PaymentType
		/// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
		public PaymentType PaymentType { get; set; }

		/// <summary>
		/// Gets or sets PreauthCurrency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PreauthCurrency", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.PreauthCurrency, Id = Index.PreauthCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string PreauthCurrency { get; set; }

		/// <summary>
		/// Gets or sets PreauthTransactionID
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PreauthTransactionID", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.PreauthTransactionID, Id = Index.PreauthTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
		public string PreauthTransactionID { get; set; }

		/// <summary>
		/// Gets or sets CaptureTransactionID
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CaptureTransactionID", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.CaptureTransactionID, Id = Index.CaptureTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
		public string CaptureTransactionID { get; set; }

		/// <summary>
		/// Gets or sets VoidTransactionID
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VoidTransactionID", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.VoidTransactionID, Id = Index.VoidTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
		public string VoidTransactionID { get; set; }

		/// <summary>
		/// Gets or sets PreauthAmount
		/// </summary>
        [Display(Name = "PreauthAmount", ResourceType = typeof(OECommonResx))]
		[ViewField(Name = Fields.PreauthAmount, Id = Index.PreauthAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal PreauthAmount { get; set; }

		/// <summary>
		/// Gets or sets CreditCardChargeStatus
		/// </summary>
        [Display(Name = "CreditCardChargeStatus", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.CreditCardChargeStatus, Id = Index.CreditCardChargeStatus, FieldType = EntityFieldType.Int, Size = 2)]
		public CreditCardChargeStatus CreditCardChargeStatus { get; set; }

		/// <summary>
		/// Gets or sets YPProcessCode
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "YPProcessCode", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.YpProcessCode, Id = Index.YpProcessCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string YpProcessCode { get; set; }

		/// <summary>
		/// Gets or sets CapturePreauthorization
		/// </summary>
        [Display(Name = "CapturePreauthorization", ResourceType = typeof(OrderEntryResx))]
		[ViewField(Name = Fields.CapturePreauthorization, Id = Index.CapturePreauthorization, FieldType = EntityFieldType.Bool, Size = 2)]
		public CapturePreauthorization CapturePreauthorization { get; set; }

        /// <summary>
        /// Gets or sets DepositNumber 
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DepositNumber", ResourceType = typeof(OECommonResx))]
        public decimal DepositNumber { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets PaymentType string value
		/// </summary>
		public string PaymentTypeString
		{
			get { return EnumUtility.GetStringValue(PaymentType); }
		}

		/// <summary>
		/// Gets CreditCardChargeStatus string value
		/// </summary>
		public string CreditCardChargeStatusString
		{
			get { return EnumUtility.GetStringValue(CreditCardChargeStatus); }
		}

		/// <summary>
		/// Gets CapturePreauthorization string value
		/// </summary>
		public string CapturePreauthorizationString
		{
			get { return EnumUtility.GetStringValue(CapturePreauthorization); }
		}

		#endregion
	}
}
