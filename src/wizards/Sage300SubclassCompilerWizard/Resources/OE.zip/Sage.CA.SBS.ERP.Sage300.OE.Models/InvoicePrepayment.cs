// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
	/// <summary>
	/// Partial class for InvoicePrepayment
	/// </summary>
	public partial class InvoicePrepayment : ModelBase
	{
        /// <summary>
        /// True if prepayment exists; otherwise false
        /// </summary>
        public bool PrepaymentExists { get; set; }

        /// <summary>
        /// True if pre-authorization exists; otherwise false
        /// </summary>
        public bool PreAuthorizationExists { get; set; }
        
        /// <summary>
		/// Gets or sets InvoiceUniquifier
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.InvoiceUniquifier, Id = Index.InvoiceUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal InvoiceUniquifier { get; set; }

		/// <summary>
		/// Gets or sets CustomerNumber
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string CustomerNumber { get; set; }

		/// <summary>
		/// Gets or sets CustomerName
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
		public string CustomerName { get; set; }

		/// <summary>
		/// Gets or sets CustomerCurrency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string CustomerCurrency { get; set; }

		/// <summary>
		/// Gets or sets CustRate
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustRate, Id = Index.CustRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal CustRate { get; set; }

		/// <summary>
		/// Gets or sets CustRateDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustRateDate, Id = Index.CustRateDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime CustRateDate { get; set; }

		/// <summary>
		/// Gets or sets CustRateType
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CustRateType, Id = Index.CustRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string CustRateType { get; set; }

		/// <summary>
		/// Gets or sets OperCustCurnToFunc
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OperCustCurnToFunc, Id = Index.OperCustCurnToFunc, FieldType = EntityFieldType.Int, Size = 2)]
		public int OperCustCurnToFunc { get; set; }

		/// <summary>
		/// Gets or sets DocumentTotal
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.DocumentTotal, Id = Index.DocumentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DocumentTotal { get; set; }

		/// <summary>
		/// Gets or sets DiscountAvailable
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.DiscountAvailable, Id = Index.DiscountAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DiscountAvailable { get; set; }

		/// <summary>
		/// Gets or sets AmountDue
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.AmountDue, Id = Index.AmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal AmountDue { get; set; }

		/// <summary>
		/// Gets or sets ReceiptBatchNumber
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ReceiptBatchNumber, Id = Index.ReceiptBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
		public decimal ReceiptBatchNumber { get; set; }

		/// <summary>
		/// Gets or sets BankCode
		/// </summary>
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
		public string BankCode { get; set; }

		/// <summary>
		/// Gets or sets ReceiptType
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ReceiptType, Id = Index.ReceiptType, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string ReceiptType { get; set; }

		/// <summary>
		/// Gets or sets CheckReceiptNo
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CheckReceiptNo, Id = Index.CheckReceiptNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string CheckReceiptNo { get; set; }

		/// <summary>
		/// Gets or sets ReceiptDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ReceiptDate, Id = Index.ReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? ReceiptDate { get; set; }

		/// <summary>
		/// Gets or sets ReceiptAmount
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ReceiptAmount, Id = Index.ReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal ReceiptAmount { get; set; }

		/// <summary>
		/// Gets or sets BankCurrency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BankCurrency, Id = Index.BankCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string BankCurrency { get; set; }

		/// <summary>
		/// Gets or sets RateType
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string RateType { get; set; }

		/// <summary>
		/// Gets or sets BankRate
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BankRate, Id = Index.BankRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal BankRate { get; set; }

		/// <summary>
		/// Gets or sets RateDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime RateDate { get; set; }

		/// <summary>
		/// Gets or sets BatchDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BatchDescription, Id = Index.BatchDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string BatchDescription { get; set; }

		/// <summary>
		/// Gets or sets ReceiptDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ReceiptDescription, Id = Index.ReceiptDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string ReceiptDescription { get; set; }

		/// <summary>
		/// Gets or sets BankRateSpread
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BankRateSpread, Id = Index.BankRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal BankRateSpread { get; set; }

		/// <summary>
		/// Gets or sets PrepaymentID
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PrepaymentID, Id = Index.PrepaymentID, FieldType = EntityFieldType.Char, Size = 22)]
		public string PrepaymentID { get; set; }

		/// <summary>
		/// Gets or sets ICDayEndTransNumber
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ICDayEndTransNumber, Id = Index.ICDayEndTransNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal ICDayEndTransNumber { get; set; }

		/// <summary>
		/// Gets or sets PaymentType
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
		public PaymentType PaymentType { get; set; }

		/// <summary>
		/// Gets or sets PreauthCurrency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PreauthCurrency, Id = Index.PreauthCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string PreauthCurrency { get; set; }

		/// <summary>
		/// Gets or sets PreauthTransactionID
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PreauthTransactionID, Id = Index.PreauthTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
		public string PreauthTransactionID { get; set; }

		/// <summary>
		/// Gets or sets CaptureTransactionID
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CaptureTransactionID, Id = Index.CaptureTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
		public string CaptureTransactionID { get; set; }

		/// <summary>
		/// Gets or sets VoidTransactionID
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.VoidTransactionID, Id = Index.VoidTransactionID, FieldType = EntityFieldType.Char, Size = 36)]
		public string VoidTransactionID { get; set; }

		/// <summary>
		/// Gets or sets PreauthAmount
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.PreauthAmount, Id = Index.PreauthAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal PreauthAmount { get; set; }

		/// <summary>
		/// Gets or sets CreditCardChargeStatus
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CreditCardChargeStatus, Id = Index.CreditCardChargeStatus, FieldType = EntityFieldType.Int, Size = 2)]
		public CreditCardChargeStatus CreditCardChargeStatus { get; set; }

		/// <summary>
		/// Gets or sets YPProcessCode
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.YPProcessCode, Id = Index.YPProcessCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string YPProcessCode { get; set; }

		/// <summary>
		/// Gets or sets CapturePreauthorization
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CapturePreauthorization, Id = Index.CapturePreauthorization, FieldType = EntityFieldType.Bool, Size = 2)]
		public CapturePreauthorization CapturePreauthorization { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets PaymentType string value
		/// </summary>
		public string PaymentTypeString
		{
			get { return EnumUtility.GetStringValue(PaymentType); }
		}

		/// <summary>
		/// Gets CreditCardChargeStatus string value
		/// </summary>
		public string CreditCardChargeStatusString
		{
			get { return EnumUtility.GetStringValue(CreditCardChargeStatus); }
		}

		/// <summary>
		/// Gets CapturePreauthorization string value
		/// </summary>
		public string CapturePreauthorizationString
		{
			get { return EnumUtility.GetStringValue(CapturePreauthorization); }
		}

		#endregion
	}
}
