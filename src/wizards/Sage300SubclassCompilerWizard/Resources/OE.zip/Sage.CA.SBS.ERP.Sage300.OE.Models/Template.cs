// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using System.ComponentModel.DataAnnotations;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
    /// <summary>
    /// Partial class for Template
    /// </summary>
    public partial class Template : ModelBase
    {
        /// <summary>
        /// Gets or sets TemplateCode
        /// </summary>
        [Key]
        [Display(Name = "TemplateCode", ResourceType = typeof(OECommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TemplateCode { get; set; }

        /// <summary>
        /// Gets or sets TemplateDescription
        /// </summary>
        [Display(Name = "TemplateDescription", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TemplateDescription, Id = Index.TemplateDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TemplateDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultOrderType
        /// </summary>
        [Display(Name = "OrderType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DefaultOrderType, Id = Index.DefaultOrderType, FieldType = EntityFieldType.Int, Size = 2)]
        public OrderType DefaultOrderType { get; set; }

        /// <summary>
        /// Gets or sets DefaultFreeOnBoardPoint
        /// </summary>
        [Display(Name = "FOBPoint", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultFreeOnBoardPoint, Id = Index.DefaultFreeOnBoardPoint, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultFreeOnBoardPoint { get; set; }

        /// <summary>
        /// Gets or sets DefaultOnHold
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DefaultOnHold, Id = Index.DefaultOnHold, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DefaultOnHold { get; set; }

        /// <summary>
        /// Gets or sets DefaultLocation
        /// </summary>
        [Display(Name = "Location", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultLocation, Id = Index.DefaultLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultLocation { get; set; }

        /// <summary>
        /// Gets or sets DefaultDescription
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultDescription, Id = Index.DefaultDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultReference
        /// </summary>
        [Display(Name = "Reference", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultReference, Id = Index.DefaultReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultReference { get; set; }

        /// <summary>
        /// Gets or sets DefaultComment
        /// </summary>
        [Display(Name = "Comment", ResourceType = typeof(OECommonResx))]
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultComment, Id = Index.DefaultComment, FieldType = EntityFieldType.Char, Size = 250)]
        public string DefaultComment { get; set; }

        /// <summary>
        /// Gets or sets DefaultShipViaCode
        /// </summary>
        [Display(Name = "ShipViaCode", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultShipViaCode, Id = Index.DefaultShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets DefaultCustomerType
        /// </summary>
        [Display(Name = "CustomerType", ResourceType = typeof(OECommonResx))]
        [ViewField(Name = Fields.DefaultCustomerType, Id = Index.DefaultCustomerType, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerType DefaultCustomerType { get; set; }

        /// <summary>
        /// Gets or sets DefaultPriceList
        /// </summary>
        [Display(Name = "PriceList", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultPriceList, Id = Index.DefaultPriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultPriceList { get; set; }

        /// <summary>
        /// Gets or sets DefaultTerritory
        /// </summary>
        [Display(Name = "Territory", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultTerritory, Id = Index.DefaultTerritory, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultTerritory { get; set; }

        /// <summary>
        /// Gets or sets DefaultTaxGroup
        /// </summary>
        [Display(Name = "TaxGroup", ResourceType = typeof(OECommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultTaxGroup, Id = Index.DefaultTaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string DefaultTaxGroup { get; set; }

        /// <summary>
        /// Gets or sets DefaultPaymentTerms
        /// </summary>
        [Display(Name = "Terms", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultPaymentTerms, Id = Index.DefaultPaymentTerms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultPaymentTerms { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCodeDescription
        /// </summary>
        [Display(Name = "ShipViaDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipViaCodeDescription, Id = Index.ShipViaCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets PriceListCodeDescription
        /// </summary>
        [Display(Name = "PriceListDescription", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PriceListCodeDescription, Id = Index.PriceListCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string PriceListCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets PaymentTermsDescription
        /// </summary>
        [Display(Name = "TermsDescription", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentTermsDescription, Id = Index.PaymentTermsDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentTermsDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription
        /// </summary>
         [Display(Name = "TaxGroupDescription", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets LocationDescription
        /// </summary>
        [Display(Name = "LocationDescription", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LocationDescription, Id = Index.LocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroupCurrency", ResourceType = typeof(TemplatesResx))]
        [ViewField(Name = Fields.TaxGroupCurrency, Id = Index.TaxGroupCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxGroupCurrency { get; set; }

        /// <summary>
        /// Gets or sets OnholdReason
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OnholdReason", ResourceType = typeof(TemplatesResx))]
        [ViewField(Name = Fields.OnholdReason, Id = Index.OnholdReason, FieldType = EntityFieldType.Char, Size = 60)]
        public string OnholdReason { get; set; }

        /// <summary>
        /// UI Property
        /// </summary>
        [IgnoreExportImport]
        public string CustomerTypeDescription
        {
            get { return EnumUtility.GetStringValue(DefaultCustomerType); }
        }

        /// <summary>
        /// UI Property
        /// </summary>
        [IgnoreExportImport]
        public string OrderTypeDescription
        {
            get { return EnumUtility.GetStringValue(DefaultOrderType); }
        }

        /// <summary>
        /// Get the string of OnHold property,UI Property
        /// </summary>
        [IgnoreExportImport]
        public string OnHoldString
        {
            get
            {
                var result = DefaultOnHold ? Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.BooleanType.True : Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.BooleanType.False;
                return EnumUtility.GetStringValue(result);
            }
        }

        /// <summary>
        /// Gets or sets DefaultCustomerAccountSet
        /// </summary>
        [Display(Name = "CustomerAccountSet", ResourceType = typeof(OECommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultCustomerAccountSet, Id = Index.DefaultCustomerAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultCustomerAccountSet { get; set; }

        /// <summary>
        /// Gets or sets CustomerAccountSetDescription
        /// </summary>
        [Display(Name = "CustomerAccountSetDescription", ResourceType = typeof(OECommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerAccountSetDescription, Id = Index.CustomerAccountSetDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerAccountSetDescription { get; set; }

    }
}
