// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Partial class for OrderComment
     /// </summary>
     public partial class OrderComment : ModelBase
     {
          /// <summary>
          /// Gets or sets OrderUniquifier
          /// </summary>
          [Key]
         [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
         [Display(Name = "OrderUniquifier", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal OrderUniquifier {get; set;}

          /// <summary>
          /// Gets or sets Uniquifier
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Uniquifier", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.Uniquifier, Id = Index.Uniquifier, FieldType = EntityFieldType.Int, Size = 2)]
          public int Uniquifier {get; set;}

          /// <summary>
          /// Gets or sets DetailNumber
          /// </summary>
          [Display(Name = "DetailNumber", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int DetailNumber {get; set;}

          /// <summary>
          /// Gets or sets CommentsInstructionsType
          /// </summary>
          [Display(Name = "CommentsInstructionsType", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.CommentsInstructionsType, Id = Index.CommentsInstructionsType, FieldType = EntityFieldType.Int, Size = 2)]
          public CommentsInstructionsType CommentsInstructionsType {get; set;}

          /// <summary>
          /// Gets or sets CommentsInstructions
          /// </summary>
          [StringLength(80, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "CommentsInstructions", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 80)]
          public string Comments {get; set;}

          [IgnoreExportImport]
          public int SerialNumber { get; set; }

          /// <summary>
          /// Gets or sets Invoiced
          /// </summary>
          [IgnoreExportImport]
          [ViewField(Name = Fields.Invoiced, Id = Index.Invoiced, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool Invoiced {get; set;}

     }
}
