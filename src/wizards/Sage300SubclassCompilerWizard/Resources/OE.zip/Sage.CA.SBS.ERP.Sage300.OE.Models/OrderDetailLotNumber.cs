// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.OE.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.OE.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.OE.Models
{
     /// <summary>
     /// Partial class for OrderDetailLotNumber
     /// </summary>
     public partial class OrderDetailLotNumber : ModelBase
     {
          /// <summary>
          /// Gets or sets OrderUniquifier
          /// </summary>
          [Key]
         [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
         [Display(Name = "OrderUniquifier", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal OrderUniquifier {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "LineNumber", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int LineNumber {get; set;}

          /// <summary>
          /// Gets or sets LotNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "LotNumber", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
          public string LotNumber {get; set;}

          /// <summary>
          /// Gets or sets DetailNumber
          /// </summary>
          [Display(Name = "DetailNumber", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int DetailNumber {get; set;}

          /// <summary>
          /// Gets or sets ExpirationDate
          /// </summary>
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ExpirationDate", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime ExpirationDate {get; set;}

          /// <summary>
          /// Gets or sets QuantityInStockingUom
          /// </summary>
          [Display(Name = "QuantityInStockingUOM", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.QuantityInStockingUom, Id = Index.QuantityInStockingUom, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityInStockingUom {get; set;}

          /// <summary>
          /// Gets or sets TransactionQuantity
          /// </summary>
          [Display(Name = "TransactionQuantity", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal TransactionQuantity {get; set;}

          /// <summary>
          /// Gets or sets QtyShippedInStockingUom
          /// </summary>
          [Display(Name = "QtyShippedInStockingUOM", ResourceType = typeof(OrderEntryResx))]
          [ViewField(Name = Fields.QtyShippedInStockingUom, Id = Index.QtyShippedInStockingUom, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QtyShippedInStockingUom {get; set;}

          /// <summary>
          /// Gets or sets QuantityShipped
          /// </summary>
          [Display(Name = "QtyShipped", ResourceType = typeof(OECommonResx))]
          [ViewField(Name = Fields.QuantityShipped, Id = Index.QuantityShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityShipped {get; set;}

     }
}
