﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.CustomDataAnnotations
{
    /// <summary>
    /// Class ValidateListForSelection.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class ValidateListForSelection : ValidationAttribute
    {
        /// <summary>
        /// The default error
        /// </summary>
        private static readonly string DefaultError = AnnotationsResx.RequiredList;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateListForSelection"/> class.
        /// </summary>
        public ValidateListForSelection() : base(DefaultError)
        {
        }

        /// <summary>
        /// Provide a different implementaiton for IsValid function
        /// </summary>
        /// <param name="value">Object</param>
        /// <returns>Function Result</returns>
        public override bool IsValid(object value)
        {
            if (value != null)
            {
                var list = value as List<MultiSelect>;

                // ReSharper disable once LoopCanBeConvertedToQuery
                if (list != null)
                {
                    foreach (var listItem in list)
                    {
                        if (listItem.isSelected)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            return true;
        }

        /// <summary>
        /// Format the error message
        /// </summary>
        /// <param name="name">Input message</param>
        /// <returns>Formatted message</returns>
        public override string FormatErrorMessage(string name)
        {
            return String.Format(ErrorMessageString, name);
        }
    }
}