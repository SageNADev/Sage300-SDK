﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.CustomDataAnnotations
{
    /// <summary>
    /// Custome data annotation to check the list count
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class ValidateListCount : ValidationAttribute
    {
        /// <summary>
        /// The default error
        /// </summary>
        private static readonly string DefaultError = AnnotationsResx.RequiredList;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateListCount"/> class.
        /// </summary>
        public ValidateListCount() : base(DefaultError)
        {
        }

        /// <summary>
        /// Provide a different implementaiton for IsValid function
        /// </summary>
        /// <param name="value">Object</param>
        /// <returns>Function Result</returns>
        public override bool IsValid(object value)
        {
            var list = value as IList;
            return (list != null && list.Count > 0);
        }

        /// <summary>
        /// Format the error message
        /// </summary>
        /// <param name="name">Input message</param>
        /// <returns>Formatted message</returns>
        public override string FormatErrorMessage(string name)
        {
            return String.Format(ErrorMessageString, name);
        }
    }
}