/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class AccountSourceCurrencyInqProcessor : ModelBase
    {
        /// <summary>
        /// This constructor initializes keys to be empty strings. This avoids the
        /// problem of serializing objects with a null required property.
        /// </summary>
        public AccountSourceCurrencyInqProcessor()
        {
            Account = string.Empty;
            SourceCurrencyInquiryDetails = new EnumerableResponse<AccountSourceCurrencyInqProcessor>();
        }

        /// <summary>
        /// Gets or sets Account 
        /// </summary>
        [ViewField(Name = Fields.Account, Id = Index.Account, FieldType = EntityFieldType.Char, Size = 45)]
        public string Account { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2)]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets RollupSwitch 
        /// </summary>
        [ViewField(Name = Fields.RollupSwitch, Id = Index.RollupSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int RollupSwitch { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3)]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDescription 
        /// </summary>
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets SourceBalance 
        /// </summary>
        [ViewField(Name = Fields.SourceBalance, Id = Index.SourceBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceBalance { get; set; }

        /// <summary>
        /// Gets or sets EquivalentBalance 
        /// </summary>
        [ViewField(Name = Fields.EquivalentBalance, Id = Index.EquivalentBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EquivalentBalance { get; set; }

        /// <summary>
        /// Gets or sets ReportingBalance 
        /// </summary>
        [ViewField(Name = Fields.ReportingBalance, Id = Index.ReportingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReportingBalance { get; set; }

        /// <summary>
        /// Gets and sets SourceCurrencyInquiryDetails
        /// </summary>
        public EnumerableResponse<AccountSourceCurrencyInqProcessor> SourceCurrencyInquiryDetails { get; set; }
    }
}
