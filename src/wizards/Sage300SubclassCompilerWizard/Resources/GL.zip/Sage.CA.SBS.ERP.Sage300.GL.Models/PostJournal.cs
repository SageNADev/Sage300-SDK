/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class PostJournal.
    /// </summary>
    public partial class PostJournal : ModelBase
    {
        /// <summary>
        /// Gets or sets PostAllBatchesSwitch
        /// </summary>
        /// <value>The post all batches switch.</value>
        [ViewField(Name = Fields.PostAllBatchesSwitch, Id = Index.PostAllBatchesSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public PostAllBatchesSwitch PostAllBatchesSwitch { get; set; }

        /// <summary>
        /// Gets or sets ProvisionalPostSwitch
        /// </summary>
        /// <value>The provisional post switch.</value>
        [ViewField(Name = Fields.ProvisionalPostSwitch, Id = Index.ProvisionalPostSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public ProvisionalPostSwitch ProvisionalPostSwitch { get; set; }

        /// <summary>
        /// Gets or sets FromBatchNumber
        /// </summary>
        /// <value>From batch number.</value>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof (GLCommonResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromBatchNumber, Id = Index.FromBatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string FromBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets ToBatchNumber
        /// </summary>
        /// <value>To batch number.</value>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof (GLCommonResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [ViewField(Name = Fields.ToBatchNumber, Id = Index.ToBatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string ToBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets ErrorBatchCreatedSwitch
        /// </summary>
        /// <value>The error batch created switch.</value>
        [ViewField(Name = Fields.ErrorBatchCreatedSwitch, Id = Index.ErrorBatchCreatedSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public ErrorBatchCreatedSwitch ErrorBatchCreatedSwitch { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="PostJournal"/> is switch.
        /// </summary>
        /// <value><c>true</c> if switch; otherwise, <c>false</c>.</value>
        public bool Switch { get; set; }

        /// <summary>
        /// Allow Provisional Posting
        /// </summary>
        /// <value><c>true</c> if [allow provisional posting]; otherwise, <c>false</c>.</value>
        public bool AllowProvisionalPosting { get; set; }
    }
}
