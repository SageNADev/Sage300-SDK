/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class Recurring Entry Details model
    /// </summary>
    public partial class RecurringEntryDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets for RecurringEntryCode
        /// </summary>
        /// <value>The recurring entry code.</value>
        [Display(Name = "RecurringEntryCode", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.RecurringEntryCode, Id = Index.RecurringEntryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string RecurringEntryCode { get; set; }

        /// <summary>
        /// Gets or sets the sequential line number for the recurring entry detail items
        /// </summary>
        /// <value>The line number.</value>
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets for SequenceNumber
        /// </summary>
        /// <value>The sequence number.</value>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Char, Size = 10, Mask = "%C%09D")]
        public string SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets for AccountNumber
        /// </summary>
        /// <value>The account number.</value>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountNumber", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the Account description
        /// </summary>
        /// <value>The account description.</value>
        [Display(Name = "AccountDescription", ResourceType = typeof(RecurringEntriesResx))]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets for CompanyId
        /// </summary>
        /// <value>The company identifier.</value>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompanyId", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.CompanyId, Id = Index.CompanyId, FieldType = EntityFieldType.Char, Size = 8)]
        public string CompanyId { get; set; }

        /// <summary>
        /// Gets or sets for Amount
        /// </summary>
        /// <value>The amount.</value>
        [Display(Name = "Amount", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? Amount { get; set; }

        /// <summary>
        /// Gets or sets for Quantity
        /// </summary>
        /// <value>The quantity.</value>
        [Display(Name = "Quantity", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets for SourceCurrencyDecimals
        /// </summary>
        /// <value>The source currency decimals.</value>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCurrencyDecimals", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.SourceCurrencyDecimals, Id = Index.SourceCurrencyDecimals, FieldType = EntityFieldType.Char, Size = 1)]
        public string SourceCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets for SourceCurrencyAmount
        /// </summary>
        /// <value>The source currency amount.</value>
        [Display(Name = "SourceCurrencyAmount", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.SourceCurrencyAmount, Id = Index.SourceCurrencyAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceCurrencyAmount { get; set; }

        /// <summary>
        /// Gets or sets for HomeCurrency
        /// </summary>
        /// <value>The home currency.</value>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "HomeCurrency", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.HomeCurrency, Id = Index.HomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets for CurrencyRateTable
        /// </summary>
        /// <value>The currency rate table.</value>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyRateTable", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.CurrencyRateTable, Id = Index.CurrencyRateTable, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CurrencyRateTable { get; set; }

        /// <summary>
        /// Gets or sets for SourceCurrency
        /// </summary>
        /// <value>The source currency.</value>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCurrency", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.SourceCurrency, Id = Index.SourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string SourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets for CurrencyRateDate
        /// </summary>
        /// <value>The currency rate date.</value>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [Display(Name = "CurrencyRateDate", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.CurrencyRateDate, Id = Index.CurrencyRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CurrencyRateDate { get; set; }

        /// <summary>
        /// Gets or sets for CurrencyRate
        /// </summary>
        /// <value>The currency rate.</value>
        [Display(Name = "CurrencyRate", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.CurrencyRate, Id = Index.CurrencyRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CurrencyRate { get; set; }

        /// <summary>
        /// Gets or sets for CurrencyRateSpread
        /// </summary>
        /// <value>The currency rate spread.</value>
        [Display(Name = "CurrencyRateSpread", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.CurrencyRateSpread, Id = Index.CurrencyRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CurrencyRateSpread { get; set; }

        /// <summary>
        /// Gets or sets for CurrencyRateDateMatching
        /// </summary>
        /// <value>The currency rate date matching.</value>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyRateDateMatching", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.CurrencyRateDateMatching, Id = Index.CurrencyRateDateMatching, FieldType = EntityFieldType.Char, Size = 1)]
        public string CurrencyRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets for CurrencyRateOperator
        /// </summary>
        /// <value>The currency rate operator.</value>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyRateOperator", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.CurrencyRateOperator, Id = Index.CurrencyRateOperator, FieldType = EntityFieldType.Char, Size = 1)]
        public string CurrencyRateOperator { get; set; }

        /// <summary>
        /// Gets or sets for Description
        /// </summary>
        /// <value>The description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets for Reference
        /// </summary>
        /// <value>The reference.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets for RecurringEntryDate
        /// </summary>
        /// <value>The recurring entry date.</value>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [Display(Name = "Date", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.RecurringEntryDate, Id = Index.RecurringEntryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RecurringEntryDate { get; set; }

        /// <summary>
        /// Gets or sets for SourceLedger
        /// </summary>
        /// <value>The source ledger.</value>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceLedger", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.SourceLedger, Id = Index.SourceLedger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedger { get; set; }

        /// <summary>
        /// Gets or sets for SourceType
        /// </summary>
        /// <value>The type of the source.</value>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.SourceType, Id = Index.SourceType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType { get; set; }

        /// <summary>
        /// Gets or sets for Comment
        /// </summary>
        /// <value>The comment.</value>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets for ZeroSourceAmountFlag
        /// </summary>
        /// <value>The zero source amount flag.</value>
        [Display(Name = "ZeroSourceAmountFlag", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.ZeroSourceAmountFlag, Id = Index.ZeroSourceAmountFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public long ZeroSourceAmountFlag { get; set; }

        /// <summary>
        /// Gets or sets for OptionalFields
        /// </summary>
        /// <value>The optional fields.</value>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets the Optional Field property to set yes or no
        /// </summary>
        /// <value>The optional fields string.</value>
        public string OptionalFieldsString { get; set; }

        /// <summary>
        /// Gets or sets the positive Source Currency Amount Value
        /// </summary>
        /// <value>The debit amount.</value>
        public decimal DebitAmount { get; set; }

        /// <summary>
        /// Gets or sets the negative Source Currency Amount Value
        /// </summary>
        /// <value>The credit amount.</value>
        public decimal CreditAmount { get; set; }

        /// <summary>
        /// Gets or sets the postitive Trans Amount value
        /// </summary>
        /// <value>The functional debit amount.</value>
        public decimal? FunctionalDebitAmount { get; set; }

        /// <summary>
        /// Gets or sets the negative Trans Amount Value
        /// </summary>
        /// <value>The functional credit amount.</value>
        public decimal? FunctionalCreditAmount { get; set; }

        /// <summary>
        /// Gets or sets if is Quantities Allowed in Account
        /// </summary>
        /// <value>The maintain quantities.</value>
        public Allowed MaintainQuantities { get; set; }

        /// <summary>
        /// Gets or sets if Multicurrency is enabled for the Account
        /// </summary>
        /// <value>The multi currency enabled.</value>
        public Allowed MultiCurrencyEnabled { get; set; }

        /// <summary>
        /// Gets or sets specifc currency of the Account
        /// </summary>
        /// <value>The specific currency.</value>
        public SpecificCurrency SpecificCurrency { get; set; }

        /// <summary>
        /// Gets or sets if Transactional Optional fields set in Account
        /// </summary>
        /// <value>The trans optional fields.</value>
        public long TransOptionalFields { get; set; }

        /// <summary>
        /// Journal Optional fields for journal detail
        /// </summary>
        /// <value>The recurring entry optional fields.</value>
        public EnumerableResponse<RecurringEntryOptionalFields> RecurringEntryOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets DestQtyDecimals 
        /// </summary>
        public decimal DestQtyDecimals { get; set; }

        /// <summary>
        /// Gets or sets UnformattedAccount 
        /// </summary>
        public string UnformattedAccount { get; set; }
    }
}
