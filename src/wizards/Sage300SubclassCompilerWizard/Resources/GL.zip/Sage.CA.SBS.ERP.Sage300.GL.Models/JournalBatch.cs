/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class JournalBatch.
    /// </summary>
    [KnownType(typeof (JournalBatch))]
    public partial class JournalBatch : ModelBase
    {
        /// <summary>
        /// This constructor initializes EnumerableResponses/Lists to be empty, as well as
        /// the key to be an empty string. This avoids the problem of serializing null
        /// collections or objects with a null required property.
        /// </summary>
        public JournalBatch()
        {
            JournalEntry = new JournalEntry
            {
                JournalDetail = new EnumerableResponse<JournalDetail>
                {
                    Items = new List<JournalDetail>()
                }
            };
            JournalEntries = new List<JournalEntry>();

            PostJournal = new PostJournal();

            BatchNumber = string.Empty;
        }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        /// <value>The batch number.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof (GLCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets ActiveSwitch
        /// </summary>
        /// <value>The active switch.</value>
        [ViewField(Name = Fields.ActiveSwitch, Id = Index.ActiveSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public ActiveSwitch ActiveSwitch { get; set; }

        /// <summary>
        /// To get the string of ActiveSwitch property
        /// Added for Finder filter
        /// </summary>
        /// <value>The ActiveSwitch string.</value>
        public string ActiveSwitchString
        {
            get { return EnumUtility.GetStringValue(ActiveSwitch); }
        }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        /// <value>The description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BatchDescription", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets SourceLedger
        /// </summary>
        /// <value>The source ledger.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SourceLedger", ResourceType = typeof (GLCommonResx))]
        [ViewField(Name = Fields.SourceLedger, Id = Index.SourceLedger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedger { get; set; }

        /// <summary>
        /// Gets or sets DateCreated
        /// </summary>
        /// <value>The date created.</value>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Date", ResourceType = typeof(JournalEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "Created", ResourceType = typeof(BatchListResx))]
        [ViewField(Name = Fields.DateCreated, Id = Index.DateCreated, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCreated { get; set; }

        /// <summary>
        /// Gets or sets DateLastEdited
        /// </summary>
        /// <value>The date last edited.</value>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "Edited", ResourceType = typeof(BatchListResx))]
        [ViewField(Name = Fields.DateLastEdited, Id = Index.DateLastEdited, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastEdited { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        /// <value>The type.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Type", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Char, Size = 1)]
        public JournalBatchType Type { get; set; }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string.</value>
        [Display(Name = "Type", ResourceType = typeof(JournalEntryResx))]
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        /// <value>The status.</value>
        [Display(Name = "Status", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Char, Size = 1)]
        public JournalBatchStatus Status { get; set; }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        /// <value>The status string.</value>
        [Display(Name = "Status", ResourceType = typeof(JournalEntryResx))]
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets PostingSequence
        /// </summary>
        /// <value>The posting sequence.</value>
        [Display(Name = "PostingSequence", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal PostingSequence { get; set; }

        /// <summary>
        /// Gets or sets Debits
        /// </summary>
        /// <value>The debits.</value>
        [Display(Name = "DebitsC", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.Debits, Id = Index.Debits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Debits { get; set; }

        /// <summary>
        /// Gets or sets Credits
        /// </summary>
        /// <value>The credits.</value>
        [Display(Name = "CreditsC", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.Credits, Id = Index.Credits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Credits { get; set; }

        /// <summary>
        /// Gets or sets QuantityTotal
        /// </summary>
        /// <value>The quantity total.</value>
        [Display(Name = "QuantityC", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.QuantityTotal, Id = Index.QuantityTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal QuantityTotal { get; set; }

        /// <summary>
        /// Gets or sets NumberofEntries
        /// </summary>
        /// <value>The numberof entries.</value>
        [Display(Name = "EntriesC", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.NumberofEntries, Id = Index.NumberofEntries, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofEntries { get; set; }

        /// <summary>
        /// Gets or sets NextEntryNumber
        /// </summary>
        /// <value>The next entry number.</value>
        [ViewField(Name = Fields.NextEntryNumber, Id = Index.NextEntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NextEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets NoofErrors
        /// </summary>
        /// <value>The noof errors.</value>
        [Display(Name = "NoOfErrors", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.NoofErrors, Id = Index.NoofErrors, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NoofErrors { get; set; }

        /// <summary>
        /// Gets or sets OriginalStatus
        /// </summary>
        /// <value>The original status.</value>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.OriginalStatus, Id = Index.OriginalStatus, FieldType = EntityFieldType.Char, Size = 1)]
        public string OriginalStatus { get; set; }

        /// <summary>
        /// Gets or sets Printed
        /// </summary>
        /// <value>The printed.</value>
        [Display(Name = "Printed", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed Printed { get; set; }

        /// <summary>
        /// To get the string of Printed property
        /// Added for Finder filter
        /// </summary>
        /// <value>The Printed string.</value>
        public string PrintedString
        {
            get { return EnumUtility.GetStringValue(Printed); }
        }

        /// <summary>
        /// Gets or sets ICTRelated
        /// </summary>
        /// <value>The ict related.</value>
        public Printed IctRelated { get; set; }

        /// <summary>
        /// To get the string of IctRelated property
        /// Added for Finder filter
        /// </summary>
        /// <value>The IctRelated string.</value>
        public string IctRelatedString
        {
            get { return EnumUtility.GetStringValue(IctRelated); }
        }

        /// <summary>
        /// Gets or sets RevaluationRecognizedBatch
        /// </summary>
        /// <value>The revaluation recognized batch.</value>
        [ViewField(Name = Fields.RevaluationRecognizedBatch, Id = Index.RevaluationRecognizedBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed RevaluationRecognizedBatch { get; set; }

        /// <summary>
        /// To get the string of RevaluationRecognizedBatch property
        /// Added for Finder filter
        /// </summary>
        /// <value>The RevaluationRecognizedBatch string.</value>
        public string RevaluationRecognizedBatchString
        {
            get { return EnumUtility.GetStringValue(RevaluationRecognizedBatch); }
        }

        /// <summary>
        /// Gets or sets EligibleforEditSwitch
        /// </summary>
        /// <value>The eligiblefor edit switch.</value>
        [ViewField(Name = Fields.EligibleforEditSwitch, Id = Index.EligibleforEditSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed EligibleforEditSwitch { get; set; }

        /// <summary>
        /// To get the string of EligibleforEditSwitch property
        /// Added for Finder filter
        /// </summary>
        /// <value>The EligibleforEditSwitch string.</value>
        public string EligibleforEditSwitchString
        {
            get { return EnumUtility.GetStringValue(EligibleforEditSwitch); }
        }

        /// <summary>
        /// Gets or sets EligibleforDeleteSwitch
        /// </summary>
        /// <value>The eligiblefor delete switch.</value>
        [ViewField(Name = Fields.EligibleforDeleteSwitch, Id = Index.EligibleforDeleteSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed EligibleforDeleteSwitch { get; set; }

        /// <summary>
        /// To get the string of EligibleforDeleteSwitch property
        /// Added for Finder filter
        /// </summary>
        /// <value>The EligibleforDeleteSwitch string.</value>
        public string EligibleforDeleteSwitchString
        {
            get { return EnumUtility.GetStringValue(EligibleforDeleteSwitch); }
        }

        /// <summary>
        /// Gets or sets EligibleforPostingSwitch
        /// </summary>
        /// <value>The eligiblefor posting switch.</value>
        [ViewField(Name = Fields.EligibleforPostingSwitch, Id = Index.EligibleforPostingSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed EligibleforPostingSwitch { get; set; }

        /// <summary>
        /// To get the string of EligibleforPostingSwitch property
        /// Added for Finder filter
        /// </summary>
        /// <value>The EligibleforPostingSwitch string.</value>
        public string EligibleforPostingSwitchString
        {
            get { return EnumUtility.GetStringValue(EligibleforPostingSwitch); }
        }

        /// <summary>
        /// Gets or sets EligibleforPrintingSwitch
        /// </summary>
        /// <value>The eligiblefor printing switch.</value>
        [ViewField(Name = Fields.EligibleforPrintingSwitch, Id = Index.EligibleforPrintingSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed EligibleforPrintingSwitch { get; set; }

        /// <summary>
        /// To get the string of EligibleforPrintingSwitch property
        /// Added for Finder filter
        /// </summary>
        /// <value>The EligibleforPrintingSwitch string.</value>
        public string EligibleforPrintingSwitchString
        {
            get { return EnumUtility.GetStringValue(EligibleforPrintingSwitch); }
        }

        /// <summary>
        /// Gets or sets EligibleforProvPostSwitch
        /// </summary>
        /// <value>The eligiblefor prov post switch.</value>
        [ViewField(Name = Fields.EligibleforProvPostSwitch, Id = Index.EligibleforProvPostSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed EligibleforProvPostSwitch { get; set; }

        /// <summary>
        /// To get the string of EligibleforProvPostSwitch property
        /// Added for Finder filter
        /// </summary>
        /// <value>The EligibleforProvPostSwitch string.</value>
        public string EligibleforProvPostSwitchString
        {
            get { return EnumUtility.GetStringValue(EligibleforProvPostSwitch); }
        }

        /// <summary>
        /// Gets or sets ReadytoPost
        /// </summary>
        /// <value>The readyto post.</value>
        [Display(Name = "ReadyToPost", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.ReadytoPost, Id = Index.ReadytoPost, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed ReadytoPost { get; set; }

        /// <summary>
        /// To get the string of ReadytoPost property
        /// Added for Finder filter
        /// </summary>
        /// <value>The ReadytoPost string.</value>
        public string ReadytoPostString
        {
            get { return EnumUtility.GetStringValue(ReadytoPost); }
        }

        /// <summary>
        /// Gets or sets LockBatchSwitch
        /// </summary>
        /// <value>The lock batch switch.</value>
        [ViewField(Name = Fields.LockBatchSwitch, Id = Index.LockBatchSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public LockBatchSwitch LockBatchSwitch { get; set; }

        /// <summary>
        /// Journal Entries related to the Journal Batch
        /// </summary>
        /// <value>The journal entry.</value>
        [IsMvcSpecific]
        public JournalEntry JournalEntry { get; set; }

        /// <summary>
        /// Journal Entries related to the Journal Batch
        /// </summary>
        /// <value>The journal entries.</value>
        public List<JournalEntry> JournalEntries { get; set; }

        /// <summary>
        /// Entries related to posting a Journal
        /// </summary>
        /// <value>The post journal.</value>
        public PostJournal PostJournal { get; set; }

        /// <summary>
        /// To check for CS Multicurrency
        /// </summary>
        /// <value><c>true</c> if this instance is multi currency; otherwise, <c>false</c>.</value>
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets the Company functional currency
        /// </summary>
        /// <value>The home currency.</value>
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        public short SessionWarnDays { get; set; }

        /// <summary>
        /// NumberOfDecimalsForQty
        /// </summary>
        /// <value>The number of decimals for qty.</value>
        public decimal NumberOfDecimalsForQty { get; set; }

        /// <summary>
        /// Gets or sets IsOptionalFieldLicense
        /// </summary>
        /// <value><c>true</c> if this instance is optional field license; otherwise, <c>false</c>.</value>
        public bool IsOptionalFieldLicense { get; set; }
    }

    /// <summary>
    /// Journal Batch Setup
    /// </summary>
    public class JournalBatchSetup : ModelBase
    {
        /// <summary>
        /// Is Multicurrency
        /// </summary>
        public bool IsMultiCurrency;

        /// <summary>
        /// Is QUantities enabled
        /// </summary>
        public bool HasQuantities;

        /// <summary>
        /// Has Optional Field license
        /// </summary>
        public bool HasOptionalFields;

        /// <summary>
        /// Batch Will not be editable in case GL option has a setup value of "NoEdit"
        /// </summary>
        public bool ImportedBatchNotEditable { get; set; }
    }
}
