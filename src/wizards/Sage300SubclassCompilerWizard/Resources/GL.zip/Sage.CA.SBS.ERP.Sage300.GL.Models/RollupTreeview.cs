﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.Collections.Generic;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class RollupTreeview.
    /// </summary>
    public class RollupTreeview
    {
        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>The parent identifier.</value>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the rollups.
        /// </summary>
        /// <value>The rollups.</value>
        public List<RollupTreeview> Rollups { get; set; }

        /// <summary>
        /// hasChildren
        /// </summary>
        public bool hasChildren { get; set; }
    }
}