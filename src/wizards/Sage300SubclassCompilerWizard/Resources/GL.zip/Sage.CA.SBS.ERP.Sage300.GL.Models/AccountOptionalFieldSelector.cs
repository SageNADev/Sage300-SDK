﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class AccountOptionalFieldSelector.
    /// </summary>
    public class AccountOptionalFieldSelector
    {
        /// <summary>
        /// Gets or Sets OptionalField
        /// </summary>
        /// <value>The serial number.</value>
        public int SerialNumber { get; set; }

        /// <summary>
        /// Gets or Sets OptionalField
        /// </summary>
        /// <value>The optional field.</value>
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        /// <value>The type.</value>
        public Type Type { get; set; }

        /// <summary>
        /// Gets or Sets To
        /// </summary>
        /// <value>From.</value>
        public string From { get; set; }

        /// <summary>
        /// Gets or Sets To
        /// </summary>
        /// <value>To.</value>
        public string To { get; set; }
    }
}