/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Account Fiscal Sets class.
    /// </summary>
    public partial class AccountFiscalSets : ModelBase
    {
        /// <summary>
        /// This constructor initializes keys to be empty strings. This avoids the
        /// problem of serializing objects with a null required property.
        /// </summary>
        public AccountFiscalSets()
        {
            AccountNumber = string.Empty;
            FiscalSetYear = string.Empty;
            CurrencyCode = string.Empty;
        }

        /// <summary>
        /// Gets or sets AccountNumber.
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets FiscalSetYear.
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.FiscalSetYear, Id = Index.FiscalSetYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalSetYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalSetDesignator.
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.FiscalSetDesignator, Id = Index.FiscalSetDesignator, FieldType = EntityFieldType.Char, Size = 1)]
        public AccountFiscalSetDesignator FiscalSetDesignator { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode.
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyType.
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.CurrencyType, Id = Index.CurrencyType, FieldType = EntityFieldType.Char, Size = 1)]
        public AccountFiscalSetCurrencyType CurrencyType { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrencyDecimals.
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SourceCurrencyDecimals, Id = Index.SourceCurrencyDecimals, FieldType = EntityFieldType.Char, Size = 1)]
        public string SourceCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets BeginningBalance.
        /// </summary>
        [ViewField(Name = Fields.BeginningBalance, Id = Index.BeginningBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningBalance { get; set; }

        /// <summary>
        /// Gets or sets Period01NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period01NetAmount, Id = Index.Period01NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period01NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period02NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period02NetAmount, Id = Index.Period02NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period02NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period03NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period03NetAmount, Id = Index.Period03NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period03NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period04NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period04NetAmount, Id = Index.Period04NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period04NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period05NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period05NetAmount, Id = Index.Period05NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period05NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period06NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period06NetAmount, Id = Index.Period06NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period06NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period07NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period07NetAmount, Id = Index.Period07NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period07NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period08NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period08NetAmount, Id = Index.Period08NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period08NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period09NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period09NetAmount, Id = Index.Period09NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period09NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period10NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period10NetAmount, Id = Index.Period10NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period10NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period11NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period11NetAmount, Id = Index.Period11NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period11NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period12NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period12NetAmount, Id = Index.Period12NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period12NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period13NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period13NetAmount, Id = Index.Period13NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period13NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period14NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period14NetAmount, Id = Index.Period14NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period14NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Period15NetAmount.
        /// </summary>
        [ViewField(Name = Fields.Period15NetAmount, Id = Index.Period15NetAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period15NetAmount { get; set; }

        /// <summary>
        /// Gets or sets ActivitySwitch.
        /// </summary>
        [ViewField(Name = Fields.ActivitySwitch, Id = Index.ActivitySwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public ActivitySwitch ActivitySwitch { get; set; }
    }
}
