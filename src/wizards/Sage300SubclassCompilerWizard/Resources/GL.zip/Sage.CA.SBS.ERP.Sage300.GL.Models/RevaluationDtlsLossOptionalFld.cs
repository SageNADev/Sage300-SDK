// Copyright © 2016 Sage Software, Inc.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using optfieldsenum = Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.OptionalFields;

using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for RevaluationDtlsLossOptionalFld
    /// </summary>
    public partial class RevaluationDtlsLossOptionalFld : ModelBase
    {
        /// <summary>
        /// Gets or sets CurrencycodeTorevalue
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencycodeTorevalue", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.CurrencycodeTorevalue, Id = Index.CurrencycodeTorevalue, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencycodeTorevalue { get; set; }

        /// <summary>
        /// Gets or sets Defaultrevaluationcode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Defaultrevaluationcode", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.Defaultrevaluationcode, Id = Index.Defaultrevaluationcode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Defaultrevaluationcode { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Value
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Value", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public optfieldsenum.FieldType Type { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public optfieldsenum.YesNo AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public optfieldsenum.YesNo Validate { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public optfieldsenum.ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets TypedValueFieldIndex
        /// </summary>
        [Display(Name = "TypedValueFieldIndex", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets TextValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TextValue", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string TextValue { get; set; }

        /// <summary>
        /// Gets or sets AmountValue
        /// </summary>
        [Display(Name = "AmountValue", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountValue { get; set; }

        /// <summary>
        /// Gets or sets NumberValue
        /// </summary>
        [Display(Name = "NumberValue", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NumberValue { get; set; }

        /// <summary>
        /// Gets or sets IntegerValue
        /// </summary>
        [Display(Name = "IntegerValue", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long IntegerValue { get; set; }

        /// <summary>
        /// Gets or sets YesNoValue
        /// </summary>
        [Display(Name = "YesNoValue", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.YesNoValue, Id = Index.YesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public optfieldsenum.YesNo YesNoValue { get; set; }

        /// <summary>
        /// Gets or sets DateValue
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateValue", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateValue { get; set; }

        /// <summary>
        /// Gets or sets TimeValue
        /// </summary>
        [Display(Name = "TimeValue", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime? TimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ValueDescription", ResourceType = typeof (RevaluationDtlsLossOptionalFldResx))]
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Type string value
        /// </summary>
        public string TypeString
        {
         get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets AllowBlank string value
        /// </summary>
        public string AllowBlankString
        {
         get { return EnumUtility.GetStringValue(AllowBlank); }
        }

        /// <summary>
        /// Gets Validate string value
        /// </summary>
        public string ValidateString
        {
         get { return EnumUtility.GetStringValue(Validate); }
        }
        
        /// <summary>
        /// Gets ValueSet string value
        /// </summary>
        public string ValueSetString
        {
            get { return (ValueSet == optfieldsenum.ValueSet.Yes) ? "Yes" : "No"; }
        }
        
        /// <summary>
        /// Gets YesNoValue string value
        /// </summary>
        public string YesNoValueString
        {
         get { return EnumUtility.GetStringValue(YesNoValue); }
        }

        #endregion

        /// <summary>
        /// Gets or sets the serial number.
        /// </summary>
        /// <value>
        /// The serial number.
        /// </value>
        public string SerialNumber { get; set; }
    }
}
