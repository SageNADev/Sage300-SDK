// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for UserAccountPermission
    /// </summary>
    public partial class UserAccountPermission : ModelBase
    {
        /// <summary>
        /// Gets or sets UserID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets LineNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNo", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.LineNo, Id = Index.LineNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineNo { get; set; }

        /// <summary>
        /// Gets or sets Allow
        /// </summary>
        [Display(Name = "Allow", ResourceType = typeof (AccountPermissionsResx))]
        [ViewField(Name = Fields.Allow, Id = Index.Allow, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowPermission Allow { get; set; }

        /// <summary>
        /// Gets or sets FromAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromAccount", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.FromAccount, Id = Index.FromAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string FromAccount { get; set; }

        /// <summary>
        /// Gets or sets ToAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToAccount", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.ToAccount, Id = Index.ToAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ToAccount { get; set; }

        /// <summary>
        /// Gets or sets FormattedFromAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedFromAccount", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.FormattedFromAccount, Id = Index.FormattedFromAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string FormattedFromAccount { get; set; }

        /// <summary>
        /// Gets or sets FormattedToAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedToAccount", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.FormattedToAccount, Id = Index.FormattedToAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string FormattedToAccount { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Allow string value
        /// </summary>
        public string AllowString
        {
            get { return EnumUtility.GetStringValue(Allow); }
        }

        #endregion
    }
}
