// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.GL.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for Accounts
    /// </summary>
    public partial class FRAccount : ModelBase
    {
        /// <summary>
        /// Gets or sets UnformattedAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedAccount", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.UnformattedAccount, Id = Index.UnformattedAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnformattedAccount { get; set; }

        /// <summary>
        /// Gets or sets DateCreated
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateCreated", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.DateCreated, Id = Index.DateCreated, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCreated { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Char, Size = 1)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Type Type { get; set; }

        /// <summary>
        /// Gets or sets NormalBalanceDRCR
        /// </summary>
        [Display(Name = "NormalBalanceDRCR", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.NormalBalanceDRCR, Id = Index.NormalBalanceDRCR, FieldType = EntityFieldType.Char, Size = 1)]
        public int NormalBalanceDRCR { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Status Status { get; set; }

        /// <summary>
        /// Gets or sets PostToAccount
        /// </summary>
        [Display(Name = "PostToAccount", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.PostToAccount, Id = Index.PostToAccount, FieldType = EntityFieldType.Int, Size = 2)]
        public int PostToAccount { get; set; }

        /// <summary>
        /// Gets or sets QuantitiesAllowed
        /// </summary>
        [Display(Name = "QuantitiesAllowed", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.QuantitiesAllowed, Id = Index.QuantitiesAllowed, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.QuantitiesAllowed QuantitiesAllowed { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 6)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets AllocationsAllowed
        /// </summary>
        [Display(Name = "AllocationsAllowed", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AllocationsAllowed, Id = Index.AllocationsAllowed, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.AllocationsAllowed AllocationsAllowed { get; set; }

        /// <summary>
        /// Gets or sets AllocOffsetAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocOffsetAccount", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AllocOffsetAccount, Id = Index.AllocOffsetAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AllocOffsetAccount { get; set; }

        /// <summary>
        /// Gets or sets AllocSourceType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocSourceType", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AllocSourceType, Id = Index.AllocSourceType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string AllocSourceType { get; set; }

        /// <summary>
        /// Gets or sets Rollup
        /// </summary>
        [Display(Name = "Rollup", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.Rollup, Id = Index.Rollup, FieldType = EntityFieldType.Int, Size = 2)]
        public int Rollup { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.Multicurrency, Id = Index.Multicurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public int Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets SpecificCurrency
        /// </summary>
        [Display(Name = "SpecificCurrency", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.SpecificCurrency, Id = Index.SpecificCurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.SpecificCurrency SpecificCurrency { get; set; }

        /// <summary>
        /// Gets or sets AccountGroupCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountGroupCode", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountGroupCode, Id = Index.AccountGroupCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AccountGroupCode { get; set; }

        /// <summary>
        /// Gets or sets ControlAccount
        /// </summary>
        [Display(Name = "ControlAccount", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.ControlAccount, Id = Index.ControlAccount, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.ControlAccount ControlAccount { get; set; }

        /// <summary>
        /// Gets or sets Reserved
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reserved", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.Reserved, Id = Index.Reserved, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string Reserved { get; set; }

        /// <summary>
        /// Gets or sets AllocationPercentTotal
        /// </summary>
        [Display(Name = "AllocationPercentTotal", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AllocationPercentTotal, Id = Index.AllocationPercentTotal, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal AllocationPercentTotal { get; set; }

        /// <summary>
        /// Gets or sets StructureCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StructureCode", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.StructureCode, Id = Index.StructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StructureCode { get; set; }

        /// <summary>
        /// Gets or sets YearLastClosed
        /// </summary>
        [Display(Name = "YearLastClosed", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.YearLastClosed, Id = Index.YearLastClosed, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal YearLastClosed { get; set; }

        /// <summary>
        /// Gets or sets AccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountNumber", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45)]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode1", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode1, Id = Index.AccountSegmentCode1, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode1 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode2", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode2, Id = Index.AccountSegmentCode2, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode2 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode3", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode3, Id = Index.AccountSegmentCode3, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode3 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode4", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode4, Id = Index.AccountSegmentCode4, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode4 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode5", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode5, Id = Index.AccountSegmentCode5, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode5 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode6", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode6, Id = Index.AccountSegmentCode6, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode6 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode7
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode7", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode7, Id = Index.AccountSegmentCode7, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode7 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode8
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode8", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode8, Id = Index.AccountSegmentCode8, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode8 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode9
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode9", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode9, Id = Index.AccountSegmentCode9, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode9 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode10
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode10", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode10, Id = Index.AccountSegmentCode10, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode10 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentCode", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.SegmentCode, Id = Index.SegmentCode, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode { get; set; }

        /// <summary>
        /// Gets or sets AccountGroupSortCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountGroupSortCode", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountGroupSortCode, Id = Index.AccountGroupSortCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AccountGroupSortCode { get; set; }

        /// <summary>
        /// Gets or sets PostToSegmentID
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostToSegmentID", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.PostToSegmentID, Id = Index.PostToSegmentID, FieldType = EntityFieldType.Char, Size = 6)]
        public string PostToSegmentID { get; set; }

        /// <summary>
        /// Gets or sets DefaultCurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultCurrencyCode", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.DefaultCurrencyCode, Id = Index.DefaultCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string DefaultCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCurrencyCode", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.SourceCurrencyCode, Id = Index.SourceCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string SourceCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets SourceLedgerCode
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceLedgerCode", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.SourceLedgerCode, Id = Index.SourceLedgerCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedgerCode { get; set; }

        /// <summary>
        /// Gets or sets SourceTypeCode
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceTypeCode", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.SourceTypeCode, Id = Index.SourceTypeCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceTypeCode { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNumber
        /// </summary>
        [Display(Name = "PostingSequenceNumber", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.PostingSequenceNumber, Id = Index.PostingSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal PostingSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailCount
        /// </summary>
        [Display(Name = "DetailCount", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.DetailCount, Id = Index.DetailCount, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal DetailCount { get; set; }

        /// <summary>
        /// Gets or sets JournalDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "JournalDate", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.JournalDate, Id = Index.JournalDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime JournalDate { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets JournalEntryNumber
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "JournalEntryNumber", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.JournalEntryNumber, Id = Index.JournalEntryNumber, FieldType = EntityFieldType.Char, Size = 5, Mask = "%05D")]
        public string JournalEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets JournalTransactionNumber
        /// </summary>
        [Display(Name = "JournalTransactionNumber", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.JournalTransactionNumber, Id = Index.JournalTransactionNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal JournalTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets ConsolidationOccurredOnPost
        /// </summary>
        [ViewField(Name = Fields.ConsolidationOccurredOnPost, Id = Index.ConsolidationOccurredOnPost, FieldType = EntityFieldType.Int, Size = 2)]
        public int ConsolidationOccurredOnPost { get; set; }

        /// <summary>
        /// Gets or sets JournalDetailDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "JournalDetailDescription", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.JournalDetailDescription, Id = Index.JournalDetailDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string JournalDetailDescription { get; set; }

        /// <summary>
        /// Gets or sets JournalDetailReference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "JournalDetailReference", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.JournalDetailReference, Id = Index.JournalDetailReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string JournalDetailReference { get; set; }

        /// <summary>
        /// Gets or sets JournalTransactionAmount
        /// </summary>
        [Display(Name = "JournalTransactionAmount", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.JournalTransactionAmount, Id = Index.JournalTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal JournalTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets JournalTransactionQuantity
        /// </summary>
        [Display(Name = "JournalTransactionQuantity", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.JournalTransactionQuantity, Id = Index.JournalTransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal JournalTransactionQuantity { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrencyAmount
        /// </summary>
        [Display(Name = "SourceCurrencyAmount", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.SourceCurrencyAmount, Id = Index.SourceCurrencyAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceCurrencyAmount { get; set; }

        /// <summary>
        /// Gets or sets ReportCurrencyAmount
        /// </summary>
        [Display(Name = "ReportCurrencyAmount", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.ReportCurrencyAmount, Id = Index.ReportCurrencyAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReportCurrencyAmount { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateTableType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyRateTableType", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.CurrencyRateTableType, Id = Index.CurrencyRateTableType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CurrencyRateTableType { get; set; }

        /// <summary>
        /// Gets or sets DateOfCurrencyRateSelected
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateOfCurrencyRateSelected", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.DateOfCurrencyRateSelected, Id = Index.DateOfCurrencyRateSelected, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateOfCurrencyRateSelected { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateForConversion
        /// </summary>
        [Display(Name = "CurrencyRateForConversion", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.CurrencyRateForConversion, Id = Index.CurrencyRateForConversion, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CurrencyRateForConversion { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateOperator
        /// </summary>
        [Display(Name = "CurrencyRateOperator", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.CurrencyRateOperator, Id = Index.CurrencyRateOperator, FieldType = EntityFieldType.Char, Size = 1)]
        public int CurrencyRateOperator { get; set; }

        /// <summary>
        /// Gets or sets NumberOfGlpostoRecords
        /// </summary>
        [Display(Name = "NumberOfGlpostoRecords", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.NumberOfGlpostoRecords, Id = Index.NumberOfGlpostoRecords, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfGlpostoRecords { get; set; }

        /// <summary>
        /// Gets or sets TotalAccountOptionalFields
        /// </summary>
        [Display(Name = "TotalAccountOptionalFields", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.TotalAccountOptionalFields, Id = Index.TotalAccountOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int TotalAccountOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets TotalTransactionOptionalFields
        /// </summary>
        [Display(Name = "TotalTransactionOptionalFields", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.TotalTransactionOptionalFields, Id = Index.TotalTransactionOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int TotalTransactionOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets TableSwitch
        /// </summary>
        [Display(Name = "TableSwitch", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.TableSwitch, Id = Index.TableSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int TableSwitch { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [StringLength(14, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 14)]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldLocation
        /// </summary>
        [Display(Name = "OptionalFieldLocation", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.OptionalFieldLocation, Id = Index.OptionalFieldLocation, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.OptionalFieldLocation OptionalFieldLocation { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDesc", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.OptionalFieldDesc, Id = Index.OptionalFieldDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDesc { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Type string value
        /// </summary>
        public string TypeString
        {
         get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
         get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets QuantitiesAllowed string value
        /// </summary>
        public string QuantitiesAllowedString
        {
         get { return EnumUtility.GetStringValue(QuantitiesAllowed); }
        }

        /// <summary>
        /// Gets AllocationsAllowed string value
        /// </summary>
        public string AllocationsAllowedString
        {
         get { return EnumUtility.GetStringValue(AllocationsAllowed); }
        }

        /// <summary>
        /// Gets SpecificCurrency string value
        /// </summary>
        public string SpecificCurrencyString
        {
         get { return EnumUtility.GetStringValue(SpecificCurrency); }
        }

        /// <summary>
        /// Gets ControlAccount string value
        /// </summary>
        public string ControlAccountString
        {
         get { return EnumUtility.GetStringValue(ControlAccount); }
        }

        /// <summary>
        /// Gets OptionalFieldLocation string value
        /// </summary>
        public string OptionalFieldLocationString
        {
         get { return EnumUtility.GetStringValue(OptionalFieldLocation); }
        }

        #endregion
    }
}
