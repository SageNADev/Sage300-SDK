/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.GL.Models.CustomDataAnnotations;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class AccountStructure
    /// </summary>
    public partial class AccountStructure : ModelBase
    {
        /// <summary>
        /// Gets or Sets Structure Code
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StructureCode", ResourceType = typeof(AccountStructuresResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceType = typeof(AnnotationsResx),
            ErrorMessageResourceName = "AlphaNumeric")]
        [Key]
        [ViewField(Name = Fields.StructureCode, Id = Index.StructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StructureCode { get; set; }

        /// <summary>
        /// Gets or Sets Description
        /// </summary>
        [Display(Name = "StructureCodeDescription", ResourceType = typeof(AccountStructuresResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Selected Account Segments data from the database with respect to the account structure
        /// </summary>
        [ValidateListCount]
        [Display(Name = "SelectedAccountSegments", ResourceType = typeof(AccountStructuresResx))]
        public IEnumerable<AccountSegments> SelectedAccountSegments { get; set; }

        /// <summary>
        /// Gets or Sets Segment Number1
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber1", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.SegmentNumber1, Id = Index.SegmentNumber1, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber1 { get; set; }

        /// <summary>
        /// Gets or Sets Segment1 Starting Position
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment1StartingPosition", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment1StartingPosition, Id = Index.Segment1StartingPosition, FieldType = EntityFieldType.Char, Size = 2)]
        public string Segment1StartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment1 Length 
        /// </summary>
        [Display(Name = "Segment1Length", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment1Length, Id = Index.Segment1Length, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Segment1Length { get; set; }

        /// <summary>
        /// RESERVEDAcctseg1validationseq
        /// </summary>
        public string RESERVEDAcctseg1validationseq { get; set; }

        /// <summary>
        /// Gets or Sets Segment Number2 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber2", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.SegmentNumber2, Id = Index.SegmentNumber2, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber2 { get; set; }

        /// <summary>
        /// Gets or Sets Segment2 Starting Position 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment2StartingPosition", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment2StartingPosition, Id = Index.Segment2StartingPosition, FieldType = EntityFieldType.Char, Size = 2)]
        public string Segment2StartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment2 Length 
        /// </summary>
        [Display(Name = "Segment2Length", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment2Length, Id = Index.Segment2Length, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Segment2Length { get; set; }

        /// <summary>
        /// Gets or Sets Segment Number3 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber3", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.SegmentNumber3, Id = Index.SegmentNumber3, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber3 { get; set; }

        /// <summary>
        /// RESERVEDAcctseg2validationseq
        /// </summary>
        public string RESERVEDAcctseg2validationseq { get; set; }

        /// <summary>
        /// Gets or Sets Segment3 Starting Position 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment3StartingPosition", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment3StartingPosition, Id = Index.Segment3StartingPosition, FieldType = EntityFieldType.Char, Size = 2)]
        public string Segment3StartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment3 Length 
        /// </summary>
        [Display(Name = "Segment3Length", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment3Length, Id = Index.Segment3Length, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Segment3Length { get; set; }
        /// <summary>
        /// RESERVEDAcctseg3validationseq
        /// </summary>
        public string RESERVEDAcctseg3validationseq { get; set; }

        /// <summary>
        /// Gets or Sets Segment Number4 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber4", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.SegmentNumber4, Id = Index.SegmentNumber4, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber4 { get; set; }

        /// <summary>
        /// Gets or Sets Segment4 Starting Position 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment4StartingPosition", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment4StartingPosition, Id = Index.Segment4StartingPosition, FieldType = EntityFieldType.Char, Size = 2)]
        public string Segment4StartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment4 Length 
        /// </summary>
        [Display(Name = "Segment4Length", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment4Length, Id = Index.Segment4Length, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Segment4Length { get; set; }

        /// <summary>
        /// RESERVEDAcctseg4validationseq
        /// </summary>
        public string RESERVEDAcctseg4validationseq { get; set; }

        /// <summary>
        /// Gets or Sets Segment Number5 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber5", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.SegmentNumber5, Id = Index.SegmentNumber5, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber5 { get; set; }

        /// <summary>
        /// Gets or Sets Segment5 Starting Position 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment5StartingPosition", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment5StartingPosition, Id = Index.Segment5StartingPosition, FieldType = EntityFieldType.Char, Size = 2)]
        public string Segment5StartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment5 Length 
        /// </summary>
        [Display(Name = "Segment5Length", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment5Length, Id = Index.Segment5Length, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Segment5Length { get; set; }

        /// <summary>
        /// RESERVEDAcctseg5validationseq
        /// </summary>
        public string RESERVEDAcctseg5validationseq { get; set; }

        /// <summary>
        /// Gets or Sets Segment Number6 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber6", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.SegmentNumber6, Id = Index.SegmentNumber6, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber6 { get; set; }

        /// <summary>
        /// Gets or Sets Segment6 Starting Position 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment6StartingPosition", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment6StartingPosition, Id = Index.Segment6StartingPosition, FieldType = EntityFieldType.Char, Size = 2)]
        public string Segment6StartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment6 Length
        /// </summary>
        [Display(Name = "Segment6Length", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment6Length, Id = Index.Segment6Length, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Segment6Length { get; set; }

        /// <summary>
        /// RESERVEDAcctseg6validationseq
        /// </summary>
        public string RESERVEDAcctseg6validationseq { get; set; }

        /// <summary>
        /// Gets or Sets Segment Number7 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber7", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.SegmentNumber7, Id = Index.SegmentNumber7, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber7 { get; set; }

        /// <summary>
        /// Gets or Sets Segment7 Starting Position 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment7StartingPosition", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment7StartingPosition, Id = Index.Segment7StartingPosition, FieldType = EntityFieldType.Char, Size = 2)]
        public string Segment7StartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment7 Length 
        /// </summary>
        [Display(Name = "Segment7Length", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment7Length, Id = Index.Segment7Length, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Segment7Length { get; set; }

        /// <summary>
        /// RESERVEDAcctseg7validationseq
        /// </summary>
        public string RESERVEDAcctseg7validationseq { get; set; }

        /// <summary>
        /// Gets or Sets Segment Number8 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber8", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.SegmentNumber8, Id = Index.SegmentNumber8, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber8 { get; set; }

        /// <summary>
        /// Gets or Sets Segment8 Starting Position 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment8StartingPosition", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment8StartingPosition, Id = Index.Segment8StartingPosition, FieldType = EntityFieldType.Char, Size = 2)]
        public string Segment8StartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment8 Length 
        /// </summary>
        [Display(Name = "Segment8Length", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment8Length, Id = Index.Segment8Length, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Segment8Length { get; set; }

        /// <summary>
        /// RESERVEDAcctseg8validationseq
        /// </summary>
        public string RESERVEDAcctseg8validationseq { get; set; }

        /// <summary>
        /// Gets or Sets Segment Number9
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber9", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.SegmentNumber9, Id = Index.SegmentNumber9, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber9 { get; set; }

        /// <summary>
        /// Gets or Sets Segment9 Starting Position
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment9StartingPosition", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment9StartingPosition, Id = Index.Segment9StartingPosition, FieldType = EntityFieldType.Char, Size = 2)]
        public string Segment9StartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment9 Length 
        /// </summary>
        [Display(Name = "Segment9Length", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment9Length, Id = Index.Segment9Length, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Segment9Length { get; set; }

        /// <summary>
        /// RESERVEDAcctseg9validationseq
        /// </summary>
        public string RESERVEDAcctseg9validationseq { get; set; }

        /// <summary>
        /// Gets or Sets Segment Number10 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber10", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.SegmentNumber10, Id = Index.SegmentNumber10, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber10 { get; set; }

        /// <summary>
        /// Gets or Sets Segment10 Starting Position
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment10StartingPosition", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment10StartingPosition, Id = Index.Segment10StartingPosition, FieldType = EntityFieldType.Char, Size = 2)]
        public string Segment10StartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment10 Length 
        /// </summary>
        [Display(Name = "Segment10Length", ResourceType = typeof(AccountStructuresResx))]
        [ViewField(Name = Fields.Segment10Length, Id = Index.Segment10Length, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Segment10Length { get; set; }

        /// <summary>
        /// RESERVEDAcctseg10validationseq
        /// </summary>
        public string RESERVEDAcctseg10validationseq { get; set; }

        /// <summary>
        /// Gets or Sets DefaultStructureCode
        /// </summary>
        public bool IsDefaultStructureCode { get; set; }

        /// <summary>
        /// Gets or Sets Default Structure Code of Options
        /// </summary>
        public string DefaultStructureCode { get; set; }

        /// <summary>
        ///  Gets or Sets check
        /// </summary>
        public bool check { get; set; }
    }
}
