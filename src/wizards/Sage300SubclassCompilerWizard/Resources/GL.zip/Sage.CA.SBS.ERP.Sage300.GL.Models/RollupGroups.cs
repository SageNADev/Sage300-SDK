/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class RollupGroups : ModelBase
    {
        /// <summary>
        /// Constructor for intializing Enum Values
        /// </summary>
        public RollupGroups()
        {
            Add = Allowed.No;
            IntegrityCheckSwitch = Allowed.No;
            MemberAccountRollupSwitch = Allowed.No;
            MemberAccountType = AccountType.BalanceSheet;
            MemberMulticurrency = Allowed.No;
            MemberNormalBalanceDrorCr = NormalBalanceDrorCr.Debit;
            MemberPosttoAccount = PosttoAccount.Detail;
            MemberStatus = Status.Inactive;
        }

        /// <summary>
        /// Gets or sets RollupAccount 
        /// </summary>
        [Key]
        [Display(Name = "RollupAccount", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.RollupAccount, Id = Index.RollupAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RollupAccount { get; set; }

        /// <summary>
        /// Gets or sets MemberAccount 
        /// </summary>
        [Display(Name = "MemberAccount", ResourceType = typeof(AccountsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.MemberAccount, Id = Index.MemberAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string MemberAccount { get; set; }

        /// <summary>
        /// Gets or sets processMode 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ProcessMode, Id = Index.ProcessMode, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProcessMode { get; set; }

        /// <summary>
        /// Gets or sets Hasglachdurecords? 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Hasglachdurecords, Id = Index.Hasglachdurecords, FieldType = EntityFieldType.Int, Size = 2)]
        public int? Hasglachdurecords { get; set; }

        /// <summary>
        /// Gets or sets FormattedMemberAccount 
        /// </summary>
        // [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedMemberAccount", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.FormattedMemberAccount, Id = Index.FormattedMemberAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string FormattedMemberAccount { get; set; }

        /// <summary>
        /// Gets or sets MemberAccountDescription 
        /// </summary>
        //[StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.MemberAccountDescription, Id = Index.MemberAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string MemberAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets FormattedRollupAccount 
        /// </summary>
        //[StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedRollupAccount", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.FormattedRollupAccount, Id = Index.FormattedRollupAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string FormattedRollupAccount { get; set; }

        /// <summary>
        /// Gets or sets MemberAccountRollupSwitch 
        /// </summary>         
        [Display(Name = "Rollup", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.MemberAccountRollupSwitch, Id = Index.MemberAccountRollupSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public Allowed MemberAccountRollupSwitch { get; set; }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        [Display(Name = "Rollup", ResourceType = typeof(AccountsResx))]
        public string MemberAccountRollupSwitchString
        {
            get { return EnumUtility.GetStringValue(MemberAccountRollupSwitch); }
        }

        /// <summary>
        /// Gets or sets MemberAccountType 
        /// </summary>         
        [Display(Name = "AccountType", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.MemberAccountType, Id = Index.MemberAccountType, FieldType = EntityFieldType.Char, Size = 1)]
        public AccountType MemberAccountType { get; set; }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        [Display(Name = "AccountType", ResourceType = typeof(AccountsResx))]
        public string MemberAccountTypeString
        {
            get { return EnumUtility.GetStringValue(MemberAccountType); }
        }

        /// <summary>
        /// Gets or sets MemberAccountGroup 
        /// </summary>
        //[StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountGroup", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.MemberAccountGroup, Id = Index.MemberAccountGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string MemberAccountGroup { get; set; }

        /// <summary>
        /// Gets or sets IntegrityCheckSwitch 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.IntegrityCheckSwitch, Id = Index.IntegrityCheckSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public Allowed IntegrityCheckSwitch { get; set; }

        /// <summary>
        /// Gets or sets IntegrityCheckErrorCount 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.IntegrityCheckErrorCount, Id = Index.IntegrityCheckErrorCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int IntegrityCheckErrorCount { get; set; }

        /// <summary>
        /// Gets or sets MemberNormalBalanceDROrCR 
        /// </summary>
        [Display(Name = "NormalBalanceDrorCr", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.MemberNormalBalanceDrorCr, Id = Index.MemberNormalBalanceDrorCr, FieldType = EntityFieldType.Char, Size = 1)]
        public NormalBalanceDrorCr MemberNormalBalanceDrorCr { get; set; }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        [Display(Name = "NormalBalanceDrorCr", ResourceType = typeof(AccountsResx))]
        public string MemberNormalBalanceDrOrCrString
        {
            get { return EnumUtility.GetStringValue(MemberNormalBalanceDrorCr); }
        }

        /// <summary>
        /// Gets or sets MemberStatus 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.MemberStatus, Id = Index.MemberStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Status MemberStatus { get; set; }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(AccountsResx))]
        public string MemberStatusString
        {
            get { return EnumUtility.GetStringValue(MemberStatus); }
        }

        /// <summary>
        /// Gets or sets MemberPosttoAccount 
        /// </summary>
        [Display(Name = "PostToAccount", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.MemberPosttoAccount, Id = Index.MemberPosttoAccount, FieldType = EntityFieldType.Int, Size = 2)]
        public PosttoAccount MemberPosttoAccount { get; set; }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        [Display(Name = "PostToAccount", ResourceType = typeof(AccountsResx))]
        public string MemberPosttoAccountString
        {
            get { return EnumUtility.GetStringValue(MemberPosttoAccount); }
        }

        /// <summary>
        /// Gets or sets MemberMulticurrency 
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.MemberMulticurrency, Id = Index.MemberMulticurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public Allowed MemberMulticurrency { get; set; }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof(AccountsResx))]
        public string MemberMulticurrencyString
        {
            get { return EnumUtility.GetStringValue(MemberMulticurrency); }
        }

        /// <summary>
        /// Gets or sets ProcessSwitch 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ProcessSwitch, Id = Index.ProcessSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProcessSwitch { get; set; }

        /// <summary>
        /// Gets or sets Add - Account Rollup preview selector Screen
        /// </summary>         
        public Allowed Add { get; set; }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        public long SerialNumber { get; set; }
    }
}
