// Copyright (c) 2020 Sage  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.GL.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for AccountBudgetCalculator
    /// </summary>
    public partial class AccountBudgetCalculator : ModelBase
    {
        /// <summary>
        /// Gets or sets BudgetMethodCode
        /// </summary>
        [Display(Name = "BudgetMethodCode", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.BudgetMethodCode, Id = Index.BudgetMethodCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.BudgetMethodCode BudgetMethodCode { get; set; }

        /// <summary>
        /// Gets or sets InputAmount
        /// </summary>
        [Display(Name = "InputAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.InputAmount, Id = Index.InputAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InputAmount { get; set; }

        /// <summary>
        /// Gets or sets InputIncreaseAmount
        /// </summary>
        [Display(Name = "InputIncreaseAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.InputIncreaseAmount, Id = Index.InputIncreaseAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InputIncreaseAmount { get; set; }

        /// <summary>
        /// Gets or sets InputIncreasePercent
        /// </summary>
        [Display(Name = "InputIncreasePercent", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.InputIncreasePercent, Id = Index.InputIncreasePercent, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal InputIncreasePercent { get; set; }

        /// <summary>
        /// Gets or sets PeriodStart
        /// </summary>
        [Display(Name = "PeriodStart", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.PeriodStart, Id = Index.PeriodStart, FieldType = EntityFieldType.Int, Size = 2)]
        public short PeriodStart { get; set; }

        /// <summary>
        /// Gets or sets PeriodEnd
        /// </summary>
        [Display(Name = "PeriodEnd", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.PeriodEnd, Id = Index.PeriodEnd, FieldType = EntityFieldType.Int, Size = 2)]
        public short PeriodEnd { get; set; }

        /// <summary>
        /// Gets or sets TypeOfUpdate
        /// </summary>
        [Display(Name = "TypeOfUpdate", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.TypeOfUpdate, Id = Index.TypeOfUpdate, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.TypeOfUpdate TypeOfUpdate { get; set; }

        /// <summary>
        /// Gets or sets Period01InquiryAmount
        /// </summary>
        [Display(Name = "Period01InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period01InquiryAmount, Id = Index.Period01InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period01InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period02InquiryAmount
        /// </summary>
        [Display(Name = "Period02InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period02InquiryAmount, Id = Index.Period02InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period02InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period03InquiryAmount
        /// </summary>
        [Display(Name = "Period03InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period03InquiryAmount, Id = Index.Period03InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period03InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period04InquiryAmount
        /// </summary>
        [Display(Name = "Period04InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period04InquiryAmount, Id = Index.Period04InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period04InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period05InquiryAmount
        /// </summary>
        [Display(Name = "Period05InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period05InquiryAmount, Id = Index.Period05InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period05InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period06InquiryAmount
        /// </summary>
        [Display(Name = "Period06InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period06InquiryAmount, Id = Index.Period06InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period06InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period07InquiryAmount
        /// </summary>
        [Display(Name = "Period07InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period07InquiryAmount, Id = Index.Period07InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period07InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period08InquiryAmount
        /// </summary>
        [Display(Name = "Period08InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period08InquiryAmount, Id = Index.Period08InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period08InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period09InquiryAmount
        /// </summary>
        [Display(Name = "Period09InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period09InquiryAmount, Id = Index.Period09InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period09InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period10InquiryAmount
        /// </summary>
        [Display(Name = "Period10InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period10InquiryAmount, Id = Index.Period10InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period10InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period11InquiryAmount
        /// </summary>
        [Display(Name = "Period11InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period11InquiryAmount, Id = Index.Period11InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period11InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period12InquiryAmount
        /// </summary>
        [Display(Name = "Period12InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period12InquiryAmount, Id = Index.Period12InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period12InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period13InquiryAmount
        /// </summary>
        [Display(Name = "Period13InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period13InquiryAmount, Id = Index.Period13InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period13InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period14InquiryAmount
        /// </summary>
        [Display(Name = "Period14InquiryAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period14InquiryAmount, Id = Index.Period14InquiryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period14InquiryAmount { get; set; }

        /// <summary>
        /// Gets or sets Period01WorkAmount
        /// </summary>
        [Display(Name = "Period01WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period01WorkAmount, Id = Index.Period01WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period01WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period02WorkAmount
        /// </summary>
        [Display(Name = "Period02WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period02WorkAmount, Id = Index.Period02WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period02WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period03WorkAmount
        /// </summary>
        [Display(Name = "Period03WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period03WorkAmount, Id = Index.Period03WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period03WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period04WorkAmount
        /// </summary>
        [Display(Name = "Period04WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period04WorkAmount, Id = Index.Period04WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period04WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period05WorkAmount
        /// </summary>
        [Display(Name = "Period05WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period05WorkAmount, Id = Index.Period05WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period05WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period06WorkAmount
        /// </summary>
        [Display(Name = "Period06WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period06WorkAmount, Id = Index.Period06WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period06WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period07WorkAmount
        /// </summary>
        [Display(Name = "Period07WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period07WorkAmount, Id = Index.Period07WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period07WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period08WorkAmount
        /// </summary>
        [Display(Name = "Period08WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period08WorkAmount, Id = Index.Period08WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period08WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period09WorkAmount
        /// </summary>
        [Display(Name = "Period09WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period09WorkAmount, Id = Index.Period09WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period09WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period10WorkAmount
        /// </summary>
        [Display(Name = "Period10WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period10WorkAmount, Id = Index.Period10WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period10WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period11WorkAmount
        /// </summary>
        [Display(Name = "Period11WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period11WorkAmount, Id = Index.Period11WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period11WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period12WorkAmount
        /// </summary>
        [Display(Name = "Period12WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period12WorkAmount, Id = Index.Period12WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period12WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period13WorkAmount
        /// </summary>
        [Display(Name = "Period13WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period13WorkAmount, Id = Index.Period13WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period13WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets Period14WorkAmount
        /// </summary>
        [Display(Name = "Period14WorkAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.Period14WorkAmount, Id = Index.Period14WorkAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period14WorkAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalAmount
        /// </summary>
        [Display(Name = "TotalAmount", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.TotalAmount, Id = Index.TotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAmount { get; set; }

        /// <summary>
        /// Gets or sets BudgetCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof (AccountBudgetCalculatorResx))]
        [ViewField(Name = Fields.BudgetCurrency, Id = Index.BudgetCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BudgetCurrency { get; set; }

        [Display(Name = "Account", ResourceType = typeof(AccountsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        public string AccountNumber { get; set; }

        [Display(Name = "Account", ResourceType = typeof(AccountsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        public string FSAccountNumber { get; set; }
        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(AccountsResx))]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(AccountsResx))]
        public string FSDescription { get; set; }

        [Display(Name = "BudgetSet", ResourceType = typeof(AccountBudgetCalculatorResx))]
        public FiscalSetDesignator BudgetSet { get; set; }

        [Display(Name = "Year", ResourceType = typeof(AccountBudgetCalculatorResx))]
        public string FiscalSetYear { get; set; }

        [Display(Name = "Year", ResourceType = typeof(AccountBudgetCalculatorResx))]
        public string Year { get; set; }

        public bool IsMulticurrency { get; set; }

        [Display(Name = "Currency", ResourceType = typeof(AccountBudgetCalculatorResx))]
        public string DefaultCurrencyCode { get; set; }

        public int FunctionalDecimals { get; set; }

        [Display(Name = "CurrencyType", ResourceType = typeof(AccountBudgetCalculatorResx))]
        public FiscalSetCurrencyType BudgetCurrencyType { get; set; }

        [Display(Name = "FiscalSet", ResourceType = typeof(AccountBudgetCalculatorResx))]
        public FiscalSetDesignator FiscalSet { get; set; }

        [Display(Name = "Currency", ResourceType = typeof(AccountBudgetCalculatorResx))]
        public string FiscalSetCurrencyCode { get; set; }

        [Display(Name = "CurrencyType", ResourceType = typeof(AccountBudgetCalculatorResx))]
        public FiscalSetCurrencyType FiscalSetCurrencyType { get; set; }

        public bool UseRolledUpAmounts { get; set; }

        [Display(Name = "TotalInquiryAmount", ResourceType = typeof(AccountBudgetCalculatorResx))]
        public decimal TotalInquiryAmount { get; set; }

        [Display(Name = "TotalBudgetAmount", ResourceType = typeof(AccountBudgetCalculatorResx))]
        public decimal TotalBudgetAmount { get; set; }

        public bool IsRollUpAccount { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets BudgetMethodCode string value
        /// </summary>
        public string BudgetMethodCodeString
        {
         get { return EnumUtility.GetStringValue(BudgetMethodCode); }
        }

        /// <summary>
        /// Gets TypeOfUpdate string value
        /// </summary>
        public string TypeOfUpdateString
        {
         get { return EnumUtility.GetStringValue(TypeOfUpdate); }
        }

        #endregion
    }
}
