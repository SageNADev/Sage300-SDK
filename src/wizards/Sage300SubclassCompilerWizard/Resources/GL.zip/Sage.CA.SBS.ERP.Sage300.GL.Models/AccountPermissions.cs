// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for User
    /// </summary>
    public partial class AccountPermissions : ModelBase
    {
        public AccountPermissions()
        {
            SegmentPermissionDetails = new EnumerableResponse<UserSegmentPermission>();
            AccountPermissionDetails = new EnumerableResponse<UserAccountPermission>();
        }

        /// <summary>
        /// Gets or sets UserID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof (AccountPermissionsResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets HasRestrictionRecordsSwitch
        /// </summary>
        [Display(Name = "HasRestrictionRecordsSwitch", ResourceType = typeof (AccountPermissionsResx))]
        [ViewField(Name = Fields.HasRestrictionRecordsSwitch, Id = Index.HasRestrictionRecordsSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public HasRestrictionRecordsSwitch HasRestrictionRecordsSwitch { get; set; }

        /// <summary>
        /// Gets or sets UserName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserName", ResourceType = typeof (AccountPermissionsResx))]
        [ViewField(Name = Fields.UserName, Id = Index.UserName, FieldType = EntityFieldType.Char, Size = 60)]
        public string UserName { get; set; }

        /// <summary>
        /// Gets and sets SegmentPermissionDetails
        /// </summary>
        public EnumerableResponse<UserSegmentPermission> SegmentPermissionDetails { get; set; }

        /// <summary>
        /// Gets and sets AccountPermissionDetails
        /// </summary>
        public EnumerableResponse<UserAccountPermission> AccountPermissionDetails { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets HasRestrictionRecordsSwitch string value
        /// </summary>
        [Display(Name = "HasRestrictionRecordsSwitch", ResourceType = typeof(AccountPermissionsResx))]
        public string HasRestrictionRecordsSwitchString
        {
            get { return EnumUtility.GetStringValue(HasRestrictionRecordsSwitch); }
        }

        #endregion
    }
}
