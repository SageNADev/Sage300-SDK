// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for PreviewAccount
    /// </summary>
    public partial class PreviewAccount : ModelBase
    {
        /// <summary>
        /// Gets or sets UnformattedAccount
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedAccount", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.UnformattedAccount, Id = Index.UnformattedAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnformattedAccount { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessingDescription", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Char, Size = 1)]
        public PreviewAccountType Type { get; set; }

        /// <summary>
        /// Gets or sets NormalBalanceDebitOrCredit
        /// </summary>
        [Display(Name = "NormalBalance", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.NormalBalanceDebitOrCredit, Id = Index.NormalBalanceDebitOrCredit, FieldType = EntityFieldType.Char, Size = 1)]
        public NormalBalanceDebitOrCredit NormalBalanceDebitOrCredit { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Status Status { get; set; }

        /// <summary>
        /// Gets or sets ConsolidateJournals
        /// </summary>
        [Display(Name = "ConsolidatedJournals", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.ConsolidateJournals, Id = Index.ConsolidateJournals, FieldType = EntityFieldType.Int, Size = 2)]
        public ConsolidateJournals ConsolidateJournals { get; set; }

        /// <summary>
        /// Gets or sets QuantitiesAllowed
        /// </summary>
        [Display(Name = "QuantitiesAllowed", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.QuantitiesAllowed, Id = Index.QuantitiesAllowed, FieldType = EntityFieldType.Int, Size = 2)]
        public QuantitiesAllowed QuantitiesAllowed { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 6)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets AllocationsAllowed
        /// </summary>
        [Display(Name = "AllocationsAllowed", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AllocationsAllowed, Id = Index.AllocationsAllowed, FieldType = EntityFieldType.Int, Size = 2)]
        public int AllocationsAllowed { get; set; }

        /// <summary>
        /// Gets or sets AllocOffsetAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocOffsetAccount", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AllocOffsetAccount, Id = Index.AllocOffsetAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string AllocOffsetAccount { get; set; }

        /// <summary>
        /// Gets or sets AllocSourceType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocSourceType", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AllocSourceType, Id = Index.AllocSourceType, FieldType = EntityFieldType.Char, Size = 2)]
        public string AllocSourceType { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Multicurrency, Id = Index.Multicurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public Multicurrency Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets SpecificCurrency
        /// </summary>
        [Display(Name = "SpecificCurrency", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.SpecificCurrency, Id = Index.SpecificCurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public SpecificCurrency SpecificCurrency { get; set; }

        /// <summary>
        /// Gets or sets AccountGroupCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountGroupCode", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountGroupCode, Id = Index.AccountGroupCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AccountGroupCode { get; set; }

        /// <summary>
        /// Gets or sets ControlAccount
        /// </summary>
        [Display(Name = "ControlAccount", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.ControlAccount, Id = Index.ControlAccount, FieldType = EntityFieldType.Int, Size = 2)]
        public ControlAccount ControlAccount { get; set; }

        /// <summary>
        /// Gets or sets Reserved
        /// </summary>
        [Display(Name = "Reserved", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.Reserved, Id = Index.Reserved, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string Reserved { get; set; }

        /// <summary>
        /// Gets or sets AllocationPercentTotal
        /// </summary>
        [Display(Name = "AllocationPercentTotal", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AllocationPercentTotal, Id = Index.AllocationPercentTotal, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal AllocationPercentTotal { get; set; }

        /// <summary>
        /// Gets or sets StructureCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StructureCode", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.StructureCode, Id = Index.StructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StructureCode { get; set; }

        /// <summary>
        /// Gets or sets YearLastClosed
        /// </summary>
        [Display(Name = "YearLastClosed", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.YearLastClosed, Id = Index.YearLastClosed, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal YearLastClosed { get; set; }

        /// <summary>
        /// Gets or sets AccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountNumber", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45)]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode1", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountSegmentCode1, Id = Index.AccountSegmentCode1, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode1 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode2", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountSegmentCode2, Id = Index.AccountSegmentCode2, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode2 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode3", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountSegmentCode3, Id = Index.AccountSegmentCode3, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode3 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode4", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountSegmentCode4, Id = Index.AccountSegmentCode4, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode4 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode5", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountSegmentCode5, Id = Index.AccountSegmentCode5, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode5 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode6", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountSegmentCode6, Id = Index.AccountSegmentCode6, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode6 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode7
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode7", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountSegmentCode7, Id = Index.AccountSegmentCode7, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode7 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode8
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode8", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountSegmentCode8, Id = Index.AccountSegmentCode8, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode8 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode9
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode9", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountSegmentCode9, Id = Index.AccountSegmentCode9, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode9 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode10
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSegmentCode10", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountSegmentCode10, Id = Index.AccountSegmentCode10, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode10 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentCode", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.SegmentCode, Id = Index.SegmentCode, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode { get; set; }

        /// <summary>
        /// Gets or sets AccountGroupSortCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountGroupSortCode", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.AccountGroupSortCode, Id = Index.AccountGroupSortCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AccountGroupSortCode { get; set; }

        /// <summary>
        /// Gets or sets PostToSegmentId
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PosttoSegmentID", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.PostToSegmentId, Id = Index.PostToSegmentId, FieldType = EntityFieldType.Char, Size = 6)]
        public string PostToSegmentId { get; set; }

        /// <summary>
        /// Gets or sets PostToSegmentIdCopy
        /// </summary>
        [Display(Name = "PosttoSegmentIDCopy", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.PostToSegmentIdCopy, Id = Index.PostToSegmentIdCopy, FieldType = EntityFieldType.Int, Size = 2)]
        public PostToSegmentIdCopy PostToSegmentIdCopy { get; set; }

        /// <summary>
        /// Gets or sets DefaultCurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultCurrencyCode", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.DefaultCurrencyCode, Id = Index.DefaultCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string DefaultCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets ProcessSwitch
        /// </summary>
        [Display(Name = "ProcessSwitch", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.ProcessSwitch, Id = Index.ProcessSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public PreviewAccountProcessSwitch ProcessSwitch { get; set; }

        /// <summary>
        /// Gets or sets CreateSwitch
        /// </summary>
        [Display(Name = "CreateSwitch", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.CreateSwitch, Id = Index.CreateSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateSwitch CreateSwitch { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets TransactionOptionalFields
        /// </summary>
        [Display(Name = "TransOptionalFields", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.TransactionOptionalFields, Id = Index.TransactionOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets the ValidCurrencies
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<PreviewAccountValidCurrency> ValidCurrencies { get; set; }

        /// <summary>
        /// Gets or sets AccountSubledgers
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<PreviewControlAccountSubledger> AccountSubledgers { get; set; }

        /// <summary>
        /// Gets or sets AccountOptionalFields
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<AccountOptionalField> AccountOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets AccountTransOptionalFields
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<AccountTransOptionalField> AccountTransOptionalFields { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Type string value
        /// </summary>
        [IgnoreExportImport]
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets NormalBalanceDebitOrCredit string value
        /// </summary>
        [IgnoreExportImport]
        public string NormalBalanceDebitOrCreditString
        {
            get { return EnumUtility.GetStringValue(NormalBalanceDebitOrCredit); }
        }

        /// <summary>
        /// Gets Status string value
        /// </summary>
        [IgnoreExportImport]
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets ConsolidateJournals string value
        /// </summary>
        [IgnoreExportImport]
        public string ConsolidateJournalsString
        {
            get { return EnumUtility.GetStringValue(ConsolidateJournals); }
        }

        /// <summary>
        /// Gets QuantitiesAllowed string value
        /// </summary>
        [IgnoreExportImport]
        public string QuantitiesAllowedString
        {
            get { return EnumUtility.GetStringValue(QuantitiesAllowed); }
        }

        /// <summary>
        /// Gets Multicurrency string value
        /// </summary>
        [IgnoreExportImport]
        public string MulticurrencyString
        {
            get { return EnumUtility.GetStringValue(Multicurrency); }
        }

        /// <summary>
        /// Gets SpecificCurrency string value
        /// </summary>
        [IgnoreExportImport]
        public string SpecificCurrencyString
        {
            get { return EnumUtility.GetStringValue(SpecificCurrency); }
        }

        /// <summary>
        /// Gets ControlAccount string value
        /// </summary>
        [IgnoreExportImport]
        public string ControlAccountString
        {
            get { return EnumUtility.GetStringValue(ControlAccount); }
        }

        /// <summary>
        /// Gets PostToSegmentIdCopy string value
        /// </summary>
        [IgnoreExportImport]
        public string PostToSegmentIdCopyString
        {
            get { return EnumUtility.GetStringValue(PostToSegmentIdCopy); }
        }

        /// <summary>
        /// Gets ProcessSwitch string value
        /// </summary>
        [IgnoreExportImport]
        public string ProcessSwitchString
        {
            get { return EnumUtility.GetStringValue(ProcessSwitch); }
        }

        /// <summary>
        /// Gets CreateSwitch string value
        /// </summary>
        [IgnoreExportImport]
        public string CreateSwitchString
        {
            get { return EnumUtility.GetStringValue(CreateSwitch); }
        }

        #endregion
    }
}
