/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

//using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class CreateReverseEntry.
    /// </summary>
    public partial class CreateReverseEntry : ModelBase
    {
        /// <summary>
        /// Gets or sets OptionSwitch
        /// </summary>
        /// <value>The option switch.</value>
        [ViewField(Name = Fields.OptionSwitch, Id = Index.OptionSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public OptionSwitch OptionSwitch { get; set; }

        /// <summary>
        /// Gets or sets SelectedBatchId
        /// </summary>
        /// <value>The selected batch identifier.</value>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof (GLCommonResx))]
        [ViewField(Name = Fields.SelectedBatchId, Id = Index.SelectedBatchId, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string SelectedBatchId { get; set; }

        /// <summary>
        /// Gets or sets SelectedEntry
        /// </summary>
        /// <value>The selected entry.</value>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.SelectedEntry, Id = Index.SelectedEntry, FieldType = EntityFieldType.Char, Size = 5, Mask = "%05D")]
        public string SelectedEntry { get; set; }

        /// <summary>
        /// Gets or sets NewReverseBatchSourceLedger
        /// </summary>
        /// <value>The new reverse batch source ledger.</value>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SourceLedger", ResourceType = typeof (GLCommonResx))]
        [ViewField(Name = Fields.NewReverseBatchSourceLedger, Id = Index.NewReverseBatchSourceLedger, FieldType = EntityFieldType.Char, Size = 2)]
        public string NewReverseBatchSourceLedger { get; set; }

        /// <summary>
        /// Gets or sets NewReverseBatchType
        /// </summary>
        /// <value>The new type of the reverse batch.</value>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Type", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.NewReverseBatchType, Id = Index.NewReverseBatchType, FieldType = EntityFieldType.Char, Size = 1)]
        public string NewReverseBatchType { get; set; }

        /// <summary>
        /// Gets or sets ReverseBatchId
        /// </summary>
        /// <value>The reverse batch identifier.</value>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof (GLCommonResx))]
        [ViewField(Name = Fields.ReverseBatchId, Id = Index.ReverseBatchId, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string ReverseBatchId { get; set; }

        /// <summary>
        /// Gets or sets ReverseBatchDescription
        /// </summary>
        /// <value>The reverse batch description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BatchDescription", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.ReverseBatchDescription, Id = Index.ReverseBatchDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReverseBatchDescription { get; set; }

        /// <summary>
        /// Gets or sets ReverseEntryDescription
        /// </summary>
        /// <value>The reverse entry description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "EntryDescription", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.ReverseEntryDescription, Id = Index.ReverseEntryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReverseEntryDescription { get; set; }

        /// <summary>
        /// Gets or sets CreatedReverseEntryNo
        /// </summary>
        /// <value>The created reverse entry no.</value>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CreatedReverseEntryNo", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.CreatedReverseEntryNo, Id = Index.CreatedReverseEntryNo, FieldType = EntityFieldType.Char, Size = 5, Mask = "%05D")]
        public string CreatedReverseEntryNo { get; set; }

        /// <summary>
        /// Gets or sets EntryYear
        /// </summary>
        /// <value>The entry year.</value>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "EntryYear", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.EntryYear, Id = Index.EntryYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string EntryYear { get; set; }

        /// <summary>
        /// Gets or sets EntryPeriod
        /// </summary>
        /// <value>The entry period.</value>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "EntryPeriod", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.EntryPeriod, Id = Index.EntryPeriod, FieldType = EntityFieldType.Char, Size = 2)]
        public string EntryPeriod { get; set; }

        /// <summary>
        /// Gets or sets AutoReversal
        /// </summary>
        /// <value>The automatic reversal.</value>
        [ViewField(Name = Fields.AutoReversal, Id = Index.AutoReversal, FieldType = EntityFieldType.Int, Size = 2)]
        public int AutoReversal { get; set; }

        /// <summary>
        /// Gets or sets SpecificReversalYear
        /// </summary>
        /// <value>The specific reversal year.</value>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SpecificReversalYear", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.SpecificReversalYear, Id = Index.SpecificReversalYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string SpecificReversalYear { get; set; }

        /// <summary>
        /// Gets or sets SpecificReversalPeriod
        /// </summary>
        /// <value>The specific reversal period.</value>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SpecificReversalPeriod", ResourceType = typeof (JournalEntryResx))]
        [ViewField(Name = Fields.SpecificReversalPeriod, Id = Index.SpecificReversalPeriod, FieldType = EntityFieldType.Char, Size = 2)]
        public string SpecificReversalPeriod { get; set; }

        /// <summary>
        /// Gets or sets JournalDescriptionOption
        /// </summary>
        /// <value>The journal description option.</value>
        [ViewField(Name = Fields.JournalDescriptionOption, Id = Index.JournalDescriptionOption, FieldType = EntityFieldType.Int, Size = 2)]
        public JournalDescriptionOption JournalDescriptionOption { get; set; }

        /// <summary>
        /// Gets or sets Reverse Mode
        /// </summary>
        /// <value>The reverse mode.</value>
        public ReverseMode ReverseMode { get; set; }

        /// <summary>
        /// Gets or sets Original With Prefix
        /// </summary>
        /// <value>The original with prefix.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OriginalWithPrefix", ResourceType = typeof (JournalEntryResx))]
        public string OriginalWithPrefix { get; set; }

        /// <summary>
        /// Gets or sets New Description
        /// </summary>
        /// <value>The new description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "NewDescription", ResourceType = typeof (JournalEntryResx))]
        public string NewDescription { get; set; }

        /// <summary>
        /// Get or sets IsProcessDone
        /// </summary>
        /// <value><c>true</c> if this instance is process done; otherwise, <c>false</c>.</value>
        public bool IsProcessDone { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; set; }
    }
}
