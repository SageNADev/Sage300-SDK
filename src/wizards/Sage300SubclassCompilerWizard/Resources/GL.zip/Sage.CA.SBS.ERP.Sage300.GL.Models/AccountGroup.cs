/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Account Groups class
    /// </summary>
    public partial class AccountGroup : ModelBase
    {
        /// <summary>
        /// This constructor initializes the key to be an empty string.
        /// This avoids the problem of serializing an object with a null required property.
        /// </summary>
        public AccountGroup()
        {
            AccountGroupCode = string.Empty;
        }

        /// <summary>
        /// Account Group Code
        /// </summary>
        [Display(Name = "AccountGroupCode", ResourceType = typeof(AccountGroupsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.AccountGroupCode, Id = Index.AccountGroupCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AccountGroupCode { get; set; }

        /// <summary>
        /// Account Group Description
        /// </summary>
        [Display(Name = "AccountGroupDescription", ResourceType = typeof(AccountGroupsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AccountGroupDescription, Id = Index.AccountGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string AccountGroupDescription { get; set; }

        /// <summary>
        /// Account Group Sort Code
        /// </summary>
        [Display(Name = "AccountGroupSortCode", ResourceType = typeof(AccountGroupsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AccountGroupSortCode, Id = Index.AccountGroupSortCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AccountGroupSortCode { get; set; }

        /// <summary>
        /// Group Category
        /// </summary>
        [Display(Name = "GroupCategory", ResourceType = typeof(AccountGroupsResx))]
        [ViewField(Name = Fields.GroupCategory, Id = Index.GroupCategory, FieldType = EntityFieldType.Int, Size = 2)]
        public GroupCategory GroupCategory { get; set; }

        /// <summary>
        /// Gets or sets groupcategory
        /// </summary>
        public string GroupCategoryString
        {
            get { return EnumUtility.GetStringValue(GroupCategory); }
        }
    }
}
