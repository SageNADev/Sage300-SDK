// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for CreateAccountInputCriteria
    /// </summary>
    public partial class CreateAccountInputCriteria : ModelBase
    {
        /// <summary>
        /// Gets or sets Key
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Key, Id = Index.Key, FieldType = EntityFieldType.Int, Size = 2)]
        public int Key { get; set; }

        /// <summary>
        /// Gets or sets State
        /// </summary>
        [ViewField(Name = Fields.State, Id = Index.State, FieldType = EntityFieldType.Int, Size = 2)]
        public int State { get; set; }

        /// <summary>
        /// Gets or sets totalrecords
        /// </summary>
        [ViewField(Name = Fields.TotalRecords, Id = Index.TotalRecords, FieldType = EntityFieldType.Long, Size = 4)]
        public long TotalRecords { get; set; }

        /// <summary>
        /// Gets or sets FromAccountsWithStructureCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromAccountsWithStructureCode, Id = Index.FromAccountsWithStructureCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string FromAccountsWithStructureCode { get; set; }

        /// <summary>
        /// Gets or sets CreateUsingStructureCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreateUsingStructureCode, Id = Index.CreateUsingStructureCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string CreateUsingStructureCode { get; set; }

        /// <summary>
        /// Gets or sets SelectBy
        /// </summary>
        [ViewField(Name = Fields.SelectBy, Id = Index.SelectBy, FieldType = EntityFieldType.Int, Size = 2)]
        public int SelectBy { get; set; }

        /// <summary>
        /// Gets or sets FromAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromAccountNumber, Id = Index.FromAccountNumber, FieldType = EntityFieldType.Char, Size = 45)]
        public string FromAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets ToAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToAccountNumber, Id = Index.ToAccountNumber, FieldType = EntityFieldType.Char, Size = 45)]
        public string ToAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets FromAccountGroupCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromAccountGroupCode, Id = Index.FromAccountGroupCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string FromAccountGroupCode { get; set; }

        /// <summary>
        /// Gets or sets ToAccountGroupCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToAccountGroupCode, Id = Index.ToAccountGroupCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string ToAccountGroupCode { get; set; }

        /// <summary>
        /// Gets or sets FromAccountGroupSortCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromAccountGroupSortCode, Id = Index.FromAccountGroupSortCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string FromAccountGroupSortCode { get; set; }

        /// <summary>
        /// Gets or sets ToAccountGroupSortCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToAccountGroupSortCode, Id = Index.ToAccountGroupSortCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string ToAccountGroupSortCode { get; set; }

        /// <summary>
        /// Gets or sets SegmentId
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SegmentId, Id = Index.SegmentId, FieldType = EntityFieldType.Char, Size = 6)]
        public string SegmentId { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SegmentCode, Id = Index.SegmentCode, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode { get; set; }

        /// <summary>
        /// Gets or sets DefaultSubledgerDetails
        /// </summary>
        [ViewField(Name = Fields.DefaultSubledgerDetails, Id = Index.DefaultSubledgerDetails, FieldType = EntityFieldType.Int, Size = 2)]
        public bool DefaultSubledgerDetails { get; set; }

        /// <summary>
        /// Gets or sets DefaultCurrencyOptions
        /// </summary>
        [ViewField(Name = Fields.DefaultCurrencyOptions, Id = Index.DefaultCurrencyOptions, FieldType = EntityFieldType.Int, Size = 2)]
        public bool DefaultCurrencyOptions { get; set; }

        /// <summary>
        /// Gets or sets IncludeExistingAccounts
        /// </summary>
        [ViewField(Name = Fields.IncludeExistingAccounts, Id = Index.IncludeExistingAccounts, FieldType = EntityFieldType.Int, Size = 2)]
        public bool IncludeExistingAccounts { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment1
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment1, Id = Index.CreateNewForSegment1, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreateNewForSegment1 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment1, Id = Index.FromSegment1, FieldType = EntityFieldType.Char, Size = 15)]
        public string FromSegment1 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment1, Id = Index.ToSegment1, FieldType = EntityFieldType.Char, Size = 15)]
        public string ToSegment1 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment1, Id = Index.DefaultOptionFromSegment1, FieldType = EntityFieldType.Char, Size = 15)]
        public string DefaultOptionFromSegment1 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment2
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment2, Id = Index.CreateNewForSegment2, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreateNewForSegment2 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment2, Id = Index.FromSegment2, FieldType = EntityFieldType.Char, Size = 15)]
        public string FromSegment2 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment2, Id = Index.ToSegment2, FieldType = EntityFieldType.Char, Size = 15)]
        public string ToSegment2 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment2, Id = Index.DefaultOptionFromSegment2, FieldType = EntityFieldType.Char, Size = 15)]
        public string DefaultOptionFromSegment2 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment3
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment3, Id = Index.CreateNewForSegment3, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreateNewForSegment3 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment3, Id = Index.FromSegment3, FieldType = EntityFieldType.Char, Size = 15)]
        public string FromSegment3 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment3, Id = Index.ToSegment3, FieldType = EntityFieldType.Char, Size = 15)]
        public string ToSegment3 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment3, Id = Index.DefaultOptionFromSegment3, FieldType = EntityFieldType.Char, Size = 15)]
        public string DefaultOptionFromSegment3 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment4
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment4, Id = Index.CreateNewForSegment4, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreateNewForSegment4 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment4, Id = Index.FromSegment4, FieldType = EntityFieldType.Char, Size = 15)]
        public string FromSegment4 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment4, Id = Index.ToSegment4, FieldType = EntityFieldType.Char, Size = 15)]
        public string ToSegment4 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment4, Id = Index.DefaultOptionFromSegment4, FieldType = EntityFieldType.Char, Size = 15)]
        public string DefaultOptionFromSegment4 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment5
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment5, Id = Index.CreateNewForSegment5, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreateNewForSegment5 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment5, Id = Index.FromSegment5, FieldType = EntityFieldType.Char, Size = 15)]
        public string FromSegment5 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment5, Id = Index.ToSegment5, FieldType = EntityFieldType.Char, Size = 15)]
        public string ToSegment5 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment5, Id = Index.DefaultOptionFromSegment5, FieldType = EntityFieldType.Char, Size = 15)]
        public string DefaultOptionFromSegment5 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment6
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment6, Id = Index.CreateNewForSegment6, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreateNewForSegment6 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment6, Id = Index.FromSegment6, FieldType = EntityFieldType.Char, Size = 15)]
        public string FromSegment6 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment6, Id = Index.ToSegment6, FieldType = EntityFieldType.Char, Size = 15)]
        public string ToSegment6 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment6, Id = Index.DefaultOptionFromSegment6, FieldType = EntityFieldType.Char, Size = 15)]
        public string DefaultOptionFromSegment6 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment7
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment7, Id = Index.CreateNewForSegment7, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreateNewForSegment7 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment7
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment7, Id = Index.FromSegment7, FieldType = EntityFieldType.Char, Size = 15)]
        public string FromSegment7 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment7
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment7, Id = Index.ToSegment7, FieldType = EntityFieldType.Char, Size = 15)]
        public string ToSegment7 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment7
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment7, Id = Index.DefaultOptionFromSegment7, FieldType = EntityFieldType.Char, Size = 15)]
        public string DefaultOptionFromSegment7 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment8
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment8, Id = Index.CreateNewForSegment8, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreateNewForSegment8 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment8
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment8, Id = Index.FromSegment8, FieldType = EntityFieldType.Char, Size = 15)]
        public string FromSegment8 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment8
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment8, Id = Index.ToSegment8, FieldType = EntityFieldType.Char, Size = 15)]
        public string ToSegment8 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment8
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment8, Id = Index.DefaultOptionFromSegment8, FieldType = EntityFieldType.Char, Size = 15)]
        public string DefaultOptionFromSegment8 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment9
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment9, Id = Index.CreateNewForSegment9, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreateNewForSegment9 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment9
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment9, Id = Index.FromSegment9, FieldType = EntityFieldType.Char, Size = 15)]
        public string FromSegment9 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment9
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment9, Id = Index.ToSegment9, FieldType = EntityFieldType.Char, Size = 15)]
        public string ToSegment9 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment9
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment9, Id = Index.DefaultOptionFromSegment9, FieldType = EntityFieldType.Char, Size = 15)]
        public string DefaultOptionFromSegment9 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment10
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment10, Id = Index.CreateNewForSegment10, FieldType = EntityFieldType.Int, Size = 2)]
        public int CreateNewForSegment10 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment10
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment10, Id = Index.FromSegment10, FieldType = EntityFieldType.Char, Size = 15)]
        public string FromSegment10 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment10
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment10, Id = Index.ToSegment10, FieldType = EntityFieldType.Char, Size = 15)]
        public string ToSegment10 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment10
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment10, Id = Index.DefaultOptionFromSegment10, FieldType = EntityFieldType.Char, Size = 15)]
        public string DefaultOptionFromSegment10 { get; set; }

        /// <summary>
        /// Gets or sets SegmentOrderOftheSelectedAccount
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SegmentOrderOftheSelectedAccount, Id = Index.SegmentOrderOftheSelectedAccount, FieldType = EntityFieldType.Char, Size = 20)]
        public string SegmentOrderOftheSelectedAccount { get; set; }

        /// <summary>
        /// Gets or sets SegmentOrderOftheCreatedAccount
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SegmentOrderOftheCreatedAccount, Id = Index.SegmentOrderOftheCreatedAccount, FieldType = EntityFieldType.Char, Size = 20)]
        public string SegmentOrderOftheCreatedAccount { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber - Unique key for grid rows
        /// </summary>
        [IgnoreExportImport]
        [IsMvcSpecific]
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber - Unique key for grid rows
        /// </summary>
        [IgnoreExportImport]
        [IsMvcSpecific]
        public bool IsStructureChanged { get; set; }

        #region UI Strings

        #endregion
    }
}
