// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for UserSegmentPermission
    /// </summary>
    public partial class UserSegmentPermission : ModelBase
    {
        /// <summary>
        /// Gets or sets UserID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets LineNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNo", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.LineNo, Id = Index.LineNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineNo { get; set; }

        /// <summary>
        /// Gets or sets Allow
        /// </summary>
        [Display(Name = "Allow", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.Allow, Id = Index.Allow, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowPermission Allow { get; set; }

        /// <summary>
        /// Gets or sets Segment
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.Segment, Id = Index.Segment, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string Segment { get; set; }

        /// <summary>
        /// Gets or sets FromSegment
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromSegment", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.FromSegment, Id = Index.FromSegment, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15C")]
        public string FromSegment { get; set; }

        /// <summary>
        /// Gets or sets ToSegment
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToSegment", ResourceType = typeof(AccountPermissionsResx))]
        [ViewField(Name = Fields.ToSegment, Id = Index.ToSegment, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15C")]
        public string ToSegment { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Allow string value
        /// </summary>
        public string AllowString
        {
            get { return EnumUtility.GetStringValue(Allow); }
        }

        #endregion
    }
}
