﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class representing the segment details of account structure
    /// </summary>
    public class Segment
    {
        /// <summary>
        /// Gets or Sets SegmentNumber
        /// </summary>
        public string SegmentNumber { get; set; }

        /// <summary>
        /// Gets or Sets Segment Starting Position
        /// </summary>
        public string SegmentStartingPosition { get; set; }

        /// <summary>
        /// Gets or Sets Segment Length 
        /// </summary>
        public decimal SegmentLength { get; set; }
    }
}
