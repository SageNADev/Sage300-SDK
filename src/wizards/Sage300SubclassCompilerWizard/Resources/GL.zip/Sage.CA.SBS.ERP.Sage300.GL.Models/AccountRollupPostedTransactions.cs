// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class AccountRollupPostedTransactions : ModelBase
    {
        /// <summary>
        /// Gets or sets AccountNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "AccountNumber", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "FiscalYear", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "FiscalPeriod", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SRCECURN
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "SRCECURN", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.SRCECURN, Id = Index.SRCECURN, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string SRCECURN { get; set; }

        /// <summary>
        /// Gets or sets SourceLedgerCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "SourceLedgerCode", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.SourceLedgerCode, Id = Index.SourceLedgerCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedgerCode { get; set; }

        /// <summary>
        /// Gets or sets SourceTypeCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "SourceTypeCode", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.SourceTypeCode, Id = Index.SourceTypeCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceTypeCode { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "PostingSequenceNumber", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.PostingSequenceNumber, Id = Index.PostingSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal PostingSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailCount
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "DetailCount", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.DetailCount, Id = Index.DetailCount, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal DetailCount { get; set; }

        /// <summary>
        /// Gets or sets JournalDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "JournalDate", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.JournalDate, Id = Index.JournalDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime JournalDate { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "BatchNumber", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets JournalEntryNumber
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "JournalEntryNumber", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.JournalEntryNumber, Id = Index.JournalEntryNumber, FieldType = EntityFieldType.Char, Size = 5, Mask = "%05D")]
        public string JournalEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets JournalTransactionNumber
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "JournalTransactionNumber", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.JournalTransactionNumber, Id = Index.JournalTransactionNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal JournalTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets ConsolidationOccurredonPost
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "ConsolidationOccurredonPost", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.ConsolidationOccurredonPost, Id = Index.ConsolidationOccurredonPost, FieldType = EntityFieldType.Int, Size = 2)]
        public ConsolidationOccurredOnPost ConsolidationOccurredonPost { get; set; }

        /// <summary>
        /// Gets or sets CompanyID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "CompanyID", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.CompanyID, Id = Index.CompanyID, FieldType = EntityFieldType.Char, Size = 8)]
        public string CompanyID { get; set; }

        /// <summary>
        /// Gets or sets JournalDetailDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "JournalDetailDescription", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.JournalDetailDescription, Id = Index.JournalDetailDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string JournalDetailDescription { get; set; }

        /// <summary>
        /// Gets or sets JournalDetailReference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "JournalDetailReference", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.JournalDetailReference, Id = Index.JournalDetailReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string JournalDetailReference { get; set; }

        /// <summary>
        /// Gets or sets JournalTransactionAmount
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "JournalTransactionAmount", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.JournalTransactionAmount, Id = Index.JournalTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal JournalTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets JournalTransactionQuantity
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "JournalTransactionQuantity", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.JournalTransactionQuantity, Id = Index.JournalTransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal JournalTransactionQuantity { get; set; }

        /// <summary>
        /// Gets or sets NbrOfSourceCurrencyDecimals
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "NbrOfSourceCurrencyDecimals", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.NbrOfSourceCurrencyDecimals, Id = Index.NbrOfSourceCurrencyDecimals, FieldType = EntityFieldType.Char, Size = 1)]
        public string NbrOfSourceCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrencyAmount
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "SourceCurrencyAmount", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.SourceCurrencyAmount, Id = Index.SourceCurrencyAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceCurrencyAmount { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "HomeCurrencyCode", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.HomeCurrencyCode, Id = Index.HomeCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string HomeCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateTableType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "CurrencyRateTableType", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.CurrencyRateTableType, Id = Index.CurrencyRateTableType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CurrencyRateTableType { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SCURNCODE
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "SCURNCODE", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.SCURNCODE, Id = Index.SCURNCODE, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string SCURNCODE { get; set; }

        /// <summary>
        /// Gets or sets DateOfCurrencyRateSelected
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "DateOfCurrencyRateSelected", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.DateOfCurrencyRateSelected, Id = Index.DateOfCurrencyRateSelected, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateOfCurrencyRateSelected { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateForConversion
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "CurrencyRateForConversion", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.CurrencyRateForConversion, Id = Index.CurrencyRateForConversion, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CurrencyRateForConversion { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateSpreadAllowed
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "CurrencyRateSpreadAllowed", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.CurrencyRateSpreadAllowed, Id = Index.CurrencyRateSpreadAllowed, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CurrencyRateSpreadAllowed { get; set; }

        /// <summary>
        /// Gets or sets CodeForRateDateMatching
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "CodeForRateDateMatching", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.CodeForRateDateMatching, Id = Index.CodeForRateDateMatching, FieldType = EntityFieldType.Char, Size = 1)]
        public string CodeForRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateOperator
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "CurrencyRateOperator", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.CurrencyRateOperator, Id = Index.CurrencyRateOperator, FieldType = EntityFieldType.Char, Size = 1)]
        public string CurrencyRateOperator { get; set; }

        /// <summary>
        /// Gets or sets DrillDownType
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "DrillDownType", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.DrillDownType, Id = Index.DrillDownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrillDownType { get; set; }

        /// <summary>
        /// Gets or sets DrillDownLinkNumber
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "DrillDownLinkNumber", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.DrillDownLinkNumber, Id = Index.DrillDownLinkNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrillDownLinkNumber { get; set; }

        /// <summary>
        /// Gets or sets DrillDownApplicationSource
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "DrillDownApplicationSource", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.DrillDownApplicationSource, Id = Index.DrillDownApplicationSource, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string DrillDownApplicationSource { get; set; }

        /// <summary>
        /// Gets or sets ReportCurrencyAmount
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "ReportCurrencyAmount", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.ReportCurrencyAmount, Id = Index.ReportCurrencyAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReportCurrencyAmount { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "OptionalFields", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets FormattedAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "FormattedAccountNumber", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.FormattedAccountNumber, Id = Index.FormattedAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string FormattedAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets TransAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "TransAccountNumber", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.TransAccountNumber, Id = Index.TransAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TransAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets TransFormattedAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Ensure the generated string is a valid string in the referenced resx file
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "TransFormattedAccountNumber", ResourceType = typeof(RollupPostedTransactionResx))]
        [ViewField(Name = Fields.TransFormattedAccountNumber, Id = Index.TransFormattedAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TransFormattedAccountNumber { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ConsolidationOccurredonPost string value
        /// </summary>
        public string ConsolidationOccurredonPostString
        {
            get { return EnumUtility.GetStringValue(ConsolidationOccurredonPost); }
        }

        #endregion
    }
}
