/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class RollupMemberPreview : ModelBase
    {

        /// <summary>
        /// Gets or sets SourceAccount 
        /// </summary>
        [Key]
        public string SourceAccount { get; set; }

        /// <summary>
        /// Gets or sets Account 
        /// </summary>
        [Key]
        public string Account { get; set; }

        /// <summary>
        /// Gets or sets AddOrDelete 
        /// </summary>

        public bool Add { get; set; }

        /// <summary>
        /// Gets or sets FormattedAccount 
        /// </summary>
        [Display(Name = "Account", ResourceType = typeof(AccountsResx))]
        public string FormattedAccount { get; set; }

        /// <summary>
        /// Gets or sets AccountDescription 
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(AccountsResx))]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets RollupSwitch 
        /// </summary>

        public Allowed RollupSwitch { get; set; }

        /// <summary>
        /// Gets or sets AccountType 
        /// </summary>
        public AccountType AccountType { get; set; }

        /// <summary>
        /// Gets or sets AccountGroup 
        /// </summary>
        [Display(Name = "AccountGroup", ResourceType = typeof(GLCommonResx))]
        public string AccountGroup { get; set; }

        /// <summary>
        /// Gets or sets NormalBalanceDROrCR 
        /// </summary>
        public NormalBalanceDrorCr NormalBalanceDrorCr { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>

        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets PosttoAccount 
        /// </summary>
        public PosttoAccount PosttoAccount { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency 
        /// </summary>
        public Allowed Multicurrency { get; set; }

        /// <summary>
        ///  Gets StatusDescription 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(AccountsResx))]
        public string StatusDescription
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets RollupSwitchDescription 
        /// </summary>
        [Display(Name = "Rollup", ResourceType = typeof(AccountsResx))]
        public string RollupSwitchDescription
        {
            get { return EnumUtility.GetStringValue(RollupSwitch); }
        }

        /// <summary>
        /// Gets AccountTypeDescription 
        /// </summary>
        [Display(Name = "AccountType", ResourceType = typeof(AccountsResx))]
        public string AccountTypeDescription
        {
            get { return EnumUtility.GetStringValue(AccountType); }
        }

        /// <summary>
        /// Gets NormalBalanceDROrCRDescription 
        /// </summary>
        [Display(Name = "NormalBalanceDrorCr", ResourceType = typeof(AccountsResx))]
        public string NormalBalanceDrorCrDescription
        {
            get { return EnumUtility.GetStringValue(NormalBalanceDrorCr); }
        }

        /// <summary>
        /// Gets PosttoAccountDescription 
        /// </summary>
        [Display(Name = "PostToAccount", ResourceType = typeof(AccountsResx))]
        public string PosttoAccountDescription
        {
            get { return EnumUtility.GetStringValue(PosttoAccount); }
        }

        /// <summary>
        /// Gets MulticurrencyDescription 
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof(AccountsResx))]
        public string MulticurrencyDescription
        {
            get { return EnumUtility.GetStringValue(Multicurrency); }
        }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        public long SerialNumber { get; set; }
    }
}
