// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for PreviewAccountValidCurrency
    /// </summary>
    public partial class PreviewAccountValidCurrency : ModelBase
    {
        /// <summary>
        /// Gets or sets AccountNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountNumber", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RevaluationSwitch
        /// </summary>
        [Display(Name = "RevaluationSwitch", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.RevaluationSwitch, Id = Index.RevaluationSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public PreviewAccountRevaluationSwitch RevaluationSwitch { get; set; }

        /// <summary>
        /// Gets or sets RevaluationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevaluationCode", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.RevaluationCode, Id = Index.RevaluationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RevaluationCode { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets RevaluationSwitch string value
        /// </summary>
        public string RevaluationSwitchString
        {
            get { return EnumUtility.GetStringValue(RevaluationSwitch); }
        }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        public string Description { get; set; }

        #endregion
    }
}
