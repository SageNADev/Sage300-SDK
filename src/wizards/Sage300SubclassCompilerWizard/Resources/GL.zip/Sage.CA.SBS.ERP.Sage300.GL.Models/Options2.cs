/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of properties for General Ledger Options 2
    /// </summary>
    public partial class Options2 : ModelBase
    {
        /// <summary>
        /// Gets or Sets GLOptionKey
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLOptionKey", ResourceType = typeof(Options2Resx))]
        [Key]
        public string GLOptionKey { get; set; }

        /// <summary>
        /// Gets or Sets EditImportedBatches
        /// </summary>
        [Display(Name = "EditImportedBatches", ResourceType = typeof(Options2Resx))]
        public EditImportedBatches EditImportedBatches { get; set; }

        /// <summary>
        /// Gets or Sets EditSubledgerBatches
        /// </summary>
        [Display(Name = "EditSubledgerBatches", ResourceType = typeof(Options2Resx))]
        public EditSubledgerBatches EditSubledgerBatches { get; set; }
    }
}
