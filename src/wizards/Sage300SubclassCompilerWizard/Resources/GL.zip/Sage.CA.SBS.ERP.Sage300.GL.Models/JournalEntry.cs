/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class JournalEntry.
    /// </summary>
    public partial class JournalEntry : ModelBase
    {
        /// <summary>
        /// This constructor initializes the keys to be empty strings.
        /// This avoids the problem of serializing an object with a null required property.
        /// </summary>
        public JournalEntry()
        {
            BatchNumber = string.Empty;
            EntryNumber = string.Empty;
            SourceLedger = string.Empty;
            SourceType = string.Empty;
            FiscalYear = string.Empty;
            SpecificReversalYear = string.Empty;
        }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        /// <value>The batch number.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(JournalEntryResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber
        /// </summary>
        /// <value>The entry number.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(JournalEntryResx))]
        [Key]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Char, Size = 5, Mask = "%05D")]
        public string EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets Originator
        /// </summary>
        /// <value>The originator.</value>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Originator", ResourceType = typeof(JournalEntryResx))]
        [Key]
        [ViewField(Name = Fields.Originator, Id = Index.Originator, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Originator { get; set; }

        /// <summary>
        /// Gets or sets SourceLedger
        /// </summary>
        /// <value>The source ledger.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceLedger", ResourceType = typeof(GLCommonResx))]
        [Key]
        [ViewField(Name = Fields.SourceLedger, Id = Index.SourceLedger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedger { get; set; }

        /// <summary>
        /// Gets or sets SourceType
        /// </summary>
        /// <value>The type of the source.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType", ResourceType = typeof(JournalEntryResx))]
        [Key]
        [ViewField(Name = Fields.SourceType, Id = Index.SourceType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        /// <value>The fiscal year.</value>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        /// <value>The fiscal period.</value>
        [ValidateFiscalPeriod(ModuleName.GL, ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2)]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ReservedJournalEdit
        /// </summary>
        /// <value>The reserved journal edit.</value>
        public int ReservedJournalEdit { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [automatic reversal bool].
        /// </summary>
        /// <value><c>true</c> if [automatic reversal bool]; otherwise, <c>false</c>.</value>
        public bool AutoReversalBool { get; set; }

        /// <summary>
        /// Gets or sets AutoReversal
        /// </summary>
        /// <value>The automatic reversal.</value>
        [Display(Name = "AutoReverse", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.AutoReversal, Id = Index.AutoReversal, FieldType = EntityFieldType.Int, Size = 2)]
        public FindAutoReversal AutoReversal { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        /// <value>The description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryDescription", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Debits
        /// </summary>
        /// <value>The debits.</value>
        [Display(Name = "DebitsC", ResourceType = typeof(JournalEntryResx))]
        [DisplayFormat(DataFormatString = "{0:F2}", ApplyFormatInEditMode = true)]
        [ViewField(Name = Fields.Debits, Id = Index.Debits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Debits { get; set; }

        /// <summary>
        /// Gets or sets Credits
        /// </summary>
        /// <value>The credits.</value>
        [Display(Name = "CreditsC", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.Credits, Id = Index.Credits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Credits { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        /// <value>The quantity.</value>
        [Display(Name = "QuantityC", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets EntryDate
        /// </summary>
        /// <value>The entry date.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryDate", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.EntryDate, Id = Index.EntryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime EntryDate { get; set; }

        /// <summary>
        /// Gets or sets DrillDownType
        /// </summary>
        /// <value>The type of the drill down.</value>
        [Display(Name = "DrillDownType", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.DrillDownType, Id = Index.DrillDownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrillDownType { get; set; }

        /// <summary>
        /// Gets or sets DrillDownLinkNumber
        /// </summary>
        /// <value>The drill down link number.</value>
        [Display(Name = "DrillDownLinkNumber", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.DrillDownLinkNumber, Id = Index.DrillDownLinkNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public string DrillDownLinkNumber { get; set; }

        /// <summary>
        /// Gets or sets DrillDownApplicationSource
        /// </summary>
        /// <value>The drill down application source.</value>
        [Display(Name = "DrillDownApplicationSource", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.DrillDownApplicationSource, Id = Index.DrillDownApplicationSource, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string DrillDownApplicationSource { get; set; }

        /// <summary>
        /// Gets or sets OutofBalanceBy
        /// </summary>
        /// <value>The outof balance by.</value>
        [Display(Name = "OutofBalanceBy", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.OutofBalanceBy, Id = Index.OutofBalanceBy, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OutofBalanceBy { get; set; }

        /// <summary>
        /// Gets or sets SpecificReversalYear
        /// </summary>
        /// <value>The specific reversal year.</value>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SpecificReversalYear", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.SpecificReversalYear, Id = Index.SpecificReversalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string SpecificReversalYear { get; set; }

        /// <summary>
        /// Gets or sets SpecificReversalPeriod
        /// </summary>
        /// <value>The specific reversal period.</value>
        [ValidateFiscalPeriod(ModuleName.GL, ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SpecificReversalPeriod", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.SpecificReversalPeriod, Id = Index.SpecificReversalPeriod, FieldType = EntityFieldType.Char, Size = 2)]
        public string SpecificReversalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ErrorBatch
        /// </summary>
        /// <value>The error batch.</value>
        [Display(Name = "ErrorBatch", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.ErrorBatch, Id = Index.ErrorBatch, FieldType = EntityFieldType.Long, Size = 4)]
        public long ErrorBatch { get; set; }

        /// <summary>
        /// Gets or sets ErrorEntry
        /// </summary>
        /// <value>The error entry.</value>
        [Display(Name = "ErrorEntry", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.ErrorEntry, Id = Index.ErrorEntry, FieldType = EntityFieldType.Long, Size = 4)]
        public long ErrorEntry { get; set; }

        /// <summary>
        /// Gets or sets NumberofDetails
        /// </summary>
        /// <value>The numberof details.</value>
        [Display(Name = "NumberofDetails", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.NumberofDetails, Id = Index.NumberofDetails, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofDetails { get; set; }

        /// <summary>
        /// Gets or sets Processswitches
        /// </summary>
        /// <value>The processswitches.</value>
        [Display(Name = "Processswitches", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.Processswitches, Id = Index.Processswitches, FieldType = EntityFieldType.Int, Size = 2)]
        public FindProcessSwitch Processswitches { get; set; }

        /// <summary>
        /// Gets or sets OrigExists
        /// </summary>
        /// <value>The original exists.</value>
        [IgnoreExportImport]
        [ViewField(Name = Fields.OrigExists, Id = Index.OrigExists, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrigExists { get; set; }

        /// <summary>
        /// Gets or sets OrigDescription
        /// </summary>
        /// <value>The original description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.OrigDescription, Id = Index.OrigDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OrigDescription { get; set; }

        /// <summary>
        /// Gets or sets OrigStatus
        /// </summary>
        /// <value>The original status.</value>
        [Display(Name = "OrigStatus", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.OrigStatus, Id = Index.OrigStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrigStatus { get; set; }

        /// <summary>
        /// Gets or sets OrigMulticurrencySwitch
        /// </summary>
        /// <value>The original multicurrency switch.</value>
        [Display(Name = "OrigMulticurrencySwitch", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.OrigMulticurrencySwitch, Id = Index.OrigMulticurrencySwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrigMulticurrencySwitch { get; set; }

        /// <summary>
        /// Gets or sets OrigHomeCurrency
        /// </summary>
        /// <value>The original home currency.</value>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "HomeCurrency", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.OrigHomeCurrency, Id = Index.OrigHomeCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string OrigHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets OrigHomeCurrencyDecimals
        /// </summary>
        /// <value>The original home currency decimals.</value>
        [Display(Name = "OrigHomeCurrencyDecimals", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.OrigHomeCurrencyDecimals, Id = Index.OrigHomeCurrencyDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrigHomeCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets OrigQtySwitch
        /// </summary>
        /// <value>The original qty switch.</value>
        [Display(Name = "OrigQtySwitch", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.OrigQtySwitch, Id = Index.OrigQtySwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrigQtySwitch { get; set; }

        /// <summary>
        /// Gets or sets OrigQtyDecimals
        /// </summary>
        /// <value>The original qty decimals.</value>
        [Display(Name = "OrigQtyDecimals", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.OrigQtyDecimals, Id = Index.OrigQtyDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrigQtyDecimals { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeExists
        /// </summary>
        /// <value>The source code exists.</value>
        [Display(Name = "SourceCodeExists", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.SourceCodeExists, Id = Index.SourceCodeExists, FieldType = EntityFieldType.Int, Size = 2)]
        public int SourceCodeExists { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeDescription
        /// </summary>
        /// <value>The source code description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeDescription", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.SourceCodeDescription, Id = Index.SourceCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string SourceCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        /// <value>The EnteredBy.</value>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets Document Date
        /// </summary>
        /// <value>The document date.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentDate", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocumentDate { get; set; }
        /// <summary>
        /// Gets or sets the entry mode for recurring entry
        /// </summary>
        /// <value>The entry mode.</value>
        public EntryMode EntryMode { get; set; }

        /// <summary>
        /// The Journal details related to the Journal entry
        /// </summary>
        /// <value>The journal detail.</value>
        public EnumerableResponse<JournalDetail> JournalDetail { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroupDescription", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }
        /// <summary>
        /// Tax group currency code decimal place
        /// </summary>
        public int TaxGroupCurrencyDecimals { get; set; }
        /// <summary>
        /// Gets or sets TaxTransactionType
        /// </summary>
        [Display(Name = "TaxTransactionType", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxTransactionType, Id = Index.TaxTransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxTransactionType TaxTransactionType { get; set; }

        /// <summary>
        /// Gets or sets CustomerVendorNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerVendorNumber", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.CustomerVendorNumber, Id = Index.CustomerVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentType
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority Description 1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthorityDescription1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthorityDescription1, Id = Index.TaxAuthorityDescription1, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority Description 2
        /// </summary>
        [Display(Name = "TaxAuthorityDescription2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthorityDescription2, Id = Index.TaxAuthorityDescription2, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority Description 3
        /// </summary>
        [Display(Name = "TaxAuthorityDescription3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthorityDescription3, Id = Index.TaxAuthorityDescription3, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority Description 4
        /// </summary>
        [Display(Name = "TaxAuthorityDescription4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthorityDescription4, Id = Index.TaxAuthorityDescription4, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority Description 5
        /// </summary>
        [Display(Name = "TaxAuthorityDescription5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthorityDescription5, Id = Index.TaxAuthorityDescription5, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription5 { get; set; }

        /// <summary>
        /// Gets or sets TaxVendorClass1
        /// </summary>
        [Display(Name = "TaxVendorClass1", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxVendorClass1, Id = Index.TaxVendorClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxVendorClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxVendorClass2
        /// </summary>
        [Display(Name = "TaxVendorClass2", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxVendorClass2, Id = Index.TaxVendorClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxVendorClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxVendorClass3
        /// </summary>
        [Display(Name = "TaxVendorClass3", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxVendorClass3, Id = Index.TaxVendorClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxVendorClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxVendorClass4
        /// </summary>
        [Display(Name = "TaxVendorClass4", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxVendorClass4, Id = Index.TaxVendorClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxVendorClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxVendorClass5
        /// </summary>
        [Display(Name = "TaxVendorClass5", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxVendorClass5, Id = Index.TaxVendorClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxVendorClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxItemClass1
        /// </summary>
        [Display(Name = "TaxItemClass1", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxItemClass1, Id = Index.TaxItemClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxItemClass2
        /// </summary>
        [Display(Name = "TaxItemClass2", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxItemClass2, Id = Index.TaxItemClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxItemClass3
        /// </summary>
        [Display(Name = "TaxItemClass3", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxItemClass3, Id = Index.TaxItemClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxItemClass4
        /// </summary>
        [Display(Name = "TaxItemClass4", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxItemClass4, Id = Index.TaxItemClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxItemClass5
        /// </summary>
        [Display(Name = "TaxItemClass5", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxItemClass5, Id = Index.TaxItemClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseAmount1
        /// </summary>
        [Display(Name = "TaxBaseAmount1", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxBaseAmount1, Id = Index.TaxBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseAmount2
        /// </summary>
        [Display(Name = "TaxBaseAmount2", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxBaseAmount2, Id = Index.TaxBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseAmount3
        /// </summary>
        [Display(Name = "TaxBaseAmount3", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxBaseAmount3, Id = Index.TaxBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseAmount4
        /// </summary>
        [Display(Name = "TaxBaseAmount4", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxBaseAmount4, Id = Index.TaxBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseAmount5
        /// </summary>
        [Display(Name = "TaxBaseAmount5", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxBaseAmount5, Id = Index.TaxBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1
        /// </summary>
        [Display(Name = "TaxExpenseAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxExpenseAmount1, Id = Index.TaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2
        /// </summary>
        [Display(Name = "TaxExpenseAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxExpenseAmount2, Id = Index.TaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3
        /// </summary>
        [Display(Name = "TaxExpenseAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxExpenseAmount3, Id = Index.TaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4
        /// </summary>
        [Display(Name = "TaxExpenseAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxExpenseAmount4, Id = Index.TaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5
        /// </summary>
        [Display(Name = "TaxExpenseAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxExpenseAmount5, Id = Index.TaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1
        /// </summary>
        [Display(Name = "TaxRecoverableAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRecoverableAmount1, Id = Index.TaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2
        /// </summary>
        [Display(Name = "TaxRecoverableAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRecoverableAmount2, Id = Index.TaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3
        /// </summary>
        [Display(Name = "TaxRecoverableAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRecoverableAmount3, Id = Index.TaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4
        /// </summary>
        [Display(Name = "TaxRecoverableAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRecoverableAmount4, Id = Index.TaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5
        /// </summary>
        [Display(Name = "TaxRecoverableAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRecoverableAmount5, Id = Index.TaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxAllocatedAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxAllocatedAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxAllocatedAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxAllocatedAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxAllocatedAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed1
        /// </summary>
        [Display(Name = "TaxReportingExpensed1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingExpensed1, Id = Index.TaxReportingExpensed1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed2
        /// </summary>
        [Display(Name = "TaxReportingExpensed2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingExpensed2, Id = Index.TaxReportingExpensed2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed3
        /// </summary>
        [Display(Name = "TaxReportingExpensed3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingExpensed3, Id = Index.TaxReportingExpensed3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed4
        /// </summary>
        [Display(Name = "TaxReportingExpensed4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingExpensed4, Id = Index.TaxReportingExpensed4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed5
        /// </summary>
        [Display(Name = "TaxReportingExpensed5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingExpensed5, Id = Index.TaxReportingExpensed5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed5 { get; set; }

        /// <summary>
        /// Gets or sets TXRECVB1RC
        /// </summary>
        [Display(Name = "TXRECVB1RC", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TXRECVB1RC, Id = Index.TXRECVB1RC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXRECVB1RC { get; set; }

        /// <summary>
        /// Gets or sets TXRECVB2RC
        /// </summary>
        [Display(Name = "TXRECVB2RC", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TXRECVB2RC, Id = Index.TXRECVB2RC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXRECVB2RC { get; set; }

        /// <summary>
        /// Gets or sets TXRECVB3RC
        /// </summary>
        [Display(Name = "TXRECVB3RC", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TXRECVB3RC, Id = Index.TXRECVB3RC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXRECVB3RC { get; set; }

        /// <summary>
        /// Gets or sets TXRECVB4RC
        /// </summary>
        [Display(Name = "TXRECVB4RC", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TXRECVB4RC, Id = Index.TXRECVB4RC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXRECVB4RC { get; set; }

        /// <summary>
        /// Gets or sets TXRECVB5RC
        /// </summary>
        [Display(Name = "TXRECVB5RC", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TXRECVB5RC, Id = Index.TXRECVB5RC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXRECVB5RC { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingAllocatedAmount1, Id = Index.TaxReportingAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingAllocatedAmount2, Id = Index.TaxReportingAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingAllocatedAmount3, Id = Index.TaxReportingAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingAllocatedAmount4, Id = Index.TaxReportingAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingAllocatedAmount5, Id = Index.TaxReportingAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrencyCode", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRate
        /// </summary>
        [Display(Name = "TaxReportingRate", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingRate, Id = Index.TaxReportingRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateDate", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperation
        /// </summary>
        [Display(Name = "TaxReportingRateOperation", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxReportingRateOperation, Id = Index.TaxReportingRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxReportingRateOperation TaxReportingRateOperation { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount1
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxExpenseAccount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxExpenseAccount1, Id = Index.TaxExpenseAccount1, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount2
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxExpenseAccount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxExpenseAccount2, Id = Index.TaxExpenseAccount2, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount3
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxExpenseAccount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxExpenseAccount3, Id = Index.TaxExpenseAccount3, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount4
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxExpenseAccount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxExpenseAccount4, Id = Index.TaxExpenseAccount4, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount5
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxExpenseAccount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxExpenseAccount5, Id = Index.TaxExpenseAccount5, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount1
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRecoverableAccount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRecoverableAccount1, Id = Index.TaxRecoverableAccount1, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount2
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRecoverableAccount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRecoverableAccount2, Id = Index.TaxRecoverableAccount2, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount3
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRecoverableAccount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRecoverableAccount3, Id = Index.TaxRecoverableAccount3, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount4
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRecoverableAccount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRecoverableAccount4, Id = Index.TaxRecoverableAccount4, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount5
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRecoverableAccount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRecoverableAccount5, Id = Index.TaxRecoverableAccount5, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1
        /// </summary>
        [Display(Name = "TaxRate1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2
        /// </summary>
        [Display(Name = "TaxRate2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3
        /// </summary>
        [Display(Name = "TaxRate3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4
        /// </summary>
        [Display(Name = "TaxRate4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5
        /// </summary>
        [Display(Name = "TaxRate5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount1
        /// </summary>
        [Display(Name = "FunctionalTaxAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalTaxAmount1, Id = Index.FunctionalTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount2
        /// </summary>
        [Display(Name = "FunctionalTaxAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalTaxAmount2, Id = Index.FunctionalTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount3
        /// </summary>
        [Display(Name = "FunctionalTaxAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalTaxAmount3, Id = Index.FunctionalTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount4
        /// </summary>
        [Display(Name = "FunctionalTaxAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalTaxAmount4, Id = Index.FunctionalTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount5
        /// </summary>
        [Display(Name = "FunctionalTaxAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalTaxAmount5, Id = Index.FunctionalTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount1
        /// </summary>
        [Display(Name = "FunctionalTaxBaseAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalTaxBaseAmount1, Id = Index.FunctionalTaxBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount2
        /// </summary>
        [Display(Name = "FunctionalTaxBaseAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalTaxBaseAmount2, Id = Index.FunctionalTaxBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount3
        /// </summary>
        [Display(Name = "FunctionalTaxBaseAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalTaxBaseAmount3, Id = Index.FunctionalTaxBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount4
        /// </summary>
        [Display(Name = "FunctionalTaxBaseAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalTaxBaseAmount4, Id = Index.FunctionalTaxBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount5
        /// </summary>
        [Display(Name = "FunctionalTaxBaseAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalTaxBaseAmount5, Id = Index.FunctionalTaxBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount1
        /// </summary>
        [Display(Name = "FunctionalExpensedAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalExpensedAmount1, Id = Index.FunctionalExpensedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount2
        /// </summary>
        [Display(Name = "FunctionalExpensedAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalExpensedAmount2, Id = Index.FunctionalExpensedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount3
        /// </summary>
        [Display(Name = "FunctionalExpensedAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalExpensedAmount3, Id = Index.FunctionalExpensedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount4
        /// </summary>
        [Display(Name = "FunctionalExpensedAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalExpensedAmount4, Id = Index.FunctionalExpensedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount5
        /// </summary>
        [Display(Name = "FunctionalExpensedAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalExpensedAmount5, Id = Index.FunctionalExpensedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount1
        /// </summary>
        [Display(Name = "FunctionalRecoverableAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalRecoverableAmount1, Id = Index.FunctionalRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount2
        /// </summary>
        [Display(Name = "FunctionalRecoverableAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalRecoverableAmount2, Id = Index.FunctionalRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount3
        /// </summary>
        [Display(Name = "FunctionalRecoverableAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalRecoverableAmount3, Id = Index.FunctionalRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount4
        /// </summary>
        [Display(Name = "FunctionalRecoverableAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalRecoverableAmount4, Id = Index.FunctionalRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount5
        /// </summary>
        [Display(Name = "FunctionalRecoverableAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalRecoverableAmount5, Id = Index.FunctionalRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount1
        /// </summary>
        [Display(Name = "FunctionalAllocatedAmount1", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalAllocatedAmount1, Id = Index.FunctionalAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount2
        /// </summary>
        [Display(Name = "FunctionalAllocatedAmount2", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalAllocatedAmount2, Id = Index.FunctionalAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount3
        /// </summary>
        [Display(Name = "FunctionalAllocatedAmount3", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalAllocatedAmount3, Id = Index.FunctionalAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount4
        /// </summary>
        [Display(Name = "FunctionalAllocatedAmount4", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalAllocatedAmount4, Id = Index.FunctionalAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount5
        /// </summary>
        [Display(Name = "FunctionalAllocatedAmount5", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.FunctionalAllocatedAmount5, Id = Index.FunctionalAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets InvoiceTotalTaxGroup
        /// </summary>
        //[ViewField(Name = Fields.InvoiceTotalTaxGroup, Id = Index.InvoiceTotalTaxGroup, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceTotalTaxGroup { get; set; }
        /// <summary>
        /// Gets or sets for InvoiceTotalFunctional
        /// </summary>
        //[ViewField(Name = Fields.InvoiceTotalFunctional, Id = Index.InvoiceTotalFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceTotalFunctional { get; set; }
        /// <summary>
        /// Gets AutoReversal string value
        /// </summary>
        public string AutoReversalString
        {
            get { return EnumUtility.GetStringValue(AutoReversal); }
        }

        /// <summary>
        /// Gets ProcessSwitches string value
        /// </summary>
        //public string ProcessSwitchesString
        //{
        //    get { return EnumUtility.GetStringValue(ProcessSwitches); }
        //}

        /// <summary>
        /// Gets TaxTransactionType string value
        /// </summary>
        public string TaxTransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TaxTransactionType); }
        }

        /// <summary>
        /// Gets DocumentType string value
        /// </summary>
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Gets TaxReportingRateOperation string value
        /// </summary>
        public string TaxReportingRateOperationString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOperation); }
        }

        /// <summary>
        /// Tax Currency Code Description
        /// </summary>
        //[ViewField(Name = Fields.CurrencyCodeDescription, Id = Index.CurrencyCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CurrencyCodeDescription { get; set; }

        /// <summary>
        /// Tax Reporting Rate Type Description
        /// </summary>
        //[ViewField(Name = Fields.RateTypeDescription, Id = Index.RateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RateTypeDescription { get; set; }

        /// <summary>
        /// Tax Customer/Vendor Name
        /// </summary>
        //[ViewField(Name = Fields.CustomerVendorName, Id = Index.CustomerVendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerVendorName { get; set; }
        
        /// <summary>
        /// Tax group currency spread
        /// </summary>
        public decimal CurrencySpread { get; set; }

        /// <summary>
        /// Tax amount save to DB flag
        /// </summary>
        public bool IsSaveDetails { get; set; }
    }
}
