/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Optional Fields Class
    /// </summary>
    public partial class OptionalFields : ModelBase
    {
        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Display(Name = "TypeCount", ResourceType = typeof(OptionalFieldsResx))]
        [Key]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public OptionalFieldLocation Location { get; set; }

        /// <summary>
        /// LocationString
        /// </summary>
        public string LocationString
        {
            get
            {
                return EnumUtility.GetStringValue(Location);
            }
        }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Display(Name = "OptionalField", ResourceType = typeof(CommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets DefaultValue
        /// </summary>
        [Display(Name = "DefaultValue", ResourceType = typeof(OptionalFieldsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultValue, Id = Index.DefaultValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultValue { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public OptionalFieldType Type { get; set; }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        [IgnoreExportImport]
        public string TypeString
        {
            get
            {
                return EnumUtility.GetStringValue(Type);
            }
        }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }


        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowedType AllowBlank { get; set; }

        /// <summary>
        /// Allow Blank String
        /// </summary>
        public string AllowBlankString
        {
            get { return EnumUtility.GetStringValue(AllowBlank); }
        }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowedType Validate { get; set; }

        /// <summary>
        /// Validate String
        /// </summary>
        public string ValidateString
        {
            get { return EnumUtility.GetStringValue(Validate); }
        }

        /// <summary>
        /// Gets or sets AutoInsert
        /// </summary>
        [Display(Name = "AutoInsert", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AutoInsert, Id = Index.AutoInsert, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType AutoInsert { get; set; }

        /// <summary>
        /// AutoInsert String
        /// </summary>
        public string AutoInsertString
        {
            get { return EnumUtility.GetStringValue(AutoInsert); }
        }

        /// <summary>
        ///  Gets or sets Required
        /// </summary>
        [Display(Name = "Required", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Required, Id = Index.Required, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType Required { get; set; }

        /// <summary>
        /// Required String
        /// </summary>
        public string RequiredString
        {
            get { return EnumUtility.GetStringValue(Required); }
        }

        /// <summary>
        ///  Gets or sets ValueSet
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType ValueSet { get; set; }

        /// <summary>
        /// ValueSet String
        /// </summary>
        public string ValueSetString
        {
            get { return EnumUtility.GetStringValue(ValueSet); }
        }

        /// <summary>
        ///  Gets or sets TypedDefaultValueFieldIndex
        /// </summary>
        [Display(Name = "TypedDefaultValueFieldIndex", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TypedDefaultValueFieldIndex, Id = Index.TypedDefaultValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public int TypedDefaultValueFieldIndex { get; set; }

        /// <summary>
        ///  Gets or sets DefaultTextValue
        /// </summary>
        [Display(Name = "DefaultTextValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTextValue, Id = Index.DefaultTextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultTextValue { get; set; }


        /// <summary>
        ///  Gets or sets DefaultAmountValue
        /// </summary>
        [Display(Name = "DefaultAmountValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultAmountValue, Id = Index.DefaultAmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DefaultAmountValue { get; set; }

        /// <summary>
        ///  Gets or sets DefaultNumberValue
        /// </summary>
        [Display(Name = "DefaultNumberValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultNumberValue, Id = Index.DefaultNumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DefaultNumberValue { get; set; }

        /// <summary>
        ///  Gets or sets DefaultIntegerValue
        /// </summary>
        [Display(Name = "DefaultIntegerValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultIntegerValue, Id = Index.DefaultIntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public int DefaultIntegerValue { get; set; }

        /// <summary>
        ///  Gets or sets DefaultYesOrNoValue
        /// </summary>
        [Display(Name = "DefaultYesOrNoValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultYesOrNoValue, Id = Index.DefaultYesOrNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowedType DefaultYesOrNoValue { get; set; }

        /// <summary>
        /// DefaultYesOrNoValue String
        /// </summary>
        public string DefaultYesOrNoValueString
        {
            get { return EnumUtility.GetStringValue(DefaultYesOrNoValue); }
        }

        /// <summary>
        ///  Gets or sets DefaultDateValue
        /// </summary>
        [Display(Name = "DefaultDateValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultDateValue, Id = Index.DefaultDateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DefaultDateValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultTimeValue
        /// </summary>
        [Display(Name = "DefaultTimeValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTimeValue, Id = Index.DefaultTimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime DefaultTimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultValueDescription
        /// </summary>
        [Display(Name = "DefaultValueDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultValueDescription, Id = Index.DefaultValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultValueDescription { get; set; }


        /// <summary>
        /// Gets or sets the property when new optional field is being inserted
        /// </summary>
        public bool IsNewOptionalField { get; set; }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets IsDeleted
        /// </summary>
        public bool IsValidate { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFieldsValue DefaultOptionField { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public CS.Models.OptionalFields DefaultOptionFieldValue { get; set; }

        /// <summary>
        /// To get integer min
        /// </summary>
        /// <value>The int minimum.</value>
        public string IntMin
        {
            get { return "-2147483647"; }
        }

        /// <summary>
        /// To get integer max
        /// </summary>
        /// <value>The int maximum.</value>
        public string IntMax
        {
            get { return "2147483647"; }
        }

        /// <summary>
        /// To get decimal min
        /// </summary>
        /// <value>The decimal minimum.</value>
        public string DecimalMinAmountType
        {
            get
            {
                return CommonUtil.GetDecimalDefaultFormat('9', 15, 3, true);
            }
        }

        /// <summary>
        /// To get decimal max
        /// </summary>
        /// <value>The decimal maximum.</value>
        public string DecimalMaxAmountType
        {
            get { return CommonUtil.GetDecimalDefaultFormat('9', 15, 3, false); }
        }

        /// <summary>
        /// To get decimal min
        /// </summary>
        /// <value>The decimal minimum.</value>
        public string DecimalMinNumberType
        {
            get
            {
                return CommonUtil.GetDecimalDefaultFormat('9', 15, Decimals, true);
            }
        }

        /// <summary>
        /// To get decimal max
        /// </summary>
        /// <value>The decimal maximum.</value>
        public string DecimalMaxNumberType
        {
            get { return CommonUtil.GetDecimalDefaultFormat('9', 15, Decimals, false); }
        }

        /// <summary>
        /// To get decimal regular expression
        /// </summary>
        public string IntegerRegEx
        {
            get { return CommonUtil.GetDecimalRegularExpression(10, 0); }
        }

        /// <summary>
        /// To get decimal regular expression
        /// </summary>
        public string DecimalRegExAmountType
        {
            get { return CommonUtil.GetDecimalRegularExpression(18, 3); }
        }

        /// <summary>
        /// To get decimal regular expression
        /// </summary>
        public string DecimalRegExNumberType
        {
            get { return CommonUtil.GetDecimalRegularExpression(18, Decimals); }
        }
    }
}
