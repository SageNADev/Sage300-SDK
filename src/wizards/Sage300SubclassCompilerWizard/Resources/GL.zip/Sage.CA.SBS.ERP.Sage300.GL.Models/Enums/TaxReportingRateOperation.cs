// Copyright (c) 2020 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for TaxReportingRateOperation
    /// </summary>
    public enum TaxReportingRateOperation
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(JournalEntryResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Multiply
        /// </summary>
        [EnumValue("Multiply", typeof(JournalEntryResx))]
        Multiply = 1,
        /// <summary>
        /// Gets or sets Divide
        /// </summary>
        [EnumValue("Divide", typeof(JournalEntryResx))]
        Divide = 2
    }
}