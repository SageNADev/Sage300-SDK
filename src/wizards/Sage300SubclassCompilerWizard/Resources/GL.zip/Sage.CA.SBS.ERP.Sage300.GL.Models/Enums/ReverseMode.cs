﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum ReverseMode
    /// </summary>
    public enum ReverseMode
    {
        /// <summary>
        /// The entry
        /// </summary>
        Entry = 0,

        /// <summary>
        /// The batch
        /// </summary>
        Batch = 1,
    }
}