﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum JournalDetailOptionalFieldsSwitch
    /// </summary>
    public enum JournalDetailOptionalFieldsSwitch
    {
        /// <summary>
        /// The insert journal entry optional fields
        /// </summary>
        InsertJournalEntryOptionalFields = 0,

        /// <summary>
        /// The refresh journal header fields
        /// </summary>
        RefreshJournalHeaderFields = 3,

        /// <summary>
        /// The refresh source ledger fieldin journal header
        /// </summary>
        RefreshSourceLedgerFieldinJournalHeader = 4,
    }
}