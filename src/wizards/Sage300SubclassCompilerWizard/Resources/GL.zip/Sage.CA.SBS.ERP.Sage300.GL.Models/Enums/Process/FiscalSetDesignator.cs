// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Enum for FiscalSetDesignator
    /// </summary>
    public enum FiscalSetDesignator
    {
        /// <summary>
        /// Gets or sets Actuals
        /// </summary>
        [EnumValue("Actuals", typeof(FinancialReportInformationResx))]
        Actuals = 'A',
        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [EnumValue("Quantity", typeof(FinancialReportInformationResx))]
        Quantity = 'Q',
        /// <summary>
        /// Gets or sets Reporting
        /// </summary>
        [EnumValue("Reporting", typeof(FinancialReportInformationResx))]
        Reporting = 'R',
        /// <summary>
        /// Gets or sets ProvisionalActuals
        /// </summary>
        [EnumValue("ProvisionalActuals", typeof(FinancialReportInformationResx))]
        ProvisionalActuals = 'P',
        /// <summary>
        /// Gets or sets ProvisionalQuantity
        /// </summary>
        [EnumValue("ProvisionalQuantity", typeof(FinancialReportInformationResx))]
        ProvisionalQuantity = 'O',
        /// <summary>
        /// Gets or sets ProvisionalReporting
        /// </summary>
        [EnumValue("ProvisionalReporting", typeof(FinancialReportInformationResx))]
        ProvisionalReporting = 'T',
        /// <summary>
        /// Gets or sets Budget1
        /// </summary>
        [EnumValue("Budget1", typeof(FinancialReportInformationResx))]
        Budget1 = 1,
        /// <summary>
        /// Gets or sets Budget2
        /// </summary>
        [EnumValue("Budget2", typeof(FinancialReportInformationResx))]
        Budget2 = 2,
        /// <summary>
        /// Gets or sets Budget3
        /// </summary>
        [EnumValue("Budget3", typeof(FinancialReportInformationResx))]
        Budget3 = 3,
        /// <summary>
        /// Gets or sets Budget4
        /// </summary>
        [EnumValue("Budget4", typeof(FinancialReportInformationResx))]
        Budget4 = 4,
        /// <summary>
        /// Gets or sets Budget5
        /// </summary>
        [EnumValue("Budget5", typeof(FinancialReportInformationResx))]
        Budget5 = 5
    }
}