﻿// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Segment type
    /// </summary>
    public enum FRPrintSegmentType
    {
        Unused,
        Summary,
        Separate
    }
}
