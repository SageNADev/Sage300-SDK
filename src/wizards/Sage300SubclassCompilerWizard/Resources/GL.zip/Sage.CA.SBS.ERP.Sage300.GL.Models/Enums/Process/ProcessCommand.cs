﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    public enum ProcessCommand
    {
		/// <summary>
		/// Gets or sets ProcessAutoAllocation
		/// </summary>
        [EnumValue("BothAccountBalQty", typeof(CreateAllocationBatchResx))]
		Both = 3,

		/// <summary>
		/// Gets or sets InsertOptionalFields
		/// </summary>
        [EnumValue("AccountBalance", typeof(CreateAllocationBatchResx))]
		AccountBalance = 1,

        /// <summary>
        /// Gets or sets InsertOptionalFields
        /// </summary>
        [EnumValue("AccountQuantity", typeof(CreateAllocationBatchResx))]
        AccountQuantity = 2
    }
}
