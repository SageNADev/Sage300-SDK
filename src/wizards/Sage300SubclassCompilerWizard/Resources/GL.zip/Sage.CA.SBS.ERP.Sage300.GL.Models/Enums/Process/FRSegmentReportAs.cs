﻿// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Enum for Segment Report As
    /// </summary>
    public enum FRSegmentReportAs
    {
        [Display(Name = "Separate", ResourceType = typeof(GLCommonResx))]
        Separate,

        [Display(Name = "Consolidated", ResourceType = typeof(GLCommonResx))]
        Consolidated
    }
}
