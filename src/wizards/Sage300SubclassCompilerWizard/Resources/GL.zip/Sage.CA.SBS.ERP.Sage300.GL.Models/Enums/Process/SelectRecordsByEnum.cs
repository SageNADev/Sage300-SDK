/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Enum SelectRecordsByEnum
    /// </summary>
    public enum SelectRecordsByEnum
    {
        /// <summary>
        /// The recurring entry code
        /// </summary>
        RecurringEntryCode = 0,

        /// <summary>
        /// The schedule link
        /// </summary>
        ScheduleLink = 1,
    }
}