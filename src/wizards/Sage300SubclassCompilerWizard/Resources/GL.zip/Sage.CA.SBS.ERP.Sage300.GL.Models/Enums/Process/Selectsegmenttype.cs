// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Enum for Selectsegmenttype
    /// </summary>
    public enum Selectsegmenttype
    {
        /// <summary>
        /// Gets or sets Fullaccount
        /// </summary>
        [EnumValue("Fullaccount", typeof(CreateRevaluationBatchResx))]
        Fullaccount = 1,

        /// <summary>
        /// Gets or sets Anysegment
        /// </summary>
        [EnumValue("Anysegment", typeof(CreateRevaluationBatchResx))]
        Anysegment = 2

    }
}