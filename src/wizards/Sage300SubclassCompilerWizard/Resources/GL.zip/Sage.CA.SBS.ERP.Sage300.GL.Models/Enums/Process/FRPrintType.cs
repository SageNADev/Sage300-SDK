﻿// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Print actions for FR Web Addin
    /// </summary>
    public enum FRPrintType
    {
        // Do nothing
        None,
        // Print
        Print,
        // Run FRView
        View
    }
}
