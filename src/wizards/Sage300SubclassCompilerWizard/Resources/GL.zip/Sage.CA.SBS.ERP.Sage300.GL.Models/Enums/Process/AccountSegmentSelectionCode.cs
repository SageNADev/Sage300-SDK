// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
	/// <summary>
	/// Enum for Accountsegmentselectioncode
	/// </summary>
	public enum AccountSegmentSelectionCode
	{
		/// <summary>
		/// Gets or sets Fullaccount
		/// </summary>
        [EnumValue("FullAccountId", typeof(CreateAllocationBatchResx))]
		Fullaccount = 1,

		/// <summary>
		/// Gets or sets Anysegment
		/// </summary>
        [EnumValue("Anysegment", typeof(ConsolidatePostedTransactionsResx))]
		Anysegment = 2
	}
}
