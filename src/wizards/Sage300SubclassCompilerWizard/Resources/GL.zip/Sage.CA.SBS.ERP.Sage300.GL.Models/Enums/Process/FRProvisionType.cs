﻿// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Provision type
    /// </summary>
    public enum FRProvisionType
    {
        Actual = 1,
        Provisional = 2
    }
}
