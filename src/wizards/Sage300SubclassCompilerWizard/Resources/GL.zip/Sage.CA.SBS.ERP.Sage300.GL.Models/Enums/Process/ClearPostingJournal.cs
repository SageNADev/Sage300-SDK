﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Contains list of ClearPostingJournal Enums
    /// </summary>
    public enum ClearPostingJournal
    {
        /// <summary>
        /// The mark journals asprinted
        /// </summary>
        MarkJournalsAsprinted = 0,

        /// <summary>
        /// The clear printed journals
        /// </summary>
        ClearPrintedJournals = 1,
    }
}