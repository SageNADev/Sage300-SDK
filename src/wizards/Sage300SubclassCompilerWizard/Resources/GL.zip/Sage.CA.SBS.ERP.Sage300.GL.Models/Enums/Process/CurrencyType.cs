// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Enum for CurrencyType
    /// </summary>
    public enum CurrencyType
    {
        /// <summary>
        /// Gets or sets Source
        /// </summary>
        [EnumValue("Source", typeof(FinancialReportInformationResx))]
        Source = 'S',
        /// <summary>
        /// Gets or sets Equivalent
        /// </summary>
        [EnumValue("Equivalent", typeof(FinancialReportInformationResx))]
        Equivalent = 'E',
        /// <summary>
        /// Gets or sets Functional
        /// </summary>
        [EnumValue("Functional", typeof(FinancialReportInformationResx))]
        Functional = 'F'
    }
}