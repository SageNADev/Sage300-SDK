// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
	/// <summary>
	/// Enum for Type
	/// </summary>
	public enum Type
	{
		/// <summary>
		/// Gets or sets Text
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		Text = 1,

		/// <summary>
		/// Gets or sets Amount
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		Amount = 100,

		/// <summary>
		/// Gets or sets Number
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		Number = 6,

		/// <summary>
		/// Gets or sets Integer
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		Integer = 8,

		/// <summary>
		/// Gets or sets YesNo
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		YesNo = 9,

		/// <summary>
		/// Gets or sets Date
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		Date = 3,

		/// <summary>
		/// Gets or sets Time
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		Time = 4
	}
}
