// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
	/// <summary>
	/// Enum for TypeOfconsolidation
	/// </summary>
	public enum TypeOfconsolidation
	{
		/// <summary>
		/// Gets or sets ConsolidatebyAccountFiscalPeriod
		/// </summary>
        [EnumValue("ConsolidatebyAccountFiscalPeriod", typeof(ConsolidatePostedTransactionsResx))]
		ConsolidatebyAccountFiscalPeriod = 1,

		/// <summary>
		/// Gets or sets ConsolidatebyAccountFiscalPeriodSourceCode
		/// </summary>
        [EnumValue("ConsolidatebyAccountFiscalPeriodSourceCode", typeof(ConsolidatePostedTransactionsResx))]
		ConsolidatebyAccountFiscalPeriodSourceCode = 2,

		/// <summary>
		/// Gets or sets ConsolidatebyAccountFiscalPeriodSourceLedger
		/// </summary>
        [EnumValue("ConsolidatebyAccountFiscalPeriodSourceLedger", typeof(ConsolidatePostedTransactionsResx))]
		ConsolidatebyAccountFiscalPeriodSourceLedger = 3
	}
}
