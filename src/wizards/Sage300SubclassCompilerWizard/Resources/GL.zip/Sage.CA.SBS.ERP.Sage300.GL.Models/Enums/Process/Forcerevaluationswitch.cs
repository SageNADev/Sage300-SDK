// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Enum for Forcerevaluationswitch
    /// </summary>
    public enum Forcerevaluationswitch
    {
        /// <summary>
        /// Gets or sets Revalueaccountswhichwishit
        /// </summary>
        [EnumValue("Revalueaccountswhichwishit", typeof(CreateRevaluationBatchResx))]
        Revalueaccountswhichwishit = 0,

        /// <summary>
        /// Gets or sets Forceaccountswhichdonotwishit
        /// </summary>
        [EnumValue("Forceaccountswhichdonotwishit", typeof(CreateRevaluationBatchResx))]
        Forceaccountswhichdonotwishit = 1

    }
}