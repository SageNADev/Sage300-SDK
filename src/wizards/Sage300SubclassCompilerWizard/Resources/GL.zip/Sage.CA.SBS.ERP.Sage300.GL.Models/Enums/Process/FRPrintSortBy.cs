﻿// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Sort type
    /// </summary>
    public enum FRPrintSortBy
    {
        Account = 1,
        Segment = 2,
        AccountGroup = 3
    }
}
