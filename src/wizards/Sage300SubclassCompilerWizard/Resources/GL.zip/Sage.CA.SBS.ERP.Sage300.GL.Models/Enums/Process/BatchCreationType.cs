/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Enum BatchCreationType
    /// </summary>
    public enum BatchCreationType
    {
        /// <summary>
        /// The default
        /// </summary>
        [EnumValue("BatchCreationType_Default", typeof (EnumerationsResx))] Default = 0,

        /// <summary>
        /// The createa new batch
        /// </summary>
        [EnumValue("BatchCreationType_CreateaNewBatch", typeof (EnumerationsResx))] CreateaNewBatch = 1,

        /// <summary>
        /// The addtoan existing batch
        /// </summary>
        [EnumValue("BatchCreationType_AddtoanExistingBatch", typeof (EnumerationsResx))] AddtoanExistingBatch = 2,
    }
}