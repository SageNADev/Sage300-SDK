﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Enum BatchStatusPrintedEnum
    /// </summary>
    public enum BatchStatusPrintedEnum
    {
        /// <summary>
        /// The not applicable
        /// </summary>
        NotApplicable = 0,

        /// <summary>
        /// The select
        /// </summary>
        Select = 1,

        /// <summary>
        /// The removedeletedandpostedbatches
        /// </summary>
        Removedeletedandpostedbatches = 67,
    }
}