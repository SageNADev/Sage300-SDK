/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Account Post to account
    /// </summary>
    public enum PosttoAccount
    {
        /// <summary>
        /// Used to Set Account Post to account is Detail
        /// </summary>
        [EnumValue("AccountPosttoAccount_Detail", typeof(EnumerationsResx))]
        Detail = 0,
        /// <summary>
        /// Used to Set Account Post to account is Consolidated
        /// </summary>
        [EnumValue("AccountPosttoAccount_Consolidated", typeof(EnumerationsResx))]
        Consolidated = 1,
        /// <summary>
        /// Used to Set Account Post to account is Prohibited
        /// </summary>
        [EnumValue("AccountPosttoAccount_Prohibited", typeof(EnumerationsResx))]
        Prohibited = 2,
    }
}
