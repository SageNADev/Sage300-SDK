﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum SelectBy
    /// </summary>
    public enum SelectBy
    {
        /// <summary>
        /// The account group
        /// </summary>
        [EnumValue("AccountGroup", typeof (GLCommonResx))] AccountGroup = 1,

        /// <summary>
        /// The sort code account group
        /// </summary>
        [EnumValue("SortCodeAccountGroup", typeof (GLCommonResx))] SortCodeAccountGroup = 2
    }
}