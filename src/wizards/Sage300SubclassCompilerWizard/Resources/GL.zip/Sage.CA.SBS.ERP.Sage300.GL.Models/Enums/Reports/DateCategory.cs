// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Date Category
    /// </summary>
    public enum DateCategory
    {
        /// <summary>
        /// Document Date
        /// </summary>
        [EnumValue("DocumentDate", typeof(PostingJournalsResx))]
        DocumentDate = 0,

        /// <summary>
        /// Session Date
        /// </summary>
        [EnumValue("PostingDate", typeof(PostingJournalsResx))]
        PostingDate = 1,

    }
}