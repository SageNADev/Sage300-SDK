/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Account Process Switch
    /// </summary>
    public enum ProcessSwitch
    {
        /// <summary>
        /// The update unitof measurement
        /// </summary>
        [EnumValue("AccountProcessSwitch_UpdateUnitofMeasurement", typeof (EnumerationsResx))] UpdateUnitofMeasurement =
            0,

        /// <summary>
        /// The insert optional fields
        /// </summary>
        [EnumValue("AccountProcessSwitch_InsertOptionalFields", typeof (EnumerationsResx))] InsertOptionalFields = 1,

        /// <summary>
        /// The replace optional fields
        /// </summary>
        [EnumValue("AccountProcessSwitch_ReplaceOptionalFields", typeof (EnumerationsResx))] ReplaceOptionalFields = 2,

        /// <summary>
        /// The checkvalidaccountunder gs
        /// </summary>
        [EnumValue("AccountProcessSwitch_CheckvalidaccountunderGs", typeof (EnumerationsResx))] CheckvalidaccountunderGs
        = 3,

        /// <summary>
        /// The create preview accts
        /// </summary>
        [EnumValue("AccountProcessSwitch_CreatePreviewAccts", typeof (EnumerationsResx))] CreatePreviewAccts = 4,

        /// <summary>
        /// The copy acctsfrom preview
        /// </summary>
        [EnumValue("AccountProcessSwitch_CopyAcctsfromPreview", typeof (EnumerationsResx))] CopyAcctsfromPreview = 5,

        /// <summary>
        /// The unlock account selector preview
        /// </summary>
        [EnumValue("AccountProcessSwitch_UnlockAccountSelectorPreview", typeof (EnumerationsResx))] UnlockAccountSelectorPreview = 6,

        /// <summary>
        /// The check overlapped rollup relationship
        /// </summary>
        [EnumValue("AccountProcessSwitch_CheckOverlappedRollupRelationship", typeof (EnumerationsResx))] CheckOverlappedRollupRelationship = 7,
    }
}