// Copyright (c) 2020 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for BudgetMethodCode
    /// </summary>
    public enum BudgetMethodCode
    {
        /// <summary>
        /// Gets or sets FixedAmount
        /// </summary>
        [EnumValue("FixedAmount", typeof(AccountBudgetCalculatorResx))]
        FixedAmount = 1,
        /// <summary>
        /// Gets or sets SpreadAmount
        /// </summary>
        [EnumValue("SpreadAmount", typeof(AccountBudgetCalculatorResx))]
        SpreadAmount = 2,
        /// <summary>
        /// Gets or sets BaseWithPercentIncrease
        /// </summary>
        [EnumValue("BaseWithPercentIncrease", typeof(AccountBudgetCalculatorResx))]
        BaseWithPercentIncrease = 3,
        /// <summary>
        /// Gets or sets BaseWithAmountIncrease
        /// </summary>
        [EnumValue("BaseWithAmountIncrease", typeof(AccountBudgetCalculatorResx))]
        BaseWithAmountIncrease = 4,
        /// <summary>
        /// Gets or sets CopyAsIs
        /// </summary>
        [EnumValue("CopyAsIs", typeof(AccountBudgetCalculatorResx))]
        CopyAsIs = 5,
        /// <summary>
        /// Gets or sets CopyWithPercentIncrease
        /// </summary>
        [EnumValue("CopyWithPercentIncrease", typeof(AccountBudgetCalculatorResx))]
        CopyWithPercentIncrease = 6,
        /// <summary>
        /// Gets or sets CopyWithAmountIncrease
        /// </summary>
        [EnumValue("CopyWithAmountIncrease", typeof(AccountBudgetCalculatorResx))]
        CopyWithAmountIncrease = 7,
        /// <summary>
        /// Gets or sets CopyWithProratedSpread
        /// </summary>
        [EnumValue("CopyWithProratedSpread", typeof(AccountBudgetCalculatorResx))]
        CopyWithProratedSpread = 8
    }
}