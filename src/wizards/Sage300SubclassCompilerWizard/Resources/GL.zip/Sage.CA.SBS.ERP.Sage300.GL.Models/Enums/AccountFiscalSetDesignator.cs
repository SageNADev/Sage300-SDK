/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for AccountFiscalSetDesignator (used by Account Fiscal Sets). Not to be
    /// confused with FiscalSetDesignator.
    /// </summary>
    public enum AccountFiscalSetDesignator
    {
        /// <summary>
        /// Gets or sets Actuals.
        /// </summary>	
        [StoredAsChar(true)]
        Actuals = 'A',

        /// <summary>
        /// Gets or sets Quantity.
        /// </summary>	
        [StoredAsChar(true)]
        Quantity = 'Q',

        /// <summary>
        /// Gets or sets Reporting.
        /// </summary>	
        [StoredAsChar(true)]
        Reporting = 'R',

        /// <summary>
        /// Gets or sets ProvisionalActuals.
        /// </summary>	
        [StoredAsChar(true)]
        ProvisionalActuals = 'P',

        /// <summary>
        /// Gets or sets ProvisionalQuantity.
        /// </summary>	
        [StoredAsChar(true)]
        ProvisionalQuantity = 'O',

        /// <summary>
        /// Gets or sets ProvisionalReporting.
        /// </summary>	
        [StoredAsChar(true)]
        ProvisionalReporting = 'T',

        /// <summary>
        /// Gets or sets Budget1.
        /// </summary>	
        [StoredAsChar(true)]
        Budget1 = '1',

        /// <summary>
        /// Gets or sets Budget2.
        /// </summary>	
        [StoredAsChar(true)]
        Budget2 = '2',

        /// <summary>
        /// Gets or sets Budget3.
        /// </summary>	
        [StoredAsChar(true)]
        Budget3 = '3',

        /// <summary>
        /// Gets or sets Budget4.
        /// </summary>	
        [StoredAsChar(true)]
        Budget4 = '4',

        /// <summary>
        /// Gets or sets Budget5.
        /// </summary>	
        [StoredAsChar(true)]
        Budget5 = '5'
    }
}