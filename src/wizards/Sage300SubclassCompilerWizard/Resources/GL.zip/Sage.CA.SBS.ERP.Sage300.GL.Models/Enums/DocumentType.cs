// Copyright (c) 2020 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for DocumentType
    /// </summary>
    public enum DocumentType
    {
        /// <summary>
        /// Gets or sets Invoice
        /// </summary>
        [EnumValue("Invoice", typeof(JournalEntryResx))]
        Invoice = 1,
        /// <summary>
        /// Gets or sets DebitNote
        /// </summary>
        [EnumValue("DebitNote", typeof(JournalEntryResx))]
        DebitNote = 2,
        /// <summary>
        /// Gets or sets CreditNote
        /// </summary>
        [EnumValue("CreditNote", typeof(JournalEntryResx))]
        CreditNote = 3
    }
}