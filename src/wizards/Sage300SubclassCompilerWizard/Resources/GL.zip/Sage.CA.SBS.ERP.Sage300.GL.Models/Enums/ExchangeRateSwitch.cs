/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum ExchangeRateSwitch
    /// </summary>
    public enum ExchangeRateSwitch
    {
        /// <summary>
        /// The userecurringentryrate
        /// </summary>
        [EnumValue("ExchangeRateSwitch_RecurringEntryRate", typeof (EnumerationsResx))] Userecurringentryrate = 0,

        /// <summary>
        /// The usecurrentrate
        /// </summary>
        [EnumValue("ExchangeRateSwitch_CurrentRate", typeof (EnumerationsResx))] Usecurrentrate = 1,
    }
}