/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Allow Previous Year Posting
    /// </summary>
    public enum AllowPreviousYearPosting
    {
        /// <summary>
        /// The do not allow previous yr posting
        /// </summary>
        [EnumValue("AllowPreviousYearPosting_DoNotAllowPreviousYrPosting", typeof (EnumerationsResx))] DoNotAllowPreviousYrPosting = 0,

        /// <summary>
        /// The previous yr posting allowed
        /// </summary>
        [EnumValue("AllowPreviousYearPosting_PreviousYrPostingAllowed", typeof (EnumerationsResx))] PreviousYrPostingAllowed = 1
    }
}