﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum AllowBlankInverse
    /// </summary>
    public enum AllowBlankInverse
    {
        /// <summary>
        /// The no
        /// </summary>
        [EnumValue("AccountValueSet_No", typeof(EnumerationsResx))]
        No = 1,

        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("AccountValueSet_Yes", typeof(EnumerationsResx))]
        Yes = 0,
    }
}