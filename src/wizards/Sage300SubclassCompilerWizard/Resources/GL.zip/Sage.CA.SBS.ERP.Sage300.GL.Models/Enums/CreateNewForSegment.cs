﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process
{
    /// <summary>
    /// Enum for CreateNewForSegment
    /// </summary>
    public enum CreateNewForSegment
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("No", typeof(CommonResx))]
        No = 0,

        /// <summary>
        /// Gets or sets Yes
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
       [EnumValue("Yes", typeof(CommonResx))]
        Yes = 1,

        /// <summary>
        /// Gets or sets AllowedYesOnly
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Yes", typeof(CommonResx))]
        AllowedYesOnly = 2,

        /// <summary>
        /// Gets or sets NotApplicable
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
       [EnumValue("NotApplicable", typeof(CommonResx))]
        NotApplicable = 3
    }
}
