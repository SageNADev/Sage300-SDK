﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum CurrencyType
    /// </summary>
    public enum CurrencyType
    {
        /// <summary>
        /// The functional
        /// </summary>
        [EnumValue("Functional", typeof(EnumerationsResx), 1)]
        Functional = 'F',

        /// <summary>
        /// The source and functional
        /// </summary>
        [EnumValue("SourceandFunctional", typeof(GLCommonResx), 2)]
        SourceAndFunctional = 'S',

        /// <summary>
        /// The reporting
        /// </summary>
        [EnumValue("Reporting", typeof(EnumerationsResx), 3)]
        Reporting = 'R'
    }
}