/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Account Normal Balance
    /// </summary>
    public enum NormalBalanceDrorCr
    {
        /// <summary>
        /// Used to Set Account Balance is Debit
        /// </summary>
        [EnumValue("AccountNormalBalanceDrorCr_Debit", typeof(EnumerationsResx))]
        Debit = 1,

        /// <summary>
        /// Used to Identify Account Balance is Credit
        /// </summary>
        [EnumValue("AccountNormalBalanceDrorCr_Credit", typeof(EnumerationsResx))]
        Credit = 2,
    }
}
