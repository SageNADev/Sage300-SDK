/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum AutoReversal
    /// </summary>
    public enum AutoReversal
    {
        /// <summary>
        /// The automatic reversal off
        /// </summary>
        [EnumValue("AutoReversalOff", typeof(EnumerationsResx))]
        AutoReversalOff = 0,

        /// <summary>
        /// The automatic reversal on
        /// </summary>
        [EnumValue("AutoReversalOn", typeof(EnumerationsResx))]
        AutoReversalOn = 1,
    }
}