// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
	/// <summary>
	/// Enum for Allow
	/// </summary>
	public enum AllowPermission
	{
		/// <summary>
		/// No
		/// </summary>
		[EnumValue("No", typeof(CommonResx))]
		No = 0,

		/// <summary>
		/// Yes
		/// </summary>
		[EnumValue("Yes", typeof(CommonResx))]
		Yes = 1
	}
}
