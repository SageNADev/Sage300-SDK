/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Maximum Segments Per Acct
    /// </summary>
    public enum MaximumSegmentsPerAcct
    {
        /// <summary>
        /// The num10 segments
        /// </summary>
        [EnumValue("MaximumSegmentsPerAcct_10Segments", typeof (EnumerationsResx))] Num10Segments = 10,

        /// <summary>
        /// The num3 segments
        /// </summary>
        [EnumValue("MaximumSegmentsPerAcct_3Segments", typeof (EnumerationsResx))] Num3Segments = 4,

        /// <summary>
        /// The num2 segments
        /// </summary>
        [EnumValue("MaximumSegmentsPerAcct_2Segments", typeof (EnumerationsResx))] Num2Segments = 3
    }
}