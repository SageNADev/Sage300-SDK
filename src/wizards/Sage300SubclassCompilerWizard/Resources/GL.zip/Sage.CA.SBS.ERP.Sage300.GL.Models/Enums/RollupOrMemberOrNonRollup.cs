/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Account Rollup Or Member Or NonRollup
    /// </summary>
    public enum RollupOrMemberOrNonRollup
    {
        /// <summary>
        /// Used to Set Account is Rollup
        /// </summary>
        [EnumValue("AccountRollupOrMemberOrNonRollup_AccountNotinRollupGroup", typeof(EnumerationsResx))]
        AccountNotinRollupGroup = 0,
        /// <summary>
        /// Used to Set Account is Member
        /// </summary>
        [EnumValue("AccountRollupOrMemberOrNonRollup_MemberAccountinRollupGroup", typeof(EnumerationsResx))]
        MemberAccountinRollupGroup = 1,
        /// <summary>
        /// Used to Set Account is NonRollup
        /// </summary>
        [EnumValue("AccountRollupOrMemberOrNonRollup_RollupAccountinRollupGroup", typeof(EnumerationsResx))]
        RollupAccountinRollupGroup = 2,
    }
}
