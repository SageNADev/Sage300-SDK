// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
	/// <summary>
	/// Enum for PostToSegmentIDCopy
	/// </summary>
	public enum PostToSegmentIdCopy
	{
		/// <summary>
		/// Gets or sets 
		/// </summary>
		[EnumValue("None", typeof(CommonResx))]
		None = 0,

		/// <summary>
		/// Gets or sets Division
		/// </summary>
        [EnumValue("Segment_Division", typeof(GL.Resources.EnumerationsResx))]
		Division = 2
	}
}
