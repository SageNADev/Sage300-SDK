// Copyright (c) 2020 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for TaxAccountType
    /// </summary>
    public enum TaxAccountType
    {
        /// <summary>
        /// Gets or sets Liability
        /// </summary>
        [EnumValue("None", typeof(JournalEntryResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Liability
        /// </summary>
        [EnumValue("Liability", typeof(JournalEntryResx))]
        Liability = 1,
        /// <summary>
        /// Gets or sets Expense
        /// </summary>
        [EnumValue("Expense", typeof(JournalEntryResx))]
        Expense = 2,
        /// <summary>
        /// Gets or sets Recoverable
        /// </summary>
        [EnumValue("Recoverable", typeof(JournalEntryResx))]
        Recoverable = 3,
        /// <summary>
        /// Gets or sets Allocated
        /// </summary>
        [EnumValue("Allocated", typeof(JournalEntryResx))]
        Allocated = 4
    }
}