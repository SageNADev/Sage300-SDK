// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for NormalBalanceDRCR
    /// </summary>
    public enum NormalBalanceDebitOrCredit
    {
        /// <summary>
        /// Gets or sets Debit
        /// </summary>
        [EnumValue("AccountNormalBalanceDrorCr_Debit", typeof(EnumerationsResx))]
        Debit = 1,

        /// <summary>
        /// Gets or sets Credit
        /// </summary>
        [EnumValue("AccountNormalBalanceDrorCr_Credit", typeof(EnumerationsResx))]
        Credit = 2
    }
}
