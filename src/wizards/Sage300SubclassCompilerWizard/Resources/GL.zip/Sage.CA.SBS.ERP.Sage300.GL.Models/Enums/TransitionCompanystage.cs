/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Transition Company Stage
    /// </summary>
    public enum TransitionCompanyStage
    {
        /// <summary>
        /// The not a block currency company
        /// </summary>
        [EnumValue("TransitionCompanyStage_NotABlockCurrencyCompany", typeof (EnumerationsResx))] NotABlockCurrencyCompany = 0,

        /// <summary>
        /// The transition block currency company
        /// </summary>
        [EnumValue("TransitionCompanyStage_TransitionBlockCurrencyCompany", typeof (EnumerationsResx))] TransitionBlockCurrencyCompany = 1,

        /// <summary>
        /// The block currency company
        /// </summary>
        [EnumValue("TransitionCompanyStage_BlockCurrencyCompany", typeof (EnumerationsResx))] BlockCurrencyCompany = 2
    }
}