/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Account Allocation Allowed
    /// </summary>
    public enum AllocationsAllowed
    {
        /// <summary>
        /// The no allocation
        /// </summary>
        [EnumValue("AccountAllocationAllowed_NoAllocation", typeof (EnumerationsResx))] NoAllocation = 0,

        /// <summary>
        /// The allocatedby account balance
        /// </summary>
        [EnumValue("AccountAllocationAllowed_AllocatedbyAccountBalance", typeof (EnumerationsResx))] AllocatedbyAccountBalance = 1,

        /// <summary>
        /// The allocatedby account quantity
        /// </summary>
        [EnumValue("AccountAllocationAllowed_AllocatedbyAccountQuantity", typeof (EnumerationsResx))] AllocatedbyAccountQuantity = 2,
    }
}