﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum PostAllBatchesSwitch
    /// </summary>
    public enum PostAllBatchesSwitch
    {
        /// <summary>
        /// The postall batches
        /// </summary>
        PostallBatches = 0,

        /// <summary>
        /// The postby batch range
        /// </summary>
        PostbyBatchRange = 1,
    }
}