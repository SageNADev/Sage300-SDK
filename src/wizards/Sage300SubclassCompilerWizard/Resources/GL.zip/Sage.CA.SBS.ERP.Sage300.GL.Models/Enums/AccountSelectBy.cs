﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum AccountSelectBy
    /// </summary>
    public enum AccountSelectBy
    {
        /// <summary>
        /// The account number
        /// </summary>
        [EnumValue("AccountNumber", typeof(GLCommonResx))]
        AccountNumber = 1,

        /// <summary>
        /// The account number
        /// </summary>
        [EnumValue("Segment", typeof(GLCommonResx))]
        Segment = 2,

        /// <summary>
        /// The account group
        /// </summary>
        [EnumValue("AccountGroup", typeof(GLCommonResx))]
        AccountGroup = 3,

        /// <summary>
        /// The sort code account group
        /// </summary>
        [EnumValue("SortCodeAccountGroup", typeof(GLCommonResx))]
        SortCodeAccountGroup = 4
    }
}