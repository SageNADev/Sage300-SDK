// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Type
    /// </summary>
    public enum PreviewAccountType
    {
        /// <summary>
        /// Gets or sets IncomeStatement
        /// </summary>
        [EnumValue("AccountType_IncomeStatement", typeof(GL.Resources.EnumerationsResx))]
        [StoredAsChar]
        IncomeStatement = 'I',

        /// <summary>
        /// Gets or sets BalanceSheet
        /// </summary>
        [EnumValue("BalanceSheet", typeof(GL.Resources.EnumerationsResx))]
        [StoredAsChar]
        BalanceSheet = 'B',

        /// <summary>
        /// Gets or sets RetainedEarnings
        /// </summary>
        [EnumValue("AccountType_RetainedEarnings", typeof(GL.Resources.EnumerationsResx))]
        [StoredAsChar]
        RetainedEarnings = 'R'
    }
}
