// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
	/// <summary>
	/// Enum for Drilldowntype
	/// </summary>
	public enum DrillDownType
	{
		/// <summary>
		/// Gets or sets Nodrilldowninformationavailable
		/// </summary>
		NoDrillDownInformationAvailable = 0,

		/// <summary>
		/// Gets or sets Keepparentwindowopen
		/// </summary>
		KeepParentWindowopen = 1,

		/// <summary>
		/// Gets or sets Closeparentwindow
		/// </summary>
		CloseParentWindow = 2,

		/// <summary>
		/// Gets or sets NotauthorizedTodrilldown
		/// </summary>
		NotAuthorizedToDrillDown = 3
	}
}
