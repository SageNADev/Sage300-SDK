﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum EntryMode
    /// </summary>
    public enum EntryMode
    {
        /// <summary>
        /// The normal
        /// </summary>
        Normal = 0,

        /// <summary>
        /// The quick
        /// </summary>
        Quick = 1,
    }
}