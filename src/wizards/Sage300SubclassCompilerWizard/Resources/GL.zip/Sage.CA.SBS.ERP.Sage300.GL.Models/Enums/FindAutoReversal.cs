﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum FindAutoReversal
    /// </summary>
    public enum FindAutoReversal
    {
        /// <summary>
        /// The automatic reversal off
        /// </summary>
        [EnumValue("AutoReversalOff", typeof (EnumerationsResx))] AutoReversalOff = 0,

        /// <summary>
        /// The next period
        /// </summary>
        [EnumValue("NextPeriod", typeof (EnumerationsResx))] NextPeriod = 1,

        /// <summary>
        /// The specific period
        /// </summary>
        [EnumValue("SpecificPeriod", typeof (EnumerationsResx))] SpecificPeriod = 2,
    }

    /// <summary>
    /// Enum JournalEntryAutoReversal
    /// </summary>
    public enum JournalEntryAutoReversal
    {
        //[EnumValue("AutoReversalOff", typeof(EnumerationsResx))]
        //AutoReversalOff = 0,
        /// <summary>
        /// The next period
        /// </summary>
        [EnumValue("NextPeriod", typeof (EnumerationsResx))] NextPeriod = 1,

        /// <summary>
        /// The specific period
        /// </summary>
        [EnumValue("SpecificPeriod", typeof (EnumerationsResx))] SpecificPeriod = 2,
    }
}