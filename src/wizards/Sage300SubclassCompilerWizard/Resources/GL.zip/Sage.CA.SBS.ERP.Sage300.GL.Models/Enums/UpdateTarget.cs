﻿/* Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved. */

using System;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Defines what field caused the Revaluation Detail line update
    /// </summary>
    [Flags]
    public enum UpdateTarget
    {
        /// <summary>
        /// Currency code to revalue field
        /// </summary>
        CurrencyCode = 1,

        /// <summary>
        /// DefaultRevaluationCode field
        /// </summary>
        DefaultRevaluationCode = 1 << 1,

        /// <summary>
        /// Selects egment type field
        /// </summary>
        SelectsegmentID = 1 << 2,

        /// <summary>
        /// Force revaluation switch field
        /// </summary>
        Forcerevaluationswitch = 1 << 3,

        /// <summary>
        /// From account number field
        /// </summary>
        FromAccountNumber = 1 << 4,

        /// <summary>
        /// To account number field
        /// </summary>
        ToAccountNumber = 1 << 5,

        /// <summary>
        /// Fiscal year field
        /// </summary>
        Fiscalyear = 1 << 6,

        /// <summary>
        /// From fiscal period field
        /// </summary>
        Fromfiscalperiod = 1 << 7,

        /// <summary>
        /// To fiscal period field
        /// </summary>
        Tofiscalperiod = 1 << 8,

        /// <summary>
        /// Journal date field
        /// </summary>
        Journaldate = 1 << 9,

        /// <summary>
        /// Conversion rate field
        /// </summary>
        Conversionrate = 1 << 10,

        /// <summary>
        /// Date used for conversion field
        /// </summary>
        DateusedForconversion = 1 << 11,

        /// <summary>
        /// No particular field caused the update, all the fields need to be updated
        /// </summary>
        All = ~0
    }
}
