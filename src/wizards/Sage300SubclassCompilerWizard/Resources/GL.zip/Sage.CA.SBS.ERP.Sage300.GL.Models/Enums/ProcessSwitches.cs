﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */


namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enumeration for Process switch
    /// </summary>
    public enum ProcessSwitches
    {
        /// <summary>
        /// Process Switch : Insert Recurring Entry Optional Fields
        /// </summary>
        InsertRecurringEntryOptionalFields = 0
    }
}
