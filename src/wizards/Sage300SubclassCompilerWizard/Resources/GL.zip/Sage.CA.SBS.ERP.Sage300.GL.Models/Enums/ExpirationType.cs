/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum ExpirationType
    /// </summary>
    public enum ExpirationType
    {
        /// <summary>
        /// The no expiration date
        /// </summary>
        [EnumValue("ExpirationType_NoExpiration", typeof (EnumerationsResx))] NoExpirationDate = 0,

        /// <summary>
        /// The specific date
        /// </summary>
        [EnumValue("ExpirationType_SpecificDate", typeof (EnumerationsResx))] SpecificDate = 1,
    }
}