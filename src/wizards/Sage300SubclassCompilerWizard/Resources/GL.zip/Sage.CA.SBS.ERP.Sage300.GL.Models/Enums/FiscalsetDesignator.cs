// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
	/// <summary>
	/// Enum for FiscalsetDesignator
	/// </summary>
	public enum FiscalsetDesignator
	{
		/// <summary>
		/// Gets or sets Actuals
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Actuals", typeof(EnumerationsResx))]
		Actuals = 'A',

		/// <summary>
		/// Gets or sets Quantity
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Quantity", typeof(EnumerationsResx))]
		Quantity = 'Q',

		/// <summary>
		/// Gets or sets Reporting
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Reporting", typeof(EnumerationsResx))]
		Reporting = 'R',

		/// <summary>
		/// Gets or sets ProvisionalActuals
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("ProvisionalActuals", typeof(EnumerationsResx))]
		ProvisionalActuals = 'P',

		/// <summary>
		/// Gets or sets ProvisionalQuantity
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("ProvisionalQuantity", typeof(EnumerationsResx))]
		ProvisionalQuantity = 'O',

		/// <summary>
		/// Gets or sets ProvisionalReporting
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("ProvisionalReporting", typeof(EnumerationsResx))]
		ProvisionalReporting = 'T',

		/// <summary>
		/// Gets or sets Budget1
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Budget1", typeof(EnumerationsResx))]
		Budget1 = 1,

		/// <summary>
		/// Gets or sets Budget2
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Budget2", typeof(EnumerationsResx))]
		Budget2 = 2,

		/// <summary>
		/// Gets or sets Budget3
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Budget3", typeof(EnumerationsResx))]
		Budget3 = 3,

		/// <summary>
		/// Gets or sets Budget4
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Budget4", typeof(EnumerationsResx))]
		Budget4 = 4,

		/// <summary>
		/// Gets or sets Budget5
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Budget5", typeof(EnumerationsResx))]
		Budget5 = 5
	}
}
