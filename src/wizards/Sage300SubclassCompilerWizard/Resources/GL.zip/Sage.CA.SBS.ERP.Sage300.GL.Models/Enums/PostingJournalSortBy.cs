﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// enum for PostingJournalSortBy
    /// </summary>
    public enum PostingJournalSortBy
    {
        #region Enum for PostingJournalSortBy

        /// <summary>
        /// The posting sequence
        /// </summary>
        [EnumValue("PostingJournalSortBy_PostingSequence", typeof(EnumerationsResx))]
        PostingSequence = 0,

        /// <summary>
        /// The account number
        /// </summary>
        [EnumValue("PostingJournalSortBy_AccountNumber", typeof(EnumerationsResx))]
        AccountNumber = 1

        #endregion
    }
}