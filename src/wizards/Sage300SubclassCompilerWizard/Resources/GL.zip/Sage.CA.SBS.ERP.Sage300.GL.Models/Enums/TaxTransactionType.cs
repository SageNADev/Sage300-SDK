// Copyright (c) 2020 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for TaxTransactionType
    /// </summary>
    public enum TaxTransactionType
    {
        /// <summary>
        /// Gets or sets Sales
        /// </summary>
        [EnumValue("Standard", typeof(JournalEntryResx))]
        Regular = 0,
        /// <summary>
        /// Gets or sets Sales
        /// </summary>
        [EnumValue("SalesTax", typeof(JournalEntryResx))]
        Sales = 1,
        /// <summary>
        /// Gets or sets Purchases
        /// </summary>
        [EnumValue("PurchasesTax", typeof(JournalEntryResx))]
        Purchases = 2
    }
}