/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Segment Status
    /// </summary>
    public enum SegmentStatus
    {
        /// <summary>
        /// The inactive
        /// </summary>
        [EnumValue("SegmentStatus_Inactive", typeof (EnumerationsResx))] Inactive = 0,

        /// <summary>
        /// The active
        /// </summary>
        [EnumValue("SegmentStatus_Active", typeof (EnumerationsResx))] Active = 1
    }
}