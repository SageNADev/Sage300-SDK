﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Use In Closing
    /// </summary>
    public enum UseInClosing
    {
        /// <summary>
        /// The no
        /// </summary>
        [EnumValue("UseInClosing_No", typeof (EnumerationsResx))] No = 0,

        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("UseInClosing_Yes", typeof (EnumerationsResx))] Yes = 1
    }
}