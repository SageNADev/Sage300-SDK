﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for SelectJournal
    /// </summary>
    public enum SelectJournal
    {
        #region Enum for SelectJournal

        /// <summary>
        /// The posting journal
        /// </summary>
        [EnumValue("SelectJournal_PostingJournal", typeof(EnumerationsResx))]
        PostingJournal = 0,

        /// <summary>
        /// The posting journal errors
        /// </summary>
        [EnumValue("SelectJournal_PostingJournalErrors", typeof(EnumerationsResx))]
        PostingJournalErrors = 1,

        /// <summary>
        /// The provisional posting journal
        /// </summary>
        [EnumValue("SelectJournal_ProvisionalPostingJournal", typeof(EnumerationsResx))]
        ProvisionalPostingJournal = 2,

        /// <summary>
        /// The provisional posting journal errors
        /// </summary>
        [EnumValue("SelectJournal_ProvisionalPostingJournalErrors", typeof(EnumerationsResx))]
        ProvisionalPostingJournalErrors = 3,

        #endregion
    }
}