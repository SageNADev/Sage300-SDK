/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Account Group Switch
    /// </summary>
    public enum AccountGroupSwitch
    {
        /// <summary>
        /// The do not allow account groups
        /// </summary>
        [EnumValue("AccountGroupSwitch_DoNotAllowAccountGroups", typeof (EnumerationsResx))] DoNotAllowAccountGroups = 0,

        /// <summary>
        /// The account groups allowed
        /// </summary>
        [EnumValue("AccountGroupSwitch_AccountGroupsAllowed", typeof (EnumerationsResx))] AccountGroupsAllowed = 1
    }
}