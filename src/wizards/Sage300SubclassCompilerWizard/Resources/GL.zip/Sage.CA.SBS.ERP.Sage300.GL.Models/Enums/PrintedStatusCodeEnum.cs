﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for PrintedStatusCodeEnum
    /// </summary>
    public enum PrintedStatusCode
    {
        /// <summary>
        /// The not printed
        /// </summary>
        [EnumValue("PrintedStatusCodeEnum_NotPrinted", typeof (EnumerationsResx))] NotPrinted = 0,

        /// <summary>
        /// The printed
        /// </summary>
        [EnumValue("PrintedStatusCodeEnum_Printed", typeof (EnumerationsResx))] Printed = 1
    }
}