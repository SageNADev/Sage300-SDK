/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Account Currency
    /// </summary>
    public enum SpecificCurrency
    {
        /// <summary>
        /// Used to Set Account is AllCurrencies
        /// </summary>
        [EnumValue("AccountSpecificCurrency_AllCurrencies", typeof(EnumerationsResx))]
        AllCurrencies = 0,

        /// <summary>
        /// Used to Set Account is SpecificCurrencies
        /// </summary>
        [EnumValue("AccountSpecificCurrency_SpecificCurrencies", typeof(EnumerationsResx))]
        SpecificCurrencies = 1,
    }
}
