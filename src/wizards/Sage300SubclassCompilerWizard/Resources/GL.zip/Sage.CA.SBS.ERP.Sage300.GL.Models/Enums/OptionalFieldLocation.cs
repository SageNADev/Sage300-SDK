﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Optional Field Location
    /// </summary>
    public enum OptionalFieldLocation
    {
        /// <summary>
        /// The accounts
        /// </summary>
        [EnumValue("OptionalFieldLocation_Accounts", typeof (EnumerationsResx))] Accounts = 0,

        /// <summary>
        /// The transaction details
        /// </summary>
        [EnumValue("OptionalFieldLocation_TransactionDetails", typeof (EnumerationsResx))] TransactionDetails = 1,
    }
}