/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Contains List of Options Switch Enum
    /// </summary>
    public enum OptionSwitch
    {
        /// <summary>
        /// The create new batch
        /// </summary>
        CreateNewBatch = 1,

        /// <summary>
        /// The create reverse entry
        /// </summary>
        CreateReverseEntry = 2,

        /// <summary>
        /// The create reverse batch
        /// </summary>
        CreateReverseBatch = 3,
    }
}