﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum TrialBalanceReportPrint
    /// </summary>
    public enum TrialBalanceReportPrint
    {
        /// <summary>
        /// The cap balance as of year period
        /// </summary>
        [EnumValue("CapBalanceAsOfYearPeriod", typeof (EnumerationsResx))] CapBalanceAsOfYearPeriod = 1,

        /// <summary>
        /// The cap net changes for the period
        /// </summary>
        [EnumValue("CapNetChangesForThePeriod", typeof (EnumerationsResx))] CapNetChangesForThePeriod = 2,
    }
}