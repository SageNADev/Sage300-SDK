/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for GSAccount Access Switch
    /// </summary>
    public enum GSAccountAccessSwitch
    {
        /// <summary>
        /// All account access right
        /// </summary>
        [EnumValue("GsAccountAccessSwitch_AllAccountAccessRight", typeof (EnumerationsResx))] AllAccountAccessRight = 0,

        /// <summary>
        /// The only accounts under gs
        /// </summary>
        [EnumValue("GsAccountAccessSwitch_OnlyAccountsUnderGS", typeof (EnumerationsResx))] OnlyAccountsUnderGs = 1,

        /// <summary>
        /// The no account access right
        /// </summary>
        [EnumValue("GsAccountAccessSwitch_NoAccountAccessRight", typeof (EnumerationsResx))] NoAccountAccessRight = 2
    }
}