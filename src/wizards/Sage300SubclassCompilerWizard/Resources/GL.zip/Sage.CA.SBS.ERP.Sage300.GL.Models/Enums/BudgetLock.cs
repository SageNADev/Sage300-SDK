/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Budget Lock
    /// </summary>
    public enum BudgetLock
    {
        /// <summary>
        /// The unlocked
        /// </summary>
        [EnumValue("BudgetLock_Unlocked", typeof (EnumerationsResx))] Unlocked = 0,

        /// <summary>
        /// The locked
        /// </summary>
        [EnumValue("BudgetLock_Locked", typeof (EnumerationsResx))] Locked = 1
    }
}