﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Structure Code Delimiter
    /// </summary>
    public enum StructureCodeDelimiter
    {
        /// <summary>
        /// The hyphen
        /// </summary>
        [EnumValue("StructureCodeDelimiter_Hyphen", typeof (EnumerationsResx))] Hyphen = '-',

        /// <summary>
        /// The slash
        /// </summary>
        [EnumValue("StructureCodeDelimiter_Slash", typeof (EnumerationsResx))] Slash = '/',

        /// <summary>
        /// The backslash
        /// </summary>
        [EnumValue("StructureCodeDelimiter_Backslash", typeof (EnumerationsResx))] Backslash = '\\',

        /// <summary>
        /// The asterisk
        /// </summary>
        [EnumValue("StructureCodeDelimiter_Asterisk", typeof (EnumerationsResx))] Asterisk = '*',

        /// <summary>
        /// The period
        /// </summary>
        [EnumValue("StructureCodeDelimiter_Period", typeof (EnumerationsResx))] Period = '.'
    }
}