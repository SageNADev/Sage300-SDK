/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Default Access
    /// </summary>
    public enum DefaultAccess
    {
        /// <summary>
        /// All accounts
        /// </summary>
        [EnumValue("DefaultAccess_AllAccounts", typeof (EnumerationsResx))] AllAccounts = 0,

        /// <summary>
        /// The no accounts
        /// </summary>
        [EnumValue("DefaultAccess_NoAccounts", typeof (EnumerationsResx))] NoAccounts = 1
    }
}