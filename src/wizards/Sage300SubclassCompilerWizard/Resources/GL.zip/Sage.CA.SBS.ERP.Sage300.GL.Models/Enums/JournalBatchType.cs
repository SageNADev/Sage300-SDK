﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum JournalBatchType
    /// </summary>
    public enum JournalBatchType
    {
        /// <summary>
        /// The entered
        /// </summary>
        [EnumValue("JournalBatchType_Entered", typeof (EnumerationsResx))] Entered = 1,

        /// <summary>
        /// The subledger
        /// </summary>
        [EnumValue("JournalBatchType_Subledger", typeof (EnumerationsResx))] Subledger = 2,

        /// <summary>
        /// The imported
        /// </summary>
        [EnumValue("JournalBatchType_Imported", typeof (EnumerationsResx))] Imported = 3,

        /// <summary>
        /// The generated
        /// </summary>
        [EnumValue("JournalBatchType_Generated", typeof (EnumerationsResx))] Generated = 4,

        /// <summary>
        /// The recurring
        /// </summary>
        [EnumValue("JournalBatchType_Recurring", typeof (EnumerationsResx))] Recurring = 5
    }
}