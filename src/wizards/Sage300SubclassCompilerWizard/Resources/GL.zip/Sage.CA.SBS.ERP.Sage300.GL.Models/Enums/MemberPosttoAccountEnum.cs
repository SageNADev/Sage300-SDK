/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum MemberPosttoAccountEnum
    /// </summary>
    public enum MemberPosttoAccountEnum
    {
        /// <summary>
        /// The detail
        /// </summary>
        Detail = 0,

        /// <summary>
        /// The consolidated
        /// </summary>
        Consolidated = 1,

        /// <summary>
        /// The prohibited
        /// </summary>
        Prohibited = 2,
    }
}