﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum ActiveSwitch
    /// </summary>
    public enum ActiveSwitch
    {
        /// <summary>
        /// The inactive
        /// </summary>
        [EnumValue("MulticurrencyActivatedSwitch_Inactive", typeof(EnumerationsResx))]
        Inactive = 0,

        /// <summary>
        /// The active
        /// </summary>
        [EnumValue("MulticurrencyActivatedSwitch_Active", typeof(EnumerationsResx))]
        Active = 1,
    }
}