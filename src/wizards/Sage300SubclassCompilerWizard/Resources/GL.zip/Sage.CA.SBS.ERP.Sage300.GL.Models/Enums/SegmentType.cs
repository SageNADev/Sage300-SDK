/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Segment Type
    /// </summary>
    public enum SegmentType
    {
        /// <summary>
        /// The entity
        /// </summary>
        [EnumValue("SegmentType_Entity", typeof (EnumerationsResx))] Entity = 1,

        /// <summary>
        /// The account number
        /// </summary>
        [EnumValue("SegmentType_AccountNumber", typeof (EnumerationsResx))] AccountNumber = 2
    }
}