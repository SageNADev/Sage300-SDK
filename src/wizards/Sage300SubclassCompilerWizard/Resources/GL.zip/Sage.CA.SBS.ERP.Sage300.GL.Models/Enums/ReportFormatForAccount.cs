﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum ReportFormatForAccount
    /// </summary>
    public enum ReportFormatForAccount
    {
        /// <summary>
        /// The detail_ short form
        /// </summary>
        [EnumValue("ReportFormatForAccount_Detail_ShortForm", typeof (EnumerationsResx))] Detail_ShortForm = 1,

        /// <summary>
        /// The detail_ long form
        /// </summary>
        [EnumValue("ReportFormatForAccount_Detail_LongForm", typeof (EnumerationsResx))] Detail_LongForm = 2,

        /// <summary>
        /// The allocation
        /// </summary>
        [EnumValue("ReportFormatForAccount_Allocation", typeof (EnumerationsResx))] Allocation = 3,

        /// <summary>
        /// The control account subledgers
        /// </summary>
        [EnumValue("ReportFormatForAccount_ControlAccountSubledgers", typeof (EnumerationsResx))] ControlAccountSubledgers = 4,

        /// <summary>
        /// The fiscal set comparison
        /// </summary>
        [EnumValue("ReportFormatForAccount_FiscalSetComparison", typeof (EnumerationsResx))] FiscalSetComparison = 5,

        /// <summary>
        /// The roll up accounts
        /// </summary>
        [EnumValue("ReportFormatForAccount_RollupAccounts", typeof (EnumerationsResx))] RollUpAccounts = 6
    }
}