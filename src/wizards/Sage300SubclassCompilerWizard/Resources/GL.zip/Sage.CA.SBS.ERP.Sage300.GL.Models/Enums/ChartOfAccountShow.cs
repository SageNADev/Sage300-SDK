﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum ChartOfAccountShow
    /// </summary>
    public enum ChartOfAccountShow
    {
        /// <summary>
        /// The cap members
        /// </summary>
        [EnumValue("CapMembers", typeof (EnumerationsResx))] CapMembers = 0,

        /// <summary>
        /// The cap rollup accounts
        /// </summary>
        [EnumValue("CapRollupAccounts", typeof (EnumerationsResx))] CapRollupAccounts = 1
    }
}