/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for ActivitySwitch 
    /// </summary>
    public enum ActivitySwitch
    {
        /// <summary>
        /// Gets or sets Inactive.
        /// </summary>	
        Inactive = 0,

        /// <summary>
        /// Gets or sets PeriodsActive.
        /// </summary>	
        PeriodsActive = 1,

        /// <summary>
        /// Gets or sets BalanceForwardActive.
        /// </summary>	
        BalanceForwardActive = 2
    }
}