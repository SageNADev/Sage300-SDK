/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum AddOrDeleteEnum
    /// </summary>
    public enum AddOrDeleteEnum
    {
        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("Yes", typeof (EnumerationsResx))] Yes = 0,

        /// <summary>
        /// The no
        /// </summary>
        [EnumValue("No", typeof (EnumerationsResx))] No = 1,
    }
}