﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum FindProcessSwitch
    /// </summary>
    public enum FindProcessSwitch
    {
        /// <summary>
        /// The none
        /// </summary>
        None = 0,

        /// <summary>
        /// The refresh source ledger field
        /// </summary>
        RefreshSourceLedgerField = 2
    }
}