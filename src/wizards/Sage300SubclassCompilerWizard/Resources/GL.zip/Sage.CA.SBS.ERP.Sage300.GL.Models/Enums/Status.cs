﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Status
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// The inactive
        /// </summary>
        [EnumValue("Status_Inactive", typeof (EnumerationsResx))] Inactive = 0,

        /// <summary>
        /// The active
        /// </summary>
        [EnumValue("Status_Active", typeof (EnumerationsResx))] Active = 1
    }
}