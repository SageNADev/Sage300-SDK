﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum TrialBalanceReportFormat
    /// </summary>
    public enum TrialBalanceReportFormat
    {
        /// <summary>
        /// The RPT report
        /// </summary>
        [EnumValue("RptReport", typeof (EnumerationsResx))] RptReport = 1,

        /// <summary>
        /// The RPT work sheet
        /// </summary>
        [EnumValue("RptWorkSheet", typeof (EnumerationsResx))] RptWorkSheet = 2,

        /// <summary>
        /// The RPT qty
        /// </summary>
        [EnumValue("RptQty", typeof (EnumerationsResx))] RptQty = 3,

        /// <summary>
        /// The RPT prov qty
        /// </summary>
        [EnumValue("RptProvQty", typeof (EnumerationsResx))] RptProvQty = 4,

        /// <summary>
        /// The RPT prov incl
        /// </summary>
        [EnumValue("RptProvIncl", typeof (EnumerationsResx))] RptProvIncl = 5,

        /// <summary>
        /// The RPT prov sep
        /// </summary>
        [EnumValue("RptProvSep", typeof (EnumerationsResx))] RptProvSep = 6,

        /// <summary>
        /// The RPT prov ws
        /// </summary>
        [EnumValue("RptProvWS", typeof (EnumerationsResx))] RptProvWs = 7,
    }
}