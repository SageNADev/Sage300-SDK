﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum SortOrder
    /// </summary>
    public enum SortOrder
    {
        /// <summary>
        /// The account group order
        /// </summary>
        [EnumValue("AccountGroupOrder", typeof (EnumerationsResx))] AccountGroupOrder = 0,

        /// <summary>
        /// The new sort code
        /// </summary>
        [EnumValue("NewSortCode", typeof (EnumerationsResx))] NewSortCode = 1
    }
}