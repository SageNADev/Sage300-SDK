﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum TypeOfCurrency
    /// </summary>
    public enum TypeOfCurrency
    {
        /// <summary>
        /// The functional
        /// </summary>
        [EnumValue("Functional", typeof (EnumerationsResx))] Functional = 0,

        /// <summary>
        /// The source and functional
        /// </summary>
        [EnumValue("SourceandFunctional", typeof (GLCommonResx))] SourceAndFunctional = 1,
    }
}