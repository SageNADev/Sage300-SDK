/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum JournalDescriptionOption
    /// </summary>
    public enum JournalDescriptionOption
    {
        /// <summary>
        /// The original description
        /// </summary>
        OriginalDescription = 1,

        /// <summary>
        /// The originalwithprefix description
        /// </summary>
        OriginalwithprefixDescription = 2,

        /// <summary>
        /// The new description
        /// </summary>
        NewDescription = 3,
    }
}