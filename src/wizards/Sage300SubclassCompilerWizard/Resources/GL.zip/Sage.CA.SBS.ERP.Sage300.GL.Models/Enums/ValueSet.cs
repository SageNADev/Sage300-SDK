﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */


using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Optional Fields Value Set
    /// </summary>
    public enum ValueSet
    {
        /// <summary>
        /// Value Set No
        /// </summary>
        [EnumValue("AccountValueSet_No", typeof(EnumerationsResx))]
        No = 0,
        /// <summary>
        /// Value Set Yes
        /// </summary>
        [EnumValue("AccountValueSet_Yes", typeof(EnumerationsResx))]
        Yes = 1,

        ///// <summary>
        ///// Value Set NotApplicable
        ///// </summary>
        //[EnumValue("AccountValueSet_NotApplicable", typeof(EnumerationsResx))]
        //NotApplicable = 99,
    }
}
