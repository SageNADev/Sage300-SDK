// Copyright © 2016 Sage Software, Inc.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Forcerevaluationswitch
    /// </summary>
    public enum Forcerevaluationswitch
    {
        /// <summary>
        /// Gets or sets Revalueaccountswhichwishit
        /// </summary>
        [EnumValue("Revalueaccountswhichwishit", typeof(RevaluationDetailResx))]
        Revalueaccountswhichwishit = 0,

        /// <summary>
        /// Gets or sets Forceaccountswhichdonotwishit
        /// </summary>
        [EnumValue("Forceaccountswhichdonotwishit", typeof(RevaluationDetailResx))]
        Forceaccountswhichdonotwishit = 1

    }
}