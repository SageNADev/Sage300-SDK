﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum ErrorBatchCreatedSwitch
    /// </summary>
    public enum ErrorBatchCreatedSwitch
    {
        /// <summary>
        /// The errorbatchnotcreated
        /// </summary>
        Errorbatchnotcreated = 0,

        /// <summary>
        /// The errorbatchcreated
        /// </summary>
        Errorbatchcreated = 1,
    }
}