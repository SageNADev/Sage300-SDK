/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region references

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum For Account Optional Type
    /// </summary>
    public enum Type
    {
        #region enums

        /// <summary>
        /// Used to set Account Optional Type Text
        /// </summary>
        [EnumValue("AccountType_Text", typeof (EnumerationsResx))] Text = 1,

        /// <summary>
        /// Used to set Account Optional Type Number
        /// </summary>
        [EnumValue("AccountType_Number", typeof (EnumerationsResx))] Number = 6,

        /// <summary>
        /// Used to set Account Optional Type Integer
        /// </summary>
        [EnumValue("AccountType_Integer", typeof (EnumerationsResx))] Integer = 8,

        /// <summary>
        /// Used to set Account Optional Type YesOrNo
        /// </summary>
        [EnumValue("AccountType_YesOrNo", typeof (EnumerationsResx))] YesOrNo = 9,

        /// <summary>
        /// Used to set Account Optional Type Date
        /// </summary>
        [EnumValue("AccountType_Date", typeof (EnumerationsResx))] Date = 3,

        /// <summary>
        /// Used to set Account Optional Type Time
        /// </summary>
        [EnumValue("AccountType_Time", typeof (EnumerationsResx))] Time = 4,

        /// <summary>
        /// Gets or sets IncomeStatement 
        /// </summary>	
        IncomeStatement = 73,

        /// <summary>
        /// Gets or sets BalanceSheet 
        /// </summary>	
        BalanceSheet = 66,

        /// <summary>
        /// Gets or sets RetainedEarnings 
        /// </summary>	
        RetainedEarnings = 82,

        /// <summary>
        /// Used to set Account Optional Type Amount
        /// </summary>
        [EnumValue("AccountType_Amount", typeof (EnumerationsResx))] Amount = 100,

        #endregion
    }
}
