﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum ChartOfAccountFormat
    /// </summary>
    public enum ChartOfAccountFormat
    {
        /// <summary>
        /// The RPT short form
        /// </summary>
        [EnumValue("RptShortForm", typeof (EnumerationsResx))] RptShortForm = 0,

        /// <summary>
        /// The RPT long form
        /// </summary>
        [EnumValue("RptLongForm", typeof (EnumerationsResx))] RptLongForm = 1,

        /// <summary>
        /// The RPT valid currencies
        /// </summary>
        [EnumValue("ValidCurrencies", typeof (EnumerationsResx))] RptValidCurrencies = 2,

        /// <summary>
        /// The RPT allocation
        /// </summary>
        [EnumValue("RptAllocation", typeof (EnumerationsResx))] RptAllocation = 3,

        /// <summary>
        /// The RPT control account subledgers
        /// </summary>
        [EnumValue("ControlAccountSubledgers", typeof (EnumerationsResx))] RptControlAccountSubledgers = 4,

        /// <summary>
        /// The RPT fiscal set
        /// </summary>
        [EnumValue("RptFiscalSet", typeof (EnumerationsResx))] RptFiscalSet = 5,

        /// <summary>
        /// The RPT rollup accounts
        /// </summary>
        [EnumValue("RptRollupAccounts", typeof (EnumerationsResx))] RptRollupAccounts = 6
    }
}