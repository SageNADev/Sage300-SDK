﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Group Category
    /// </summary>
    public enum GroupCategory
    {
        /// <summary>
        /// The cashand cash equivalents
        /// </summary>
        [EnumValue("DefaultCategory", typeof(EnumerationsResx))]
        DefaultCategory = 0,

        /// <summary>
        /// The cashand cash equivalents
        /// </summary>
        [EnumValue("CashandCashEquivalents", typeof (EnumerationsResx))] CashandCashEquivalents = 10,

        /// <summary>
        /// The accounts receivable
        /// </summary>
        [EnumValue("AccountsReceivable", typeof (EnumerationsResx))] AccountsReceivable = 20,

        /// <summary>
        /// The inventory
        /// </summary>
        [EnumValue("Inventory", typeof (EnumerationsResx))] Inventory = 30,

        /// <summary>
        /// The other current assets
        /// </summary>
        [EnumValue("OtherCurrentAssets", typeof (EnumerationsResx))] OtherCurrentAssets = 40,

        /// <summary>
        /// The fixed assets
        /// </summary>
        [EnumValue("FixedAssets", typeof (EnumerationsResx))] FixedAssets = 50,

        /// <summary>
        /// The accumulated depreciation
        /// </summary>
        [EnumValue("AccumulatedDepreciation", typeof (EnumerationsResx))] AccumulatedDepreciation = 60,

        /// <summary>
        /// The other assets
        /// </summary>
        [EnumValue("OtherAssets", typeof (EnumerationsResx))] OtherAssets = 70,

        /// <summary>
        /// The accounts payable
        /// </summary>
        [EnumValue("AccountsPayable", typeof (EnumerationsResx))] AccountsPayable = 80,

        /// <summary>
        /// The other current liabilities
        /// </summary>
        [EnumValue("OtherCurrentLiabilities", typeof (EnumerationsResx))] OtherCurrentLiabilities = 90,

        /// <summary>
        /// The long term liabilities
        /// </summary>
        [EnumValue("LongTermLiabilities", typeof (EnumerationsResx))] LongTermLiabilities = 100,

        /// <summary>
        /// The other liabilities
        /// </summary>
        [EnumValue("OtherLiabilities", typeof (EnumerationsResx))] OtherLiabilities = 110,

        /// <summary>
        /// The share capital
        /// </summary>
        [EnumValue("ShareCapital", typeof (EnumerationsResx))] ShareCapital = 120,

        /// <summary>
        /// The shareholders equity
        /// </summary>
        [EnumValue("ShareholdersEquity", typeof (EnumerationsResx))] ShareholdersEquity = 130,

        /// <summary>
        /// The revenue
        /// </summary>
        [EnumValue("Revenue", typeof (EnumerationsResx))] Revenue = 140,

        /// <summary>
        /// The costof sales
        /// </summary>
        [EnumValue("CostofSales", typeof (EnumerationsResx))] CostofSales = 150,

        /// <summary>
        /// The other revenue
        /// </summary>
        [EnumValue("OtherRevenue", typeof (EnumerationsResx))] OtherRevenue = 160,

        /// <summary>
        /// The other expenses
        /// </summary>
        [EnumValue("OtherExpenses", typeof (EnumerationsResx))] OtherExpenses = 170,

        /// <summary>
        /// The depreciation expense
        /// </summary>
        [EnumValue("DepreciationExpense", typeof (EnumerationsResx))] DepreciationExpense = 180,

        /// <summary>
        /// The gains or losses
        /// </summary>
        [EnumValue("GainsOrLosses", typeof (EnumerationsResx))] GainsOrLosses = 190,

        /// <summary>
        /// The interest expense
        /// </summary>
        [EnumValue("InterestExpense", typeof (EnumerationsResx))] InterestExpense = 200,

        /// <summary>
        /// The income taxes
        /// </summary>
        [EnumValue("IncomeTaxes", typeof (EnumerationsResx))] IncomeTaxes = 210
    }
}