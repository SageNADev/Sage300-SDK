// Copyright © 2016 Sage Software, Inc.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Selectsegmenttype
    /// </summary>
    public enum Selectsegmenttype
    {
        /// <summary>
        /// Gets or sets Fullaccount
        /// </summary>
        [EnumValue("Fullaccount", typeof(RevaluationDetailResx))]
        Fullaccount = 1,

        /// <summary>
        /// Gets or sets Anysegment
        /// </summary>
        [EnumValue("Anysegment", typeof(RevaluationDetailResx))]
        Anysegment = 2

    }
}