﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum TypeOfSegment
    /// </summary>
    public enum TypeOfSegment
    {
        /// <summary>
        /// All segments
        /// </summary>
        [EnumValue("AllSegments ", typeof (EnumerationsResx))] AllSegments = 0,

        /// <summary>
        /// The specific segments
        /// </summary>
        [EnumValue("SpecificSegments ", typeof (EnumerationsResx))] SpecificSegments = 1,
    }
}