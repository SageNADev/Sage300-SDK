/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Revaluation Method
    /// </summary>
    public enum RevaluationMethod
    {
        /// <summary>
        /// The none
        /// </summary>
        [EnumValue("RevaluationMethod_None", typeof (EnumerationsResx))] None = 0,

        /// <summary>
        /// The unrealized gain and loss
        /// </summary>
        [EnumValue("RevaluationMethod_UnrealizedGainAndLoss", typeof (EnumerationsResx))] UnrealizedGainAndLoss = 1,

        /// <summary>
        /// The recognized gain and loss
        /// </summary>
        [EnumValue("RevaluationMethod_RecognizedGainAndLoss", typeof (EnumerationsResx))] RecognizedGainAndLoss = 2
    }
}