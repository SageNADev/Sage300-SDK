/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Maximum Account Structures
    /// </summary>
    public enum MaximumAccountStructures
    {
        /// <summary>
        /// The unlimited structures
        /// </summary>
        [EnumValue("MaximumAccountStructures_UnlimitedStructures", typeof (EnumerationsResx))] UnlimitedStructures = 0,

        /// <summary>
        /// The num3 structures
        /// </summary>
        [EnumValue("MaximumAccountStructures_3Structures", typeof (EnumerationsResx))] Num3Structures = 4,

        /// <summary>
        /// The num2 structures
        /// </summary>
        [EnumValue("MaximumAccountStructures_2Structures", typeof (EnumerationsResx))] Num2Structures = 3,
    }
}