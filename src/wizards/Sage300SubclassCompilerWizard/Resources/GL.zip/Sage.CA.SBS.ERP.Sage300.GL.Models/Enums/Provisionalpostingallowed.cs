/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Provisional posting allowed
    /// </summary>
    public enum ProvisionalPostingAllowed
    {
        /// <summary>
        /// The provisional posting not allowed
        /// </summary>
        [EnumValue("ProvisionalPostingAllowed_ProvisionalPostingNotAllowed", typeof (EnumerationsResx))] ProvisionalPostingNotAllowed = 0,

        /// <summary>
        /// The provisional posting allowed
        /// </summary>
        [EnumValue("ProvisionalPostingAllowed_ProvisionalPostingAllowed", typeof (EnumerationsResx))] ProvisionalPostingAllowed = 1
    }
}