﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum SortBy
    /// </summary>
    public enum SortBy
    {
        /// <summary>
        /// The account no
        /// </summary>
        [EnumValue("AccountNo", typeof (GLCommonResx))] AccountNo = 1,

        /// <summary>
        /// The segment
        /// </summary>
        [EnumValue("Segment", typeof (GLCommonResx))] Segment = 2,

        /// <summary>
        /// The account group
        /// </summary>
        [EnumValue("AccountSortedGroup", typeof (GLCommonResx))] AccountGroup = 3
    }
}