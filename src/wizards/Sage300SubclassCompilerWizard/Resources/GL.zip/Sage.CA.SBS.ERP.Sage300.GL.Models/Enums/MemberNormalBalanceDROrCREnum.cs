/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum MemberNormalBalanceDROrCREnum
    /// </summary>
    public enum MemberNormalBalanceDrOrCrEnum
    {
        /// <summary>
        /// The debit
        /// </summary>
        Debit = 1,

        /// <summary>
        /// The credit
        /// </summary>
        Credit = 2,
    }
}