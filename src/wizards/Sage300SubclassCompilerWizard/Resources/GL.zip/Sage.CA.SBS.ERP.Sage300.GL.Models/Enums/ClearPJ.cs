﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for ClearPJ
    /// </summary>
    public enum ClearPJ
    {
        /// <summary>
        /// The mark journals
        /// </summary>
        [EnumValue("ClearPJ_MarkJournals", typeof (EnumerationsResx))] MarkJournals = 0,

        /// <summary>
        /// The printed journals
        /// </summary>
        [EnumValue("ClearPJ_PrintedJournals", typeof (EnumerationsResx))] PrintedJournals = 1,
    }
}