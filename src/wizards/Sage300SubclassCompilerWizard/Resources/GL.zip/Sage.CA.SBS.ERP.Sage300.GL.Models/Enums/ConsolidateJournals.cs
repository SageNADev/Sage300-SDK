// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for ConsolidateJournals
    /// </summary>
    public enum ConsolidateJournals
    {
        /// <summary>
        /// Gets or sets Detail
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Detail", typeof(EnumerationsResx))]
        Detail = 0,

        /// <summary>
        /// Gets or sets Consolidated
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("AccountPosttoAccount_Consolidated", typeof(GL.Resources.EnumerationsResx))]
        Consolidated = 1,

        /// <summary>
        /// Gets or sets Prohibited
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("AccountPosttoAccount_Prohibited", typeof(GL.Resources.EnumerationsResx))]
        Prohibited = 2
    }
}
