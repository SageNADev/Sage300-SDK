/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum RevaluationSwitch
    /// </summary>
    public enum RevaluationSwitch
    {
        /// <summary>
        /// The donotrevalue
        /// </summary>
        [EnumValue("RevaluationSwitch_Donotrevalue", typeof (EnumerationsResx))] Donotrevalue = 0,

        /// <summary>
        /// The revalue
        /// </summary>
        [EnumValue("RevaluationSwitch_Revalue", typeof (EnumerationsResx))] Revalue = 1,
    }
}