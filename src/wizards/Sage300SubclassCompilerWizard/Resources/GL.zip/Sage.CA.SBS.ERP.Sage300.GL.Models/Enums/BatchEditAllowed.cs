/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Batch Edit Allowed
    /// </summary>
    public enum BatchEditAllowed
    {
        /// <summary>
        /// All fields
        /// </summary>
        [EnumValue("BatchEditAllowed_AllFields", typeof (EnumerationsResx))] AllFields = 1,

        /// <summary>
        /// The fiscal period year trans date
        /// </summary>
        [EnumValue("BatchEditAllowed_FiscalPeriodYearTransDate", typeof (EnumerationsResx))] FiscalPeriodYearTransDate =
            2,

        /// <summary>
        /// The no edit
        /// </summary>
        [EnumValue("BatchEditAllowed_NoEdit", typeof (EnumerationsResx))] NoEdit = 3
    }
}