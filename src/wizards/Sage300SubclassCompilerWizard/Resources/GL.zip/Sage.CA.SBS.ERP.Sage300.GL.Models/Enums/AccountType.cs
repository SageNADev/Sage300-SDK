﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Account Type
    /// </summary>
    public enum AccountType
    {
        /// <summary>
        /// Used to Set Account Type is IncomeStatement
        /// </summary>
        [StoredAsChar]
        [EnumValue("AccountType_IncomeStatement", typeof(EnumerationsResx), 1)]
        IncomeStatement = 'I',

        /// <summary>
        /// Used to Set Account Type is BalanceSheet
        /// </summary>
        [StoredAsChar]
        [EnumValue("AccountType_BalanceSheet", typeof(EnumerationsResx), 2)]
        BalanceSheet = 'B',

        /// <summary>
        /// Used to Set Account Type is RetainedEarnings
        /// </summary>
        [StoredAsChar]
        [EnumValue("AccountType_RetainedEarnings", typeof(EnumerationsResx), 3)]
        RetainedEarnings = 'R'
    }
}