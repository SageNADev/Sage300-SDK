﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for RevalueBy
    /// </summary>
    public enum RevalueBy
    {
        /// <summary>
        /// The balances
        /// </summary>
        [EnumValue("RevalueBy_Balances", typeof(EnumerationsResx))]
        Balances = 0,

        /// <summary>
        /// The net changes
        /// </summary>
        [EnumValue("RevalueBy_NetChanges", typeof(EnumerationsResx))]
        NetChanges = 1,
    }
}