﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum ProvisionalPostSwitch
    /// </summary>
    public enum ProvisionalPostSwitch
    {
        /// <summary>
        /// The actual post
        /// </summary>
        ActualPost = 0,

        /// <summary>
        /// The provisional post
        /// </summary>
        ProvisionalPost = 1,
    }
}