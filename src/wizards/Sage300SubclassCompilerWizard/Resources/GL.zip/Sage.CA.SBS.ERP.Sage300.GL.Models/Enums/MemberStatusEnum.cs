/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum MemberStatusEnum
    /// </summary>
    public enum MemberStatusEnum
    {
        /// <summary>
        /// The inactive
        /// </summary>
        Inactive = 0,

        /// <summary>
        /// The active
        /// </summary>
        Active = 1,
    }
}