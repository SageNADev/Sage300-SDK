/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum MemberAccountRollupSwitchEnum
    /// </summary>
    public enum MemberAccountRollupSwitchEnum
    {
        /// <summary>
        /// The no
        /// </summary>
        No = 0,

        /// <summary>
        /// The yes
        /// </summary>
        Yes = 1,
    }
}