﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum Revaluation Switch
    /// </summary>
    public enum Revaluation
    {
        /// <summary>
        /// The donotrevalue
        /// </summary>
        [EnumValue("RevaluationSwitch_Donotrevalue1", typeof(EnumerationsResx))]
        Donotrevalue = 0,

        /// <summary>
        /// The revalue
        /// </summary>
        [EnumValue("RevaluationSwitch_Revalue1", typeof(EnumerationsResx))]
        Revalue = 1,
    }
}
