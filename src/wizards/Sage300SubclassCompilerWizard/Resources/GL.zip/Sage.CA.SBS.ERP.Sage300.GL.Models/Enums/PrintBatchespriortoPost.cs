/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Print Batches Prior To Post
    /// </summary>
    public enum PrintBatchesPriorToPost
    {
        /// <summary>
        /// The printing not required
        /// </summary>
        [EnumValue("PrintBatchesPriorToPost_PrintingNotRequired", typeof (EnumerationsResx))] PrintingNotRequired = 0,

        /// <summary>
        /// The printing required
        /// </summary>
        [EnumValue("PrintBatchesPriorToPost_PrintingRequired", typeof (EnumerationsResx))] PrintingRequired = 1
    }
}