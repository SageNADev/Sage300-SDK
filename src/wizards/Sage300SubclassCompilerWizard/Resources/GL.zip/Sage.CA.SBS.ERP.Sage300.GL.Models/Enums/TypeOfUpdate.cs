// Copyright (c) 2020 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for TypeOfUpdate
    /// </summary>
    public enum TypeOfUpdate
    {
        /// <summary>
        /// Gets or sets AddTo
        /// </summary>
        [EnumValue("AddTo", typeof(AccountBudgetCalculatorResx))]
        AddTo = 1,
        /// <summary>
        /// Gets or sets Replace
        /// </summary>
        [EnumValue("Replace", typeof(AccountBudgetCalculatorResx))]
        Replace = 2
    }
}