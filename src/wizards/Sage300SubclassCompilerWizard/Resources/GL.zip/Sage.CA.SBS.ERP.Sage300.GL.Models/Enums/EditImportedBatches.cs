/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    public enum EditImportedBatches
    {
        No = 0,
        Yes = 1
    }
}
