/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum FiscalSetAllowSpecificCurrenciesSwitch
    /// </summary>
    public enum FiscalSetAllowSpecificCurrenciesSwitch
    {
        /// <summary>
        /// All currencies
        /// </summary>
        [EnumValue("AllCurrencies", typeof (EnumerationsResx))] AllCurrencies = 0,

        /// <summary>
        /// The specific currencies
        /// </summary>
        [EnumValue("SpecificCurrencies", typeof (EnumerationsResx))] SpecificCurrencies = 1,
    }
}