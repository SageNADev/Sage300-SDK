﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum SegmentName
    /// </summary>
    public enum SegmentName
    {
        /// <summary>
        /// The account
        /// </summary>
        [EnumValue("Segment_Account", typeof (EnumerationsResx))] Account = 1,

        /// <summary>
        /// The division
        /// </summary>
        [EnumValue("Segment_Division", typeof (EnumerationsResx))] Division = 2,

        /// <summary>
        /// The region
        /// </summary>
        [EnumValue("Segment_Region", typeof (EnumerationsResx))] Region = 3
    }
}