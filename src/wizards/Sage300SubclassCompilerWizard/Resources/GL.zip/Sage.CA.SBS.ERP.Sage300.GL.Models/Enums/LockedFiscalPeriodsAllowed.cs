/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Locked Fiscal Periods Allowed
    /// </summary>
    public enum LockedFiscalPeriodsAllowed
    {
        /// <summary>
        /// The okay
        /// </summary>
        [EnumValue("LockedFiscalPeriodsAllowed_Okay", typeof (EnumerationsResx))] Okay = 0,

        /// <summary>
        /// The warning
        /// </summary>
        [EnumValue("LockedFiscalPeriodsAllowed_Warning", typeof (EnumerationsResx))] Warning = 1,

        /// <summary>
        /// The error
        /// </summary>
        [EnumValue("LockedFiscalPeriodsAllowed_Error", typeof (EnumerationsResx))] Error = 2
    }
}