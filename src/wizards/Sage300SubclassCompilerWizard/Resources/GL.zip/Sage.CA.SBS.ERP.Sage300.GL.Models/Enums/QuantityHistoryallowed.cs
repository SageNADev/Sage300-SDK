/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Quantity History allowed
    /// </summary>
    public enum QuantityHistoryAllowed
    {
        /// <summary>
        /// The do not allow quantities
        /// </summary>
        [EnumValue("QuantityHistoryAllowed_DoNotAllowQuantities", typeof (EnumerationsResx))] DoNotAllowQuantities = 0,

        /// <summary>
        /// The quantities allowed
        /// </summary>
        [EnumValue("QuantityHistoryAllowed_QuantitiesAllowed", typeof (EnumerationsResx))] QuantitiesAllowed = 1
    }
}