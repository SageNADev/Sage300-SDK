/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum MemberAccountTypeEnum
    /// </summary>
    public enum MemberAccountTypeEnum
    {
        /// <summary>
        /// The income statement
        /// </summary>
        IncomeStatement = 'I',

        /// <summary>
        /// The balance sheet
        /// </summary>
        BalanceSheet = 'B',

        /// <summary>
        /// The retained earnings
        /// </summary>
        RetainedEarnings = 'R',
    }
}