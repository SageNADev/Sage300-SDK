﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for Account Segment Type
    /// </summary>
    public enum AccountSegmentS500
    {
        /// <summary>
        /// The one
        /// </summary>
        [EnumValue("AccountSegmentS500_One", typeof (EnumerationsResx))] One = 1,

        /// <summary>
        /// The two
        /// </summary>
        [EnumValue("AccountSegmentS500_Two", typeof (EnumerationsResx))] Two = 2,

        /// <summary>
        /// The three
        /// </summary>
        [EnumValue("AccountSegmentS500_Three", typeof (EnumerationsResx))] Three = 3,

        /// <summary>
        /// The four
        /// </summary>
        [EnumValue("AccountSegmentS500_Four", typeof (EnumerationsResx))] Four = 4,

        /// <summary>
        /// The five
        /// </summary>
        [EnumValue("AccountSegmentS500_Five", typeof (EnumerationsResx))] Five = 5,

        /// <summary>
        /// The six
        /// </summary>
        [EnumValue("AccountSegmentS500_Six", typeof (EnumerationsResx))] Six = 6,

        /// <summary>
        /// The seven
        /// </summary>
        [EnumValue("AccountSegmentS500_Seven", typeof (EnumerationsResx))] Seven = 7,

        /// <summary>
        /// The eight
        /// </summary>
        [EnumValue("AccountSegmentS500_Eight", typeof (EnumerationsResx))] Eight = 8,

        /// <summary>
        /// The nine
        /// </summary>
        [EnumValue("AccountSegmentS500_Nine", typeof (EnumerationsResx))] Nine = 9,

        /// <summary>
        /// The ten
        /// </summary>
        [EnumValue("AccountSegmentS500_Ten", typeof (EnumerationsResx))] Ten = 10
    }
}