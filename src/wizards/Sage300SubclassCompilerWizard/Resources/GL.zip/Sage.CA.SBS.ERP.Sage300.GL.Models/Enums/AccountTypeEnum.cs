/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum AccountTypeEnum
    /// </summary>
    public enum AccountTypeEnum
    {
        /// <summary>
        /// Used to Set Account Type is IncomeStatement
        /// </summary>
        [EnumValue("AccountType_IncomeStatement", typeof (EnumerationsResx))] IncomeStatement = 73,

        /// <summary>
        /// Used to Set Account Type is BalanceSheet
        /// </summary>
        [EnumValue("AccountType_BalanceSheet", typeof (EnumerationsResx))] BalanceSheet = 66,

        /// <summary>
        /// Used to Set Account Type is RetainedEarnings
        /// </summary>
        [EnumValue("AccountType_RetainedEarnings", typeof (EnumerationsResx))] RetainedEarnings = 82,
    }
}