/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum FiscalSetProcessasytdbalancesSwitch
    /// </summary>
    public enum FiscalSetProcessasytdbalancesSwitch
    {
        /// <summary>
        /// The balances
        /// </summary>
        [EnumValue("Balance", typeof(FiscalSetComparisonResx))]
        Balances = 0,

        /// <summary>
        /// The net changes
        /// </summary>
        [EnumValue("NetChange", typeof(FiscalSetComparisonResx))]
        NetChanges = 1,
    }
}