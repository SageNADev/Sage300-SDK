/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// AccountGroups-SortOrder Process Command
    /// </summary>
    public enum ProcessCommandAccountGroups
    {
        /// <summary>
        /// The copy account groups
        /// </summary>
        CopyAccountGroups = 0,

        /// <summary>
        /// The update account group
        /// </summary>
        UpdateAccountGroup = 1,
    }
}