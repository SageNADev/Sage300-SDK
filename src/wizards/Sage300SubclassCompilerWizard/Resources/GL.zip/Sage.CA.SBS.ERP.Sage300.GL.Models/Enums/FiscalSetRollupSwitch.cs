/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum FiscalSetRollupSwitch
    /// </summary>
    public enum FiscalSetRollupSwitch
    {
        /// <summary>
        /// The no
        /// </summary>
        [EnumValue("No", typeof (EnumerationsResx))] No = 0,

        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("Yes", typeof (EnumerationsResx))] Yes = 1,

        /// <summary>
        /// The rollupin f rmode
        /// </summary>
        [EnumValue("RollupinFRmode", typeof (EnumerationsResx))] RollupinFRmode = 9,
    }
}