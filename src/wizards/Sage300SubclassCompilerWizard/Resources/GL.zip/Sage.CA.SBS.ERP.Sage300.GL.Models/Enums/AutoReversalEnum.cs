﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for AutoReversalEnum
    /// </summary>
    public enum AutoReversalEnum
    {
        /// <summary>
        /// The automatic reversal off
        /// </summary>
        [EnumValue("AutoReversalEnum_ AutoReversalOff ", typeof (EnumerationsResx))] AutoReversalOff = 0,

        /// <summary>
        /// The next period
        /// </summary>
        [EnumValue("AutoReversalEnum_ NextPeriod ", typeof (EnumerationsResx))] NextPeriod = 1,

        /// <summary>
        /// The specific period
        /// </summary>
        [EnumValue("AutoReversalEnum_  SpecificPeriod  ", typeof (EnumerationsResx))] SpecificPeriod = 2,
    }
}