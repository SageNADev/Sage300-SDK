﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.ExportImport
{
    /// <summary>
    /// Enum for Account Switch
    /// </summary>
    public enum AccountExportOptions
    {
        /// <summary>
        /// Used to Set Account Type is BasicAccountProfile
        /// </summary>
        [EnumValue("Basic_Account_Profile", typeof(EnumerationsResx), 1)]
        BasicAccountProfile = 1,

        /// <summary>
        /// Used to Set Account Type is AllocationInstruction
        /// </summary>
        [EnumValue("Allocation_Instruction", typeof(EnumerationsResx), 2)]
        AllocationInstruction = 2,

        /// <summary>
        /// Used to Set Account Type is ValidCurrencyCodes
        /// </summary>
        [EnumValue("Valid_Currency_Codes", typeof(EnumerationsResx), 3)]
        ValidCurrencyCodes = 3,

        /// <summary>
        /// Used to Set Account Type is ControlAccountSubledger
        /// </summary>
        [EnumValue("Control_Account_Subledger", typeof(EnumerationsResx), 4)]
        ControlAccountSubledger = 4,

        /// <summary>
        /// Used to Set Account Type is Rollup
        /// </summary>
        [EnumValue("Rollup", typeof(EnumerationsResx), 5)]
        Rollup = 5,

        /// <summary>
        /// Used to Set Account Type is OptionalFields
        /// </summary>
        [EnumValue("Optional_Fields", typeof(EnumerationsResx), 6)]
        OptionalFields = 6,
    }
}
