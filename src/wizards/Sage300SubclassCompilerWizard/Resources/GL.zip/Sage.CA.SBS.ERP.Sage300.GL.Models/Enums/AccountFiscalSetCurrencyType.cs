/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Enums
{
    /// <summary>
    /// Enum for AccountFiscalSetCurrencyType (used by Account Fiscal Sets). Not to be
    /// confused with CurrencyType or FiscalSetCurrencyType.
    /// </summary>
    public enum AccountFiscalSetCurrencyType
    {
        /// <summary>
        /// Gets or sets Source.
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("Source", typeof(EnumerationsResx))]
        Source = 0,

        /// <summary>
        /// Gets or sets Equivalent.
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("Equivalent", typeof(EnumerationsResx))]
        Equivalent = 1,

        /// <summary>
        /// Gets or sets Functional.
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("Functional", typeof(EnumerationsResx))]
        Functional = 2
    }
}