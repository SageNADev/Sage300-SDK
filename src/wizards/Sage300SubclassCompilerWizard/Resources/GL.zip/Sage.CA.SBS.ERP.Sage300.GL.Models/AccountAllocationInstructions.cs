/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class AccountAllocationInstructions.
    /// </summary>
    public partial class AccountAllocationInstructions : ModelBase
    {
        /// <summary>
        /// Gets or sets Account
        /// </summary>
        /// <value>The account.</value>
        [Display(Name = "Account", ResourceType = typeof(AccountsResx))]
        [Key]
        [ViewField(Name = Fields.Account, Id = Index.Account, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Account { get; set; }

        /// <summary>
        /// Gets or sets DistributionAccount
        /// </summary>
        /// <value>The distribution account.</value>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionAccount", ResourceType = typeof(AccountsResx))]
        [Key]
        [ViewField(Name = Fields.DistributionAccount, Id = Index.DistributionAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DistributionAccount { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        /// <value>The description.</value>
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets JournalReference
        /// </summary>
        /// <value>The journal reference.</value>
        [Display(Name = "Reference", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.JournalReference, Id = Index.JournalReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string JournalReference { get; set; }

        /// <summary>
        /// Gets or sets AllocationPercent
        /// </summary>
        /// <value>The allocation percent.</value>
        [Display(Name = "AllocationPercent", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.AllocationPercent, Id = Index.AllocationPercent, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal AllocationPercent { get; set; }

        /// <summary>
        /// </summary>
        /// <value>The account description.</value>
        [Display(Name = "Description", ResourceType = typeof(AccountsResx))]
        public string AccountDescription { get; set; }

        /// <summary>
        ///  Gets or sets PageNumber 
        /// </summary>
        public int PageNumber { get; set; }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        /// <value>The serial number.</value>
        public long SerialNumber { get; set; }
    }
}
