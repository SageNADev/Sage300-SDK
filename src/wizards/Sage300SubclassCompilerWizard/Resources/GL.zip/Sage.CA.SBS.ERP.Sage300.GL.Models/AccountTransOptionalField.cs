// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for AccountTransOptionalField
    /// </summary>
    public partial class AccountTransOptionalField : ModelBase
    {
        /// <summary>
        /// Gets or sets UnformattedAccount
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedAccount", ResourceType = typeof(CreateAccountPreviewResx))]
        [ViewField(Name = Fields.UnformattedAccount, Id = Index.UnformattedAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnformattedAccount { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets DefaultValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultValue, Id = Index.DefaultValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultValue { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public GL.Models.Enums.Process.Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public Validate Validate { get; set; }

        /// <summary>
        /// Gets or sets AutoInsert
        /// </summary>
        [Display(Name = "AutoInsert", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AutoInsert, Id = Index.AutoInsert, FieldType = EntityFieldType.Int, Size = 2)]
        public AutoInsert AutoInsert { get; set; }

        /// <summary>
        /// Gets or sets Required
        /// </summary>
        [Display(Name = "RequiredLegend", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Required, Id = Index.Required, FieldType = EntityFieldType.Int, Size = 2)]
        public Required Required { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets TypedDefaultValueFieldIndex
        /// </summary>
        [Display(Name = "TypedDefaultValueFieldIndex", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TypedDefaultValueFieldIndex, Id = Index.TypedDefaultValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedDefaultValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets DefaultTextValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultTextValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTextValue, Id = Index.DefaultTextValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultTextValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultAmountValue
        /// </summary>
        [Display(Name = "DefaultAmountValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultAmountValue, Id = Index.DefaultAmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DefaultAmountValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultNumberValue
        /// </summary>
        [Display(Name = "DefaultNumberValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultNumberValue, Id = Index.DefaultNumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DefaultNumberValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultIntegerValue
        /// </summary>
        [Display(Name = "DefaultIntegerValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultIntegerValue, Id = Index.DefaultIntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long DefaultIntegerValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultYesNoValue
        /// </summary>
        [Display(Name = "DefaultYesOrNoValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultYesNoValue, Id = Index.DefaultYesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public YesNoValue DefaultYesNoValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultDateValue
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultDateValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultDateValue, Id = Index.DefaultDateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DefaultDateValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultTimeValue
        /// </summary>
        [Display(Name = "DefaultTimeValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTimeValue, Id = Index.DefaultTimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime DefaultTimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ValueDescription", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Type string value
        /// </summary>
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets AllowBlank string value
        /// </summary>
        public string AllowBlankString
        {
            get { return EnumUtility.GetStringValue(AllowBlank); }
        }

        /// <summary>
        /// Gets Validate string value
        /// </summary>
        public string ValidateString
        {
            get { return EnumUtility.GetStringValue(Validate); }
        }

        /// <summary>
        /// Gets AutoInsert string value
        /// </summary>
        public string AutoInsertString
        {
            get { return EnumUtility.GetStringValue(AutoInsert); }
        }

        /// <summary>
        /// Gets Required string value
        /// </summary>
        public string RequiredString
        {
            get { return EnumUtility.GetStringValue(Required); }
        }

        /// <summary>
        /// Gets ValueSet string value
        /// </summary>
        public string ValueSetString
        {
            get { return EnumUtility.GetStringValue(ValueSet); }
        }

        /// <summary>
        /// Gets DefaultYesNoValue string value
        /// </summary>
        public string DefaultYesNoValueString
        {
            get { return EnumUtility.GetStringValue(DefaultYesNoValue); }
        }

        #endregion
    }
}
