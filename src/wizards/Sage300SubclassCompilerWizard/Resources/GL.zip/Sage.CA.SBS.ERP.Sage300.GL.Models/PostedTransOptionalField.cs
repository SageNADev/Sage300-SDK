// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for PostedTransOptionalField
    /// </summary>
    public partial class PostedTransOptionalField : ModelBase
    {
        /// <summary>
        /// Gets or sets AccountNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountNumber", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets Fiscalyear
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fiscalyear", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.Fiscalyear, Id = Index.Fiscalyear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string Fiscalyear { get; set; }

        /// <summary>
        /// Gets or sets Fiscalperiod
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fiscalperiod", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.Fiscalperiod, Id = Index.Fiscalperiod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string Fiscalperiod { get; set; }

        /// <summary>
        /// Gets or sets Sourcecurrencycode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sourcecurrencycode", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.Sourcecurrencycode, Id = Index.Sourcecurrencycode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Sourcecurrencycode { get; set; }

        /// <summary>
        /// Gets or sets SourceLedgerCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceLedgerCode", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.SourceLedgerCode, Id = Index.SourceLedgerCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedgerCode { get; set; }

        /// <summary>
        /// Gets or sets SourceTypeCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceTypeCode", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.SourceTypeCode, Id = Index.SourceTypeCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceTypeCode { get; set; }

        /// <summary>
        /// Gets or sets Postingsequencenumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Postingsequencenumber", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.Postingsequencenumber, Id = Index.Postingsequencenumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Postingsequencenumber { get; set; }

        /// <summary>
        /// Gets or sets Detailcount
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Detailcount", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.Detailcount, Id = Index.Detailcount, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal Detailcount { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Value
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Value", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process.Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public Validate Validate { get; set; }

        /// <summary>
        /// Gets or sets TypedValueFieldIndex
        /// </summary>
        [Display(Name = "TypedValueFieldIndex", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets TextValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TextValue", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string TextValue { get; set; }

        /// <summary>
        /// Gets or sets AmountValue
        /// </summary>
        [Display(Name = "AmountValue", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountValue { get; set; }

        /// <summary>
        /// Gets or sets NumberValue
        /// </summary>
        [Display(Name = "NumberValue", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NumberValue { get; set; }

        /// <summary>
        /// Gets or sets IntegerValue
        /// </summary>
        [Display(Name = "IntegerValue", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long IntegerValue { get; set; }

        /// <summary>
        /// Gets or sets YesNoValue
        /// </summary>
        [Display(Name = "YesNoValue", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.YesNoValue, Id = Index.YesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public YesNoValue YesNoValue { get; set; }

        /// <summary>
        /// Gets or sets DateValue
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateValue", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateValue { get; set; }

        /// <summary>
        /// Gets or sets TimeValue
        /// </summary>
        [Display(Name = "TimeValue", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan TimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ValueDescription", ResourceType = typeof(PostedTransOptionalFieldResx))]
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }

        [IgnoreExportImport]
        public ValueSet ValueSet { get { return ValueSet.Yes; } }

        /// <summary>
        /// To get the string of ValueSet property
        /// </summary>
        [IgnoreExportImport]
        public string ValueSetString { get { return EnumUtility.GetStringValue(ValueSet); } }

        /// <summary>
        /// Fake a Items list for optional field list
        /// </summary>
        [IgnoreExportImport]
        public IEnumerable<PostedTransOptionalField> Items { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Type string value
        /// </summary>
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets AllowBlank string value
        /// </summary>
        public string AllowBlankString
        {
            get { return EnumUtility.GetStringValue(AllowBlank); }
        }

        /// <summary>
        /// Gets Validate string value
        /// </summary>
        public string ValidateString
        {
            get { return EnumUtility.GetStringValue(Validate); }
        }

        /// <summary>
        /// Gets YesNoValue string value
        /// </summary>
        public string YesNoValueString
        {
            get { return EnumUtility.GetStringValue(YesNoValue); }
        }

        #endregion
    }

}
