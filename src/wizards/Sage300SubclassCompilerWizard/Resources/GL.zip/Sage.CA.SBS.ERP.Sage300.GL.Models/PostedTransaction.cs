// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
	/// <summary>
	/// Partial class for PostedTransaction
	/// </summary>
	public partial class PostedTransaction : ModelBase
	{

        public PostedTransaction()
        {          
            //relatedAccount = new Account();
        }

		/// <summary>
		/// Gets or sets AccountNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[ForeignKey("relatedAccount")]
		[ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
		public string AccountNumber {get; set;}

        //[Display(Name = "relatedAccounts")]
        public virtual Account relatedAccount { get; set; }

		/// <summary>
		/// Gets or sets FiscalYear
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
		public string FiscalYear {get; set;}

		/// <summary>
		/// Gets or sets FiscalPeriod
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
		public string FiscalPeriod {get; set;}

		// TODO: The naming convention of this property has to be manually evaluated
		/// <summary>
		/// Gets or sets SRCECURN
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.SRCECURN, Id = Index.SRCECURN, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string SRCECURN {get; set;}

		/// <summary>
		/// Gets or sets SourceLedgerCode
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.SourceLedgerCode, Id = Index.SourceLedgerCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
		public string SourceLedgerCode {get; set;}

		/// <summary>
		/// Gets or sets SourceTypeCode
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.SourceTypeCode, Id = Index.SourceTypeCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string SourceTypeCode {get; set;}

		/// <summary>
		/// Gets or sets PostingSequenceNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.PostingSequenceNumber, Id = Index.PostingSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
		public decimal PostingSequenceNumber {get; set;}

		/// <summary>
		/// Gets or sets DetailCount
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DetailCount, Id = Index.DetailCount, FieldType = EntityFieldType.Decimal, Size = 4)]
		public decimal DetailCount {get; set;}

		/// <summary>
		/// Gets or sets JournalDate
		/// </summary>
		[ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.JournalDate, Id = Index.JournalDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime JournalDate {get; set;}

		/// <summary>
		/// Gets or sets BatchNumber
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
		public string BatchNumber {get; set;}

		/// <summary>
		/// Gets or sets JournalEntryNumber
		/// </summary>
		[StringLength(5, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.JournalEntryNumber, Id = Index.JournalEntryNumber, FieldType = EntityFieldType.Char, Size = 5, Mask = "%05D")]
		public string JournalEntryNumber {get; set;}

		/// <summary>
		/// Gets or sets JournalTransactionNumber
		/// </summary>
		[ViewField(Name = Fields.JournalTransactionNumber, Id = Index.JournalTransactionNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
		public decimal JournalTransactionNumber {get; set;}

		/// <summary>
		/// Gets or sets ConsolidationOccurredonPost
		/// </summary>
		[ViewField(Name = Fields.ConsolidationOccurredonPost, Id = Index.ConsolidationOccurredonPost, FieldType = EntityFieldType.Int, Size = 2)]
		public ConsolidationOccurredOnPost ConsolidationOccurredonPost {get; set;}

		/// <summary>
		/// Gets or sets CompanyID
		/// </summary>
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CompanyID, Id = Index.CompanyID, FieldType = EntityFieldType.Char, Size = 8)]
		public string CompanyID {get; set;}

		/// <summary>
		/// Gets or sets JournalDetailDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.JournalDetailDescription, Id = Index.JournalDetailDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string JournalDetailDescription {get; set;}

		/// <summary>
		/// Gets or sets JournalDetailReference
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.JournalDetailReference, Id = Index.JournalDetailReference, FieldType = EntityFieldType.Char, Size = 60)]
		public string JournalDetailReference {get; set;}

		/// <summary>
		/// Gets or sets JournalTransactionAmount
		/// </summary>
		[ViewField(Name = Fields.JournalTransactionAmount, Id = Index.JournalTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal JournalTransactionAmount {get; set;}

		/// <summary>
		/// Gets or sets JournalTransactionQuantity
		/// </summary>
		[ViewField(Name = Fields.JournalTransactionQuantity, Id = Index.JournalTransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal JournalTransactionQuantity {get; set;}

		/// <summary>
		/// Gets or sets NbrOfSourceCurrencyDecimals
		/// </summary>
		[StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.NbrOfSourceCurrencyDecimals, Id = Index.NbrOfSourceCurrencyDecimals, FieldType = EntityFieldType.Char, Size = 1)]
		public string NbrOfSourceCurrencyDecimals {get; set;}

		/// <summary>
		/// Gets or sets SourceCurrencyAmount
		/// </summary>
		[ViewField(Name = Fields.SourceCurrencyAmount, Id = Index.SourceCurrencyAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal SourceCurrencyAmount {get; set;}

		/// <summary>
		/// Gets or sets HomeCurrencyCode
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.HomeCurrencyCode, Id = Index.HomeCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string HomeCurrencyCode {get; set;}

		/// <summary>
		/// Gets or sets CurrencyRateTableType
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CurrencyRateTableType, Id = Index.CurrencyRateTableType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string CurrencyRateTableType {get; set;}

		// TODO: The naming convention of this property has to be manually evaluated
		/// <summary>
		/// Gets or sets SCURNCODE
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.SCURNCODE, Id = Index.SCURNCODE, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string SCURNCODE {get; set;}

		/// <summary>
		/// Gets or sets DateOfCurrencyRateSelected
		/// </summary>
		[ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DateOfCurrencyRateSelected, Id = Index.DateOfCurrencyRateSelected, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateOfCurrencyRateSelected {get; set;}

		/// <summary>
		/// Gets or sets CurrencyRateForConversion
		/// </summary>
		[ViewField(Name = Fields.CurrencyRateForConversion, Id = Index.CurrencyRateForConversion, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal CurrencyRateForConversion {get; set;}

		/// <summary>
		/// Gets or sets CurrencyRateSpreadAllowed
		/// </summary>
		[ViewField(Name = Fields.CurrencyRateSpreadAllowed, Id = Index.CurrencyRateSpreadAllowed, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal CurrencyRateSpreadAllowed {get; set;}

		/// <summary>
		/// Gets or sets CodeForRateDateMatching
		/// </summary>
		[StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CodeForRateDateMatching, Id = Index.CodeForRateDateMatching, FieldType = EntityFieldType.Char, Size = 1)]
		public string CodeForRateDateMatching {get; set;}

		/// <summary>
		/// Gets or sets CurrencyRateOperator
		/// </summary>
		[StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CurrencyRateOperator, Id = Index.CurrencyRateOperator, FieldType = EntityFieldType.Char, Size = 1)]
		public string CurrencyRateOperator {get; set;}

		/// <summary>
		/// Gets or sets DrillDownType
		/// </summary>
		[ViewField(Name = Fields.DrillDownType, Id = Index.DrillDownType, FieldType = EntityFieldType.Int, Size = 2)]
		public int DrillDownType {get; set;}

		/// <summary>
		/// Gets or sets DrillDownLinkNumber
		/// </summary>
		[ViewField(Name = Fields.DrillDownLinkNumber, Id = Index.DrillDownLinkNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal DrillDownLinkNumber {get; set;}

		/// <summary>
		/// Gets or sets DrillDownApplicationSource
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DrillDownApplicationSource, Id = Index.DrillDownApplicationSource, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
		public string DrillDownApplicationSource {get; set;}

		/// <summary>
		/// Gets or sets ReportCurrencyAmount
		/// </summary>
		[ViewField(Name = Fields.ReportCurrencyAmount, Id = Index.ReportCurrencyAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal ReportCurrencyAmount {get; set;}

		/// <summary>
		/// Gets or sets OptionalFields
		/// </summary>
		[ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
		public long OptionalFields {get; set;}

		/// <summary>
		/// Gets or sets DocumentDate
		/// </summary>
		[ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DocumentDate {get; set;}

        /// <summary>
        /// Return formatted Source Code
        /// </summary>
        [IgnoreExportImport]
        public string SourceLedgerTypeCode
        {
            get { return string.Format("{0}-{1}", SourceLedgerCode, SourceTypeCode); }
        }

        /// <summary>
        /// Gets or Sets Formatted Account number
        /// </summary>
        [IgnoreExportImport]
        public string FormattedAccountNumber { get; set; }

        /// <summary>
        /// Return optional field value as string
        /// </summary>
        [IgnoreExportImport]
        public string OptionalFieldString
        {
            get { return OptionalFields == 0 ? CommonResx.No : CommonResx.Yes; }
        }

		#region UI Strings

		/// <summary>
		/// Gets ConsolidationOccurredonPost string value
		/// </summary>
		public string ConsolidationOccurredonPostString
		{
			get { return EnumUtility.GetStringValue(ConsolidationOccurredonPost); }
		}

		#endregion
	}
}
