// Copyright © 2016 Sage Software, Inc.

#region Namespace

using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for RevaluationDetail
    /// </summary>
    public partial class RevaluationDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets CurrencycodeTorevalue
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencycodeTorevalue", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.CurrencycodeTorevalue, Id = Index.CurrencycodeTorevalue, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencycodeTorevalue { get; set; }

        /// <summary>
        /// Gets or sets Defaultrevaluationcode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Defaultrevaluationcode", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.Defaultrevaluationcode, Id = Index.Defaultrevaluationcode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Defaultrevaluationcode { get; set; }

        /// <summary>
        /// Gets or sets BatchDescription
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDescription", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.BatchDescription, Id = Index.BatchDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string BatchDescription { get; set; }

        /// <summary>
        /// Gets or sets Forcerevaluationswitch
        /// </summary>
        [Display(Name = "Forcerevaluationswitch", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.Forcerevaluationswitch, Id = Index.Forcerevaluationswitch, FieldType = EntityFieldType.Int, Size = 2)]
        public Forcerevaluationswitch Forcerevaluationswitch { get; set; }

        /// <summary>
        /// Gets or sets Selectsegmenttype
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Selectsegmenttype", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.Selectsegmenttype, Id = Index.Selectsegmenttype, FieldType = EntityFieldType.Char, Size = 1)]
        public Selectsegmenttype Selectsegmenttype { get; set; }

        /// <summary>
        /// Gets or sets SelectsegmentID
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectsegmentID", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.SelectsegmentID, Id = Index.SelectsegmentID, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string SelectsegmentID { get; set; }

        /// <summary>
        /// Gets or sets FromAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromAccountNumber", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.FromAccountNumber, Id = Index.FromAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string FromAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the formatted from account number.
        /// </summary>
        /// <value>
        /// The formatted from account number.
        /// </value>
        public string FormattedFromAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets ToAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToAccountNumber", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.ToAccountNumber, Id = Index.ToAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ToAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the formatted to account number.
        /// </summary>
        /// <value>
        /// The formatted to account number.
        /// </value>
        public string FormattedToAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets Fromfiscalperiod
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fromfiscalperiod", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.Fromfiscalperiod, Id = Index.Fromfiscalperiod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string Fromfiscalperiod { get; set; }

        /// <summary>
        /// Gets or sets Tofiscalperiod
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Tofiscalperiod", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.Tofiscalperiod, Id = Index.Tofiscalperiod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string Tofiscalperiod { get; set; }

        /// <summary>
        /// Gets or sets Fiscalyear
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fiscalyear", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.Fiscalyear, Id = Index.Fiscalyear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string Fiscalyear { get; set; }

        /// <summary>
        /// Gets or sets Journaldate
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Journaldate", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.Journaldate, Id = Index.Journaldate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Journaldate { get; set; }

        /// <summary>
        /// Gets or sets DateusedForconversion
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateusedForconversion", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.DateusedForconversion, Id = Index.DateusedForconversion, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateusedForconversion { get; set; }

        /// <summary>
        /// Gets or sets Conversionrate
        /// </summary>
        [Display(Name = "Conversionrate", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.Conversionrate, Id = Index.Conversionrate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal Conversionrate { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeGainAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnrealizedExchangeGainAccount", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.UnrealizedExchangeGainAccount, Id = Index.UnrealizedExchangeGainAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnrealizedExchangeGainAccount { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeLossAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnrealizedExchangeLossAccount", ResourceType = typeof (RevaluationDetailResx))]
        [ViewField(Name = Fields.UnrealizedExchangeLossAccount, Id = Index.UnrealizedExchangeLossAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnrealizedExchangeLossAccount { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeGainOptionalFlds list
        /// </summary>
        [Display(Name = "UnrealizedExchangeGainOptionalFlds", ResourceType = typeof(RevaluationDetailResx))]
        [ViewField(Name = Fields.UnrealizedExchangeGainOptionalFlds, Id = Index.UnrealizedExchangeGainOptionalFlds, FieldType = EntityFieldType.Long, Size = 4)]
        public EnumerableResponse<RevaluationDtlsGainOptionalFld> UnrealizedExchangeGainOptionalFlds { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeLossOptionalFlds list
        /// </summary>
        [Display(Name = "UnrealizedExchangeLossOptionalFlds", ResourceType = typeof(RevaluationDetailResx))]
        [ViewField(Name = Fields.UnrealizedExchangeLossOptionalFlds, Id = Index.UnrealizedExchangeLossOptionalFlds, FieldType = EntityFieldType.Long, Size = 4)]
        public EnumerableResponse<RevaluationDtlsLossOptionalFld> UnrealizedExchangeLossOptionalFlds { get; set; }

        
        /// <summary>
        /// Gets or sets UnrealizedExchangeGainOptionalFlds count
        /// </summary>
        [Display(Name = "UnrealizedExchangeGainOptionalFlds", ResourceType = typeof (RevaluationDetailResx))]
        public long UnrealizedExchangeGainOptionalFldsCount { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeLossOptionalFlds count
        /// </summary>
        [Display(Name = "UnrealizedExchangeLossOptionalFlds", ResourceType = typeof (RevaluationDetailResx))]
        public long UnrealizedExchangeLossOptionalFldsCount { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Forcerevaluationswitch string value
        /// </summary>
        public string ForcerevaluationswitchString
        {
         get { return EnumUtility.GetStringValue(Forcerevaluationswitch); }
        }

        /// <summary>
        /// Gets Selectsegmenttype string value
        /// </summary>
        public string SelectsegmenttypeString
        {
         get { return EnumUtility.GetStringValue(Selectsegmenttype); }
        }

        /// <summary>
        /// Gets or set the Optional Field property to set yes or no
        /// </summary>
        /// <value>The optional fields string.</value>
        [Display(Name = "OptionalFields", ResourceType = typeof(OptionalFieldsResx))]
        public string OptionalFieldsString { get; set; }

        #endregion

        /// <summary>
        /// Gets or sets record internal ID
        /// </summary>
        public string InternalId { get; set; }

        /// <summary>
        /// Forcerevaluationswitch list
        /// </summary>
        public IEnumerable<CustomSelectList> Forcerevaluationswitches
        {
            get { return EnumUtility.GetItemsList<Forcerevaluationswitch>(); }
        }

    }
}
