/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    ///ConsolidatePostedTransactionDetail
    /// </summary>
    public class ConsolidatePostedTransactionDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets SourceLedger
        /// </summary>
        public string SourceLedger { get; set; }

        /// <summary>
        /// Gets or sets ConsolidateSwitch
        /// </summary>
        public ConsolidateSwitch ConsolidateSwitch { get; set; }

        /// <summary>
        /// Gets or sets SourceType
        /// </summary>
        public string SourceType { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets ConsolidateSwitch string value
        /// </summary>
        public string ConsolidateSwitchString
        {
            get { return EnumUtility.GetStringValue(ConsolidateSwitch); }
        }
    }
}