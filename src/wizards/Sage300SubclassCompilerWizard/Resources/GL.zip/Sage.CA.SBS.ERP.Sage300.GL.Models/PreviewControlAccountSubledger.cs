// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Partial class for PreviewControlAccountSubledger
    /// </summary>
    public partial class PreviewControlAccountSubledger : ModelBase
    {
        /// <summary>
        /// Gets or sets Account
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Account", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.Account, Id = Index.Account, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Account { get; set; }

        /// <summary>
        /// Gets or sets Subledger
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Subledger", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.Subledger, Id = Index.Subledger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string Subledger { get; set; }

        #region UI Strings

        #endregion
    }
}
