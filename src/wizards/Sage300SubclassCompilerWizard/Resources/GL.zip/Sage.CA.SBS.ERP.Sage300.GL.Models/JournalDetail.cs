/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using System.Collections.Generic;
using System;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class JournalDetail : ModelBase
    {
        /// <summary>
        /// This constructor initializes JournalDetailOptionalFields to be an empty list,
        /// as well as the keys to be empty strings. This avoids the problem of serializing
        /// null collections or objects with a null required property.
        /// </summary>
        public JournalDetail()
        {
            JournalDetailOptionalFields = new List<JournalDetailOptionalFields>();

            AccountNumber = string.Empty;
            BatchNumber = string.Empty;
            EntryNumber = string.Empty;
            SourceType = string.Empty;
        }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(GLCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(JournalEntryResx))]
        [Key]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Char, Size = 5, Mask = "%05D")]
        public string EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionNumber", ResourceType = typeof(JournalEntryResx))]
        [Key]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Char, Size = 10, Mask = "%C%09D")]
        public string TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets Destination 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Destination", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.Destination, Id = Index.Destination, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Destination { get; set; }

        /// <summary>
        /// Gets or sets RouteNo 
        /// </summary>
        [Display(Name = "Route", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.RouteNo, Id = Index.RouteNo, FieldType = EntityFieldType.Int, Size = 2)]
        public int RouteNo { get; set; }


        /// <summary>
        /// Gets or sets AccountNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountNumber", ResourceType = typeof(GLCommonResx))]
        [Key]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets CompanyId 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompanyId", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.CompanyId, Id = Index.CompanyId, FieldType = EntityFieldType.Char, Size = 8)]
        public string CompanyId { get; set; }

        /// <summary>
        /// Gets or sets Amount 
        /// </summary>
        [Display(Name = "Amount", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? Amount { get; set; }


        /// <summary>
        /// Gets or sets Debit Amount 
        /// </summary>
        [Display(Name = "SourceDebit", ResourceType = typeof(JournalEntryResx))]
        public decimal? DebitAmount { get; set; }

        /// <summary>
        /// Gets or sets Credit Amount 
        /// </summary>
        [Display(Name = "SourceCredit", ResourceType = typeof(JournalEntryResx))]
        public decimal? CreditAmount { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrency Amount 
        /// </summary>
        [Display(Name = "FunctionalDebit", ResourceType = typeof(JournalEntryResx))]
        public decimal? FunctionalDebitAmount { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrency Amount  
        /// </summary>
        [Display(Name = "FunctionalCredit", ResourceType = typeof(JournalEntryResx))]
        public decimal? FunctionalCreditAmount { get; set; }

        /// <summary>
        /// Gets or sets Quantity 
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Quantity { get; set; }


        /// <summary>
        /// Determines if the account allows quantities or not
        /// </summary>
        public bool QuantityAllowed { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrencyDecimals 
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCurrencyDecimals", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.SourceCurrencyDecimals, Id = Index.SourceCurrencyDecimals, FieldType = EntityFieldType.Char, Size = 1)]
        public string SourceCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrencyAmount 
        /// </summary>
        [Display(Name = "SourceCurrencyAmount", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.SourceCurrencyAmount, Id = Index.SourceCurrencyAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal? SourceCurrencyAmount { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "HomeCurrency", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.HomeCurrency, Id = Index.HomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateTable 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyRateTable", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.CurrencyRateTable, Id = Index.CurrencyRateTable, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CurrencyRateTable { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrency 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCurrency", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.SourceCurrency, Id = Index.SourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string SourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateDate 
        /// </summary>
        [Display(Name = "RateDate", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.CurrencyRateDate, Id = Index.CurrencyRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CurrencyRateDate { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRate 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Rate", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.CurrencyRate, Id = Index.CurrencyRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CurrencyRate { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateSpread 
        /// </summary>
        [Display(Name = "CurrencyRateSpread", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.CurrencyRateSpread, Id = Index.CurrencyRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CurrencyRateSpread { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateDateMatching 
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyRateDateMatching", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.CurrencyRateDateMatching, Id = Index.CurrencyRateDateMatching, FieldType = EntityFieldType.Char, Size = 1)]
        public string CurrencyRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateOperator 
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyRateOperator", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.CurrencyRateOperator, Id = Index.CurrencyRateOperator, FieldType = EntityFieldType.Char, Size = 1)]
        public string CurrencyRateOperator { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets JournalDate 
        /// </summary>
        [Display(Name = "Date", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.JournalDate, Id = Index.JournalDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime JournalDate { get; set; }

        /// <summary>
        /// Gets or sets SourceLedger 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceLedger", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.SourceLedger, Id = Index.SourceLedger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedger { get; set; }

        /// <summary>
        /// Gets or sets SourceType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.SourceType, Id = Index.SourceType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType { get; set; }

        /// <summary>
        /// Gets or sets Comment 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [Display(Name = "OptionalField", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or Sets OptionalFieldString
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        public string OptionalFieldString { get; set; }

        /// <summary>
        /// Gets or sets ProcessSwitch 
        /// </summary>
        [Display(Name = "Processswitches", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.ProcessSwitch, Id = Index.ProcessSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public JournalDetailsProcessswitch ProcessSwitch { get; set; }

        /// <summary>
        /// Gets or sets the sequential line number for the journal batch detail items
        /// </summary>
        [Display(Name = "LineNumber", ResourceType = typeof(JournalEntryResx))]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets DestExists 
        /// </summary>
        [Display(Name = "DestExists", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DestExists, Id = Index.DestExists, FieldType = EntityFieldType.Int, Size = 2)]
        public int DestExists { get; set; }

        /// <summary>
        /// Gets or sets DestDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DestDescription, Id = Index.DestDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DestDescription { get; set; }

        /// <summary>
        /// Gets or sets DestStatus 
        /// </summary>
        [Display(Name = "DestStatus", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DestStatus, Id = Index.DestStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int DestStatus { get; set; }

        /// <summary>
        /// Gets or sets DestMulticurrencySwitch 
        /// </summary>
        [Display(Name = "DestMulticurrencySwitch", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DestMulticurrencySwitch, Id = Index.DestMulticurrencySwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int DestMulticurrencySwitch { get; set; }

        /// <summary>
        /// Gets or sets DestHomeCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DestHomeCurrency, Id = Index.DestHomeCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string DestHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets DestHomeCurrencyDecimals 
        /// </summary>
        [Display(Name = "DestHomeCurrencyDecimals", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DestHomeCurrencyDecimals, Id = Index.DestHomeCurrencyDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int DestHomeCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets DestQtySwitch 
        /// </summary>
        [Display(Name = "DestQtySwitch", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DestQtySwitch, Id = Index.DestQtySwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int DestQtySwitch { get; set; }

        /// <summary>
        /// Gets or sets DestQtyDecimals 
        /// </summary>
       [Display(Name = "DestQtyDecimals", ResourceType = typeof(JournalEntryResx))]
        [ViewField(Name = Fields.DestQtyDecimals, Id = Index.DestQtyDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int DestQtyDecimals { get; set; }

        /// <summary>
        /// Gets or sets DestOptionalFlds 
        /// </summary>
        [Display(Name = "DestOptionalFlds", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DestOptionalFlds, Id = Index.DestOptionalFlds, FieldType = EntityFieldType.Long, Size = 4)]
        public long DestOptionalFlds { get; set; }

        /// <summary>
        /// Gets or sets RouteExists 
        /// </summary>
        [Display(Name = "RouteExists", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RouteExists, Id = Index.RouteExists, FieldType = EntityFieldType.Int, Size = 2)]
        public int RouteExists { get; set; }

        /// <summary>
        /// Gets or sets RouteDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RouteDescription", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RouteDescription, Id = Index.RouteDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RouteDescription { get; set; }

        /// <summary>
        /// Gets or sets RouteStatus 
        /// </summary>
        [Display(Name = "RouteStatus", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RouteStatus, Id = Index.RouteStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int RouteStatus { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeExists 
        /// </summary>
        [Display(Name = "SourceCodeExists", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.SourceCodeExists, Id = Index.SourceCodeExists, FieldType = EntityFieldType.Int, Size = 2)]
        public int SourceCodeExists { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeDescription", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.SourceCodeDescription, Id = Index.SourceCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string SourceCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets AcctExists 
        /// </summary>
        [Display(Name = "AcctExists", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctExists, Id = Index.AcctExists, FieldType = EntityFieldType.Int, Size = 2)]
        public int AcctExists { get; set; }

        /// <summary>
        /// Gets or sets AcctFormatted 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AcctFormatted", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctFormatted, Id = Index.AcctFormatted, FieldType = EntityFieldType.Char, Size = 45)]
        public string AcctFormatted { get; set; }

        /// <summary>
        /// Gets or sets AccountDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountDescription", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AccountDescription, Id = Index.AccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets AcctStatus 
        /// </summary>
        [Display(Name = "AcctStatus", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctStatus, Id = Index.AcctStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int AcctStatus { get; set; }

        /// <summary>
        /// Gets or sets AcctMulticurrencySwitch 
        /// </summary>
        [Display(Name = "AcctMulticurrencySwitch", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctMulticurrencySwitch, Id = Index.AcctMulticurrencySwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int AcctMulticurrencySwitch { get; set; }

        /// <summary>
        /// Gets or sets AcctSpecificCurrenciesSwitch 
        /// </summary>
        [Display(Name = "AcctSpecificCurrenciesSwitch", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSpecificCurrenciesSwitch, Id = Index.AcctSpecificCurrenciesSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int AcctSpecificCurrenciesSwitch { get; set; }

        /// <summary>
        /// Gets or sets AcctControlSwitch 
        /// </summary>
        [Display(Name = "AcctControlSwitch", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctControlSwitch, Id = Index.AcctControlSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int AcctControlSwitch { get; set; }

        /// <summary>
        /// Gets or sets AcctQtySwitch 
        /// </summary>
        [Display(Name = "AcctQtySwitch", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctQtySwitch, Id = Index.AcctQtySwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int AcctQtySwitch { get; set; }

        /// <summary>
        /// Gets or sets AcctOptionalFlds 
        /// </summary>
        [Display(Name = "AcctOptionalFlds", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctOptionalFlds, Id = Index.AcctOptionalFlds, FieldType = EntityFieldType.Long, Size = 4)]
        public long AcctOptionalFlds { get; set; }

        /// <summary>
        /// Gets or sets AcctTransactionOptionalFlds 
        /// </summary>
        [Display(Name = "AcctTransactionOptionalFlds", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctTransactionOptionalFlds, Id = Index.AcctTransactionOptionalFlds, FieldType = EntityFieldType.Long, Size = 4)]
        public long AcctTransactionOptionalFlds { get; set; }

        /// <summary>
        /// Gets or sets AcctUnitofMeasure 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AcctUnitofMeasure", ResourceType = typeof(JournalEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctUnitofMeasure, Id = Index.AcctUnitofMeasure, FieldType = EntityFieldType.Char, Size = 6)]
        public string AcctUnitofMeasure { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets TaxAccountType
        /// </summary>
        [Display(Name = "TaxAccountType", ResourceType = typeof(JournalEntryResx))]
        //[ViewField(Name = Fields.TaxAccountType, Id = Index.TaxAccountType, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxAccountType TaxAccountType { get; set; }

        /// <summary>
        /// Journal Optional fields for journal detail
        /// </summary>
        public List<JournalDetailOptionalFields> JournalDetailOptionalFields { get; set; }
    }
}

