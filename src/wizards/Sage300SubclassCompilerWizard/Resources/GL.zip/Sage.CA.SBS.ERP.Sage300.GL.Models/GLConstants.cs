﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    ///  Static Class for GL Module constants 
    /// </summary>
    public static class GLConstants
    {
        #region Reports

        /// <summary>
        /// Constant for Application Id
        /// </summary>
        public const string GLApplicationId = "GL";

        /// <summary>
        /// Constant for OE Application Id
        /// </summary>
        public const string OEApplicationId = "OE";

        /// <summary>
        /// Constant for PO Application Id
        /// </summary>
        public const string POApplicationId = "PO";

        /// <summary>
        /// Constant for SN Application Id
        /// </summary>
        public const string SNApplicationId = "SN";

        /// <summary>
        /// Constant for Yes Value
        /// </summary>
        public const string Yes = "Y";

        /// <summary>
        /// Constant for No Value
        /// </summary>
        public const string No = "N";

        /// <summary>
        /// Constant for Zero Value
        /// </summary>
        public const int Inactive = 0;

        /// <summary>
        /// Constant for One Value
        /// </summary>
        public const int Active = 1;

        /// <summary>
        /// Constant for Empty String
        /// </summary>
        public const string EmptyValue = " ";

        /// <summary>
        /// Constant for Functional Currency
        /// </summary>
        public const string FunctionalCurrency = "F";

        /// <summary>
        /// Constant for Vendor Currency
        /// </summary>
        public const string VendorCurrency = "V";

        /// <summary>
        /// Constant for Customer Currency
        /// </summary>
        public const string CustomerCurrency = "C";

        /// <summary>
        /// Constant for Empty Date Value
        /// </summary>
        public const string EmptyDate = "00000000";

        /// <summary>
        /// Constant for Adding Comma with Space
        /// </summary>
        public const string AddComma = ", ";

        /// <summary>
        /// Constant for Comma
        /// </summary>
        public const string Comma = ",";

        /// <summary>
        /// Constant for Closing Bracket
        /// </summary>
        public const string ClosingBracket = ")";

        /// <summary>
        /// Constant for Currency Decimal
        /// </summary>
        public const string CurrencyDecimal = "3";

        /// <summary>
        /// Constant for Age Sequence
        /// </summary>
        public const string AgeSequence = "1";

        /// <summary>
        ///  Constant for Default RangeIndex
        /// </summary>
        public const int DefaultRangeIndex = -1;

        /// <summary>
        /// Constant for Question Mark
        /// </summary>
        public const string Question = "?";

        /// <summary>
        /// Constant for EmptyChar
        /// </summary>
        public const char EmptyChar = ' ';

        /// <summary>
        /// Constant for Default Pad Value
        /// </summary>
        public const int DefaultPadValue = 2;

        /// <summary>
        ///  Constant for Default Sequence Number
        /// </summary>
        public const int DefaultSequenceNumber = 1;

        /// <summary>
        /// Constant for Field Value Zero
        /// </summary>
        public const string FieldValueZero = "0";

        /// <summary>
        /// Constant for Field Value One
        /// </summary>
        public const string FieldValueOne = "1";

        /// <summary>
        /// Constant for Minus One
        /// </summary>
        public const string MinusOne = "-1";

        /// <summary>
        /// Constant for Field Length Two
        /// </summary>
        public const string FieldLengthTwo = "2";

        /// <summary>
        /// Constant for Field Length Three
        /// </summary>
        public const string FieldLengthThree = "3";

        /// <summary>
        /// Constant for Field Length Four
        /// </summary>
        public const string FieldLengthFour = "4";

        /// <summary>
        /// Constant for Field Length Six
        /// </summary>
        public const string FieldLengthSix = "6";

        /// <summary>
        /// Constant for Field Length Eight
        /// </summary>
        public const string FieldLengthEight = "8";

        /// <summary>
        /// Constant for Field Length Ten
        /// </summary>
        public const string FieldLengthTen = "10";

        /// <summary>
        /// Constant for Field Length Twelve
        /// </summary>
        public const string FieldLengthTwelve = "12";

        /// <summary>
        /// Constant for Field Length Six
        /// </summary>
        public const string FieldLengthFourteen = "14";

        /// <summary>
        /// Constant for Field Length Twenty Four
        /// </summary>
        public const string FieldLengthTwentyFour = "24";

        /// <summary>
        /// Constant for Field Length Six
        /// </summary>
        public const string FieldLengthSixty = "60";

        /// <summary>
        /// Constant for Empty year Value
        /// </summary>
        public const string EmptyYear = "0000";

        /// <summary>
        /// Default To One
        /// </summary>
        public const string DefaultToOne = "Z";

        /// <summary>
        /// Default To Two
        /// </summary>
        public const string DefaultToTwo = "ZZ";

        /// <summary>
        /// Default To Four
        /// </summary>
        public const string DefaultToFour = "ZZZZ";

        /// <summary>
        /// Default To Five
        /// </summary>
        public const string DefaultToFive = "ZZZZZ";

        /// <summary>
        /// Default To Ten
        /// </summary>
        public const string DefaultToTen = "zzzzzzzzzz";

        /// <summary>
        /// Default To Twelve
        /// </summary>
        public const string DefaultToTwelve = "zzzzzzzzzzzz";

        /// <summary>
        /// Default To Twenty
        /// </summary>
        public const string DefaultToTwenty = "ZZZZZZZZZZZZZZZZZZZZ";

        /// <summary>
        /// Default To Twenty Four
        /// </summary>
        public const string DefaultToTwentyFour = "ZZZZZZZZZZZZZZZZZZZZZZZZ";

        /// <summary>
        /// Default To Thirty
        /// </summary>
        public const string DefaultToThirty = "zzzzzzzzzzzzzzzzzzzzzzzzzzzzzz";

        /// <summary>
        /// Default To Sixty
        /// </summary>
        public const string DefaultToSixty = "zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz";

        /// <summary>
        /// Sort Number for Optional Fields
        /// </summary>
        public const int OptionalFieldSortNumber = 10;

        /// <summary>
        /// Constant for capital z
        /// </summary>
        public const char Z = 'Z';

        /// <summary>
        /// Constant for small z
        /// </summary>
        public const char Zsmall = 'z';

        /// <summary>
        /// Constant for Report MenuId
        /// </summary>
        public const string ReportMenuId = "<MENU ID>";

        public const string ReportExtension = "RPT";

        #endregion
    }
}
