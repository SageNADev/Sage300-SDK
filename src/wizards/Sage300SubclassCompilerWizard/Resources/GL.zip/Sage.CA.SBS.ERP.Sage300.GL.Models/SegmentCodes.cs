/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class SegmentCodes
    /// </summary>
    public partial class SegmentCodes : ModelBase
    {
        /// <summary>
        /// Gets or sets SegmentNumber
        /// </summary>
        /// <value>The segment number</value>
        [Display(Name = "SegmentNumber", ResourceType = typeof(SegmentCodesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SegmentNumber, Id = Index.SegmentNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentNumber { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode
        /// </summary>
        /// <value>The segment code</value>
        [Display(Name = "SegmentCode", ResourceType = typeof(SegmentCodesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.SegmentCode, Id = Index.SegmentCode, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentCode { get; set; }

        /// <summary>
        /// Gets or sets SegmentCodeDescription
        /// </summary>
        /// <value>The segment code description</value>
        [Display(Name = "Description", ResourceType = typeof(SegmentCodesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SegmentCodeDescription, Id = Index.SegmentCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string SegmentCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets ClosingAccount
        /// </summary>
        /// <value>The closing account</value>
        [Display(Name = "ClosingAccount", ResourceType = typeof(SegmentCodesResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ClosingAccount, Id = Index.ClosingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ClosingAccount { get; set; }

        #region UI Property

        /// <summary>
        /// Gets or sets the formatted account number
        /// </summary>
        /// <value>The formatted account number</value>
        [IsMvcSpecific]
        public string FormattedAccountNumber { get; set; }

        #endregion
    }
}
