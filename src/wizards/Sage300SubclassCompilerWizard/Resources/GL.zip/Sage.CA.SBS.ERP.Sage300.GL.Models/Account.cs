/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of properties for GL Account.
    /// </summary>
    public partial class Account : ModelBase
    {
        /// <summary>
        /// This constructor initializes EnumerableResponses/Lists to be empty.
        /// This avoids the problem of serializing null collections.
        /// </summary>
        public Account() 
        {
            OptionalFields = new EnumerableResponse<AccountOptionalFields>();
            OptionalTransFields = new EnumerableResponse<AccountTransOptionalFields>();
            AccountAllocationInstructions = new EnumerableResponse<AccountAllocationInstructions>();
            AccountValidCurrencies = new EnumerableResponse<AccountValidCurrencies>();
            ControlAccountSubledgers = new EnumerableResponse<ControlAccountSubledgers>();
            RollupGroups = new EnumerableResponse<RollupGroups>();
            AccountSelectorCopyRollupGroups = new EnumerableResponse<RollupMemberPreview>();

            AccountSegments = new List<AccountSegment>();
            CloseToAccountSegments = new List<AccountSegments>();
            AccountOptionalFieldSelectors = new List<AccountOptionalFieldSelector>();
            RollupTreeView = new List<RollupTreeview>();
            SegmentCodes = new List<SegmentCodes>();
            AllocationAllowedList = new List<CustomSelectList>(); // Casts from List to IList.
        }

        /// <summary>
        /// Gets or sets UnformattedAccount 
        /// </summary>
        [Display(Name = "UnformattedAccount", ResourceType = typeof (AccountsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.UnformattedAccount, Id = Index.UnformattedAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnformattedAccount { get; set; }

        /// <summary>
        /// Gets or sets DateCreated
        /// </summary>
        [Display(Name = "DateCreated", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.DateCreated, Id = Index.DateCreated, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCreated { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Char, Size = 1)]
        public AccountType Type { get; set; }

        /// <summary>
        /// Gets or sets NormalBalanceDrorCr
        /// </summary>
        [Display(Name = "NormalBalanceDrorCr", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.NormalBalanceDrorCr, Id = Index.NormalBalanceDrorCr, FieldType = EntityFieldType.Char, Size = 1)]
        public NormalBalanceDrorCr NormalBalanceDrorCr { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets PosttoAccount
        /// </summary>
        [Display(Name = "PostToAccount", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.PosttoAccount, Id = Index.PosttoAccount, FieldType = EntityFieldType.Int, Size = 2)]
        public PosttoAccount PosttoAccount { get; set; }

        /// <summary>
        /// Gets or sets QuantitiesAllowed
        /// </summary>
        [Display(Name = "QuantitiesAllowed", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.QuantitiesAllowed, Id = Index.QuantitiesAllowed, FieldType = EntityFieldType.Int, Size = 2)]
        public Allowed QuantitiesAllowed { get; set; }

        /// <summary>
        /// Gets or sets UnitofMeasure
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "UnitofMeasure", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.UnitofMeasure, Id = Index.UnitofMeasure, FieldType = EntityFieldType.Char, Size = 6)]
        public string UnitofMeasure { get; set; }

        /// <summary>
        /// Gets or sets AllocationsAllowed
        /// </summary>
        [Display(Name = "AllocationsAllowed", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AllocationsAllowed, Id = Index.AllocationsAllowed, FieldType = EntityFieldType.Int, Size = 2)]
        public AllocationsAllowed AllocationsAllowed { get; set; }

        /// <summary>
        /// Gets or sets AllocationsAllowed
        /// </summary>
        [Display(Name = "AllocOffsetAccount", ResourceType = typeof (AccountsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.AllocOffsetAccount, Id = Index.AllocOffsetAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AllocOffsetAccount { get; set; }

        /// <summary>
        /// Gets or sets AllocSourceType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SourceType", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AllocSourceType, Id = Index.AllocSourceType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string AllocSourceType { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.Multicurrency, Id = Index.Multicurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public Allowed Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets SpecificCurrency
        /// </summary>
        [Display(Name = "SpecificCurrency", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.SpecificCurrency, Id = Index.SpecificCurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public SpecificCurrency SpecificCurrency { get; set; }

        /// <summary>
        /// Gets or sets Acctgrpid 
        /// </summary>
        [IgnoreExportImport]
        public int Acctgrpid { get; set; }

        /// <summary>
        /// Gets or sets ControlAccount
        /// </summary>
        [Display(Name = "ControlAccount", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.ControlAccount, Id = Index.ControlAccount, FieldType = EntityFieldType.Int, Size = 2)]
        public Allowed ControlAccount { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public EnumerableResponse<AccountOptionalFields> OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets OptionalTransFields
        /// </summary>
        public EnumerableResponse<AccountTransOptionalFields> OptionalTransFields { get; set; }

        /// <summary>
        /// Gets or sets AccountAllocationInstructions
        /// </summary>
        public EnumerableResponse<AccountAllocationInstructions> AccountAllocationInstructions { get; set; }

        /// <summary>
        /// Gets or sets AccountValidCurrencies
        /// </summary>
        public EnumerableResponse<AccountValidCurrencies> AccountValidCurrencies { get; set; }

        /// <summary>
        /// Gets or sets ControlAccountSubledgers
        /// </summary>
        public EnumerableResponse<ControlAccountSubledgers> ControlAccountSubledgers { get; set; }

        /// <summary>
        /// Gets or sets RollupGroups
        /// </summary>
        public EnumerableResponse<RollupGroups> RollupGroups { get; set; }

        /// <summary>
        /// Gets or sets AccountSegments
        /// </summary>
        public List<AccountSegment> AccountSegments { get; set; }

        /// <summary>
        /// Gets or sets CloseToAccountSegments
        /// </summary>
        public List<AccountSegments> CloseToAccountSegments { get; set; }

        /// <summary>
        /// Gets or sets AccountOptionalFieldSelectors
        /// </summary>
        public List<AccountOptionalFieldSelector> AccountOptionalFieldSelectors { get; set; }

        /// <summary>
        /// Gets or sets AccountSelectorCopyRollupGroups
        /// </summary>
        public EnumerableResponse<RollupMemberPreview> AccountSelectorCopyRollupGroups { get; set; }

        /// <summary>
        /// Gets or sets RollupTreeView
        /// </summary>
        [IsMvcSpecific]
        public List<RollupTreeview> RollupTreeView { get; set; }

        /// <summary>
        /// Gets or sets DefaultAccount
        /// </summary>
        [Display(Name = "Account", ResourceType = typeof (AccountsResx))]
        [IgnoreExportImport]
        public string DefaultAccount { get; set; }

        /// <summary>
        /// Gets or sets ActivateMultiCurrency
        /// </summary>
        [IgnoreExportImport]
        public bool ActivateMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Srceldgid
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Reserved", ResourceType = typeof (AccountsResx))]
        public string Srceldgid { get; set; }

        /// <summary>
        /// Gets or sets AllocationPercentTotal
        /// </summary>
        [Display(Name = "TotalPercent", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AllocationPercentTotal, Id = Index.AllocationPercentTotal, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal AllocationPercentTotal { get; set; }

        /// <summary>
        /// Gets or sets StructureCode
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "StructureCode", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.StructureCode, Id = Index.StructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StructureCode { get; set; }

        /// <summary>
        /// Gets or sets StructureCodeDescription
        /// </summary>
        [IgnoreExportImport]
        public string StructureCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets YearLastClosed
        /// </summary>
        [Display(Name = "YearLastClosed", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.YearLastClosed, Id = Index.YearLastClosed, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal YearLastClosed { get; set; }

        /// <summary>
        /// Gets or sets AccountNumber
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Account", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45)]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountSegmentCode1", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode1, Id = Index.AccountSegmentCode1, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode1 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountSegmentCode2", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode2, Id = Index.AccountSegmentCode2, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode2 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountSegmentCode3", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode3, Id = Index.AccountSegmentCode3, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode3 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountSegmentCode4", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode4, Id = Index.AccountSegmentCode4, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode4 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountSegmentCode5", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode5, Id = Index.AccountSegmentCode5, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode5 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountSegmentCode6", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode6, Id = Index.AccountSegmentCode6, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode6 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode7
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountSegmentCode7", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode7, Id = Index.AccountSegmentCode7, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode7 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode8
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountSegmentCode8", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode8, Id = Index.AccountSegmentCode8, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode8 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode9
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountSegmentCode9", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode9, Id = Index.AccountSegmentCode9, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode9 { get; set; }

        /// <summary>
        /// Gets or sets AccountSegmentCode10
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountSegmentCode10", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountSegmentCode10, Id = Index.AccountSegmentCode10, FieldType = EntityFieldType.Char, Size = 15)]
        public string AccountSegmentCode10 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentCode", ResourceType = typeof (GLCommonResx))]
        [ViewField(Name = Fields.SegmentCode, Id = Index.SegmentCode, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode { get; set; }

        /// <summary>
        /// Gets or sets SegmentCodes
        /// </summary>
        public List<SegmentCodes> SegmentCodes { get; set; }

        /// <summary>
        /// Gets or sets Acctgrpcpy
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Acctgrpcpy", ResourceType = typeof (AccountsResx))]
        [IgnoreExportImport]
        public string Acctgrpcpy { get; set; }

        /// <summary>
        /// Gets or sets PosttoSegmentId
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CloseToSegment", ResourceType = typeof (AccountsResx))]
        public string PosttoSegmentId { get; set; }

        /// <summary>
        /// Gets or sets DefaultCurrencyCode
        /// </summary>
        [Display(Name = "DefaultCurrency", ResourceType = typeof (AccountsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DefaultCurrencyCode, Id = Index.DefaultCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string DefaultCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets Cuom
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Cuom", ResourceType = typeof (AccountsResx))]
        [IgnoreExportImport]
        public string Cuom { get; set; }

        /// <summary>
        /// Gets or sets Sameuomsw
        /// </summary>
        public int Sameuomsw { get; set; }

        /// <summary>
        /// Gets or sets Gsstatus
        /// </summary>
        public int Gsstatus { get; set; }

        /// <summary>
        /// Gets or sets TransactionOptionalFields
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TransactionOptionalFields, Id = Index.TransactionOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessSwitch
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ProcessSwitch, Id = Index.ProcessSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessSwitch ProcessSwitch { get; set; }

        /// <summary>
        /// Gets or sets AccountGroupCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountGroup", ResourceType = typeof (GLCommonResx))]
        [ViewField(Name = Fields.AccountGroupCode, Id = Index.AccountGroupCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AccountGroupCode { get; set; }

        /// <summary>
        /// Gets or sets AccountGroupDescription
        /// </summary>
        public string AccountGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets AccountGroupCategoryString
        /// </summary>
        [Display(Name = "AccountGroupCategoryString", ResourceType = typeof (AccountsResx))]
        public string AccountGroupCategoryString { get; set; }

        /// <summary>
        /// Gets or sets AccountGroupSortCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SortCode", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.AccountGroupSortCode, Id = Index.AccountGroupSortCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AccountGroupSortCode { get; set; }

        /// <summary>
        /// Gets or sets RollupSwitch
        /// </summary>
        [Display(Name = "RollupSwitch", ResourceType = typeof (AccountsResx))]
        [ViewField(Name = Fields.RollupSwitch, Id = Index.RollupSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public Allowed RollupSwitch { get; set; }

        /// <summary>
        /// Gets or sets RollupOrMemberOrNonRollup
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RollupOrMemberOrNonRollup, Id = Index.RollupOrMemberOrNonRollup, FieldType = EntityFieldType.Int, Size = 2)]
        public RollupOrMemberOrNonRollup RollupOrMemberOrNonRollup { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "From", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromAccount, Id = Index.AcctSelectorFromAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AcctSelectorFromAccount { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "To", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToAccount, Id = Index.AcctSelectorToAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AcctSelectorToAccount { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromSeg1Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromSeg1Val, Id = Index.AcctSelectorFromSeg1Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorFromSeg1Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToSeg1Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToSeg1Val, Id = Index.AcctSelectorToSeg1Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorToSeg1Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromSeg2Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromSeg2Val, Id = Index.AcctSelectorFromSeg2Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorFromSeg2Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToSeg2Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToSeg2Val, Id = Index.AcctSelectorToSeg2Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorToSeg2Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromSeg3Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromSeg3Val, Id = Index.AcctSelectorFromSeg3Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorFromSeg3Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToSeg3Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToSeg3Val, Id = Index.AcctSelectorToSeg3Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorToSeg3Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromSeg4Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromSeg4Val, Id = Index.AcctSelectorFromSeg4Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorFromSeg4Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToSeg4Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToSeg4Val, Id = Index.AcctSelectorToSeg4Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorToSeg4Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromSeg5Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromSeg5Val, Id = Index.AcctSelectorFromSeg5Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorFromSeg5Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToSeg5Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToSeg5Val, Id = Index.AcctSelectorToSeg5Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorToSeg5Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromSeg6Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromSeg6Val, Id = Index.AcctSelectorFromSeg6Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorFromSeg6Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToSeg6Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToSeg6Val, Id = Index.AcctSelectorToSeg6Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorToSeg6Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromSeg7Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromSeg7Val, Id = Index.AcctSelectorFromSeg7Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorFromSeg7Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToSeg7Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToSeg7Val, Id = Index.AcctSelectorToSeg7Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorToSeg7Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromSeg8Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromSeg8Val, Id = Index.AcctSelectorFromSeg8Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorFromSeg8Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToSeg8Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToSeg8Val, Id = Index.AcctSelectorToSeg8Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorToSeg8Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromSeg9Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromSeg9Val, Id = Index.AcctSelectorFromSeg9Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorFromSeg9Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToSeg9Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToSeg9Val, Id = Index.AcctSelectorToSeg9Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorToSeg9Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromSeg10Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromSeg10Val, Id = Index.AcctSelectorFromSeg10Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorFromSeg10Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToSeg10Val
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Segment", ResourceType = typeof (GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToSeg10Val, Id = Index.AcctSelectorToSeg10Val, FieldType = EntityFieldType.Char, Size = 15)]
        public string AcctSelectorToSeg10Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorOptField1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        public string AcctSelectorOptField1 { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorOptField2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorOptField2, Id = Index.AcctSelectorOptField2, FieldType = EntityFieldType.Char, Size = 12)]
        public string AcctSelectorOptField2 { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorOptField3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorOptField3, Id = Index.AcctSelectorOptField3, FieldType = EntityFieldType.Char, Size = 12)]
        public string AcctSelectorOptField3 { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromOpt1Val
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OptionalFieldValue", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromOpt1Val, Id = Index.AcctSelectorFromOpt1Val, FieldType = EntityFieldType.Char, Size = 60)]
        public string AcctSelectorFromOpt1Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToOpt1Val
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OptionalFieldValue", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToOpt1Val, Id = Index.AcctSelectorToOpt1Val, FieldType = EntityFieldType.Char, Size = 60)]
        public string AcctSelectorToOpt1Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromOpt2Val
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OptionalFieldValue", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromOpt2Val, Id = Index.AcctSelectorFromOpt2Val, FieldType = EntityFieldType.Char, Size = 60)]
        public string AcctSelectorFromOpt2Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToOpt2Val
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OptionalFieldValue", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToOpt2Val, Id = Index.AcctSelectorToOpt2Val, FieldType = EntityFieldType.Char, Size = 60)]
        public string AcctSelectorToOpt2Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromOpt3Val
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OptionalFieldValue", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromOpt3Val, Id = Index.AcctSelectorFromOpt3Val, FieldType = EntityFieldType.Char, Size = 60)]
        public string AcctSelectorFromOpt3Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToOpt3Val
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "OptionalFieldValue", ResourceType = typeof (CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToOpt3Val, Id = Index.AcctSelectorToOpt3Val, FieldType = EntityFieldType.Char, Size = 60)]
        public string AcctSelectorToOpt3Val { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorAcctType
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorAcctType, Id = Index.AcctSelectorAcctType, FieldType = EntityFieldType.Int, Size = 2)]
        public int AcctSelectorAcctType { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorFromAcctGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountGroup", ResourceType = typeof(GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorFromAcctGroup, Id = Index.AcctSelectorFromAcctGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AcctSelectorFromAcctGroup { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorToAcctGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AccountGroup", ResourceType = typeof(GLCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorToAcctGroup, Id = Index.AcctSelectorToAcctGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AcctSelectorToAcctGroup { get; set; }

        /// <summary>
        /// Gets or sets AcctSelectorQuantAllowed
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.AcctSelectorQuantAllowed, Id = Index.AcctSelectorQuantAllowed, FieldType = EntityFieldType.Int, Size = 2)]
        public int AcctSelectorQuantAllowed { get; set; }

        /// <summary>
        /// Gets or sets Noofcreatedpreviewaccounts
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Noofcreatedpreviewaccounts, Id = Index.Noofcreatedpreviewaccounts, FieldType = EntityFieldType.Long, Size = 4)]
        public long Noofcreatedpreviewaccounts { get; set; }

        /// <summary>
        /// Gets or sets RollupMembersinOtherAccounts
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RollupMembersinOtherAccounts, Id = Index.RollupMembersinOtherAccounts, FieldType = EntityFieldType.Int, Size = 2)]
        public int RollupMembersinOtherAccounts { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFieldsValue DefaultOptionField { get; set; }

        /// <summary>
        /// Gets or sets NewAccount
        /// </summary>
        public bool NewAccount { get; set; }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        public string QuantitiesString
        {
            get { return EnumUtility.GetStringValue(QuantitiesAllowed); }
        }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        public string StatusDescription
        {
            get
            {
                var val =  EnumUtility.GetStringValue(Status);
                return val;
            }
        }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        public string RollupSwitchString
        {
            get { return EnumUtility.GetStringValue(RollupSwitch); }
        }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        [IgnoreExportImport]
        public string AccountTypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        public string NormalBalanceString
        {
            get { return EnumUtility.GetStringValue(NormalBalanceDrorCr); }
        }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        public string MulticurrencyString
        {
            get { return EnumUtility.GetStringValue(Multicurrency); }
        }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        public string ControlAccountString
        {
            get { return EnumUtility.GetStringValue(ControlAccount); }
        }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        public string PosttoAccountString
        {
            get { return EnumUtility.GetStringValue(PosttoAccount); }
        }

        /// <summary>
        /// Finder Grid property set.
        /// </summary>
        public string AllowedDescription
        {
            get { return ControlAccount.ToString(); }
        }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        public string SpecificCurrencyString
        {
            get { return EnumUtility.GetStringValue(SpecificCurrency); }
        }

        #region UI Properties

        /// <summary>
        /// Control Account Allowed for UI
        /// </summary>
        /// 
        [Display(Name = "ControlAccount", ResourceType = typeof (AccountsResx))]
        public bool ControlAccountAllowed
        {
            get { return ControlAccount == Allowed.Yes; }
            set { ControlAccount = value == false ? Allowed.No : Allowed.Yes; }
        }

        /// <summary>
        /// Control Account Allowed for UI
        /// </summary>
        /// 
        [Display(Name = "AutoAllocation", ResourceType = typeof (AccountsResx))]
        public bool AutoAllocationAllowed
        {
            get
            {
                if (AllocationsAllowed == AllocationsAllowed.NoAllocation)
                {
                    return false;
                }

                return true;
            }
            set
            {
                if (!value)
                {
                    AllocationsAllowed = AllocationsAllowed.NoAllocation;
                }
            }
        }

        /// <summary>
        /// Control Account Allowed for UI
        /// </summary>
        /// 
        [Display(Name = "Multicurrency", ResourceType = typeof (AccountsResx))]
        public bool MulticurrencyAllowed
        {
            get
            {
                if (Multicurrency == Allowed.Yes)
                {
                    return true;
                }
                return false;
            }
            set { Multicurrency = value == false ? Allowed.No : Allowed.Yes; }
        }

        /// <summary>
        /// Control Account Allowed for UI
        /// </summary>
        /// 
        [Display(Name = "QuantityAllowed", ResourceType = typeof (AccountsResx))]
        public bool QuantityAllowed
        {
            get { return QuantitiesAllowed == Allowed.Yes; }
            set { QuantitiesAllowed = value == false ? Allowed.No : Allowed.Yes; }
        }

        /// <summary>
        /// Control Account Allowed for UI
        /// </summary>
        /// 
        [Display(Name = "Rollup", ResourceType = typeof (AccountsResx))]
        public bool RollupAllowed
        {
            get
            {
                if (RollupSwitch == Allowed.Yes)
                {
                    return true;
                }
                return false;
                //return RollupSwitch == Allowed.Yes;
            }
            set { RollupSwitch = value == false ? Allowed.No : Allowed.Yes; }
        }

        /// <summary>
        /// Finder Grid Property Set
        /// </summary>
        public string AllocationDescription
        {
            get { return EnumUtility.GetStringValue(AllocationsAllowed); }
        }

        /// <summary>
        /// Multicurrency Activated Switch Disable for UI
        /// </summary>
        public bool MultiCurrActivatedSwitchDisable
        {
            get
            {
                if (Multicurrency == Allowed.No)
                {
                    return false;
                }
                return true;
            }
        }

        /// <summary>
        /// Quantity Allowed Switch Disable for UI
        /// </summary>
        public bool QuantityAllowedDisable
        {
            get
            {
                if (QuantitiesAllowed == Allowed.No)
                {
                    return false;
                }
                return true;
            }
        }

        /// <summary>
        ///  StructureCodeDisable Allowed Switch Disable for UI
        /// </summary>
        public bool StructureCodeDisable
        {
            get
            {
                if (StructureCode != null)
                {
                    return true;
                }

                return false;
            }
        }

        /// <summary>
        /// IncomeStatementSelected
        /// </summary>
        [Display(Name = "IncomeStatement", ResourceType = typeof (AccountsResx))]
        public bool IncomeStatementSelected { get; set; }

        /// <summary>
        /// BalanceSheetSelected
        /// </summary>
        [Display(Name = "BalanceSheet", ResourceType = typeof (AccountsResx))]
        public bool BalanceSheetSelected { get; set; }

        /// <summary>
        /// RetainedEarningsSelected
        /// </summary>
        [Display(Name = "RetainedEarnings", ResourceType = typeof (AccountsResx))]
        public bool RetainedEarningsSelected { get; set; }

        /// <summary>
        /// RequiredDefaultOptionFieldsFetched
        /// </summary>
        public bool RequiredDefaultOptionFieldsFetched { get; set; }

        /// <summary>
        /// ParentRollupAccountAdd
        /// </summary>
        public bool ParentRollupAccountAdd { get; set; }

        /// <summary>
        /// Allocation Allowed List for Drop Down
        /// </summary>
        public List<CustomSelectList> AllocationAllowedList { get; set; }

        /// <summary>
        /// Account Group Visisble
        /// </summary>
        public bool AccountGroupVisible { get; set; }

        /// <summary>
        /// Quantities Visisble
        /// </summary>
        public bool QuantitiesVisible { get; set; }

        #endregion
    }
}
