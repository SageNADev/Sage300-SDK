/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Model for PostingJournalDetail
    /// </summary>
    public partial class PostingJournalDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets PostingSequenceNumber
        /// </summary>
        /// <value>The posting sequence number.</value>
        [Key]
        public decimal PostingSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        /// <value>The batch number.</value>
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets JournalEntryNumber
        /// </summary>
        /// <value>The journal entry number.</value>
        [Key]
        public string JournalEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets JournalTransactionNumber
        /// </summary>
        /// <value>The journal transaction number.</value>
        [Key]
        public decimal JournalTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets JournalDate
        /// </summary>
        /// <value>The journal date.</value>
        public string JournalDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        /// <value>The fiscal year.</value>
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        /// <value>The fiscal period.</value>
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets SourceLedgerCode
        /// </summary>
        /// <value>The source ledger code.</value>
        [ViewField(Name = Fields.SourceLedgerCode, Id = Index.SourceLedgerCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedgerCode { get; set; }

        /// <summary>
        /// Gets or sets SourceTypeCode
        /// </summary>
        /// <value>The source type code.</value>
        [ViewField(Name = Fields.SourceTypeCode, Id = Index.SourceTypeCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceTypeCode { get; set; }

        /// <summary>
        /// Gets or sets Reserved
        /// </summary>
        /// <value>The reserved.</value>
        public int Reserved { get; set; }

        /// <summary>
        /// Gets or sets ConsolidationOccurredOnPost
        /// </summary>
        /// <value>The consolidation occurred on post.</value>
        public ConsolidationOccurredOnPost ConsolidationOccurredOnPost { get; set; }

        /// <summary>
        /// Gets or sets AccountNumber
        /// </summary>
        /// <value>The account number.</value>
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets CompanyID
        /// </summary>
        /// <value>The company identifier.</value>
        [ViewField(Name = Fields.CompanyID, Id = Index.CompanyID, FieldType = EntityFieldType.Char, Size = 8)]
        public string CompanyID { get; set; }

        /// <summary>
        /// Gets or sets JournalDetailDescription
        /// </summary>
        /// <value>The journal detail description.</value>
        public string JournalDetailDescription { get; set; }

        /// <summary>
        /// Gets or sets the journald dtail reference.
        /// </summary>
        /// <value>The journald dtail reference.</value>
        ///// </summary>
        public string JournaldDtailReference { get; set; }

        /// <summary>
        /// Gets or sets JournalTransactionAmount
        /// </summary>
        /// <value>The journal transaction amount.</value>
        public decimal JournalTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets JournalTransactionQuantity
        /// </summary>
        /// <value>The journal transaction quantity.</value>
        public decimal JournalTransactionQuantity { get; set; }

        /// <summary>
        /// Gets or sets NbrOfSourceCurrencyDecimals
        /// </summary>
        /// <value>The NBR of source currency decimals.</value>
        public string NbrOfSourceCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrencyAmount
        /// </summary>
        /// <value>The source currency amount.</value>
        public decimal SourceCurrencyAmount { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrencyCode
        /// </summary>
        /// <value>The home currency code.</value>
        public string HomeCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRatetableType
        /// </summary>
        /// <value>The type of the currency ratetable.</value>
        public string CurrencyRatetableType { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrencyCode
        /// </summary>
        /// <value>The source currency code.</value>
        public string SourceCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets DateOfCurrencyRateSelected
        /// </summary>
        /// <value>The date of currency rate selected.</value>
        public string DateOfCurrencyRateSelected { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateForConversion
        /// </summary>
        /// <value>The currency rate for conversion.</value>
        public decimal CurrencyRateForConversion { get; set; }

        /// <summary>
        /// Gets or sets CurrencyRateSpreadAllowed
        /// </summary>
        /// <value>The currency rate spread allowed.</value>
        public decimal CurrencyRateSpreadAllowed { get; set; }

        /// <summary>
        /// Gets or sets CodeForRateDateMatching
        /// </summary>
        /// <value>The code for rate date matching.</value>
        public string CodeForRateDateMatching { get; set; }

        /// <summary>
        /// Gets or sets Currencyrateoperator
        /// </summary>
        /// <value>The currency rate operator.</value>
        public string CurrencyRateOperator { get; set; }

        /// <summary>
        /// Gets or sets Printedstatuscode
        /// </summary>
        /// <value>The printedstatuscode.</value>
        [ViewField(Name = Fields.Printedstatuscode, Id = Index.Printedstatuscode, FieldType = EntityFieldType.Int, Size = 2)]
        public PrintedStatusCode Printedstatuscode { get; set; }

        /// <summary>
        /// Gets or sets EntryDate
        /// </summary>
        /// <value>The entry date.</value>
        [ViewField(Name = Fields.EntryDate, Id = Index.EntryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string EntryDate { get; set; }

        /// <summary>
        /// Gets or sets ReportCurrencyAmount
        /// </summary>
        /// <value>The report currency amount.</value>
        public decimal ReportCurrencyAmount { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        /// <value>The optional fields.</value>
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets Originator
        /// </summary>
        /// <value>The originator.</value>
        [ViewField(Name = Fields.Originator, Id = Index.Originator, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Originator { get; set; }

        /// <summary>
        /// Gets or sets AutoReversal
        /// </summary>
        /// <value>The automatic reversal.</value>
        [ViewField(Name = Fields.AutoReversal, Id = Index.AutoReversal, FieldType = EntityFieldType.Int, Size = 2)]
        public AutoReversalEnum AutoReversal { get; set; }

        /// <summary>
        /// Gets or sets Destination
        /// </summary>
        /// <value>The destination.</value>
        [ViewField(Name = Fields.Destination, Id = Index.Destination, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Destination { get; set; }

        /// <summary>
        /// Gets or sets RouteNo
        /// </summary>
        /// <value>The route no.</value>
        [ViewField(Name = Fields.RouteNo, Id = Index.RouteNo, FieldType = EntityFieldType.Int, Size = 2)]
        public int RouteNo { get; set; }
    }
}
