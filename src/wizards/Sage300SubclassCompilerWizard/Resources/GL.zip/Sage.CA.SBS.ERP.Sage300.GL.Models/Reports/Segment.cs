﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class Segment.
    /// </summary>
    public class Segment
    {
        #region Model Properties

        /// <summary>
        /// Gets or Sets Selected Segment
        /// </summary>
        /// <value>The selected segment.</value>
        public string SelectedSegment { get; set; }

        /// <summary>
        /// Gets or Sets Selected Segment Text
        /// </summary>
        /// <value>The selected segment text.</value>
        public string SelectedSegmentText { get; set; }

        /// <summary>
        /// Gets or Sets Selected Segment Length
        /// </summary>
        /// <value>The selected segment Length.</value>
        public string SelectedSegmentLength { get; set; }

        /// <summary>
        /// Gets or Sets From Account
        /// </summary>
        /// <value>From account.</value>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        public string FromAccount { get; set; }

        /// <summary>
        /// Gets or Sets To Account
        /// </summary>
        /// <value>To account.</value>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        public string ToAccount { get; set; }

        /// <summary>
        /// Gets or Sets From Format Account
        /// </summary>
        /// <value>From format account.</value>
        public string FromFormatAccount { get; set; }

        /// <summary>
        /// Gets or Sets To Format Account
        /// </summary>
        /// <value>To format account.</value>
        public string ToFormatAccount { get; set; }

        #endregion
    }
}