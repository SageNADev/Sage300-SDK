﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Chart Of Accounts Model
    /// </summary>
    public partial class ChartOfAccount : ReportBase
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ChartOfAccount"/> class.
        /// </summary>
        public ChartOfAccount()
        {

            OptionalField = new EnumerableResponse<OptionalFields>();
            AccountSegment = new EnumerableResponse<AccountSegment>();
            SegmentList = new EnumerableResponse<AccountSegment>();

        }

        #endregion

        #region Report Fields

        /// <summary>
        /// Gets or Sets Range
        /// </summary>
        public string Range { get; set; }

        /// <summary>
        /// Gets or Sets FromAccount
        /// </summary>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        public string FromAccount { get; set; }

        /// <summary>
        /// Gets or Sets ToAccount
        /// </summary>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        public string ToAccount { get; set; }

        /// <summary>
        /// Gets or Sets Sortby
        /// </summary>
        public string SortBy { get; set; }

        /// <summary>
        /// Gets or Sets FiscalCode1
        /// </summary>
        public string FiscalCode1 { get; set; }

        /// <summary>
        /// Gets or Sets FiscalYear1
        /// </summary>
        public string FiscalYear1 { get; set; }

        /// <summary>
        /// Gets or Sets NumPeriod
        /// </summary>
        public string NumPeriod { get; set; }

        /// <summary>
        /// Gets or Sets FiscalCode2
        /// </summary>
        public string FiscalCode2 { get; set; }

        /// <summary>
        /// Gets or Sets FiscalYear2
        /// </summary>
        public string FiscalYear2 { get; set; }

        /// <summary>
        /// Gets or Sets CurrencyType
        /// </summary>
        public string CurrencyType { get; set; }

        /// <summary>
        /// Gets or Sets CurrencyCode
        /// </summary>
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or Sets MultiCurrency
        /// </summary>
        public string MultiCurrency { get; set; }

        /// <summary>
        /// Gets or Sets AccountGroupSortBy
        /// </summary>
        public string AccountGroupSortBy { get; set; }

        /// <summary>
        /// Gets or Sets FromGroupId
        /// </summary>
        public string FromGroupId { get; set; }

        /// <summary>
        /// Gets or Sets ToGroupId
        /// </summary>
        public string ToGroupId { get; set; }

        /// <summary>
        /// Gets or Sets FromSortId
        /// </summary>
        [Display(Name = "FromSortCodeAccountGroup", ResourceType = typeof(ChartOfAccountsReportResx))]
        public string FromSortId { get; set; }

        /// <summary>
        /// Gets or Sets ToSortId
        /// </summary>
        [Display(Name = "ToAccountGroup", ResourceType = typeof(ChartOfAccountsReportResx))]
        public string ToSortId { get; set; }

        /// <summary>
        /// Gets or Sets SegmentNum1
        /// </summary>
        public string SegmentNum1 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFrom1
        /// </summary>
        public string SegmentFrom1 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTo1
        /// </summary>
        public string SegmentTo1 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentNum2
        /// </summary>
        public string SegmentNum2 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFrom2
        /// </summary>
        public string SegmentFrom2 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTo2
        /// </summary>
        public string SegmentTo2 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentNum3
        /// </summary>
        public string SegmentNum3 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFrom3
        /// </summary>
        public string SegmentFrom3 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTo3
        /// </summary>
        public string SegmentTo3 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentNum4
        /// </summary>
        public string SegmentNum4 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFrom4
        /// </summary>
        public string SegmentFrom4 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTo4
        /// </summary>
        public string SegmentTo4 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentNum5
        /// </summary>
        public string SegmentNum5 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFrom5
        /// </summary>
        public string SegmentFrom5 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTo5
        /// </summary>
        public string SegmentTo5 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentNum6
        /// </summary>
        public string SegmentNum6 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFrom6
        /// </summary>
        public string SegmentFrom6 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTo6
        /// </summary>
        public string SegmentTo6 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentNum7
        /// </summary>
        public string SegmentNum7 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFrom7
        /// </summary>
        public string SegmentFrom7 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTo7
        /// </summary>
        public string SegmentTo7 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentNum8
        /// </summary>
        public string SegmentNum8 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFrom8
        /// </summary>
        public string SegmentFrom8 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTo8
        /// </summary>
        public string SegmentTo8 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentNum9
        /// </summary>
        public string SegmentNum9 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFrom9
        /// </summary>
        public string SegmentFrom9 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTo9
        /// </summary>
        public string SegmentTo9 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentNum10
        /// </summary>
        public string SegmentNum10 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFrom10
        /// </summary>
        public string SegmentFrom10 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTo10
        /// </summary>
        public string SegmentTo10 { get; set; }

        /// <summary>
        /// Gets or Sets DecimalPlace
        /// </summary>
        public string DecimalPlace { get; set; }

        /// <summary>
        /// Gets or Sets FiscalName1
        /// </summary>
        public string FiscalName1 { get; set; }

        /// <summary>
        /// Gets or Sets FiscalName2
        /// </summary>
        public string FiscalName2 { get; set; }

        /// <summary>
        /// Gets or Sets SegmentFroms
        /// </summary>
        public string SegmentFroms { get; set; }

        /// <summary>
        /// Gets or Sets SegmentTos
        /// </summary>
        public string SegmentTos { get; set; }

        /// <summary>
        /// Gets or Sets Usegs
        /// </summary>
        public string UseGs { get; set; }

        /// <summary>
        /// Gets or Sets Optionalfields
        /// </summary>
        public string Optionalfields { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalField1
        /// </summary>
        public string SelectOptionalField1 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalField2
        /// </summary>
        public string SelectOptionalField2 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalField3
        /// </summary>
        public string SelectOptionalField3 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldType1
        /// </summary>
        public string SelectOptionalFieldType1 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldType2
        /// </summary>
        public string SelectOptionalFieldType2 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldType3
        /// </summary>
        public string SelectOptionalFieldType3 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldDecimal1
        /// </summary>
        public string SelectOptionalFieldDecimal1 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldDecimal2
        /// </summary>
        public string SelectOptionalFieldDecimal2 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldDecimal3
        /// </summary>
        public string SelectOptionalFieldDecimal3 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldFromValue1
        /// </summary>
        public string SelectOptionalFieldFromValue1 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldToValue1
        /// </summary>
        public string SelectOptionalFieldToValue1 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldFromValue2
        /// </summary>
        public string SelectOptionalFieldFromValue2 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldToValue2
        /// </summary>
        public string SelectOptionalFieldToValue2 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldFromValue3
        /// </summary>
        public string SelectOptionalFieldFromValue3 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldToValue3
        /// </summary>
        public string SelectOptionalFieldToValue3 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldFromDisplay1
        /// </summary>
        public string SelectOptionalFieldFromDisplay1 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldToDisplay1
        /// </summary>
        public string SelectOptionalFieldToDisplay1 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldFromDisplay2
        /// </summary>
        public string SelectOptionalFieldFromDisplay2 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldToDisplay2
        /// </summary>
        public string SelectOptionalFieldToDisplay2 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldFromDisplay3
        /// </summary>
        public string SelectOptionalFieldFromDisplay3 { get; set; }

        /// <summary>
        /// Gets or Sets SelectOptionalFieldToDisplay3
        /// </summary>
        public string SelectOptionalFieldToDisplay3 { get; set; }

        /// <summary>
        /// Gets or Sets ExcludeFiscalYear
        /// </summary>
        public string ExcludeFiscalYear { get; set; }

        /// <summary>
        /// Gets or Sets ExcludeFromPeriod
        /// </summary>
        public string ExcludeFromPeriod { get; set; }

        /// <summary>
        /// Gets or Sets ExcludeToperiod
        /// </summary>
        public string ExcludeToperiod { get; set; }

        /// <summary>
        /// Gets or Sets ShowOptionalField
        /// </summary>
        public string ShowOptionalField { get; set; }

        /// <summary>
        /// Gets or Sets FromFormatAccount
        /// </summary>
        public string FromFormatAccount { get; set; }

        /// <summary>
        /// Gets or Sets ToFormatAccount
        /// </summary>
        public string ToFormatAccount { get; set; }

        /// <summary>
        /// Gets or Sets ActiveSwitch
        /// </summary>
        public string ActiveSwitch { get; set; }

        #endregion

        #region UI

        /// <summary>
        /// Gets or Sets Account With No activity
        /// </summary>
        /// <value><c>true</c> if [account with no activity]; otherwise, <c>false</c>.</value>
        [Display(Name = "ExcludeAcctWithNoAct", ResourceType = typeof(ChartOfAccountsReportResx))]
        public bool AccountWithNoActivity { get; set; }

        /// <summary>
        /// Gets or Sets Account Group by Sort code
        /// </summary>
        /// <value><c>true</c> if [act grpby sort code]; otherwise, <c>false</c>.</value>
        public bool ActGrpbySortCode { get; set; }

        /// <summary>
        /// Gets or Sets Inactive Account
        /// </summary>
        /// <value><c>true</c> if [in active account]; otherwise, <c>false</c>.</value>
        [Display(Name = "ExcludeInactiveAccount", ResourceType = typeof(ChartOfAccountsReportResx))]
        public bool InActiveAccount { get; set; }

        /// <summary>
        /// Gets or sets Account Segments List
        /// </summary>
        /// <value>The account segment values.</value>
        public List<AccountSegments> AccountSegmentValues { get; set; }

        /// <summary>
        /// Gets or sets SortBy
        /// </summary>
        /// <value>The sort.</value>
        public SortBy Sort { get; set; }

        /// <summary>
        /// Gets or sets PaperSize
        /// </summary>
        /// <value>The size of the paper.</value>
        public PaperSizeType PaperSize { get; set; }

        /// <summary>
        /// Gets or sets the type of the sort by.
        /// </summary>
        /// <value>The type of the sort by.</value>
        public SortByType SortByType { get; set; }

        /// <summary>
        /// Gets or sets Segment information from view perspective
        /// </summary>
        /// <value>The segment.</value>
        public Segment Segment { get; set; }

        /// <summary>
        /// Gets or sets account group inforamtion from view perspective
        /// </summary>
        /// <value>The sort account group.</value>
        public AccountGroup SortAccountGroup { get; set; }

        /// <summary>
        /// Gets or sets the optional fields inforamtion
        /// </summary>
        /// <value>The optional field.</value>
        public EnumerableResponse<OptionalFields> OptionalField { get; set; }

        /// <summary>
        /// SortCode AccountGroup Partial View
        /// </summary>
        /// <value>The sort code account group.</value>
        public SortAccountGroup SortCodeAccountGroup { get; set; }

        /// <summary>
        /// Gest or sets options
        /// </summary>
        /// <value>The options.</value>
        public Options Options { get; set; }

        /// <summary>
        /// Gets or sets Account Segments List
        /// </summary>
        /// <value>The account segment.</value>
        public EnumerableResponse<AccountSegment> AccountSegment { get; set; }

        /// <summary>
        /// Gets or sets Chart Of Account Report Format
        /// </summary>
        /// <value>The chart of account format.</value>
        public ChartOfAccountFormat ChartOfAccountFormat { get; set; }

        /// <summary>
        /// Gets or sets Chart Of Account Show
        /// </summary>
        /// <value>The chart of account show.</value>
        public ChartOfAccountShow ChartOfAccountShow { get; set; }

        /// <summary>
        /// Gets or sets IsTransOptionalFieldsVisible
        /// </summary>
        /// <value><c>true</c> if this instance is trans optional fields visible; otherwise, <c>false</c>.</value>
        public bool IsTransOptionalFieldsVisible { get; set; }

        /// <summary>
        /// Gets or Sets From Fiscal Calendar Year
        /// </summary>
        /// <value>From fiscal cal yr.</value>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromFiscalCalYr { get; set; }

        /// <summary>
        /// Gets or Sets From Fiscal Calendar Period
        /// </summary>
        /// <value>From fiscal cal PRD.</value>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromFiscalCalPrd { get; set; }

        /// <summary>
        /// Gets or Sets To Fiscal Calendar Period
        /// </summary>
        /// <value>To fiscal cal PRD.</value>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToFiscalCalPrd { get; set; }

        /// <summary>
        /// Gets or Sets To Fiscal Calendar Year
        /// </summary>
        /// <value>To fiscal cal yr.</value>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToFiscalCalYr { get; set; }

        /// <summary>
        /// Gets or Sets list of account segments
        /// </summary>
        /// <value>The segment list.</value>
        public EnumerableResponse<AccountSegment> SegmentList { get; set; }

        /// <summary>
        /// Gets or Sets Account Segment Total
        /// </summary>
        /// <value>The account segment total.</value>
        public string AccountSegmentTotal { get; set; }

        /// <summary>
        /// Gets or Sets OrderBy
        /// </summary>
        /// <value>The order by.</value>
        public string OrderBy { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [account segment total UI].
        /// </summary>
        /// <value><c>true</c> if [account segment total UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "AcctSegTotal", ResourceType = typeof(TransactionsListingResx))]
        public bool AccountSegmentTotalUi { get; set; }

        /// <summary>
        /// Gets or Sets Account Group
        /// </summary>
        /// <value>The account group.</value>
        public string AccountGroup { get; set; }

        /// <summary>
        /// Gets or Sets Inactive
        /// </summary>
        /// <value>The inactive.</value>
        [Display(Name = "AcctNoActivity", ResourceType = typeof(TransactionsListingResx))]
        public string Inactive { get; set; }

        /// <summary>
        /// Gets or Sets Roll Up Accounts
        /// </summary>
        /// <value>The roll up accounts.</value>
        public string RollUpAccounts { get; set; }

        /// <summary>
        /// Gets or Sets Sort Transaction
        /// </summary>
        /// <value>The sort transaction.</value>
        public string SortTransaction { get; set; }

        /// <summary>
        /// Gets or Sets Include
        /// </summary>
        /// <value>The include.</value>
        public Include Include { get; set; }

        /// <summary>
        /// Gets or Sets RollupAcountsUi
        /// </summary>
        /// <value><c>true</c> if [roll up accounts UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "UseRolledUpAmounts", ResourceType = typeof(GLCommonResx))]
        public bool RollUpAccountsUi { get; set; }

        /// <summary>
        /// Gets or Sets SortTransactionUi
        /// </summary>
        /// <value><c>true</c> if [sort transaction UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "SortTransByDate", ResourceType = typeof(GLCommonResx))]
        public bool SortTransactionUi { get; set; }

        /// <summary>
        /// Gets or Sets Include Change
        /// </summary>
        /// <value>The include change.</value>
        public string IncludeChange { get; set; }

        /// <summary>
        /// Gets or sets for Fiscal Set
        /// </summary>
        /// <value>The fiscal set.</value>
        public FiscalSet FiscalSet { get; set; }

        /// <summary>
        /// Gets or sets for IncludeOptionalFields
        /// </summary>
        /// <value><c>true</c> if [include optional fields]; otherwise, <c>false</c>.</value>
        [Display(Name = "IncludeOptionalFields", ResourceType = typeof(ChartOfAccountsReportResx))]
        public bool IncludeOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets optional grid visibility
        /// </summary>
        /// <value><c>true</c> if this instance is optional grid visible; otherwise, <c>false</c>.</value>
        public bool IsOptionalGridVisible { get; set; }

        /// <summary>
        /// Gets or sets Home currency
        /// </summary>
        /// <value>The home currency decimals.</value>
        public string HomeCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets Reporting currency
        /// </summary>
        /// <value>The reporting currency decimals.</value>
        public string ReportingCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrency
        /// </summary>
        /// <value><c>true</c> if this instance is multi currency; otherwise, <c>false</c>.</value>
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Include optional Field visible value
        /// </summary>
        /// <value><c>true</c> if this instance is include optional field visible; otherwise, <c>false</c>.</value>
        public bool IsIncludeOptionalFieldVisible { get; set; }

        /// <summary>
        /// Gets or sets Fiscal first year
        /// </summary>
        /// <value>The fiscal first year.</value>
        public string FiscalFirstYear { get; set; }

        /// <summary>
        /// Gets or sets Fiscal last year
        /// </summary>
        /// <value>The fiscal last year.</value>
        public string FiscalLastYear { get; set; }

        /// <summary>
        /// Gets Home currency 
        /// </summary>
        /// <value>The Home currency .</value>
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Security Check for the Fiscal set Comparision value in Report Format Drop down
        /// </summary>
        public bool CanInquireHistory { get; set; }

        #endregion
    }
}