﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class AccountSegment.
    /// </summary>
    public class AccountSegment : AccountSegments
    {
        #region Model Properties

        /// <summary>
        /// Gets or Sets To
        /// </summary>
        /// <value>From.</value>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        public string From { get; set; }

        /// <summary>
        /// Gets or Sets To
        /// </summary>
        /// <value>To.</value>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        public string To { get; set; }

        #endregion
    }
}