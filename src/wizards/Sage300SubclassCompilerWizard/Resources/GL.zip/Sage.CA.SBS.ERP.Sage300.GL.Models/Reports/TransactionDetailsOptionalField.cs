﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class TransactionDetailsOptionalField.
    /// </summary>
    public partial class TransactionDetailsOptionalField : ReportBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TransactionDetailsOptionalField()
        {

                SegmentList = new EnumerableResponse<AccountSegment>();
                OptionalField = new EnumerableResponse<OptionalFields>();
                TransactionOptionalFields = new EnumerableResponse<TransactionOptionalField>();

        }

        #region Properties

        /// <summary>
        /// Gets or Sets Range
        /// </summary>
        /// <value>The range.</value>
        public string Range { get; set; }

        /// <summary>
        /// Gets or Sets From Account
        /// </summary>
        /// <value>From account.</value>
        public string FromAccount { get; set; }

        /// <summary>
        /// Gets or Sets To Account
        /// </summary>
        /// <value>To account.</value>
        public string ToAccount { get; set; }

        /// <summary>
        /// Gets or Sets SortBy
        /// </summary>
        /// <value>The sort by.</value>
        public string SortBy { get; set; }

        /// <summary>
        /// Gets or Sets Fiscal Calendar Year
        /// </summary>
        /// <value>From fiscal cal yr.</value>
        public string FromFiscalCalYr { get; set; }

        /// <summary>
        /// Gets or Sets Fiscal Calendar Period
        /// </summary>
        /// <value>From fiscal cal PRD.</value>
        public string FromFiscalCalPrd { get; set; }

        /// <summary>
        /// Gets or Sets Fiscal Calendar Period
        /// </summary>
        /// <value>To fiscal cal PRD.</value>
        public string ToFiscalCalPrd { get; set; }

        /// <summary>
        /// Gets or Sets OrderBy
        /// </summary>
        /// <value>The order by.</value>
        public string OrderBy { get; set; }

        /// <summary>
        /// Gets or Sets Quantity Deimal
        /// </summary>
        /// <value>The quantity deimal.</value>
        public string QuantityDeimal { get; set; }

        /// <summary>
        /// Gets or sets the quantity title.
        /// </summary>
        /// <value>The quantity title.</value>
        public string QuantityTitle { get; set; }

        /// <summary>
        /// Gets or Sets Account Group
        /// </summary>
        /// <value>The account group.</value>
        public string AccountGroup { get; set; }

        /// <summary>
        /// Gets or Sets From Group Id
        /// </summary>
        /// <value>From group identifier.</value>
        public string FromGroupId { get; set; }

        /// <summary>
        /// Gets or Sets To Group Id
        /// </summary>
        /// <value>To group identifier.</value>
        public string ToGroupId { get; set; }

        /// <summary>
        /// Gets or Sets From Sort Id
        /// </summary>
        /// <value>From sort identifier.</value>
        public string FromSortId { get; set; }

        /// <summary>
        /// Gets or Sets To Sort Id
        /// </summary>
        /// <value>To sort identifier.</value>
        public string ToSortId { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment1 { get; set; }

        /// <summary>
        /// Gets or Sets Segment From1
        /// </summary>
        /// <value>The segment from1.</value>
        public string SegmentFrom1 { get; set; }

        /// <summary>
        /// Gets or Sets Segment To1
        /// </summary>
        /// <value>The segment to1.</value>
        public string SegmentTo1 { get; set; }

        /// <summary>
        /// Gets or Sets Segment2
        /// </summary>
        /// <value>The segment2.</value>
        public string Segment2 { get; set; }

        /// <summary>
        /// Gets or Sets Segment From2
        /// </summary>
        /// <value>The segment from2.</value>
        public string SegmentFrom2 { get; set; }

        /// <summary>
        /// Gets or Sets Segment To2
        /// </summary>
        /// <value>The segment to2.</value>
        public string SegmentTo2 { get; set; }

        /// <summary>
        /// Gets or Sets Segment3
        /// </summary>
        /// <value>The segment3.</value>
        public string Segment3 { get; set; }

        /// <summary>
        /// Gets or Sets Segment From3
        /// </summary>
        /// <value>The segment from3.</value>
        public string SegmentFrom3 { get; set; }

        /// <summary>
        /// Gets or Sets Segment To3
        /// </summary>
        /// <value>The segment to3.</value>
        public string SegmentTo3 { get; set; }

        /// <summary>
        /// Gets or Sets Segment4
        /// </summary>
        /// <value>The segment4.</value>
        public string Segment4 { get; set; }

        /// <summary>
        /// Gets or Sets Segment From4
        /// </summary>
        /// <value>The segment from4.</value>
        public string SegmentFrom4 { get; set; }

        /// <summary>
        /// Gets or Sets Segment To4
        /// </summary>
        /// <value>The segment to4.</value>
        public string SegmentTo4 { get; set; }

        /// <summary>
        /// Gets or Sets Segment5
        /// </summary>
        /// <value>The segment5.</value>
        public string Segment5 { get; set; }

        /// <summary>
        /// Gets or Sets Segment From5
        /// </summary>
        /// <value>The segment from5.</value>
        public string SegmentFrom5 { get; set; }

        /// <summary>
        /// Gets or Sets Segment To5
        /// </summary>
        /// <value>The segment to5.</value>
        public string SegmentTo5 { get; set; }

        /// <summary>
        /// Gets or Sets Segment6
        /// </summary>
        /// <value>The segment6.</value>
        public string Segment6 { get; set; }

        /// <summary>
        /// Gets or Sets Segment From6
        /// </summary>
        /// <value>The segment from6.</value>
        public string SegmentFrom6 { get; set; }

        /// <summary>
        /// Gets or Sets Segment To6
        /// </summary>
        /// <value>The segment to6.</value>
        public string SegmentTo6 { get; set; }

        /// <summary>
        /// Gets or Sets Segment7
        /// </summary>
        /// <value>The segment7.</value>
        public string Segment7 { get; set; }

        /// <summary>
        /// Gets or Sets Segment From7
        /// </summary>
        /// <value>The segment from7.</value>
        public string SegmentFrom7 { get; set; }

        /// <summary>
        /// Gets or Sets Segment To7
        /// </summary>
        /// <value>The segment to7.</value>
        public string SegmentTo7 { get; set; }

        /// <summary>
        /// Gets or Sets Segment8
        /// </summary>
        /// <value>The segment8.</value>
        public string Segment8 { get; set; }

        /// <summary>
        /// Gets or Sets Segment From8
        /// </summary>
        /// <value>The segment from8.</value>
        public string SegmentFrom8 { get; set; }

        /// <summary>
        /// Gets or Sets Segment To8
        /// </summary>
        /// <value>The segment to8.</value>
        public string SegmentTo8 { get; set; }

        /// <summary>
        /// Gets or Sets Segment9
        /// </summary>
        /// <value>The segment9.</value>
        public string Segment9 { get; set; }

        /// <summary>
        /// Gets or Sets Segment From9
        /// </summary>
        /// <value>The segment from9.</value>
        public string SegmentFrom9 { get; set; }

        /// <summary>
        /// Gets or Sets Segment To9
        /// </summary>
        /// <value>The segment to9.</value>
        public string SegmentTo9 { get; set; }

        /// <summary>
        /// Gets or Sets Segment10
        /// </summary>
        /// <value>The segment10.</value>
        public string Segment10 { get; set; }

        /// <summary>
        /// Gets or Sets Segment From10
        /// </summary>
        /// <value>The segment from10.</value>
        public string SegmentFrom10 { get; set; }

        /// <summary>
        /// Gets or Sets Segment To10
        /// </summary>
        /// <value>The segment to10.</value>
        public string SegmentTo10 { get; set; }

        /// <summary>
        /// Gets or Sets Currency
        /// </summary>
        /// <value>The currency.</value>
        public string Currency { get; set; }

        /// <summary>
        /// Gets or Sets Account Segment Total
        /// </summary>
        /// <value>The account segment total.</value>
        public string AccountSegmentTotal { get; set; }

        /// <summary>
        /// Gets or Sets UseGs
        /// </summary>
        /// <value>The use gs.</value>
        public string UseGs { get; set; }

        /// <summary>
        /// Gets or Sets Select OptionalField1
        /// </summary>
        /// <value>The select optional field1.</value>
        public string SelectOptionalField1 { get; set; }

        /// <summary>
        /// Gets or Sets Select OptionalField2
        /// </summary>
        /// <value>The select optional field2.</value>
        public string SelectOptionalField2 { get; set; }

        /// <summary>
        /// Gets or Sets Select OptionalField3
        /// </summary>
        /// <value>The select optional field3.</value>
        public string SelectOptionalField3 { get; set; }

        /// <summary>
        /// Gets or Sets Select OptionalField Type1
        /// </summary>
        /// <value>The select optional field type1.</value>
        public string SelectOptionalFieldType1 { get; set; }

        /// <summary>
        /// Gets or Sets Select OptionalField Type2
        /// </summary>
        /// <value>The select optional field type2.</value>
        public string SelectOptionalFieldType2 { get; set; }

        /// <summary>
        /// Gets or Sets Select OptionalField Type3
        /// </summary>
        /// <value>The select optional field type3.</value>
        public string SelectOptionalFieldType3 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field Decimal1
        /// </summary>
        /// <value>The select optional field decimal1.</value>
        public string SelectOptionalFieldDecimal1 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field Decimal2
        /// </summary>
        /// <value>The select optional field decimal2.</value>
        public string SelectOptionalFieldDecimal2 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field Decimal3
        /// </summary>
        /// <value>The select optional field decimal3.</value>
        public string SelectOptionalFieldDecimal3 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field From Value1
        /// </summary>
        /// <value>The select optional field from value1.</value>
        public string SelectOptionalFieldFromValue1 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field To Value1
        /// </summary>
        /// <value>The select optional field to value1.</value>
        public string SelectOptionalFieldToValue1 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field From Value2
        /// </summary>
        /// <value>The select optional field from value2.</value>
        public string SelectOptionalFieldFromValue2 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field To Value2
        /// </summary>
        /// <value>The select optional field to value2.</value>
        public string SelectOptionalFieldToValue2 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field From Value3
        /// </summary>
        /// <value>The select optional field from value3.</value>
        public string SelectOptionalFieldFromValue3 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field To Value3
        /// </summary>
        /// <value>The select optional field to value3.</value>
        public string SelectOptionalFieldToValue3 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field From Display1
        /// </summary>
        /// <value>The select optional field from display1.</value>
        public string SelectOptionalFieldFromDisplay1 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field To Display1
        /// </summary>
        /// <value>The select optional field to display1.</value>
        public string SelectOptionalFieldToDisplay1 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field From Display2
        /// </summary>
        /// <value>The select optional field from display2.</value>
        public string SelectOptionalFieldFromDisplay2 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field To Display2
        /// </summary>
        /// <value>The select optional field to display2.</value>
        public string SelectOptionalFieldToDisplay2 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field From Display3
        /// </summary>
        /// <value>The select optional field from display3.</value>
        public string SelectOptionalFieldFromDisplay3 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field To Display3
        /// </summary>
        /// <value>The select optional field to display3.</value>
        public string SelectOptionalFieldToDisplay3 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field Length1
        /// </summary>
        /// <value>The select optional field length1.</value>
        public string SelectOptionalFieldLength1 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field Length2
        /// </summary>
        /// <value>The select optional field length2.</value>
        public string SelectOptionalFieldLength2 { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field Length3
        /// </summary>
        /// <value>The select optional field length3.</value>
        public string SelectOptionalFieldLength3 { get; set; }

        /// <summary>
        /// Gets or Sets Selected Optionalfield1
        /// </summary>
        /// <value>The selected optional field1.</value>
        public string SelectedOptionalField1 { get; set; }

        /// <summary>
        /// Gets or Sets Seletced OptionalField2
        /// </summary>
        /// <value>The selected optional field2.</value>
        public string SelectedOptionalField2 { get; set; }

        /// <summary>
        /// Gets or Sets Seletced OptionalField3
        /// </summary>
        /// <value>The selected optional field3.</value>
        public string SelectedOptionalField3 { get; set; }

        /// <summary>
        /// Gets or Sets Seletced OptionalFieldType1
        /// </summary>
        /// <value>The selected optional field type1.</value>
        public string SelectedOptionalFieldType1 { get; set; }

        /// <summary>
        /// Property Gets or Sets Seletced OptionalFieldType2
        /// </summary>
        /// <value>The selected optional field type2.</value>
        public string SelectedOptionalFieldType2 { get; set; }

        /// <summary>
        /// Gets or Sets Seletced OptionalFieldType3
        /// </summary>
        /// <value>The selected optional field type3.</value>
        public string SelectedOptionalFieldType3 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldDescimal1
        /// </summary>
        /// <value>The selected optional field descimal1.</value>
        public string SelectedOptionalFieldDescimal1 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldDescimal2
        /// </summary>
        /// <value>The selected optional field descimal2.</value>
        public string SelectedOptionalFieldDescimal2 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldDescimal3
        /// </summary>
        /// <value>The selected optional field descimal3.</value>
        public string SelectedOptionalFieldDescimal3 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldFromValue1
        /// </summary>
        /// <value>The selected optional field from value1.</value>
        public string SelectedOptionalFieldFromValue1 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldToValue1
        /// </summary>
        /// <value>The selected optional field to value1.</value>
        public string SelectedOptionalFieldToValue1 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldFromValue2
        /// </summary>
        /// <value>The selected optional field from value2.</value>
        public string SelectedOptionalFieldFromValue2 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldToValue2
        /// </summary>
        /// <value>The selected optional field to value2.</value>
        public string SelectedOptionalFieldToValue2 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldFromValue3
        /// </summary>
        /// <value>The selected optional field from value3.</value>
        public string SelectedOptionalFieldFromValue3 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldToValue3
        /// </summary>
        /// <value>The selected optional field to value3.</value>
        public string SelectedOptionalFieldToValue3 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldFromDisplay1
        /// </summary>
        /// <value>The selected optional field from display1.</value>
        public string SelectedOptionalFieldFromDisplay1 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldToDisplay1
        /// </summary>
        /// <value>The selected optional field to display1.</value>
        public string SelectedOptionalFieldToDisplay1 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldFromDisplay2
        /// </summary>
        /// <value>The selected optional field from display2.</value>
        public string SelectedOptionalFieldFromDisplay2 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldToDisplay2
        /// </summary>
        /// <value>The selected optional field to display2.</value>
        public string SelectedOptionalFieldToDisplay2 { get; set; }

        /// <summary>
        /// Gets or Sets SelectedOptionalFieldFromDisplay3
        /// </summary>
        /// <value>The selected optional field from display3.</value>
        public string SelectedOptionalFieldFromDisplay3 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldToDisplay3
        /// </summary>
        /// <value>The selected optional field to display3.</value>
        public string SelectedOptionalFieldToDisplay3 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldLength1
        /// </summary>
        /// <value>The selected optional field length1.</value>
        public string SelectedOptionalFieldLength1 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldLength2
        /// </summary>
        /// <value>The selected optional field length2.</value>
        public string SelectedOptionalFieldLength2 { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldLength3
        /// </summary>
        /// <value>The selected optional field length3.</value>
        public string SelectedOptionalFieldLength3 { get; set; }

        /// <summary>
        /// Gets or Sets Amount decimal
        /// </summary>
        /// <value>The amount decimal.</value>
        public string AmountDecimal { get; set; }

        /// <summary>
        /// Gets or Sets From Format Account
        /// </summary>
        /// <value>From format account.</value>
        public string FromFormatAccount { get; set; }

        /// <summary>
        /// Gets or Sets To Format Account
        /// </summary>
        /// <value>To format account.</value>
        public string ToFormatAccount { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [sort transaction UI].
        /// </summary>
        /// <value><c>true</c> if [sort transaction UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "SortTransByDate", ResourceType = typeof (GLCommonResx))]
        public bool SortTransactionUi { get; set; }

        #endregion

        #region UI properties

        /// <summary>
        /// Gets or sets a value indicating whether [account group UI].
        /// </summary>
        /// <value><c>true</c> if [account group UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "SelectAccountGroupsBySortCodeRange", ResourceType = typeof (GLCommonResx))]
        public bool AccountGroupUi { get; set; }

        /// <summary>
        /// Gets or sets the selected segment.
        /// </summary>
        /// <value>The selected segment.</value>
        public string SelectedSegment { get; set; }

        /// <summary>
        /// Gets or sets the options.
        /// </summary>
        /// <value>The options.</value>
        public Options Options { get; set; }

        /// <summary>
        /// Gets or sets Account Segments List
        /// </summary>
        /// <value>The account segment.</value>
        public EnumerableResponse<AccountSegment> AccountSegment { get; set; }

        /// <summary>
        /// Gets or sets the segment list.
        /// </summary>
        /// <value>The segment list.</value>
        public EnumerableResponse<AccountSegment> SegmentList { get; set; }

        /// <summary>
        /// Gets or sets the transaction optional field.
        /// </summary>
        /// <value>The transaction optional field.</value>
        public string TransactionOptionalField { get; set; }

        /// <summary>
        /// Gets or sets the optional fields.
        /// </summary>
        /// <value>The optional fields.</value>
        public string OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets the optional field.
        /// </summary>
        /// <value>The optional field.</value>
        public EnumerableResponse<OptionalFields> OptionalField { get; set; }

        /// <summary>
        /// Gets or sets the transaction optional fields.
        /// </summary>
        /// <value>The transaction optional fields.</value>
        public EnumerableResponse<TransactionOptionalField> TransactionOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets the sort account group.
        /// </summary>
        /// <value>The sort account group.</value>
        public AccountGroup SortAccountGroup { get; set; }

        /// <summary>
        /// Gets or Sets Segment Code List
        /// </summary>
        /// <value>The segment codes.</value>
        public List<AccountSegments> SegmentCodes { get; set; }

        /// <summary>
        /// SortCode AccountGroup Partial View
        /// </summary>
        /// <value>The sort code account group.</value>
        public SortAccountGroup SortCodeAccountGroup { get; set; }

        /// <summary>
        /// Segment Partial View
        /// </summary>
        /// <value>The segment.</value>
        public Segment Segment { get; set; }

        /// <summary>
        /// Gets or sets SortBy
        /// </summary>
        /// <value>The sort.</value>
        public SortBy Sort { get; set; }

        /// <summary>
        /// Currency type Partial view
        /// </summary>
        /// <value>The currency types.</value>
        public CurrencyTypes CurrencyTypes { get; set; }

        /// <summary>
        /// SortByType Partial view.
        /// </summary>
        /// <value>The type of the sort by.</value>
        public SortByType SortByType { get; set; }

        /// <summary>
        /// Get or set paper size for print.
        /// </summary>
        /// <value>The type of the paper size.</value>
        public PaperSizeType PaperSizeType { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is license ok.
        /// </summary>
        /// <value><c>true</c> if this instance is license ok; otherwise, <c>false</c>.</value>
        public bool IsLicenseOk { get; set; }

        /// <summary>
        /// Gets or sets Fiscal first year
        /// </summary>
        /// <value>The fiscal first year.</value>
        public string FiscalFirstYear { get; set; }

        /// <summary>
        /// Gets or sets Fiscal last year
        /// </summary>
        /// <value>The fiscal last year.</value>
        public string FiscalLastYear { get; set; }

        #endregion
    }
}