// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Contains list of AccountPermissionReport Constants
    /// </summary>
    public partial class AccountPermissionReport
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "c288a612-7f62-45b3-b5ad-0693137679b1";

        #region Properties

        /// <summary>
        /// Contains list of AccountPermissionReport Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for Fruser
            /// </summary>
            public const string FromUser = "FRUSER";

            /// <summary>
            /// Property for Touser
            /// </summary>
            public const string ToUser = "TOUSER";

            /// <summary>
            /// Property for Default Access
            /// </summary>
            public const string DefaultAccess = "DEFACCESS";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of AccountPermissionReport Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for Fruser
            /// </summary>
            public const int Fruser = 2;

            /// <summary>
            /// Property Indexer for Touser
            /// </summary>
            public const int Touser = 3;

            /// <summary>
            /// Property Indexer for Defaccess
            /// </summary>
            public const int Defaccess = 4;

        }

        #endregion

    }
}
