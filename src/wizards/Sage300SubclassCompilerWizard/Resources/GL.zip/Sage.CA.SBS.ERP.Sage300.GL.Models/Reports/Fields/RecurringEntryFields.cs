﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Contains list of Recurring Entries Report Constants
    /// </summary>
    public partial class RecurringEntry
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "00ddaa1b-88d3-4f2e-8e28-abc73808f796";

        /// <summary>
        /// Class Fields
        /// </summary>
        public class Fields
        {
            #region Field Names

            /// <summary>
            /// Property for FromRecurringEntryCode
            /// </summary>
            public const string FromRecurringEntryCode = "FROMCODE";

            /// <summary>
            /// Property for ToRecurringEntryCode
            /// </summary>
            public const string ToRecurringEntryCode = "TOCODE";

            /// <summary>
            /// Property for ShowSch
            /// </summary>
            public const string ShowSch = "SHOWSCH";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "OPTIONALFIELDS";

            /// <summary>
            /// Property for NumberOfDecimalsForQty
            /// </summary>
            public const string NumberOfDecimalsForQty = "QTYDEC";

            /// <summary>
            /// Property for Functional Currency
            /// </summary>
            public const string FcurnDec = "FCURNDEC";

            /// <summary>
            /// Property for Multi Currency
            /// </summary>
            public const string MultCurn = "MULTCURN";

            /// <summary>
            /// Property for ShowsRecurringEntry
            /// </summary>
            public const string ShowsRccur = "SHOWSRCCUR";

            /// <summary>
            /// Property for Usegs
            /// </summary>
            public const string Usegs = "USEGS";

            /// <summary>
            /// Property for User
            /// </summary>
            public const string User = "USER";

            #endregion
        }
    }
}