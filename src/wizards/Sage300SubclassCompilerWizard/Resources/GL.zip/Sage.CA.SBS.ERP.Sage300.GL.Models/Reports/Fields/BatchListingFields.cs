﻿/* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class BatchListing.
    /// </summary>
    public partial class BatchListing
    {
        /// <summary>
        /// Unique name
        /// </summary>
        public const string ViewName = "1af65614-6be3-4a33-a33f-5e4653df21fa";

        /// <summary>
        /// Contains list of Batch Listing Report Constants
        /// </summary>
        public class Fields
        {
            #region Field Names

            /// <summary>
            /// Property for FromBatchNumber
            /// </summary>
            public const string FromBatchNumber = "FRBATCH";

            /// <summary>
            /// Property for ToBatchNumber
            /// </summary>
            public const string ToBatchNumber = "TOBATCH";

            /// <summary>
            /// Property for FromLedger
            /// </summary>
            public const string FromLedger = "FRLDGR";

            /// <summary>
            /// Property for ToLedger
            /// </summary>
            public const string ToLedger = "TOLDGR";

            /// <summary>
            /// Property for FromDate
            /// </summary>
            public const string FromDate = "FRDATE";

            /// <summary>
            /// Property for ToDate
            /// </summary>
            public const string ToDate = "TODATE";

            /// <summary>
            /// Property for Types
            /// </summary>
            public const string Types = "TYPES";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "STATUS";

            /// <summary>
            /// Property for FcurnDec
            /// </summary>
            public const string FcurnDec = "FCURNDEC";

            /// <summary>
            /// Property for NumberOfDecimalsForQty
            /// </summary>
            public const string NumberOfDecimalsForQty = "QTYDEC";

            /// <summary>
            /// Property for QtyHdg
            /// </summary>
            public const string QtyHdg = "QTYHDG";

            /// <summary>
            /// Property for UnitHdg
            /// </summary>
            public const string UnitHdg = "UNITHDG";

            /// <summary>
            /// Property for Query
            /// </summary>
            public const string Query = "QUERY";

            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "PRINTED";

            /// <summary>
            /// Property for Usegs
            /// </summary>
            public const string Usegs = "USEGS";

            /// <summary>
            /// Property for User
            /// </summary>
            public const string User = "USER";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "OPTIONALFIELDS";

            /// <summary>
            /// Property for IctInstalled
            /// </summary>
            public const string IctInstalled = "ICTINSTALLED";

            /// <summary>
            /// Property for IctMulti
            /// </summary>
            public const string IctMulti = "ICTMULTI";

            /// <summary>
            /// Property for InclDetails
            /// </summary>
            public const string InclDetails = "INCLDETAILS";

            /// <summary>
            /// E-09360
            /// Property for InclTaxInformation
            /// </summary>
            public const string InclTaxInformation = "INCLUDETAXINFORMATION";


            /// <summary>
            /// property for date category
            /// </summary>
            public const string DateCategory = "DATECATEGORY";

            #endregion
        }
    }
}