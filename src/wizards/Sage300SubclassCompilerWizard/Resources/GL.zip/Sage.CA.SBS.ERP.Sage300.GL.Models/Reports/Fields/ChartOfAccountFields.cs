﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Contains list of Chart Of Accounts Constants 
    /// </summary>
    public partial class ChartOfAccount
    {
        /// <summary>
        /// Unique name
        /// </summary>
        public const string ViewName = "72d6ca41-ce76-47f6-88cd-8d67a7942eb3";
        /// <summary>
        /// Chart of Accounts Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Constant for Range
            /// </summary>
            public const string Range = "RANGE";

            /// <summary>
            /// Constant for Range
            /// </summary>
            public const string Orderby = "ORDERBY";

            /// <summary>
            /// Constant for FromAccount
            /// </summary>
            public const string FromAccount = "FROMACCT";

            /// <summary>
            /// Constant for ToAccount
            /// </summary>
            public const string ToAccount = "TOACCT";

            /// <summary>
            /// Constant for Sortby
            /// </summary>
            public const string Sortby = "SORTBY";

            /// <summary>
            /// Constant for FiscalCode1
            /// </summary>
            public const string FiscalCode1 = "FSCODE1";

            /// <summary>
            /// Constant for FiscalYear1
            /// </summary>
            public const string FiscalYear1 = "FSYEAR1";

            /// <summary>
            /// Constant for NumPeriod
            /// </summary>
            public const string NumPeriod = "NUMPERD";

            /// <summary>
            /// Constant for FiscalCode2
            /// </summary>
            public const string FiscalCode2 = "FSCODE2";

            /// <summary>
            /// Constant for FiscalYear2
            /// </summary>
            public const string FiscalYear2 = "FSYEAR2";

            /// <summary>
            /// Constant for CurrencyType
            /// </summary>
            public const string CurrencyType = "CURNTYPE";

            /// <summary>
            /// Constant for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CURNCODE";

            /// <summary>
            /// Constant for MultiCurrency
            /// </summary>
            public const string MultiCurrency = "MULTCURN";

            /// <summary>
            /// Constant for AccountGroupSortBy
            /// </summary>
            public const string AccountGroupSortBy = "ACTGRPSB";

            /// <summary>
            /// Constant for FromGroupId
            /// </summary>
            public const string FromGroupId = "FRGRPID";

            /// <summary>
            /// Constant for ToGroupId
            /// </summary>
            public const string ToGroupId = "TOGRPID";

            /// <summary>
            /// Constant for FromSortId
            /// </summary>
            public const string FromSortId = "FRSORTID";

            /// <summary>
            /// Constant for ToSortId
            /// </summary>
            public const string ToSortId = "TOSORTID";

            /// <summary>
            /// Constant for SegmentNum1
            /// </summary>
            public const string SegmentNum1 = "SEGNM1";

            /// <summary>
            /// Constant for SegmentFrom1
            /// </summary>
            public const string SegmentFrom1 = "SEGFR1";

            /// <summary>
            /// Constant for SegmentTo1
            /// </summary>
            public const string SegmentTo1 = "SEGTO1";

            /// <summary>
            /// Constant for SegmentNum2
            /// </summary>
            public const string SegmentNum2 = "SEGNM2";

            /// <summary>
            /// Constant for SegmentFrom2
            /// </summary>
            public const string SegmentFrom2 = "SEGFR2";

            /// <summary>
            /// Constant for SegmentTo2
            /// </summary>
            public const string SegmentTo2 = "SEGTO2";

            /// <summary>
            /// Constant for SegmentNum3
            /// </summary>
            public const string SegmentNum3 = "SEGNM3";

            /// <summary>
            /// Constant for SegmentFrom3
            /// </summary>
            public const string SegmentFrom3 = "SEGFR3";

            /// <summary>
            /// Constant for SegmentTo3
            /// </summary>
            public const string SegmentTo3 = "SEGTO3";

            /// <summary>
            /// Constant for SegmentNum4
            /// </summary>
            public const string SegmentNum4 = "SEGNM4";

            /// <summary>
            /// Constant for SegmentFrom4
            /// </summary>
            public const string SegmentFrom4 = "SEGFR4";

            /// <summary>
            /// Constant for SegmentTo4
            /// </summary>
            public const string SegmentTo4 = "SEGTO4";

            /// <summary>
            /// Constant for SegmentNum5
            /// </summary>
            public const string SegmentNum5 = "SEGNM5";

            /// <summary>
            /// Constant for SegmentFrom5
            /// </summary>
            public const string SegmentFrom5 = "SEGFR5";

            /// <summary>
            /// Constant for SegmentTo5
            /// </summary>
            public const string SegmentTo5 = "SEGTO5";

            /// <summary>
            /// Constant for SegmentNum6
            /// </summary>
            public const string SegmentNum6 = "SEGNM6";

            /// <summary>
            /// Constant for SegmentFrom6
            /// </summary>
            public const string SegmentFrom6 = "SEGFR6";

            /// <summary>
            /// Constant for SegmentTo6
            /// </summary>
            public const string SegmentTo6 = "SEGTO6";

            /// <summary>
            /// Constant for SegmentNum7
            /// </summary>
            public const string SegmentNum7 = "SEGNM7";

            /// <summary>
            /// Constant for SegmentFrom7
            /// </summary>
            public const string SegmentFrom7 = "SEGFR7";

            /// <summary>
            /// Constant for SegmentTo7
            /// </summary>
            public const string SegmentTo7 = "SEGTO7";

            /// <summary>
            /// Constant for SegmentNum8
            /// </summary>
            public const string SegmentNum8 = "SEGNM8";

            /// <summary>
            /// Constant for SegmentFrom8
            /// </summary>
            public const string SegmentFrom8 = "SEGFR8";

            /// <summary>
            /// Constant for SegmentTo8
            /// </summary>
            public const string SegmentTo8 = "SEGTO8";

            /// <summary>
            /// Constant for SegmentNum9
            /// </summary>
            public const string SegmentNum9 = "SEGNM9";

            /// <summary>
            /// Constant for SegmentFrom9
            /// </summary>
            public const string SegmentFrom9 = "SEGFR9";

            /// <summary>
            /// Constant for SegmentTo9
            /// </summary>
            public const string SegmentTo9 = "SEGTO9";

            /// <summary>
            /// Constant for SegmentNum10
            /// </summary>
            public const string SegmentNum10 = "SEGNM10";

            /// <summary>
            /// Constant for SegmentFrom10
            /// </summary>
            public const string SegmentFrom10 = "SEGFR10";

            /// <summary>
            /// Constant for SegmentTo10
            /// </summary>
            public const string SegmentTo10 = "SEGTO10";

            /// <summary>
            /// Constant for DecimalPlace
            /// </summary>
            public const string DecimalPlace = "DECPL";

            /// <summary>
            /// Constant for FiscalName1
            /// </summary>
            public const string FiscalName1 = "FSNAME1";

            /// <summary>
            /// Constant for FiscalName2
            /// </summary>
            public const string FiscalName2 = "FSNAME2";

            /// <summary>
            /// Constant for SegmentFroms
            /// </summary>
            public const string SegmentFroms = "SEGFRS";

            /// <summary>
            /// Constant for SegmentTos
            /// </summary>
            public const string SegmentTos = "SEGTOS";

            /// <summary>
            /// Constant for Usegs
            /// </summary>
            public const string Usegs = "USEGS";

            /// <summary>
            /// Constant for User
            /// </summary>
            public const string User = "USER";

            /// <summary>
            /// Constant for Optionalfields
            /// </summary>
            public const string Optionalfields = "OPTIONALFIELDS";

            /// <summary>
            /// Constant for SelectOptionalField1
            /// </summary>
            public const string SelectOptionalField1 = "SELOPTFLD1";

            /// <summary>
            /// Constant for SelectOptionalField2
            /// </summary>
            public const string SelectOptionalField2 = "SELOPTFLD2";

            /// <summary>
            /// Constant for SelectOptionalField3
            /// </summary>
            public const string SelectOptionalField3 = "SELOPTFLD3";

            /// <summary>
            /// Constant for SelectOptionalFieldType1
            /// </summary>
            public const string SelectOptionalFieldType1 = "SELOPTTYPE1";

            /// <summary>
            /// Constant for SelectOptionalFieldType2
            /// </summary>
            public const string SelectOptionalFieldType2 = "SELOPTTYPE2";

            /// <summary>
            /// Constant for SelectOptionalFieldType3
            /// </summary>
            public const string SelectOptionalFieldType3 = "SELOPTTYPE3";

            /// <summary>
            /// Constant for SelectOptionalFieldDecimal1
            /// </summary>
            public const string SelectOptionalFieldDecimal1 = "SELOPTDEC1";

            /// <summary>
            /// Constant for SelectOptionalFieldDecimal2
            /// </summary>
            public const string SelectOptionalFieldDecimal2 = "SELOPTDEC2";

            /// <summary>
            /// Constant for SelectOptionalFieldDecimal3
            /// </summary>
            public const string SelectOptionalFieldDecimal3 = "SELOPTDEC3";

            /// <summary>
            /// Constant for SelectOptionalFieldFromValue1
            /// </summary>
            public const string SelectOptionalFieldFromValue1 = "SELOPTFRVAL1";

            /// <summary>
            /// Constant for SelectOptionalFieldToValue1
            /// </summary>
            public const string SelectOptionalFieldToValue1 = "SELOPTTOVAL1";

            /// <summary>
            /// Constant for SelectOptionalFieldFromValue2
            /// </summary>
            public const string SelectOptionalFieldFromValue2 = "SELOPTFRVAL2";

            /// <summary>
            /// Constant for SelectOptionalFieldToValue2
            /// </summary>
            public const string SelectOptionalFieldToValue2 = "SELOPTTOVAL2";

            /// <summary>
            /// Constant for SelectOptionalFieldFromValue3
            /// </summary>
            public const string SelectOptionalFieldFromValue3 = "SELOPTFRVAL3";

            /// <summary>
            /// Constant for SelectOptionalFieldToValue3
            /// </summary>
            public const string SelectOptionalFieldToValue3 = "SELOPTTOVAL3";

            /// <summary>
            /// Constant for SelectOptionalFieldFromDisplay1
            /// </summary>
            public const string SelectOptionalFieldFromDisplay1 = "SELOPTFRDISP1";

            /// <summary>
            /// Constant for SelectOptionalFieldToDisplay1
            /// </summary>
            public const string SelectOptionalFieldToDisplay1 = "SELOPTTODISP1";

            /// <summary>
            /// Constant for SelectOptionalFieldFromDisplay2
            /// </summary>
            public const string SelectOptionalFieldFromDisplay2 = "SELOPTFRDISP2";

            /// <summary>
            /// Constant for SelectOptionalFieldToDisplay2
            /// </summary>
            public const string SelectOptionalFieldToDisplay2 = "SELOPTTODISP2";

            /// <summary>
            /// Constant for SelectOptionalFieldFromDisplay3
            /// </summary>
            public const string SelectOptionalFieldFromDisplay3 = "SELOPTFRDISP3";

            /// <summary>
            /// Constant for SelectOptionalFieldToDisplay3
            /// </summary>
            public const string SelectOptionalFieldToDisplay3 = "SELOPTTODISP3";

            /// <summary>
            /// Constant for ExcludeFiscalYear
            /// </summary>
            public const string ExcludeFiscalYear = "EXCLYR";

            /// <summary>
            /// Constant for ExcludeFromPeriod
            /// </summary>
            public const string ExcludeFromPeriod = "EXCLFRPERD";

            /// <summary>
            /// Constant for ExcludeToperiod
            /// </summary>
            public const string ExcludeToperiod = "EXCLTOPERD";

            /// <summary>
            /// Constant for ShowOptionalField
            /// </summary>
            public const string ShowOptionalField = "SHOWOPT";

            /// <summary>
            /// Constant for FromFormatAccount
            /// </summary>
            public const string FromFormatAccount = "FROMFMTACCT";

            /// <summary>
            /// Constant for ToFormatAccount
            /// </summary>
            public const string ToFormatAccount = "TOFMTACCT";

            /// <summary>
            /// Constant for ActiveSwitch
            /// </summary>
            public const string ActiveSwitch = "ACTIVESW";

            /// <summary>
            /// Constant for RollupAccounts
            /// </summary>
            public const string RollupAccounts = "ROLLUPACCTS";

            #endregion
        }

    }
}
