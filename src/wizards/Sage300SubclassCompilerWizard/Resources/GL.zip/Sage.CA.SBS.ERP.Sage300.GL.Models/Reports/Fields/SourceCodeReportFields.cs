// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
// ReSharper restore CheckNamespace
{
	/// <summary>
	/// Contains list of SourceCode Constants
	/// </summary>
	public partial class SourceCodeReport
    {
        #region Entity

        /// <summary>
        /// Entity Name
		/// </summary>
		public const string EntityName = "41e43b4d-85f9-4dbd-890f-a2598b474cdf";

        #endregion

        #region Fields Properties

        /// <summary>
		/// Contains list of SourceCode Field Constants
		/// </summary>
		public class Fields
		{
			/// <summary>
			/// Property for From Source Ledger
			/// </summary>
			public const string FromSourceLedger = "FRLDGR";

			/// <summary>
			/// Property for From Source Type
			/// </summary>
			public const string FromSourceType = "FRTYPE";

			/// <summary>
            /// Property for To Source Ledger
			/// </summary>
			public const string ToSourceLedger = "TOLDGR";

			/// <summary>
            /// Property for To Source Type
			/// </summary>
			public const string ToSourceType = "TOTYPE";
		}

		#endregion

        #region Index Properties

        /// <summary>
		/// Contains list of SourceCode Index Constants
		/// </summary>
		public class Index
		{
			/// <summary>
            /// Property Indexer for From Source Ledger
			/// </summary>
            public const int FromSourceLedger = 2;

			/// <summary>
            /// Property Indexer for From Source Type
			/// </summary>
            public const int FromSourceType = 3;

			/// <summary>
            /// Property Indexer for To Source Ledger
			/// </summary>
            public const int ToSourceLedger = 4;

			/// <summary>
            /// Property Indexer for To Source Type
			/// </summary>
            public const int ToSourceType = 5;
		}

		#endregion

	}
}