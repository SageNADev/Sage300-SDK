﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Contains List of transactional optional fields.
    /// </summary>
    public partial class TransactionDetailsOptionalField
    {
        /// <summary>
        /// Unique name
        /// </summary>
        public const string ViewName = "bc21e1b5-b9cc-499b-afa5-3a8f53790033";
        #region Fields

        /// <summary>
        /// Class Fields.
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for Range
            /// </summary>
            public const string Range = "RANGE";

            /// <summary>
            /// Property for From Account
            /// </summary>
            public const string FromAccount = "FROMACCT";

            /// <summary>
            /// Property for To Account
            /// </summary>
            public const string ToAccount = "TOACCT";

            /// <summary>
            /// Property for SortBy
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// Property for From Fiscal Calendar Year
            /// </summary>
            public const string FromFiscalCalYr = "FSYEAR";

            /// <summary>
            /// Property for From Fiscal Calendar Period
            /// </summary>
            public const string FromFiscalCalPrd = "FRPERD";

            /// <summary>
            /// Property for To Fiscal Calendar Period
            /// </summary>
            public const string ToFiscalCalPrd = "TOPERD";

            /// <summary>
            /// Property for OrderBy
            /// </summary>
            public const string OrderBy = "ORDERBY";

            /// <summary>
            /// Property for Quantity Deimal
            /// </summary>
            public const string QuantityDeimal = "QTYDEC";

            /// <summary>
            /// The quantity title
            /// </summary>
            public const string QuantityTitle = "QTYTITLE";

            /// <summary>
            /// Property for Account Group
            /// </summary>
            public const string AccountGroup = "ACTGRPSB";

            /// <summary>
            /// Property for From Group Id
            /// </summary>
            public const string FromGroupId = "FRGRPID";

            /// <summary>
            /// Property for To Group Id
            /// </summary>
            public const string ToGroupId = "TOGRPID";

            /// <summary>
            /// Property for From Sort Id
            /// </summary>
            public const string FromSortId = "FRSORTID";

            /// <summary>
            /// Property for To Sort Id
            /// </summary>
            public const string ToSortId = "TOSORTID";

            /// <summary>
            /// Property for Segment1
            /// </summary>
            public const string Segment1 = "SEGNM1";

            /// <summary>
            /// Property for Segment From1
            /// </summary>
            public const string SegmentFrom1 = "SEGFR1";

            /// <summary>
            /// Property for Segment To1
            /// </summary>
            public const string SegmentTo1 = "SEGTO1";

            /// <summary>
            /// Property for Segment2
            /// </summary>
            public const string Segment2 = "SEGNM2";

            /// <summary>
            /// Property for Segment From2
            /// </summary>
            public const string SegmentFrom2 = "SEGFR2";

            /// <summary>
            /// Property for Segment To2
            /// </summary>
            public const string SegmentTo2 = "SEGTO2";

            /// <summary>
            /// Property for Segment3
            /// </summary>
            public const string Segment3 = "SEGNM3";

            /// <summary>
            /// Property for Segment From3
            /// </summary>
            public const string SegmentFrom3 = "SEGFR3";

            /// <summary>
            /// Property for Segment To3
            /// </summary>
            public const string SegmentTo3 = "SEGTO3";

            /// <summary>
            /// Property for Segment4
            /// </summary>
            public const string Segment4 = "SEGNM4";

            /// <summary>
            /// Property for Segment From4
            /// </summary>
            public const string SegmentFrom4 = "SEGFR4";

            /// <summary>
            /// Property for Segment To4
            /// </summary>
            public const string SegmentTo4 = "SEGTO4";

            /// <summary>
            /// Property for Segment5
            /// </summary>
            public const string Segment5 = "SEGNM5";

            /// <summary>
            /// Property for Segment From5
            /// </summary>
            public const string SegmentFrom5 = "SEGFR5";

            /// <summary>
            /// Property for Segment To5
            /// </summary>
            public const string SegmentTo5 = "SEGTO5";

            /// <summary>
            /// Property for Segment6
            /// </summary>
            public const string Segment6 = "SEGNM6";

            /// <summary>
            /// Property for Segment From6
            /// </summary>
            public const string SegmentFrom6 = "SEGFR6";

            /// <summary>
            /// Property for Segment To6
            /// </summary>
            public const string SegmentTo6 = "SEGTO6";

            /// <summary>
            /// Property for Segment7
            /// </summary>
            public const string Segment7 = "SEGNM7";

            /// <summary>
            /// Property for Segment From7
            /// </summary>
            public const string SegmentFrom7 = "SEGFR7";

            /// <summary>
            /// Property for Segment To7
            /// </summary>
            public const string SegmentTo7 = "SEGTO7";

            /// <summary>
            /// Property for Segment8
            /// </summary>
            public const string Segment8 = "SEGNM8";

            /// <summary>
            /// Property for Segment From8
            /// </summary>
            public const string SegmentFrom8 = "SEGFR8";

            /// <summary>
            /// Property for Segment To8
            /// </summary>
            public const string SegmentTo8 = "SEGTO8";

            /// <summary>
            /// Property for Segment9
            /// </summary>
            public const string Segment9 = "SEGNM9";

            /// <summary>
            /// Property for Segment From9
            /// </summary>
            public const string SegmentFrom9 = "SEGFR9";

            /// <summary>
            /// Property for Segment To9
            /// </summary>
            public const string SegmentTo9 = "SEGTO9";

            /// <summary>
            /// Property for Segment10
            /// </summary>
            public const string Segment10 = "SEGNM10";

            /// <summary>
            /// Property for Segment From10
            /// </summary>
            public const string SegmentFrom10 = "SEGFR10";

            /// <summary>
            /// Property for Segment To10
            /// </summary>
            public const string SegmentTo10 = "SEGTO10";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string DateCategory = "DATECATEGORY";

            /// <summary>
            /// Property for Account Segment Total
            /// </summary>
            public const string AccountSegmentTotal = "ACCTSEGTOT";

            /// <summary>
            /// Property for UseGs
            /// </summary>
            public const string UseGs = "USEGS";

            /// <summary>
            /// Property for User
            /// </summary>
            public const string User = "USER";

            /// <summary>
            /// Property for Select OptionalField1
            /// </summary>
            public const string SelectOptionalField1 = "SELOPTFLD1";

            /// <summary>
            /// Property for Select OptionalField2
            /// </summary>
            public const string SelectOptionalField2 = "SELOPTFLD2";

            /// <summary>
            /// Property for Select OptionalField3
            /// </summary>
            public const string SelectOptionalField3 = "SELOPTFLD3";

            /// <summary>
            /// Property for Select OptionalField Type1
            /// </summary>
            public const string SelectOptionalFieldType1 = "SELOPTTYPE1";

            /// <summary>
            /// Property for Select OptionalField Type2
            /// </summary>
            public const string SelectOptionalFieldType2 = "SELOPTTYPE2";

            /// <summary>
            /// Property for Select OptionalField Type3
            /// </summary>
            public const string SelectOptionalFieldType3 = "SELOPTTYPE3";

            /// <summary>
            /// Property for Select Optional Field Decimal1
            /// </summary>
            public const string SelectOptionalFieldDecimal1 = "SELOPTDEC1";

            /// <summary>
            /// Property for Select Optional Field Decimal2
            /// </summary>
            public const string SelectOptionalFieldDecimal2 = "SELOPTDEC2";

            /// <summary>
            /// Property for Select Optional Field Decimal3
            /// </summary>
            public const string SelectOptionalFieldDecimal3 = "SELOPTDEC3";

            /// <summary>
            /// Property for Select Optional Field From Value1
            /// </summary>
            public const string SelectOptionalFieldFromValue1 = "SELOPTFRVAL1";

            /// <summary>
            /// Property for Select Optional Field To Value1
            /// </summary>
            public const string SelectOptionalFieldToValue1 = "SELOPTTOVAL1";

            /// <summary>
            /// Property for Select Optional Field From Value2
            /// </summary>
            public const string SelectOptionalFieldFromValue2 = "SELOPTFRVAL2";

            /// <summary>
            /// Property for Select Optional Field To Value2
            /// </summary>
            public const string SelectOptionalFieldToValue2 = "SELOPTTOVAL2";

            /// <summary>
            /// Property for Select Optional Field From Value3
            /// </summary>
            public const string SelectOptionalFieldFromValue3 = "SELOPTFRVAL3";

            /// <summary>
            /// Property for Select Optional Field To Value3
            /// </summary>
            public const string SelectOptionalFieldToValue3 = "SELOPTTOVAL3";

            /// <summary>
            /// Property for Select Optional Field From Display1
            /// </summary>
            public const string SelectOptionalFieldFromDisplay1 = "SELOPTFRDISP1";

            /// <summary>
            /// Property for Select Optional Field To Display1
            /// </summary>
            public const string SelectOptionalFieldToDisplay1 = "SELOPTTODISP1";

            /// <summary>
            /// Property for Select Optional Field From Display2
            /// </summary>
            public const string SelectOptionalFieldFromDisplay2 = "SELOPTFRDISP2";

            /// <summary>
            /// Property for Select Optional Field To Display2
            /// </summary>
            public const string SelectOptionalFieldToDisplay2 = "SELOPTTODISP2";

            /// <summary>
            /// Property for Select Optional Field From Display3
            /// </summary>
            public const string SelectOptionalFieldFromDisplay3 = "SELOPTFRDISP3";

            /// <summary>
            /// Property for Select Optional Field To Display3
            /// </summary>
            public const string SelectOptionalFieldToDisplay3 = "SELOPTTODISP3";

            /// <summary>
            /// Property for Select Optional Field Length1
            /// </summary>
            public const string SelectOptionalFieldLength1 = "SELOPTLEN1";

            /// <summary>
            /// Property for Select Optional Field Length2
            /// </summary>
            public const string SelectOptionalFieldLength2 = "SELOPTLEN2";

            /// <summary>
            /// Property for Select Optional Field Length3
            /// </summary>
            public const string SelectOptionalFieldLength3 = "SELOPTLEN3";

            /// <summary>
            /// Property for Selected Optionalfield1
            /// </summary>
            public const string SelectedOptionalField1 = "SELTOPTFLD1";

            /// <summary>
            /// Property for Seletced OptionalField2
            /// </summary>
            public const string SelectedOptionalField2 = "SELTOPTFLD2";

            /// <summary>
            /// Property for Seletced OptionalField3
            /// </summary>
            public const string SelectedOptionalField3 = "SELTOPTFLD3";

            /// <summary>
            /// Property for Seletced OptionalFieldType1
            /// </summary>
            public const string SelectedOptionalFieldType1 = "SELTOPTTYPE1";

            /// <summary>
            /// Property for Seletced OptionalFieldType2
            /// </summary>
            public const string SelectedOptionalFieldType2 = "SELTOPTTYPE2";

            /// <summary>
            /// Property for Seletced OptionalFieldType3
            /// </summary>
            public const string SelectedOptionalFieldType3 = "SELTOPTTYPE3";

            /// <summary>
            /// Property for Selected OptionalFieldDescimal1
            /// </summary>
            public const string SelectedOptionalFieldDescimal1 = "SELTOPTDEC1";

            /// <summary>
            /// Property for Selected OptionalFieldDescimal2
            /// </summary>
            public const string SelectedOptionalFieldDescimal2 = "SELTOPTDEC2";

            /// <summary>
            /// Property for Selected OptionalFieldDescimal3
            /// </summary>
            public const string SelectedOptionalFieldDescimal3 = "SELTOPTDEC3";

            /// <summary>
            /// Property for Selected OptionalFieldFromValue1
            /// </summary>
            public const string SelectedOptionalFieldFromValue1 = "SELTOPTFRVAL1";

            /// <summary>
            /// Property for Selected OptionalFieldToValue1
            /// </summary>
            public const string SelectedOptionalFieldToValue1 = "SELTOPTTOVAL1";

            /// <summary>
            /// Property for Selected OptionalFieldFromValue2
            /// </summary>
            public const string SelectedOptionalFieldFromValue2 = "SELTOPTFRVAL2";

            /// <summary>
            /// Property for Selected OptionalFieldToValue2
            /// </summary>
            public const string SelectedOptionalFieldToValue2 = "SELTOPTTOVAL2";

            /// <summary>
            /// Property for Selected OptionalFieldFromValue3
            /// </summary>
            public const string SelectedOptionalFieldFromValue3 = "SELTOPTFRVAL3";

            /// <summary>
            /// Property for Selected OptionalFieldToValue3
            /// </summary>
            public const string SelectedOptionalFieldToValue3 = "SELTOPTTOVAL3";

            /// <summary>
            /// Property for Selected OptionalFieldFromDisplay1
            /// </summary>
            public const string SelectedOptionalFieldFromDisplay1 = "SELTOPTFRDISP1";

            /// <summary>
            /// Property for Selected OptionalFieldToDisplay1
            /// </summary>
            public const string SelectedOptionalFieldToDisplay1 = "SELTOPTTODISP1";

            /// <summary>
            /// Property for Selected OptionalFieldFromDisplay2
            /// </summary>
            public const string SelectedOptionalFieldFromDisplay2 = "SELTOPTFRDISP2";

            /// <summary>
            /// Property for Selected OptionalFieldToDisplay2
            /// </summary>
            public const string SelectedOptionalFieldToDisplay2 = "SELTOPTTODISP2";

            /// <summary>
            /// Property for SelectedOptionalFieldFromDisplay3
            /// </summary>
            public const string SelectedOptionalFieldFromDisplay3 = "SELTOPTFRDISP3";

            /// <summary>
            /// Property for Selected OptionalFieldToDisplay3
            /// </summary>
            public const string SelectedOptionalFieldToDisplay3 = "SELTOPTTODISP3";

            /// <summary>
            /// Property for Selected OptionalFieldLength1
            /// </summary>
            public const string SelectedOptionalFieldLength1 = "SELTOPTLEN1";

            /// <summary>
            /// Property for Selected OptionalFieldLength2
            /// </summary>
            public const string SelectedOptionalFieldLength2 = "SELTOPTLEN2";

            /// <summary>
            /// Property for Selected OptionalFieldLength3
            /// </summary>
            public const string SelectedOptionalFieldLength3 = "SELTOPTLEN3";

            /// <summary>
            /// Property for Amount decimal
            /// </summary>
            public const string AmountDecimal = "AMTDEC";

            /// <summary>
            /// Property for From Format Account
            /// </summary>
            public const string FromFormatAccount = "FROMFMTACCT";

            /// <summary>
            /// Property for To Format Account
            /// </summary>
            public const string ToFormatAccount = "TOFMTACCT";

            #endregion
        }

        #endregion
    }
}