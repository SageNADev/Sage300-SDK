﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Contains list of Transaction Listing Constants 
    /// </summary>
    public partial class TransactionListing
    {
        /// <summary>
        /// View Name - New Guid
        /// </summary>
        public const string ViewName = "a751831c-dd31-472d-b1b4-c8645d0809ac";

        /// <summary>
        /// Transaction Listing Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class
            /// <summary>
            /// Property for Include Quantity 
            /// </summary>
            public const string IncludeQuantity = "INCLQTY";

            /// <summary>
            /// Property for Range
            /// </summary>
            public const string Range = "RANGE";

            /// <summary>
            /// Property for From Account
            /// </summary>
            public const string FromAccount = "FROMACCT";

            /// <summary>
            /// Property for To Account
            /// </summary>
            public const string ToAccount = "TOACCT";

            /// <summary>
            /// Property for SortBy
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// Property for From Fiscal Calendar Year
            /// </summary>
            public const string FromFiscalCalYr = "FRFSYEAR";

            /// <summary>
            /// Property for From Fiscal Calendar Period
            /// </summary>
            public const string FromFiscalCalPrd = "FRPERD";

            /// <summary>
            /// Property for To Fiscal Calendar Period
            /// </summary>
            public const string ToFiscalCalPrd = "TOPERD";

            /// <summary>
            /// Property for Inactive
            /// </summary>
            public const string Inactive = "INACTIVE";

            /// <summary>
            /// Property for OrderBy
            /// </summary>
            public const string OrderBy = "ORDERBY";

            /// <summary>
            /// Property for Order
            /// </summary>
            public const string Order = "ORDER";

            /// <summary>
            /// Property for Quantity Deimal
            /// </summary>
            public const string QuantityDeimal = "QTYDEC";

            /// <summary>
            /// Property for Account Group
            /// </summary>
            public const string AccountGroup = "ACTGRPSB";

            /// <summary>
            /// Property for From Group Id
            /// </summary>
            public const string FromGroupId = "FRGRPID";

            /// <summary>
            /// Property for To Group Id
            /// </summary>
            public const string ToGroupId = "TOGRPID";

            /// <summary>
            /// Property for From Sort Id
            /// </summary>
            public const string FromSortId = "FRSORTID";

            /// <summary>
            /// Property for To Sort Id
            /// </summary>
            public const string ToSortId = "TOSORTID";

            /// <summary>
            /// Property for Segment1
            /// </summary>
            public const string Segment1 = "SEGNM1";

            /// <summary>
            /// Property for Segment From1
            /// </summary>
            public const string SegmentFrom1 = "SEGFR1";

            /// <summary>
            /// Property for Segment To1
            /// </summary>
            public const string SegmentTo1 = "SEGTO1";

            /// <summary>
            /// Property for Segment2
            /// </summary>
            public const string Segment2 = "SEGNM2";

            /// <summary>
            /// Property for Segment From2
            /// </summary>
            public const string SegmentFrom2 = "SEGFR2";

            /// <summary>
            /// Property for Segment To2
            /// </summary>
            public const string SegmentTo2 = "SEGTO2";

            /// <summary>
            /// Property for Segment3
            /// </summary>
            public const string Segment3 = "SEGNM3";

            /// <summary>
            /// Property for Segment From3
            /// </summary>
            public const string SegmentFrom3 = "SEGFR3";

            /// <summary>
            /// Property for Segment To3
            /// </summary>
            public const string SegmentTo3 = "SEGTO3";

            /// <summary>
            /// Property for Segment4
            /// </summary>
            public const string Segment4 = "SEGNM4";

            /// <summary>
            /// Property for Segment From4
            /// </summary>
            public const string SegmentFrom4 = "SEGFR4";

            /// <summary>
            /// Property for Segment To4
            /// </summary>
            public const string SegmentTo4 = "SEGTO4";

            /// <summary>
            /// Property for Segment5
            /// </summary>
            public const string Segment5 = "SEGNM5";

            /// <summary>
            /// Property for Segment From5
            /// </summary>
            public const string SegmentFrom5 = "SEGFR5";

            /// <summary>
            /// Property for Segment To5
            /// </summary>
            public const string SegmentTo5 = "SEGTO5";

            /// <summary>
            /// Property for Segment6
            /// </summary>
            public const string Segment6 = "SEGNM6";

            /// <summary>
            /// Property for Segment From6
            /// </summary>
            public const string SegmentFrom6 = "SEGFR6";

            /// <summary>
            /// Property for Segment To6
            /// </summary>
            public const string SegmentTo6 = "SEGTO6";

            /// <summary>
            /// Property for Segment7
            /// </summary>
            public const string Segment7 = "SEGNM7";

            /// <summary>
            /// Property for Segment From7
            /// </summary>
            public const string SegmentFrom7 = "SEGFR7";

            /// <summary>
            /// Property for Segment To7
            /// </summary>
            public const string SegmentTo7 = "SEGTO7";

            /// <summary>
            /// Property for Segment8
            /// </summary>
            public const string Segment8 = "SEGNM8";

            /// <summary>
            /// Property for Segment From8
            /// </summary>
            public const string SegmentFrom8 = "SEGFR8";

            /// <summary>
            /// Property for Segment To8
            /// </summary>
            public const string SegmentTo8 = "SEGTO8";

            /// <summary>
            /// Property for Segment9
            /// </summary>
            public const string Segment9 = "SEGNM9";

            /// <summary>
            /// Property for Segment From9
            /// </summary>
            public const string SegmentFrom9 = "SEGFR9";

            /// <summary>
            /// Property for Segment To9
            /// </summary>
            public const string SegmentTo9 = "SEGTO9";

            /// <summary>
            /// Property for Segment10
            /// </summary>
            public const string Segment10 = "SEGNM10";

            /// <summary>
            /// Property for Segment From10
            /// </summary>
            public const string SegmentFrom10 = "SEGFR10";

            /// <summary>
            /// Property for Segment To10
            /// </summary>
            public const string SegmentTo10 = "SEGTO10";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for Date
            /// </summary>
            public const string Date = "DATECATEGORY";

            /// <summary>
            /// Property for Account Segment Total
            /// </summary>
            public const string AccountSegmentTotal = "ACCTSEGTOT";

            /// <summary>
            /// Property for UseGs
            /// </summary>
            public const string UseGs = "USEGS";

            /// <summary>
            /// Property for User
            /// </summary>
            public const string User = "USER";

            /// <summary>
            /// Property for Optional Fields
            /// </summary>
            public const string OptionalFields = "OPTIONALFIELDS";

            /// <summary>
            /// Property for Select OptionalField1
            /// </summary>
            public const string SelectOptionalField1 = "SELOPTFLD1";

            /// <summary>
            /// Property for Select OptionalField2
            /// </summary>
            public const string SelectOptionalField2 = "SELOPTFLD2";

            /// <summary>
            /// Property for Select OptionalField3
            /// </summary>
            public const string SelectOptionalField3 = "SELOPTFLD3";

            /// <summary>
            /// Property for Select OptionalField Type1
            /// </summary>
            public const string SelectOptionalFieldType1 = "SELOPTTYPE1";

            /// <summary>
            /// Property for Select OptionalField Type2
            /// </summary>
            public const string SelectOptionalFieldType2 = "SELOPTTYPE2";

            /// <summary>
            /// Property for Select OptionalField Type3
            /// </summary>
            public const string SelectOptionalFieldType3 = "SELOPTTYPE3";

            /// <summary>
            /// Property for Select Optional Field Decimal1
            /// </summary>
            public const string SelectOptionalFieldDecimal1 = "SELOPTDEC1";

            /// <summary>
            /// Property for Select Optional Field Decimal2
            /// </summary>
            public const string SelectOptionalFieldDecimal2 = "SELOPTDEC2";

            /// <summary>
            /// Property for Select Optional Field Decimal3
            /// </summary>
            public const string SelectOptionalFieldDecimal3 = "SELOPTDEC3";

            /// <summary>
            /// Property for Select Optional Field From Value1
            /// </summary>
            public const string SelectOptionalFieldFromValue1 = "SELOPTFRVAL1";

            /// <summary>
            /// Property for Select Optional Field To Value1
            /// </summary>
            public const string SelectOptionalFieldToValue1 = "SELOPTTOVAL1";

            /// <summary>
            /// Property for Select Optional Field From Value2
            /// </summary>
            public const string SelectOptionalFieldFromValue2 = "SELOPTFRVAL2";

            /// <summary>
            /// Property for Select Optional Field To Value2
            /// </summary>
            public const string SelectOptionalFieldToValue2 = "SELOPTTOVAL2";

            /// <summary>
            /// Property for Select Optional Field From Value3
            /// </summary>
            public const string SelectOptionalFieldFromValue3 = "SELOPTFRVAL3";

            /// <summary>
            /// Property for Select Optional Field To Value3
            /// </summary>
            public const string SelectOptionalFieldToValue3 = "SELOPTTOVAL3";

            /// <summary>
            /// Property for Select Optional Field From Display1
            /// </summary>
            public const string SelectOptionalFieldFromDisplay1 = "SELOPTFRDISP1";

            /// <summary>
            /// Property for Select Optional Field To Display1
            /// </summary>
            public const string SelectOptionalFieldToDisplay1 = "SELOPTTODISP1";

            /// <summary>
            /// Property for Select Optional Field From Display2
            /// </summary>
            public const string SelectOptionalFieldFromDisplay2 = "SELOPTFRDISP2";

            /// <summary>
            /// Property for Select Optional Field To Display2
            /// </summary>
            public const string SelectOptionalFieldToDisplay2 = "SELOPTTODISP2";

            /// <summary>
            /// Property for Select Optional Field From Display3
            /// </summary>
            public const string SelectOptionalFieldFromDisplay3 = "SELOPTFRDISP3";

            /// <summary>
            /// Property for Select Optional Field To Display3
            /// </summary>
            public const string SelectOptionalFieldToDisplay3 = "SELOPTTODISP3";

            /// <summary>
            /// Property for Select Optional Field Length1
            /// </summary>
            public const string SelectOptionalFieldLength1 = "SELOPTLEN1";

            /// <summary>
            /// Property for Select Optional Field Length2
            /// </summary>
            public const string SelectOptionalFieldLength2 = "SELOPTLEN2";

            /// <summary>
            /// Property for Select Optional Field Length3
            /// </summary>
            public const string SelectOptionalFieldLength3 = "SELOPTLEN3";

            /// <summary>
            /// Property for Roll Up Accounts
            /// </summary>
            public const string RollUpAccounts = "ROLLUPACCTS";

            /// <summary>
            /// Property for Include Change
            /// </summary>
            public const string IncludeChange = "INCLCHG";

            /// <summary>
            /// Property for From Format Account
            /// </summary>
            public const string FromFormatAccount = "FROMFMTACCT";

            /// <summary>
            /// Property for To Format Account
            /// </summary>
            public const string ToFormatAccount = "TOFMTACCT";

            /// <summary>
            /// Property for Sort Transaction
            /// </summary>
            public const string SortTransaction = "SORTTRANS";

            /// <summary>
            /// Property for To Fiscal Calendar Year
            /// </summary>
            public const string ToFiscalCalYr = "TOFSYEAR";

            /// <summary>
            /// E-09360
            /// Property for IncludeTaxInformation
            /// </summary>
            public const string IncludeTaxInformation = "INCLUDETAXINFORMATION";

            #endregion
        }

        /// <summary>
        /// Transaction Listing Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index
            /// <summary>
            /// Property Indexer for Include Quantity
            /// </summary>
            public const string IncludeQuantity = "2";

            /// <summary>
            /// Property Indexer for Range
            /// </summary>
            public const string Range = "3";

            /// <summary>
            /// Property Indexer for From Account
            /// </summary>
            public const string FromAccount = "4";

            /// <summary>
            /// Property Indexer for To Account
            /// </summary>
            public const string ToAccount = "5";

            /// <summary>
            /// Property Indexer for SortBy
            /// </summary>
            public const string SortBy = "6";

            /// <summary>
            /// Property Indexer for From Fiscal Calendar Year
            /// </summary>
            public const string FromFiscalCalYr = "7";

            /// <summary>
            /// Property Indexer for From Fiscal Calendar Period
            /// </summary>
            public const string FromFiscalCalPrd = "8";

            /// <summary>
            /// Property Indexer for To Fiscal Calendar Period
            /// </summary>
            public const string ToFiscalCalPrd = "9";

            /// <summary>
            /// Property Indexer for Inactive
            /// </summary>
            public const string Inactive = "10";

            /// <summary>
            /// Property Indexer for OrderBy
            /// </summary>
            public const string OrderBy = "11";

            /// <summary>
            /// Property Indexer for Order
            /// </summary>
            public const string Order = "12";

            /// <summary>
            /// Property Indexer for Quantity Deimal
            /// </summary>
            public const string QuantityDeimal = "13";

            /// <summary>
            /// Property Indexer for Account Group
            /// </summary>
            public const string AccountGroup = "14";

            /// <summary>
            /// Property Indexer for From Group Id
            /// </summary>
            public const string FromGroupId = "15";

            /// <summary>
            /// Property Indexer for To Group Id
            /// </summary>
            public const string ToGroupId = "16";

            /// <summary>
            /// Property Indexer for From Sort Id
            /// </summary>
            public const string FromSortId = "17";

            /// <summary>
            /// Property Indexer for To Sort Id
            /// </summary>
            public const string ToSortId = "18";

            /// <summary>
            /// Property Indexer for Segment1
            /// </summary>
            public const string Segment1 = "19";

            /// <summary>
            /// Property Indexer for Segmen tFrom1
            /// </summary>
            public const string SegmentFrom1 = "20";

            /// <summary>
            /// Property Indexer for Segment To1
            /// </summary>
            public const string SegmentTo1 = "21";

            /// <summary>
            /// Property Indexer for Segment2
            /// </summary>
            public const string Segment2 = "22";

            /// <summary>
            /// Property Indexer for Segment From2
            /// </summary>
            public const string SegmentFrom2 = "23";

            /// <summary>
            /// Property Indexer for Segment To2
            /// </summary>
            public const string SegmentTo2 = "24";

            /// <summary>
            /// Property Indexer for Segment3
            /// </summary>
            public const string Segment3 = "25";

            /// <summary>
            /// Property Indexer for Segment From3
            /// </summary>
            public const string SegmentFrom3 = "26";

            /// <summary>
            /// Property Indexer for Segment To3
            /// </summary>
            public const string SegmentTo3 = "27";

            /// <summary>
            /// Property Indexer for Segment4
            /// </summary>
            public const string Segment4 = "28";

            /// <summary>
            /// Property Indexer for Segment From4
            /// </summary>
            public const string SegmentFrom4 = "29";

            /// <summary>
            /// Property Indexer for Segment To4
            /// </summary>
            public const string SegmentTo4 = "30";

            /// <summary>
            /// Property Indexer for Segment5
            /// </summary>
            public const string Segment5 = "31";

            /// <summary>
            /// Property Indexer for Segment From5
            /// </summary>
            public const string SegmentFrom5 = "32";

            /// <summary>
            /// Property Indexer for Segment To5
            /// </summary>
            public const string SegmentTo5 = "33";

            /// <summary>
            /// Property Indexer for Segment6
            /// </summary>
            public const string Segment6 = "34";

            /// <summary>
            /// Property Indexer for Segment From6
            /// </summary>
            public const string SegmentFrom6 = "35";

            /// <summary>
            /// Property Indexer for Segment To6
            /// </summary>
            public const string SegmentTo6 = "36";

            /// <summary>
            /// Property Indexer for Segment7
            /// </summary>
            public const string Segment7 = "37";

            /// <summary>
            /// Property Indexer for Segment From7
            /// </summary>
            public const string SegmentFrom7 = "38";

            /// <summary>
            /// Property Indexer for Segment To7
            /// </summary>
            public const string SegmentTo7 = "39";

            /// <summary>
            /// Property Indexer for Segment8
            /// </summary>
            public const string Segment8 = "40";

            /// <summary>
            /// Property Indexer for Segment From8
            /// </summary>
            public const string SegmentFrom8 = "41";

            /// <summary>
            /// Property Indexer for Segment To8
            /// </summary>
            public const string SegmentTo8 = "42";

            /// <summary>
            /// Property Indexer for Segment9
            /// </summary>
            public const string Segment9 = "43";

            /// <summary>
            /// Property Indexer for Segment From9
            /// </summary>
            public const string SegmentFrom9 = "44";

            /// <summary>
            /// Property Indexer for Segment To9
            /// </summary>
            public const string SegmentTo9 = "45";

            /// <summary>
            /// Property Indexer for Segment10
            /// </summary>
            public const string Segment10 = "46";

            /// <summary>
            /// Property Indexer for Segment From10
            /// </summary>
            public const string SegmentFrom10 = "47";

            /// <summary>
            /// Property Indexer for Segment To10
            /// </summary>
            public const string SegmentTo10 = "48";

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const string Currency = "49";

            /// <summary>
            /// Property Indexer for Account Segment Total
            /// </summary>
            public const string AccountSegmentTotal = "50";

            /// <summary>
            /// Property Indexer for UseGs
            /// </summary>
            public const string UseGs = "51";

            /// <summary>
            /// Property Indexer for User
            /// </summary>
            public const string User = "52";

            /// <summary>
            /// Property Indexer for Optional Fields
            /// </summary>
            public const string OptionalFields = "53";

            /// <summary>
            /// Property Indexer for Select Optional Field1
            /// </summary>
            public const string SelectOptionalField1 = "54";

            /// <summary>
            /// Property Indexer for Select Optional Field2
            /// </summary>
            public const string SelectOptionalField2 = "55";

            /// <summary>
            /// Property Indexer for Select Optional Field3
            /// </summary>
            public const string SelectOptionalField3 = "56";

            /// <summary>
            /// Property Indexer for Select Optional Field Type1
            /// </summary>
            public const string SelectOptionalFieldType1 = "57";

            /// <summary>
            /// Property Indexer for Select Optional Field Type2
            /// </summary>
            public const string SelectOptionalFieldType2 = "58";

            /// <summary>
            /// Property Indexer for Select Optional Field Type3
            /// </summary>
            public const string SelectOptionalFieldType3 = "59";

            /// <summary>
            /// Property Indexer for Select Optional Field Decimal1
            /// </summary>
            public const string SelectOptionalFieldDecimal1 = "60";

            /// <summary>
            /// Property Indexer for Select Optional Field Decimal2
            /// </summary>
            public const string SelectOptionalFieldDecimal2 = "61";

            /// <summary>
            /// Property Indexer for Select Optional Field Decimal3
            /// </summary>
            public const string SelectOptionalFieldDecimal3 = "62";

            /// <summary>
            /// Property Indexer for Select Optional Field From Value1
            /// </summary>
            public const string SelectOptionalFieldFromValue1 = "63";

            /// <summary>
            /// Property Indexer for Select Optional Field To Value1
            /// </summary>
            public const string SelectOptionalFieldToValue1 = "64";

            /// <summary>
            /// Property Indexer for Select Optional Field From Value2
            /// </summary>
            public const string SelectOptionalFieldFromValue2 = "65";

            /// <summary>
            /// Property Indexer for Select Optional Field To Value2
            /// </summary>
            public const string SelectOptionalFieldToValue2 = "66";

            /// <summary>
            /// Property Indexer for Select Optional Field From Value3
            /// </summary>
            public const string SelectOptionalFieldFromValue3 = "67";

            /// <summary>
            /// Property Indexer for Select Optional Field To Value3
            /// </summary>
            public const string SelectOptionalFieldToValue3 = "68";

            /// <summary>
            /// Property Indexer for Select Optional Field From Display1
            /// </summary>
            public const string SelectOptionalFieldFromDisplay1 = "69";

            /// <summary>
            /// Property Indexer for Select Optional Field To Display1
            /// </summary>
            public const string SelectOptionalFieldToDisplay1 = "70";

            /// <summary>
            /// Property Indexer for Select Optional Field From Display2
            /// </summary>
            public const string SelectOptionalFieldFromDisplay2 = "71";

            /// <summary>
            /// Property Indexer for Select Optional Field To Display2
            /// </summary>
            public const string SelectOptionalFieldToDisplay2 = "72";

            /// <summary>
            /// Property Indexer for Select Optional Field From Display3
            /// </summary>
            public const string SelectOptionalFieldFromDisplay3 = "73";

            /// <summary>
            /// Property Indexer for Select Optional Field To Display3
            /// </summary>
            public const string SelectOptionalFieldToDisplay3 = "74";

            /// <summary>
            /// Property Indexer for Select Optional Field Length1
            /// </summary>
            public const string SelectOptionalFieldLength1 = "75";

            /// <summary>
            /// Property Indexer for Select Optional Field Length2
            /// </summary>
            public const string SelectOptionalFieldLength2 = "76";

            /// <summary>
            /// Property Indexer for Select Optional Field Length3
            /// </summary>
            public const string SelectOptionalFieldLength3 = "77";

            /// <summary>
            /// Property Indexer for Roll Up Accounts
            /// </summary>
            public const string RollUpAccounts = "78";

            /// <summary>
            /// Property Indexer for Include Change
            /// </summary>
            public const string IncludeChange = "79";

            /// <summary>
            /// Property Indexer for From Format Account
            /// </summary>
            public const string FromFormatAccount = "80";

            /// <summary>
            /// Property Indexer for To Format Account
            /// </summary>
            public const string ToFormatAccount = "81";

            /// <summary>
            /// Property Indexer for Sort Transaction
            /// </summary>
            public const string SortTransaction = "82";

            /// <summary>
            /// Property Indexer for To Fiscal Calendar Year
            /// </summary>
            public const string ToFiscalCalYr = "83";

            #endregion
        }
    }
}