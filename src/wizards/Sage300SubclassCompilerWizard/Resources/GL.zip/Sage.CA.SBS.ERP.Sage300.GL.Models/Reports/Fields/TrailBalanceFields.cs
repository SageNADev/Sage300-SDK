﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */


namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Contains list of TrailBalance Fields
    /// </summary>
    public partial class TrialBalance
    {
        /// <summary>
        /// Unique name
        /// </summary>
        public const string ViewName = "86170239-26ff-4f81-8570-7f7164ff3410";
        /// <summary>
        /// Trail Balance Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for Range
            /// </summary>
            public const string Range = "RANGE";

            /// <summary>
            /// Property for From Account
            /// </summary>
            public const string FromAccount = "FROMACCT";

            /// <summary>
            /// Property for To Account
            /// </summary>
            public const string ToAccount = "TOACCT";

            /// <summary>
            /// Property for SortBy
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// Property for From Fiscal Calendar Year
            /// </summary>
            public const string FiscalCalYr = "FSYEAR";

            /// <summary>
            /// Property for From Trail Balance Date
            /// </summary>
            public const string TrailBalanceDate = "TBDATE";

            /// <summary>
            /// Property for From Trail Balance Date
            /// </summary>
            public const string TrailBalanceDate2 = "TBDATE2";

            /// <summary>
            /// Property for Inactive
            /// </summary>
            public const string Inactive = "INACTIVE";

            /// <summary>
            /// Property for FiscalCalPrd
            /// </summary>
            public const string FiscalCalPrd = "YTDPERD";

            /// <summary>
            /// Property for OrderBy
            /// </summary>
            public const string OrderBy = "ORDERBY";

            /// <summary>
            /// Property for Adjust
            /// </summary>
            public const string Adjust = "ADJUST";

            /// <summary>
            /// Property for Account Group
            /// </summary>
            public const string AccountGroup = "ACTGRPSB";

            /// <summary>
            /// Property for From Group Id
            /// </summary>
            public const string FromGroupId = "FRGRPID";

            /// <summary>
            /// Property for To Group Id
            /// </summary>
            public const string ToGroupId = "TOGRPID";

            /// <summary>
            /// Property for From Sort Id
            /// </summary>
            public const string FromSortId = "FRSORTID";

            /// <summary>
            /// Property for To Sort Id
            /// </summary>
            public const string ToSortId = "TOSORTID";

            /// <summary>
            /// Property for Segment1
            /// </summary>
            public const string Segment1 = "SEGNM1";

            /// <summary>
            /// Property for Segment From1
            /// </summary>
            public const string SegmentFrom1 = "SEGFR1";

            /// <summary>
            /// Property for Segment To1
            /// </summary>
            public const string SegmentTo1 = "SEGTO1";

            /// <summary>
            /// Property for Segment2
            /// </summary>
            public const string Segment2 = "SEGNM2";

            /// <summary>
            /// Property for Segment From2
            /// </summary>
            public const string SegmentFrom2 = "SEGFR2";

            /// <summary>
            /// Property for Segment To2
            /// </summary>
            public const string SegmentTo2 = "SEGTO2";

            /// <summary>
            /// Property for Segment3
            /// </summary>
            public const string Segment3 = "SEGNM3";

            /// <summary>
            /// Property for Segment From3
            /// </summary>
            public const string SegmentFrom3 = "SEGFR3";

            /// <summary>
            /// Property for Segment To3
            /// </summary>
            public const string SegmentTo3 = "SEGTO3";

            /// <summary>
            /// Property for Segment4
            /// </summary>
            public const string Segment4 = "SEGNM4";

            /// <summary>
            /// Property for Segment From4
            /// </summary>
            public const string SegmentFrom4 = "SEGFR4";

            /// <summary>
            /// Property for Segment To4
            /// </summary>
            public const string SegmentTo4 = "SEGTO4";

            /// <summary>
            /// Property for Segment5
            /// </summary>
            public const string Segment5 = "SEGNM5";

            /// <summary>
            /// Property for Segment From5
            /// </summary>
            public const string SegmentFrom5 = "SEGFR5";

            /// <summary>
            /// Property for Segment To5
            /// </summary>
            public const string SegmentTo5 = "SEGTO5";

            /// <summary>
            /// Property for Segment6
            /// </summary>
            public const string Segment6 = "SEGNM6";

            /// <summary>
            /// Property for Segment From6
            /// </summary>
            public const string SegmentFrom6 = "SEGFR6";

            /// <summary>
            /// Property for Segment To6
            /// </summary>
            public const string SegmentTo6 = "SEGTO6";

            /// <summary>
            /// Property for Segment7
            /// </summary>
            public const string Segment7 = "SEGNM7";

            /// <summary>
            /// Property for Segment From7
            /// </summary>
            public const string SegmentFrom7 = "SEGFR7";

            /// <summary>
            /// Property for Segment To7
            /// </summary>
            public const string SegmentTo7 = "SEGTO7";

            /// <summary>
            /// Property for Segment8
            /// </summary>
            public const string Segment8 = "SEGNM8";

            /// <summary>
            /// Property for Segment From8
            /// </summary>
            public const string SegmentFrom8 = "SEGFR8";

            /// <summary>
            /// Property for Segment To8
            /// </summary>
            public const string SegmentTo8 = "SEGTO8";

            /// <summary>
            /// Property for Segment9
            /// </summary>
            public const string Segment9 = "SEGNM9";

            /// <summary>
            /// Property for Segment From9
            /// </summary>
            public const string SegmentFrom9 = "SEGFR9";

            /// <summary>
            /// Property for Segment To9
            /// </summary>
            public const string SegmentTo9 = "SEGTO9";

            /// <summary>
            /// Property for Segment10
            /// </summary>
            public const string Segment10 = "SEGNM10";

            /// <summary>
            /// Property for Segment From10
            /// </summary>
            public const string SegmentFrom10 = "SEGFR10";

            /// <summary>
            /// Property for Segment To10
            /// </summary>
            public const string SegmentTo10 = "SEGTO10";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for UseGs
            /// </summary>
            public const string UseGs = "USEGS";

            /// <summary>
            /// Property for User
            /// </summary>
            public const string User = "USER";

            /// <summary>
            /// Property for Select OptionalField1
            /// </summary>
            public const string SelectOptionalField1 = "SELOPTFLD1";

            /// <summary>
            /// Property for Select OptionalField2
            /// </summary>
            public const string SelectOptionalField2 = "SELOPTFLD2";

            /// <summary>
            /// Property for Select OptionalField3
            /// </summary>
            public const string SelectOptionalField3 = "SELOPTFLD3";

            /// <summary>
            /// Property for Select OptionalField Type1
            /// </summary>
            public const string SelectOptionalFieldType1 = "SELOPTTYPE1";

            /// <summary>
            /// Property for Select OptionalField Type2
            /// </summary>
            public const string SelectOptionalFieldType2 = "SELOPTTYPE2";

            /// <summary>
            /// Property for Select OptionalField Type3
            /// </summary>
            public const string SelectOptionalFieldType3 = "SELOPTTYPE3";

            /// <summary>
            /// Property for Select Optional Field Decimal1
            /// </summary>
            public const string SelectOptionalFieldDecimal1 = "SELOPTDEC1";

            /// <summary>
            /// Property for Select Optional Field Decimal2
            /// </summary>
            public const string SelectOptionalFieldDecimal2 = "SELOPTDEC2";

            /// <summary>
            /// Property for Select Optional Field Decimal3
            /// </summary>
            public const string SelectOptionalFieldDecimal3 = "SELOPTDEC3";

            /// <summary>
            /// Property for Select Optional Field From Value1
            /// </summary>
            public const string SelectOptionalFieldFromValue1 = "SELOPTFRVAL1";

            /// <summary>
            /// Property for Select Optional Field To Value1
            /// </summary>
            public const string SelectOptionalFieldToValue1 = "SELOPTTOVAL1";

            /// <summary>
            /// Property for Select Optional Field From Value2
            /// </summary>
            public const string SelectOptionalFieldFromValue2 = "SELOPTFRVAL2";

            /// <summary>
            /// Property for Select Optional Field To Value2
            /// </summary>
            public const string SelectOptionalFieldToValue2 = "SELOPTTOVAL2";

            /// <summary>
            /// Property for Select Optional Field From Value3
            /// </summary>
            public const string SelectOptionalFieldFromValue3 = "SELOPTFRVAL3";

            /// <summary>
            /// Property for Select Optional Field To Value3
            /// </summary>
            public const string SelectOptionalFieldToValue3 = "SELOPTTOVAL3";

            /// <summary>
            /// Property for Select Optional Field From Display1
            /// </summary>
            public const string SelectOptionalFieldFromDisplay1 = "SELOPTFRDISP1";

            /// <summary>
            /// Property for Select Optional Field To Display1
            /// </summary>
            public const string SelectOptionalFieldToDisplay1 = "SELOPTTODISP1";

            /// <summary>
            /// Property for Select Optional Field From Display2
            /// </summary>
            public const string SelectOptionalFieldFromDisplay2 = "SELOPTFRDISP2";

            /// <summary>
            /// Property for Select Optional Field To Display2
            /// </summary>
            public const string SelectOptionalFieldToDisplay2 = "SELOPTTODISP2";

            /// <summary>
            /// Property for Select Optional Field From Display3
            /// </summary>
            public const string SelectOptionalFieldFromDisplay3 = "SELOPTFRDISP3";

            /// <summary>
            /// Property for Select Optional Field To Display3
            /// </summary>
            public const string SelectOptionalFieldToDisplay3 = "SELOPTTODISP3";

            /// <summary>
            /// Property for Roll Up Accounts
            /// </summary>
            public const string RollUpAccounts = "ROLLUPACCTS";

            /// <summary>
            /// Property for Roll Up Accounts
            /// </summary>
            public const string FiscalCalPrd2 = "YTDPERD2";

            /// <summary>
            /// Property for From Format Account
            /// </summary>
            public const string FromFormatAccount = "FROMFMTACCT";

            /// <summary>
            /// Property for To Format Account
            /// </summary>
            public const string ToFormatAccount = "TOFMTACCT";

            /// <summary>
            /// Property for Optional Fields
            /// </summary>
            public const string OptionalFields = "OPTIONALFIELDS";

            /// <summary>
            /// The order
            /// </summary>
            public const string Order = "ORDER";

            /// <summary>
            /// The account segment total
            /// </summary>
            public const string AccountSegmentTotal = "ACCTSEGTOT";

            /// <summary>
            /// The select optional field length1
            /// </summary>
            public const string SelectOptionalFieldLength1 = "SELOPTLEN1";

            /// <summary>
            /// The select optional field length2
            /// </summary>
            public const string SelectOptionalFieldLength2 = "SELOPTLEN2";

            /// <summary>
            /// The select optional field length3
            /// </summary>
            public const string SelectOptionalFieldLength3 = "SELOPTLEN3";

            /// <summary>
            /// The show net income total
            /// </summary>
            public const string ShowNetIncomeTotal = "SHOWINCOMETOT";

            /// <summary>
            /// The quantity decimal
            /// </summary>
            public const string QuantityDecimal = "QTYDEC";

            #endregion
        }
    }
}