﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Contains list of Batch Status Report Constants
    /// </summary>
    public partial class BatchStatusReport
    {        
        /// <summary>
        /// Unique name
        /// </summary>
        public const string ViewName = "084c658c-9fee-4c71-b69e-b221dafd3f5a";
        /// <summary>
        /// Class Fields.
        /// </summary>
        public class Fields
        {
            #region Field Names
            /// <summary>
            /// Property for FromBatchNumber
            /// </summary>
            public const string FromBatchNumber = "FRBATCH";

            /// <summary>
            /// Property for ToBatchNumber
            /// </summary>
            public const string ToBatchNumber = "TOBATCH";

            /// <summary>
            /// Property for FromLedger
            /// </summary>
            public const string FromLedger = "FRLDGR";

            /// <summary>
            /// Property for ToLedger
            /// </summary>
            public const string ToLedger = "TOLDGR";

            /// <summary>
            /// Property for FromDate
            /// </summary>
            public const string FromDate = "FRDATE";

            /// <summary>
            /// Property for ToDate
            /// </summary>
            public const string ToDate = "TODATE";

            /// <summary>
            /// Property for Types
            /// </summary>
            public const string Types = "TYPES";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "STATUS";

            /// <summary>
            /// Property for FcurnDec
            /// </summary>
            public const string FcurnDec = "FCURNDEC";

            /// <summary>
            /// Property for NumberOfDecimalsForQty
            /// </summary>
            public const string NumberOfDecimalsForQty = "QTYDEC";

            /// <summary>
            /// Property for QtyHdg
            /// </summary>
            public const string QtyHdg = "QTYHDG";

            /// <summary>
            /// Property for Query
            /// </summary>
            public const string Query = "QUERY";

            /// <summary>
            /// Property for Usegs
            /// </summary>
            public const string Usegs = "USEGS";

            /// <summary>
            /// Property for User
            /// </summary>
            public const string User = "USER";

            /// <summary>
            /// Property for QtySw
            /// </summary>
            public const string QtySw = "QTYSW";

            /// <summary>
            /// Property for IctActive
            /// </summary>
            public const string IctActive = "ICTACTIVE";
            #endregion
        }
    }
}