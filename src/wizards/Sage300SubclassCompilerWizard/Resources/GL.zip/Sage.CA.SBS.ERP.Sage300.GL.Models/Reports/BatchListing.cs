﻿/* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Customization.Validators;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Batch Listing Model
    /// </summary>
    public partial class BatchListing : ReportBase
    {
        /// <summary>
        ///  Gets or sets FromBatchNumber 
        /// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof(BatchListingReportResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromBatchNumber { get; set; }

        /// <summary>
        ///  Gets or sets ToBatchNumber 
        /// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof(BatchListingReportResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToBatchNumber { get; set; }

        /// <summary>
        ///  Gets or sets FromLedger 
        /// </summary>
        [Display(Name = "SourceLedger", ResourceType = typeof(BatchListingReportResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromLedger { get; set; }

        /// <summary>
        /// Gets or sets ToLedger 
        /// </summary>
        [Display(Name = "SourceLedger", ResourceType = typeof(BatchListingReportResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToLedger { get; set; }

        /// <summary>
        /// Gets or sets FromDate 
        /// </summary>
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime FromDate { get; set; }

        /// <summary>
        /// Gets or sets ToDate 
        /// </summary>  
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Gets or sets IncludePrevPrintedBatches
        /// </summary>
        [Display(Name = "PrevPrintedBatches", ResourceType = typeof(BatchListingReportResx))]
        public bool IncludePrevPrintedBatches { get; set; }

        /// <summary>
        /// Gets or sets IsTransOptionalFieldsVisible
        /// </summary>
        public bool IsTransOptionalFieldsVisible { get; set; }

        /// <summary>
        /// Gets or sets IncludeTransOptionalFields
        /// </summary>
        [Display(Name = "IncludeTransactionOptionalFields", ResourceType = typeof(BatchListingReportResx))]
        public bool IncludeTransOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets IncludeRefandDesc
        /// </summary>
        [Display(Name = "RefAndDesc", ResourceType = typeof(BatchListingReportResx))]
        public bool IncludeRefandDesc { get; set; }

        /// <summary>
        /// Gets or sets IncludeComments
        /// </summary>
        [Display(Name = "Comments", ResourceType = typeof(BatchListingReportResx))]
        public bool IncludeComments { get; set; }

        /// <summary>
        /// E-09360
        /// Gets or sets IsTaxInformationVisible
        /// </summary>
        public bool IsTaxInformationVisible { get; set; }

        /// <summary>
        /// E-09360
        /// Gets or sets IncludeTaxInformation
        /// </summary>
        [Display(Name = "TaxInformation", ResourceType = typeof(BatchListingReportResx))]
        public bool IncludeTaxInformation { get; set; }

        /// <summary>
        /// Gets or sets Batch Types
        /// </summary>
        [ValidateListForSelection]
        [Display(Name = "Type", ResourceType = typeof(BatchListingReportResx))]
        public List<MultiSelect> Types { get; set; }

        /// <summary>
        /// Gets or sets Batch Status
        /// </summary>
        [ValidateListForSelection]
        [Display(Name = "Status", ResourceType = typeof(BatchListingReportResx))]
        public List<MultiSelect> Status { get; set; }
        
        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        public TypeOfCurrency Currency { get; set; }

        /// <summary>
        /// Gets or sets Paper
        /// </summary>
        public PaperSize Paper { get; set; }

        /// <summary>
        /// Gets or sets IctMulti
        /// </summary>
        public int IctMulti { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDecimalsForQty
        /// </summary>
        public decimal NumberOfDecimalsForQty { get; set; }

        /// <summary>
        /// Gets or sets UseGLSecurity
        /// </summary>
        public UseGLSecurity UseGLSecurity { get; set; }

        /// <summary>
        /// Gets or sets NextBatchNumber
        /// </summary>
        public decimal LastIssuedBatchNumber { get; set; }

        /// <summary>
        /// Gets or Sets IctInstalled
        /// </summary>
        public int IctInstalled { get; set; }

        /// <summary>
        /// Gets or sets ProvisionalPostingAllowed
        /// </summary>
        public bool ProvisionalPostingAllowed { get; set; }

        /// <summary>
        /// Gets or Sets Quantity History Allowed
        /// </summary>
        public QuantityHistoryAllowed QuantityHistoryAllowed { get; set; }

        /// <summary>
        /// Gets or Sets GSAccount Access Switch
        /// </summary>
        public GSAccountAccessSwitch GSAccountAccessSwitch { get; set; }

        /// <summary>
        /// Gets or Sets FcurnDec 
        /// </summary>
        public decimal FcurnDec { get; set; }

        /// <summary>
        /// Gets or Sets QtyHdg
        /// </summary>
        public string Quantity { get; set; }

        /// <summary>
        /// Gets or Sets UnitHdg
        /// </summary>
        public string Unit { get; set; }

        /// <summary>
        /// Gets or Sets Usegs
        /// </summary>
        public decimal Usegs { get; set; }
               
        /// <summary>
        /// Gets or Sets OptionalFields
        /// </summary>
        public decimal OptionalFields { get; set; }

        /// <summary>
        /// Gets or Sets Printed
        /// </summary>
        public int Printed { get; set; }

        /// <summary>
        /// Gets or Sets InclDetails
        /// </summary>
        public decimal InclDetails { get; set; }

        /// <summary>
        /// Gets or Sets Date Category
        /// </summary>
        [Display(Name = "Date", ResourceType = typeof(GLCommonResx))]
        public DateCategory DateCategory { get; set; } = DateCategory.DocumentDate;
    }
}
