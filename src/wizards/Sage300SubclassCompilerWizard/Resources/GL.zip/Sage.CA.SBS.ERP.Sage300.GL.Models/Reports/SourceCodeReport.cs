// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Partial class for SourceCode
    /// </summary>
    public partial class SourceCodeReport : ReportBase
    {
        /// <summary>
        /// Gets or sets FromSourceLedger
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromSourceCode", ResourceType = typeof(SourceCodesReportResx))]
        public string FromSourceLedger { get; set; }

        /// <summary>
        /// Gets or sets FromSourceType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType", ResourceType = typeof(SourceCodesReportResx))]
        public string FromSourceType { get; set; }

        /// <summary>
        /// Gets or sets ToSourceLedger
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToSourceCode", ResourceType = typeof(SourceCodesReportResx))]
        public string ToSourceLedger { get; set; }

        /// <summary>
        /// Gets or sets ToSourceType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType", ResourceType = typeof(SourceCodesReportResx))]
        public string ToSourceType { get; set; }
    }
}