﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class SortByType.
    /// </summary>
    public class SortByType
    {
        #region Model Property

        /// <summary>
        /// Gets or Sets Sort
        /// </summary>
        /// <value>The sort by.</value>
        public SortBy SortBy { get; set; }

        #endregion
    }
}