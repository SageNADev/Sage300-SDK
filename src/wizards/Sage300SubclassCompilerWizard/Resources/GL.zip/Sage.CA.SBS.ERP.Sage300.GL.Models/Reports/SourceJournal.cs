﻿//Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Partial class for SourceJournal
    /// </summary>
    public partial class SourceJournal : ReportBase
    {

        /// <summary>
        /// SourceJournal Constructor to initialize default Account Segments
        /// </summary>
        public SourceJournal()
        {
            OptionalField = new EnumerableResponse<OptionalFields>();
            AccountSegment = new EnumerableResponse<AccountSegment>();
            SegmentList = new EnumerableResponse<AccountSegment>();
        }

        /// <summary>
        /// Gets or sets Frdtfmt
        /// </summary>
        public string Frdtfmt { get; set; }

        /// <summary>
        /// Gets or sets Todtfmt
        /// </summary>
        public string Todtfmt { get; set; }

        /// <summary>
        /// Gets or sets Range
        /// </summary>
        public string Range { get; set; }

        /// <summary>
        /// Gets or sets Fromacct
        /// </summary>
        public string Fromacct { get; set; }

        /// <summary>
        /// Gets or sets Toacct
        /// </summary>
        public string Toacct { get; set; }

        /// <summary>
        /// Gets or sets SelectedSegment
        /// </summary>
        public string SelectedSegment { get; set; }
        
        /// <summary>
        /// Gets or sets Jrnlid
        /// </summary>
        public string Jrnlid { get; set; }

        /// <summary>
        /// Gets or sets Rptname
        /// </summary>
        public string Rptname { get; set; }

        /// <summary>
        /// Gets or sets Fcurndec
        /// </summary>
        public string Fcurndec { get; set; }

        /// <summary>
        /// Gets or sets Qtydec
        /// </summary>
        public string Qtydec { get; set; }

        /// <summary>
        /// Gets or sets Qtyhdg
        /// </summary>
        public string Qtyhdg { get; set; }

        /// <summary>
        /// Gets or sets Unithdg
        /// </summary>
        public string Unithdg { get; set; }

        /// <summary>
        /// Gets or sets Codelist2
        /// </summary>
        public string Codelist2 { get; set; }

        /// <summary>
        /// Gets or sets SelectAccountGroups
        /// </summary>
        public string SelectAccountGroups { get; set; }

        /// <summary>
        /// Gets or sets FromGroupId
        /// </summary>
        public string FromGroupId { get; set; }
        
        /// <summary>
        /// Gets or sets ToGroupId
        /// </summary>
        public string ToGroupId { get; set; }

        /// <summary>
        /// Gets or sets FromSortId
        /// </summary>
        public string FromSortId { get; set; }
        
        /// <summary>
        /// Gets or sets ToSortId
        /// </summary>
        public string ToSortId { get; set; }

        /// <summary>
        /// Gets or sets Segment1
        /// </summary>
        public string Segment1 { get; set; }

        /// <summary>
        /// Gets or sets Segment2
        /// </summary>
        public string Segment2 { get; set; }

        /// <summary>
        /// Gets or sets Segment3
        /// </summary>
        public string Segment3 { get; set; }

        /// <summary>
        /// Gets or sets Segment4
        /// </summary>
        public string Segment4 { get; set; }

        /// <summary>
        /// Gets or sets Segment5
        /// </summary>
        public string Segment5 { get; set; }

        /// <summary>
        /// Gets or sets Segment6
        /// </summary>
        public string Segment6 { get; set; }

        /// <summary>
        /// Gets or sets Segment7
        /// </summary>
        public string Segment7 { get; set; }

        /// <summary>
        /// Gets or sets Segment8
        /// </summary>
        public string Segment8 { get; set; }

        /// <summary>
        /// Gets or sets Segment9
        /// </summary>
        public string Segment9 { get; set; }

        /// <summary>
        /// Gets or sets Segment10
        /// </summary>
        public string Segment10 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom
        /// </summary>
        public string SegmentFrom { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo
        /// </summary>
        public string SegmentTo { get; set; }

        /// <summary>
        /// Gets or sets Fromyear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Fromyear { get; set; }

        /// <summary>
        /// Gets or sets Fromperd
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Fromperd { get; set; }

        /// <summary>
        /// Gets or sets Toyear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Toyear { get; set; }

        /// <summary>
        /// Gets or sets Toperd
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Toperd { get; set; }

        /// <summary>
        /// Gets or sets Fromref
        /// </summary>
        public string Fromref { get; set; }

        /// <summary>
        /// Gets or sets Toref
        /// </summary>
        public string Toref { get; set; }

        /// <summary>
        /// Gets or sets Fromdate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        public DateTime Fromdate { get; set; }

        /// <summary>
        /// Gets or sets Todate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        public DateTime Todate { get; set; }

        /// <summary>
        /// Gets or sets Fromseq
        /// </summary>
        public string Fromseq { get; set; }

        /// <summary>
        /// Gets or sets Toseq
        /// </summary>
        public string Toseq { get; set; }

        /// <summary>
        /// Gets or sets Frbatch
        /// </summary>
        public string Frbatch { get; set; }

        /// <summary>
        /// Gets or sets Tobatch
        /// </summary>
        public string Tobatch { get; set; }

        /// <summary>
        /// Gets or sets Frscur
        /// </summary>
        public string Frscur { get; set; }

        /// <summary>
        /// Gets or sets Toscur
        /// </summary>
        public string Toscur { get; set; }

        /// <summary>
        /// Gets or sets Codeqry
        /// </summary>
        public string Codeqry { get; set; }

        /// <summary>
        /// Gets or sets Codelist
        /// </summary>
        public string Codelist { get; set; }

        /// <summary>
        /// Gets or sets Orderby
        /// </summary>
        public string Orderby { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets Usegs
        /// </summary>
        public string UseGs { get; set; }

        /// <summary>
        /// Gets or sets IncludeTransOptionalFields
        /// </summary>
        [Display(Name = "IncludeTransactionOptionalFields", ResourceType = typeof(SourceJournalsReportResx))]
        public bool IncludeTransOptionalFields { get; set; }

        /// <summary>
        /// Gets or Sets Optional Fields
        /// </summary>
        /// <value>The optional fields.</value>
        public string OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets Seloptfld1
        /// </summary>
        public string Seloptfld1 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfld2
        /// </summary>
        public string Seloptfld2 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfld3
        /// </summary>
        public string Seloptfld3 { get; set; }

        /// <summary>
        /// Gets or sets Selopttype1
        /// </summary>
        public string Selopttype1 { get; set; }

        /// <summary>
        /// Gets or sets Selopttype2
        /// </summary>
        public string Selopttype2 { get; set; }

        /// <summary>
        /// Gets or sets Selopttype3
        /// </summary>
        public string Selopttype3 { get; set; }

        /// <summary>
        /// Gets or sets Seloptdec1
        /// </summary>
        public string Seloptdec1 { get; set; }

        /// <summary>
        /// Gets or sets Seloptdec2
        /// </summary>
        public string Seloptdec2 { get; set; }

        /// <summary>
        /// Gets or sets Seloptdec3
        /// </summary>
        public string Seloptdec3 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfrval1
        /// </summary>
        public string Seloptfrval1 { get; set; }

        /// <summary>
        /// Gets or sets Selopttoval1
        /// </summary>
        public string Selopttoval1 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfrval2
        /// </summary>
        public string Seloptfrval2 { get; set; }

        /// <summary>
        /// Gets or sets Selopttoval2
        /// </summary>
        public string Selopttoval2 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfrval3
        /// </summary>
        public string Seloptfrval3 { get; set; }

        /// <summary>
        /// Gets or sets Selopttoval3
        /// </summary>
        public string Selopttoval3 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfrdisp1
        /// </summary>
        public string Seloptfrdisp1 { get; set; }

        /// <summary>
        /// Gets or sets Selopttodisp1
        /// </summary>
        public string Selopttodisp1 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfrdisp2
        /// </summary>
        public string Seloptfrdisp2 { get; set; }

        /// <summary>
        /// Gets or sets Selopttodisp2
        /// </summary>
        public string Selopttodisp2 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfrdisp3
        /// </summary>
        public string Seloptfrdisp3 { get; set; }

        /// <summary>
        /// Gets or sets Selopttodisp3
        /// </summary>
        public string Selopttodisp3 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfldlength1
        /// </summary>
        public string Seloptfldlength1 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfldlength2
        /// </summary>
        public string Seloptfldlength2 { get; set; }

        /// <summary>
        /// Gets or sets Seloptfldlength3
        /// </summary>
        public string Seloptfldlength3 { get; set; }

        /// <summary>
        /// Gets or sets FromFormatAccount
        /// </summary>
        public string FromFormatAccount { get; set; }

        /// <summary>
        /// Gets or sets ToFormatAccount
        /// </summary>
        public string ToFormatAccount { get; set; }

        #region UI Properties

        /// <summary>
        /// Gets or sets the options.
        /// </summary>
        /// <value>The options.</value>
        public Options Options { get; set; }

        /// <summary>
        /// Gets or sets IsMultiCurrency
        /// </summary>
        public bool IsMultiCurrency { get; set; }

        #region Account Tab

        /// <summary>
        /// Gets or Sets Account Segment Total
        /// </summary>
        /// <value>The account segment total.</value>
        public string AccountSegmentTotal { get; set; }

        /// <summary>
        /// Gets or sets the type of the sort by.
        /// </summary>
        /// <value>The type of the sort by.</value>
        public SortByType SortByType { get; set; }

        /// <summary>
        /// Gets or sets the segment.
        /// </summary>
        /// <value>The segment.</value>
        public Segment Segment { get; set; }

        /// <summary>
        /// Gets or sets the sort account group.
        /// </summary>
        /// <value>The sort account group.</value>
        public AccountGroup SortAccountGroup { get; set; }

        /// <summary>
        /// Gets or sets the sort code account group.
        /// </summary>
        /// <value>The sort code account group.</value>
        public SortAccountGroup SortCodeAccountGroup { get; set; }

        /// <summary>
        /// Gets or sets the include.
        /// </summary>
        /// <value>The include.</value>
        public Include Include { get; set; }

        /// <summary>
        /// Gets or sets the optional field.
        /// </summary>
        /// <value>The optional field.</value>
        public EnumerableResponse<OptionalFields> OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Account Segments List
        /// </summary>
        /// <value>The account segment.</value>
       // [IgnorePreferences]
        public EnumerableResponse<AccountSegment> AccountSegment { get; set; }

        /// <summary>
        /// Gets or sets the segment list.
        /// </summary>
        /// <value>The segment list.</value>
        public EnumerableResponse<AccountSegment> SegmentList { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [account segment total UI].
        /// </summary>
        /// <value><c>true</c> if [account segment total UI]; otherwise, <c>false</c>.</value>
        public bool AccountSegmentTotalUi { get; set; }

        /// <summary>
        /// Gets or Sets Account Group
        /// </summary>
        /// <value>The account group.</value>
        public string AccountGroup { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From1
        /// </summary>
        /// <value>The segment from1.</value>
        public string SegmentFrom1 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To1
        /// </summary>
        /// <value>The segment to1.</value>
        public string SegmentTo1 { get; set; }
        /// <summary>
        /// Gets or Sets for Segment From2
        /// </summary>
        /// <value>The segment from2.</value>
        public string SegmentFrom2 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To2
        /// </summary>
        /// <value>The segment to2.</value>
        public string SegmentTo2 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From3
        /// </summary>
        /// <value>The segment from3.</value>
        public string SegmentFrom3 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To3
        /// </summary>
        /// <value>The segment to3.</value>
        public string SegmentTo3 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From4
        /// </summary>
        /// <value>The segment from4.</value>
        public string SegmentFrom4 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To4
        /// </summary>
        /// <value>The segment to4.</value>
        public string SegmentTo4 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From5
        /// </summary>
        /// <value>The segment from5.</value>
        public string SegmentFrom5 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To5
        /// </summary>
        /// <value>The segment to5.</value>
        public string SegmentTo5 { get; set; }
        /// <summary>
        /// Gets or Sets for Segment From6
        /// </summary>
        /// <value>The segment from6.</value>
        public string SegmentFrom6 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To6
        /// </summary>
        /// <value>The segment to6.</value>
        public string SegmentTo6 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From7
        /// </summary>
        /// <value>The segment from7.</value>
        public string SegmentFrom7 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To7
        /// </summary>
        /// <value>The segment to7.</value>
        public string SegmentTo7 { get; set; }
        /// <summary>
        /// Gets or Sets for Segment From8
        /// </summary>
        /// <value>The segment from8.</value>
        public string SegmentFrom8 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To8
        /// </summary>
        /// <value>The segment to8.</value>
        public string SegmentTo8 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From9
        /// </summary>
        /// <value>The segment from9.</value>
        public string SegmentFrom9 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To9
        /// </summary>
        /// <value>The segment to9.</value>
        public string SegmentTo9 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From10
        /// </summary>
        /// <value>The segment from10.</value>
        public string SegmentFrom10 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To10
        /// </summary>
        /// <value>The segment to10.</value>
        public string SegmentTo10 { get; set; }

        #endregion

        #endregion

    }
}
