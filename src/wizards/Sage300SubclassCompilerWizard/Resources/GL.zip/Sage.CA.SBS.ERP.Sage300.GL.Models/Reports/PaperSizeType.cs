﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class PaperSizeType.
    /// </summary>
    public class PaperSizeType
    {
        /// <summary>
        /// Gets or Sets Paper Size
        /// </summary>
        /// <value>The size of the paper.</value>
        public PaperSize PaperSize { get; set; }
    }
}