﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    public partial class RecurringEntry : ReportBase
    {
        /// <summary>
        /// Gets or sets FromRecurringEntryCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromRecurringEntryCode", ResourceType = typeof(RecurringEntriesReportResx))]
        public string FromRecurringEntryCode { get; set; }

        /// <summary>
        /// Gets or sets ToRecurringEntryCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToRecurringEntryCode", ResourceType = typeof(RecurringEntriesReportResx))]
        public string ToRecurringEntryCode { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        public TypeOfCurrency Currency { get; set; }

        /// <summary>
        /// Gets or sets IncludeSchedules
        /// </summary>
        [Display(Name = "Schedules", ResourceType = typeof(RecurringEntriesReportResx))]
        public bool IncludeSchedules { get; set; }

        /// <summary>
        /// Gets or sets IsTransOptionalFieldsVisible
        /// </summary>
        public bool IsTransOptionalFieldsVisible { get; set; }

        /// <summary>
        /// Gets or sets IncludeTransOptionalFields
        /// </summary>
        [Display(Name = "TransOptionalFields", ResourceType = typeof(RecurringEntriesReportResx))]
        public bool IncludeTransOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrencyActivatedSwitch
        /// </summary>
        public int MultiCurrencyActivatedSwitch { get; set; }

        /// <summary>
        /// Gets or Sets ShowSch
        /// </summary>
        public int ShowSch { get; set; }

        /// <summary>
        /// Gets or Sets OptionalFields
        /// </summary>
        public int OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDecimalsForQty
        /// </summary>
        public decimal NumberOfDecimalsForQty { get; set; }

        /// <summary>
        /// Gets or Sets Functional Currency 
        /// </summary>
        public decimal FCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets Multi Currency
        /// </summary>
        public string MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets ShowsRecurringEntry
        /// </summary>
        public string ShowsRccur { get; set; }

        /// <summary>
        /// Gets or Sets Usegs
        /// </summary>
        public int Usegs { get; set; }
    }
}