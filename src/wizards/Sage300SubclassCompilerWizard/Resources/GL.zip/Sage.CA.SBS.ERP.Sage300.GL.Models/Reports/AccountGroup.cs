﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class AccountGroup.
    /// </summary>
    public class AccountGroup
    {
        /// <summary>
        /// Gets or Sets Accoun tGroup
        /// </summary>
        /// <value><c>true</c> if [select account groups]; otherwise, <c>false</c>.</value>
        [Display(Name = "SelectAccountGroupsBySortCodeRange", ResourceType = typeof (GLCommonResx))]
        public bool SelectAccountGroups { get; set; }
    }
}