﻿/* Copyright (c) 1994-2023 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class OptionalFields.
    /// </summary>
    public class OptionalFields : ModelBase
    {
        /// <summary>
        /// Gets or Sets Serial Number
        /// </summary>
        /// <value>The serial number.</value>
        public string SerialNumber { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field
        /// </summary>
        /// <value>The select optional field.</value>
        [Display(Name = "AccountOptionalField", ResourceType = typeof(GLCommonResx))]
        public string SelectOptionalField { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field Type
        /// </summary>
        /// <value>The type of the select optional field.</value>
        public string SelectOptionalFieldType { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field Decimal
        /// </summary>
        /// <value>The select optional field decimal.</value>
        public string SelectOptionalFieldDecimal { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field From Value
        /// </summary>
        /// <value>The select optional field from value.</value>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        public string SelectOptionalFieldFromValue { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field To Value
        /// </summary>
        /// <value>The select optional field to value.</value>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        public string SelectOptionalFieldToValue { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field From Display
        /// </summary>
        /// <value>The select optional field from display.</value>
        public string SelectOptionalFieldFromDisplay { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field To Display
        /// </summary>
        /// <value>The select optional field to display.</value>
        public string SelectOptionalFieldToDisplay { get; set; }

        /// <summary>
        /// Gets or Sets Select Optional Field Length
        /// </summary>
        /// <value>The length of the select optional field.</value>
        public string SelectOptionalFieldLength { get; set; }

        /// <summary>
        /// Gets or sets the select optional field desc.
        /// </summary>
        /// <value>The select optional field desc.</value>
        public string SelectOptionalFieldDesc { get; set; }


        /// <summary>
        /// To get Options list from Enum
        /// </summary>
        /// <value>The use in closing.</value>
        [IgnoreDataMember]
        public IEnumerable<CustomSelectList> UseInClosing
        {
            get { return EnumUtility.GetItemsList<UseInClosing>(); }
        }

        /// <summary>
        /// To get decimal regular expression
        /// </summary>
        public string DecimalRegEx { get; set; }
    }
}