// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using System.Dynamic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Partial class for AccountPermissionReport
    /// </summary>
    public partial class AccountPermissionReport : ReportBase
    {
        private const char Z = 'Z';
        private const int UserLength = 8;

        public AccountPermissionReport()
        {
            ToUser = CommonUtil.Repeat(Z, UserLength);
            FromUser = string.Empty;
        }

        /// <summary>
        /// Gets or sets FromUser
        /// </summary>
        [StringLength(UserLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromUserID", ResourceType = typeof (AccountPermissionsResx))]
        public string FromUser { get; set; }

        /// <summary>
        /// Gets or sets ToUser
        /// </summary>
        [StringLength(UserLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToUserID", ResourceType = typeof (AccountPermissionsResx))]
        public string ToUser { get; set; }

        /// <summary>
        /// Gets or sets Default Access
        /// </summary>
        public DefaultAccess DefaultAccess { get; set; }
    }
}
