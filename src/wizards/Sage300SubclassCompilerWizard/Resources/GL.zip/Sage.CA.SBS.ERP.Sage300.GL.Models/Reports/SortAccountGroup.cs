﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class SortAccountGroup.
    /// </summary>
    public class SortAccountGroup
    {
        #region Model Properties

        /// <summary>
        /// Gets or Sets From Group Id
        /// </summary>
        /// <value>From group identifier.</value>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromGroupId { get; set; }

        /// <summary>
        /// Gets or Sets To Group Id
        /// </summary>
        /// <value>To group identifier.</value>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToGroupId { get; set; }

        /// <summary>
        /// Gets or Sets From Sort Id
        /// </summary>
        /// <value>From sort identifier.</value>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromSortId { get; set; }

        /// <summary>
        /// Gets or Sets To Sort Id
        /// </summary>
        /// <value>To sort identifier.</value>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToSortId { get; set; }

        #endregion
    }
}