﻿using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    public partial class TransactionListingReport:ReportBase
    {

        /// <summary>
        /// Gets or Sets Sortby
        /// </summary>
        public SortBy Sortby { get; set; }
              
        /// <summary>
        /// Gets or Sets Segment
        /// </summary>
        public SegmentName Segment{get;set;}

        /// <summary>
        /// Gets or Sets PaperSize
        /// </summary>
        public PaperSize papersize { get; set; }

        /// <summary>
        /// Gets or Sets Account with No Activity
        /// </summary>
        [Display(Name = "AcctNoActivity", ResourceType = typeof(TransactionsListingResx))]
        public bool AcctNoActivity { get; set; }

        /// <summary>
        /// Gets or Sets Quantity
        /// </summary>
        public bool Quantity { get; set; }

        /// <summary>
        /// Gets or Sets Transaction optional field
        /// </summary>
        [Display(Name = "TransOpt", ResourceType = typeof(TransactionsListingResx))]
        public bool TransOpt { get; set; }

        /// <summary>
        /// Gets or Sets Balance
        /// </summary>
        [Display(Name = "BalNetChanges", ResourceType = typeof(TransactionsListingResx))]
        public bool BalNetChanges { get; set; }

        /// <summary>
        /// Gets or Sets posting sequence
        /// </summary>
        [Display(Name = "PSeqBatchEntry", ResourceType = typeof(TransactionsListingResx))]
        public bool PSeqBatchEntry { get; set; }

        /// <summary>
        /// Gets or Sets Sort Transaction
        /// </summary>
        [Display(Name = "SortTrans", ResourceType = typeof(TransactionsListingResx))]
        public bool SortTrans { get; set; }

        /// <summary>
        /// Gets or Sets Sort Account Group
        /// </summary>
        [Display(Name = "SortAcctGrp", ResourceType = typeof(TransactionsListingResx))]
        public bool SortAcctGrp { get; set; }

        /// <summary>
        /// Gets or Sets RollUp
        /// </summary>
        [Display(Name = "RollUp", ResourceType = typeof(TransactionsListingResx))]
        public bool RollUp { get; set; }

        /// <summary>
        /// Gets or Sets PageBreak 
        /// </summary>
        [Display(Name = "AcctSegTotal", ResourceType = typeof(TransactionsListingResx))]
        public bool AcctSegTotal { get; set; }

        /// <summary>
        /// Gets or Sets From Account
        /// </summary>
        public string FromAccount { get; set; }

        /// <summary>
        /// Gets or Sets To Account
        /// </summary>
        public string ToAccount { get; set; }

        /// <summary>
        /// Gets or Sets From Year Period
        /// </summary>
        public string FromYearPeriod { get; set; }

        /// <summary>
        /// Gets or Sets To Year Period
        /// </summary>
        public string ToYearPeriod { get; set; }

        /// <summary>
        /// Gets or Sets Currency
        /// </summary>
        public CurrencyType Currency { get; set; }
        /// <summary>
        /// Gets or Sets From Sort Code
        /// </summary>
        public string FromSortCode { get; set; }

        /// <summary>
        /// Gets or Sets To Sort Code
        /// </summary>
        public string ToSortCode { get; set; }

        /// <summary>
        /// Gets or Sets From Account Group
        /// </summary>
        public string FromAcctGrp { get; set; }

        /// <summary>
        /// Gets or Sets To Account Group
        /// </summary>
        public string ToAcctGrp { get; set; }

        //TODO:Identify the required properties
        public string RANGE { get; set; }

        public string FRGRPID { get; set; }

        public string TOGRPID { get; set; }

        public string ACTGRPSB { get; set; }

        public string INACTIVE { get; set; }

        public string FRPERD { get; set; }

        public string TOPERD { get; set; }

        public string QTYDEC { get; set; }

        public string USEGS { get; set; }

        public string USER { get; set; }

        public string SELOPTFLD1 { get; set; }

        public string SELOPTFLD2 { get; set; }

        public string SELOPTFLD3 { get; set; }

        public string SELOPTTYPE1 { get; set; }

        public string SELOPTTYPE2 { get; set; }

        public string SELOPTTYPE3 { get; set; }

        public string SELOPTDEC1 { get; set; }

        public string SELOPTDEC2 { get; set; }

        public string SELOPTDEC3 { get; set; }

        public string SELOPTLEN1 { get; set; }

        public string SELOPTLEN2 { get; set; }

        public string SELOPTLEN3 { get; set; }

        public string SELOPTFRVAL1 { get; set; }

        public string SELOPTFRVAL2 { get; set; }

        public string SELOPTFRVAL3 { get; set; }

        public string SELOPTTOVAL1 { get; set; }

        public string SELOPTTOVAL2 { get; set; }

        public string SELOPTTOVAL3 { get; set; }

        public string SELOPTFRDISP1 { get; set; }

        public string SELOPTFRDISP2 { get; set; }

        public string SELOPTFRDISP3 { get; set; }

        public string SELOPTTODISP1 { get; set; }

        public string SELOPTTODISP2 { get; set; }

        public string SELOPTTODISP3 { get; set; }

        public string FROMFMTACCT { get; set; }

        public string TOFMTACCT { get; set; }

    }
}
