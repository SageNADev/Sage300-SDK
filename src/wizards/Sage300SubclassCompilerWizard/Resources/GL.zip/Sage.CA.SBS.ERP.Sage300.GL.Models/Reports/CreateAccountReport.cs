// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Partial class for CreateAccountReport
    /// </summary>
    public partial class CreateAccountReport : ReportBase
    {
        #region Constructor

        /// <summary>
        /// Default constructor for CreateAccountReport
        /// </summary>
        public CreateAccountReport()
        {
            SortCodeAccountGroup = new SortAccountGroup();
            Segment = new Segment();
            SortByType = new SortByType { SortBy = SortBy.AccountNo };
            AccountSegments = new EnumerableResponse<AccountSegment>();
            SegmentList = new EnumerableResponse<AccountSegment>();
        }

        #endregion

        #region Model Properties

        /// <summary>
        /// Gets or sets Range
        /// </summary>
        public string Range { get; set; }

        /// <summary>
        /// Gets or sets FromAccount
        /// </summary>
        public string FromAccount { get; set; }

        /// <summary>
        /// Gets or sets ToAccount
        /// </summary>
        public string ToAccount { get; set; }

        /// <summary>
        /// Gets or Sets Sort By
        /// </summary>
        /// <value>The sort by.</value>
        public SortByType SortByType { get; set; }

        /// <summary>
        /// Gets or sets FromGroupId
        /// </summary>
        public string FromGroupId { get; set; }

        /// <summary>
        /// Gets or sets ToGroupId
        /// </summary>
        public string ToGroupId { get; set; }

        /// <summary>
        /// Gets or sets FromSortId
        /// </summary>
        public string FromSortId { get; set; }

        /// <summary>
        /// Gets or sets ToSortId
        /// </summary>
        public string ToSortId { get; set; }

        /// <summary>
        /// Gets or sets SegmentName1
        /// </summary>
        public string SegmentName1 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom1
        /// </summary>
        public string SegmentFrom1 { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo1
        /// </summary>
        public string SegmentTo1 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName2
        /// </summary>
        public string SegmentName2 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom2
        /// </summary>
        public string SegmentFrom2 { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo2
        /// </summary>
        public string SegmentTo2 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName3
        /// </summary>
        public string SegmentName3 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom3
        /// </summary>
        public string SegmentFrom3 { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo3
        /// </summary>
        public string SegmentTo3 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName4
        /// </summary>
        public string SegmentName4 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom4
        /// </summary>
        public string SegmentFrom4 { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo4
        /// </summary>
        public string SegmentTo4 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName5
        /// </summary>
        public string SegmentName5 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom5
        /// </summary>
        public string SegmentFrom5 { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo5
        /// </summary>
        public string SegmentTo5 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName6
        /// </summary>
        public string SegmentName6 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom6
        /// </summary>
        public string SegmentFrom6 { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo6
        /// </summary>
        public string SegmentTo6 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName7
        /// </summary>
        public string SegmentName7 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom7
        /// </summary>
        public string SegmentFrom7 { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo7
        /// </summary>
        public string SegmentTo7 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName8
        /// </summary>
        public string SegmentName8 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom8
        /// </summary>
        public string SegmentFrom8 { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo8
        /// </summary>
        public string SegmentTo8 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName9
        /// </summary>
        public string SegmentName9 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom9
        /// </summary>
        public string SegmentFrom9 { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo9
        /// </summary>
        public string SegmentTo9 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName10
        /// </summary>
        public string SegmentName10 { get; set; }

        /// <summary>
        /// Gets or sets SegmentFrom10
        /// </summary>
        public string SegmentFrom10 { get; set; }

        /// <summary>
        /// Gets or sets SegmentTo10
        /// </summary>
        public string SegmentTo10 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode
        /// </summary>
        public string SegmentCode { get; set; }

        /// <summary>
        /// Gets or sets IncludeAvc
        /// </summary>
        public string IncludeAvc { get; set; }

        /// <summary>
        /// Gets or sets FromAccountStructureCode
        /// </summary>
        public string FromAccountStructureCode { get; set; }

        /// <summary>
        /// Gets or sets CreateUsingStructureCode
        /// </summary>
        public string CreateUsingStructureCode { get; set; }

        /// <summary>
        /// Gets or sets PSelectBy
        /// </summary>
        public int PSelectBy { get; set; }

        /// <summary>
        /// Gets or sets PAccountFrom
        /// </summary>
        public string PAccountFrom { get; set; }

        /// <summary>
        /// Gets or sets PAccountTo
        /// </summary>
        public string PAccountTo { get; set; }

        /// <summary>
        /// Gets or sets PAccountGroupFrom
        /// </summary>
        public string PAccountGroupFrom { get; set; }

        /// <summary>
        /// Gets or sets PAccountGroupTo
        /// </summary>
        public string PAccountGroupTo { get; set; }

        /// <summary>
        /// Gets or sets PSortAccountGroupFrom
        /// </summary>
        public string PSortAccountGroupFrom { get; set; }

        /// <summary>
        /// Gets or sets PSortAccountGroupTo
        /// </summary>
        public string PSortAccountGroupTo { get; set; }

        /// <summary>
        /// Gets or sets PSegName
        /// </summary>
        public string PSegName { get; set; }

        /// <summary>
        /// Gets or sets PSegId
        /// </summary>
        public string PSegId { get; set; }

        /// <summary>
        /// Gets or sets PdfCas
        /// </summary>
        public bool PdfCas { get; set; }

        /// <summary>
        /// Gets or sets PdfAvc
        /// </summary>
        public bool PdfAvc { get; set; }

        /// <summary>
        /// Gets or sets PdfExist
        /// </summary>
        public bool PdfExist { get; set; }

        /// <summary>
        /// Gets or sets PSeg1
        /// </summary>
        public string PSeg1 { get; set; }

        /// <summary>
        /// Gets or sets Pseg2
        /// </summary>
        public string PSeg2 { get; set; }

        /// <summary>
        /// Gets or sets Pseg3
        /// </summary>
        public string PSeg3 { get; set; }

        /// <summary>
        /// Gets or sets Pseg4
        /// </summary>
        public string PSeg4 { get; set; }

        /// <summary>
        /// Gets or sets Pseg5
        /// </summary>
        public string PSeg5 { get; set; }

        /// <summary>
        /// Gets or sets Pseg6
        /// </summary>
        public string PSeg6 { get; set; }

        /// <summary>
        /// Gets or sets Pseg7
        /// </summary>
        public string PSeg7 { get; set; }

        /// <summary>
        /// Gets or sets Pseg8
        /// </summary>
        public string PSeg8 { get; set; }

        /// <summary>
        /// Gets or sets Pseg9
        /// </summary>
        public string PSeg9 { get; set; }

        /// <summary>
        /// Gets or sets Pnew1
        /// </summary>
        public string PNew1 { get; set; }

        /// <summary>
        /// Gets or sets Pnew2
        /// </summary>
        public string PNew2 { get; set; }

        /// <summary>
        /// Gets or sets Pnew3
        /// </summary>
        public string PNew3 { get; set; }

        /// <summary>
        /// Gets or sets Pnew4
        /// </summary>
        public string PNew4 { get; set; }

        /// <summary>
        /// Gets or sets Pnew5
        /// </summary>
        public string PNew5 { get; set; }

        /// <summary>
        /// Gets or sets Pnew6
        /// </summary>
        public string PNew6 { get; set; }

        /// <summary>
        /// Gets or sets Pnew7
        /// </summary>
        public string PNew7 { get; set; }

        /// <summary>
        /// Gets or sets Pnew8
        /// </summary>
        public string PNew8 { get; set; }

        /// <summary>
        /// Gets or sets Pnew9
        /// </summary>
        public string PNew9 { get; set; }

        /// <summary>
        /// Gets or sets Psegfr1
        /// </summary>
        public string PSegFrom1 { get; set; }

        /// <summary>
        /// Gets or sets Psegfr2
        /// </summary>
        public string PSegFrom2 { get; set; }

        /// <summary>
        /// Gets or sets Psegfr3
        /// </summary>
        public string PSegFrom3 { get; set; }

        /// <summary>
        /// Gets or sets Psegfr4
        /// </summary>
        public string PSegFrom4 { get; set; }

        /// <summary>
        /// Gets or sets Psegfr5
        /// </summary>
        public string PSegFrom5 { get; set; }

        /// <summary>
        /// Gets or sets Psegfr6
        /// </summary>
        public string PSegFrom6 { get; set; }

        /// <summary>
        /// Gets or sets Psegfr7
        /// </summary>
        public string PSegFrom7 { get; set; }

        /// <summary>
        /// Gets or sets Psegfr8
        /// </summary>
        public string PSegFrom8 { get; set; }

        /// <summary>
        /// Gets or sets Psegfr9
        /// </summary>
        public string PSegFrom9 { get; set; }

        /// <summary>
        /// Gets or sets Psegto1
        /// </summary>
        public string PSegTo1 { get; set; }

        /// <summary>
        /// Gets or sets Psegto2
        /// </summary>
        public string PSegTo2 { get; set; }

        /// <summary>
        /// Gets or sets Psegto3
        /// </summary>
        public string PSegTo3 { get; set; }

        /// <summary>
        /// Gets or sets Psegto4
        /// </summary>
        public string PSegTo4 { get; set; }

        /// <summary>
        /// Gets or sets Psegto5
        /// </summary>
        public string PSegTo5 { get; set; }

        /// <summary>
        /// Gets or sets Psegto6
        /// </summary>
        public string PSegTo6 { get; set; }

        /// <summary>
        /// Gets or sets Psegto7
        /// </summary>
        public string PSegTo7 { get; set; }

        /// <summary>
        /// Gets or sets Psegto8
        /// </summary>
        public string PSegTo8 { get; set; }

        /// <summary>
        /// Gets or sets Psegto9
        /// </summary>
        public string PSegTo9 { get; set; }

        /// <summary>
        /// Gets or sets Psegdf1
        /// </summary>
        public string PSegdf1 { get; set; }

        /// <summary>
        /// Gets or sets Psegdf2
        /// </summary>
        public string PSegdf2 { get; set; }

        /// <summary>
        /// Gets or sets Psegdf3
        /// </summary>
        public string PSegdf3 { get; set; }

        /// <summary>
        /// Gets or sets Psegdf4
        /// </summary>
        public string PSegdf4 { get; set; }

        /// <summary>
        /// Gets or sets Psegdf5
        /// </summary>
        public string PSegdf5 { get; set; }

        /// <summary>
        /// Gets or sets Psegdf6
        /// </summary>
        public string PSegdf6 { get; set; }

        /// <summary>
        /// Gets or sets Psegdf7
        /// </summary>
        public string PSegdf7 { get; set; }

        /// <summary>
        /// Gets or sets Psegdf8
        /// </summary>
        public string PSegdf8 { get; set; }

        /// <summary>
        /// Gets or sets Psegdf9
        /// </summary>
        public string PSegdf9 { get; set; }

        /// <summary>
        /// Gets or sets PSegRow
        /// </summary>
        public string PSegRow { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        public bool OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets FromFmtAccount
        /// </summary>
        public string FromFmtAccount { get; set; }

        /// <summary>
        /// Gets or sets ToFmtAccount
        /// </summary>
        public string ToFmtAccount { get; set; }

        /// <summary>
        /// Gets or sets PFmtAccountFrom
        /// </summary>
        public string PFmtAccountFrom { get; set; }

        /// <summary>
        /// Gets or sets PFmtAccountTo
        /// </summary>
        public string PFmtAccountTo { get; set; }

        /// <summary>
        /// Gets or sets CreateAccountFromNumber
        /// </summary>
        public string CreateAccountFromNumber { get; set; }

        /// <summary>
        /// Gets or sets CreateAccountToNumber
        /// </summary>
        public string CreateAccountToNumber { get; set; }

        /// <summary>
        /// Gets or sets the segment.
        /// </summary>
        /// <value>The segment.</value>
        public Segment Segment { get; set; }

        /// <summary>
        /// Gets or Sets SelectAccountGroups
        /// </summary>
        [Display(Name = "SelectAccountGroupsBySortCodeRange", ResourceType = typeof(GLCommonResx))]
        public bool SelectAccountGroups { get; set; }

        /// <summary>
        /// Gets or sets the sort code account group.
        /// </summary>
        public SortAccountGroup SortCodeAccountGroup { get; set; }

        /// <summary>
        /// Gets or sets the Subledger.
        /// </summary>
        [Display(Name = "Subledger", ResourceType = typeof(GLCommonResx))]
        public bool Subledger { get; set; }

        /// <summary>
        /// Gets or sets the Currency.
        /// </summary>
        [Display(Name = "Currency", ResourceType = typeof(GLCommonResx))]
        public bool Currency { get; set; }

        /// <summary>
        /// Gets or sets the AccountGroupSwitch.
        /// </summary>
        public bool AccountGroupSwitch { get; set; }

        /// <summary>
        /// Gets or sets the IsMultiCurrency.
        /// </summary>
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets the IsQuantityHistoryAllowed.
        /// </summary>
        public bool IsQuantityHistoryAllowed { get; set; }

        /// <summary>
        /// Gets or sets the HasObLicense.
        /// </summary>
        public bool HasObLicense { get; set; }

        /// <summary>
        /// Gets or sets the SelectedSegmentIndex.
        /// </summary>
        public int SelectedSegmentIndex { get; set; }

        /// <summary>
        /// Gets or sets AccountSegments
        /// </summary>
        public EnumerableResponse<AccountSegment> AccountSegments { get; set; }

        /// <summary>
        /// Gets or sets SegmentList
        /// </summary>
        public EnumerableResponse<AccountSegment> SegmentList { get; set; }

        #endregion
    }
}
