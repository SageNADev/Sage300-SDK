﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class TransactionOptionalField.
    /// </summary>
    public class TransactionOptionalField : ModelBase
    {
        /// <summary>
        /// Gets or Sets Serial Number
        /// </summary>
        /// <value>The serial number.</value>
        public string SerialNumber { get; set; }

        /// <summary>
        /// Gets or Sets Selected Optionalfield
        /// </summary> 
        /// <value>The selected optional field.</value>
        [Display(Name = "TransOptionalField", ResourceType = typeof(TransactionDetailsOptionalFieldsReportResx))]
        public string SelectedOptionalField { get; set; }

        /// <summary>
        /// Gets or Sets Seletced OptionalFieldType
        /// </summary>
        /// <value>The type of the selected optional field.</value>
        public string SelectedOptionalFieldType { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldDescimal
        /// </summary>
        /// <value>The selected optional field descimal.</value>
        public string SelectedOptionalFieldDescimal { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldFromValue
        /// </summary>
        /// <value>The selected optional field from value.</value>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        public string SelectedOptionalFieldFromValue { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldToValue
        /// </summary>
        /// <value>The selected optional field to value.</value>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        public string SelectedOptionalFieldToValue { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldFromDisplay
        /// </summary>
        /// <value>The selected optional field from display.</value>
        public string SelectedOptionalFieldFromDisplay { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldToDisplay
        /// </summary>
        /// <value>The selected optional field to display.</value>
        public string SelectedOptionalFieldToDisplay { get; set; }

        /// <summary>
        /// Gets or Sets Selected OptionalFieldLength
        /// </summary>
        /// <value>The length of the selected optional field.</value>
        public string SelectedOptionalFieldLength { get; set; }

        /// <summary>
        /// To get Options list from Enum
        /// </summary>
        /// <value>The use in closing.</value>
        public IEnumerable<CustomSelectList> UseInClosing
        {
            get { return EnumUtility.GetItemsList<UseInClosing>(); }
        }

        /// <summary>
        /// To get decimal regular expression
        /// </summary>
        public string DecimalRegEx { get; set; }
    }
}