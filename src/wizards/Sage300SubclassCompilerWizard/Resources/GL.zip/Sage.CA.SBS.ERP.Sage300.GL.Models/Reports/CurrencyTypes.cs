﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class CurrencyTypes.
    /// </summary>
    public class CurrencyTypes
    {
        /// <summary>
        /// Gets or Sets Currency
        /// </summary>
        /// <value>The currency.</value>
        [Display(Name = "Currency", ResourceType = typeof (GLCommonResx))]
        public string Currency { get; set; }
    }
}