﻿/* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Transaction Listing Model
    /// </summary>
    public partial class TransactionListing : ReportBase
    {
        /// <summary>
        /// GLTransactionListing Constructor to initialize default Account Segments
        /// </summary>
        public TransactionListing()
        {
                OptionalField = new EnumerableResponse<OptionalFields>();
                AccountSegment = new EnumerableResponse<AccountSegment>();
                SegmentList = new EnumerableResponse<AccountSegment>();
        }

        /// <summary>
        /// Gets or Sets Include Quantity
        /// </summary>
        /// <value>The include quantity.</value>
        public string IncludeQuantity { get; set; }

        /// <summary>
        /// Gets or Sets Range
        /// </summary>
        /// <value>The range.</value>
        public string Range { get; set; }

        /// <summary>
        /// Gets or Sets Sort By
        /// </summary>
        /// <value>The sort by.</value>
        public string SortBy { get; set; }

        /// <summary>
        /// Gets or Sets From Fiscal Calendar Year
        /// </summary>
        /// <value>From fiscal cal yr.</value>
        [Display(Name = "From", ResourceType = typeof (CommonResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string FromFiscalCalYr { get; set; }

        /// <summary>
        /// Gets or Sets From Fiscal Calendar Period
        /// </summary>
        /// <value>From fiscal cal PRD.</value>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "From", ResourceType = typeof (CommonResx))]
        public string FromFiscalCalPrd { get; set; }

        /// <summary>
        /// Gets or Sets To Fiscal Calendar Period
        /// </summary>
        /// <value>To fiscal cal PRD.</value>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "To", ResourceType = typeof (CommonResx))]
        public string ToFiscalCalPrd { get; set; }

        /// <summary>
        /// Gets or Sets Inactive
        /// </summary>
        /// <value>The inactive.</value>
        [Display(Name = "AcctNoActivity", ResourceType = typeof (TransactionsListingResx))]
        public string Inactive { get; set; }

        /// <summary>
        /// Gets or Sets OrderBy
        /// </summary>
        /// <value>The order by.</value>
        public string OrderBy { get; set; }

        /// <summary>
        /// Gets or Sets Order
        /// </summary>
        /// <value>The order.</value>
        public string Order { get; set; }

        /// <summary>
        /// Gets or Sets Quantity Deimal
        /// </summary>
        /// <value>The quantity deimal.</value>
        public string QuantityDeimal { get; set; }

        /// <summary>
        /// Gets or Sets Account Group
        /// </summary>
        /// <value>The account group.</value>
        public string AccountGroup { get; set; }

        /// <summary>
        /// Gets or Sets Account Segment Total
        /// </summary>
        /// <value>The account segment total.</value>
        public string AccountSegmentTotal { get; set; }

        /// <summary>
        /// Gets or Sets UseGs
        /// </summary>
        /// <value>The use gs.</value>
        public string UseGs { get; set; }

        /// <summary>
        /// Gets or Sets Optional Fields
        /// </summary>
        /// <value>The optional fields.</value>
        public string OptionalFields { get; set; }

        /// <summary>
        /// Gets or Sets Roll Up Accounts
        /// </summary>
        /// <value>The roll up accounts.</value>
        public string RollUpAccounts { get; set; }

        /// <summary>
        /// Gets or Sets Include Change
        /// </summary>
        /// <value>The include change.</value>
        public string IncludeChange { get; set; }

        /// <summary>
        /// Gets or Sets Sort Transaction
        /// </summary>
        /// <value>The sort transaction.</value>
        public string SortTransaction { get; set; }

        /// <summary>
        /// Gets or Sets To Fiscal Calendar Year
        /// </summary>
        /// <value>To fiscal cal yr.</value>
        [Display(Name = "To", ResourceType = typeof (CommonResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ToFiscalCalYr { get; set; }

        /// <summary>
        /// Gets or Sets for Segment Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment1 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From1
        /// </summary>
        /// <value>The segment from1.</value>
        public string SegmentFrom1 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To1
        /// </summary>
        /// <value>The segment to1.</value>
        public string SegmentTo1 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment Segment2
        /// </summary>
        /// <value>The segment2.</value>
        public string Segment2 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From2
        /// </summary>
        /// <value>The segment from2.</value>
        public string SegmentFrom2 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To2
        /// </summary>
        /// <value>The segment to2.</value>
        public string SegmentTo2 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment Segment3
        /// </summary>
        /// <value>The segment3.</value>
        public string Segment3 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From3
        /// </summary>
        /// <value>The segment from3.</value>
        public string SegmentFrom3 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To3
        /// </summary>
        /// <value>The segment to3.</value>
        public string SegmentTo3 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment Segment4
        /// </summary>
        /// <value>The segment4.</value>
        public string Segment4 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From4
        /// </summary>
        /// <value>The segment from4.</value>
        public string SegmentFrom4 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To4
        /// </summary>
        /// <value>The segment to4.</value>
        public string SegmentTo4 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment Segment5
        /// </summary>
        /// <value>The segment5.</value>
        public string Segment5 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From5
        /// </summary>
        /// <value>The segment from5.</value>
        public string SegmentFrom5 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To5
        /// </summary>
        /// <value>The segment to5.</value>
        public string SegmentTo5 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment Segment6
        /// </summary>
        /// <value>The segment6.</value>
        public string Segment6 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From6
        /// </summary>
        /// <value>The segment from6.</value>
        public string SegmentFrom6 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To6
        /// </summary>
        /// <value>The segment to6.</value>
        public string SegmentTo6 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment Segment7
        /// </summary>
        /// <value>The segment7.</value>
        public string Segment7 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From7
        /// </summary>
        /// <value>The segment from7.</value>
        public string SegmentFrom7 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To7
        /// </summary>
        /// <value>The segment to7.</value>
        public string SegmentTo7 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment Segment8
        /// </summary>
        /// <value>The segment8.</value>
        public string Segment8 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From8
        /// </summary>
        /// <value>The segment from8.</value>
        public string SegmentFrom8 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To8
        /// </summary>
        /// <value>The segment to8.</value>
        public string SegmentTo8 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment Segment9
        /// </summary>
        /// <value>The segment9.</value>
        public string Segment9 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From9
        /// </summary>
        /// <value>The segment from9.</value>
        public string SegmentFrom9 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To9
        /// </summary>
        /// <value>The segment to9.</value>
        public string SegmentTo9 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment Segment10
        /// </summary>
        /// <value>The segment10.</value>
        public string Segment10 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment From10
        /// </summary>
        /// <value>The segment from10.</value>
        public string SegmentFrom10 { get; set; }

        /// <summary>
        /// Gets or Sets for Segment To10
        /// </summary>
        /// <value>The segment to10.</value>
        public string SegmentTo10 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field1
        /// </summary>
        /// <value>The select optional field1.</value>
        public string SelectOptionalField1 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field2
        /// </summary>
        /// <value>The select optional field2.</value>
        public string SelectOptionalField2 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field3
        /// </summary>
        /// <value>The select optional field3.</value>
        public string SelectOptionalField3 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field Type1
        /// </summary>
        /// <value>The select optional field type1.</value>
        public string SelectOptionalFieldType1 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field Type2
        /// </summary>
        /// <value>The select optional field type2.</value>
        public string SelectOptionalFieldType2 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field Type3
        /// </summary>
        /// <value>The select optional field type3.</value>
        public string SelectOptionalFieldType3 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field Decimal1
        /// </summary>
        /// <value>The select optional field decimal1.</value>
        public string SelectOptionalFieldDecimal1 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field Decimal2
        /// </summary>
        /// <value>The select optional field decimal2.</value>
        public string SelectOptionalFieldDecimal2 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field Decimal3
        /// </summary>
        /// <value>The select optional field decimal3.</value>
        public string SelectOptionalFieldDecimal3 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field From Value1
        /// </summary>
        /// <value>The select optional field from value1.</value>
        public string SelectOptionalFieldFromValue1 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field To Value1
        /// </summary>
        /// <value>The select optional field to value1.</value>
        public string SelectOptionalFieldToValue1 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field From Value2
        /// </summary>
        /// <value>The select optional field from value2.</value>
        public string SelectOptionalFieldFromValue2 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field To Value2
        /// </summary>
        /// <value>The select optional field to value2.</value>
        public string SelectOptionalFieldToValue2 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field From Value3
        /// </summary>
        /// <value>The select optional field from value3.</value>
        public string SelectOptionalFieldFromValue3 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field To Value3
        /// </summary>
        /// <value>The select optional field to value3.</value>
        public string SelectOptionalFieldToValue3 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field From Display1
        /// </summary>
        /// <value>The select optional field from display1.</value>
        public string SelectOptionalFieldFromDisplay1 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field To Display1
        /// </summary>
        /// <value>The select optional field to display1.</value>
        public string SelectOptionalFieldToDisplay1 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field From Display2
        /// </summary>
        /// <value>The select optional field from display2.</value>
        public string SelectOptionalFieldFromDisplay2 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field To Display2
        /// </summary>
        /// <value>The select optional field to display2.</value>
        public string SelectOptionalFieldToDisplay2 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field From Display3
        /// </summary>
        /// <value>The select optional field from display3.</value>
        public string SelectOptionalFieldFromDisplay3 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field To Display3
        /// </summary>
        /// <value>The select optional field to display3.</value>
        public string SelectOptionalFieldToDisplay3 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field Length1
        /// </summary>
        /// <value>The select optional field length1.</value>
        public string SelectOptionalFieldLength1 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field Length2
        /// </summary>
        /// <value>The select optional field length2.</value>
        public string SelectOptionalFieldLength2 { get; set; }

        /// <summary>
        /// Gets or Sets for Select Optional Field Length3
        /// </summary>
        /// <value>The select optional field length3.</value>
        public string SelectOptionalFieldLength3 { get; set; }

        /// <summary>
        /// Gets or Sets From Account
        /// </summary>
        /// <value>From account.</value>
        public string FromAccount { get; set; }

        /// <summary>
        /// Gets or Sets To Account
        /// </summary>
        /// <value>To account.</value>
        public string ToAccount { get; set; }

        /// <summary>
        /// Gets or Sets From Format Account
        /// </summary>
        /// <value>From format account.</value>
        public string FromFormatAccount { get; set; }

        /// <summary>
        /// Gets or Sets To Format Account
        /// </summary>
        /// <value>To format account.</value>
        public string ToFormatAccount { get; set; }

        #region UI Properties

        /// <summary>
        /// Gets or sets a value indicating whether [sort transaction UI].
        /// </summary>
        /// <value><c>true</c> if [sort transaction UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "SortTransByDate", ResourceType = typeof (GLCommonResx))]
        public bool SortTransactionUi { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [roll up accounts UI].
        /// </summary>
        /// <value><c>true</c> if [roll up accounts UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "UseRolledUpAmounts", ResourceType = typeof (GLCommonResx))]
        public bool RollUpAccountsUi { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [account segment total UI].
        /// </summary>
        /// <value><c>true</c> if [account segment total UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "AcctSegTotal", ResourceType = typeof (TransactionsListingResx))]
        public bool AccountSegmentTotalUi { get; set; }

        /// <summary>
        /// Gets or sets the options.
        /// </summary>
        /// <value>The options.</value>
        public Options Options { get; set; }

        /// <summary>
        /// Gets or sets the name of the report.
        /// </summary>
        /// <value>The name of the report.</value>
        public string ReportName { get; set; }

        /// <summary>
        /// Gets or sets Account Segments List
        /// </summary>
        /// <value>The account segment.</value>
        [IgnorePreferences]
        public EnumerableResponse<AccountSegment> AccountSegment { get; set; }

        /// <summary>
        /// Gets or sets the segment list.
        /// </summary>
        /// <value>The segment list.</value>
        public EnumerableResponse<AccountSegment> SegmentList { get; set; }

        /// <summary>
        /// Gets or sets the type of the sort by.
        /// </summary>
        /// <value>The type of the sort by.</value>
        public SortByType SortByType { get; set; }

        /// <summary>
        /// Gets or sets the segment.
        /// </summary>
        /// <value>The segment.</value>
        public Segment Segment { get; set; }

        /// <summary>
        /// Gets or sets the sort account group.
        /// </summary>
        /// <value>The sort account group.</value>
        public AccountGroup SortAccountGroup { get; set; }

        /// <summary>
        /// Gets or sets the currency types.
        /// </summary>
        /// <value>The currency types.</value>
        public CurrencyTypes CurrencyTypes { get; set; }

        /// <summary>
        /// Gets or sets the DateTypes types.
        /// </summary>
        /// <value>The currency types.</value>
        public DateTypes DateTypes { get; set; }

        /// <summary>
        /// Gets or sets the sort code account group.
        /// </summary>
        /// <value>The sort code account group.</value>
        public SortAccountGroup SortCodeAccountGroup { get; set; }

        /// <summary>
        /// Gets or sets the type of the paper size.
        /// </summary>
        /// <value>The type of the paper size.</value>
        public PaperSizeType PaperSizeType { get; set; }

        /// <summary>
        /// Gets or sets the include.
        /// </summary>
        /// <value>The include.</value>
        public Include Include { get; set; }

        /// <summary>
        /// Gets or sets the optional field.
        /// </summary>
        /// <value>The optional field.</value>
        public EnumerableResponse<OptionalFields> OptionalField { get; set; }

        /// <summary>
        /// Gets or sets IsTransOptionalFieldsVisible
        /// </summary>
        /// <value><c>true</c> if this instance is trans optional fields visible; otherwise, <c>false</c>.</value>
        public bool IsTransOptionalFieldsVisible { get; set; }
        #endregion

        /// <summary>
        /// E-09360
        /// Gets or Sets IncludeTaxInformation
        /// </summary>
        public bool IncludeTaxInformation { get; set; }

        /// <summary>
        /// E-09360
        /// Gets or Sets IsTaxInformationVisible
        /// </summary>
        public bool IsTaxInformationVisible { get; set; }
    }
}