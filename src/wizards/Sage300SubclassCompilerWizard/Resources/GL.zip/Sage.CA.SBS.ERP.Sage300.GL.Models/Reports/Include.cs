﻿/* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Class Include.
    /// </summary>
    public class Include
    {
        /// <summary>
        /// Gets or Sets Inactive
        /// </summary>
        /// <value><c>true</c> if [inactive UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "AcctNoActivity", ResourceType = typeof (TransactionsListingResx))]
        public bool InactiveUi { get; set; }

        /// <summary>
        /// Gets or Sets Include Quantity
        /// </summary>
        /// <value><c>true</c> if [include quantity UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "Quantity", ResourceType = typeof (CommonResx))]
        public bool IncludeQuantityUi { get; set; }

        /// <summary>
        /// Gets or Sets Optional Fields
        /// </summary>
        /// <value><c>true</c> if [optional fields UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "TransOpt", ResourceType = typeof (TransactionsListingResx))]
        public bool OptionalFieldsUi { get; set; }

        /// <summary>
        /// Gets or Sets Balances and Net Changes
        /// </summary>
        /// <value><c>true</c> if [bal net changes]; otherwise, <c>false</c>.</value>
        [Display(Name = "BalNetChanges", ResourceType = typeof (TransactionsListingResx))]
        public bool BalNetChanges { get; set; }

        /// <summary>
        /// Gets or Sets Include Change
        /// </summary>
        /// <value><c>true</c> if [include change UI]; otherwise, <c>false</c>.</value>
        [Display(Name = "PSeqBatchEntry", ResourceType = typeof (TransactionsListingResx))]
        public bool IncludeChangeUi { get; set; }

        /// <summary>
        /// E-09360
        /// Gets or Sets Include Tax Information
        /// </summary>
        /// <value><c>true</c> if [include tax info]; otherwise, <c>false</c>.</value>
        [Display(Name = "TaxInformation", ResourceType = typeof(TransactionsListingResx))]
        public bool IncludeTaxInformation { get; set; }
    }
}