// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
	/// <summary>
	/// Partial class for SourceJournalProfileReport
	/// </summary>
	public partial class SourceJournalProfileReport : ReportBase
	{
		/// <summary>
		/// Gets or sets From Source Journal Profile.
		/// </summary>
        [Display(Name = "FromProfile", ResourceType = typeof(SourceJournalProfileReportResx))]
		public string Frjrnl { get; set; }

		/// <summary>
		/// Gets or sets To Source Journal Profile.
		/// </summary>
        [Display(Name = "ToProfile", ResourceType = typeof(SourceJournalProfileReportResx))]
		public string Tojrnl { get; set; }
	}
}
