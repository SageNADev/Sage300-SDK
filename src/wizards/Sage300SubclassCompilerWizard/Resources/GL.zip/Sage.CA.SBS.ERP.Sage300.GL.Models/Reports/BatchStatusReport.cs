﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Customization.Validators;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    public partial class BatchStatusReport : ReportBase
    {
        /// <summary>
        ///  Gets or sets FromBatchNumber 
        /// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof(BatchStatusReportResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromBatchNumber { get; set; }

        /// <summary>
        ///  Gets or sets ToBatchNumber 
        /// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof(BatchStatusReportResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToBatchNumber { get; set; }

        /// <summary>
        ///  Gets or sets FromLedger 
        /// </summary>
        [Display(Name = "SourceLedger", ResourceType = typeof(BatchStatusReportResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromLedger { get; set; }

        /// <summary>
        /// Gets or sets ToLedger 
        /// </summary>
        [Display(Name = "SourceLedger", ResourceType = typeof(BatchStatusReportResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToLedger { get; set; }

        /// <summary>
        /// Gets or sets FromDate 
        /// </summary>
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or sets ToDate 
        /// </summary>
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ToDate { get; set; }

        /// <summary>
        /// Gets or sets Batch Types
        /// </summary>
        [ValidateListForSelection]
        [Display(Name = "Type", ResourceType = typeof(BatchStatusReportResx))]
        public List<MultiSelect> Types { get; set; }

        /// <summary>
        /// Gets or sets Batch Status
        /// </summary>
        [ValidateListForSelection]
        [Display(Name = "Status", ResourceType = typeof(BatchStatusReportResx))]
        public List<MultiSelect> Status { get; set; }

        /// <summary>
        /// Gets or Sets Provisional Posting Allowed
        /// </summary>
        public bool ProvisionalPostingAllowed { get; set; }

        /// <summary>
        /// Gets or Sets Quantity History Allowed
        /// </summary>
        public QuantityHistoryAllowed QuantityHistoryAllowed { get; set; }

        /// <summary>
        /// Gets or Sets Number Of Decimals For Qty
        /// </summary>
        public decimal NumberOfDecimalsForQty { get; set; }

        /// <summary>
        /// Gets or Sets UseGLSecurity
        /// </summary>
        public UseGLSecurity UseGLSecurity { get; set; }

        /// <summary>
        /// Gets or Sets Last Issued Batch Number
        /// </summary>
        public decimal LastIssuedBatchNumber { get; set; }

        /// <summary>
        /// Gets or Sets GSAccount Access Switch
        /// </summary>
        // ReSharper disable once InconsistentNaming
        public GSAccountAccessSwitch GSAccountAccessSwitch { get; set; }

        /// <summary>
        /// Gets or Sets FcurnDec 
        /// </summary>
        public decimal FcurnDec { get; set; }

        /// <summary>
        /// Gets or Sets QtyHdg
        /// </summary>
        public string QtyHdg { get; set; }

        /// <summary>
        /// Gets or Sets Usegs
        /// </summary>
        public decimal Usegs { get; set; }

        /// <summary>
        /// Gets or Sets QtyHdg
        /// </summary>
        public string QtySw { get; set; }

        /// <summary>
        /// Gets or Sets QtyHdg
        /// </summary>
        public int IctActive { get; set; }

        /// <summary>
        /// Provisional Posting Allowed for UI
        /// </summary>
        public bool ProvisionalPostAllowed { get; set; }
    }
}
