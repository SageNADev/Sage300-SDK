// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Reports;
using System.ComponentModel.DataAnnotations;
using GLCurrencyType = Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.CurrencyType;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Partial class for PostingJournal
    /// </summary>
    public partial class PostingJournal : ReportBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or Sets SelectJournal
        ///  </summary>
        public SelectJournal SelectJournal { get; set; }

        /// <summary>
        /// Gets or Sets PostingJournalSortBy
        ///  </summary>
        public PostingJournalSortBy PostingJournalSortBy { get; set; }

        /// <summary>
        /// Gets or sets FromSequence
        /// </summary>
        [Display(Name = "FromPSQ", ResourceType = typeof (PostingJournalsResx))]
        public string FromSequence { get; set; }

        /// <summary>
        /// Gets or sets ToSequence
        /// </summary>
        [Display(Name = "ToPSQ", ResourceType = typeof (PostingJournalsResx))]
        public string ToSequence { get; set; }

        /// <summary>
        /// Gets or sets QuantityDecimal
        /// </summary>
        public decimal QuantityDecimal { get; set; }

        /// <summary>
        /// Gets or sets QtyHdg
        /// </summary>
        public string QtyHdg { get; set; }

        /// <summary>
        /// Gets or sets UnitHdg
        /// </summary>
        public string UnitHdg { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyDecimal
        /// </summary>
        public decimal FunctionalCurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        public GLCurrencyType Currency { get; set; }

        /// <summary>
        /// Gets or sets Usegs
        /// </summary>
        public string UseGs { get; set; }

        /// <summary>
        /// Gets or sets ApplicationUser
        /// </summary>
        public string ApplicationUser { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "TransDetail", ResourceType = typeof (PostingJournalsResx))]
        public bool OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets DateCategory
        /// </summary>
        public DateCategory DateCategory { get; set; }

        /// <summary>
        /// Gets or sets Reprint
        /// </summary>
        [Display(Name = "Reprint", ResourceType = typeof (CommonResx))]
        public bool Reprint { get; set; }

        /// <summary>
        /// Gets or sets Is Ict Installed
        /// </summary>
        public bool IsIctInstalled { get; set; }

        /// <summary>
        /// Gets or sets IcMultiCurrency
        /// </summary>
        public bool IcMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets IctExpType
        /// </summary>
        public string IctExpType { get; set; }

        /// <summary>
        /// Gets or sets PaperSize
        /// </summary>
        public PaperSize PaperSize { get; set; }

        /// <summary>
        /// Gets or sets HasObLicense
        /// </summary>
        public bool HasObLicense { get; set; }

        /// <summary>
        /// Gets or sets Next Actual Posting Sequence
        /// </summary>
        public decimal NextActualPostSeq { get; set; }

        /// <summary>
        /// Gets or sets Is Quantity History Allowed
        /// </summary>
        public bool IsQuantityHistoryAllowed { get; set; }

        /// <summary>
        /// Gets or sets IsProvisionalPostingAllowed
        /// </summary>
        public bool IsProvisionalPostingAllowed { get; set; }

        /// <summary>
        /// Gets or sets TransitionCompanyStage
        /// </summary>
        public TransitionCompanyStage TransitionCompanyStage { get; set; }

        /// <summary>
        /// E-09360
        /// Gets or Sets Include Tax Information
        /// </summary>
        /// <value><c>true</c> if [include tax info]; otherwise, <c>false</c>.</value>
        [Display(Name = "TaxInformation", ResourceType = typeof(PostingJournalsResx))]
        public bool IncludeTaxInformation { get; set; }

        /// <summary>
        /// E-09360
        /// Gets or Sets IsTaxInformationVisible
        /// </summary>
        public bool IsTaxInformationVisible { get; set; }

        #endregion
    }
}
