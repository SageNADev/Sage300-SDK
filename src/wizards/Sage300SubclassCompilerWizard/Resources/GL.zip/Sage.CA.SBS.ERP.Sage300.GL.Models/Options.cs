﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of properties for GLOptions
    /// </summary>
    public partial class Options : ModelBase
    {
        /// <summary>
        /// GLOptions Constructor to initialise default Account Segments
        /// </summary>
        public Options()
        {
            AccountSegments = new List<AccountSegments> { new AccountSegments() };
            CompanyProfile=new CompanyProfile();
        }

        /// <summary>
        /// Gets or Sets GLOptionKey
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLOptionKey", ResourceType = typeof(OptionsResx))]
        [Key]
        public string GLOptionKey { get; set; }

        /// <summary>
        /// Gets or Sets Company Phone Number
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompanyPhoneNumber", ResourceType = typeof(OptionsResx))]
        public string CompanyPhoneNumber { get; set; }

        /// <summary>
        /// Gets or Sets Company Fax Number
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompanyFaxNumber", ResourceType = typeof(OptionsResx))]
        public string CompanyFaxNumber { get; set; }

        /// <summary>
        /// Gets or Sets OrganizationId
        /// </summary>
        public string OrganizationId { get; set; }

        /// <summary>
        /// Gets or Sets Client Contact Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactName", ResourceType = typeof(OptionsResx))]
        public string ClientContactName { get; set; }

        /// <summary>
        /// Gets or Sets Main Account SegmentId
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MainAcctSegmentId", ResourceType = typeof(OptionsResx))]
        public string MainAcctSegmentId { get; set; }

        /// <summary>
        /// Gets or Sets Default Structure Code
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultStructureCode", ResourceType = typeof(OptionsResx))]
        public string DefaultStructureCode { get; set; }

        /// <summary>
        /// Gets or Sets Structure Code Delimiter
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentDelim", ResourceType = typeof(OptionsResx))]
        public string StructureCodeDelimiter { get; set; }

        /// <summary>
        /// Gets or Sets Batch Edit Allowed
        /// </summary>
        [Display(Name = "EditImportEnt", ResourceType = typeof(OptionsResx))]
        public BatchEditAllowed BatchEditAllowed { get; set; }

        /// <summary>
        /// Gets or Sets Provisional Posting Allowed
        /// </summary>
        [Display(Name = "AllowProvPosting", ResourceType = typeof(OptionsResx))]
        public ProvisionalPostingAllowed ProvisionalPostingAllowed { get; set; }

        /// <summary>
        /// Gets or Sets Print Batches Prior To Post
        /// </summary>
        [Display(Name = "ForceBatchListing", ResourceType = typeof(OptionsResx))]
        public PrintBatchesPriorToPost PrintBatchesPriorToPost { get; set; }

        /// <summary>
        /// Gets or Sets Budget1 Lock
        /// </summary>
        [Display(Name = "BudgetSet1", ResourceType = typeof(OptionsResx))]
        public BudgetLock Budget1Lock { get; set; }

        /// <summary>
        /// Gets or Sets Budget2 Lock
        /// </summary>
        [Display(Name = "BudgetSet2", ResourceType = typeof(OptionsResx))]
        public BudgetLock Budget2Lock { get; set; }

        /// <summary>
        /// Gets or Sets Budget3 Lock
        /// </summary>
        [Display(Name = "BudgetSet3", ResourceType = typeof(OptionsResx))]
        public BudgetLock Budget3Lock { get; set; }

        /// <summary>
        /// Gets or Sets Budget4 Lock
        /// </summary>
        [Display(Name = "BudgetSet4", ResourceType = typeof(OptionsResx))]
        public BudgetLock Budget4Lock { get; set; }

        /// <summary>
        /// Gets or Sets Budget5 Lock
        /// </summary>
        [Display(Name = "BudgetSet5", ResourceType = typeof(OptionsResx))]
        public BudgetLock Budget5Lock { get; set; }

        /// <summary>
        /// Gets or Sets Quantity History Allowed
        /// </summary>
        [Display(Name = "QuantityHistoryAllowed", ResourceType = typeof(OptionsResx))]
        public QuantityHistoryAllowed QuantityHistoryAllowed { get; set; }

        /// <summary>
        /// Gets or Sets Number Of Decimals For Qty
        /// </summary>
        [Range(0, 3, ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DecimalPlaces", ResourceType = typeof(OptionsResx))]
        public decimal NumberOfDecimalsForQty { get; set; }

        /// <summary>
        /// Gets or Sets Years Of Summary History Kept
        /// </summary>
        [Range(0, 99, ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "YearsOfFiscalSets", ResourceType = typeof(OptionsResx))]
        public decimal YearsOfSummaryHistoryKept { get; set; }

        /// <summary>
        /// Gets or Sets Last Issued Batch Number
        /// </summary>
        [Display(Name = "LastBatch", ResourceType = typeof(OptionsResx))]
        public decimal LastIssuedBatchNumber { get; set; }

        /// <summary>
        /// Gets or Sets Next Actual Post Seq
        /// </summary>
        [Display(Name = "NextPostingSeq", ResourceType = typeof(OptionsResx))]
        public decimal NextActualPostSeq { get; set; }

        /// <summary>
        /// Gets or Sets Next Provisional Post Seq
        /// </summary>
        [Display(Name = "NextProvPostSeq", ResourceType = typeof(OptionsResx))]
        public decimal NextProvisionalPostSeq { get; set; }

        /// <summary>
        /// Gets or Sets Last Closed Year
        /// </summary>
        public decimal LastClosedYear { get; set; }

        /// <summary>
        /// Gets or Sets Oldest Year Of Fiscal Sets
        /// </summary>
        [Display(Name = "OldestYearFS", ResourceType = typeof(OptionsResx))]
        public decimal OldestYearOfFiscalSets { get; set; }

        /// <summary>
        /// Gets or Sets Oldest Year Of TransDetail
        /// </summary>
        [Display(Name = "OldestYearTrans", ResourceType = typeof(OptionsResx))]
        public decimal OldestYearOfTransDetail { get; set; }

        /// <summary>
        /// Gets or Sets Default Retained Earning Account
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultClosingAcct", ResourceType = typeof(OptionsResx))]
        public string DefaultRetainedEarningAcct { get; set; }

        /// <summary>
        /// Gets or Sets MultiCurrency Activated Switch
        /// </summary>
        [Display(Name = "MulticurrencyActivatedSwitch", ResourceType = typeof(OptionsResx))]
        public MulticurrencyActivatedSwitch MultiCurrencyActivatedSwitch { get; set; }

        /// <summary>
        /// Gets or Sets Default Currency Rate Type
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultRateType", ResourceType = typeof(OptionsResx))]
        public string DefaultCurrencyRateType { get; set; }

        /// <summary>
        /// Gets or Sets Account Group Switch
        /// </summary>
        [Display(Name = "UseAcctGroup", ResourceType = typeof(OptionsResx))]
        public AccountGroupSwitch AccountGroupSwitch { get; set; }

        /// <summary>
        /// Gets or Sets Allow Previous Year Posting
        /// </summary>
        [Display(Name = "AllowPostingPrevYr", ResourceType = typeof(OptionsResx))]
        public AllowPreviousYearPosting AllowPreviousYearPosting { get; set; }

        /// <summary>
        /// Gets or Sets Years Of Detail History Kept
        /// </summary>
        [Range(0, 99, ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "YearsOfTransDetail", ResourceType = typeof(OptionsResx))]
        public decimal YearsOfDetailHistoryKept { get; set; }

        /// <summary>
        /// Gets or Sets Transition Rounding Account
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransitionRoundingAccount", ResourceType = typeof(OptionsResx))]
        public string TransitionRoundingAccount { get; set; }

        /// <summary>
        /// Gets or Sets Source Type
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultSourceCode", ResourceType = typeof(OptionsResx))]
        public string SourceType { get; set; }

        /// <summary>
        /// Gets or Sets UseGLSecurity
        /// </summary>
        [Display(Name = "UseSecurity", ResourceType = typeof(OptionsResx))]
        public UseGLSecurity UseGLSecurity { get; set; }

        /// <summary>
        /// Gets or Sets Default Access
        /// </summary>
        [Display(Name = "DefaultAccess", ResourceType = typeof(OptionsResx))]
        public DefaultAccess DefaultAccess { get; set; }

        /// <summary>
        /// Gets or Sets Current Year
        /// </summary>
        [Display(Name = "CurrentYear", ResourceType = typeof(OptionsResx))]
        public decimal CurrentYear { get; set; }

        /// <summary>
        /// Gets or Sets Transition Company Stage
        /// </summary>
        public TransitionCompanyStage TransitionCompanyStage { get; set; }

        /// <summary>
        /// Gets or Sets Maximum Segments Per Acct
        /// </summary>
        public MaximumSegmentsPerAcct MaximumSegmentsPerAcct { get; set; }

        /// <summary>
        /// Gets or Sets Maximum Account Structures
        /// </summary>
        public MaximumAccountStructures MaximumAccountStructures { get; set; }

        /// <summary>
        /// Gets or Sets Locked Fiscal Periods Allowed
        /// </summary>
        public LockedFiscalPeriodsAllowed LockedFiscalPeriodsAllowed { get; set; }

        /// <summary>
        /// Gets or Sets IctInstalled
        /// </summary>
        public UseGLSecurity IctInstalled { get; set; }

        /// <summary>
        /// Gets or Sets GSAccount Access Switch
        /// </summary>
        public GSAccountAccessSwitch GSAccountAccessSwitch { get; set; }

        /// <summary>
        /// Gets or Sets Revaluation Method
        /// </summary>
        public RevaluationMethod RevaluationMethod { get; set; }

        /// <summary>
        /// Gets or sets Account Segments List
        /// </summary>
        public List<AccountSegments> AccountSegments { get; set; }

        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        public CompanyProfile CompanyProfile { get; set; }

        #region UI Properties

        /// <summary>
        /// Segment Delimeter Disable for UI to freeze control
        /// </summary>
        public bool SegmentDelimeterDisable
        {
            get { return !string.IsNullOrEmpty(StructureCodeDelimiter); }
        }

        /// <summary>
        /// Multicurrency Activated Switch Disable for UI to freeze control
        /// </summary>
        public bool MultiCurrActivatedSwitchDisable
        {
            get { return MultiCurrencyActivatedSwitch != MulticurrencyActivatedSwitch.Inactive; }
        }

        /// <summary>
        /// Multicurrency Activated Switch for UI
        /// </summary>
        public bool MultiCurrActivatedSwitch
        {
            get { return MultiCurrencyActivatedSwitch != MulticurrencyActivatedSwitch.Inactive; }
            set
            {
                MultiCurrencyActivatedSwitch = value
                    ? MulticurrencyActivatedSwitch.Active
                    : MulticurrencyActivatedSwitch.Inactive;
            }
        }

        /// <summary>
        /// Account Group Switch for UI
        /// </summary>
        public bool AcctGroupSwitch
        {
            get { return AccountGroupSwitch != AccountGroupSwitch.DoNotAllowAccountGroups; }
            set
            {
                AccountGroupSwitch = value
                    ? AccountGroupSwitch.AccountGroupsAllowed
                    : AccountGroupSwitch.DoNotAllowAccountGroups;
            }
        }

        /// <summary>
        /// Quantity History Allowed Disable for UI to freeze control
        /// </summary>
        public bool QuantityHistAllowedDisable
        {
            get { return QuantityHistoryAllowed != QuantityHistoryAllowed.DoNotAllowQuantities; }
        }

        /// <summary>
        /// Quantity History Allowed for UI
        /// </summary>
        public bool QuantityHistAllowed
        {
            get { return QuantityHistoryAllowed != QuantityHistoryAllowed.DoNotAllowQuantities; }
            set
            {
                QuantityHistoryAllowed = value
                    ? QuantityHistoryAllowed.QuantitiesAllowed
                    : QuantityHistoryAllowed.DoNotAllowQuantities;
            }
        }

        /// <summary>
        /// Use GL Security for UI
        /// </summary>
        public bool UseGlSecurityUi
        {
            get { return UseGLSecurity != UseGLSecurity.No; }
            set { UseGLSecurity = value ? UseGLSecurity.Yes : UseGLSecurity.No; }
        }

        /// <summary>
        /// Budget1 Lock for UI
        /// </summary>
        public bool BudgetOnelock
        {
            get { return Budget1Lock != BudgetLock.Unlocked; }
            set { Budget1Lock = value ? BudgetLock.Locked : BudgetLock.Unlocked; }
        }

        /// <summary>
        /// Budget2 Lock for UI
        /// </summary>
        public bool BudgetTwoLock
        {
            get { return Budget2Lock != BudgetLock.Unlocked; }
            set { Budget2Lock = value ? BudgetLock.Locked : BudgetLock.Unlocked; }
        }

        /// <summary>
        /// Budget3 Lock for UI
        /// </summary>
        public bool BudgetThreeLock
        {
            get { return Budget3Lock != BudgetLock.Unlocked; }
            set { Budget3Lock = value ? BudgetLock.Locked : BudgetLock.Unlocked; }
        }

        /// <summary>
        /// Budget4 Lock for UI
        /// </summary>
        public bool BudgetFourLock
        {
            get { return Budget4Lock != BudgetLock.Unlocked; }
            set { Budget4Lock = value ? BudgetLock.Locked : BudgetLock.Unlocked; }
        }

        /// <summary>
        /// Budget5 Lock for UI
        /// </summary>
        public bool BudgetFiveLock
        {
            get { return Budget5Lock != BudgetLock.Unlocked; }
            set { Budget5Lock = value ? BudgetLock.Locked : BudgetLock.Unlocked; }
        }

        /// <summary>
        /// Allow Previous Year Posting for UI
        /// </summary>
        public bool AllowPreviousYrPosting
        {
            get { return AllowPreviousYearPosting != AllowPreviousYearPosting.DoNotAllowPreviousYrPosting; }
            set
            {
                AllowPreviousYearPosting = value
                    ? AllowPreviousYearPosting.PreviousYrPostingAllowed
                    : AllowPreviousYearPosting.DoNotAllowPreviousYrPosting;
            }
        }

        /// <summary>
        /// Provisional Posting Allowed for UI
        /// </summary>
        public bool ProvisionalPostAllowed
        {
            get { return ProvisionalPostingAllowed != ProvisionalPostingAllowed.ProvisionalPostingNotAllowed; }
            set
            {
                ProvisionalPostingAllowed = value
                    ? ProvisionalPostingAllowed.ProvisionalPostingAllowed
                    : ProvisionalPostingAllowed.ProvisionalPostingNotAllowed;
            }
        }

        /// <summary>
        /// Print Batches Prior To Post for UI
        /// </summary>
        public bool PrintBatchPriorToPost
        {
            get { return PrintBatchesPriorToPost != PrintBatchesPriorToPost.PrintingNotRequired; }
            set
            {
                PrintBatchesPriorToPost = value
                    ? PrintBatchesPriorToPost.PrintingRequired
                    : PrintBatchesPriorToPost.PrintingNotRequired;
            }
        }

        /// <summary>
        /// Main Account Segment for UI
        /// </summary>
        public string MainAcctSegment
        {
            get
            {
                MainAcctSegmentId = MainAcctSegmentId ?? "";
                return CommonUtil.TrimStartZero(MainAcctSegmentId);
            }
            set { MainAcctSegmentId = CommonUtil.Pad(value, 6, true); }
        }

        /// <summary>
        /// Default Structure Code for UI
        /// </summary>
        public bool IsDefaultStructureCodeDisable { get; set; }

        #endregion
    }
}