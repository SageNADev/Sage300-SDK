// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Partial class for ConsolidatePostedTransaction
    /// </summary>
    public partial class ConsolidatePostedTransaction : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public ConsolidatePostedTransaction()
        {
            ConsolidatePostedTransactionDetail = new EnumerableResponse<ConsolidatePostedTransactionDetail>();
        }
        /// <summary>
        /// Gets or sets Accountsegmentselectioncode
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        public AccountSegmentSelectionCode AccountSegmentSelectionCode { get; set; }

        /// <summary>
        /// Gets or sets Accountsegmentselected
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        public string AccountSegmentSelected { get; set; }

        /// <summary>
        /// Gets or sets FromAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FromAccountNumber, Id = Index.FromAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string FromAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets ToAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ToAccountNumber, Id = Index.ToAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ToAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets YearToconsolidate
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        public string YearToConsolidate { get; set; }

        /// <summary>
        /// Gets or sets PeriodToconsolidate
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string PeriodToConsolidate { get; set; }

        /// <summary>
        /// Gets or sets TypeOfconsolidation
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        public TypeOfconsolidation TypeOfConsolidation { get; set; }

        /// <summary>
        /// Gets or sets SourceType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType", ResourceType = typeof(ConsolidatePostedTransactionsResx))]
        [ViewField(Name = Fields.SourceType, Id = Index.SourceType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType { get; set; }

        /// <summary>
        /// Gets or sets SourceLedger
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceLedger", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.SourceLedger, Id = Index.SourceLedger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedger { get; set; }

        /// <summary>
        /// Gets or sets ConsolidateSwitch
        /// </summary>
        [Display(Name = "Consolidate", ResourceType = typeof(ConsolidatePostedTransactionsResx))]
        [ViewField(Name = Fields.ConsolidateSwitch, Id = Index.ConsolidateSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public ConsolidateSwitch ConsolidateSwitch { get; set; }

        /// <summary>
        /// Gets or sets RetrieveSrcLedgerSwitch
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetrieveSrcLedgerSwitch, Id = Index.RetrieveSrcLedgerSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public RetrieveSrcLedgerSwitch RetrieveSrcLedgerSwitch { get; set; }

        /// <summary>
        /// Gets or sets TotalRetrievedLedgers
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TotalRetrievedLedgers, Id = Index.TotalRetrievedLedgers, FieldType = EntityFieldType.Int, Size = 2)]
        public int TotalRetrievedLedgers { get; set; }

        /// <summary>
        /// Gets or sets ListLedgerCodesFrom
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ListLedgerCodesFrom, Id = Index.ListLedgerCodesFrom, FieldType = EntityFieldType.Int, Size = 2)]
        public int ListLedgerCodesFrom { get; set; }

        /// <summary>
        /// Gets or sets RetrievedLedgersCodes
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetrievedLedgersCodes, Id = Index.RetrievedLedgersCodes, FieldType = EntityFieldType.Char, Size = 20)]
        public string RetrievedLedgersCodes { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(ConsolidatePostedTransactionsResx))]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets HasOBLicense
        /// </summary>
        // ReSharper disable once InconsistentNaming
        public bool HasOBLicense { get; set; }

        /// <summary>
        /// Gets ot sets MultiCurrencyActivatedSwitch
        /// </summary>
        public bool MultiCurrencyActivatedSwitch { get; set; }

        /// <summary>
        /// Gets or sets QuantityHistoryAllowed
        /// </summary>
        public bool QuantityHistoryAllowed { get; set; }

        /// <summary>
        /// Gets or sets ConsolidatePostedTransactionDetail
        /// </summary>
        public EnumerableResponse<ConsolidatePostedTransactionDetail> ConsolidatePostedTransactionDetail { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Accountsegmentselectioncode string value
        /// </summary>
        public string AccountsegmentselectioncodeString
        {
            get { return EnumUtility.GetStringValue(AccountSegmentSelectionCode); }
        }

        /// <summary>
        /// Gets TypeOfconsolidation string value
        /// </summary>
        public string TypeOfconsolidationString
        {
            get { return EnumUtility.GetStringValue(TypeOfConsolidation); }
        }

        /// <summary>
        /// Gets ConsolidateSwitch string value
        /// </summary>
        public string ConsolidateSwitchString
        {
            get { return EnumUtility.GetStringValue(ConsolidateSwitch); }
        }

        /// <summary>
        /// Gets RetrieveSrcLedgerSwitch string value
        /// </summary>
        public string RetrieveSrcLedgerSwitchString
        {
            get { return EnumUtility.GetStringValue(RetrieveSrcLedgerSwitch); }
        }

        #endregion
    }

}
