/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    public partial class BatchStatus : ModelBase
    {

        /// <summary>
        /// Gets or sets FromBatchNumber 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromBatchNumber, Id = Index.FromBatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string FromBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets ToBatchNumber 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToBatchNumber, Id = Index.ToBatchNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string ToBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets Fromledger 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromLedger, Id = Index.FromLedger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string FromLedger { get; set; }

        /// <summary>
        /// Gets or sets Toledger 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToLedger, Id = Index.ToLedger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string ToLedger { get; set; }

        /// <summary>
        /// Gets or sets Fromdate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromDate, Id = Index.FromDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FromDate { get; set; }

        /// <summary>
        /// Gets or sets Todate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToDate, Id = Index.ToDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Gets or sets Batchtypeentered 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeEntered, Id = Index.BatchTypeEntered, FieldType = EntityFieldType.Char, Size = 1)]
        public BatchTypeEnteredEnum BatchTypeEntered { get; set; }

        /// <summary>
        /// Gets or sets Batchtypesubledger 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeSubledger, Id = Index.BatchTypeSubledger, FieldType = EntityFieldType.Char, Size = 1)]
        public BatchTypeEnteredEnum BatchTypeSubledger { get; set; }

        /// <summary>
        /// Gets or sets Batchtypeimported 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeImported, Id = Index.BatchTypeImported, FieldType = EntityFieldType.Char, Size = 1)]
        public BatchTypeEnteredEnum BatchTypeImported { get; set; }

        /// <summary>
        /// Gets or sets Batchtypegenerated 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeGenerated, Id = Index.BatchTypeGenerated, FieldType = EntityFieldType.Char, Size = 1)]
        public BatchTypeEnteredEnum BatchTypeGenerated { get; set; }

        /// <summary>
        /// Gets or sets Batchstatusopen 
        /// </summary>

        [ViewField(Name = Fields.BatchStatusOpen, Id = Index.BatchStatusOpen, FieldType = EntityFieldType.Char, Size = 1)]
        public BatchTypeEnteredEnum BatchStatusOpen { get; set; }

        /// <summary>
        /// Gets or sets Batchstatusprinted 
        /// </summary>

        [ViewField(Name = Fields.BatchStatusPrinted, Id = Index.BatchStatusPrinted, FieldType = EntityFieldType.Char, Size = 1)]
        public BatchStatusPrintedEnum BatchStatusPrinted { get; set; }

        /// <summary>
        /// Gets or sets Batchstatusprovisionalpost 
        /// </summary>

        [ViewField(Name = Fields.BatchStatusProvisionalPost, Id = Index.BatchStatusProvisionalPost, FieldType = EntityFieldType.Char, Size = 1)]
        public BatchTypeEnteredEnum BatchStatusProvisionalPost { get; set; }

        /// <summary>
        /// Gets or sets Batchstatusreadytopost 
        /// </summary>

        [ViewField(Name = Fields.BatchStatusReadyToPost, Id = Index.BatchStatusReadyToPost, FieldType = EntityFieldType.Char, Size = 1)]
        public BatchTypeEnteredEnum BatchStatusReadyToPost { get; set; }

        /// <summary>
        /// Gets or sets Batchtyperecurring 
        /// </summary>

        [ViewField(Name = Fields.BatchTypeRecurring, Id = Index.BatchTypeRecurring, FieldType = EntityFieldType.Char, Size = 1)]
        public BatchTypeEnteredEnum BatchTypeRecurring { get; set; }

        /// <summary>
        /// Gets or sets Batchstatusposted 
        /// </summary>

        [ViewField(Name = Fields.BatchStatusPosted, Id = Index.BatchStatusPosted, FieldType = EntityFieldType.Char, Size = 1)]
        public BatchTypeEnteredEnum BatchStatusPosted { get; set; }
    }
}
