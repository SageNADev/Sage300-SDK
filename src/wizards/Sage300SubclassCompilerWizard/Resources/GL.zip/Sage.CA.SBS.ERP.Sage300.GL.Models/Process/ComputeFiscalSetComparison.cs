// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Partial class for ComputeFiscalSetComparison
    /// </summary>
    public partial class ComputeFiscalSetComparison : ModelBase
    {
        /// <summary>
        /// Gets or sets Amount1
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Amount1", ResourceType = typeof(FiscalSetComparisonResx))]
        [ViewField(Name = Fields.Amount1, Id = Index.Amount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount1 { get; set; }

        /// <summary>
        /// Gets or sets Amount2
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Amount2", ResourceType = typeof(FiscalSetComparisonResx))]
        [ViewField(Name = Fields.Amount2, Id = Index.Amount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount2 { get; set; }

        /// <summary>
        /// Gets or sets Difference
        /// </summary>
        [Display(Name = "Difference", ResourceType = typeof(FiscalSetComparisonResx))]
        [ViewField(Name = Fields.Difference, Id = Index.Difference, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Difference { get; set; }

        /// <summary>
        /// Gets or sets PercentDifference
        /// </summary>
        [Display(Name = "Percent", ResourceType = typeof(FiscalSetComparisonResx))]
        [ViewField(Name = Fields.PercentDifference, Id = Index.PercentDifference, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal PercentDifference { get; set; }
    }

    /// <summary>
    /// Class for ComputeFiscalSetAmount
    /// </summary>
    public class ComputeFiscalSetAmount
    {
        /// <summary>
        /// Gets or Sets List of Amount1
        /// </summary>
        public List<decimal> Amount1 { get; set; }

        /// <summary>
        /// Gets or Sets List of Amount2
        /// </summary>
        public List<decimal> Amount2 { get; set; }

    }

}
