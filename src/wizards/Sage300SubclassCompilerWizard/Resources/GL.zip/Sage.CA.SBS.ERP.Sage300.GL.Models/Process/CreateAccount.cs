// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Partial class for CreateAccount
    /// </summary>
    public partial class CreateAccount : ModelBase
    {
        /// <summary>
        /// Gets or sets FromAccountsWithStructureCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromAccountsWithStructureCode, Id = Index.FromAccountsWithStructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FromAccountsWithStructureCode { get; set; }

        /// <summary>
        /// Gets or sets CreateAccountsWithStructureCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreateAccountsWithStructureCode, Id = Index.CreateAccountsWithStructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CreateAccountsWithStructureCode { get; set; }

        /// <summary>
        /// Gets or sets SelectBy
        /// </summary>
        [ViewField(Name = Fields.SelectBy, Id = Index.SelectBy, FieldType = EntityFieldType.Int, Size = 2)]
        public int SelectBy { get; set; }

        /// <summary>
        /// Gets or sets FromAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromAccountNumber, Id = Index.FromAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string FromAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets ToAccountNumber
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToAccountNumber, Id = Index.ToAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ToAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets FromAccountGroupCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromAccountGroupCode, Id = Index.FromAccountGroupCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string FromAccountGroupCode { get; set; }

        /// <summary>
        /// Gets or sets ToAccountGroupCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToAccountGroupCode, Id = Index.ToAccountGroupCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string ToAccountGroupCode { get; set; }

        /// <summary>
        /// Gets or sets FromAccountGroupSortCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromAccountGroupSortCode, Id = Index.FromAccountGroupSortCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string FromAccountGroupSortCode { get; set; }

        /// <summary>
        /// Gets or sets ToAccountGroupSortCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToAccountGroupSortCode, Id = Index.ToAccountGroupSortCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string ToAccountGroupSortCode { get; set; }

        /// <summary>
        /// Gets or sets SegmentId
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SegmentId, Id = Index.SegmentId, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06d")]
        public string SegmentId { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SegmentCode, Id = Index.SegmentCode, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentCode { get; set; }

        /// <summary>
        /// Gets or sets DefaultSubledgerDetails
        /// </summary>
        [ViewField(Name = Fields.DefaultSubledgerDetails, Id = Index.DefaultSubledgerDetails, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType DefaultSubledgerDetails { get; set; }

        /// <summary>
        /// Gets or sets DefaultCurrencyOptions
        /// </summary>
        [ViewField(Name = Fields.DefaultCurrencyOptions, Id = Index.DefaultCurrencyOptions, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType DefaultCurrencyOptions { get; set; }

        /// <summary>
        /// Gets or sets GenerateExistingAccount
        /// </summary>
        [ViewField(Name = Fields.GenerateExistingAccount, Id = Index.GenerateExistingAccount, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType GenerateExistingAccount { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment1
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment1, Id = Index.CreateNewForSegment1, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateNewForSegment CreateNewForSegment1 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment1, Id = Index.FromSegment1, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string FromSegment1 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment1, Id = Index.ToSegment1, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ToSegment1 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment1, Id = Index.DefaultOptionFromSegment1, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string DefaultOptionFromSegment1 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment2
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment2, Id = Index.CreateNewForSegment2, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateNewForSegment CreateNewForSegment2 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment2, Id = Index.FromSegment2, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string FromSegment2 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment2, Id = Index.ToSegment2, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ToSegment2 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment2, Id = Index.DefaultOptionFromSegment2, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string DefaultOptionFromSegment2 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment3
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment3, Id = Index.CreateNewForSegment3, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateNewForSegment CreateNewForSegment3 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment3, Id = Index.FromSegment3, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string FromSegment3 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment3, Id = Index.ToSegment3, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ToSegment3 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment3, Id = Index.DefaultOptionFromSegment3, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string DefaultOptionFromSegment3 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment4
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment4, Id = Index.CreateNewForSegment4, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateNewForSegment CreateNewForSegment4 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment4, Id = Index.FromSegment4, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string FromSegment4 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment4, Id = Index.ToSegment4, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ToSegment4 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment4, Id = Index.DefaultOptionFromSegment4, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string DefaultOptionFromSegment4 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment5
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment5, Id = Index.CreateNewForSegment5, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateNewForSegment CreateNewForSegment5 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment5, Id = Index.FromSegment5, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string FromSegment5 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment5, Id = Index.ToSegment5, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ToSegment5 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment5, Id = Index.DefaultOptionFromSegment5, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string DefaultOptionFromSegment5 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment6
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment6, Id = Index.CreateNewForSegment6, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateNewForSegment CreateNewForSegment6 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment6, Id = Index.FromSegment6, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string FromSegment6 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment6, Id = Index.ToSegment6, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ToSegment6 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment6, Id = Index.DefaultOptionFromSegment6, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string DefaultOptionFromSegment6 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment7
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment7, Id = Index.CreateNewForSegment7, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateNewForSegment CreateNewForSegment7 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment7
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment7, Id = Index.FromSegment7, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string FromSegment7 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment7
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment7, Id = Index.ToSegment7, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ToSegment7 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment7
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment7, Id = Index.DefaultOptionFromSegment7, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string DefaultOptionFromSegment7 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment8
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment8, Id = Index.CreateNewForSegment8, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateNewForSegment CreateNewForSegment8 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment8
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment8, Id = Index.FromSegment8, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string FromSegment8 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment8
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment8, Id = Index.ToSegment8, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ToSegment8 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment8
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment8, Id = Index.DefaultOptionFromSegment8, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string DefaultOptionFromSegment8 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment9
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment9, Id = Index.CreateNewForSegment9, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateNewForSegment CreateNewForSegment9 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment9
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment9, Id = Index.FromSegment9, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string FromSegment9 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment9
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment9, Id = Index.ToSegment9, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ToSegment9 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment9
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment9, Id = Index.DefaultOptionFromSegment9, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string DefaultOptionFromSegment9 { get; set; }

        /// <summary>
        /// Gets or sets CreateNewForSegment10
        /// </summary>
        [ViewField(Name = Fields.CreateNewForSegment10, Id = Index.CreateNewForSegment10, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateNewForSegment CreateNewForSegment10 { get; set; }

        /// <summary>
        /// Gets or sets FromSegment10
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromSegment10, Id = Index.FromSegment10, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string FromSegment10 { get; set; }

        /// <summary>
        /// Gets or sets ToSegment10
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToSegment10, Id = Index.ToSegment10, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ToSegment10 { get; set; }

        /// <summary>
        /// Gets or sets DefaultOptionFromSegment10
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultOptionFromSegment10, Id = Index.DefaultOptionFromSegment10, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string DefaultOptionFromSegment10 { get; set; }

        /// <summary>
        /// Gets or sets SegmentOrderOftheSelectedAccount
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SegmentOrderOftheSelectedAccount, Id = Index.SegmentOrderOftheSelectedAccount, FieldType = EntityFieldType.Char, Size = 20)]
        public string SegmentOrderOftheSelectedAccount { get; set; }

        /// <summary>
        /// Gets or sets SegmentOrderOftheCreatedAccount
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SegmentOrderOftheCreatedAccount, Id = Index.SegmentOrderOftheCreatedAccount, FieldType = EntityFieldType.Char, Size = 20)]
        public string SegmentOrderOftheCreatedAccount { get; set; }

        /// <summary>
        /// Gets or sets ProcessOption
        /// </summary>
        [ViewField(Name = Fields.ProcessOption, Id = Index.ProcessOption, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProcessOption { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment1 { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment2 { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment3 { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment4 { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment5 { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment6 { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment7 { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment8 { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment9 { get; set; }

        /// <summary>
        /// Gets or Sets Segment1
        /// </summary>
        /// <value>The segment1.</value>
        public string Segment10 { get; set; }

         /// <summary>
        /// Gets or Sets CreateStructureList
        /// </summary>
        /// <value>The segment1.</value>
        public  List<string> CreateStructureList  { get; set; }

        /// <summary>
        /// Gets or Sets CreateStructureList
        /// </summary>
        /// <value>The segment1.</value>
        public int ProcessType { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets DefaultSubledgerDetails string value
        /// </summary>
        public string DefaultSubledgerDetailsString
        {
            get { return EnumUtility.GetStringValue(DefaultSubledgerDetails); }
        }

        /// <summary>
        /// Gets DefaultCurrencyOptions string value
        /// </summary>
        public string DefaultCurrencyOptionsString
        {
            get { return EnumUtility.GetStringValue(DefaultCurrencyOptions); }
        }

        /// <summary>
        /// Gets GenerateExistingAccount string value
        /// </summary>
        public string GenerateExistingAccountString
        {
            get { return EnumUtility.GetStringValue(GenerateExistingAccount); }
        }

        /// <summary>
        /// Gets CreateNewForSegment1 string value
        /// </summary>
        public string CreateNewForSegment1String
        {
            get { return EnumUtility.GetStringValue(CreateNewForSegment1); }
        }

        /// <summary>
        /// Gets CreateNewForSegment2 string value
        /// </summary>
        public string CreateNewForSegment2String
        {
            get { return EnumUtility.GetStringValue(CreateNewForSegment2); }
        }

        /// <summary>
        /// Gets CreateNewForSegment3 string value
        /// </summary>
        public string CreateNewForSegment3String
        {
            get { return EnumUtility.GetStringValue(CreateNewForSegment3); }
        }

        /// <summary>
        /// Gets CreateNewForSegment4 string value
        /// </summary>
        public string CreateNewForSegment4String
        {
            get { return EnumUtility.GetStringValue(CreateNewForSegment4); }
        }

        /// <summary>
        /// Gets CreateNewForSegment5 string value
        /// </summary>
        public string CreateNewForSegment5String
        {
            get { return EnumUtility.GetStringValue(CreateNewForSegment5); }
        }

        /// <summary>
        /// Gets CreateNewForSegment6 string value
        /// </summary>
        public string CreateNewForSegment6String
        {
            get { return EnumUtility.GetStringValue(CreateNewForSegment6); }
        }

        /// <summary>
        /// Gets CreateNewForSegment7 string value
        /// </summary>
        public string CreateNewForSegment7String
        {
            get { return EnumUtility.GetStringValue(CreateNewForSegment7); }
        }

        /// <summary>
        /// Gets CreateNewForSegment8 string value
        /// </summary>
        public string CreateNewForSegment8String
        {
            get { return EnumUtility.GetStringValue(CreateNewForSegment8); }
        }

        /// <summary>
        /// Gets CreateNewForSegment9 string value
        /// </summary>
        public string CreateNewForSegment9String
        {
            get { return EnumUtility.GetStringValue(CreateNewForSegment9); }
        }

        /// <summary>
        /// Gets CreateNewForSegment10 string value
        /// </summary>
        public string CreateNewForSegment10String
        {
            get { return EnumUtility.GetStringValue(CreateNewForSegment10); }
        }

        #endregion
    }
}
