// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.GL.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Partial class for FinancialReportInformation
    /// </summary>
    public partial class FinancialReportInformation : ModelBase
    {
        /// <summary>
        /// Gets or sets AccountNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountNumber", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets ReportingYear
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReportingYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.ReportingYear, Id = Index.ReportingYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string ReportingYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalSetDesignator
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalSetDesignator", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.FiscalSetDesignator, Id = Index.FiscalSetDesignator, FieldType = EntityFieldType.Char, Size = 1)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process.FiscalSetDesignator FiscalSetDesignator { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyType
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyType", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.CurrencyType, Id = Index.CurrencyType, FieldType = EntityFieldType.Char, Size = 1)]
        public Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process.CurrencyType CurrencyType { get; set; }

        /// <summary>
        /// Gets or sets FiscalSetType
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalSetType", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.FiscalSetType, Id = Index.FiscalSetType, FieldType = EntityFieldType.Char, Size = 1)]
        public string FiscalSetType { get; set; }

        /// <summary>
        /// Gets or sets ReportingYearOffset
        /// </summary>
        [Display(Name = "ReportingYearOffset", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.ReportingYearOffset, Id = Index.ReportingYearOffset, FieldType = EntityFieldType.Int, Size = 2)]
        public short ReportingYearOffset { get; set; }

        /// <summary>
        /// Gets or sets ReportingPeriod
        /// </summary>
        [Display(Name = "ReportingPeriod", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.ReportingPeriod, Id = Index.ReportingPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public short ReportingPeriod { get; set; }

        /// <summary>
        /// Gets or sets BalanceCurrentPeriod
        /// </summary>
        [Display(Name = "BalanceCurrentPeriod", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceCurrentPeriod, Id = Index.BalanceCurrentPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceCurrentPeriod { get; set; }

        /// <summary>
        /// Gets or sets BalanceLastPeriod
        /// </summary>
        [Display(Name = "BalanceLastPeriod", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceLastPeriod, Id = Index.BalanceLastPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceLastPeriod { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod1
        /// </summary>
        [Display(Name = "BalancePeriod1", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod1, Id = Index.BalancePeriod1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod1 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod2
        /// </summary>
        [Display(Name = "BalancePeriod2", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod2, Id = Index.BalancePeriod2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod2 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod3
        /// </summary>
        [Display(Name = "BalancePeriod3", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod3, Id = Index.BalancePeriod3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod3 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod4
        /// </summary>
        [Display(Name = "BalancePeriod4", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod4, Id = Index.BalancePeriod4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod4 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod5
        /// </summary>
        [Display(Name = "BalancePeriod5", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod5, Id = Index.BalancePeriod5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod5 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod6
        /// </summary>
        [Display(Name = "BalancePeriod6", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod6, Id = Index.BalancePeriod6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod6 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod7
        /// </summary>
        [Display(Name = "BalancePeriod7", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod7, Id = Index.BalancePeriod7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod7 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod8
        /// </summary>
        [Display(Name = "BalancePeriod8", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod8, Id = Index.BalancePeriod8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod8 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod9
        /// </summary>
        [Display(Name = "BalancePeriod9", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod9, Id = Index.BalancePeriod9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod9 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod10
        /// </summary>
        [Display(Name = "BalancePeriod10", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod10, Id = Index.BalancePeriod10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod10 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod11
        /// </summary>
        [Display(Name = "BalancePeriod11", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod11, Id = Index.BalancePeriod11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod11 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod12
        /// </summary>
        [Display(Name = "BalancePeriod12", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod12, Id = Index.BalancePeriod12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod12 { get; set; }

        /// <summary>
        /// Gets or sets BalancePeriod13
        /// </summary>
        [Display(Name = "BalancePeriod13", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalancePeriod13, Id = Index.BalancePeriod13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalancePeriod13 { get; set; }

        /// <summary>
        /// Gets or sets Balance1PeriodAgo
        /// </summary>
        [Display(Name = "Balance1PeriodAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance1PeriodAgo, Id = Index.Balance1PeriodAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance1PeriodAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance2PeriodsAgo
        /// </summary>
        [Display(Name = "Balance2PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance2PeriodsAgo, Id = Index.Balance2PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance2PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance3PeriodsAgo
        /// </summary>
        [Display(Name = "Balance3PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance3PeriodsAgo, Id = Index.Balance3PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance3PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance4PeriodsAgo
        /// </summary>
        [Display(Name = "Balance4PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance4PeriodsAgo, Id = Index.Balance4PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance4PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance5PeriodsAgo
        /// </summary>
        [Display(Name = "Balance5PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance5PeriodsAgo, Id = Index.Balance5PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance5PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance6PeriodsAgo
        /// </summary>
        [Display(Name = "Balance6PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance6PeriodsAgo, Id = Index.Balance6PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance6PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance7PeriodsAgo
        /// </summary>
        [Display(Name = "Balance7PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance7PeriodsAgo, Id = Index.Balance7PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance7PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance8PeriodsAgo
        /// </summary>
        [Display(Name = "Balance8PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance8PeriodsAgo, Id = Index.Balance8PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance8PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance9PeriodsAgo
        /// </summary>
        [Display(Name = "Balance9PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance9PeriodsAgo, Id = Index.Balance9PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance9PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance10PeriodsAgo
        /// </summary>
        [Display(Name = "Balance10PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance10PeriodsAgo, Id = Index.Balance10PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance10PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance11PeriodsAgo
        /// </summary>
        [Display(Name = "Balance11PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance11PeriodsAgo, Id = Index.Balance11PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance11PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance12PeriodsAgo
        /// </summary>
        [Display(Name = "Balance12PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance12PeriodsAgo, Id = Index.Balance12PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance12PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance13PeriodsAgo
        /// </summary>
        [Display(Name = "Balance13PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance13PeriodsAgo, Id = Index.Balance13PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance13PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets BalanceCurrentQuarter
        /// </summary>
        [Display(Name = "BalanceCurrentQuarter", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceCurrentQuarter, Id = Index.BalanceCurrentQuarter, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceCurrentQuarter { get; set; }

        /// <summary>
        /// Gets or sets BalanceLastQuarter
        /// </summary>
        [Display(Name = "BalanceLastQuarter", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceLastQuarter, Id = Index.BalanceLastQuarter, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceLastQuarter { get; set; }

        /// <summary>
        /// Gets or sets BalanceQuarter1
        /// </summary>
        [Display(Name = "BalanceQuarter1", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceQuarter1, Id = Index.BalanceQuarter1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceQuarter1 { get; set; }

        /// <summary>
        /// Gets or sets BalanceQuarter2
        /// </summary>
        [Display(Name = "BalanceQuarter2", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceQuarter2, Id = Index.BalanceQuarter2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceQuarter2 { get; set; }

        /// <summary>
        /// Gets or sets BalanceQuarter3
        /// </summary>
        [Display(Name = "BalanceQuarter3", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceQuarter3, Id = Index.BalanceQuarter3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceQuarter3 { get; set; }

        /// <summary>
        /// Gets or sets BalanceQuarter4
        /// </summary>
        [Display(Name = "BalanceQuarter4", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceQuarter4, Id = Index.BalanceQuarter4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceQuarter4 { get; set; }

        /// <summary>
        /// Gets or sets BalanceQuarter1ToDate
        /// </summary>
        [Display(Name = "BalanceQuarter1ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceQuarter1ToDate, Id = Index.BalanceQuarter1ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceQuarter1ToDate { get; set; }

        /// <summary>
        /// Gets or sets BalanceQuarter2ToDate
        /// </summary>
        [Display(Name = "BalanceQuarter2ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceQuarter2ToDate, Id = Index.BalanceQuarter2ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceQuarter2ToDate { get; set; }

        /// <summary>
        /// Gets or sets BalanceQuarter3ToDate
        /// </summary>
        [Display(Name = "BalanceQuarter3ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceQuarter3ToDate, Id = Index.BalanceQuarter3ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceQuarter3ToDate { get; set; }

        /// <summary>
        /// Gets or sets BalanceQuarter4ToDate
        /// </summary>
        [Display(Name = "BalanceQuarter4ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceQuarter4ToDate, Id = Index.BalanceQuarter4ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceQuarter4ToDate { get; set; }

        /// <summary>
        /// Gets or sets Balance1QuarterAgo
        /// </summary>
        [Display(Name = "Balance1QuarterAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance1QuarterAgo, Id = Index.Balance1QuarterAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance1QuarterAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance2QuartersAgo
        /// </summary>
        [Display(Name = "Balance2QuartersAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance2QuartersAgo, Id = Index.Balance2QuartersAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance2QuartersAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance3QuartersAgo
        /// </summary>
        [Display(Name = "Balance3QuartersAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance3QuartersAgo, Id = Index.Balance3QuartersAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance3QuartersAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance4QuartersAgo
        /// </summary>
        [Display(Name = "Balance4QuartersAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance4QuartersAgo, Id = Index.Balance4QuartersAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance4QuartersAgo { get; set; }

        /// <summary>
        /// Gets or sets BalanceCurrentHalfYear
        /// </summary>
        [Display(Name = "BalanceCurrentHalfYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceCurrentHalfYear, Id = Index.BalanceCurrentHalfYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceCurrentHalfYear { get; set; }

        /// <summary>
        /// Gets or sets BalanceLastHalfYear
        /// </summary>
        [Display(Name = "BalanceLastHalfYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceLastHalfYear, Id = Index.BalanceLastHalfYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceLastHalfYear { get; set; }

        /// <summary>
        /// Gets or sets BalanceHalfYear1
        /// </summary>
        [Display(Name = "BalanceHalfYear1", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceHalfYear1, Id = Index.BalanceHalfYear1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceHalfYear1 { get; set; }

        /// <summary>
        /// Gets or sets BalanceHalfYear2
        /// </summary>
        [Display(Name = "BalanceHalfYear2", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceHalfYear2, Id = Index.BalanceHalfYear2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceHalfYear2 { get; set; }

        /// <summary>
        /// Gets or sets BalanceHalfYear1ToDate
        /// </summary>
        [Display(Name = "BalanceHalfYear1ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceHalfYear1ToDate, Id = Index.BalanceHalfYear1ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceHalfYear1ToDate { get; set; }

        /// <summary>
        /// Gets or sets BalanceHalfYear2ToDate
        /// </summary>
        [Display(Name = "BalanceHalfYear2ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceHalfYear2ToDate, Id = Index.BalanceHalfYear2ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceHalfYear2ToDate { get; set; }

        /// <summary>
        /// Gets or sets Balance1HalfYearAgo
        /// </summary>
        [Display(Name = "Balance1HalfYearAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance1HalfYearAgo, Id = Index.Balance1HalfYearAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance1HalfYearAgo { get; set; }

        /// <summary>
        /// Gets or sets Balance2HalfYearsAgo
        /// </summary>
        [Display(Name = "Balance2HalfYearsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance2HalfYearsAgo, Id = Index.Balance2HalfYearsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance2HalfYearsAgo { get; set; }

        /// <summary>
        /// Gets or sets BalanceTotalYear
        /// </summary>
        [Display(Name = "BalanceTotalYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceTotalYear, Id = Index.BalanceTotalYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceTotalYear { get; set; }

        /// <summary>
        /// Gets or sets BalanceYearToDate
        /// </summary>
        [Display(Name = "BalanceYearToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceYearToDate, Id = Index.BalanceYearToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceYearToDate { get; set; }

        /// <summary>
        /// Gets or sets BalanceBeginningOfYear
        /// </summary>
        [Display(Name = "BalanceBeginningOfYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceBeginningOfYear, Id = Index.BalanceBeginningOfYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceBeginningOfYear { get; set; }

        /// <summary>
        /// Gets or sets NetCurrentPeriod
        /// </summary>
        [Display(Name = "NetCurrentPeriod", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetCurrentPeriod, Id = Index.NetCurrentPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetCurrentPeriod { get; set; }

        /// <summary>
        /// Gets or sets NetLastPeriod
        /// </summary>
        [Display(Name = "NetLastPeriod", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetLastPeriod, Id = Index.NetLastPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetLastPeriod { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod1
        /// </summary>
        [Display(Name = "NetPeriod1", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod1, Id = Index.NetPeriod1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod1 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod2
        /// </summary>
        [Display(Name = "NetPeriod2", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod2, Id = Index.NetPeriod2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod3
        /// </summary>
        [Display(Name = "NetPeriod3", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod3, Id = Index.NetPeriod3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod4
        /// </summary>
        [Display(Name = "NetPeriod4", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod4, Id = Index.NetPeriod4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod4 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod5
        /// </summary>
        [Display(Name = "NetPeriod5", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod5, Id = Index.NetPeriod5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod5 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod6
        /// </summary>
        [Display(Name = "NetPeriod6", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod6, Id = Index.NetPeriod6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod6 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod7
        /// </summary>
        [Display(Name = "NetPeriod7", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod7, Id = Index.NetPeriod7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod7 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod8
        /// </summary>
        [Display(Name = "NetPeriod8", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod8, Id = Index.NetPeriod8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod8 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod9
        /// </summary>
        [Display(Name = "NetPeriod9", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod9, Id = Index.NetPeriod9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod9 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod10
        /// </summary>
        [Display(Name = "NetPeriod10", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod10, Id = Index.NetPeriod10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod10 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod11
        /// </summary>
        [Display(Name = "NetPeriod11", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod11, Id = Index.NetPeriod11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod11 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod12
        /// </summary>
        [Display(Name = "NetPeriod12", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod12, Id = Index.NetPeriod12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod12 { get; set; }

        /// <summary>
        /// Gets or sets NetPeriod13
        /// </summary>
        [Display(Name = "NetPeriod13", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPeriod13, Id = Index.NetPeriod13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPeriod13 { get; set; }

        /// <summary>
        /// Gets or sets Net1PeriodAgo
        /// </summary>
        [Display(Name = "Net1PeriodAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net1PeriodAgo, Id = Index.Net1PeriodAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net1PeriodAgo { get; set; }

        /// <summary>
        /// Gets or sets Net2PeriodsAgo
        /// </summary>
        [Display(Name = "Net2PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net2PeriodsAgo, Id = Index.Net2PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net2PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net3PeriodsAgo
        /// </summary>
        [Display(Name = "Net3PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net3PeriodsAgo, Id = Index.Net3PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net3PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net4PeriodsAgo
        /// </summary>
        [Display(Name = "Net4PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net4PeriodsAgo, Id = Index.Net4PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net4PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net5PeriodsAgo
        /// </summary>
        [Display(Name = "Net5PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net5PeriodsAgo, Id = Index.Net5PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net5PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net6PeriodsAgo
        /// </summary>
        [Display(Name = "Net6PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net6PeriodsAgo, Id = Index.Net6PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net6PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net7PeriodsAgo
        /// </summary>
        [Display(Name = "Net7PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net7PeriodsAgo, Id = Index.Net7PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net7PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net8PeriodsAgo
        /// </summary>
        [Display(Name = "Net8PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net8PeriodsAgo, Id = Index.Net8PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net8PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net9PeriodsAgo
        /// </summary>
        [Display(Name = "Net9PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net9PeriodsAgo, Id = Index.Net9PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net9PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net10PeriodsAgo
        /// </summary>
        [Display(Name = "Net10PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net10PeriodsAgo, Id = Index.Net10PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net10PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net11PeriodsAgo
        /// </summary>
        [Display(Name = "Net11PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net11PeriodsAgo, Id = Index.Net11PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net11PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net12PeriodsAgo
        /// </summary>
        [Display(Name = "Net12PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net12PeriodsAgo, Id = Index.Net12PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net12PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets Net13PeriodsAgo
        /// </summary>
        [Display(Name = "Net13PeriodsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net13PeriodsAgo, Id = Index.Net13PeriodsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net13PeriodsAgo { get; set; }

        /// <summary>
        /// Gets or sets NetCurrentQuarter
        /// </summary>
        [Display(Name = "NetCurrentQuarter", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetCurrentQuarter, Id = Index.NetCurrentQuarter, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetCurrentQuarter { get; set; }

        /// <summary>
        /// Gets or sets NetLastQuarter
        /// </summary>
        [Display(Name = "NetLastQuarter", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetLastQuarter, Id = Index.NetLastQuarter, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetLastQuarter { get; set; }

        /// <summary>
        /// Gets or sets NetQuarter1
        /// </summary>
        [Display(Name = "NetQuarter1", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetQuarter1, Id = Index.NetQuarter1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetQuarter1 { get; set; }

        /// <summary>
        /// Gets or sets NetQuarter2
        /// </summary>
        [Display(Name = "NetQuarter2", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetQuarter2, Id = Index.NetQuarter2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetQuarter2 { get; set; }

        /// <summary>
        /// Gets or sets NetQuarter3
        /// </summary>
        [Display(Name = "NetQuarter3", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetQuarter3, Id = Index.NetQuarter3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetQuarter3 { get; set; }

        /// <summary>
        /// Gets or sets NetQuarter4
        /// </summary>
        [Display(Name = "NetQuarter4", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetQuarter4, Id = Index.NetQuarter4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetQuarter4 { get; set; }

        /// <summary>
        /// Gets or sets NetQuarter1ToDate
        /// </summary>
        [Display(Name = "NetQuarter1ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetQuarter1ToDate, Id = Index.NetQuarter1ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetQuarter1ToDate { get; set; }

        /// <summary>
        /// Gets or sets NetQuarter2ToDate
        /// </summary>
        [Display(Name = "NetQuarter2ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetQuarter2ToDate, Id = Index.NetQuarter2ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetQuarter2ToDate { get; set; }

        /// <summary>
        /// Gets or sets NetQuarter3ToDate
        /// </summary>
        [Display(Name = "NetQuarter3ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetQuarter3ToDate, Id = Index.NetQuarter3ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetQuarter3ToDate { get; set; }

        /// <summary>
        /// Gets or sets NetQuarter4ToDate
        /// </summary>
        [Display(Name = "NetQuarter4ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetQuarter4ToDate, Id = Index.NetQuarter4ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetQuarter4ToDate { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter
        /// </summary>
        [Display(Name = "NetPreceedingQuarter", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter, Id = Index.NetPreceedingQuarter, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter1PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter1PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter1PAgo, Id = Index.NetPreceedingQuarter1PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter1PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter2PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter2PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter2PAgo, Id = Index.NetPreceedingQuarter2PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter2PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter3PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter3PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter3PAgo, Id = Index.NetPreceedingQuarter3PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter3PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter4PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter4PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter4PAgo, Id = Index.NetPreceedingQuarter4PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter4PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter5PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter5PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter5PAgo, Id = Index.NetPreceedingQuarter5PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter5PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter6PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter6PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter6PAgo, Id = Index.NetPreceedingQuarter6PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter6PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter7PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter7PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter7PAgo, Id = Index.NetPreceedingQuarter7PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter7PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter8PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter8PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter8PAgo, Id = Index.NetPreceedingQuarter8PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter8PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter9PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter9PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter9PAgo, Id = Index.NetPreceedingQuarter9PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter9PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter10PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter10PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter10PAgo, Id = Index.NetPreceedingQuarter10PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter10PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter11PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter11PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter11PAgo, Id = Index.NetPreceedingQuarter11PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter11PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter12PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter12PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter12PAgo, Id = Index.NetPreceedingQuarter12PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter12PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingQuarter13PAgo
        /// </summary>
        [Display(Name = "NetPreceedingQuarter13PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingQuarter13PAgo, Id = Index.NetPreceedingQuarter13PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingQuarter13PAgo { get; set; }

        /// <summary>
        /// Gets or sets Net1QuarterAgo
        /// </summary>
        [Display(Name = "Net1QuarterAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net1QuarterAgo, Id = Index.Net1QuarterAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net1QuarterAgo { get; set; }

        /// <summary>
        /// Gets or sets Net2QuartersAgo
        /// </summary>
        [Display(Name = "Net2QuartersAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net2QuartersAgo, Id = Index.Net2QuartersAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net2QuartersAgo { get; set; }

        /// <summary>
        /// Gets or sets Net3QuartersAgo
        /// </summary>
        [Display(Name = "Net3QuartersAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net3QuartersAgo, Id = Index.Net3QuartersAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net3QuartersAgo { get; set; }

        /// <summary>
        /// Gets or sets Net4QuartersAgo
        /// </summary>
        [Display(Name = "Net4QuartersAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net4QuartersAgo, Id = Index.Net4QuartersAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net4QuartersAgo { get; set; }

        /// <summary>
        /// Gets or sets NetCurrentHalfYear
        /// </summary>
        [Display(Name = "NetCurrentHalfYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetCurrentHalfYear, Id = Index.NetCurrentHalfYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetCurrentHalfYear { get; set; }

        /// <summary>
        /// Gets or sets NetLastHalfYear
        /// </summary>
        [Display(Name = "NetLastHalfYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetLastHalfYear, Id = Index.NetLastHalfYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetLastHalfYear { get; set; }

        /// <summary>
        /// Gets or sets NetHalfYear1
        /// </summary>
        [Display(Name = "NetHalfYear1", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetHalfYear1, Id = Index.NetHalfYear1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetHalfYear1 { get; set; }

        /// <summary>
        /// Gets or sets NetHalfYear2
        /// </summary>
        [Display(Name = "NetHalfYear2", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetHalfYear2, Id = Index.NetHalfYear2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetHalfYear2 { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear, Id = Index.NetPreceedingHalfYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear { get; set; }

        /// <summary>
        /// Gets or sets NetHalfYear1ToDate
        /// </summary>
        [Display(Name = "NetHalfYear1ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetHalfYear1ToDate, Id = Index.NetHalfYear1ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetHalfYear1ToDate { get; set; }

        /// <summary>
        /// Gets or sets NetHalfYear2ToDate
        /// </summary>
        [Display(Name = "NetHalfYear2ToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetHalfYear2ToDate, Id = Index.NetHalfYear2ToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetHalfYear2ToDate { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear1PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear1PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear1PAgo, Id = Index.NetPreceedingHalfYear1PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear1PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear2PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear2PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear2PAgo, Id = Index.NetPreceedingHalfYear2PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear2PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear3PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear3PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear3PAgo, Id = Index.NetPreceedingHalfYear3PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear3PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear4PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear4PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear4PAgo, Id = Index.NetPreceedingHalfYear4PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear4PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear5PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear5PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear5PAgo, Id = Index.NetPreceedingHalfYear5PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear5PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear6PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear6PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear6PAgo, Id = Index.NetPreceedingHalfYear6PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear6PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear7PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear7PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear7PAgo, Id = Index.NetPreceedingHalfYear7PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear7PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear8PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear8PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear8PAgo, Id = Index.NetPreceedingHalfYear8PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear8PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear9PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear9PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear9PAgo, Id = Index.NetPreceedingHalfYear9PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear9PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear10PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear10PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear10PAgo, Id = Index.NetPreceedingHalfYear10PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear10PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear11PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear11PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear11PAgo, Id = Index.NetPreceedingHalfYear11PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear11PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear12PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear12PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear12PAgo, Id = Index.NetPreceedingHalfYear12PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear12PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingHalfYear13PAgo
        /// </summary>
        [Display(Name = "NetPreceedingHalfYear13PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingHalfYear13PAgo, Id = Index.NetPreceedingHalfYear13PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingHalfYear13PAgo { get; set; }

        /// <summary>
        /// Gets or sets Net1HalfYearAgo
        /// </summary>
        [Display(Name = "Net1HalfYearAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net1HalfYearAgo, Id = Index.Net1HalfYearAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net1HalfYearAgo { get; set; }

        /// <summary>
        /// Gets or sets Net2HalfYearsAgo
        /// </summary>
        [Display(Name = "Net2HalfYearsAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net2HalfYearsAgo, Id = Index.Net2HalfYearsAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net2HalfYearsAgo { get; set; }

        /// <summary>
        /// Gets or sets NetTotalYear
        /// </summary>
        [Display(Name = "NetTotalYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetTotalYear, Id = Index.NetTotalYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetTotalYear { get; set; }

        /// <summary>
        /// Gets or sets NetYearToDate
        /// </summary>
        [Display(Name = "NetYearToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetYearToDate, Id = Index.NetYearToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetYearToDate { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear
        /// </summary>
        [Display(Name = "NetPreceedingYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear, Id = Index.NetPreceedingYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear1PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear1PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear1PAgo, Id = Index.NetPreceedingYear1PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear1PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear2PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear2PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear2PAgo, Id = Index.NetPreceedingYear2PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear2PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear3PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear3PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear3PAgo, Id = Index.NetPreceedingYear3PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear3PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear4PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear4PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear4PAgo, Id = Index.NetPreceedingYear4PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear4PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear5PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear5PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear5PAgo, Id = Index.NetPreceedingYear5PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear5PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear6PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear6PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear6PAgo, Id = Index.NetPreceedingYear6PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear6PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear7PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear7PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear7PAgo, Id = Index.NetPreceedingYear7PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear7PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear8PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear8PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear8PAgo, Id = Index.NetPreceedingYear8PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear8PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear9PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear9PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear9PAgo, Id = Index.NetPreceedingYear9PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear9PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear10PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear10PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear10PAgo, Id = Index.NetPreceedingYear10PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear10PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear11PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear11PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear11PAgo, Id = Index.NetPreceedingYear11PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear11PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear12PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear12PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear12PAgo, Id = Index.NetPreceedingYear12PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear12PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetPreceedingYear13PAgo
        /// </summary>
        [Display(Name = "NetPreceedingYear13PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetPreceedingYear13PAgo, Id = Index.NetPreceedingYear13PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPreceedingYear13PAgo { get; set; }

        /// <summary>
        /// Gets or sets NetAdjustments
        /// </summary>
        [Display(Name = "NetAdjustments", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetAdjustments, Id = Index.NetAdjustments, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetAdjustments { get; set; }

        /// <summary>
        /// Gets or sets ClosingBalance
        /// </summary>
        [Display(Name = "ClosingBalance", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.ClosingBalance, Id = Index.ClosingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ClosingBalance { get; set; }

        /// <summary>
        /// Gets or sets NetClosingAmount
        /// </summary>
        [Display(Name = "NetClosingAmount", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetClosingAmount, Id = Index.NetClosingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetClosingAmount { get; set; }

        /// <summary>
        /// Gets or sets BalanceQuarterToDate
        /// </summary>
        [Display(Name = "BalanceQuarterToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceQuarterToDate, Id = Index.BalanceQuarterToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceQuarterToDate { get; set; }

        /// <summary>
        /// Gets or sets BalanceLastQuarterToDate
        /// </summary>
        [Display(Name = "BalanceLastQuarterToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceLastQuarterToDate, Id = Index.BalanceLastQuarterToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceLastQuarterToDate { get; set; }

        /// <summary>
        /// Gets or sets Balance1QuarterAgoToDate
        /// </summary>
        [Display(Name = "Balance1QuarterAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance1QuarterAgoToDate, Id = Index.Balance1QuarterAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance1QuarterAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets Balance2QuartersAgoToDate
        /// </summary>
        [Display(Name = "Balance2QuartersAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance2QuartersAgoToDate, Id = Index.Balance2QuartersAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance2QuartersAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets Balance3QuartersAgoToDate
        /// </summary>
        [Display(Name = "Balance3QuartersAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance3QuartersAgoToDate, Id = Index.Balance3QuartersAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance3QuartersAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets Balance4QuartersAgoToDate
        /// </summary>
        [Display(Name = "Balance4QuartersAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance4QuartersAgoToDate, Id = Index.Balance4QuartersAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance4QuartersAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets BalanceHalfYearToDate
        /// </summary>
        [Display(Name = "BalanceHalfYearToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceHalfYearToDate, Id = Index.BalanceHalfYearToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceHalfYearToDate { get; set; }

        /// <summary>
        /// Gets or sets BalanceLastHalfYearToDate
        /// </summary>
        [Display(Name = "BalanceLastHalfYearToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalanceLastHalfYearToDate, Id = Index.BalanceLastHalfYearToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceLastHalfYearToDate { get; set; }

        /// <summary>
        /// Gets or sets Balance1HalfYearAgoToDate
        /// </summary>
        [Display(Name = "Balance1HalfYearAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance1HalfYearAgoToDate, Id = Index.Balance1HalfYearAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance1HalfYearAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets Balance2HalfYearsAgoToDate
        /// </summary>
        [Display(Name = "Balance2HalfYearsAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Balance2HalfYearsAgoToDate, Id = Index.Balance2HalfYearsAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance2HalfYearsAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets NetQuarterToDate
        /// </summary>
        [Display(Name = "NetQuarterToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetQuarterToDate, Id = Index.NetQuarterToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetQuarterToDate { get; set; }

        /// <summary>
        /// Gets or sets NetLastQuarterToDate
        /// </summary>
        [Display(Name = "NetLastQuarterToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetLastQuarterToDate, Id = Index.NetLastQuarterToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetLastQuarterToDate { get; set; }

        /// <summary>
        /// Gets or sets Net1QuarterAgoToDate
        /// </summary>
        [Display(Name = "Net1QuarterAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net1QuarterAgoToDate, Id = Index.Net1QuarterAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net1QuarterAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets Net2QuartersAgoToDate
        /// </summary>
        [Display(Name = "Net2QuartersAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net2QuartersAgoToDate, Id = Index.Net2QuartersAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net2QuartersAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets Net3QuartersAgoToDate
        /// </summary>
        [Display(Name = "Net3QuartersAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net3QuartersAgoToDate, Id = Index.Net3QuartersAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net3QuartersAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets Net4QuartersAgoToDate
        /// </summary>
        [Display(Name = "Net4QuartersAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net4QuartersAgoToDate, Id = Index.Net4QuartersAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net4QuartersAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets NetHalfYearToDate
        /// </summary>
        [Display(Name = "NetHalfYearToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetHalfYearToDate, Id = Index.NetHalfYearToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetHalfYearToDate { get; set; }

        /// <summary>
        /// Gets or sets NetLastHalfYearToDate
        /// </summary>
        [Display(Name = "NetLastHalfYearToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.NetLastHalfYearToDate, Id = Index.NetLastHalfYearToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetLastHalfYearToDate { get; set; }

        /// <summary>
        /// Gets or sets Net1HalfYearAgoToDate
        /// </summary>
        [Display(Name = "Net1HalfYearAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net1HalfYearAgoToDate, Id = Index.Net1HalfYearAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net1HalfYearAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets Net2HalfYearsAgoToDate
        /// </summary>
        [Display(Name = "Net2HalfYearsAgoToDate", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.Net2HalfYearsAgoToDate, Id = Index.Net2HalfYearsAgoToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Net2HalfYearsAgoToDate { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter
        /// </summary>
        [Display(Name = "BalPreceedingQuarter", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter, Id = Index.BalPreceedingQuarter, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter1PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter1PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter1PAgo, Id = Index.BalPreceedingQuarter1PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter1PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter2PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter2PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter2PAgo, Id = Index.BalPreceedingQuarter2PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter2PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter3PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter3PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter3PAgo, Id = Index.BalPreceedingQuarter3PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter3PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter4PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter4PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter4PAgo, Id = Index.BalPreceedingQuarter4PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter4PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter5PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter5PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter5PAgo, Id = Index.BalPreceedingQuarter5PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter5PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter6PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter6PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter6PAgo, Id = Index.BalPreceedingQuarter6PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter6PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter7PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter7PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter7PAgo, Id = Index.BalPreceedingQuarter7PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter7PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter8PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter8PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter8PAgo, Id = Index.BalPreceedingQuarter8PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter8PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter9PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter9PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter9PAgo, Id = Index.BalPreceedingQuarter9PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter9PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter10PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter10PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter10PAgo, Id = Index.BalPreceedingQuarter10PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter10PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter11PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter11PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter11PAgo, Id = Index.BalPreceedingQuarter11PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter11PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter12PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter12PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter12PAgo, Id = Index.BalPreceedingQuarter12PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter12PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingQuarter13PAgo
        /// </summary>
        [Display(Name = "BalPreceedingQuarter13PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingQuarter13PAgo, Id = Index.BalPreceedingQuarter13PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingQuarter13PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear, Id = Index.BalPreceedingHalfYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear1PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear1PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear1PAgo, Id = Index.BalPreceedingHalfYear1PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear1PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear2PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear2PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear2PAgo, Id = Index.BalPreceedingHalfYear2PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear2PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear3PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear3PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear3PAgo, Id = Index.BalPreceedingHalfYear3PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear3PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear4PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear4PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear4PAgo, Id = Index.BalPreceedingHalfYear4PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear4PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear5PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear5PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear5PAgo, Id = Index.BalPreceedingHalfYear5PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear5PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear6PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear6PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear6PAgo, Id = Index.BalPreceedingHalfYear6PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear6PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear7PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear7PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear7PAgo, Id = Index.BalPreceedingHalfYear7PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear7PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear8PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear8PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear8PAgo, Id = Index.BalPreceedingHalfYear8PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear8PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear9PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear9PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear9PAgo, Id = Index.BalPreceedingHalfYear9PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear9PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear10PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear10PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear10PAgo, Id = Index.BalPreceedingHalfYear10PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear10PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear11PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear11PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear11PAgo, Id = Index.BalPreceedingHalfYear11PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear11PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear12PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear12PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear12PAgo, Id = Index.BalPreceedingHalfYear12PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear12PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingHalfYear13PAgo
        /// </summary>
        [Display(Name = "BalPreceedingHalfYear13PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingHalfYear13PAgo, Id = Index.BalPreceedingHalfYear13PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingHalfYear13PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear
        /// </summary>
        [Display(Name = "BalPreceedingYear", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear, Id = Index.BalPreceedingYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear1PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear1PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear1PAgo, Id = Index.BalPreceedingYear1PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear1PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear2PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear2PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear2PAgo, Id = Index.BalPreceedingYear2PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear2PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear3PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear3PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear3PAgo, Id = Index.BalPreceedingYear3PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear3PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear4PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear4PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear4PAgo, Id = Index.BalPreceedingYear4PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear4PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear5PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear5PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear5PAgo, Id = Index.BalPreceedingYear5PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear5PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear6PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear6PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear6PAgo, Id = Index.BalPreceedingYear6PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear6PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear7PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear7PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear7PAgo, Id = Index.BalPreceedingYear7PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear7PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear8PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear8PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear8PAgo, Id = Index.BalPreceedingYear8PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear8PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear9PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear9PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear9PAgo, Id = Index.BalPreceedingYear9PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear9PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear10PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear10PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear10PAgo, Id = Index.BalPreceedingYear10PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear10PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear11PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear11PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear11PAgo, Id = Index.BalPreceedingYear11PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear11PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear12PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear12PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear12PAgo, Id = Index.BalPreceedingYear12PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear12PAgo { get; set; }

        /// <summary>
        /// Gets or sets BalPreceedingYear13PAgo
        /// </summary>
        [Display(Name = "BalPreceedingYear13PAgo", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BalPreceedingYear13PAgo, Id = Index.BalPreceedingYear13PAgo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalPreceedingYear13PAgo { get; set; }

        /// <summary>
        /// Gets or sets BudgetOpeningBalanceSwitch
        /// </summary>
        [Display(Name = "BudgetOpeningBalanceSwitch", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.BudgetOpeningBalanceSwitch, Id = Index.BudgetOpeningBalanceSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public short BudgetOpeningBalanceSwitch { get; set; }

        /// <summary>
        /// Gets or sets QuantityOpeningBalanceSwitch
        /// </summary>
        [Display(Name = "QuantityOpeningBalanceSwitch", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.QuantityOpeningBalanceSwitch, Id = Index.QuantityOpeningBalanceSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public short QuantityOpeningBalanceSwitch { get; set; }

        /// <summary>
        /// Gets or sets AdditionalFRTRNFilter
        /// </summary>
        [StringLength(1024, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdditionalFRTRNFilter", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.AdditionalFRTRNFilter, Id = Index.AdditionalFRTRNFilter, FieldType = EntityFieldType.Char, Size = 1024)]
        public string AdditionalFRTRNFilter { get; set; }

        /// <summary>
        /// Gets or sets TableGLPOSTSwitch
        /// </summary>
        [Display(Name = "TableGLPOSTSwitch", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.TableGLPOSTSwitch, Id = Index.TableGLPOSTSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public short TableGLPOSTSwitch { get; set; }

        /// <summary>
        /// Gets or sets FRTRNSwitch
        /// </summary>
        [Display(Name = "FRTRNSwitch", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.FRTRNSwitch, Id = Index.FRTRNSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public short FRTRNSwitch { get; set; }

        /// <summary>
        /// Gets or sets AccountBalOf1StFRTRNRecord
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountBalOf1StFRTRNRecord", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.AccountBalOf1StFRTRNRecord, Id = Index.AccountBalOf1StFRTRNRecord, FieldType = EntityFieldType.Char, Size = 1)]
        public string AccountBalOf1StFRTRNRecord { get; set; }

        /// <summary>
        /// Gets or sets FRTRNBrowsingOrder
        /// </summary>
        [Display(Name = "FRTRNBrowsingOrder", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.FRTRNBrowsingOrder, Id = Index.FRTRNBrowsingOrder, FieldType = EntityFieldType.Int, Size = 2)]
        public short FRTRNBrowsingOrder { get; set; }

        /// <summary>
        /// Gets or sets RollupSwitch
        /// </summary>
        [Display(Name = "RollupSwitch", ResourceType = typeof (FinancialReportInformationResx))]
        [ViewField(Name = Fields.RollupSwitch, Id = Index.RollupSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public short RollupSwitch { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets FiscalSetDesignator string value
        /// </summary>
        public string FiscalSetDesignatorString => EnumUtility.GetStringValue(FiscalSetDesignator);

        /// <summary>
        /// Gets CurrencyType string value
        /// </summary>
        public string CurrencyTypeString => EnumUtility.GetStringValue(CurrencyType);

        #endregion
    }
}
