﻿// Copyright (c) 2022 The Sage Group plc or its licensors.  All rights reserved.

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Attributes;
using System;
using System.Net;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    [EncryptionRequired(new byte[] { 
        0x41, 0x3F, 0x44, 0x28, 0x47, 0x2B, 0x4B, 0x61, 
        0x50, 0x64, 0x53, 0x67, 0x56, 0x6B, 0x59, 0x70, 
        0x33, 0x73, 0x36, 0x76, 0x39, 0x79, 0x24, 0x42, 
        0x26, 0x45, 0x29, 0x48, 0x40, 0x4D, 0x63, 0x51 
    })]
    public class FRDrilldown
    {
        public NetworkCredential Credentials { get; set; }

        public DateTime SessionDate { get; set; }
    }
}

