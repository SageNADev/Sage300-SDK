﻿// Copyright(c) 2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Constants for keys to store hidden sheet data in FR Web Addin
    /// </summary>
    public class FRSettingKeys
    {
        public const string COVER_SHEET  = "D81AD042-9141-42E4-AF9E-F81B855";
        public const string HIDDEN_SHEET = "66B9E30E-7105-4153-9209-178113B";

        public const string FRVERSIONNUMBER           = "FRVersionNumber";
        public const string FRWEBAPIURL               = "FRWebAPIURL";
        public const string ACCESSTOKEN               = "AccessToken";
        public const string USER                      = "User";
        public const string ORGANIZATION              = "Organization";
        public const string SAGE300WEBSCREENBASEURL   = "Sage300WebScreenBaseUrl";
        public const string SAGE300PROXYBASEURL       = "Sage300ProxyBaseUrl";
        public const string SESSIONDATE               = "SessionDate";
        public const string COMPANYDESCRIPTION        = "CompanyDescription";
        public const string USEBUDGETOPENINGBALANCE   = "UseBudgetOpeningBalance";
        public const string USEQUANTITYOPENINGBALANCE = "UseQuantityOpeningBalance";
        public const string PRODUCTSERIES             = "ProductSeries";
        public const string CULTURE                   = "Culture";
        public const string HELPLINKS                 = "HelpLinks";
        public const string FISCALYEARS               = "FiscalYears";
        public const string GLOPT                     = "GLOPTValues";
        public const string FRAMFFIELDS               = "FRAMFFields";
        public const string FRAMF                     = "FRAMFValues";
        public const string GLOFD                     = "GLOFDValues";
        public const string GLAMFFIELDS               = "GLAMFFields";
        public const string GLASVFIELDS               = "GLASVFields";
        public const string CSCCDFIELDS               = "CSCCDFields";
        public const string CSCRTFIELDS               = "CSCRTFields";
        public const string GLABK                     = "GLABKValues";
        public const string GLACGRPFIELDS             = "GLACGRPFields";
        public const string PRINTTYPE                 = "PrintType";
        public const string PRINTPARAMETERS           = "PrintParameters";
    }
}
