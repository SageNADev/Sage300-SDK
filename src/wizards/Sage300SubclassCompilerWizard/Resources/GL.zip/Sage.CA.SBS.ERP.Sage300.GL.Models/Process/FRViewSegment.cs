﻿// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Model for FR View and Print Segment grid
    /// </summary>
    public class FRViewSegment
    {
        public string SegmentName { get; set; }

        public string From { get; set; }

        public string To { get; set; }

        public string ReportAs { get; set; }

        public string SegmentNumber { get; set; }
    }
}
