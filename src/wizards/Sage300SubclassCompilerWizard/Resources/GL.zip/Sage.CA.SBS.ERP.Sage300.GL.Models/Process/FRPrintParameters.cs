﻿// Copyright(c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Imports
using System.Collections.Generic;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Runtime parameters passed to GenerateReport. Equivalent of FRRUNPARAM in vb
    /// </summary>
    public class FRPrintParameters
    {
        public int iProvType { get; set; }

        public int iCurrFiscPeriod { get; set; }

        public string szCurrFiscYear { get; set; }

        public bool fInclDrillDown { get; set; }

        public bool fInclFormulas { get; set; }

        public bool fInclAudit { get; set; }

        public bool fInclOptions { get; set; }

        public int iOrderBy { get; set; }

        public int iOrderBySegId { get; set; }

        public string szAcctIdStart { get; set; }

        public string szAcctIdEnd { get; set; }

        public bool fSelectBySortedGroup { get; set; }

        public string sGroupStart { get; set; }

        public string sGroupEnd { get; set; }

        public string sSortGroupStart { get; set; }

        public string sSortGroupEnd { get; set; }

        public List<SegmentRange> srSegRanges { get; set; }

        public string szCurrReportFilter { get; set; }

        public bool fConsolidated { get; set; }

        /// <summary>
        /// Unused by print model
        /// </summary>
        public int AccountLength { get; set; }

        /// <summary>
        /// Unused by print model
        /// </summary>
        public int GroupLength { get; set; }

        /// <summary>
        /// Unused by print model
        /// </summary>
        public int SortGroupLength { get; set; }
    }

    /// <summary>
    /// Segments for FRPrintParameters. Equivalent of SEGRANGE in vb
    /// </summary>
    public class SegmentRange
    {
        public int iSegOption { get; set; }

        public string szSegStart { get; set; }

        public string szSegEnd { get; set; }

        public string szSegCurVal { get; set; }

        public long iSegStart { get; set; }

        public long iSegEnd { get; set; }

        public long iSegCurVal { get; set; }

        /// <summary>
        /// Unused by print model
        /// </summary>
        public string SegmentNumber { get; set; }

        /// <summary>
        /// Unused by print model
        /// </summary>
        public int SegmentLength { get; set; }
    }
}
