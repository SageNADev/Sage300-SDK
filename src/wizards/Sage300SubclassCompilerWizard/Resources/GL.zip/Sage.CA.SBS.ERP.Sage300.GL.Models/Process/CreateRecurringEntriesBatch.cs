/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
	public partial class CreateRecurringEntriesBatch : ModelBase
	{
		/// <summary>
        /// Gets or sets RunDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RunDate", ResourceType = typeof(CreateRecurringEntriesBatchResx))]
        [ViewField(Name = Fields.RunDate, Id = Index.RunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RunDate {get; set;}
	 
		/// <summary>
        /// Gets or sets Mode 
        /// </summary>
        [Display(Name = "Method", ResourceType = typeof(CreateRecurringEntriesBatchResx))]
        [ViewField(Name = Fields.Mode, Id = Index.Mode, FieldType = EntityFieldType.Int, Size = 2)]
        public int Mode {get; set;}
	 
		/// <summary>
        /// Gets or sets SelectRecordsBy 
        /// </summary>
		[ViewField(Name = Fields.SelectRecordsBy, Id = Index.SelectRecordsBy, FieldType = EntityFieldType.Int, Size = 2)]
		public SelectRecordsByEnum SelectRecordsBy {get; set;}
	 
		/// <summary>
        /// Gets or sets FromRecurringEntryCode 
        /// </summary>
        [Display(Name = "FromRecurringEntryCode", ResourceType = typeof(CreateRecurringEntriesBatchResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [ViewField(Name = Fields.FromRecurringEntryCode, Id = Index.FromRecurringEntryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FromRecurringEntryCode {get; set;}
	 
		/// <summary>
        /// Gets or sets ToRecurringEntryCode 
        /// </summary>
        [Display(Name = "ToRecurringEntryCode", ResourceType = typeof(CreateRecurringEntriesBatchResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToRecurringEntryCode, Id = Index.ToRecurringEntryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ToRecurringEntryCode {get; set;}
	 
		/// <summary>
        /// Gets or sets ScheduleKey 
        /// </summary>
        [ViewField(Name = Fields.ScheduleKey, Id = Index.ScheduleKey, FieldType = EntityFieldType.Char, Size = 12)]
        public string ScheduleKey {get; set;}
	 
		/// <summary>
        /// Gets or sets ScheduleLink 
        /// </summary>
		[ViewField(Name = Fields.ScheduleLink, Id = Index.ScheduleLink, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal ScheduleLink {get; set;}
	 
		/// <summary>
        /// Gets or sets Status 
        /// </summary>
		[ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
		public int Status {get; set;}
	 
		
        //TODO: The naming convention of this property has to be relooked
		/// <summary>
        /// Gets or sets SWBTCHMETH 
        /// </summary>
        [Display(Name = "Method", ResourceType = typeof(CreateRecurringEntriesBatchResx))]
        [ViewField(Name = Fields.BatchCreationType, Id = Index.BatchCreationType, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchCreationType BatchCreationType {get; set;}
	 
		
        //TODO: The naming convention of this property has to be relooked
  
		/// <summary>
        /// Gets or sets BTCHAPPEND 
        /// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof(CreateRecurringEntriesBatchResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AppendToBatch, Id = Index.AppendToBatch, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string AppendToBatch {get; set;}
	    }
}
