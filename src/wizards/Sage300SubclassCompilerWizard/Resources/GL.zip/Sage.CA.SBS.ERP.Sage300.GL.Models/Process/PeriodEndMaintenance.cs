/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    public partial class PeriodEndMaintenance : ModelBase
    {

        /// <summary>
        /// Gets or sets DeleteInactiveAccounts 
        /// </summary>
        [Display(Name = "DeleteInactive", ResourceType = typeof(PeriodEndMaintenanceResx))]
        [ViewField(Name = Fields.DeleteInactiveAccounts, Id = Index.DeleteInactiveAccounts, FieldType = EntityFieldType.Int, Size = 2)]
        public bool DeleteInactiveAccounts { get; set; }

        /// <summary>
        /// Gets or sets DeleteTransactionHistory 
        /// </summary>
        [Display(Name = "DeleteTransaction", ResourceType = typeof(PeriodEndMaintenanceResx))]
        [ViewField(Name = Fields.DeleteTransactionHistory, Id = Index.DeleteTransactionHistory, FieldType = EntityFieldType.Int, Size = 2)]
        public bool DeleteTransactionHistory { get; set; }

        /// <summary>
        /// Gets or sets DeleteTransactionHistory warning message
        /// </summary>
        public string DeleteTransactionHistoryWarningMsg { get; set; }

        /// <summary>
        /// Gets or sets DeleteSummaryHistory 
        /// </summary>
        [Display(Name = "DeleteFiscalSet", ResourceType = typeof(PeriodEndMaintenanceResx))]
        [ViewField(Name = Fields.DeleteSummaryHistory, Id = Index.DeleteSummaryHistory, FieldType = EntityFieldType.Int, Size = 2)]
        public bool DeleteSummaryHistory { get; set; }

        /// <summary>
        /// Gets or sets DeleteSummaryHistory  warning message
        /// </summary>
        public string DeleteSummaryHistoryWarningMsg { get; set; }

        /// <summary>
        /// Gets or sets ResetBatchNumber 
        /// </summary>
        [Display(Name = "ResetBatchNumbers", ResourceType = typeof(PeriodEndMaintenanceResx))]
        [ViewField(Name = Fields.ResetBatchNumber, Id = Index.ResetBatchNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ResetBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets ResetBatchNumber  warning message
        /// </summary>
        public string ResetBatchNumberWarningMsg { get; set; }
    }
}
