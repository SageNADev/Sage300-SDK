﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Class AccountSelector.
    /// </summary>
    public class AccountSelector
    {
        /// <summary>
        /// Gets or Sets Segment Number
        /// </summary>
        /// <value>The segment number.</value>
        //[Required(ErrorMessage = "")]
        [StringLength(6)]
        public string SegmentNumber { get; set; }

        /// <summary>
        /// Gets or Sets To
        /// </summary>
        /// <value>From.</value>
        public string From { get; set; }

        /// <summary>
        /// Gets or Sets To
        /// </summary>
        /// <value>To.</value>
        public string To { get; set; }
    }
}