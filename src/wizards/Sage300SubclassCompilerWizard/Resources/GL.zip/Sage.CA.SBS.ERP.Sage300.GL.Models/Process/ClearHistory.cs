// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Model for Clear History
    /// </summary>
    public partial class ClearHistory : ModelBase
    {
        /// <summary>
        /// Gets or sets FromPostingSequence 
        /// </summary>
        [ViewField(Name = Fields.FromPostingSequence, Id = Index.FromPostingSequence, FieldType = EntityFieldType.Char, Size = 7, Mask = "%-7D")]
        public string FromPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets ToPostingSequence 
        /// </summary>
        [Display(Name = "ThroughJournal", ResourceType = typeof(ClearHistoryResx))]
        [ViewField(Name = Fields.ToPostingSequence, Id = Index.ToPostingSequence, FieldType = EntityFieldType.Char, Size = 7, Mask = "%-7D")]
        public string ToPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets ClearPostingJournal 
        /// </summary>
        [ViewField(Name = Fields.ClearPostingJournal, Id = Index.ClearPostingJournal, FieldType = EntityFieldType.Char, Size = 1)]
        public ClearPostingJournal ClearPostingJournal { get; set; }

        /// <summary>
        /// Gets or sets ClearPostingJournal Boolean value.
        /// </summary>
        [Display(Name = "ClearPostingJournal", ResourceType = typeof(ClearHistoryResx))]
        public bool ClearPostingJournalBool
        {
            get
            {
                return ClearPostingJournal == ClearPostingJournal.ClearPrintedJournals;
            }
            set
            {
                //If Checkbox is checked set ClearPostingJournal as MarkJournalsAsprinted to return true value;
                ClearPostingJournal = value ? ClearPostingJournal.ClearPrintedJournals : ClearPostingJournal.MarkJournalsAsprinted;
            }
        }
        /// <summary>
        /// Gets or sets ClearPostedBatches Boolean value.
        /// </summary>
        [Display(Name = "ClearBatches", ResourceType = typeof(ClearHistoryResx))]
        public bool ClearPostedBatches { get; set; }

        /// <summary>
        /// Gets or sets FromBatchNumber 
        /// </summary>
        public string FromBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets ToBatchNumber 
        /// </summary>
        [Display(Name = "ThroughBatch", ResourceType = typeof(ClearHistoryResx))]
        public string ToBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets PoReceiptAccess
        /// </summary>
        public bool IsBatchClear { get; set; }

        /// <summary>
        /// Gets or sets PoReceiptAccess
        /// </summary>
        public bool IsJournalClear { get; set; }
    }
}
