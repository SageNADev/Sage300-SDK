﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;


namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    public partial class CreateNewYear : ModelBase
    {
        /// <summary>
        /// Get/Set Current Year
        /// </summary>
        public decimal CurrentYear { get; set; }

        /// <summary>
        /// Get/Set Fiscal Set Year
        /// </summary>
        public decimal FiscalSetYear { get; set; }

        /// <summary>
        /// Get/Set Transaction year
        /// </summary>
        public decimal TransactionYear { get; set; }
    }
}
