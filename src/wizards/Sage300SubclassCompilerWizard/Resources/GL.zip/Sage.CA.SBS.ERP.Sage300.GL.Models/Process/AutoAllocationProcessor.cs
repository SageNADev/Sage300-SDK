// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Process;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
	/// <summary>
	/// Partial class for AutoAllocationProcessor
	/// </summary>
	public partial class AutoAllocationProcessor : ModelBase
	{

        public AutoAllocationProcessor()
        {
            AutoAllocationOptionalField = new EnumerableResponse<AutoAllocationOptionalField>();
        }

		/// <summary>
        /// Gets or sets BatchDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDescription", ResourceType = typeof(GLCommonResx))]
		[ViewField(Name = Fields.BatchDescription, Id = Index.BatchDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string BatchDescription { get; set; }

		/// <summary>
        /// Gets or sets AccountSegmentSelectionCode
		/// </summary>
		[ViewField(Name = Fields.AccountSegmentSelectionCode, Id = Index.AccountSegmentSelectionCode, FieldType = EntityFieldType.Char, Size = 1)]
		public AccountSegmentSelectionCode AccountSegmentSelectionCode { get; set; }

		/// <summary>
        /// Gets or sets AccountSegmentSelected
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		//[ViewField(Name = Fields.AccountSegmentSelected, Id = Index.AccountSegmentSelected, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
		public string AccountSegmentSelected { get; set; }

		/// <summary>
		/// Gets or sets FromAccountNumber
		/// </summary>
		[StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.FromAccountNumber, Id = Index.FromAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
		public string FromAccountNumber { get; set; }

		/// <summary>
		/// Gets or sets ToAccountNumber
		/// </summary>
		[StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ToAccountNumber, Id = Index.ToAccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
		public string ToAccountNumber { get; set; }

		/// <summary>
        /// Gets or sets TransactionDateForDetails
		/// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "JournalEntryDate", ResourceType = typeof(CreateAllocationBatchResx))]
		public DateTime TransactionDateForDetails { get; set; }

        /// <summary>
        /// Gets or sets PostingYearForAccountBalance
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PostingYearForAccountBalance, Id = Index.PostingYearForAccountBalance, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string PostingYearForAccountBalance { get; set; }

		/// <summary>
        /// Gets or sets PostingPeriodForAccountBalance
		/// </summary>
        [ValidateFiscalPeriod(ModuleName.GL, ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.PostingPeriodForAccountBalance, Id = Index.PostingPeriodForAccountBalance, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string PostingPeriodForAccountBalance { get; set; }

		/// <summary>
		/// Gets or sets AllocateBySwitch
		/// </summary>
		[ViewField(Name = Fields.AllocateBySwitch, Id = Index.AllocateBySwitch, FieldType = EntityFieldType.Int, Size = 2)]
		public int AllocateBySwitch { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        public ProcessCommand ProcessCommand { get; set; }

		/// <summary>
        /// Gets or sets SelectFromYearForAcctQuantity
		/// </summary>
		[StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.SelectFromYearForAcctQuantity, Id = Index.SelectFromYearForAcctQuantity, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
		public string SelectFromYearForAcctQuantity { get; set; }

		/// <summary>
        /// Gets or sets SelectToYearForAcctQuantity
		/// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SelectToYearForAcctQuantity, Id = Index.SelectToYearForAcctQuantity, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string SelectToYearForAcctQuantity { get; set; }

		/// <summary>
        /// Gets or sets SelectFromPeriodForAcctQuantity
		/// </summary>
        [ValidateFiscalPeriod(ModuleName.GL, ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.SelectFromPeriodForAcctQuantity, Id = Index.SelectFromPeriodForAcctQuantity, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string SelectFromPeriodForAcctQuantity { get; set; }

		/// <summary>
        /// Gets or sets SelectToPeriodForAcctQuantity
		/// </summary>
        [ValidateFiscalPeriod(ModuleName.GL, ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.SelectToPeriodForAcctQuantity, Id = Index.SelectToPeriodForAcctQuantity, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string SelectToPeriodForAcctQuantity { get; set; }

		/// <summary>
        /// Gets or sets ProcessSwitch
		/// </summary>
		[ViewField(Name = Fields.ProcessSwitch, Id = Index.ProcessSwitch, FieldType = EntityFieldType.Int, Size = 2)]
		public ProcessSwitch ProcessSwitch { get; set; }

		/// <summary>
		/// Gets or sets KeyId
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.KeyId, Id = Index.KeyId, FieldType = EntityFieldType.Int, Size = 2)]
		public int KeyId { get; set; }

		/// <summary>
		/// Gets or sets OptionalFields
		/// </summary>
		[ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
		public long OptionalFields { get; set; }

        /// <summary>
        /// Gets ot sets MultiCurrencyActivatedSwitch
        /// </summary>
        public bool MultiCurrencyActivatedSwitch { get; set; }

        /// <summary>
        /// Gets or sets QuantityHistoryAllowed
        /// </summary>
        public bool QuantityHistoryAllowed { get; set; }

        /// <summary>
        /// Gets or sets HasOBLicense
        /// </summary>
        // ReSharper disable once InconsistentNaming
        public bool HasOBLicense { get; set; }
        /// <summary>
        /// Gets or sets InternalHeaderOptionalField
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<AutoAllocationOptionalField> AutoAllocationOptionalField { get; set; }


		#region UI Strings

		/// <summary>
		/// Gets Accountsegmentselectioncode string value
		/// </summary>
		public string AccountsegmentselectioncodeString
		{
			get { return EnumUtility.GetStringValue(AccountSegmentSelectionCode); }
		}

		/// <summary>
		/// Gets Processswitches string value
		/// </summary>
        public string ProcessCommandString
		{
            get { return EnumUtility.GetStringValue(ProcessCommand); }
		}

		#endregion
	}
}
