/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Process;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Model for Posting Journal Update Clear
    /// </summary>
    public partial class PostingJournalUpdateClear : ModelBase
    {
        #region Model Properties

        /// <summary>
        /// Gets or sets FromPostingSequence 
        /// </summary>
        [ViewField(Name = Fields.FromPostingSequence, Id = Index.FromPostingSequence, FieldType = EntityFieldType.Char, Size = 7, Mask = "%-7D")]
        public string FromPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets ToPostingSequence 
        /// </summary>
        [ViewField(Name = Fields.ToPostingSequence, Id = Index.ToPostingSequence, FieldType = EntityFieldType.Char, Size = 7, Mask = "%-7D")]
        public string ToPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets ClearPostingJournal 
        /// </summary>
        [ViewField(Name = Fields.ClearPostingJournal, Id = Index.ClearPostingJournal, FieldType = EntityFieldType.Char, Size = 1)]
        public ClearPostingJournal ClearPostingJournal { get; set; }

        #endregion
    }
}
