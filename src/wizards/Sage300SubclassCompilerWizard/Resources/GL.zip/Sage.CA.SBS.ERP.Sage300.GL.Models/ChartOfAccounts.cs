﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class ChartOfAccounts : ModelBase
    {
        /// <summary>
        /// Gets or sets Formatted AccountNumber
        /// </summary>
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets FunctionalBalance
        /// </summary>
        public string FunctionalBalance { get; set; }

        /// <summary>
        /// Gets or sets RollupOrMemberOrNonRollup
        /// </summary>
        [IgnoreExportImport]
        public RollupOrMemberOrNonRollup RollupOrMemberOrNonRollup { get; set; }

        /// <summary>
        /// Gets or sets Rollupswitch 
        /// </summary>
        public bool Rollupswitch { get; set; }
    }
}
