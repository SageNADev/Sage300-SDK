/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Model for Source Codes
    /// </summary>
    public partial class SourceCode : ModelBase
    {
        /// <summary>
        /// Gets or sets the Source Ledger
        /// </summary>
        [Display(Name = "SourceLedger", ResourceType = typeof(SourceCodesResx))]
        [Required(ErrorMessageResourceType = typeof(AnnotationsResx), ErrorMessageResourceName = "Required")]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.SourceLedger, Id = Index.SourceLedger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedger { get; set; }

        /// <summary>
        /// Gets or sets the Source Type
        /// </summary>
        [Display(Name = "SourceType", ResourceType = typeof(SourceCodesResx))]
        [Required(ErrorMessageResourceType = typeof(SourceCodesResx), ErrorMessageResourceName = "SourceTypeInvalid")]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.SourceType, Id = Index.SourceType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType { get; set; }

        /// <summary>
        /// Gets or sets the Description
        /// </summary>
        [Display(Name = "SourceDescription", ResourceType = typeof(SourceCodesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }


        #region UI - Source Journal Profile
       
        /// <summary>
        /// Gets Source
        /// </summary>
        public string Source { get; set; }
        
        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        /// <value>The serial number.</value>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Previous Source Value
        /// </summary>
        public string PreviousSourceValue { get; set; }
        
        #endregion
    }
}
