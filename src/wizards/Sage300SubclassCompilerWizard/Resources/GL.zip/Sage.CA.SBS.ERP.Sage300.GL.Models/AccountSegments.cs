/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of properties for Account Segments
    /// </summary>
    public partial class AccountSegments : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AccountSegments"/> class.
        /// </summary>
        public AccountSegments()
        {
            SegmentCodes = new EnumerableResponse<SegmentCodes> { Items = new List<SegmentCodes>() };
        }

        /// <summary>
        /// Gets or Sets Segment Number
        /// </summary>
        /// <value>The segment number.</value>
        //[Required(ErrorMessage = "")]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "SegmentNumber", ResourceType = typeof(SegmentCodesResx))]
        [ViewField(Name = Fields.SegmentNumber, Id = Index.SegmentNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
        public string SegmentNumber { get; set; }

        /// <summary>
        /// Gets or Sets Segment Status
        /// </summary>
        /// <value>The segment status.</value>
        [ViewField(Name = Fields.SegmentStatus, Id = Index.SegmentStatus, FieldType = EntityFieldType.Char, Size = 1)]
        public SegmentStatus SegmentStatus { get; set; }

        /// <summary>
        /// Gets or Sets Segment Type
        /// </summary>
        /// <value>The type of the segment.</value>
        [ViewField(Name = Fields.SegmentType, Id = Index.SegmentType, FieldType = EntityFieldType.Char, Size = 1)]
        public SegmentType SegmentType { get; set; }

        /// <summary>
        /// Gets or Sets Segment Description
        /// </summary>
        /// <value>The segment description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentName", ResourceType = typeof(SegmentCodesResx))]
        [ViewField(Name = Fields.SegmentDescription, Id = Index.SegmentDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string SegmentDescription { get; set; }

        /// <summary>
        /// Gets or Sets Segment Length
        /// </summary>
        /// <value>The length of the segment.</value>
        [Display(Name = "Length", ResourceType = typeof(SegmentCodesResx))]
        [ViewField(Name = Fields.SegmentLength, Id = Index.SegmentLength, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal SegmentLength { get; set; }

        /// <summary>
        /// Gets or Sets Close By Account Segment Switch
        /// </summary>
        /// <value>The close by acct segt switch.</value>
        [Display(Name = "UseInClosing", ResourceType = typeof(SegmentCodesResx))]
        [ViewField(Name = Fields.CloseByAcctSegtSwitch, Id = Index.CloseByAcctSegtSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int CloseByAcctSegtSwitch { get; set; }

        /// <summary>
        /// Gets or Sets Alternate Key Index
        /// </summary>
        /// <value>The alternate key indx.</value>
        public byte AlternateKeyIndx { get; set; }

        /// <summary>
        /// Get Or Sets Segment Code List
        /// </summary>
        /// <value>The segment codes.</value>
        [IsMvcSpecific]
        public EnumerableResponse<SegmentCodes> SegmentCodes { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number.</value>
        public int SerialNumber { get; set; }

        /// <summary>
        /// SegmentStartingPosition - For Account
        /// </summary>
        public string SegmentStartingPosition { get; set; }
    }
}
