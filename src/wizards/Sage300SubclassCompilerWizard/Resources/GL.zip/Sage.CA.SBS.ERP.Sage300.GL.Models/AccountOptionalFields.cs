/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
using Type = Sage.CA.SBS.ERP.Sage300.GL.Models.Enums.Type;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class AccountOptionalFields : ModelBase
    {
        /// <summary>
        /// Constructor for intializing Enum Values
        /// </summary>
        public AccountOptionalFields()
        {
            Type = Type.Text;
            Validate = AllowBlankOptional.Yes;
            YesOrNoValue = CS.Models.Enums.AllowBlank.No;
            ValueSet = ValueSet.No;
            AllowBlank = AllowBlankOptional.Yes;
        }

        /// <summary>
        /// Gets or sets UnformattedAccount 
        /// </summary>
        [Key]
        [Display(Name = "UnformattedAccount", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.UnformattedAccount, Id = Index.UnformattedAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnformattedAccount { get; set; }

        /// <summary>
        /// Gets or sets OptionalField 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(CommonResx))]
        [Key]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Value 
        /// </summary>
        [Display(Name = "Value", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length 
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals 
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank 
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlankOptional AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate 
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlankOptional Validate { get; set; }

        /// <summary>
        /// Gets or sets ValueSet 
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets TypedValueFieldIndex 
        /// </summary>
        [Display(Name = "TypedValueFieldIndex", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets TextValue 
        /// </summary>
        [Display(Name = "TextValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string TextValue { get; set; }

        /// <summary>
        /// Gets or sets AmountValue 
        /// </summary>
        [Display(Name = "AmountValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountValue { get; set; }

        /// <summary>
        /// Gets or sets NumberValue 
        /// </summary>
        [Display(Name = "NumberValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NumberValue { get; set; }

        /// <summary>
        /// Gets or sets IntegerValue 
        /// </summary>
        [Display(Name = "IntegerValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long IntegerValue { get; set; }

        /// <summary>
        /// Gets or sets YesOrNoValue 
        /// </summary>
        [Display(Name = "YesOrNoValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.YesOrNoValue, Id = Index.YesOrNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank YesOrNoValue { get; set; }

        /// <summary>
        /// Gets or sets DateValue 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateValue { get; set; }

        /// <summary>
        /// Gets or sets TimeValue 
        /// </summary>
        [Display(Name = "TimeValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime? TimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription 
        /// </summary>
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription 
        /// </summary>
        [Display(Name = "ValueDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Added AutoInsert for Replace Optional Field Functionality
        /// </summary>
        public bool AutoInsert { get; set; }
    }
}
