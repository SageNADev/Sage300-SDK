/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Revaluation Code Model
    /// </summary>
    public partial class RevaluationCode : ModelBase
    {
        /// <summary>
        /// Gets or sets Revaluation Code 
        /// </summary>
        [Key]
        [Display(Name = "Code", ResourceType = typeof(RevaluationCodesResx))]
        [Required(ErrorMessageResourceType = typeof(AnnotationsResx), ErrorMessageResourceName = "Required")]
        [ViewField(Name = Fields.Code, Id = Index.Code, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(RevaluationCodesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Revalue By 
        /// </summary>
        [Display(Name = "RevalueBy", ResourceType = typeof(RevaluationCodesResx))]
        [ViewField(Name = Fields.RevalueBy, Id = Index.RevalueBy, FieldType = EntityFieldType.Int, Size = 2)]
        public RevalueBy RevalueBy { get; set; }

        /// <summary>
        /// Gets or sets Rate Type 
        /// </summary>
        [Display(Name = "RateType", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets Source Code ID 
        /// </summary>
        [Display(Name = "SourceCodeId", ResourceType = typeof(RevaluationCodesResx))]
        [ViewField(Name = Fields.SourceCodeId, Id = Index.SourceCodeId, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeId { get; set; }

        /// <summary>
        /// Gets or sets Source Type 
        /// </summary>
        [Display(Name = "SourceType", ResourceType = typeof(SourceCodesResx))]
        [ViewField(Name = Fields.SourceType, Id = Index.SourceType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType { get; set; }

        /// <summary>
        /// Gets or sets Unrealized Or ExGainAcctID 
        /// </summary>
        [Display(Name = "GAINACCOUNTDESC", ResourceType = typeof(RevaluationCodesResx))]
        [ViewField(Name = Fields.UnrealizedOrExGainAcctId, Id = Index.UnrealizedOrExGainAcctId, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnrealizedOrExGainAcctId { get; set; }

        /// <summary>
        /// Gets or sets Unrealized Or ExLossAcctID 
        /// </summary>
        [Display(Name = "LOSSACCOUNTDESC", ResourceType = typeof(RevaluationCodesResx))]
        [ViewField(Name = Fields.UnrealizedOrExLossAcctId, Id = Index.UnrealizedOrExLossAcctId, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnrealizedOrExLossAcctId { get; set; }

        /// <summary>
        /// Gets or sets Exchange Gain AcctID 
        /// </summary>
        [Display(Name = "RECOGNGAINACCOUNTDESC", ResourceType = typeof(RevaluationCodesResx))]
        [ViewField(Name = Fields.ExchangeGainAcctId, Id = Index.ExchangeGainAcctId, FieldType = EntityFieldType.Char, Size = 45)]
        public string ExchangeGainAcctId { get; set; }

        /// <summary>
        /// Gets or sets Exchange Loss AcctID 
        /// </summary>
        [Display(Name = "RECOGNLOSSACCOUNTDESC", ResourceType = typeof(RevaluationCodesResx))]
        [ViewField(Name = Fields.ExchangeLossAcctId, Id = Index.ExchangeLossAcctId, FieldType = EntityFieldType.Char, Size = 45)]
        public string ExchangeLossAcctId { get; set; }

        /// <summary>
        /// Gets Revalue By String
        /// </summary>
        public string RevalueByString
        {
            get
            {
                return EnumUtility.GetStringValue(RevalueBy);
            }
        }
    }
}
