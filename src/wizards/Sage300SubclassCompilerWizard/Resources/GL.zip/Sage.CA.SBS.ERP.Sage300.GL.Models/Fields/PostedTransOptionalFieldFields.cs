﻿// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of PostedTransOptionalField Constants
    /// </summary>
    public partial class PostedTransOptionalField
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "GL0405";

        #region Properties

        /// <summary>
        /// Contains list of PostedTransOptionalField Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for AccountNumber
            /// </summary>
            public const string AccountNumber = "ACCTID";

            /// <summary>
            /// Property for Fiscalyear
            /// </summary>
            public const string Fiscalyear = "FISCALYR";

            /// <summary>
            /// Property for Fiscalperiod
            /// </summary>
            public const string Fiscalperiod = "FISCALPERD";

            /// <summary>
            /// Property for Sourcecurrencycode
            /// </summary>
            public const string Sourcecurrencycode = "SRCECURN";

            /// <summary>
            /// Property for SourceLedgerCode
            /// </summary>
            public const string SourceLedgerCode = "SRCELEDGER";

            /// <summary>
            /// Property for SourceTypeCode
            /// </summary>
            public const string SourceTypeCode = "SRCETYPE";

            /// <summary>
            /// Property for Postingsequencenumber
            /// </summary>
            public const string Postingsequencenumber = "POSTINGSEQ";

            /// <summary>
            /// Property for Detailcount
            /// </summary>
            public const string Detailcount = "CNTDETAIL";

            /// <summary>
            /// Property for OptionalField
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for Value
            /// </summary>
            public const string Value = "VALUE";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Length
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Decimals
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for AllowBlank
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";

            /// <summary>
            /// Property for Validate
            /// </summary>
            public const string Validate = "VALIDATE";

            /// <summary>
            /// Property for TypedValueFieldIndex
            /// </summary>
            public const string TypedValueFieldIndex = "VALINDEX";

            /// <summary>
            /// Property for TextValue
            /// </summary>
            public const string TextValue = "VALIFTEXT";

            /// <summary>
            /// Property for AmountValue
            /// </summary>
            public const string AmountValue = "VALIFMONEY";

            /// <summary>
            /// Property for NumberValue
            /// </summary>
            public const string NumberValue = "VALIFNUM";

            /// <summary>
            /// Property for IntegerValue
            /// </summary>
            public const string IntegerValue = "VALIFLONG";

            /// <summary>
            /// Property for YesNoValue
            /// </summary>
            public const string YesNoValue = "VALIFBOOL";

            /// <summary>
            /// Property for DateValue
            /// </summary>
            public const string DateValue = "VALIFDATE";

            /// <summary>
            /// Property for TimeValue
            /// </summary>
            public const string TimeValue = "VALIFTIME";

            /// <summary>
            /// Property for OptionalFieldDescription
            /// </summary>
            public const string OptionalFieldDescription = "FDESC";

            /// <summary>
            /// Property for ValueDescription
            /// </summary>
            public const string ValueDescription = "VDESC";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PostedTransOptionalField Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for AccountNumber
            /// </summary>
            public const int AccountNumber = 1;

            /// <summary>
            /// Property Indexer for Fiscalyear
            /// </summary>
            public const int Fiscalyear = 2;

            /// <summary>
            /// Property Indexer for Fiscalperiod
            /// </summary>
            public const int Fiscalperiod = 3;

            /// <summary>
            /// Property Indexer for Sourcecurrencycode
            /// </summary>
            public const int Sourcecurrencycode = 4;

            /// <summary>
            /// Property Indexer for SourceLedgerCode
            /// </summary>
            public const int SourceLedgerCode = 5;

            /// <summary>
            /// Property Indexer for SourceTypeCode
            /// </summary>
            public const int SourceTypeCode = 6;

            /// <summary>
            /// Property Indexer for Postingsequencenumber
            /// </summary>
            public const int Postingsequencenumber = 7;

            /// <summary>
            /// Property Indexer for Detailcount
            /// </summary>
            public const int Detailcount = 8;

            /// <summary>
            /// Property Indexer for OptionalField
            /// </summary>
            public const int OptionalField = 9;

            /// <summary>
            /// Property Indexer for Value
            /// </summary>
            public const int Value = 10;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 11;

            /// <summary>
            /// Property Indexer for Length
            /// </summary>
            public const int Length = 12;

            /// <summary>
            /// Property Indexer for Decimals
            /// </summary>
            public const int Decimals = 13;

            /// <summary>
            /// Property Indexer for AllowBlank
            /// </summary>
            public const int AllowBlank = 14;

            /// <summary>
            /// Property Indexer for Validate
            /// </summary>
            public const int Validate = 15;

            /// <summary>
            /// Property Indexer for TypedValueFieldIndex
            /// </summary>
            public const int TypedValueFieldIndex = 20;

            /// <summary>
            /// Property Indexer for TextValue
            /// </summary>
            public const int TextValue = 21;

            /// <summary>
            /// Property Indexer for AmountValue
            /// </summary>
            public const int AmountValue = 22;

            /// <summary>
            /// Property Indexer for NumberValue
            /// </summary>
            public const int NumberValue = 23;

            /// <summary>
            /// Property Indexer for IntegerValue
            /// </summary>
            public const int IntegerValue = 24;

            /// <summary>
            /// Property Indexer for YesNoValue
            /// </summary>
            public const int YesNoValue = 25;

            /// <summary>
            /// Property Indexer for DateValue
            /// </summary>
            public const int DateValue = 26;

            /// <summary>
            /// Property Indexer for TimeValue
            /// </summary>
            public const int TimeValue = 27;

            /// <summary>
            /// Property Indexer for OptionalFieldDescription
            /// </summary>
            public const int OptionalFieldDescription = 28;

            /// <summary>
            /// Property Indexer for ValueDescription
            /// </summary>
            public const int ValueDescription = 29;

        }
        #endregion
    }
}
