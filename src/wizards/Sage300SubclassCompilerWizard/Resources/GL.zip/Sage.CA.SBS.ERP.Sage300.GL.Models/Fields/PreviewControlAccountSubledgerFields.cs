// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of PreviewControlAccountSubledger Constants
    /// </summary>
    public partial class PreviewControlAccountSubledger
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0048";

        #region Properties

        /// <summary>
        /// Contains list of PreviewControlAccountSubledger Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for Account
            /// </summary>
            public const string Account = "ACCTID";

            /// <summary>
            /// Property for Subledger
            /// </summary>
            public const string Subledger = "SRCELDGID";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PreviewControlAccountSubledger Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for Account
            /// </summary>
            public const int Account = 1;

            /// <summary>
            /// Property Indexer for Subledger
            /// </summary>
            public const int Subledger = 2;

        }

        #endregion

    }
}
