// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of Accounts Constants
    /// </summary>
    public partial class FRAccount
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "GL0110";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of Accounts Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for UnformattedAccount
            /// </summary>
            public const string UnformattedAccount = "ACCTID";

            /// <summary>
            /// Property for DateCreated
            /// </summary>
            public const string DateCreated = "CREATEDATE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "ACCTDESC";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "ACCTTYPE";

            /// <summary>
            /// Property for NormalBalanceDRCR
            /// </summary>
            public const string NormalBalanceDRCR = "ACCTBAL";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "ACTIVESW";

            /// <summary>
            /// Property for PostToAccount
            /// </summary>
            public const string PostToAccount = "CONSLDSW";

            /// <summary>
            /// Property for QuantitiesAllowed
            /// </summary>
            public const string QuantitiesAllowed = "QTYSW";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UOM";

            /// <summary>
            /// Property for AllocationsAllowed
            /// </summary>
            public const string AllocationsAllowed = "ALLOCSW";

            /// <summary>
            /// Property for AllocOffsetAccount
            /// </summary>
            public const string AllocOffsetAccount = "ACCTOFSET";

            /// <summary>
            /// Property for AllocSourceType
            /// </summary>
            public const string AllocSourceType = "ACCTSRTY";

            /// <summary>
            /// Property for Rollup
            /// </summary>
            public const string Rollup = "ROLLUPSW";

            /// <summary>
            /// Property for Multicurrency
            /// </summary>
            public const string Multicurrency = "MCSW";

            /// <summary>
            /// Property for SpecificCurrency
            /// </summary>
            public const string SpecificCurrency = "SPECSW";

            /// <summary>
            /// Property for AccountGroupCode
            /// </summary>
            public const string AccountGroupCode = "ACCTGRPCOD";

            /// <summary>
            /// Property for ControlAccount
            /// </summary>
            public const string ControlAccount = "CTRLACCTSW";

            /// <summary>
            /// Property for Reserved
            /// </summary>
            public const string Reserved = "SRCELDGID";

            /// <summary>
            /// Property for AllocationPercentTotal
            /// </summary>
            public const string AllocationPercentTotal = "ALLOCTOT";

            /// <summary>
            /// Property for StructureCode
            /// </summary>
            public const string StructureCode = "ABRKID";

            /// <summary>
            /// Property for YearLastClosed
            /// </summary>
            public const string YearLastClosed = "YRACCTCLOS";

            /// <summary>
            /// Property for AccountNumber
            /// </summary>
            public const string AccountNumber = "ACCTFMTTD";

            /// <summary>
            /// Property for AccountSegmentCode1
            /// </summary>
            public const string AccountSegmentCode1 = "ACSEGVAL01";

            /// <summary>
            /// Property for AccountSegmentCode2
            /// </summary>
            public const string AccountSegmentCode2 = "ACSEGVAL02";

            /// <summary>
            /// Property for AccountSegmentCode3
            /// </summary>
            public const string AccountSegmentCode3 = "ACSEGVAL03";

            /// <summary>
            /// Property for AccountSegmentCode4
            /// </summary>
            public const string AccountSegmentCode4 = "ACSEGVAL04";

            /// <summary>
            /// Property for AccountSegmentCode5
            /// </summary>
            public const string AccountSegmentCode5 = "ACSEGVAL05";

            /// <summary>
            /// Property for AccountSegmentCode6
            /// </summary>
            public const string AccountSegmentCode6 = "ACSEGVAL06";

            /// <summary>
            /// Property for AccountSegmentCode7
            /// </summary>
            public const string AccountSegmentCode7 = "ACSEGVAL07";

            /// <summary>
            /// Property for AccountSegmentCode8
            /// </summary>
            public const string AccountSegmentCode8 = "ACSEGVAL08";

            /// <summary>
            /// Property for AccountSegmentCode9
            /// </summary>
            public const string AccountSegmentCode9 = "ACSEGVAL09";

            /// <summary>
            /// Property for AccountSegmentCode10
            /// </summary>
            public const string AccountSegmentCode10 = "ACSEGVAL10";

            /// <summary>
            /// Property for SegmentCode
            /// </summary>
            public const string SegmentCode = "ACCTSEGVAL";

            /// <summary>
            /// Property for AccountGroupSortCode
            /// </summary>
            public const string AccountGroupSortCode = "ACCTGRPSCD";

            /// <summary>
            /// Property for PostToSegmentID
            /// </summary>
            public const string PostToSegmentID = "POSTOSEGID";

            /// <summary>
            /// Property for DefaultCurrencyCode
            /// </summary>
            public const string DefaultCurrencyCode = "DEFCURNCOD";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCALPERD";

            /// <summary>
            /// Property for SourceCurrencyCode
            /// </summary>
            public const string SourceCurrencyCode = "SRCECURN";

            /// <summary>
            /// Property for SourceLedgerCode
            /// </summary>
            public const string SourceLedgerCode = "SRCELEDGER";

            /// <summary>
            /// Property for SourceTypeCode
            /// </summary>
            public const string SourceTypeCode = "SRCETYPE";

            /// <summary>
            /// Property for PostingSequenceNumber
            /// </summary>
            public const string PostingSequenceNumber = "POSTINGSEQ";

            /// <summary>
            /// Property for DetailCount
            /// </summary>
            public const string DetailCount = "CNTDETAIL";

            /// <summary>
            /// Property for JournalDate
            /// </summary>
            public const string JournalDate = "JRNLDATE";

            /// <summary>
            /// Property for BatchNumber
            /// </summary>
            public const string BatchNumber = "BATCHNBR";

            /// <summary>
            /// Property for JournalEntryNumber
            /// </summary>
            public const string JournalEntryNumber = "ENTRYNBR";

            /// <summary>
            /// Property for JournalTransactionNumber
            /// </summary>
            public const string JournalTransactionNumber = "TRANSNBR";

            /// <summary>
            /// Property for ConsolidationOccurredOnPost
            /// </summary>
            public const string ConsolidationOccurredOnPost = "CONSOLIDAT";

            /// <summary>
            /// Property for JournalDetailDescription
            /// </summary>
            public const string JournalDetailDescription = "JNLDTLDESC";

            /// <summary>
            /// Property for JournalDetailReference
            /// </summary>
            public const string JournalDetailReference = "JNLDTLREF";

            /// <summary>
            /// Property for JournalTransactionAmount
            /// </summary>
            public const string JournalTransactionAmount = "TRANSAMT";

            /// <summary>
            /// Property for JournalTransactionQuantity
            /// </summary>
            public const string JournalTransactionQuantity = "TRANSQTY";

            /// <summary>
            /// Property for SourceCurrencyAmount
            /// </summary>
            public const string SourceCurrencyAmount = "SCURNAMT";

            /// <summary>
            /// Property for ReportCurrencyAmount
            /// </summary>
            public const string ReportCurrencyAmount = "RPTAMT";

            /// <summary>
            /// Property for CurrencyRateTableType
            /// </summary>
            public const string CurrencyRateTableType = "RATETYPE";

            /// <summary>
            /// Property for DateOfCurrencyRateSelected
            /// </summary>
            public const string DateOfCurrencyRateSelected = "RATEDATE";

            /// <summary>
            /// Property for CurrencyRateForConversion
            /// </summary>
            public const string CurrencyRateForConversion = "CONVRATE";

            /// <summary>
            /// Property for CurrencyRateOperator
            /// </summary>
            public const string CurrencyRateOperator = "RATEOPER";

            /// <summary>
            /// Property for NumberOfGlpostoRecords
            /// </summary>
            public const string NumberOfGlpostoRecords = "VALUES";

            /// <summary>
            /// Property for TotalAccountOptionalFields
            /// </summary>
            public const string TotalAccountOptionalFields = "AVALUES";

            /// <summary>
            /// Property for TotalTransactionOptionalFields
            /// </summary>
            public const string TotalTransactionOptionalFields = "TVALUES";

            /// <summary>
            /// Property for TableSwitch
            /// </summary>
            public const string TableSwitch = "TBLSW";

            /// <summary>
            /// Property for OptionalField
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for OptionalFieldLocation
            /// </summary>
            public const string OptionalFieldLocation = "LOCATION";

            /// <summary>
            /// Property for OptionalFieldDesc
            /// </summary>
            public const string OptionalFieldDesc = "FDESC";
        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Accounts Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for UnformattedAccount
            /// </summary>
            public const int UnformattedAccount = 1;

            /// <summary>
            /// Property Indexer for DateCreated
            /// </summary>
            public const int DateCreated = 2;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 3;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 4;

            /// <summary>
            /// Property Indexer for NormalBalanceDRCR
            /// </summary>
            public const int NormalBalanceDRCR = 5;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 6;

            /// <summary>
            /// Property Indexer for PostToAccount
            /// </summary>
            public const int PostToAccount = 7;

            /// <summary>
            /// Property Indexer for QuantitiesAllowed
            /// </summary>
            public const int QuantitiesAllowed = 8;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 9;

            /// <summary>
            /// Property Indexer for AllocationsAllowed
            /// </summary>
            public const int AllocationsAllowed = 10;

            /// <summary>
            /// Property Indexer for AllocOffsetAccount
            /// </summary>
            public const int AllocOffsetAccount = 11;

            /// <summary>
            /// Property Indexer for AllocSourceType
            /// </summary>
            public const int AllocSourceType = 12;

            /// <summary>
            /// Property Indexer for Rollup
            /// </summary>
            public const int Rollup = 13;

            /// <summary>
            /// Property Indexer for Multicurrency
            /// </summary>
            public const int Multicurrency = 14;

            /// <summary>
            /// Property Indexer for SpecificCurrency
            /// </summary>
            public const int SpecificCurrency = 15;

            /// <summary>
            /// Property Indexer for AccountGroupCode
            /// </summary>
            public const int AccountGroupCode = 16;

            /// <summary>
            /// Property Indexer for ControlAccount
            /// </summary>
            public const int ControlAccount = 17;

            /// <summary>
            /// Property Indexer for Reserved
            /// </summary>
            public const int Reserved = 18;

            /// <summary>
            /// Property Indexer for AllocationPercentTotal
            /// </summary>
            public const int AllocationPercentTotal = 19;

            /// <summary>
            /// Property Indexer for StructureCode
            /// </summary>
            public const int StructureCode = 20;

            /// <summary>
            /// Property Indexer for YearLastClosed
            /// </summary>
            public const int YearLastClosed = 21;

            /// <summary>
            /// Property Indexer for AccountNumber
            /// </summary>
            public const int AccountNumber = 22;

            /// <summary>
            /// Property Indexer for AccountSegmentCode1
            /// </summary>
            public const int AccountSegmentCode1 = 23;

            /// <summary>
            /// Property Indexer for AccountSegmentCode2
            /// </summary>
            public const int AccountSegmentCode2 = 24;

            /// <summary>
            /// Property Indexer for AccountSegmentCode3
            /// </summary>
            public const int AccountSegmentCode3 = 25;

            /// <summary>
            /// Property Indexer for AccountSegmentCode4
            /// </summary>
            public const int AccountSegmentCode4 = 26;

            /// <summary>
            /// Property Indexer for AccountSegmentCode5
            /// </summary>
            public const int AccountSegmentCode5 = 27;

            /// <summary>
            /// Property Indexer for AccountSegmentCode6
            /// </summary>
            public const int AccountSegmentCode6 = 28;

            /// <summary>
            /// Property Indexer for AccountSegmentCode7
            /// </summary>
            public const int AccountSegmentCode7 = 29;

            /// <summary>
            /// Property Indexer for AccountSegmentCode8
            /// </summary>
            public const int AccountSegmentCode8 = 30;

            /// <summary>
            /// Property Indexer for AccountSegmentCode9
            /// </summary>
            public const int AccountSegmentCode9 = 31;

            /// <summary>
            /// Property Indexer for AccountSegmentCode10
            /// </summary>
            public const int AccountSegmentCode10 = 32;

            /// <summary>
            /// Property Indexer for SegmentCode
            /// </summary>
            public const int SegmentCode = 33;

            /// <summary>
            /// Property Indexer for AccountGroupSortCode
            /// </summary>
            public const int AccountGroupSortCode = 34;

            /// <summary>
            /// Property Indexer for PostToSegmentID
            /// </summary>
            public const int PostToSegmentID = 35;

            /// <summary>
            /// Property Indexer for DefaultCurrencyCode
            /// </summary>
            public const int DefaultCurrencyCode = 36;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 37;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 38;

            /// <summary>
            /// Property Indexer for SourceCurrencyCode
            /// </summary>
            public const int SourceCurrencyCode = 39;

            /// <summary>
            /// Property Indexer for SourceLedgerCode
            /// </summary>
            public const int SourceLedgerCode = 40;

            /// <summary>
            /// Property Indexer for SourceTypeCode
            /// </summary>
            public const int SourceTypeCode = 41;

            /// <summary>
            /// Property Indexer for PostingSequenceNumber
            /// </summary>
            public const int PostingSequenceNumber = 42;

            /// <summary>
            /// Property Indexer for DetailCount
            /// </summary>
            public const int DetailCount = 43;

            /// <summary>
            /// Property Indexer for JournalDate
            /// </summary>
            public const int JournalDate = 44;

            /// <summary>
            /// Property Indexer for BatchNumber
            /// </summary>
            public const int BatchNumber = 45;

            /// <summary>
            /// Property Indexer for JournalEntryNumber
            /// </summary>
            public const int JournalEntryNumber = 46;

            /// <summary>
            /// Property Indexer for JournalTransactionNumber
            /// </summary>
            public const int JournalTransactionNumber = 47;

            /// <summary>
            /// Property Indexer for ConsolidationOccurredOnPost
            /// </summary>
            public const int ConsolidationOccurredOnPost = 48;

            /// <summary>
            /// Property Indexer for JournalDetailDescription
            /// </summary>
            public const int JournalDetailDescription = 49;

            /// <summary>
            /// Property Indexer for JournalDetailReference
            /// </summary>
            public const int JournalDetailReference = 50;

            /// <summary>
            /// Property Indexer for JournalTransactionAmount
            /// </summary>
            public const int JournalTransactionAmount = 51;

            /// <summary>
            /// Property Indexer for JournalTransactionQuantity
            /// </summary>
            public const int JournalTransactionQuantity = 52;

            /// <summary>
            /// Property Indexer for SourceCurrencyAmount
            /// </summary>
            public const int SourceCurrencyAmount = 53;

            /// <summary>
            /// Property Indexer for ReportCurrencyAmount
            /// </summary>
            public const int ReportCurrencyAmount = 54;

            /// <summary>
            /// Property Indexer for CurrencyRateTableType
            /// </summary>
            public const int CurrencyRateTableType = 55;

            /// <summary>
            /// Property Indexer for DateOfCurrencyRateSelected
            /// </summary>
            public const int DateOfCurrencyRateSelected = 56;

            /// <summary>
            /// Property Indexer for CurrencyRateForConversion
            /// </summary>
            public const int CurrencyRateForConversion = 57;

            /// <summary>
            /// Property Indexer for CurrencyRateOperator
            /// </summary>
            public const int CurrencyRateOperator = 58;

            /// <summary>
            /// Property Indexer for NumberOfGlpostoRecords
            /// </summary>
            public const int NumberOfGlpostoRecords = 59;

            /// <summary>
            /// Property Indexer for TotalAccountOptionalFields
            /// </summary>
            public const int TotalAccountOptionalFields = 60;

            /// <summary>
            /// Property Indexer for TotalTransactionOptionalFields
            /// </summary>
            public const int TotalTransactionOptionalFields = 61;

            /// <summary>
            /// Property Indexer for TableSwitch
            /// </summary>
            public const int TableSwitch = 62;

            /// <summary>
            /// Property Indexer for OptionalField
            /// </summary>
            public const int OptionalField = 63;

            /// <summary>
            /// Property Indexer for OptionalFieldLocation
            /// </summary>
            public const int OptionalFieldLocation = 64;

            /// <summary>
            /// Property Indexer for OptionalFieldDesc
            /// </summary>
            public const int OptionalFieldDesc = 65;
        }

        #endregion

    }
}