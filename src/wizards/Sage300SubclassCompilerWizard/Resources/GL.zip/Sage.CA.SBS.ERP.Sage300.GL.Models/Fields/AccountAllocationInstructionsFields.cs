/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of AccountAllocationInstructions Constants 
    /// </summary>
    public partial class AccountAllocationInstructions
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0004";

        /// <summary>
        /// Contains list of AccountAllocationInstructions Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for Account 
            /// </summary>
            public const string Account = "ACCTID";
            /// <summary>
            /// Property for DistributionAccount 
            /// </summary>
            public const string DistributionAccount = "ACCTIDDIST";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";
            /// <summary>
            /// Property for JournalReference 
            /// </summary>
            public const string JournalReference = "REF";
            /// <summary>
            /// Property for AllocationPercent 
            /// </summary>
            public const string AllocationPercent = "ALLOCPCT";

            #endregion
        }


        /// <summary>
        /// Contains list of AccountAllocationInstructions Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for Account 
            /// </summary>
            public const int Account = 1;
            /// <summary>
            /// Property Indexer for DistributionAccount 
            /// </summary>
            public const int DistributionAccount = 2;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;
            /// <summary>
            /// Property Indexer for JournalReference 
            /// </summary>
            public const int JournalReference = 4;
            /// <summary>
            /// Property Indexer for AllocationPercent 
            /// </summary>
            public const int AllocationPercent = 5;

            #endregion
        }

    }
}
