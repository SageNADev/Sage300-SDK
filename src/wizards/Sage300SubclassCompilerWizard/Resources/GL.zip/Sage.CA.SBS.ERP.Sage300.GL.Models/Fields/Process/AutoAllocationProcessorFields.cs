// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
	/// <summary>
	/// Contains list of AutoAllocationProcessor Constants
	/// </summary>
	public partial class AutoAllocationProcessor
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "GL0029";

		#region Properties

		/// <summary>
		/// Contains list of AutoAllocationProcessor Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Batchdescription
			/// </summary>
			public const string BatchDescription = "TEXTDESC";

			/// <summary>
            /// Property for AccountSegmentSelectionCode
			/// </summary>
			public const string AccountSegmentSelectionCode = "CODESEGSEL";

			/// <summary>
            /// Property for AccountSegmentselected
			/// </summary>
			public const string AccountSegmentselected = "CODESEG";

			/// <summary>
			/// Property for FromAccountNumber
			/// </summary>
			public const string FromAccountNumber = "IDACCTFROM";

			/// <summary>
			/// Property for ToAccountNumber
			/// </summary>
			public const string ToAccountNumber = "IDACCTTO";

			/// <summary>
			/// Property for TransactiondateFordetails
			/// </summary>
			public const string TransactionDateForDetails = "DATETRANS";

			/// <summary>
			/// Property for PostingperiodForAccountBal
			/// </summary>
			public const string PostingPeriodForAccountBalance = "CNTPERD";

			/// <summary>
			/// Property for PostingyearForAccountBal
			/// </summary>
			public const string PostingYearForAccountBalance = "CNTYEAR";

			/// <summary>
			/// Property for AllocateBySwitch
			/// </summary>
			public const string AllocateBySwitch = "ALLOCATEBY";

			/// <summary>
			/// Property for SelectFromyearForAcctQty
			/// </summary>
            public const string SelectFromYearForAcctQuantity = "QTYFRYEAR";

			/// <summary>
			/// Property for SelectToyearForAcctQty
			/// </summary>
			public const string SelectToYearForAcctQuantity = "QTYTOYEAR";

			/// <summary>
			/// Property for SelectFromperiodForAcctQty
			/// </summary>
			public const string SelectFromPeriodForAcctQuantity = "QTYFRPERD";

			/// <summary>
			/// Property for SelectToperiodForAcctQty
			/// </summary>
			public const string SelectToPeriodForAcctQuantity = "QTYTOPERD";

			/// <summary>
			/// Property for Processswitches
			/// </summary>
			public const string ProcessSwitch = "PROCESSCMD";

			/// <summary>
			/// Property for KeyId
			/// </summary>
			public const string KeyId = "KEY";

			/// <summary>
			/// Property for OptionalFields
			/// </summary>
			public const string OptionalFields = "VALUES";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of AutoAllocationProcessor Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Batchdescription
			/// </summary>
			public const int BatchDescription = 1;

			/// <summary>
			/// Property Indexer for Accountsegmentselectioncode
			/// </summary>
			public const int AccountSegmentSelectionCode = 2;

			/// <summary>
			/// Property Indexer for Accountsegmentselected
			/// </summary>
			public const int AccountSegmentSelected = 3;

			/// <summary>
			/// Property Indexer for FromAccountNumber
			/// </summary>
			public const int FromAccountNumber = 4;

			/// <summary>
			/// Property Indexer for ToAccountNumber
			/// </summary>
			public const int ToAccountNumber = 5;

			/// <summary>
			/// Property Indexer for TransactiondateFordetails
			/// </summary>
			public const int TransactionDateFordetails = 6;

			/// <summary>
			/// Property Indexer for PostingperiodForAccountBal
			/// </summary>
			public const int PostingPeriodForAccountBalance = 7;

			/// <summary>
			/// Property Indexer for PostingyearForAccountBal
			/// </summary>
			public const int PostingYearForAccountBalance = 8;

			/// <summary>
			/// Property Indexer for AllocateBySwitch
			/// </summary>
			public const int AllocateBySwitch = 9;

			/// <summary>
			/// Property Indexer for SelectFromyearForAcctQty
			/// </summary>
			public const int SelectFromYearForAcctQuantity = 10;

			/// <summary>
			/// Property Indexer for SelectToyearForAcctQty
			/// </summary>
			public const int SelectToYearForAcctQuantity = 11;

			/// <summary>
			/// Property Indexer for SelectFromperiodForAcctQty
			/// </summary>
			public const int SelectFromPeriodForAcctQuantity = 12;

			/// <summary>
			/// Property Indexer for SelectToperiodForAcctQty
			/// </summary>
			public const int SelectToPeriodForAcctQuantity = 13;

			/// <summary>
			/// Property Indexer for Processswitches
			/// </summary>
			public const int ProcessSwitch = 14;

			/// <summary>
			/// Property Indexer for KeyId
			/// </summary>
			public const int KeyId = 15;

			/// <summary>
			/// Property Indexer for OptionalFields
			/// </summary>
			public const int OptionalFields = 16;

		}

		#endregion

	}
}
