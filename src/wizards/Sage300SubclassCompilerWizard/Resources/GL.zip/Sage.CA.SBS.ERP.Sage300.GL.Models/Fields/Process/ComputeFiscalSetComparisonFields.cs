// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Contains list of ComputeFiscalSetComparison Constants
    /// </summary>
    public partial class ComputeFiscalSetComparison
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "GL0011";

        #region Properties

        /// <summary>
        /// Contains list of ComputeFiscalSetComparison Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for Amount1
            /// </summary>
            public const string Amount1 = "AMT1";

            /// <summary>
            /// Property for Amount2
            /// </summary>
            public const string Amount2 = "AMT2";

            /// <summary>
            /// Property for Difference
            /// </summary>
            public const string Difference = "DIFF";

            /// <summary>
            /// Property for PercentDifference
            /// </summary>
            public const string PercentDifference = "PCTDIFF";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of ComputeFiscalSetComparison Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for Amount1
            /// </summary>
            public const int Amount1 = 1;

            /// <summary>
            /// Property Indexer for Amount2
            /// </summary>
            public const int Amount2 = 2;

            /// <summary>
            /// Property Indexer for Difference
            /// </summary>
            public const int Difference = 3;

            /// <summary>
            /// Property Indexer for PercentDifference
            /// </summary>
            public const int PercentDifference = 4;

        }

        #endregion

    }
}
