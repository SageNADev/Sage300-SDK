﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// ClearHistory Fields model
    /// </summary>
    public partial class ClearHistory
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0033";


        #region Fields

        /// <summary>
        /// Contains list of ClearHistory Fields Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for FromPostingSequence 
            /// </summary>
            public const string FromPostingSequence = "FROMPSEQ";
            /// <summary>
            /// Property for ToPostingSequence 
            /// </summary>
            public const string ToPostingSequence = "TOPSEQ";
            /// <summary>
            /// Property for ClearPostingJournal 
            /// </summary>
            public const string ClearPostingJournal = "CLEARPJ";

        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of ClearHistory Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for FromPostingSequence 
            /// </summary>
            public const int FromPostingSequence = 1;
            /// <summary>
            /// Property Indexer for ToPostingSequence 
            /// </summary>
            public const int ToPostingSequence = 2;
            /// <summary>
            /// Property Indexer for ClearPostingJournal 
            /// </summary>
            public const int ClearPostingJournal = 3;

        }

        #endregion

    }
}