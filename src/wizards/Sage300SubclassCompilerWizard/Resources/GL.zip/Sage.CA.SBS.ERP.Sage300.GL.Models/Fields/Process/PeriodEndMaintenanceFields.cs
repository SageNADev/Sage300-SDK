/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */


namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Contains list of PeriodEndMaintenance Constants 
    /// </summary>
    public partial class PeriodEndMaintenance
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0024";

        /// <summary>
        /// Contains list of PeriodEndMaintenance Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties

            /// <summary>
            /// Property for DeleteInactiveAccountsSW 
            /// </summary>
            public const string DeleteInactiveAccounts = "SWDELACCT";

            /// <summary>
            /// Property for DeleteTransactionHistorySW 
            /// </summary>
            public const string DeleteTransactionHistory = "SWDELTRAN";

            /// <summary>
            /// Property for DeleteSummaryHistorySW 
            /// </summary>
            public const string DeleteSummaryHistory = "SWDELFISC";

            /// <summary>
            /// Property for ResetBatchNumberSW 
            /// </summary>
            public const string ResetBatchNumber = "SRESETNBR";

            #endregion
        }

        /// <summary>
        /// Contains list of PeriodEndMaintenance Index Constants
        /// </summary>
        public class Index
        {

            #region Properties

            /// <summary>
            /// Property Indexer for Deleteinactiveaccountssw 
            /// </summary>
            public const int DeleteInactiveAccounts = 1;

            /// <summary>
            /// Property Indexer for Deletetransactionhistorysw 
            /// </summary>
            public const int DeleteTransactionHistory = 2;

            /// <summary>
            /// Property Indexer for Deletesummaryhistorysw 
            /// </summary>
            public const int DeleteSummaryHistory = 3;

            /// <summary>
            /// Property Indexer for ResetBatchNumbersw 
            /// </summary>
            public const int ResetBatchNumber = 4;

            #endregion
        }


    }
}
	