// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Contains list of FinancialReportInformation Constants
    /// </summary>
    public partial class FinancialReportInformation
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "GL0031";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of FinancialReportInformation Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for AccountNumber
            /// </summary>
            public const string AccountNumber = "ACCTID";

            /// <summary>
            /// Property for ReportingYear
            /// </summary>
            public const string ReportingYear = "RPTYR";

            /// <summary>
            /// Property for FiscalSetDesignator
            /// </summary>
            public const string FiscalSetDesignator = "DESIGNATOR";

            /// <summary>
            /// Property for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CURID";

            /// <summary>
            /// Property for CurrencyType
            /// </summary>
            public const string CurrencyType = "CURTYPE";

            /// <summary>
            /// Property for FiscalSetType
            /// </summary>
            public const string FiscalSetType = "AMTTYPE";

            /// <summary>
            /// Property for ReportingYearOffset
            /// </summary>
            public const string ReportingYearOffset = "RPTYROFF";

            /// <summary>
            /// Property for ReportingPeriod
            /// </summary>
            public const string ReportingPeriod = "RPTPERIOD";

            /// <summary>
            /// Property for BalanceCurrentPeriod
            /// </summary>
            public const string BalanceCurrentPeriod = "BALP";

            /// <summary>
            /// Property for BalanceLastPeriod
            /// </summary>
            public const string BalanceLastPeriod = "BALLP";

            /// <summary>
            /// Property for BalancePeriod1
            /// </summary>
            public const string BalancePeriod1 = "BAL1P";

            /// <summary>
            /// Property for BalancePeriod2
            /// </summary>
            public const string BalancePeriod2 = "BAL2P";

            /// <summary>
            /// Property for BalancePeriod3
            /// </summary>
            public const string BalancePeriod3 = "BAL3P";

            /// <summary>
            /// Property for BalancePeriod4
            /// </summary>
            public const string BalancePeriod4 = "BAL4P";

            /// <summary>
            /// Property for BalancePeriod5
            /// </summary>
            public const string BalancePeriod5 = "BAL5P";

            /// <summary>
            /// Property for BalancePeriod6
            /// </summary>
            public const string BalancePeriod6 = "BAL6P";

            /// <summary>
            /// Property for BalancePeriod7
            /// </summary>
            public const string BalancePeriod7 = "BAL7P";

            /// <summary>
            /// Property for BalancePeriod8
            /// </summary>
            public const string BalancePeriod8 = "BAL8P";

            /// <summary>
            /// Property for BalancePeriod9
            /// </summary>
            public const string BalancePeriod9 = "BAL9P";

            /// <summary>
            /// Property for BalancePeriod10
            /// </summary>
            public const string BalancePeriod10 = "BAL10P";

            /// <summary>
            /// Property for BalancePeriod11
            /// </summary>
            public const string BalancePeriod11 = "BAL11P";

            /// <summary>
            /// Property for BalancePeriod12
            /// </summary>
            public const string BalancePeriod12 = "BAL12P";

            /// <summary>
            /// Property for BalancePeriod13
            /// </summary>
            public const string BalancePeriod13 = "BAL13P";

            /// <summary>
            /// Property for Balance1PeriodAgo
            /// </summary>
            public const string Balance1PeriodAgo = "BAL1PA";

            /// <summary>
            /// Property for Balance2PeriodsAgo
            /// </summary>
            public const string Balance2PeriodsAgo = "BAL2PA";

            /// <summary>
            /// Property for Balance3PeriodsAgo
            /// </summary>
            public const string Balance3PeriodsAgo = "BAL3PA";

            /// <summary>
            /// Property for Balance4PeriodsAgo
            /// </summary>
            public const string Balance4PeriodsAgo = "BAL4PA";

            /// <summary>
            /// Property for Balance5PeriodsAgo
            /// </summary>
            public const string Balance5PeriodsAgo = "BAL5PA";

            /// <summary>
            /// Property for Balance6PeriodsAgo
            /// </summary>
            public const string Balance6PeriodsAgo = "BAL6PA";

            /// <summary>
            /// Property for Balance7PeriodsAgo
            /// </summary>
            public const string Balance7PeriodsAgo = "BAL7PA";

            /// <summary>
            /// Property for Balance8PeriodsAgo
            /// </summary>
            public const string Balance8PeriodsAgo = "BAL8PA";

            /// <summary>
            /// Property for Balance9PeriodsAgo
            /// </summary>
            public const string Balance9PeriodsAgo = "BAL9PA";

            /// <summary>
            /// Property for Balance10PeriodsAgo
            /// </summary>
            public const string Balance10PeriodsAgo = "BAL10PA";

            /// <summary>
            /// Property for Balance11PeriodsAgo
            /// </summary>
            public const string Balance11PeriodsAgo = "BAL11PA";

            /// <summary>
            /// Property for Balance12PeriodsAgo
            /// </summary>
            public const string Balance12PeriodsAgo = "BAL12PA";

            /// <summary>
            /// Property for Balance13PeriodsAgo
            /// </summary>
            public const string Balance13PeriodsAgo = "BAL13PA";

            /// <summary>
            /// Property for BalanceCurrentQuarter
            /// </summary>
            public const string BalanceCurrentQuarter = "BALQ";

            /// <summary>
            /// Property for BalanceLastQuarter
            /// </summary>
            public const string BalanceLastQuarter = "BALLQ";

            /// <summary>
            /// Property for BalanceQuarter1
            /// </summary>
            public const string BalanceQuarter1 = "BAL1Q";

            /// <summary>
            /// Property for BalanceQuarter2
            /// </summary>
            public const string BalanceQuarter2 = "BAL2Q";

            /// <summary>
            /// Property for BalanceQuarter3
            /// </summary>
            public const string BalanceQuarter3 = "BAL3Q";

            /// <summary>
            /// Property for BalanceQuarter4
            /// </summary>
            public const string BalanceQuarter4 = "BAL4Q";

            /// <summary>
            /// Property for BalanceQuarter1ToDate
            /// </summary>
            public const string BalanceQuarter1ToDate = "BAL1QTD";

            /// <summary>
            /// Property for BalanceQuarter2ToDate
            /// </summary>
            public const string BalanceQuarter2ToDate = "BAL2QTD";

            /// <summary>
            /// Property for BalanceQuarter3ToDate
            /// </summary>
            public const string BalanceQuarter3ToDate = "BAL3QTD";

            /// <summary>
            /// Property for BalanceQuarter4ToDate
            /// </summary>
            public const string BalanceQuarter4ToDate = "BAL4QTD";

            /// <summary>
            /// Property for Balance1QuarterAgo
            /// </summary>
            public const string Balance1QuarterAgo = "BAL1QA";

            /// <summary>
            /// Property for Balance2QuartersAgo
            /// </summary>
            public const string Balance2QuartersAgo = "BAL2QA";

            /// <summary>
            /// Property for Balance3QuartersAgo
            /// </summary>
            public const string Balance3QuartersAgo = "BAL3QA";

            /// <summary>
            /// Property for Balance4QuartersAgo
            /// </summary>
            public const string Balance4QuartersAgo = "BAL4QA";

            /// <summary>
            /// Property for BalanceCurrentHalfYear
            /// </summary>
            public const string BalanceCurrentHalfYear = "BALS";

            /// <summary>
            /// Property for BalanceLastHalfYear
            /// </summary>
            public const string BalanceLastHalfYear = "BALLS";

            /// <summary>
            /// Property for BalanceHalfYear1
            /// </summary>
            public const string BalanceHalfYear1 = "BAL1S";

            /// <summary>
            /// Property for BalanceHalfYear2
            /// </summary>
            public const string BalanceHalfYear2 = "BAL2S";

            /// <summary>
            /// Property for BalanceHalfYear1ToDate
            /// </summary>
            public const string BalanceHalfYear1ToDate = "BAL1STD";

            /// <summary>
            /// Property for BalanceHalfYear2ToDate
            /// </summary>
            public const string BalanceHalfYear2ToDate = "BAL2STD";

            /// <summary>
            /// Property for Balance1HalfYearAgo
            /// </summary>
            public const string Balance1HalfYearAgo = "BAL1SA";

            /// <summary>
            /// Property for Balance2HalfYearsAgo
            /// </summary>
            public const string Balance2HalfYearsAgo = "BAL2SA";

            /// <summary>
            /// Property for BalanceTotalYear
            /// </summary>
            public const string BalanceTotalYear = "BALY";

            /// <summary>
            /// Property for BalanceYearToDate
            /// </summary>
            public const string BalanceYearToDate = "BALYTD";

            /// <summary>
            /// Property for BalanceBeginningOfYear
            /// </summary>
            public const string BalanceBeginningOfYear = "BALOPEN";

            /// <summary>
            /// Property for NetCurrentPeriod
            /// </summary>
            public const string NetCurrentPeriod = "NETP";

            /// <summary>
            /// Property for NetLastPeriod
            /// </summary>
            public const string NetLastPeriod = "NETLP";

            /// <summary>
            /// Property for NetPeriod1
            /// </summary>
            public const string NetPeriod1 = "NET1P";

            /// <summary>
            /// Property for NetPeriod2
            /// </summary>
            public const string NetPeriod2 = "NET2P";

            /// <summary>
            /// Property for NetPeriod3
            /// </summary>
            public const string NetPeriod3 = "NET3P";

            /// <summary>
            /// Property for NetPeriod4
            /// </summary>
            public const string NetPeriod4 = "NET4P";

            /// <summary>
            /// Property for NetPeriod5
            /// </summary>
            public const string NetPeriod5 = "NET5P";

            /// <summary>
            /// Property for NetPeriod6
            /// </summary>
            public const string NetPeriod6 = "NET6P";

            /// <summary>
            /// Property for NetPeriod7
            /// </summary>
            public const string NetPeriod7 = "NET7P";

            /// <summary>
            /// Property for NetPeriod8
            /// </summary>
            public const string NetPeriod8 = "NET8P";

            /// <summary>
            /// Property for NetPeriod9
            /// </summary>
            public const string NetPeriod9 = "NET9P";

            /// <summary>
            /// Property for NetPeriod10
            /// </summary>
            public const string NetPeriod10 = "NET10P";

            /// <summary>
            /// Property for NetPeriod11
            /// </summary>
            public const string NetPeriod11 = "NET11P";

            /// <summary>
            /// Property for NetPeriod12
            /// </summary>
            public const string NetPeriod12 = "NET12P";

            /// <summary>
            /// Property for NetPeriod13
            /// </summary>
            public const string NetPeriod13 = "NET13P";

            /// <summary>
            /// Property for Net1PeriodAgo
            /// </summary>
            public const string Net1PeriodAgo = "NET1PA";

            /// <summary>
            /// Property for Net2PeriodsAgo
            /// </summary>
            public const string Net2PeriodsAgo = "NET2PA";

            /// <summary>
            /// Property for Net3PeriodsAgo
            /// </summary>
            public const string Net3PeriodsAgo = "NET3PA";

            /// <summary>
            /// Property for Net4PeriodsAgo
            /// </summary>
            public const string Net4PeriodsAgo = "NET4PA";

            /// <summary>
            /// Property for Net5PeriodsAgo
            /// </summary>
            public const string Net5PeriodsAgo = "NET5PA";

            /// <summary>
            /// Property for Net6PeriodsAgo
            /// </summary>
            public const string Net6PeriodsAgo = "NET6PA";

            /// <summary>
            /// Property for Net7PeriodsAgo
            /// </summary>
            public const string Net7PeriodsAgo = "NET7PA";

            /// <summary>
            /// Property for Net8PeriodsAgo
            /// </summary>
            public const string Net8PeriodsAgo = "NET8PA";

            /// <summary>
            /// Property for Net9PeriodsAgo
            /// </summary>
            public const string Net9PeriodsAgo = "NET9PA";

            /// <summary>
            /// Property for Net10PeriodsAgo
            /// </summary>
            public const string Net10PeriodsAgo = "NET10PA";

            /// <summary>
            /// Property for Net11PeriodsAgo
            /// </summary>
            public const string Net11PeriodsAgo = "NET11PA";

            /// <summary>
            /// Property for Net12PeriodsAgo
            /// </summary>
            public const string Net12PeriodsAgo = "NET12PA";

            /// <summary>
            /// Property for Net13PeriodsAgo
            /// </summary>
            public const string Net13PeriodsAgo = "NET13PA";

            /// <summary>
            /// Property for NetCurrentQuarter
            /// </summary>
            public const string NetCurrentQuarter = "NETQ";

            /// <summary>
            /// Property for NetLastQuarter
            /// </summary>
            public const string NetLastQuarter = "NETLQ";

            /// <summary>
            /// Property for NetQuarter1
            /// </summary>
            public const string NetQuarter1 = "NET1Q";

            /// <summary>
            /// Property for NetQuarter2
            /// </summary>
            public const string NetQuarter2 = "NET2Q";

            /// <summary>
            /// Property for NetQuarter3
            /// </summary>
            public const string NetQuarter3 = "NET3Q";

            /// <summary>
            /// Property for NetQuarter4
            /// </summary>
            public const string NetQuarter4 = "NET4Q";

            /// <summary>
            /// Property for NetQuarter1ToDate
            /// </summary>
            public const string NetQuarter1ToDate = "NET1QTD";

            /// <summary>
            /// Property for NetQuarter2ToDate
            /// </summary>
            public const string NetQuarter2ToDate = "NET2QTD";

            /// <summary>
            /// Property for NetQuarter3ToDate
            /// </summary>
            public const string NetQuarter3ToDate = "NET3QTD";

            /// <summary>
            /// Property for NetQuarter4ToDate
            /// </summary>
            public const string NetQuarter4ToDate = "NET4QTD";

            /// <summary>
            /// Property for NetPreceedingQuarter
            /// </summary>
            public const string NetPreceedingQuarter = "NETPQ";

            /// <summary>
            /// Property for NetPreceedingQuarter1PAgo
            /// </summary>
            public const string NetPreceedingQuarter1PAgo = "NETPQ1PA";

            /// <summary>
            /// Property for NetPreceedingQuarter2PAgo
            /// </summary>
            public const string NetPreceedingQuarter2PAgo = "NETPQ2PA";

            /// <summary>
            /// Property for NetPreceedingQuarter3PAgo
            /// </summary>
            public const string NetPreceedingQuarter3PAgo = "NETPQ3PA";

            /// <summary>
            /// Property for NetPreceedingQuarter4PAgo
            /// </summary>
            public const string NetPreceedingQuarter4PAgo = "NETPQ4PA";

            /// <summary>
            /// Property for NetPreceedingQuarter5PAgo
            /// </summary>
            public const string NetPreceedingQuarter5PAgo = "NETPQ5PA";

            /// <summary>
            /// Property for NetPreceedingQuarter6PAgo
            /// </summary>
            public const string NetPreceedingQuarter6PAgo = "NETPQ6PA";

            /// <summary>
            /// Property for NetPreceedingQuarter7PAgo
            /// </summary>
            public const string NetPreceedingQuarter7PAgo = "NETPQ7PA";

            /// <summary>
            /// Property for NetPreceedingQuarter8PAgo
            /// </summary>
            public const string NetPreceedingQuarter8PAgo = "NETPQ8PA";

            /// <summary>
            /// Property for NetPreceedingQuarter9PAgo
            /// </summary>
            public const string NetPreceedingQuarter9PAgo = "NETPQ9PA";

            /// <summary>
            /// Property for NetPreceedingQuarter10PAgo
            /// </summary>
            public const string NetPreceedingQuarter10PAgo = "NETPQ10PA";

            /// <summary>
            /// Property for NetPreceedingQuarter11PAgo
            /// </summary>
            public const string NetPreceedingQuarter11PAgo = "NETPQ11PA";

            /// <summary>
            /// Property for NetPreceedingQuarter12PAgo
            /// </summary>
            public const string NetPreceedingQuarter12PAgo = "NETPQ12PA";

            /// <summary>
            /// Property for NetPreceedingQuarter13PAgo
            /// </summary>
            public const string NetPreceedingQuarter13PAgo = "NETPQ13PA";

            /// <summary>
            /// Property for Net1QuarterAgo
            /// </summary>
            public const string Net1QuarterAgo = "NET1QA";

            /// <summary>
            /// Property for Net2QuartersAgo
            /// </summary>
            public const string Net2QuartersAgo = "NET2QA";

            /// <summary>
            /// Property for Net3QuartersAgo
            /// </summary>
            public const string Net3QuartersAgo = "NET3QA";

            /// <summary>
            /// Property for Net4QuartersAgo
            /// </summary>
            public const string Net4QuartersAgo = "NET4QA";

            /// <summary>
            /// Property for NetCurrentHalfYear
            /// </summary>
            public const string NetCurrentHalfYear = "NETS";

            /// <summary>
            /// Property for NetLastHalfYear
            /// </summary>
            public const string NetLastHalfYear = "NETLS";

            /// <summary>
            /// Property for NetHalfYear1
            /// </summary>
            public const string NetHalfYear1 = "NET1S";

            /// <summary>
            /// Property for NetHalfYear2
            /// </summary>
            public const string NetHalfYear2 = "NET2S";

            /// <summary>
            /// Property for NetPreceedingHalfYear
            /// </summary>
            public const string NetPreceedingHalfYear = "NETPS";

            /// <summary>
            /// Property for NetHalfYear1ToDate
            /// </summary>
            public const string NetHalfYear1ToDate = "NET1STD";

            /// <summary>
            /// Property for NetHalfYear2ToDate
            /// </summary>
            public const string NetHalfYear2ToDate = "NET2STD";

            /// <summary>
            /// Property for NetPreceedingHalfYear1PAgo
            /// </summary>
            public const string NetPreceedingHalfYear1PAgo = "NETPS1PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear2PAgo
            /// </summary>
            public const string NetPreceedingHalfYear2PAgo = "NETPS2PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear3PAgo
            /// </summary>
            public const string NetPreceedingHalfYear3PAgo = "NETPS3PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear4PAgo
            /// </summary>
            public const string NetPreceedingHalfYear4PAgo = "NETPS4PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear5PAgo
            /// </summary>
            public const string NetPreceedingHalfYear5PAgo = "NETPS5PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear6PAgo
            /// </summary>
            public const string NetPreceedingHalfYear6PAgo = "NETPS6PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear7PAgo
            /// </summary>
            public const string NetPreceedingHalfYear7PAgo = "NETPS7PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear8PAgo
            /// </summary>
            public const string NetPreceedingHalfYear8PAgo = "NETPS8PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear9PAgo
            /// </summary>
            public const string NetPreceedingHalfYear9PAgo = "NETPS9PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear10PAgo
            /// </summary>
            public const string NetPreceedingHalfYear10PAgo = "NETPS10PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear11PAgo
            /// </summary>
            public const string NetPreceedingHalfYear11PAgo = "NETPS11PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear12PAgo
            /// </summary>
            public const string NetPreceedingHalfYear12PAgo = "NETPS12PA";

            /// <summary>
            /// Property for NetPreceedingHalfYear13PAgo
            /// </summary>
            public const string NetPreceedingHalfYear13PAgo = "NETPS13PA";

            /// <summary>
            /// Property for Net1HalfYearAgo
            /// </summary>
            public const string Net1HalfYearAgo = "NET1SA";

            /// <summary>
            /// Property for Net2HalfYearsAgo
            /// </summary>
            public const string Net2HalfYearsAgo = "NET2SA";

            /// <summary>
            /// Property for NetTotalYear
            /// </summary>
            public const string NetTotalYear = "NETY";

            /// <summary>
            /// Property for NetYearToDate
            /// </summary>
            public const string NetYearToDate = "NETYTD";

            /// <summary>
            /// Property for NetPreceedingYear
            /// </summary>
            public const string NetPreceedingYear = "NETPY";

            /// <summary>
            /// Property for NetPreceedingYear1PAgo
            /// </summary>
            public const string NetPreceedingYear1PAgo = "NETPY1PA";

            /// <summary>
            /// Property for NetPreceedingYear2PAgo
            /// </summary>
            public const string NetPreceedingYear2PAgo = "NETPY2PA";

            /// <summary>
            /// Property for NetPreceedingYear3PAgo
            /// </summary>
            public const string NetPreceedingYear3PAgo = "NETPY3PA";

            /// <summary>
            /// Property for NetPreceedingYear4PAgo
            /// </summary>
            public const string NetPreceedingYear4PAgo = "NETPY4PA";

            /// <summary>
            /// Property for NetPreceedingYear5PAgo
            /// </summary>
            public const string NetPreceedingYear5PAgo = "NETPY5PA";

            /// <summary>
            /// Property for NetPreceedingYear6PAgo
            /// </summary>
            public const string NetPreceedingYear6PAgo = "NETPY6PA";

            /// <summary>
            /// Property for NetPreceedingYear7PAgo
            /// </summary>
            public const string NetPreceedingYear7PAgo = "NETPY7PA";

            /// <summary>
            /// Property for NetPreceedingYear8PAgo
            /// </summary>
            public const string NetPreceedingYear8PAgo = "NETPY8PA";

            /// <summary>
            /// Property for NetPreceedingYear9PAgo
            /// </summary>
            public const string NetPreceedingYear9PAgo = "NETPY9PA";

            /// <summary>
            /// Property for NetPreceedingYear10PAgo
            /// </summary>
            public const string NetPreceedingYear10PAgo = "NETPY10PA";

            /// <summary>
            /// Property for NetPreceedingYear11PAgo
            /// </summary>
            public const string NetPreceedingYear11PAgo = "NETPY11PA";

            /// <summary>
            /// Property for NetPreceedingYear12PAgo
            /// </summary>
            public const string NetPreceedingYear12PAgo = "NETPY12PA";

            /// <summary>
            /// Property for NetPreceedingYear13PAgo
            /// </summary>
            public const string NetPreceedingYear13PAgo = "NETPY13PA";

            /// <summary>
            /// Property for NetAdjustments
            /// </summary>
            public const string NetAdjustments = "NETADJ";

            /// <summary>
            /// Property for ClosingBalance
            /// </summary>
            public const string ClosingBalance = "BALCLOSE";

            /// <summary>
            /// Property for NetClosingAmount
            /// </summary>
            public const string NetClosingAmount = "NETCLOSE";

            /// <summary>
            /// Property for BalanceQuarterToDate
            /// </summary>
            public const string BalanceQuarterToDate = "BALQTD";

            /// <summary>
            /// Property for BalanceLastQuarterToDate
            /// </summary>
            public const string BalanceLastQuarterToDate = "BALLQTD";

            /// <summary>
            /// Property for Balance1QuarterAgoToDate
            /// </summary>
            public const string Balance1QuarterAgoToDate = "BAL1QATD";

            /// <summary>
            /// Property for Balance2QuartersAgoToDate
            /// </summary>
            public const string Balance2QuartersAgoToDate = "BAL2QATD";

            /// <summary>
            /// Property for Balance3QuartersAgoToDate
            /// </summary>
            public const string Balance3QuartersAgoToDate = "BAL3QATD";

            /// <summary>
            /// Property for Balance4QuartersAgoToDate
            /// </summary>
            public const string Balance4QuartersAgoToDate = "BAL4QATD";

            /// <summary>
            /// Property for BalanceHalfYearToDate
            /// </summary>
            public const string BalanceHalfYearToDate = "BALSTD";

            /// <summary>
            /// Property for BalanceLastHalfYearToDate
            /// </summary>
            public const string BalanceLastHalfYearToDate = "BALLSTD";

            /// <summary>
            /// Property for Balance1HalfYearAgoToDate
            /// </summary>
            public const string Balance1HalfYearAgoToDate = "BAL1SATD";

            /// <summary>
            /// Property for Balance2HalfYearsAgoToDate
            /// </summary>
            public const string Balance2HalfYearsAgoToDate = "BAL2SATD";

            /// <summary>
            /// Property for NetQuarterToDate
            /// </summary>
            public const string NetQuarterToDate = "NETQTD";

            /// <summary>
            /// Property for NetLastQuarterToDate
            /// </summary>
            public const string NetLastQuarterToDate = "NETLQTD";

            /// <summary>
            /// Property for Net1QuarterAgoToDate
            /// </summary>
            public const string Net1QuarterAgoToDate = "NET1QATD";

            /// <summary>
            /// Property for Net2QuartersAgoToDate
            /// </summary>
            public const string Net2QuartersAgoToDate = "NET2QATD";

            /// <summary>
            /// Property for Net3QuartersAgoToDate
            /// </summary>
            public const string Net3QuartersAgoToDate = "NET3QATD";

            /// <summary>
            /// Property for Net4QuartersAgoToDate
            /// </summary>
            public const string Net4QuartersAgoToDate = "NET4QATD";

            /// <summary>
            /// Property for NetHalfYearToDate
            /// </summary>
            public const string NetHalfYearToDate = "NETSTD";

            /// <summary>
            /// Property for NetLastHalfYearToDate
            /// </summary>
            public const string NetLastHalfYearToDate = "NETLSTD";

            /// <summary>
            /// Property for Net1HalfYearAgoToDate
            /// </summary>
            public const string Net1HalfYearAgoToDate = "NET1SATD";

            /// <summary>
            /// Property for Net2HalfYearsAgoToDate
            /// </summary>
            public const string Net2HalfYearsAgoToDate = "NET2SATD";

            /// <summary>
            /// Property for BalPreceedingQuarter
            /// </summary>
            public const string BalPreceedingQuarter = "BALPQ";

            /// <summary>
            /// Property for BalPreceedingQuarter1PAgo
            /// </summary>
            public const string BalPreceedingQuarter1PAgo = "BALPQ1PA";

            /// <summary>
            /// Property for BalPreceedingQuarter2PAgo
            /// </summary>
            public const string BalPreceedingQuarter2PAgo = "BALPQ2PA";

            /// <summary>
            /// Property for BalPreceedingQuarter3PAgo
            /// </summary>
            public const string BalPreceedingQuarter3PAgo = "BALPQ3PA";

            /// <summary>
            /// Property for BalPreceedingQuarter4PAgo
            /// </summary>
            public const string BalPreceedingQuarter4PAgo = "BALPQ4PA";

            /// <summary>
            /// Property for BalPreceedingQuarter5PAgo
            /// </summary>
            public const string BalPreceedingQuarter5PAgo = "BALPQ5PA";

            /// <summary>
            /// Property for BalPreceedingQuarter6PAgo
            /// </summary>
            public const string BalPreceedingQuarter6PAgo = "BALPQ6PA";

            /// <summary>
            /// Property for BalPreceedingQuarter7PAgo
            /// </summary>
            public const string BalPreceedingQuarter7PAgo = "BALPQ7PA";

            /// <summary>
            /// Property for BalPreceedingQuarter8PAgo
            /// </summary>
            public const string BalPreceedingQuarter8PAgo = "BALPQ8PA";

            /// <summary>
            /// Property for BalPreceedingQuarter9PAgo
            /// </summary>
            public const string BalPreceedingQuarter9PAgo = "BALPQ9PA";

            /// <summary>
            /// Property for BalPreceedingQuarter10PAgo
            /// </summary>
            public const string BalPreceedingQuarter10PAgo = "BALPQ10PA";

            /// <summary>
            /// Property for BalPreceedingQuarter11PAgo
            /// </summary>
            public const string BalPreceedingQuarter11PAgo = "BALPQ11PA";

            /// <summary>
            /// Property for BalPreceedingQuarter12PAgo
            /// </summary>
            public const string BalPreceedingQuarter12PAgo = "BALPQ12PA";

            /// <summary>
            /// Property for BalPreceedingQuarter13PAgo
            /// </summary>
            public const string BalPreceedingQuarter13PAgo = "BALPQ13PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear
            /// </summary>
            public const string BalPreceedingHalfYear = "BALPS";

            /// <summary>
            /// Property for BalPreceedingHalfYear1PAgo
            /// </summary>
            public const string BalPreceedingHalfYear1PAgo = "BALPS1PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear2PAgo
            /// </summary>
            public const string BalPreceedingHalfYear2PAgo = "BALPS2PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear3PAgo
            /// </summary>
            public const string BalPreceedingHalfYear3PAgo = "BALPS3PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear4PAgo
            /// </summary>
            public const string BalPreceedingHalfYear4PAgo = "BALPS4PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear5PAgo
            /// </summary>
            public const string BalPreceedingHalfYear5PAgo = "BALPS5PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear6PAgo
            /// </summary>
            public const string BalPreceedingHalfYear6PAgo = "BALPS6PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear7PAgo
            /// </summary>
            public const string BalPreceedingHalfYear7PAgo = "BALPS7PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear8PAgo
            /// </summary>
            public const string BalPreceedingHalfYear8PAgo = "BALPS8PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear9PAgo
            /// </summary>
            public const string BalPreceedingHalfYear9PAgo = "BALPS9PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear10PAgo
            /// </summary>
            public const string BalPreceedingHalfYear10PAgo = "BALPS10PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear11PAgo
            /// </summary>
            public const string BalPreceedingHalfYear11PAgo = "BALPS11PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear12PAgo
            /// </summary>
            public const string BalPreceedingHalfYear12PAgo = "BALPS12PA";

            /// <summary>
            /// Property for BalPreceedingHalfYear13PAgo
            /// </summary>
            public const string BalPreceedingHalfYear13PAgo = "BALPS13PA";

            /// <summary>
            /// Property for BalPreceedingYear
            /// </summary>
            public const string BalPreceedingYear = "BALPY";

            /// <summary>
            /// Property for BalPreceedingYear1PAgo
            /// </summary>
            public const string BalPreceedingYear1PAgo = "BALPY1PA";

            /// <summary>
            /// Property for BalPreceedingYear2PAgo
            /// </summary>
            public const string BalPreceedingYear2PAgo = "BALPY2PA";

            /// <summary>
            /// Property for BalPreceedingYear3PAgo
            /// </summary>
            public const string BalPreceedingYear3PAgo = "BALPY3PA";

            /// <summary>
            /// Property for BalPreceedingYear4PAgo
            /// </summary>
            public const string BalPreceedingYear4PAgo = "BALPY4PA";

            /// <summary>
            /// Property for BalPreceedingYear5PAgo
            /// </summary>
            public const string BalPreceedingYear5PAgo = "BALPY5PA";

            /// <summary>
            /// Property for BalPreceedingYear6PAgo
            /// </summary>
            public const string BalPreceedingYear6PAgo = "BALPY6PA";

            /// <summary>
            /// Property for BalPreceedingYear7PAgo
            /// </summary>
            public const string BalPreceedingYear7PAgo = "BALPY7PA";

            /// <summary>
            /// Property for BalPreceedingYear8PAgo
            /// </summary>
            public const string BalPreceedingYear8PAgo = "BALPY8PA";

            /// <summary>
            /// Property for BalPreceedingYear9PAgo
            /// </summary>
            public const string BalPreceedingYear9PAgo = "BALPY9PA";

            /// <summary>
            /// Property for BalPreceedingYear10PAgo
            /// </summary>
            public const string BalPreceedingYear10PAgo = "BALPY10PA";

            /// <summary>
            /// Property for BalPreceedingYear11PAgo
            /// </summary>
            public const string BalPreceedingYear11PAgo = "BALPY11PA";

            /// <summary>
            /// Property for BalPreceedingYear12PAgo
            /// </summary>
            public const string BalPreceedingYear12PAgo = "BALPY12PA";

            /// <summary>
            /// Property for BalPreceedingYear13PAgo
            /// </summary>
            public const string BalPreceedingYear13PAgo = "BALPY13PA";

            /// <summary>
            /// Property for BudgetOpeningBalanceSwitch
            /// </summary>
            public const string BudgetOpeningBalanceSwitch = "BUDGETSW";

            /// <summary>
            /// Property for QuantityOpeningBalanceSwitch
            /// </summary>
            public const string QuantityOpeningBalanceSwitch = "QTYSW";

            /// <summary>
            /// Property for AdditionalFRTRNFilter
            /// </summary>
            public const string AdditionalFRTRNFilter = "GLPOSTFIL";

            /// <summary>
            /// Property for TableGLPOSTSwitch
            /// </summary>
            public const string TableGLPOSTSwitch = "ACCESSSW";

            /// <summary>
            /// Property for FRTRNSwitch
            /// </summary>
            public const string FRTRNSwitch = "GETSW";

            /// <summary>
            /// Property for AccountBalOf1StFRTRNRecord
            /// </summary>
            public const string AccountBalOf1StFRTRNRecord = "ACCTBAL";

            /// <summary>
            /// Property for FRTRNBrowsingOrder
            /// </summary>
            public const string FRTRNBrowsingOrder = "GLPOSTORD";

            /// <summary>
            /// Property for RollupSwitch
            /// </summary>
            public const string RollupSwitch = "ROLLUPSW";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of FinancialReportInformation Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for AccountNumber
            /// </summary>
            public const int AccountNumber = 1;

            /// <summary>
            /// Property Indexer for ReportingYear
            /// </summary>
            public const int ReportingYear = 2;

            /// <summary>
            /// Property Indexer for FiscalSetDesignator
            /// </summary>
            public const int FiscalSetDesignator = 3;

            /// <summary>
            /// Property Indexer for CurrencyCode
            /// </summary>
            public const int CurrencyCode = 4;

            /// <summary>
            /// Property Indexer for CurrencyType
            /// </summary>
            public const int CurrencyType = 5;

            /// <summary>
            /// Property Indexer for FiscalSetType
            /// </summary>
            public const int FiscalSetType = 6;

            /// <summary>
            /// Property Indexer for ReportingYearOffset
            /// </summary>
            public const int ReportingYearOffset = 7;

            /// <summary>
            /// Property Indexer for ReportingPeriod
            /// </summary>
            public const int ReportingPeriod = 8;

            /// <summary>
            /// Property Indexer for BalanceCurrentPeriod
            /// </summary>
            public const int BalanceCurrentPeriod = 9;

            /// <summary>
            /// Property Indexer for BalanceLastPeriod
            /// </summary>
            public const int BalanceLastPeriod = 10;

            /// <summary>
            /// Property Indexer for BalancePeriod1
            /// </summary>
            public const int BalancePeriod1 = 11;

            /// <summary>
            /// Property Indexer for BalancePeriod2
            /// </summary>
            public const int BalancePeriod2 = 12;

            /// <summary>
            /// Property Indexer for BalancePeriod3
            /// </summary>
            public const int BalancePeriod3 = 13;

            /// <summary>
            /// Property Indexer for BalancePeriod4
            /// </summary>
            public const int BalancePeriod4 = 14;

            /// <summary>
            /// Property Indexer for BalancePeriod5
            /// </summary>
            public const int BalancePeriod5 = 15;

            /// <summary>
            /// Property Indexer for BalancePeriod6
            /// </summary>
            public const int BalancePeriod6 = 16;

            /// <summary>
            /// Property Indexer for BalancePeriod7
            /// </summary>
            public const int BalancePeriod7 = 17;

            /// <summary>
            /// Property Indexer for BalancePeriod8
            /// </summary>
            public const int BalancePeriod8 = 18;

            /// <summary>
            /// Property Indexer for BalancePeriod9
            /// </summary>
            public const int BalancePeriod9 = 19;

            /// <summary>
            /// Property Indexer for BalancePeriod10
            /// </summary>
            public const int BalancePeriod10 = 20;

            /// <summary>
            /// Property Indexer for BalancePeriod11
            /// </summary>
            public const int BalancePeriod11 = 21;

            /// <summary>
            /// Property Indexer for BalancePeriod12
            /// </summary>
            public const int BalancePeriod12 = 22;

            /// <summary>
            /// Property Indexer for BalancePeriod13
            /// </summary>
            public const int BalancePeriod13 = 23;

            /// <summary>
            /// Property Indexer for Balance1PeriodAgo
            /// </summary>
            public const int Balance1PeriodAgo = 24;

            /// <summary>
            /// Property Indexer for Balance2PeriodsAgo
            /// </summary>
            public const int Balance2PeriodsAgo = 25;

            /// <summary>
            /// Property Indexer for Balance3PeriodsAgo
            /// </summary>
            public const int Balance3PeriodsAgo = 26;

            /// <summary>
            /// Property Indexer for Balance4PeriodsAgo
            /// </summary>
            public const int Balance4PeriodsAgo = 27;

            /// <summary>
            /// Property Indexer for Balance5PeriodsAgo
            /// </summary>
            public const int Balance5PeriodsAgo = 28;

            /// <summary>
            /// Property Indexer for Balance6PeriodsAgo
            /// </summary>
            public const int Balance6PeriodsAgo = 29;

            /// <summary>
            /// Property Indexer for Balance7PeriodsAgo
            /// </summary>
            public const int Balance7PeriodsAgo = 30;

            /// <summary>
            /// Property Indexer for Balance8PeriodsAgo
            /// </summary>
            public const int Balance8PeriodsAgo = 31;

            /// <summary>
            /// Property Indexer for Balance9PeriodsAgo
            /// </summary>
            public const int Balance9PeriodsAgo = 32;

            /// <summary>
            /// Property Indexer for Balance10PeriodsAgo
            /// </summary>
            public const int Balance10PeriodsAgo = 33;

            /// <summary>
            /// Property Indexer for Balance11PeriodsAgo
            /// </summary>
            public const int Balance11PeriodsAgo = 34;

            /// <summary>
            /// Property Indexer for Balance12PeriodsAgo
            /// </summary>
            public const int Balance12PeriodsAgo = 35;

            /// <summary>
            /// Property Indexer for Balance13PeriodsAgo
            /// </summary>
            public const int Balance13PeriodsAgo = 36;

            /// <summary>
            /// Property Indexer for BalanceCurrentQuarter
            /// </summary>
            public const int BalanceCurrentQuarter = 37;

            /// <summary>
            /// Property Indexer for BalanceLastQuarter
            /// </summary>
            public const int BalanceLastQuarter = 38;

            /// <summary>
            /// Property Indexer for BalanceQuarter1
            /// </summary>
            public const int BalanceQuarter1 = 39;

            /// <summary>
            /// Property Indexer for BalanceQuarter2
            /// </summary>
            public const int BalanceQuarter2 = 40;

            /// <summary>
            /// Property Indexer for BalanceQuarter3
            /// </summary>
            public const int BalanceQuarter3 = 41;

            /// <summary>
            /// Property Indexer for BalanceQuarter4
            /// </summary>
            public const int BalanceQuarter4 = 42;

            /// <summary>
            /// Property Indexer for BalanceQuarter1ToDate
            /// </summary>
            public const int BalanceQuarter1ToDate = 43;

            /// <summary>
            /// Property Indexer for BalanceQuarter2ToDate
            /// </summary>
            public const int BalanceQuarter2ToDate = 44;

            /// <summary>
            /// Property Indexer for BalanceQuarter3ToDate
            /// </summary>
            public const int BalanceQuarter3ToDate = 45;

            /// <summary>
            /// Property Indexer for BalanceQuarter4ToDate
            /// </summary>
            public const int BalanceQuarter4ToDate = 46;

            /// <summary>
            /// Property Indexer for Balance1QuarterAgo
            /// </summary>
            public const int Balance1QuarterAgo = 47;

            /// <summary>
            /// Property Indexer for Balance2QuartersAgo
            /// </summary>
            public const int Balance2QuartersAgo = 48;

            /// <summary>
            /// Property Indexer for Balance3QuartersAgo
            /// </summary>
            public const int Balance3QuartersAgo = 49;

            /// <summary>
            /// Property Indexer for Balance4QuartersAgo
            /// </summary>
            public const int Balance4QuartersAgo = 50;

            /// <summary>
            /// Property Indexer for BalanceCurrentHalfYear
            /// </summary>
            public const int BalanceCurrentHalfYear = 51;

            /// <summary>
            /// Property Indexer for BalanceLastHalfYear
            /// </summary>
            public const int BalanceLastHalfYear = 52;

            /// <summary>
            /// Property Indexer for BalanceHalfYear1
            /// </summary>
            public const int BalanceHalfYear1 = 53;

            /// <summary>
            /// Property Indexer for BalanceHalfYear2
            /// </summary>
            public const int BalanceHalfYear2 = 54;

            /// <summary>
            /// Property Indexer for BalanceHalfYear1ToDate
            /// </summary>
            public const int BalanceHalfYear1ToDate = 55;

            /// <summary>
            /// Property Indexer for BalanceHalfYear2ToDate
            /// </summary>
            public const int BalanceHalfYear2ToDate = 56;

            /// <summary>
            /// Property Indexer for Balance1HalfYearAgo
            /// </summary>
            public const int Balance1HalfYearAgo = 57;

            /// <summary>
            /// Property Indexer for Balance2HalfYearsAgo
            /// </summary>
            public const int Balance2HalfYearsAgo = 58;

            /// <summary>
            /// Property Indexer for BalanceTotalYear
            /// </summary>
            public const int BalanceTotalYear = 59;

            /// <summary>
            /// Property Indexer for BalanceYearToDate
            /// </summary>
            public const int BalanceYearToDate = 60;

            /// <summary>
            /// Property Indexer for BalanceBeginningOfYear
            /// </summary>
            public const int BalanceBeginningOfYear = 61;

            /// <summary>
            /// Property Indexer for NetCurrentPeriod
            /// </summary>
            public const int NetCurrentPeriod = 62;

            /// <summary>
            /// Property Indexer for NetLastPeriod
            /// </summary>
            public const int NetLastPeriod = 63;

            /// <summary>
            /// Property Indexer for NetPeriod1
            /// </summary>
            public const int NetPeriod1 = 64;

            /// <summary>
            /// Property Indexer for NetPeriod2
            /// </summary>
            public const int NetPeriod2 = 65;

            /// <summary>
            /// Property Indexer for NetPeriod3
            /// </summary>
            public const int NetPeriod3 = 66;

            /// <summary>
            /// Property Indexer for NetPeriod4
            /// </summary>
            public const int NetPeriod4 = 67;

            /// <summary>
            /// Property Indexer for NetPeriod5
            /// </summary>
            public const int NetPeriod5 = 68;

            /// <summary>
            /// Property Indexer for NetPeriod6
            /// </summary>
            public const int NetPeriod6 = 69;

            /// <summary>
            /// Property Indexer for NetPeriod7
            /// </summary>
            public const int NetPeriod7 = 70;

            /// <summary>
            /// Property Indexer for NetPeriod8
            /// </summary>
            public const int NetPeriod8 = 71;

            /// <summary>
            /// Property Indexer for NetPeriod9
            /// </summary>
            public const int NetPeriod9 = 72;

            /// <summary>
            /// Property Indexer for NetPeriod10
            /// </summary>
            public const int NetPeriod10 = 73;

            /// <summary>
            /// Property Indexer for NetPeriod11
            /// </summary>
            public const int NetPeriod11 = 74;

            /// <summary>
            /// Property Indexer for NetPeriod12
            /// </summary>
            public const int NetPeriod12 = 75;

            /// <summary>
            /// Property Indexer for NetPeriod13
            /// </summary>
            public const int NetPeriod13 = 76;

            /// <summary>
            /// Property Indexer for Net1PeriodAgo
            /// </summary>
            public const int Net1PeriodAgo = 77;

            /// <summary>
            /// Property Indexer for Net2PeriodsAgo
            /// </summary>
            public const int Net2PeriodsAgo = 78;

            /// <summary>
            /// Property Indexer for Net3PeriodsAgo
            /// </summary>
            public const int Net3PeriodsAgo = 79;

            /// <summary>
            /// Property Indexer for Net4PeriodsAgo
            /// </summary>
            public const int Net4PeriodsAgo = 80;

            /// <summary>
            /// Property Indexer for Net5PeriodsAgo
            /// </summary>
            public const int Net5PeriodsAgo = 81;

            /// <summary>
            /// Property Indexer for Net6PeriodsAgo
            /// </summary>
            public const int Net6PeriodsAgo = 82;

            /// <summary>
            /// Property Indexer for Net7PeriodsAgo
            /// </summary>
            public const int Net7PeriodsAgo = 83;

            /// <summary>
            /// Property Indexer for Net8PeriodsAgo
            /// </summary>
            public const int Net8PeriodsAgo = 84;

            /// <summary>
            /// Property Indexer for Net9PeriodsAgo
            /// </summary>
            public const int Net9PeriodsAgo = 85;

            /// <summary>
            /// Property Indexer for Net10PeriodsAgo
            /// </summary>
            public const int Net10PeriodsAgo = 86;

            /// <summary>
            /// Property Indexer for Net11PeriodsAgo
            /// </summary>
            public const int Net11PeriodsAgo = 87;

            /// <summary>
            /// Property Indexer for Net12PeriodsAgo
            /// </summary>
            public const int Net12PeriodsAgo = 88;

            /// <summary>
            /// Property Indexer for Net13PeriodsAgo
            /// </summary>
            public const int Net13PeriodsAgo = 89;

            /// <summary>
            /// Property Indexer for NetCurrentQuarter
            /// </summary>
            public const int NetCurrentQuarter = 90;

            /// <summary>
            /// Property Indexer for NetLastQuarter
            /// </summary>
            public const int NetLastQuarter = 91;

            /// <summary>
            /// Property Indexer for NetQuarter1
            /// </summary>
            public const int NetQuarter1 = 92;

            /// <summary>
            /// Property Indexer for NetQuarter2
            /// </summary>
            public const int NetQuarter2 = 93;

            /// <summary>
            /// Property Indexer for NetQuarter3
            /// </summary>
            public const int NetQuarter3 = 94;

            /// <summary>
            /// Property Indexer for NetQuarter4
            /// </summary>
            public const int NetQuarter4 = 95;

            /// <summary>
            /// Property Indexer for NetQuarter1ToDate
            /// </summary>
            public const int NetQuarter1ToDate = 96;

            /// <summary>
            /// Property Indexer for NetQuarter2ToDate
            /// </summary>
            public const int NetQuarter2ToDate = 97;

            /// <summary>
            /// Property Indexer for NetQuarter3ToDate
            /// </summary>
            public const int NetQuarter3ToDate = 98;

            /// <summary>
            /// Property Indexer for NetQuarter4ToDate
            /// </summary>
            public const int NetQuarter4ToDate = 99;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter
            /// </summary>
            public const int NetPreceedingQuarter = 100;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter1PAgo
            /// </summary>
            public const int NetPreceedingQuarter1PAgo = 101;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter2PAgo
            /// </summary>
            public const int NetPreceedingQuarter2PAgo = 102;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter3PAgo
            /// </summary>
            public const int NetPreceedingQuarter3PAgo = 103;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter4PAgo
            /// </summary>
            public const int NetPreceedingQuarter4PAgo = 104;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter5PAgo
            /// </summary>
            public const int NetPreceedingQuarter5PAgo = 105;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter6PAgo
            /// </summary>
            public const int NetPreceedingQuarter6PAgo = 106;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter7PAgo
            /// </summary>
            public const int NetPreceedingQuarter7PAgo = 107;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter8PAgo
            /// </summary>
            public const int NetPreceedingQuarter8PAgo = 108;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter9PAgo
            /// </summary>
            public const int NetPreceedingQuarter9PAgo = 109;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter10PAgo
            /// </summary>
            public const int NetPreceedingQuarter10PAgo = 110;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter11PAgo
            /// </summary>
            public const int NetPreceedingQuarter11PAgo = 111;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter12PAgo
            /// </summary>
            public const int NetPreceedingQuarter12PAgo = 112;

            /// <summary>
            /// Property Indexer for NetPreceedingQuarter13PAgo
            /// </summary>
            public const int NetPreceedingQuarter13PAgo = 113;

            /// <summary>
            /// Property Indexer for Net1QuarterAgo
            /// </summary>
            public const int Net1QuarterAgo = 114;

            /// <summary>
            /// Property Indexer for Net2QuartersAgo
            /// </summary>
            public const int Net2QuartersAgo = 115;

            /// <summary>
            /// Property Indexer for Net3QuartersAgo
            /// </summary>
            public const int Net3QuartersAgo = 116;

            /// <summary>
            /// Property Indexer for Net4QuartersAgo
            /// </summary>
            public const int Net4QuartersAgo = 117;

            /// <summary>
            /// Property Indexer for NetCurrentHalfYear
            /// </summary>
            public const int NetCurrentHalfYear = 118;

            /// <summary>
            /// Property Indexer for NetLastHalfYear
            /// </summary>
            public const int NetLastHalfYear = 119;

            /// <summary>
            /// Property Indexer for NetHalfYear1
            /// </summary>
            public const int NetHalfYear1 = 120;

            /// <summary>
            /// Property Indexer for NetHalfYear2
            /// </summary>
            public const int NetHalfYear2 = 121;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear
            /// </summary>
            public const int NetPreceedingHalfYear = 122;

            /// <summary>
            /// Property Indexer for NetHalfYear1ToDate
            /// </summary>
            public const int NetHalfYear1ToDate = 123;

            /// <summary>
            /// Property Indexer for NetHalfYear2ToDate
            /// </summary>
            public const int NetHalfYear2ToDate = 124;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear1PAgo
            /// </summary>
            public const int NetPreceedingHalfYear1PAgo = 125;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear2PAgo
            /// </summary>
            public const int NetPreceedingHalfYear2PAgo = 126;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear3PAgo
            /// </summary>
            public const int NetPreceedingHalfYear3PAgo = 127;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear4PAgo
            /// </summary>
            public const int NetPreceedingHalfYear4PAgo = 128;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear5PAgo
            /// </summary>
            public const int NetPreceedingHalfYear5PAgo = 129;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear6PAgo
            /// </summary>
            public const int NetPreceedingHalfYear6PAgo = 130;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear7PAgo
            /// </summary>
            public const int NetPreceedingHalfYear7PAgo = 131;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear8PAgo
            /// </summary>
            public const int NetPreceedingHalfYear8PAgo = 132;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear9PAgo
            /// </summary>
            public const int NetPreceedingHalfYear9PAgo = 133;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear10PAgo
            /// </summary>
            public const int NetPreceedingHalfYear10PAgo = 134;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear11PAgo
            /// </summary>
            public const int NetPreceedingHalfYear11PAgo = 135;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear12PAgo
            /// </summary>
            public const int NetPreceedingHalfYear12PAgo = 136;

            /// <summary>
            /// Property Indexer for NetPreceedingHalfYear13PAgo
            /// </summary>
            public const int NetPreceedingHalfYear13PAgo = 137;

            /// <summary>
            /// Property Indexer for Net1HalfYearAgo
            /// </summary>
            public const int Net1HalfYearAgo = 138;

            /// <summary>
            /// Property Indexer for Net2HalfYearsAgo
            /// </summary>
            public const int Net2HalfYearsAgo = 139;

            /// <summary>
            /// Property Indexer for NetTotalYear
            /// </summary>
            public const int NetTotalYear = 140;

            /// <summary>
            /// Property Indexer for NetYearToDate
            /// </summary>
            public const int NetYearToDate = 141;

            /// <summary>
            /// Property Indexer for NetPreceedingYear
            /// </summary>
            public const int NetPreceedingYear = 142;

            /// <summary>
            /// Property Indexer for NetPreceedingYear1PAgo
            /// </summary>
            public const int NetPreceedingYear1PAgo = 143;

            /// <summary>
            /// Property Indexer for NetPreceedingYear2PAgo
            /// </summary>
            public const int NetPreceedingYear2PAgo = 144;

            /// <summary>
            /// Property Indexer for NetPreceedingYear3PAgo
            /// </summary>
            public const int NetPreceedingYear3PAgo = 145;

            /// <summary>
            /// Property Indexer for NetPreceedingYear4PAgo
            /// </summary>
            public const int NetPreceedingYear4PAgo = 146;

            /// <summary>
            /// Property Indexer for NetPreceedingYear5PAgo
            /// </summary>
            public const int NetPreceedingYear5PAgo = 147;

            /// <summary>
            /// Property Indexer for NetPreceedingYear6PAgo
            /// </summary>
            public const int NetPreceedingYear6PAgo = 148;

            /// <summary>
            /// Property Indexer for NetPreceedingYear7PAgo
            /// </summary>
            public const int NetPreceedingYear7PAgo = 149;

            /// <summary>
            /// Property Indexer for NetPreceedingYear8PAgo
            /// </summary>
            public const int NetPreceedingYear8PAgo = 150;

            /// <summary>
            /// Property Indexer for NetPreceedingYear9PAgo
            /// </summary>
            public const int NetPreceedingYear9PAgo = 151;

            /// <summary>
            /// Property Indexer for NetPreceedingYear10PAgo
            /// </summary>
            public const int NetPreceedingYear10PAgo = 152;

            /// <summary>
            /// Property Indexer for NetPreceedingYear11PAgo
            /// </summary>
            public const int NetPreceedingYear11PAgo = 153;

            /// <summary>
            /// Property Indexer for NetPreceedingYear12PAgo
            /// </summary>
            public const int NetPreceedingYear12PAgo = 154;

            /// <summary>
            /// Property Indexer for NetPreceedingYear13PAgo
            /// </summary>
            public const int NetPreceedingYear13PAgo = 155;

            /// <summary>
            /// Property Indexer for NetAdjustments
            /// </summary>
            public const int NetAdjustments = 156;

            /// <summary>
            /// Property Indexer for ClosingBalance
            /// </summary>
            public const int ClosingBalance = 157;

            /// <summary>
            /// Property Indexer for NetClosingAmount
            /// </summary>
            public const int NetClosingAmount = 158;

            /// <summary>
            /// Property Indexer for BalanceQuarterToDate
            /// </summary>
            public const int BalanceQuarterToDate = 159;

            /// <summary>
            /// Property Indexer for BalanceLastQuarterToDate
            /// </summary>
            public const int BalanceLastQuarterToDate = 160;

            /// <summary>
            /// Property Indexer for Balance1QuarterAgoToDate
            /// </summary>
            public const int Balance1QuarterAgoToDate = 161;

            /// <summary>
            /// Property Indexer for Balance2QuartersAgoToDate
            /// </summary>
            public const int Balance2QuartersAgoToDate = 162;

            /// <summary>
            /// Property Indexer for Balance3QuartersAgoToDate
            /// </summary>
            public const int Balance3QuartersAgoToDate = 163;

            /// <summary>
            /// Property Indexer for Balance4QuartersAgoToDate
            /// </summary>
            public const int Balance4QuartersAgoToDate = 164;

            /// <summary>
            /// Property Indexer for BalanceHalfYearToDate
            /// </summary>
            public const int BalanceHalfYearToDate = 165;

            /// <summary>
            /// Property Indexer for BalanceLastHalfYearToDate
            /// </summary>
            public const int BalanceLastHalfYearToDate = 166;

            /// <summary>
            /// Property Indexer for Balance1HalfYearAgoToDate
            /// </summary>
            public const int Balance1HalfYearAgoToDate = 167;

            /// <summary>
            /// Property Indexer for Balance2HalfYearsAgoToDate
            /// </summary>
            public const int Balance2HalfYearsAgoToDate = 168;

            /// <summary>
            /// Property Indexer for NetQuarterToDate
            /// </summary>
            public const int NetQuarterToDate = 169;

            /// <summary>
            /// Property Indexer for NetLastQuarterToDate
            /// </summary>
            public const int NetLastQuarterToDate = 170;

            /// <summary>
            /// Property Indexer for Net1QuarterAgoToDate
            /// </summary>
            public const int Net1QuarterAgoToDate = 171;

            /// <summary>
            /// Property Indexer for Net2QuartersAgoToDate
            /// </summary>
            public const int Net2QuartersAgoToDate = 172;

            /// <summary>
            /// Property Indexer for Net3QuartersAgoToDate
            /// </summary>
            public const int Net3QuartersAgoToDate = 173;

            /// <summary>
            /// Property Indexer for Net4QuartersAgoToDate
            /// </summary>
            public const int Net4QuartersAgoToDate = 174;

            /// <summary>
            /// Property Indexer for NetHalfYearToDate
            /// </summary>
            public const int NetHalfYearToDate = 175;

            /// <summary>
            /// Property Indexer for NetLastHalfYearToDate
            /// </summary>
            public const int NetLastHalfYearToDate = 176;

            /// <summary>
            /// Property Indexer for Net1HalfYearAgoToDate
            /// </summary>
            public const int Net1HalfYearAgoToDate = 177;

            /// <summary>
            /// Property Indexer for Net2HalfYearsAgoToDate
            /// </summary>
            public const int Net2HalfYearsAgoToDate = 178;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter
            /// </summary>
            public const int BalPreceedingQuarter = 179;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter1PAgo
            /// </summary>
            public const int BalPreceedingQuarter1PAgo = 180;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter2PAgo
            /// </summary>
            public const int BalPreceedingQuarter2PAgo = 181;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter3PAgo
            /// </summary>
            public const int BalPreceedingQuarter3PAgo = 182;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter4PAgo
            /// </summary>
            public const int BalPreceedingQuarter4PAgo = 183;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter5PAgo
            /// </summary>
            public const int BalPreceedingQuarter5PAgo = 184;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter6PAgo
            /// </summary>
            public const int BalPreceedingQuarter6PAgo = 185;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter7PAgo
            /// </summary>
            public const int BalPreceedingQuarter7PAgo = 186;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter8PAgo
            /// </summary>
            public const int BalPreceedingQuarter8PAgo = 187;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter9PAgo
            /// </summary>
            public const int BalPreceedingQuarter9PAgo = 188;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter10PAgo
            /// </summary>
            public const int BalPreceedingQuarter10PAgo = 189;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter11PAgo
            /// </summary>
            public const int BalPreceedingQuarter11PAgo = 190;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter12PAgo
            /// </summary>
            public const int BalPreceedingQuarter12PAgo = 191;

            /// <summary>
            /// Property Indexer for BalPreceedingQuarter13PAgo
            /// </summary>
            public const int BalPreceedingQuarter13PAgo = 192;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear
            /// </summary>
            public const int BalPreceedingHalfYear = 193;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear1PAgo
            /// </summary>
            public const int BalPreceedingHalfYear1PAgo = 194;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear2PAgo
            /// </summary>
            public const int BalPreceedingHalfYear2PAgo = 195;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear3PAgo
            /// </summary>
            public const int BalPreceedingHalfYear3PAgo = 196;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear4PAgo
            /// </summary>
            public const int BalPreceedingHalfYear4PAgo = 197;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear5PAgo
            /// </summary>
            public const int BalPreceedingHalfYear5PAgo = 198;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear6PAgo
            /// </summary>
            public const int BalPreceedingHalfYear6PAgo = 199;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear7PAgo
            /// </summary>
            public const int BalPreceedingHalfYear7PAgo = 200;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear8PAgo
            /// </summary>
            public const int BalPreceedingHalfYear8PAgo = 201;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear9PAgo
            /// </summary>
            public const int BalPreceedingHalfYear9PAgo = 202;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear10PAgo
            /// </summary>
            public const int BalPreceedingHalfYear10PAgo = 203;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear11PAgo
            /// </summary>
            public const int BalPreceedingHalfYear11PAgo = 204;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear12PAgo
            /// </summary>
            public const int BalPreceedingHalfYear12PAgo = 205;

            /// <summary>
            /// Property Indexer for BalPreceedingHalfYear13PAgo
            /// </summary>
            public const int BalPreceedingHalfYear13PAgo = 206;

            /// <summary>
            /// Property Indexer for BalPreceedingYear
            /// </summary>
            public const int BalPreceedingYear = 207;

            /// <summary>
            /// Property Indexer for BalPreceedingYear1PAgo
            /// </summary>
            public const int BalPreceedingYear1PAgo = 208;

            /// <summary>
            /// Property Indexer for BalPreceedingYear2PAgo
            /// </summary>
            public const int BalPreceedingYear2PAgo = 209;

            /// <summary>
            /// Property Indexer for BalPreceedingYear3PAgo
            /// </summary>
            public const int BalPreceedingYear3PAgo = 210;

            /// <summary>
            /// Property Indexer for BalPreceedingYear4PAgo
            /// </summary>
            public const int BalPreceedingYear4PAgo = 211;

            /// <summary>
            /// Property Indexer for BalPreceedingYear5PAgo
            /// </summary>
            public const int BalPreceedingYear5PAgo = 212;

            /// <summary>
            /// Property Indexer for BalPreceedingYear6PAgo
            /// </summary>
            public const int BalPreceedingYear6PAgo = 213;

            /// <summary>
            /// Property Indexer for BalPreceedingYear7PAgo
            /// </summary>
            public const int BalPreceedingYear7PAgo = 214;

            /// <summary>
            /// Property Indexer for BalPreceedingYear8PAgo
            /// </summary>
            public const int BalPreceedingYear8PAgo = 215;

            /// <summary>
            /// Property Indexer for BalPreceedingYear9PAgo
            /// </summary>
            public const int BalPreceedingYear9PAgo = 216;

            /// <summary>
            /// Property Indexer for BalPreceedingYear10PAgo
            /// </summary>
            public const int BalPreceedingYear10PAgo = 217;

            /// <summary>
            /// Property Indexer for BalPreceedingYear11PAgo
            /// </summary>
            public const int BalPreceedingYear11PAgo = 218;

            /// <summary>
            /// Property Indexer for BalPreceedingYear12PAgo
            /// </summary>
            public const int BalPreceedingYear12PAgo = 219;

            /// <summary>
            /// Property Indexer for BalPreceedingYear13PAgo
            /// </summary>
            public const int BalPreceedingYear13PAgo = 220;

            /// <summary>
            /// Property Indexer for BudgetOpeningBalanceSwitch
            /// </summary>
            public const int BudgetOpeningBalanceSwitch = 221;

            /// <summary>
            /// Property Indexer for QuantityOpeningBalanceSwitch
            /// </summary>
            public const int QuantityOpeningBalanceSwitch = 222;

            /// <summary>
            /// Property Indexer for AdditionalFRTRNFilter
            /// </summary>
            public const int AdditionalFRTRNFilter = 223;

            /// <summary>
            /// Property Indexer for TableGLPOSTSwitch
            /// </summary>
            public const int TableGLPOSTSwitch = 224;

            /// <summary>
            /// Property Indexer for FRTRNSwitch
            /// </summary>
            public const int FRTRNSwitch = 225;

            /// <summary>
            /// Property Indexer for AccountBalOf1StFRTRNRecord
            /// </summary>
            public const int AccountBalOf1StFRTRNRecord = 226;

            /// <summary>
            /// Property Indexer for FRTRNBrowsingOrder
            /// </summary>
            public const int FRTRNBrowsingOrder = 227;

            /// <summary>
            /// Property Indexer for RollupSwitch
            /// </summary>
            public const int RollupSwitch = 228;


        }

        #endregion

    }
}