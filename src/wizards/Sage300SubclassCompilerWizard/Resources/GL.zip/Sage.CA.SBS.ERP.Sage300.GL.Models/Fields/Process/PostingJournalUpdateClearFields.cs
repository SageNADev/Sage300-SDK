﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Contains list of PostingJournalUpdateClear Constants 
    /// </summary>
    public partial class PostingJournalUpdateClear
    {
        #region EntityName

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0033";

        #endregion 

        #region PostingJournalUpdateClear Fields Constants

        /// <summary>
        /// Contains list of PostingJournalUpdateClear Fields Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for FromPostingSequence 
            /// </summary>
            public const string FromPostingSequence = "FROMPSEQ";

            /// <summary>
            /// Property for ToPostingSequence 
            /// </summary>
            public const string ToPostingSequence = "TOPSEQ";

            /// <summary>
            /// Property for ClearPostingJournal 
            /// </summary>
            public const string ClearPostingJournal = "CLEARPJ";
        }

        #endregion

        #region PostingJournalUpdateClear Index Constants

        /// <summary>
        /// Contains list of PostingJournalUpdateClear Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for FromPostingSequence 
            /// </summary>
            public const int FromPostingSequence = 1;

            /// <summary>
            /// Property Indexer for ToPostingSequence 
            /// </summary>
            public const int ToPostingSequence = 2;

            /// <summary>
            /// Property Indexer for ClearPostingJournal 
            /// </summary>
            public const int ClearPostingJournal = 3;
        }

        #endregion
    }
}