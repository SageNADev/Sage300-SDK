﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */


namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Contains list of BatchStatus Constants 
    /// </summary>
    public partial class BatchStatus
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0032";

        /// <summary>
        /// Contains list of BatchStatus Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for FromBatchNumber 
            /// </summary>
            public const string FromBatchNumber = "FROMBATCH";
            /// <summary>
            /// Property for ToBatchNumber 
            /// </summary>
            public const string ToBatchNumber = "TOBATCH";
            /// <summary>
            /// Property for Fromledger 
            /// </summary>
            public const string FromLedger = "FROMLEDGER";
            /// <summary>
            /// Property for Toledger 
            /// </summary>
            public const string ToLedger = "TOLEDGER";
            /// <summary>
            /// Property for Fromdate 
            /// </summary>
            public const string FromDate = "FROMDATE";
            /// <summary>
            /// Property for Todate 
            /// </summary>
            public const string ToDate = "TODATE";
            /// <summary>
            /// Property for Batchtypeentered 
            /// </summary>
            public const string BatchTypeEntered = "TYPENTERED";
            /// <summary>
            /// Property for Batchtypesubledger 
            /// </summary>
            public const string BatchTypeSubledger = "TYPESUBLDG";
            /// <summary>
            /// Property for Batchtypeimported 
            /// </summary>
            public const string BatchTypeImported = "TYPEIMPORT";
            /// <summary>
            /// Property for Batchtypegenerated 
            /// </summary>
            public const string BatchTypeGenerated = "TYPEGENER";
            /// <summary>
            /// Property for Batchstatusopen 
            /// </summary>
            public const string BatchStatusOpen = "STATOPEN";
            /// <summary>
            /// Property for Batchstatusprinted 
            /// </summary>
            public const string BatchStatusPrinted = "STATPRINTD";
            /// <summary>
            /// Property for Batchstatusprovisionalpost 
            /// </summary>
            public const string BatchStatusProvisionalPost = "STATPRVPST";
            /// <summary>
            /// Property for Batchstatusreadytopost 
            /// </summary>
            public const string BatchStatusReadyToPost = "STATRDYPST";
            /// <summary>
            /// Property for Batchtyperecurring 
            /// </summary>
            public const string BatchTypeRecurring = "TYPERECUR";
            /// <summary>
            /// Property for Batchstatusposted 
            /// </summary>
            public const string BatchStatusPosted = "STATPOSTED";

            #endregion
        }


        /// <summary>
        /// Contains list of BatchStatus Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for FromBatchNumber 
            /// </summary>
            public const int FromBatchNumber = 1;
            /// <summary>
            /// Property Indexer for ToBatchNumber 
            /// </summary>
            public const int ToBatchNumber = 2;
            /// <summary>
            /// Property Indexer for Fromledger 
            /// </summary>
            public const int FromLedger = 3;
            /// <summary>
            /// Property Indexer for Toledger 
            /// </summary>
            public const int ToLedger = 4;
            /// <summary>
            /// Property Indexer for Fromdate 
            /// </summary>
            public const int FromDate = 5;
            /// <summary>
            /// Property Indexer for Todate 
            /// </summary>
            public const int ToDate = 6;
            /// <summary>
            /// Property Indexer for Batchtypeentered 
            /// </summary>
            public const int BatchTypeEntered = 7;
            /// <summary>
            /// Property Indexer for Batchtypesubledger 
            /// </summary>
            public const int BatchTypeSubledger = 8;
            /// <summary>
            /// Property Indexer for Batchtypeimported 
            /// </summary>
            public const int BatchTypeImported = 9;
            /// <summary>
            /// Property Indexer for Batchtypegenerated 
            /// </summary>
            public const int BatchTypeGenerated = 10;
            /// <summary>
            /// Property Indexer for Batchstatusopen 
            /// </summary>
            public const int BatchStatusOpen = 11;
            /// <summary>
            /// Property Indexer for Batchstatusprinted 
            /// </summary>
            public const int BatchStatusPrinted = 12;
            /// <summary>
            /// Property Indexer for Batchstatusprovisionalpost 
            /// </summary>
            public const int BatchStatusProvisionalPost = 13;
            /// <summary>
            /// Property Indexer for Batchstatusreadytopost 
            /// </summary>
            public const int BatchStatusReadyToPost = 14;
            /// <summary>
            /// Property Indexer for Batchtyperecurring 
            /// </summary>
            public const int BatchTypeRecurring = 15;
            /// <summary>
            /// Property Indexer for Batchstatusposted 
            /// </summary>
            public const int BatchStatusPosted = 16;

            #endregion
        }


    }
}
