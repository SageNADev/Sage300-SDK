// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
	/// <summary>
	/// Contains list of ConsolidatePostedTransaction Constants
	/// </summary>
	public partial class ConsolidatePostedTransaction
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "GL0025";

		/// <summary>
		/// Dynamic Attributes contain a reverse mapping of field and property
		/// </summary>
		[IgnoreExportImport]
		public static Dictionary<string, string> DynamicAttributes
		{
			get
			{
				return new Dictionary<string, string>
				{
				};
			}
		}

		#region Properties

		/// <summary>
		/// Contains list of ConsolidatePostedTransaction Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Accountsegmentselectioncode
			/// </summary>
			public const string Accountsegmentselectioncode = "SELECTCODE";

			/// <summary>
			/// Property for Accountsegmentselected
			/// </summary>
			public const string Accountsegmentselected = "ABLKID";

			/// <summary>
			/// Property for FromAccountNumber
			/// </summary>
			public const string FromAccountNumber = "ACCTFROM";

			/// <summary>
			/// Property for ToAccountNumber
			/// </summary>
			public const string ToAccountNumber = "ACCTTO";

			/// <summary>
			/// Property for YearToconsolidate
			/// </summary>
			public const string YearToconsolidate = "CONSLYR";

			/// <summary>
			/// Property for PeriodToconsolidate
			/// </summary>
			public const string PeriodToconsolidate = "CONSLPERD";

			/// <summary>
			/// Property for TypeOfconsolidation
			/// </summary>
			public const string TypeOfconsolidation = "CONSLTYPE";

			/// <summary>
			/// Property for SourceType
			/// </summary>
			public const string SourceType = "SRCETYPE";

			/// <summary>
			/// Property for SourceLedger
			/// </summary>
			public const string SourceLedger = "SRCELEDGER";

			/// <summary>
			/// Property for ConsolidateSwitch
			/// </summary>
			public const string ConsolidateSwitch = "SWCONSOL";

			/// <summary>
			/// Property for RetrieveSrcLedgerSwitch
			/// </summary>
			public const string RetrieveSrcLedgerSwitch = "RTVSRCLDGR";

			/// <summary>
			/// Property for TotalRetrievedLedgers
			/// </summary>
			public const string TotalRetrievedLedgers = "RTVTOTAL";

			/// <summary>
			/// Property for ListLedgerCodesFrom
			/// </summary>
			public const string ListLedgerCodesFrom = "RTVLDGRFR";

			/// <summary>
			/// Property for RetrievedLedgersCodes
			/// </summary>
			public const string RetrievedLedgersCodes = "RTVLIST";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ConsolidatePostedTransaction Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Accountsegmentselectioncode
			/// </summary>
			public const int Accountsegmentselectioncode = 1;

			/// <summary>
			/// Property Indexer for Accountsegmentselected
			/// </summary>
			public const int Accountsegmentselected = 2;

			/// <summary>
			/// Property Indexer for FromAccountNumber
			/// </summary>
			public const int FromAccountNumber = 3;

			/// <summary>
			/// Property Indexer for ToAccountNumber
			/// </summary>
			public const int ToAccountNumber = 4;

			/// <summary>
			/// Property Indexer for YearToconsolidate
			/// </summary>
			public const int YearToconsolidate = 5;

			/// <summary>
			/// Property Indexer for PeriodToconsolidate
			/// </summary>
			public const int PeriodToconsolidate = 6;

			/// <summary>
			/// Property Indexer for TypeOfconsolidation
			/// </summary>
			public const int TypeOfconsolidation = 7;

			/// <summary>
			/// Property Indexer for SourceType
			/// </summary>
			public const int SourceType = 8;

			/// <summary>
			/// Property Indexer for SourceLedger
			/// </summary>
			public const int SourceLedger = 9;

			/// <summary>
			/// Property Indexer for ConsolidateSwitch
			/// </summary>
			public const int ConsolidateSwitch = 10;

			/// <summary>
			/// Property Indexer for RetrieveSrcLedgerSwitch
			/// </summary>
			public const int RetrieveSrcLedgerSwitch = 11;

			/// <summary>
			/// Property Indexer for TotalRetrievedLedgers
			/// </summary>
			public const int TotalRetrievedLedgers = 12;

			/// <summary>
			/// Property Indexer for ListLedgerCodesFrom
			/// </summary>
			public const int ListLedgerCodesFrom = 13;

			/// <summary>
			/// Property Indexer for RetrievedLedgersCodes
			/// </summary>
			public const int RetrievedLedgersCodes = 14;

		}

		#endregion

	}
}
