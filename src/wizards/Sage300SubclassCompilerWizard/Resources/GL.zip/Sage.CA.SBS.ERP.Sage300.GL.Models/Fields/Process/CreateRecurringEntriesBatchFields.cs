/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Contains list of CreateRecurringEntriesBatch Constants 
    /// </summary>
	public partial class CreateRecurringEntriesBatch 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "GL0043";

        /// <summary>
        /// Contains list of CreateRecurringEntriesBatch Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for RunDate 
        /// </summary>
	    public const string RunDate  = "DATERUN";
	            /// <summary>
        /// Property for Mode 
        /// </summary>
	    public const string Mode  = "MODE";
	            /// <summary>
        /// Property for SelectRecordsBy 
        /// </summary>
	    public const string SelectRecordsBy  = "SELECTBY";
	            /// <summary>
        /// Property for FromRecurringEntryCode 
        /// </summary>
	    public const string FromRecurringEntryCode  = "RECFROM";
	            /// <summary>
        /// Property for ToRecurringEntryCode 
        /// </summary>
	    public const string ToRecurringEntryCode  = "RECTO";
	            /// <summary>
        /// Property for ScheduleKey 
        /// </summary>
	    public const string ScheduleKey  = "SCHEDKEY";
	            /// <summary>
        /// Property for ScheduleLink 
        /// </summary>
	    public const string ScheduleLink  = "SCHEDLINK";
	            /// <summary>
        /// Property for Status 
        /// </summary>
	    public const string Status  = "STATUS";
	     
        /// <summary>
        /// Property for SWBTCHMETH 
        /// </summary>
        public const string BatchCreationType = "SWBTCHMETH";
	     
        /// <summary>
        /// Property for BTCHAPPEND
        /// </summary>
        public const string AppendToBatch = "BTCHAPPEND";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of CreateRecurringEntriesBatch Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for RunDate 
        /// </summary>
	    public const int RunDate  = 1;
	             /// <summary>
        /// Property Indexer for Mode 
        /// </summary>
	    public const int Mode  = 2;
	             /// <summary>
        /// Property Indexer for SelectRecordsBy 
        /// </summary>
	    public const int SelectRecordsBy  = 3;
	             /// <summary>
        /// Property Indexer for FromRecurringEntryCode 
        /// </summary>
	    public const int FromRecurringEntryCode  = 4;
	             /// <summary>
        /// Property Indexer for ToRecurringEntryCode 
        /// </summary>
	    public const int ToRecurringEntryCode  = 5;
	             /// <summary>
        /// Property Indexer for ScheduleKey 
        /// </summary>
	    public const int ScheduleKey  = 6;
	             /// <summary>
        /// Property Indexer for ScheduleLink 
        /// </summary>
	    public const int ScheduleLink  = 7;
	             /// <summary>
        /// Property Indexer for Status 
        /// </summary>
	    public const int Status  = 8;
	     
        /// <summary>
        /// Property Indexer for SWBTCHMETH 
        /// </summary>
        public const int BatchCreationType = 9;
	     
        /// <summary>
        /// Property Indexer for BTCHAPPEND 
        /// </summary>
        public const int AppendToBatch = 10;
	     
        #endregion
	    }

	
	}
}
	