/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Process
{
    /// <summary>
    /// Contains list of CreateNewYear Constants 
    /// </summary>
	public partial class CreateNewYear 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "GL0026";

        /// <summary>
        /// Contains list of CreateNewYear Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for Reserved 
        /// </summary>
	    public const string Reserved  = "NEWYEAR";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of CreateNewYear Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for Reserved 
        /// </summary>
	    public const int Reserved  = 1;
	     
        #endregion
	    }

	
	}
}
	