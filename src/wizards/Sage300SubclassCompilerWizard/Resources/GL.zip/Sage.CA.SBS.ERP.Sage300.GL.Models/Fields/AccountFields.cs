/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
// ReSharper disable CheckNamespace


namespace Sage.CA.SBS.ERP.Sage300.GL.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Accounts Constants 
    /// </summary>
    public partial class Account
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0001";

        /// <summary>
        /// Accounts Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for UnformattedAccount 
            /// </summary>
            public const string UnformattedAccount = "ACCTID";

            /// <summary>
            /// Property for DateCreated 
            /// </summary>
            public const string DateCreated = "CREATEDATE";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "ACCTDESC";

            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string Type = "ACCTTYPE";
            /// <summary>
            /// Property for Type 
            /// </summary>
            [IsMvcSpecific]
            public const string AccountTypeString = "ACCTTYPE";

            /// <summary>
            /// Property for NormalBalanceDROrCR 
            /// </summary>
            public const string NormalBalanceDrorCr = "ACCTBAL";

            /// <summary>
            /// Property for NormalBalanceDROrCR 
            /// </summary>
            public const string NormalBalanceString = "ACCTBAL";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "ACTIVESW";

            /// <summary>
            /// Property for Status
            /// Added for finder 
            /// </summary>
            [IsMvcSpecific]
            public const string StatusDescription = "ACTIVESW";


            /// <summary>
            /// Property for PosttoAccount 
            /// </summary>
            public const string PosttoAccount = "CONSLDSW";

            /// <summary>
            /// Property for PosttoAccountString 
            /// Added for finder 
            /// </summary>
            public const string PosttoAccountString = "CONSLDSW";

            /// <summary>
            /// Property for QuantitiesAllowed 
            /// </summary>
            public const string QuantitiesAllowed = "QTYSW";

            /// <summary>
            /// Property for QuantitiesAllowed 
            /// Added for filter
            /// </summary>
            [IsMvcSpecific]
            public const string QuantitiesString = "QTYSW";


            /// <summary>
            /// Property for UnitofMeasure 
            /// </summary>
            public const string UnitofMeasure = "UOM";


            /// <summary>
            /// Property for AllocationsAllowed 
            /// </summary>
            public const string AllocationsAllowed = "ALLOCSW";
            /// <summary>
            /// Property for AllocationsAllowed 
            /// Added for filter
            /// </summary>
            [IsMvcSpecific]
            public const string AllocationDescription = "ALLOCSW";

            /// <summary>
            /// Property for AllocOffsetAccount 
            /// </summary>
            public const string AllocOffsetAccount = "ACCTOFSET";

            /// <summary>
            /// Property for AllocSourceType 
            /// </summary>
            public const string AllocSourceType = "ACCTSRTY";

            /// <summary>
            /// Property for Multicurrency 
            /// </summary>
            public const string Multicurrency = "MCSW";
            /// <summary>
            /// Property for Multicurrency 
            /// Added for filter
            /// </summary>
            [IsMvcSpecific]
            public const string MulticurrencyString = "MCSW";

            /// <summary>
            /// Property for SpecificCurrency 
            /// </summary>
            public const string SpecificCurrency = "SPECSW";

            /// <summary>
            /// Property for SpecificCurrencyString 
            /// Added for filter
            /// </summary>
            public const string SpecificCurrencyString = "SPECSW";

            /// <summary>
            /// Property for ControlAccount 
            /// </summary>
            public const string ControlAccount = "CTRLACCTSW";

            /// <summary>
            /// Property for ControlAccount 
            /// Added for finder
            /// </summary>
            [IsMvcSpecific]
            public const string ControlAccountString = "CTRLACCTSW";

            /// <summary>
            /// Property for AllocationPercentTotal 
            /// </summary>
            public const string AllocationPercentTotal = "ALLOCTOT";

            /// <summary>
            /// Property for StructureCode 
            /// </summary>
            public const string StructureCode = "ABRKID";


            /// <summary>
            /// Property for YearLastClosed 
            /// </summary>
            public const string YearLastClosed = "YRACCTCLOS";


            /// <summary>
            /// Property for AccountNumber 
            /// </summary>
            public const string AccountNumber = "ACCTFMTTD";


            /// <summary>
            /// Property for AccountSegmentCode1 
            /// </summary>
            public const string AccountSegmentCode1 = "ACSEGVAL01";


            /// <summary>
            /// Property for AccountSegmentCode2 
            /// </summary>
            public const string AccountSegmentCode2 = "ACSEGVAL02";


            /// <summary>
            /// Property for AccountSegmentCode3 
            /// </summary>
            public const string AccountSegmentCode3 = "ACSEGVAL03";


            /// <summary>
            /// Property for AccountSegmentCode4 
            /// </summary>
            public const string AccountSegmentCode4 = "ACSEGVAL04";


            /// <summary>
            /// Property for AccountSegmentCode5 
            /// </summary>
            public const string AccountSegmentCode5 = "ACSEGVAL05";


            /// <summary>
            /// Property for AccountSegmentCode6 
            /// </summary>
            public const string AccountSegmentCode6 = "ACSEGVAL06";


            /// <summary>
            /// Property for AccountSegmentCode7 
            /// </summary>
            public const string AccountSegmentCode7 = "ACSEGVAL07";


            /// <summary>
            /// Property for AccountSegmentCode8 
            /// </summary>
            public const string AccountSegmentCode8 = "ACSEGVAL08";


            /// <summary>
            /// Property for AccountSegmentCode9 
            /// </summary>
            public const string AccountSegmentCode9 = "ACSEGVAL09";


            /// <summary>
            /// Property for AccountSegmentCode10 
            /// </summary>
            public const string AccountSegmentCode10 = "ACSEGVAL10";

            /// <summary>
            /// Property for SegmentCode 
            /// </summary>
            public const string SegmentCode = "ACCTSEGVAL";

            /// <summary>
            /// Property for PosttoSegmentId 
            /// </summary>
            public const string PosttoSegmentId = "POSTOSEGID";

            /// <summary>
            /// Property for DefaultCurrencyCode 
            /// </summary>
            public const string DefaultCurrencyCode = "DEFCURNCOD";
            
            /// <summary>
            /// Property for AllowRetrieve 
            /// </summary>
            public const string AllowRetrieve = "GSSTATUS";

            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "OVALUES";

            /// <summary>
            /// Property for TransactionOptionalFields 
            /// </summary>
            public const string TransactionOptionalFields = "TOVALUES";

            /// <summary>
            /// Property for ProcessSwitch 
            /// </summary>
            public const string ProcessSwitch = "PROCESSCMD";

            /// <summary>
            /// Property for AccountGroupCode 
            /// </summary>
            public const string AccountGroupCode = "ACCTGRPCOD";

            /// <summary>
            /// Property for AccountGroupSortCode 
            /// </summary>
            public const string AccountGroupSortCode = "ACCTGRPSCD";

            /// <summary>
            /// Property for RollupSwitch 
            /// </summary>
            public const string RollupSwitch = "ROLLUPSW";

            /// <summary>
            /// Property for RollupSwitchString 
            /// Added for Finder Filter
            /// </summary>
            [IsMvcSpecific]
            public const string RollupSwitchString = "ROLLUPSW";

            /// <summary>
            /// Property for RollupOrMemberOrNonRollup 
            /// </summary>
            public const string RollupOrMemberOrNonRollup = "TOPPARSW";

            /// <summary>
            /// Property for AcctSelectorFromAccount 
            /// </summary>
            public const string AcctSelectorFromAccount = "RFRACCT";

            /// <summary>
            /// Property for AcctSelectorToAccount 
            /// </summary>
            public const string AcctSelectorToAccount = "RTOACCT";

            /// <summary>
            /// Property for AcctSelectorFromSeg1Val 
            /// </summary>
            public const string AcctSelectorFromSeg1Val = "RFRSEG1";

            /// <summary>
            /// Property for AcctSelectorToSeg1Val 
            /// </summary>
            public const string AcctSelectorToSeg1Val = "RTOSEG1";

            /// <summary>
            /// Property for AcctSelectorFromSeg2Val 
            /// </summary>
            public const string AcctSelectorFromSeg2Val = "RFRSEG2";

            /// <summary>
            /// Property for AcctSelectorToSeg2Val 
            /// </summary>
            public const string AcctSelectorToSeg2Val = "RTOSEG2";

            /// <summary>
            /// Property for AcctSelectorFromSeg3Val 
            /// </summary>
            public const string AcctSelectorFromSeg3Val = "RFRSEG3";

            /// <summary>
            /// Property for AcctSelectorToSeg3Val 
            /// </summary>
            public const string AcctSelectorToSeg3Val = "RTOSEG3";

            /// <summary>
            /// Property for AcctSelectorFromSeg4Val 
            /// </summary>
            public const string AcctSelectorFromSeg4Val = "RFRSEG4";

            /// <summary>
            /// Property for AcctSelectorToSeg4Val 
            /// </summary>
            public const string AcctSelectorToSeg4Val = "RTOSEG4";

            /// <summary>
            /// Property for AcctSelectorFromSeg5Val 
            /// </summary>
            public const string AcctSelectorFromSeg5Val = "RFRSEG5";

            /// <summary>
            /// Property for AcctSelectorToSeg5Val 
            /// </summary>
            public const string AcctSelectorToSeg5Val = "RTOSEG5";

            /// <summary>
            /// Property for AcctSelectorFromSeg6Val 
            /// </summary>
            public const string AcctSelectorFromSeg6Val = "RFRSEG6";

            /// <summary>
            /// Property for AcctSelectorToSeg6Val 
            /// </summary>
            public const string AcctSelectorToSeg6Val = "RTOSEG6";

            /// <summary>
            /// Property for AcctSelectorFromSeg7Val 
            /// </summary>
            public const string AcctSelectorFromSeg7Val = "RFRSEG7";

            /// <summary>
            /// Property for AcctSelectorToSeg7Val 
            /// </summary>
            public const string AcctSelectorToSeg7Val = "RTOSEG7";

            /// <summary>
            /// Property for AcctSelectorFromSeg8Val 
            /// </summary>
            public const string AcctSelectorFromSeg8Val = "RFRSEG8";

            /// <summary>
            /// Property for AcctSelectorToSeg8Val 
            /// </summary>
            public const string AcctSelectorToSeg8Val = "RTOSEG8";

            /// <summary>
            /// Property for AcctSelectorFromSeg9Val 
            /// </summary>
            public const string AcctSelectorFromSeg9Val = "RFRSEG9";

            /// <summary>
            /// Property for AcctSelectorToSeg9Val 
            /// </summary>
            public const string AcctSelectorToSeg9Val = "RTOSEG9";

            /// <summary>
            /// Property for AcctSelectorFromSeg10Val 
            /// </summary>
            public const string AcctSelectorFromSeg10Val = "RFRSEG10";

            /// <summary>
            /// Property for AcctSelectorToSeg10Val 
            /// </summary>
            public const string AcctSelectorToSeg10Val = "RTOSEG10";

            /// <summary>
            /// Property for AcctSelectorOptField1 
            /// </summary>
            public const string AcctSelectorOptField1 = "ROPTFLD1";

            /// <summary>
            /// Property for AcctSelectorOptField2 
            /// </summary>
            public const string AcctSelectorOptField2 = "ROPTFLD2";

            /// <summary>
            /// Property for AcctSelectorOptField3 
            /// </summary>
            public const string AcctSelectorOptField3 = "ROPTFLD3";

            /// <summary>
            /// Property for AcctSelectorFromOpt1Val 
            /// </summary>
            public const string AcctSelectorFromOpt1Val = "ROPTFRVAL1";

            /// <summary>
            /// Property for AcctSelectorToOpt1Val 
            /// </summary>
            public const string AcctSelectorToOpt1Val = "ROPTTOVAL1";

            /// <summary>
            /// Property for AcctSelectorFromOpt2Val 
            /// </summary>
            public const string AcctSelectorFromOpt2Val = "ROPTFRVAL2";

            /// <summary>
            /// Property for AcctSelectorToOpt2Val 
            /// </summary>
            public const string AcctSelectorToOpt2Val = "ROPTTOVAL2";

            /// <summary>
            /// Property for AcctSelectorFromOpt3Val 
            /// </summary>
            public const string AcctSelectorFromOpt3Val = "ROPTFRVAL3";

            /// <summary>
            /// Property for AcctSelectorToOpt3Val 
            /// </summary>
            public const string AcctSelectorToOpt3Val = "ROPTTOVAL3";

            /// <summary>
            /// Property for AcctSelectorAcctType 
            /// </summary>
            public const string AcctSelectorAcctType = "RACCTTYPE";

            /// <summary>
            /// Property for AcctSelectorFromAcctGroup 
            /// </summary>
            public const string AcctSelectorFromAcctGroup = "RFRGRPID";

            /// <summary>
            /// Property for AcctSelectorToAcctGroup 
            /// </summary>
            public const string AcctSelectorToAcctGroup = "RTOGRPID";

            /// <summary>
            /// Property for AcctSelectorQuantAllowed 
            /// </summary>
            public const string AcctSelectorQuantAllowed = "RQTYSW";

            /// <summary>
            /// Property for Noofcreatedpreviewaccounts 
            /// </summary>
            public const string Noofcreatedpreviewaccounts = "RCNT";

            /// <summary>
            /// Property for RollupMembersinOtherAccounts 
            /// </summary>
            public const string RollupMembersinOtherAccounts = "ROVERLAP";

            /// <summary>
            /// Property for Source ledger Id 
            /// </summary>
            public const string Srceldgid = "SRCELDGID";

            #endregion
        }

        /// <summary>
        /// Accounts Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index
            /// <summary>
            /// Property Indexer for UnformattedAccount 
            /// </summary>
            public const int UnformattedAccount = 1;

            /// <summary>
            /// Property Indexer for DateCreated 
            /// </summary>
            public const int DateCreated = 2;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;

            /// <summary>
            /// Property Indexer for Type 
            /// </summary>
            public const int Type = 4;

            /// <summary>
            /// Property Indexer for NormalBalanceDROrCR 
            /// </summary>
            public const int NormalBalanceDrorCr = 5;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 6;

            /// <summary>
            /// Property Indexer for PosttoAccount 
            /// </summary>
            public const int PosttoAccount = 7;

            /// <summary>
            /// Property Indexer for QuantitiesAllowed 
            /// </summary>
            public const int QuantitiesAllowed = 8;

            /// <summary>
            /// Property Indexer for UnitofMeasure 
            /// </summary>
            public const int UnitofMeasure = 9;


            /// <summary>
            /// Property Indexer for AllocationsAllowed 
            /// </summary>
            public const int AllocationsAllowed = 10;


            /// <summary>
            /// Property Indexer for AllocOffsetAccount 
            /// </summary>
            public const int AllocOffsetAccount = 11;



            /// <summary>
            /// Property Indexer for AllocSourceType 
            /// </summary>
            public const int AllocSourceType = 12;

            /// <summary>
            /// Property Indexer for Multicurrency 
            /// </summary>
            public const int Multicurrency = 13;

            /// <summary>
            /// Property Indexer for SpecificCurrency 
            /// </summary>
            public const int SpecificCurrency = 14;

            /// <summary>
            /// Property Indexer for ControlAccount 
            /// </summary>
            public const int ControlAccount = 16;

            /// <summary>
            /// Property Indexer for AllocationPercentTotal 
            /// </summary>
            public const int AllocationPercentTotal = 18;


            /// <summary>
            /// Property Indexer for StructureCode 
            /// </summary>
            public const int StructureCode = 19;

            /// <summary>
            /// Property Indexer for YearLastClosed 
            /// </summary>
            public const int YearLastClosed = 20;

            /// <summary>
            /// Property Indexer for AccountNumber 
            /// </summary>
            public const int AccountNumber = 21;

            /// <summary>
            /// Property Indexer for AccountSegmentCode1 
            /// </summary>
            public const int AccountSegmentCode1 = 22;


            /// <summary>
            /// Property Indexer for AccountSegmentCode2 
            /// </summary>
            public const int AccountSegmentCode2 = 23;

            /// <summary>
            /// Property Indexer for AccountSegmentCode3 
            /// </summary>
            public const int AccountSegmentCode3 = 24;

            /// <summary>
            /// Property Indexer for AccountSegmentCode4 
            /// </summary>
            public const int AccountSegmentCode4 = 25;


            /// <summary>
            /// Property Indexer for AccountSegmentCode5 
            /// </summary>
            public const int AccountSegmentCode5 = 26;

            /// <summary>
            /// Property Indexer for AccountSegmentCode6 
            /// </summary>
            public const int AccountSegmentCode6 = 27;

            /// <summary>
            /// Property Indexer for AccountSegmentCode7 
            /// </summary>
            public const int AccountSegmentCode7 = 28;


            /// <summary>
            /// Property Indexer for AccountSegmentCode8 
            /// </summary>
            public const int AccountSegmentCode8 = 29;


            /// <summary>
            /// Property Indexer for AccountSegmentCode9 
            /// </summary>
            public const int AccountSegmentCode9 = 30;


            /// <summary>
            /// Property Indexer for AccountSegmentCode10 
            /// </summary>
            public const int AccountSegmentCode10 = 31;


            /// <summary>
            /// Property Indexer for SegmentCode 
            /// </summary>
            public const int SegmentCode = 32;

            /// <summary>
            /// Property Indexer for PosttoSegmentID 
            /// </summary>
            public const int PosttoSegmentID = 34;

            /// <summary>
            /// Property Indexer for DefaultCurrencyCode 
            /// </summary>
            public const int DefaultCurrencyCode = 35;

            /// <summary>
            /// Property Indexer for AllowRetrieve 
            /// </summary>
            public const int AllowRetrieve = 38;

            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 39;

            /// <summary>
            /// Property Indexer for TransactionOptionalFields 
            /// </summary>
            public const int TransactionOptionalFields = 40;

            /// <summary>
            /// Property Indexer for ProcessSwitch 
            /// </summary>
            public const int ProcessSwitch = 41;

            /// <summary>
            /// Property Indexer for AccountGroupCode 
            /// </summary>
            public const int AccountGroupCode = 42;

            /// <summary>
            /// Property Indexer for AccountGroupSortCode 
            /// </summary>
            public const int AccountGroupSortCode = 43;


            /// <summary>
            /// Property Indexer for RollupSwitch 
            /// </summary>
            public const int RollupSwitch = 44;


            /// <summary>
            /// Property Indexer for RollupOrMemberOrNonRollup 
            /// </summary>
            public const int RollupOrMemberOrNonRollup = 45;

            /// <summary>
            /// Property Indexer for AcctSelectorFromAccount 
            /// </summary>
            public const int AcctSelectorFromAccount = 46;


            /// <summary>
            /// Property Indexer for AcctSelectorToAccount 
            /// </summary>
            public const int AcctSelectorToAccount = 47;


            /// <summary>
            /// Property Indexer for AcctSelectorFromSeg1Val 
            /// </summary>
            public const int AcctSelectorFromSeg1Val = 48;


            /// <summary>
            /// Property Indexer for AcctSelectorToSeg1Val 
            /// </summary>
            public const int AcctSelectorToSeg1Val = 49;


            /// <summary>
            /// Property Indexer for AcctSelectorFromSeg2Val 
            /// </summary>
            public const int AcctSelectorFromSeg2Val = 50;


            /// <summary>
            /// Property Indexer for AcctSelectorToSeg2Val 
            /// </summary>
            public const int AcctSelectorToSeg2Val = 51;


            /// <summary>
            /// Property Indexer for AcctSelectorFromSeg3Val 
            /// </summary>
            public const int AcctSelectorFromSeg3Val = 52;


            /// <summary>
            /// Property Indexer for AcctSelectorToSeg3Val 
            /// </summary>
            public const int AcctSelectorToSeg3Val = 53;

            /// <summary>
            /// Property Indexer for AcctSelectorFromSeg4Val 
            /// </summary>
            public const int AcctSelectorFromSeg4Val = 54;

            /// <summary>
            /// Property Indexer for AcctSelectorToSeg4Val 
            /// </summary>
            public const int AcctSelectorToSeg4Val = 55;


            /// <summary>
            /// Property Indexer for AcctSelectorFromSeg5Val 
            /// </summary>
            public const int AcctSelectorFromSeg5Val = 56;

            /// <summary>
            /// Property Indexer for AcctSelectorToSeg5Val 
            /// </summary>
            public const int AcctSelectorToSeg5Val = 57;

            /// <summary>
            /// Property Indexer for AcctSelectorFromSeg6Val 
            /// </summary>
            public const int AcctSelectorFromSeg6Val = 58;

            /// <summary>
            /// Property Indexer for AcctSelectorToSeg6Val 
            /// </summary>
            public const int AcctSelectorToSeg6Val = 59;


            /// <summary>
            /// Property Indexer for AcctSelectorFromSeg7Val 
            /// </summary>
            public const int AcctSelectorFromSeg7Val = 60;

            /// <summary>
            /// Property Indexer for AcctSelectorToSeg7Val 
            /// </summary>
            public const int AcctSelectorToSeg7Val = 61;

            /// <summary>
            /// Property Indexer for AcctSelectorFromSeg8Val 
            /// </summary>
            public const int AcctSelectorFromSeg8Val = 62;

            /// <summary>
            /// Property Indexer for AcctSelectorToSeg8Val 
            /// </summary>
            public const int AcctSelectorToSeg8Val = 63;


            /// <summary>
            /// Property Indexer for AcctSelectorFromSeg9Val 
            /// </summary>
            public const int AcctSelectorFromSeg9Val = 64;

            /// <summary>
            /// Property Indexer for AcctSelectorToSeg9Val 
            /// </summary>
            public const int AcctSelectorToSeg9Val = 65;

            /// <summary>
            /// Property Indexer for AcctSelectorFromSeg10Val 
            /// </summary>
            public const int AcctSelectorFromSeg10Val = 66;


            /// <summary>
            /// Property Indexer for AcctSelectorToSeg10Val 
            /// </summary>
            public const int AcctSelectorToSeg10Val = 67;

            /// <summary>
            /// Property Indexer for AcctSelectorOptField1 
            /// </summary>
            public const int AcctSelectorOptField = 68;

            /// <summary>
            /// Property Indexer for AcctSelectorOptField2 
            /// </summary>
            public const int AcctSelectorOptField2 = 69;

            /// <summary>
            /// Property Indexer for AcctSelectorOptField3 
            /// </summary>
            public const int AcctSelectorOptField3 = 70;

            /// <summary>
            /// Property Indexer for AcctSelectorFromOpt1Val 
            /// </summary>
            public const int AcctSelectorFromOpt1Val = 71;


            /// <summary>
            /// Property Indexer for AcctSelectorToOpt1Val 
            /// </summary>
            public const int AcctSelectorToOpt1Val = 72;

            /// <summary>
            /// Property Indexer for AcctSelectorFromOpt2Val 
            /// </summary>
            public const int AcctSelectorFromOpt2Val = 73;


            /// <summary>
            /// Property Indexer for AcctSelectorToOpt2Val 
            /// </summary>
            public const int AcctSelectorToOpt2Val = 74;


            /// <summary>
            /// Property Indexer for AcctSelectorFromOpt3Val 
            /// </summary>
            public const int AcctSelectorFromOpt3Val = 75;

            /// <summary>
            /// Property Indexer for AcctSelectorToOpt3Val 
            /// </summary>
            public const int AcctSelectorToOpt3Val = 76;

            /// <summary>
            /// Property Indexer for AcctSelectorAcctType 
            /// </summary>
            public const int AcctSelectorAcctType = 77;

            /// <summary>
            /// Property Indexer for AcctSelectorFromAcctGroup 
            /// </summary>
            public const int AcctSelectorFromAcctGroup = 78;

            /// <summary>
            /// Property Indexer for AcctSelectorToAcctGroup 
            /// </summary>
            public const int AcctSelectorToAcctGroup = 79;

            /// <summary>
            /// Property Indexer for AcctSelectorQuantAllowed 
            /// </summary>
            public const int AcctSelectorQuantAllowed = 80;

            /// <summary>
            /// Property Indexer for Noofcreatedpreviewaccounts 
            /// </summary>
            public const int Noofcreatedpreviewaccounts = 81;

            /// <summary>
            /// Property Indexer for RollupMembersinOtherAccounts 
            /// </summary>
            public const int RollupMembersinOtherAccounts = 82;

            #endregion
        }
    }
}
