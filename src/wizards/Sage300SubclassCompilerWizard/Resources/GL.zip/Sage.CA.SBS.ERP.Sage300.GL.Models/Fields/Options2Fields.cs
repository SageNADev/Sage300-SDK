/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class Options2
    {
        public const string EntityName = "GL0068";

        public class Fields
        {
            public const string GLOptionKey          = "OPTIONID";
            public const string EditImportedBatches  = "SWEDITIMPT";
            public const string EditSubledgerBatches = "SWEDITSUB";
        }

        public class Index
        {
            public const int GLOptionKeyIndex          = 1;
            public const int EditImportedBatchesIndex  = 2;
            public const int EditSubledgerBatchesIndex = 3;
        }
    }
}
