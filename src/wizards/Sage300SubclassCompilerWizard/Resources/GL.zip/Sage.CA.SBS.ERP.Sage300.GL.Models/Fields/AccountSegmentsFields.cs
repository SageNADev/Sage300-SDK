﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of Account Segments Constants 
    /// </summary>
    public partial class AccountSegments
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "GL0022";

        /// <summary>
        /// Account Segments Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for Segment Number 
            /// </summary>
            public const string SegmentNumber = "ACCTBLKID";

            /// <summary>
            /// Property for Segment Status 
            /// </summary>
            public const string SegmentStatus = "STATUSACTV";

            /// <summary>
            /// Property for Segment Type 
            /// </summary>
            public const string SegmentType = "ABLKTYPE";

            /// <summary>
            /// Property for Segment Description 
            /// </summary>
            public const string SegmentDescription = "ABLKDESC";

            /// <summary>
            /// Property for Segment Length 
            /// </summary>
            public const string SegmentLength = "ABLKLEN";

            /// <summary>
            /// Property for Close By Account Segment Switch 
            /// </summary>
            public const string CloseByAcctSegtSwitch = "CLOSESW";

            /// <summary>
            /// Property for Alternate Key Index
            /// </summary>
            public const string AlternateKeyIndx = "NUMOFKEY";

            #endregion
        }

        /// <summary>
        /// GeneralLedgerOptions Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for Segment Number 
            /// </summary>
            public const int SegmentNumber = 1;

            /// <summary>
            /// Property Indexer for Segment Status 
            /// </summary>
            public const int SegmentStatus = 2;

            /// <summary>
            /// Property Indexer for Segment Type 
            /// </summary>
            public const int SegmentType = 3;

            /// <summary>
            /// Property Indexer for Segment Description 
            /// </summary>
            public const int SegmentDescription = 4;

            /// <summary>
            /// Property Indexer for Segment Length 
            /// </summary>
            public const int SegmentLength = 5;

            /// <summary>
            /// Property Indexer for Close By Account Segment Switch
            /// </summary>
            public const int CloseByAcctSegtSwitch = 12;

            /// <summary>
            /// Property Indexer for Alternate Key Index
            /// </summary>
            public const int AlternateKey = 14;

            #endregion
        }
    }
}
