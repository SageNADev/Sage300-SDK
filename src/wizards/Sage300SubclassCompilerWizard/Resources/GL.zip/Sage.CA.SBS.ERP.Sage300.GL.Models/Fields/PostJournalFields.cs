﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */


namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of PostJournal Constants 
    /// </summary>
    public partial class PostJournal
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0030";

        /// <summary>
        /// Contains list of PostJournal Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for PostAllBatchesSwitch 
            /// </summary>
            public const string PostAllBatchesSwitch = "ALLBTCHSW";
            /// <summary>
            /// Property for ProvisionalPostSwitch 
            /// </summary>
            public const string ProvisionalPostSwitch = "PROVPOSTSW";
            /// <summary>
            /// Property for FromBatchNumber 
            /// </summary>
            public const string FromBatchNumber = "BATCHIDFR";
            /// <summary>
            /// Property for ToBatchNumber 
            /// </summary>
            public const string ToBatchNumber = "BATCHIDTO";
            /// <summary>
            /// Property for ErrorBatchCreatedSwitch 
            /// </summary>
            public const string ErrorBatchCreatedSwitch = "ERRBTCHSW";
            /// <summary>
            /// Property for LockBatchSwitch 
            /// </summary>
            public const string LockBatchSwitch = "PROCESSCMD";

            #endregion
        }

        /// <summary>
        /// Contains list of PostJournal Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for PostAllBatchesSwitch 
            /// </summary>
            public const int PostAllBatchesSwitch = 1;
            /// <summary>
            /// Property Indexer for ProvisionalPostSwitch 
            /// </summary>
            public const int ProvisionalPostSwitch = 2;
            /// <summary>
            /// Property Indexer for FromBatchNumber 
            /// </summary>
            public const int FromBatchNumber = 3;
            /// <summary>
            /// Property Indexer for ToBatchNumber 
            /// </summary>
            public const int ToBatchNumber = 4;
            /// <summary>
            /// Property Indexer for ErrorBatchCreatedSwitch 
            /// </summary>
            public const int ErrorBatchCreatedSwitch = 5;

            #endregion
        }
    }
}
