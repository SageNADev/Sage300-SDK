﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of JournalDetails Constants 
    /// </summary>
    public partial class JournalDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0010";

        /// <summary>
        /// Contains list of JournalDetails Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "BATCHNBR";

            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "JOURNALID";

            /// <summary>
            /// Property for TransactionNumber 
            /// </summary>
            public const string TransactionNumber = "TRANSNBR";

            /// <summary>
            /// Property for Destination 
            /// </summary>
            public const string Destination = "DESCOMP";

            /// <summary>
            /// Property for RouteNo 
            /// </summary>
            public const string RouteNo = "ROUTE";

            /// <summary>
            /// Property for AccountNumber 
            /// </summary>
            public const string AccountNumber = "ACCTID";

            /// <summary>
            /// Property for CompanyId 
            /// </summary>
            public const string CompanyId = "COMPANYID";

            /// <summary>
            /// Property for Amount 
            /// </summary>
            public const string Amount = "TRANSAMT";

            /// <summary>
            /// Property for Quantity 
            /// </summary>
            public const string Quantity = "TRANSQTY";

            /// <summary>
            /// Property for SourceCurrencyDecimals 
            /// </summary>
            public const string SourceCurrencyDecimals = "SCURNDEC";

            /// <summary>
            /// Property for SourceCurrencyAmount 
            /// </summary>
            public const string SourceCurrencyAmount = "SCURNAMT";

            /// <summary>
            /// Property for HomeCurrency 
            /// </summary>
            public const string HomeCurrency = "HCURNCODE";

            /// <summary>
            /// Property for CurrencyRateTable 
            /// </summary>
            public const string CurrencyRateTable = "RATETYPE";

            /// <summary>
            /// Property for SourceCurrency 
            /// </summary>
            public const string SourceCurrency = "SCURNCODE";

            /// <summary>
            /// Property for CurrencyRateDate 
            /// </summary>
            public const string CurrencyRateDate = "RATEDATE";

            /// <summary>
            /// Property for CurrencyRate 
            /// </summary>
            public const string CurrencyRate = "CONVRATE";

            /// <summary>
            /// Property for CurrencyRateSpread 
            /// </summary>
            public const string CurrencyRateSpread = "RATESPREAD";

            /// <summary>
            /// Property for CurrencyRateDateMatching 
            /// </summary>
            public const string CurrencyRateDateMatching = "DATEMTCHCD";

            /// <summary>
            /// Property for CurrencyRateOperator 
            /// </summary>
            public const string CurrencyRateOperator = "RATEOPER";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TRANSDESC";

            /// <summary>
            /// Property for Reference 
            /// </summary>
            public const string Reference = "TRANSREF";

            /// <summary>
            /// Property for JournalDate 
            /// </summary>
            public const string JournalDate = "TRANSDATE";

            /// <summary>
            /// Property for SourceLedger 
            /// </summary>
            public const string SourceLedger = "SRCELDGR";

            /// <summary>
            /// Property for SourceType 
            /// </summary>
            public const string SourceType = "SRCETYPE";

            /// <summary>
            /// Property for Comment 
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for ProcessSwitch 
            /// </summary>
            public const string ProcessSwitch = "PROCESSCMD";

            /// <summary>
            /// Property for DestExists 
            /// </summary>
            public const string DestExists = "DESEXIST";

            /// <summary>
            /// Property for DestDescription 
            /// </summary>
            public const string DestDescription = "DESDESC";

            /// <summary>
            /// Property for DestStatus 
            /// </summary>
            public const string DestStatus = "DESSTAT";

            /// <summary>
            /// Property for DestMulticurrencySwitch 
            /// </summary>
            public const string DestMulticurrencySwitch = "DESMCSW";

            /// <summary>
            /// Property for DestHomeCurrency 
            /// </summary>
            public const string DestHomeCurrency = "DESCURN";

            /// <summary>
            /// Property for DestHomeCurrencyDecimals 
            /// </summary>
            public const string DestHomeCurrencyDecimals = "DESDEC";

            /// <summary>
            /// Property for DestQtySwitch 
            /// </summary>
            public const string DestQtySwitch = "DESQTYSW";

            /// <summary>
            /// Property for DestQtyDecimals 
            /// </summary>
            public const string DestQtyDecimals = "DESQTYDEC";

            /// <summary>
            /// Property for DestOptionalFlds 
            /// </summary>
            public const string DestOptionalFlds = "DESOPFLDS";

            /// <summary>
            /// Property for RouteExists 
            /// </summary>
            public const string RouteExists = "ROUTEXIST";

            /// <summary>
            /// Property for RouteDescription 
            /// </summary>
            public const string RouteDescription = "ROUTEDESC";

            /// <summary>
            /// Property for RouteStatus 
            /// </summary>
            public const string RouteStatus = "ROUTESTAT";

            /// <summary>
            /// Property for SourceCodeExists 
            /// </summary>
            public const string SourceCodeExists = "SRCEXIST";

            /// <summary>
            /// Property for SourceCodeDescription 
            /// </summary>
            public const string SourceCodeDescription = "SRCDESC";

            /// <summary>
            /// Property for AcctExists 
            /// </summary>
            public const string AcctExists = "ACTEXIST";

            /// <summary>
            /// Property for AcctFormatted 
            /// </summary>
            public const string AcctFormatted = "ACTFMTTD";

            /// <summary>
            /// Property for AccountDescription 
            /// </summary>
            public const string AccountDescription = "ACTDESC";

            /// <summary>
            /// Property for AcctStatus 
            /// </summary>
            public const string AcctStatus = "ACTSTAT";

            /// <summary>
            /// Property for AcctMulticurrencySwitch 
            /// </summary>
            public const string AcctMulticurrencySwitch = "ACTMCSW";

            /// <summary>
            /// Property for AcctSpecificCurrenciesSwitch 
            /// </summary>
            public const string AcctSpecificCurrenciesSwitch = "ACTSPECSW";

            /// <summary>
            /// Property for AcctControlSwitch 
            /// </summary>
            public const string AcctControlSwitch = "ACTCTRLSW";

            /// <summary>
            /// Property for AcctQtySwitch 
            /// </summary>
            public const string AcctQtySwitch = "ACTQTYSW";

            /// <summary>
            /// Property for AcctOptionalFlds 
            /// </summary>
            public const string AcctOptionalFlds = "ACTOVALS";

            /// <summary>
            /// Property for AcctTransactionOptionalFlds 
            /// </summary>
            public const string AcctTransactionOptionalFlds = "ACTTOVALS";

            /// <summary>
            /// Property for AcctUnitofMeasure 
            /// </summary>
            public const string AcctUnitofMeasure = "ACTUOM";

            #endregion
        }

        /// <summary>
        /// Contains list of JournalDetails Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 1;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 2;

            /// <summary>
            /// Property Indexer for TransactionNumber 
            /// </summary>
            public const int TransactionNumber = 3;

            /// <summary>
            /// Property Indexer for Destination 
            /// </summary>
            public const int Destination = 26;

            /// <summary>
            /// Property Indexer for RouteNo 
            /// </summary>
            public const int RouteNo = 27;

            /// <summary>
            /// Property Indexer for AccountNumber 
            /// </summary>
            public const int AccountNumber = 4;

            /// <summary>
            /// Property Indexer for CompanyId 
            /// </summary>
            public const int CompanyId = 5;

            /// <summary>
            /// Property Indexer for Amount 
            /// </summary>
            public const int Amount = 6;

            /// <summary>
            /// Property Indexer for Quantity 
            /// </summary>
            public const int Quantity = 7;

            /// <summary>
            /// Property Indexer for SourceCurrencyDecimals 
            /// </summary>
            public const int SourceCurrencyDecimals = 8;

            /// <summary>
            /// Property Indexer for SourceCurrencyAmount 
            /// </summary>
            public const int SourceCurrencyAmount = 9;

            /// <summary>
            /// Property Indexer for HomeCurrency 
            /// </summary>
            public const int HomeCurrency = 10;

            /// <summary>
            /// Property Indexer for CurrencyRateTable 
            /// </summary>
            public const int CurrencyRateTable = 11;

            /// <summary>
            /// Property Indexer for SourceCurrency 
            /// </summary>
            public const int SourceCurrency = 12;

            /// <summary>
            /// Property Indexer for CurrencyRateDate 
            /// </summary>
            public const int CurrencyRateDate = 13;

            /// <summary>
            /// Property Indexer for CurrencyRate 
            /// </summary>
            public const int CurrencyRate = 14;

            /// <summary>
            /// Property Indexer for CurrencyRateSpread 
            /// </summary>
            public const int CurrencyRateSpread = 15;

            /// <summary>
            /// Property Indexer for CurrencyRateDateMatching 
            /// </summary>
            public const int CurrencyRateDateMatching = 16;

            /// <summary>
            /// Property Indexer for CurrencyRateOperator 
            /// </summary>
            public const int CurrencyRateOperator = 17;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 18;

            /// <summary>
            /// Property Indexer for Reference 
            /// </summary>
            public const int Reference = 19;

            /// <summary>
            /// Property Indexer for JournalDate 
            /// </summary>
            public const int JournalDate = 20;

            /// <summary>
            /// Property Indexer for SourceLedger 
            /// </summary>
            public const int SourceLedger = 21;

            /// <summary>
            /// Property Indexer for SourceType 
            /// </summary>
            public const int SourceType = 22;

            /// <summary>
            /// Property Indexer for Comment 
            /// </summary>
            public const int Comment = 23;

            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 24;

            /// <summary>
            /// Property Indexer for ProcessSwitch 
            /// </summary>
            public const int ProcessSwitch = 25;

            /// <summary>
            /// Property Indexer for DestExists 
            /// </summary>
            public const int DestExists = 40;

            /// <summary>
            /// Property Indexer for DestDescription 
            /// </summary>
            public const int DestDescription = 41;

            /// <summary>
            /// Property Indexer for DestStatus 
            /// </summary>
            public const int DestStatus = 42;

            /// <summary>
            /// Property Indexer for DestMulticurrencySwitch 
            /// </summary>
            public const int DestMulticurrencySwitch = 43;

            /// <summary>
            /// Property Indexer for DestHomeCurrency 
            /// </summary>
            public const int DestHomeCurrency = 44;

            /// <summary>
            /// Property Indexer for DestHomeCurrencyDecimals 
            /// </summary>
            public const int DestHomeCurrencyDecimals = 45;

            /// <summary>
            /// Property Indexer for DestQtySwitch 
            /// </summary>
            public const int DestQtySwitch = 46;

            /// <summary>
            /// Property Indexer for DestQtyDecimals 
            /// </summary>
            public const int DestQtyDecimals = 47;

            /// <summary>
            /// Property Indexer for DestOptionalFlds 
            /// </summary>
            public const int DestOptionalFlds = 48;

            /// <summary>
            /// Property Indexer for RouteExists 
            /// </summary>
            public const int RouteExists = 55;

            /// <summary>
            /// Property Indexer for RouteDescription 
            /// </summary>
            public const int RouteDescription = 56;

            /// <summary>
            /// Property Indexer for RouteStatus 
            /// </summary>
            public const int RouteStatus = 57;

            /// <summary>
            /// Property Indexer for SourceCodeExists 
            /// </summary>
            public const int SourceCodeExists = 60;

            /// <summary>
            /// Property Indexer for SourceCodeDescription 
            /// </summary>
            public const int SourceCodeDescription = 61;

            /// <summary>
            /// Property Indexer for AcctExists 
            /// </summary>
            public const int AcctExists = 65;

            /// <summary>
            /// Property Indexer for AcctFormatted 
            /// </summary>
            public const int AcctFormatted = 66;

            /// <summary>
            /// Property Indexer for AccountDescription 
            /// </summary>
            public const int AccountDescription = 67;

            /// <summary>
            /// Property Indexer for AcctStatus 
            /// </summary>
            public const int AcctStatus = 68;

            /// <summary>
            /// Property Indexer for AcctMulticurrencySwitch 
            /// </summary>
            public const int AcctMulticurrencySwitch = 69;

            /// <summary>
            /// Property Indexer for AcctSpecificCurrenciesSwitch 
            /// </summary>
            public const int AcctSpecificCurrenciesSwitch = 70;

            /// <summary>
            /// Property Indexer for AcctControlSwitch 
            /// </summary>
            public const int AcctControlSwitch = 71;

            /// <summary>
            /// Property Indexer for AcctQtySwitch 
            /// </summary>
            public const int AcctQtySwitch = 72;

            /// <summary>
            /// Property Indexer for AcctOptionalFlds 
            /// </summary>
            public const int AcctOptionalFlds = 73;

            /// <summary>
            /// Property Indexer for AcctTransactionOptionalFlds 
            /// </summary>
            public const int AcctTransactionOptionalFlds = 74;

            /// <summary>
            /// Property Indexer for AcctUnitofMeasure 
            /// </summary>
            public const int AcctUnitofMeasure = 75;

            /// <summary>
            /// Property Indexer for TaxAuthority
            /// </summary>
            public const int TaxAuthority = 76;

            /// <summary>
            /// Property Indexer for TaxAccountType
            /// </summary>
            public const int TaxAccountType = 77;

            #endregion
        }
    }
}