// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of UserAccountPermission Constants
    /// </summary>
    public partial class UserAccountPermission
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0053";

        #region Properties

        /// <summary>
        /// Contains list of UserAccountPermission Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for UserID
            /// </summary>
            public const string UserID = "USER";

            /// <summary>
            /// Property for LineNo
            /// </summary>
            public const string LineNo = "LINE";

            /// <summary>
            /// Property for Allow
            /// </summary>
            public const string Allow = "SWCANSEE";

            /// <summary>
            /// Property for FromAccount
            /// </summary>
            public const string FromAccount = "BEGINAC";

            /// <summary>
            /// Property for ToAccount
            /// </summary>
            public const string ToAccount = "ENDAC";

            /// <summary>
            /// Property for FormattedFromAccount
            /// </summary>
            public const string FormattedFromAccount = "FMTBEGAC";

            /// <summary>
            /// Property for FormattedToAccount
            /// </summary>
            public const string FormattedToAccount = "FMTENDAC";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of UserAccountPermission Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for UserID
            /// </summary>
            public const int UserID = 1;

            /// <summary>
            /// Property Indexer for LineNo
            /// </summary>
            public const int LineNo = 2;

            /// <summary>
            /// Property Indexer for Allow
            /// </summary>
            public const int Allow = 3;

            /// <summary>
            /// Property Indexer for FromAccount
            /// </summary>
            public const int FromAccount = 4;

            /// <summary>
            /// Property Indexer for ToAccount
            /// </summary>
            public const int ToAccount = 5;

            /// <summary>
            /// Property Indexer for FormattedFromAccount
            /// </summary>
            public const int FormattedFromAccount = 8;

            /// <summary>
            /// Property Indexer for FormattedToAccount
            /// </summary>
            public const int FormattedToAccount = 9;

        }

        #endregion

    }
}
