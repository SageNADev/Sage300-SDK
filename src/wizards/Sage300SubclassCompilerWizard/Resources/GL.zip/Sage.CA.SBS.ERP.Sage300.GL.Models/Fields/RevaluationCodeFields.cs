﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of RevaluationCodes Constants 
    /// </summary>
    public partial class RevaluationCode
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0020";

        /// <summary>
        /// Contains list of RevaluationCodes Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for RevaluationCode 
            /// </summary>
            public const string Code = "RVALID";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";
            /// <summary>
            /// Property for RevalueBy 
            /// </summary>
            public const string RevalueBy = "NETCHGSW";
            /// <summary>
            /// Property for Revalue By String 
            /// </summary>
            public const string RevalueByString = "NETCHGSW";
            /// <summary>
            /// Property for RateType 
            /// </summary>
            public const string RateType = "RATETYPE";
            /// <summary>
            /// Property for SourceCodeID 
            /// </summary>
            public const string SourceCodeId = "SRCELDGR";
            /// <summary>
            /// Property for SourceType 
            /// </summary>
            public const string SourceType = "SRCETYPE";
            /// <summary>
            /// Property for UnrealizedOrExGainAcctID 
            /// </summary>
            public const string UnrealizedOrExGainAcctId = "ACCTGAIN";
            /// <summary>
            /// Property for UnrealizedOrExLossAcctID 
            /// </summary>
            public const string UnrealizedOrExLossAcctId = "ACCTLOSS";
            /// <summary>
            /// Property for ExchangeGainAcctID 
            /// </summary>
            public const string ExchangeGainAcctId = "RACCTGAIN";
            /// <summary>
            /// Property for ExchangeLossAcctID 
            /// </summary>
            public const string ExchangeLossAcctId = "RACCTLOSS";
            #endregion
        }

        /// <summary>
        /// Contains list of RevaluationCodes Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for RevaluationCode 
            /// </summary>
            public const int Code = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;
            /// <summary>
            /// Property Indexer for RevalueBy 
            /// </summary>
            public const int RevalueBy = 3;
            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 4;
            /// <summary>
            /// Property Indexer for SourceCodeID 
            /// </summary>
            public const int SourceCodeId = 5;
            /// <summary>
            /// Property Indexer for SourceType 
            /// </summary>
            public const int SourceType = 6;
            /// <summary>
            /// Property Indexer for UnrealizedOrExGainAcctID 
            /// </summary>
            public const int UnrealizedOrExGainAcctId = 7;
            /// <summary>
            /// Property Indexer for UnrealizedOrExLossAcctID 
            /// </summary>
            public const int UnrealizedOrExLossAcctId = 8;
            /// <summary>
            /// Property Indexer for ExchangeGainAcctID 
            /// </summary>
            public const int ExchangeGainAcctId = 9;
            /// <summary>
            /// Property Indexer for ExchangeLossAcctID 
            /// </summary>
            public const int ExchangeLossAcctId = 10;
            #endregion
        }
    }
}
