/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of AccountValidCurrencies Constants 
    /// </summary>
    public partial class AccountValidCurrencies
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0012";

        /// <summary>
        /// Contains list of AccountValidCurrencies Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for AccountNumber 
            /// </summary>
            public const string AccountNumber = "ACCTID";
            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CURNID";
            /// <summary>
            /// Property for RevaluationSwitch 
            /// </summary>
            public const string RevaluationSwitch = "REVALSW";
            /// <summary>
            /// Property for RevaluationCode 
            /// </summary>
            public const string RevaluationCode = "REVALID";

            #endregion
        }

        /// <summary>
        /// Contains list of AccountValidCurrencies Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for AccountNumber 
            /// </summary>
            public const int AccountNumber = 1;
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 2;
            /// <summary>
            /// Property Indexer for RevaluationSwitch 
            /// </summary>
            public const int RevaluationSwitch = 3;
            /// <summary>
            /// Property Indexer for RevaluationCode 
            /// </summary>
            public const int RevaluationCode = 4;

            #endregion
        }
    }
}
