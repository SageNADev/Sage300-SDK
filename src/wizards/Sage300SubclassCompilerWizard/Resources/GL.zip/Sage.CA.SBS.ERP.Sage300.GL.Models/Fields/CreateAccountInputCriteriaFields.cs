﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of CreateAccountInputCriteria Constants
    /// </summary>
    public partial class CreateAccountInputCriteria
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "GL0049";

        #region Properties

        /// <summary>
        /// Contains list of CreateAccountsInputCriteria Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for Key
            /// </summary>
            public const string Key = "KEY";

            /// <summary>
            /// Property for State
            /// </summary>
            public const string State = "STATESW";

            /// <summary>
            /// Property for TotalRecords
            /// </summary>
            public const string TotalRecords = "RECCOUNT";

            /// <summary>
            /// Property for FromAccountsWithStructureCode
            /// </summary>
            public const string FromAccountsWithStructureCode = "FRBRKID";

            /// <summary>
            /// Property for CreateUsingStructureCode
            /// </summary>
            public const string CreateUsingStructureCode = "CRBRKID";

            /// <summary>
            /// Property for SelectBy
            /// </summary>
            public const string SelectBy = "SELECTBY";

            /// <summary>
            /// Property for FromAccountNumber
            /// </summary>
            public const string FromAccountNumber = "FRACCTID";

            /// <summary>
            /// Property for ToAccountNumber
            /// </summary>
            public const string ToAccountNumber = "TOACCTID";

            /// <summary>
            /// Property for FromAccountGroupCode
            /// </summary>
            public const string FromAccountGroupCode = "FRGRPCOD";

            /// <summary>
            /// Property for ToAccountGroupCode
            /// </summary>
            public const string ToAccountGroupCode = "TOGRPCOD";

            /// <summary>
            /// Property for FromAccountGroupSortCode
            /// </summary>
            public const string FromAccountGroupSortCode = "FRGRPSCD";

            /// <summary>
            /// Property for ToAccountGroupSortCode
            /// </summary>
            public const string ToAccountGroupSortCode = "TOGRPSCD";

            /// <summary>
            /// Property for SegmentId
            /// </summary>
            public const string SegmentId = "IDSEG";

            /// <summary>
            /// Property for SegmentCode
            /// </summary>
            public const string SegmentCode = "SEGVAL";

            /// <summary>
            /// Property for DefaultSubledgerDetails
            /// </summary>
            public const string DefaultSubledgerDetails = "DFCTRL";

            /// <summary>
            /// Property for DefaultCurrencyOptions
            /// </summary>
            public const string DefaultCurrencyOptions = "DFMCSW";

            /// <summary>
            /// Property for IncludeExistingAccounts
            /// </summary>
            public const string IncludeExistingAccounts = "INCLEXIST";

            /// <summary>
            /// Property for CreateNewForSegment1
            /// </summary>
            public const string CreateNewForSegment1 = "CRNEW1";

            /// <summary>
            /// Property for FromSegment1
            /// </summary>
            public const string FromSegment1 = "FRSEGVAL1";

            /// <summary>
            /// Property for ToSegment1
            /// </summary>
            public const string ToSegment1 = "TOSEGVAL1";

            /// <summary>
            /// Property for DefaultOptionFromSegment1
            /// </summary>
            public const string DefaultOptionFromSegment1 = "DFSEGVAL1";

            /// <summary>
            /// Property for CreateNewForSegment2
            /// </summary>
            public const string CreateNewForSegment2 = "CRNEW2";

            /// <summary>
            /// Property for FromSegment2
            /// </summary>
            public const string FromSegment2 = "FRSEGVAL2";

            /// <summary>
            /// Property for ToSegment2
            /// </summary>
            public const string ToSegment2 = "TOSEGVAL2";

            /// <summary>
            /// Property for DefaultOptionFromSegment2
            /// </summary>
            public const string DefaultOptionFromSegment2 = "DFSEGVAL2";

            /// <summary>
            /// Property for CreateNewForSegment3
            /// </summary>
            public const string CreateNewForSegment3 = "CRNEW3";

            /// <summary>
            /// Property for FromSegment3
            /// </summary>
            public const string FromSegment3 = "FRSEGVAL3";

            /// <summary>
            /// Property for ToSegment3
            /// </summary>
            public const string ToSegment3 = "TOSEGVAL3";

            /// <summary>
            /// Property for DefaultOptionFromSegment3
            /// </summary>
            public const string DefaultOptionFromSegment3 = "DFSEGVAL3";

            /// <summary>
            /// Property for CreateNewForSegment4
            /// </summary>
            public const string CreateNewForSegment4 = "CRNEW4";

            /// <summary>
            /// Property for FromSegment4
            /// </summary>
            public const string FromSegment4 = "FRSEGVAL4";

            /// <summary>
            /// Property for ToSegment4
            /// </summary>
            public const string ToSegment4 = "TOSEGVAL4";

            /// <summary>
            /// Property for DefaultOptionFromSegment4
            /// </summary>
            public const string DefaultOptionFromSegment4 = "DFSEGVAL4";

            /// <summary>
            /// Property for CreateNewForSegment5
            /// </summary>
            public const string CreateNewForSegment5 = "CRNEW5";

            /// <summary>
            /// Property for FromSegment5
            /// </summary>
            public const string FromSegment5 = "FRSEGVAL5";

            /// <summary>
            /// Property for ToSegment5
            /// </summary>
            public const string ToSegment5 = "TOSEGVAL5";

            /// <summary>
            /// Property for DefaultOptionFromSegment5
            /// </summary>
            public const string DefaultOptionFromSegment5 = "DFSEGVAL5";

            /// <summary>
            /// Property for CreateNewForSegment6
            /// </summary>
            public const string CreateNewForSegment6 = "CRNEW6";

            /// <summary>
            /// Property for FromSegment6
            /// </summary>
            public const string FromSegment6 = "FRSEGVAL6";

            /// <summary>
            /// Property for ToSegment6
            /// </summary>
            public const string ToSegment6 = "TOSEGVAL6";

            /// <summary>
            /// Property for DefaultOptionFromSegment6
            /// </summary>
            public const string DefaultOptionFromSegment6 = "DFSEGVAL6";

            /// <summary>
            /// Property for CreateNewForSegment7
            /// </summary>
            public const string CreateNewForSegment7 = "CRNEW7";

            /// <summary>
            /// Property for FromSegment7
            /// </summary>
            public const string FromSegment7 = "FRSEGVAL7";

            /// <summary>
            /// Property for ToSegment7
            /// </summary>
            public const string ToSegment7 = "TOSEGVAL7";

            /// <summary>
            /// Property for DefaultOptionFromSegment7
            /// </summary>
            public const string DefaultOptionFromSegment7 = "DFSEGVAL7";

            /// <summary>
            /// Property for CreateNewForSegment8
            /// </summary>
            public const string CreateNewForSegment8 = "CRNEW8";

            /// <summary>
            /// Property for FromSegment8
            /// </summary>
            public const string FromSegment8 = "FRSEGVAL8";

            /// <summary>
            /// Property for ToSegment8
            /// </summary>
            public const string ToSegment8 = "TOSEGVAL8";

            /// <summary>
            /// Property for DefaultOptionFromSegment8
            /// </summary>
            public const string DefaultOptionFromSegment8 = "DFSEGVAL8";

            /// <summary>
            /// Property for CreateNewForSegment9
            /// </summary>
            public const string CreateNewForSegment9 = "CRNEW9";

            /// <summary>
            /// Property for FromSegment9
            /// </summary>
            public const string FromSegment9 = "FRSEGVAL9";

            /// <summary>
            /// Property for ToSegment9
            /// </summary>
            public const string ToSegment9 = "TOSEGVAL9";

            /// <summary>
            /// Property for DefaultOptionFromSegment9
            /// </summary>
            public const string DefaultOptionFromSegment9 = "DFSEGVAL9";

            /// <summary>
            /// Property for CreateNewForSegment10
            /// </summary>
            public const string CreateNewForSegment10 = "CRNEW10";

            /// <summary>
            /// Property for FromSegment10
            /// </summary>
            public const string FromSegment10 = "FRSEGVAL10";

            /// <summary>
            /// Property for ToSegment10
            /// </summary>
            public const string ToSegment10 = "TOSEGVAL10";

            /// <summary>
            /// Property for DefaultOptionFromSegment10
            /// </summary>
            public const string DefaultOptionFromSegment10 = "DFSEGVAL10";

            /// <summary>
            /// Property for SegmentOrderOftheSelectedAccount
            /// </summary>
            public const string SegmentOrderOftheSelectedAccount = "FRORDER";

            /// <summary>
            /// Property for SegmentOrderOftheCreatedAccount
            /// </summary>
            public const string SegmentOrderOftheCreatedAccount = "CRORDER";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of CreateAccountsInputCriteria Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for Key
            /// </summary>
            public const int Key = 1;

            /// <summary>
            /// Property Indexer for State
            /// </summary>
            public const int State = 2;

            /// <summary>
            /// Property Indexer for TotalRecords
            /// </summary>
            public const int TotalRecords = 3;

            /// <summary>
            /// Property Indexer for FromAccountsWithStructureCode
            /// </summary>
            public const int FromAccountsWithStructureCode = 4;

            /// <summary>
            /// Property Indexer for CreateUsingStructureCode
            /// </summary>
            public const int CreateUsingStructureCode = 5;

            /// <summary>
            /// Property Indexer for SelectBy
            /// </summary>
            public const int SelectBy = 6;

            /// <summary>
            /// Property Indexer for FromAccountNumber
            /// </summary>
            public const int FromAccountNumber = 7;

            /// <summary>
            /// Property Indexer for ToAccountNumber
            /// </summary>
            public const int ToAccountNumber = 8;

            /// <summary>
            /// Property Indexer for FromAccountGroupCode
            /// </summary>
            public const int FromAccountGroupCode = 9;

            /// <summary>
            /// Property Indexer for ToAccountGroupCode
            /// </summary>
            public const int ToAccountGroupCode = 10;

            /// <summary>
            /// Property Indexer for FromAccountGroupSortCode
            /// </summary>
            public const int FromAccountGroupSortCode = 11;

            /// <summary>
            /// Property Indexer for ToAccountGroupSortCode
            /// </summary>
            public const int ToAccountGroupSortCode = 12;

            /// <summary>
            /// Property Indexer for SegmentId
            /// </summary>
            public const int SegmentId = 13;

            /// <summary>
            /// Property Indexer for SegmentCode
            /// </summary>
            public const int SegmentCode = 14;

            /// <summary>
            /// Property Indexer for DefaultSubledgerDetails
            /// </summary>
            public const int DefaultSubledgerDetails = 15;

            /// <summary>
            /// Property Indexer for DefaultCurrencyOptions
            /// </summary>
            public const int DefaultCurrencyOptions = 16;

            /// <summary>
            /// Property Indexer for IncludeExistingAccounts
            /// </summary>
            public const int IncludeExistingAccounts = 17;

            /// <summary>
            /// Property Indexer for CreateNewForSegment1
            /// </summary>
            public const int CreateNewForSegment1 = 18;

            /// <summary>
            /// Property Indexer for FromSegment1
            /// </summary>
            public const int FromSegment1 = 19;

            /// <summary>
            /// Property Indexer for ToSegment1
            /// </summary>
            public const int ToSegment1 = 20;

            /// <summary>
            /// Property Indexer for DefaultOptionFromSegment1
            /// </summary>
            public const int DefaultOptionFromSegment1 = 21;

            /// <summary>
            /// Property Indexer for CreateNewForSegment2
            /// </summary>
            public const int CreateNewForSegment2 = 22;

            /// <summary>
            /// Property Indexer for FromSegment2
            /// </summary>
            public const int FromSegment2 = 23;

            /// <summary>
            /// Property Indexer for ToSegment2
            /// </summary>
            public const int ToSegment2 = 24;

            /// <summary>
            /// Property Indexer for DefaultOptionFromSegment2
            /// </summary>
            public const int DefaultOptionFromSegment2 = 25;

            /// <summary>
            /// Property Indexer for CreateNewForSegment3
            /// </summary>
            public const int CreateNewForSegment3 = 26;

            /// <summary>
            /// Property Indexer for FromSegment3
            /// </summary>
            public const int FromSegment3 = 27;

            /// <summary>
            /// Property Indexer for ToSegment3
            /// </summary>
            public const int ToSegment3 = 28;

            /// <summary>
            /// Property Indexer for DefaultOptionFromSegment3
            /// </summary>
            public const int DefaultOptionFromSegment3 = 29;

            /// <summary>
            /// Property Indexer for CreateNewForSegment4
            /// </summary>
            public const int CreateNewForSegment4 = 30;

            /// <summary>
            /// Property Indexer for FromSegment4
            /// </summary>
            public const int FromSegment4 = 31;

            /// <summary>
            /// Property Indexer for ToSegment4
            /// </summary>
            public const int ToSegment4 = 32;

            /// <summary>
            /// Property Indexer for DefaultOptionFromSegment4
            /// </summary>
            public const int DefaultOptionFromSegment4 = 33;

            /// <summary>
            /// Property Indexer for CreateNewForSegment5
            /// </summary>
            public const int CreateNewForSegment5 = 34;

            /// <summary>
            /// Property Indexer for FromSegment5
            /// </summary>
            public const int FromSegment5 = 35;

            /// <summary>
            /// Property Indexer for ToSegment5
            /// </summary>
            public const int ToSegment5 = 36;

            /// <summary>
            /// Property Indexer for DefaultOptionFromSegment5
            /// </summary>
            public const int DefaultOptionFromSegment5 = 37;

            /// <summary>
            /// Property Indexer for CreateNewForSegment6
            /// </summary>
            public const int CreateNewForSegment6 = 38;

            /// <summary>
            /// Property Indexer for FromSegment6
            /// </summary>
            public const int FromSegment6 = 39;

            /// <summary>
            /// Property Indexer for ToSegment6
            /// </summary>
            public const int ToSegment6 = 40;

            /// <summary>
            /// Property Indexer for DefaultOptionFromSegment6
            /// </summary>
            public const int DefaultOptionFromSegment6 = 41;

            /// <summary>
            /// Property Indexer for CreateNewForSegment7
            /// </summary>
            public const int CreateNewForSegment7 = 42;

            /// <summary>
            /// Property Indexer for FromSegment7
            /// </summary>
            public const int FromSegment7 = 43;

            /// <summary>
            /// Property Indexer for ToSegment7
            /// </summary>
            public const int ToSegment7 = 44;

            /// <summary>
            /// Property Indexer for DefaultOptionFromSegment7
            /// </summary>
            public const int DefaultOptionFromSegment7 = 45;

            /// <summary>
            /// Property Indexer for CreateNewForSegment8
            /// </summary>
            public const int CreateNewForSegment8 = 46;

            /// <summary>
            /// Property Indexer for FromSegment8
            /// </summary>
            public const int FromSegment8 = 47;

            /// <summary>
            /// Property Indexer for ToSegment8
            /// </summary>
            public const int ToSegment8 = 48;

            /// <summary>
            /// Property Indexer for DefaultOptionFromSegment8
            /// </summary>
            public const int DefaultOptionFromSegment8 = 49;

            /// <summary>
            /// Property Indexer for CreateNewForSegment9
            /// </summary>
            public const int CreateNewForSegment9 = 50;

            /// <summary>
            /// Property Indexer for FromSegment9
            /// </summary>
            public const int FromSegment9 = 51;

            /// <summary>
            /// Property Indexer for ToSegment9
            /// </summary>
            public const int ToSegment9 = 52;

            /// <summary>
            /// Property Indexer for DefaultOptionFromSegment9
            /// </summary>
            public const int DefaultOptionFromSegment9 = 53;

            /// <summary>
            /// Property Indexer for CreateNewForSegment10
            /// </summary>
            public const int CreateNewForSegment10 = 54;

            /// <summary>
            /// Property Indexer for FromSegment10
            /// </summary>
            public const int FromSegment10 = 55;

            /// <summary>
            /// Property Indexer for ToSegment10
            /// </summary>
            public const int ToSegment10 = 56;

            /// <summary>
            /// Property Indexer for DefaultOptionFromSegment10
            /// </summary>
            public const int DefaultOptionFromSegment10 = 57;

            /// <summary>
            /// Property Indexer for SegmentOrderOftheSelectedAccount
            /// </summary>
            public const int SegmentOrderOftheSelectedAccount = 58;

            /// <summary>
            /// Property Indexer for SegmentOrderOftheCreatedAccount
            /// </summary>
            public const int SegmentOrderOftheCreatedAccount = 59;

        }

        #endregion

    }
}
