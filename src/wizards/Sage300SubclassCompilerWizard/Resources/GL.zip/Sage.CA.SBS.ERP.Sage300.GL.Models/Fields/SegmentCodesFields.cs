﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class SegmentCodes
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0021";

        /// <summary>
        /// Contains list of SegmentCodes Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for SegmentNumber 
            /// </summary>
            public const string SegmentNumber = "IDSEG";
            /// <summary>
            /// Property for SegmentCode 
            /// </summary>
            public const string SegmentCode = "SEGVAL";
            /// <summary>
            /// Property for SegmentCodeDescription 
            /// </summary>
            public const string SegmentCodeDescription = "SEGVALDESC";
            /// <summary>
            /// Property for ClosingAccount 
            /// </summary>
            public const string ClosingAccount = "ACCTRETERN";

            #endregion
        }

        /// <summary>
        /// Contains list of SegmentCodes Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for SegmentNumber 
            /// </summary>
            public const int SegmentNumber = 1;
            /// <summary>
            /// Property Indexer for SegmentCode 
            /// </summary>
            public const int SegmentCode = 2;
            /// <summary>
            /// Property Indexer for SegmentCodeDescription 
            /// </summary>
            public const int SegmentCodeDescription = 3;
            /// <summary>
            /// Property Indexer for ClosingAccount 
            /// </summary>
            public const int ClosingAccount = 4;

            #endregion
        }

        /// <summary>
        /// To get integer value for unique id for grid
        /// </summary>
        public long SerialNumber { get; set; }
    }
}
