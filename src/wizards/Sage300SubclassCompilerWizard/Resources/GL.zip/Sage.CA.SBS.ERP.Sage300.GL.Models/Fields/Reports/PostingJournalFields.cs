// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Contains list of PostingJournal Constants
    /// </summary>
    public partial class PostingJournal
    {
        #region ViewName

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "81059224-50a6-4b0a-b8a5-765bd4f1f14c";

        #endregion

        #region PostingJournal Field Constants

        /// <summary>
        /// Contains list of PostingJournal Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for FromSequence
            /// </summary>
            public const string FromSequence = "FROMSEQ";

            /// <summary>
            /// Property for ToSequence
            /// </summary>
            public const string ToSequence = "TOSEQ";

            /// <summary>
            /// Property for QuantityDecimal
            /// </summary>
            public const string QuantityDecimal = "QTYDEC";

            /// <summary>
            /// Property for QtyHdg
            /// </summary>
            public const string QtyHdg = "QTYHDG";

            /// <summary>
            /// Property for UnitHdg
            /// </summary>
            public const string UnitHdg = "UNITHDG";

            /// <summary>
            /// Property for FunctionalCurrencyDecimal
            /// </summary>
            public const string FunctionalCurrencyDecimal = "FCURNDEC";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for UseGs
            /// </summary>
            public const string UseGs = "USEGS";

            /// <summary>
            /// Property for ApplicationUser
            /// </summary>
            public const string ApplicationUser = "USER";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "OPTIONALFIELDS";

            /// <summary>
            /// Property for DateCategory
            /// </summary>
            public const string DateCategory = "DATECATEGORY";

            /// <summary>
            /// Property for Reprint
            /// </summary>
            public const string Reprint = "REPRINT";

            /// <summary>
            /// Property for IctInstalled
            /// </summary>
            public const string IctInstalled = "ICTINST";

            /// <summary>
            /// Property for IcMultiCurrency
            /// </summary>
            public const string IcMultiCurrency = "ICTMULTI";

            /// <summary>
            /// Property for IcTexpType
            /// </summary>
            public const string IctExpType = "ICTEXPTYPE";

            /// <summary>
            /// E-09360
            /// Property for IncludeTaxInformation
            /// </summary>
            public const string IncludeTaxInformation = "INCLUDETAXINFORMATION";
        }

        #endregion

        #region PostingJournal Index Constants

        /// <summary>
        /// Contains list of PostingJournal Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for FromSequence
            /// </summary>
            public const int FromSequence = 2;

            /// <summary>
            /// Property Indexer for ToSequence
            /// </summary>
            public const int ToSequence = 3;

            /// <summary>
            /// Property Indexer for QuantityDecimal
            /// </summary>
            public const int QuantityDecimal = 4;

            /// <summary>
            /// Property Indexer for QtyHdg
            /// </summary>
            public const int QtyHdg = 5;

            /// <summary>
            /// Property Indexer for UnitHdg
            /// </summary>
            public const int UnitHdg = 6;

            /// <summary>
            /// Property Indexer for FunctionalCurrencyDecimal
            /// </summary>
            public const int FunctionalCurrencyDecimal = 7;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 8;

            /// <summary>
            /// Property Indexer for UseGs
            /// </summary>
            public const int UseGs = 9;

            /// <summary>
            /// Property Indexer for User
            /// </summary>
            public const int User = 10;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 11;

            /// <summary>
            /// Property Indexer for DateCategory
            /// </summary>
            public const int DateCategory = 12;

            /// <summary>
            /// Property Indexer for Reprint
            /// </summary>
            public const int Reprint = 13;

            /// <summary>
            /// Property Indexer for IctInstalled
            /// </summary>
            public const int IctInstalled = 14;

            /// <summary>
            /// Property Indexer for IcMultiCurrency
            /// </summary>
            public const int IcMultiCurrency = 15;

            /// <summary>
            /// Property Indexer for IcTexpType
            /// </summary>
            public const int IcTexpType = 16;
        }

        #endregion
    }
}
