﻿namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Constant class Account Group Report
    /// </summary>
    public partial class AccountGroupReport
    {
        /// <summary>
        /// Constant fields property
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Range By
            /// </summary>
            public const string RangeBy = "RANGEBY";

            /// <summary>
            /// From Account Group
            /// </summary>
            public const string FromAccountGroup = "FRACCTGRP";

            /// <summary>
            /// To Account Group
            /// </summary>
            public const string ToAccountGroup = "TOACCTGRP";

            /// <summary>
            /// From Sort Code
            /// </summary>
            public const string FromSortCode = "FRSORTCOD";

            /// <summary>
            /// To Sort Code
            /// </summary>
            public const string ToSortCode = "TOSORTCOD";
        }
    }
}
