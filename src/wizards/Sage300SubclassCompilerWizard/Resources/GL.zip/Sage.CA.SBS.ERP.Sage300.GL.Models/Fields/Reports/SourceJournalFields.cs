﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
    /// <summary>
    /// Contains list of SourceJournal Constants
    /// </summary>
    public partial class SourceJournal
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "0cdbcf04-0ec0-4869-8aa2-74d33d2d3d2a";

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "GL4104";

        #region Properties

        /// <summary>
        /// Contains list of SourceJournal Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for Frdtfmt
            /// </summary>
            public const string Frdtfmt = "FRDTFMT";

            /// <summary>
            /// Property for Todtfmt
            /// </summary>
            public const string Todtfmt = "TODTFMT";

            /// <summary>
            /// Property for Range
            /// </summary>
            public const string Range = "RANGE";

            /// <summary>
            /// Property for Fromacct
            /// </summary>
            public const string Fromacct = "FROMACCT";

            /// <summary>
            /// Property for Toacct
            /// </summary>
            public const string Toacct = "TOACCT";

            /// <summary>
            /// Property for SelectedSegment
            /// </summary>
            public const string SelectedSegment = "SORTBY";
            
            /// <summary>
            /// Property for Jrnlid
            /// </summary>
            public const string Jrnlid = "JRNLID";

            /// <summary>
            /// Property for Rptname
            /// </summary>
            public const string Rptname = "RPTNAME";

            /// <summary>
            /// Property for Fcurndec
            /// </summary>
            public const string Fcurndec = "FCURNDEC";

            /// <summary>
            /// Property for Qtydec
            /// </summary>
            public const string Qtydec = "QTYDEC";

            /// <summary>
            /// Property for Qtyhdg
            /// </summary>
            public const string Qtyhdg = "QTYHDG";

            /// <summary>
            /// Property for Unithdg
            /// </summary>
            public const string Unithdg = "UNITHDG";

            /// <summary>
            /// Property for Codelist2
            /// </summary>
            public const string Codelist2 = "CODELIST2";

            /// <summary>
            /// Property for SelectAccountGroups
            /// </summary>
            public const string SelectAccountGroups = "ACTGRPSB";
            
            /// <summary>
            /// Property for FromGroupId
            /// </summary>
            public const string FromGroupId = "FRGRPID";

            /// <summary>
            /// Property for ToGroupId
            /// </summary>
            public const string ToGroupId = "TOGRPID";
            

            /// <summary>
            /// Property for FromSortId
            /// </summary>
            public const string FromSortId = "FRSORTID";

            /// <summary>
            /// Property for ToSortId
            /// </summary>
            public const string ToSortId = "TOSORTID";

            /// <summary>
            /// Property for Segment1
            /// </summary>
            public const string Segment1 = "SEGNM1";

            /// <summary>
            /// Property for Segment2
            /// </summary>
            public const string Segment2 = "SEGNM2";

            /// <summary>
            /// Property for Segment3
            /// </summary>
            public const string Segment3 = "SEGNM3";

            /// <summary>
            /// Property for Segment4
            /// </summary>
            public const string Segment4 = "SEGNM4";

            /// <summary>
            /// Property for Segment5
            /// </summary>
            public const string Segment5 = "SEGNM5";

            /// <summary>
            /// Property for Segment6
            /// </summary>
            public const string Segment6 = "SEGNM6";

            /// <summary>
            /// Property for Segment7
            /// </summary>
            public const string Segment7 = "SEGNM7";

            /// <summary>
            /// Property for Segment8
            /// </summary>
            public const string Segment8 = "SEGNM8";

            /// <summary>
            /// Property for Segnm9
            /// </summary>
            public const string Segment9 = "SEGNM9";

            /// <summary>
            /// Property for Segment10
            /// </summary>
            public const string Segment10 = "SEGNM10";
            
            /// <summary>
            /// Property for SegmentFrom
            /// </summary>
            public const string SegmentFrom = "SEGFRS";

            /// <summary>
            /// Property for SegmentTo
            /// </summary>
            public const string SegmentTo = "SEGTOS";

            /// <summary>
            /// Property for Fromyear
            /// </summary>
            public const string Fromyear = "FROMYEAR";

            /// <summary>
            /// Property for Fromperd
            /// </summary>
            public const string Fromperd = "FROMPERD";

            /// <summary>
            /// Property for Toyear
            /// </summary>
            public const string Toyear = "TOYEAR";

            /// <summary>
            /// Property for Toperd
            /// </summary>
            public const string Toperd = "TOPERD";

            /// <summary>
            /// Property for Fromref
            /// </summary>
            public const string Fromref = "FROMREF";

            /// <summary>
            /// Property for Toref
            /// </summary>
            public const string Toref = "TOREF";

            /// <summary>
            /// Property for Fromdate
            /// </summary>
            public const string Fromdate = "FROMDATE";

            /// <summary>
            /// Property for Todate
            /// </summary>
            public const string Todate = "TODATE";

            /// <summary>
            /// Property for Fromseq
            /// </summary>
            public const string Fromseq = "FROMSEQ";

            /// <summary>
            /// Property for Toseq
            /// </summary>
            public const string Toseq = "TOSEQ";

            /// <summary>
            /// Property for Frbatch
            /// </summary>
            public const string Frbatch = "FRBATCH";

            /// <summary>
            /// Property for Tobatch
            /// </summary>
            public const string Tobatch = "TOBATCH";

            /// <summary>
            /// Property for Frscur
            /// </summary>
            public const string Frscur = "FRSCUR";

            /// <summary>
            /// Property for Toscur
            /// </summary>
            public const string Toscur = "TOSCUR";

            /// <summary>
            /// Property for Codeqry
            /// </summary>
            public const string Codeqry = "CODEQRY";

            /// <summary>
            /// Property for Codelist
            /// </summary>
            public const string Codelist = "CODELIST";

            /// <summary>
            /// Property for Orderby
            /// </summary>
            public const string Orderby = "ORDERBY";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for Usegs
            /// </summary>
            public const string Usegs = "USEGS";

            /// <summary>
            /// Property for User
            /// </summary>
            public const string User = "USER";

            /// <summary>
            /// Property for IncludeTransOptionalFields
            /// </summary>
            public const string IncludeTransOptionalFields = "OPTIONALFIELDS";
            
            /// <summary>
            /// Property for Seloptfld1
            /// </summary>
            public const string Seloptfld1 = "SELOPTFLD1";

            /// <summary>
            /// Property for Seloptfld2
            /// </summary>
            public const string Seloptfld2 = "SELOPTFLD2";

            /// <summary>
            /// Property for Seloptfld3
            /// </summary>
            public const string Seloptfld3 = "SELOPTFLD3";

            /// <summary>
            /// Property for Selopttype1
            /// </summary>
            public const string Selopttype1 = "SELOPTTYPE1";

            /// <summary>
            /// Property for Selopttype2
            /// </summary>
            public const string Selopttype2 = "SELOPTTYPE2";

            /// <summary>
            /// Property for Selopttype3
            /// </summary>
            public const string Selopttype3 = "SELOPTTYPE3";

            /// <summary>
            /// Property for Seloptdec1
            /// </summary>
            public const string Seloptdec1 = "SELOPTDEC1";

            /// <summary>
            /// Property for Seloptdec2
            /// </summary>
            public const string Seloptdec2 = "SELOPTDEC2";

            /// <summary>
            /// Property for Seloptdec3
            /// </summary>
            public const string Seloptdec3 = "SELOPTDEC3";

            /// <summary>
            /// Property for Seloptfrval1
            /// </summary>
            public const string Seloptfrval1 = "SELOPTFRVAL1";

            /// <summary>
            /// Property for Selopttoval1
            /// </summary>
            public const string Selopttoval1 = "SELOPTTOVAL1";

            /// <summary>
            /// Property for Seloptfrval2
            /// </summary>
            public const string Seloptfrval2 = "SELOPTFRVAL2";

            /// <summary>
            /// Property for Selopttoval2
            /// </summary>
            public const string Selopttoval2 = "SELOPTTOVAL2";

            /// <summary>
            /// Property for Seloptfrval3
            /// </summary>
            public const string Seloptfrval3 = "SELOPTFRVAL3";

            /// <summary>
            /// Property for Selopttoval3
            /// </summary>
            public const string Selopttoval3 = "SELOPTTOVAL3";

            /// <summary>
            /// Property for Seloptfrdisp1
            /// </summary>
            public const string Seloptfrdisp1 = "SELOPTFRDISP1";

            /// <summary>
            /// Property for Selopttodisp1
            /// </summary>
            public const string Selopttodisp1 = "SELOPTTODISP1";

            /// <summary>
            /// Property for Seloptfrdisp2
            /// </summary>
            public const string Seloptfrdisp2 = "SELOPTFRDISP2";

            /// <summary>
            /// Property for Selopttodisp2
            /// </summary>
            public const string Selopttodisp2 = "SELOPTTODISP2";

            /// <summary>
            /// Property for Seloptfrdisp3
            /// </summary>
            public const string Seloptfrdisp3 = "SELOPTFRDISP3";

            /// <summary>
            /// Property for Selopttodisp3
            /// </summary>
            public const string Selopttodisp3 = "SELOPTTODISP3";

            /// <summary>
            /// Property for FromFormatAccount
            /// </summary>
            public const string FromFormatAccount = "FROMFMTACCT";
            
            /// <summary>
            /// Property for ToFormatAccount
            /// </summary>
            public const string ToFormatAccount = "TOFMTACCT";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of SourceJournal Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for Frdtfmt
            /// </summary>
            public const int Frdtfmt = 2;

            /// <summary>
            /// Property Indexer for Todtfmt
            /// </summary>
            public const int Todtfmt = 3;

            /// <summary>
            /// Property Indexer for Range
            /// </summary>
            public const int Range = 4;

            /// <summary>
            /// Property Indexer for Fromacct
            /// </summary>
            public const int Fromacct = 5;

            /// <summary>
            /// Property Indexer for Toacct
            /// </summary>
            public const int Toacct = 6;

            /// <summary>
            /// Property Indexer for SelectedSegment
            /// </summary>
            public const int SelectedSegment = 7;
            
            /// <summary>
            /// Property Indexer for Jrnlid
            /// </summary>
            public const int Jrnlid = 8;

            /// <summary>
            /// Property Indexer for Rptname
            /// </summary>
            public const int Rptname = 9;

            /// <summary>
            /// Property Indexer for Fcurndec
            /// </summary>
            public const int Fcurndec = 10;

            /// <summary>
            /// Property Indexer for Qtydec
            /// </summary>
            public const int Qtydec = 11;

            /// <summary>
            /// Property Indexer for Qtyhdg
            /// </summary>
            public const int Qtyhdg = 12;

            /// <summary>
            /// Property Indexer for Unithdg
            /// </summary>
            public const int Unithdg = 13;

            /// <summary>
            /// Property Indexer for Codelist2
            /// </summary>
            public const int Codelist2 = 14;

            /// <summary>
            /// Property Indexer for SelectAccountGroups
            /// </summary>
            public const int SelectAccountGroups = 15;
            
            /// <summary>
            /// Property Indexer for FromGroupId
            /// </summary>
            public const int FromGroupId = 16;
            

            /// <summary>
            /// Property Indexer for ToGroupId
            /// </summary>
            public const int ToGroupId = 17;
            
            /// <summary>
            /// Property Indexer for FromSortId
            /// </summary>
            public const int FromSortId = 18;

            /// <summary>
            /// Property Indexer for ToSortId
            /// </summary>
            public const int ToSortId = 19;
            
            /// <summary>
            /// Property Indexer for Segment1
            /// </summary>
            public const int Segment1 = 20;

            /// <summary>
            /// Property Indexer for Segment2
            /// </summary>
            public const int Segment2 = 21;

            /// <summary>
            /// Property Indexer for Segnm3
            /// </summary>
            public const int Segment3 = 22;

            /// <summary>
            /// Property Indexer for Segment4
            /// </summary>
            public const int Segment4 = 23;

            /// <summary>
            /// Property Indexer for Segment5
            /// </summary>
            public const int Segment5 = 24;

            /// <summary>
            /// Property Indexer for Segment6
            /// </summary>
            public const int Segment6 = 25;

            /// <summary>
            /// Property Indexer for Segment7
            /// </summary>
            public const int Segment7 = 26;

            /// <summary>
            /// Property Indexer for Segment8
            /// </summary>
            public const int Segment8 = 27;

            /// <summary>
            /// Property Indexer for Segment9
            /// </summary>
            public const int Segment9 = 28;

            /// <summary>
            /// Property Indexer for Segment10
            /// </summary>
            public const int Segment10 = 29;

            /// <summary>
            /// Property Indexer for SegmentFrom
            /// </summary>
            public const int SegmentFrom = 30;

            /// <summary>
            /// Property Indexer for SegmentTo
            /// </summary>
            public const int SegmentTo = 31;

            /// <summary>
            /// Property Indexer for Fromyear
            /// </summary>
            public const int Fromyear = 32;

            /// <summary>
            /// Property Indexer for Fromperd
            /// </summary>
            public const int Fromperd = 33;

            /// <summary>
            /// Property Indexer for Toyear
            /// </summary>
            public const int Toyear = 34;

            /// <summary>
            /// Property Indexer for Toperd
            /// </summary>
            public const int Toperd = 35;

            /// <summary>
            /// Property Indexer for Fromref
            /// </summary>
            public const int Fromref = 36;

            /// <summary>
            /// Property Indexer for Toref
            /// </summary>
            public const int Toref = 37;

            /// <summary>
            /// Property Indexer for Fromdate
            /// </summary>
            public const int Fromdate = 38;

            /// <summary>
            /// Property Indexer for Todate
            /// </summary>
            public const int Todate = 39;

            /// <summary>
            /// Property Indexer for Fromseq
            /// </summary>
            public const int Fromseq = 40;

            /// <summary>
            /// Property Indexer for Toseq
            /// </summary>
            public const int Toseq = 41;

            /// <summary>
            /// Property Indexer for Frbatch
            /// </summary>
            public const int Frbatch = 42;

            /// <summary>
            /// Property Indexer for Tobatch
            /// </summary>
            public const int Tobatch = 43;

            /// <summary>
            /// Property Indexer for Frscur
            /// </summary>
            public const int Frscur = 44;

            /// <summary>
            /// Property Indexer for Toscur
            /// </summary>
            public const int Toscur = 45;

            /// <summary>
            /// Property Indexer for Codeqry
            /// </summary>
            public const int Codeqry = 46;

            /// <summary>
            /// Property Indexer for Codelist
            /// </summary>
            public const int Codelist = 47;

            /// <summary>
            /// Property Indexer for Orderby
            /// </summary>
            public const int Orderby = 48;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 49;

            /// <summary>
            /// Property Indexer for Usegs
            /// </summary>
            public const int Usegs = 50;

            /// <summary>
            /// Property Indexer for User
            /// </summary>
            public const int User = 51;

            /// <summary>
            /// Property Indexer for IncludeTransOptionalFields
            /// </summary>
            public const int IncludeTransOptionalFields = 52;

            /// <summary>
            /// Property Indexer for Seloptfld1
            /// </summary>
            public const int Seloptfld1 = 53;

            /// <summary>
            /// Property Indexer for Seloptfld2
            /// </summary>
            public const int Seloptfld2 = 54;

            /// <summary>
            /// Property Indexer for Seloptfld3
            /// </summary>
            public const int Seloptfld3 = 55;

            /// <summary>
            /// Property Indexer for Selopttype1
            /// </summary>
            public const int Selopttype1 = 56;

            /// <summary>
            /// Property Indexer for Selopttype2
            /// </summary>
            public const int Selopttype2 = 57;

            /// <summary>
            /// Property Indexer for Selopttype3
            /// </summary>
            public const int Selopttype3 = 58;

            /// <summary>
            /// Property Indexer for Seloptdec1
            /// </summary>
            public const int Seloptdec1 = 59;

            /// <summary>
            /// Property Indexer for Seloptdec2
            /// </summary>
            public const int Seloptdec2 = 60;

            /// <summary>
            /// Property Indexer for Seloptdec3
            /// </summary>
            public const int Seloptdec3 = 61;

            /// <summary>
            /// Property Indexer for Seloptfrval1
            /// </summary>
            public const int Seloptfrval1 = 62;

            /// <summary>
            /// Property Indexer for Selopttoval1
            /// </summary>
            public const int Selopttoval1 = 63;

            /// <summary>
            /// Property Indexer for Seloptfrval2
            /// </summary>
            public const int Seloptfrval2 = 64;

            /// <summary>
            /// Property Indexer for Selopttoval2
            /// </summary>
            public const int Selopttoval2 = 65;

            /// <summary>
            /// Property Indexer for Seloptfrval3
            /// </summary>
            public const int Seloptfrval3 = 66;

            /// <summary>
            /// Property Indexer for Selopttoval3
            /// </summary>
            public const int Selopttoval3 = 67;

            /// <summary>
            /// Property Indexer for Seloptfrdisp1
            /// </summary>
            public const int Seloptfrdisp1 = 68;

            /// <summary>
            /// Property Indexer for Selopttodisp1
            /// </summary>
            public const int Selopttodisp1 = 69;

            /// <summary>
            /// Property Indexer for Seloptfrdisp2
            /// </summary>
            public const int Seloptfrdisp2 = 70;

            /// <summary>
            /// Property Indexer for Selopttodisp2
            /// </summary>
            public const int Selopttodisp2 = 71;

            /// <summary>
            /// Property Indexer for Seloptfrdisp3
            /// </summary>
            public const int Seloptfrdisp3 = 72;

            /// <summary>
            /// Property Indexer for Selopttodisp3
            /// </summary>
            public const int Selopttodisp3 = 73;

            /// <summary>
            /// Property Indexer for FromFormatAccount
            /// </summary>
            public const int FromFormatAccount = 74;

            /// <summary>
            /// Property Indexer for ToFormatAccount
            /// </summary>
            public const int ToFormatAccount = 75;
        }

        #endregion

    }
}
