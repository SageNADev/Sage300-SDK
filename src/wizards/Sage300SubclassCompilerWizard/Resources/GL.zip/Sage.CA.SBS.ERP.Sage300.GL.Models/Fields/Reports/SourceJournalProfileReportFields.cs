// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
{
	/// <summary>
	/// Contains list of SourceJournalProfileReport Constants
	/// </summary>
	public partial class SourceJournalProfileReport
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "7ddf9cc7-1527-4451-bd47-a810f959ff28";

        /// <summary>
		/// Entity Name
		/// </summary>
        public const string EntityName = "GL4111";
        
		#region Properties

		/// <summary>
		/// Contains list of SourceJournalProfileReport Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Frjrnl
			/// </summary>
			public const string Frjrnl = "FRJRNL";

			/// <summary>
			/// Property for Tojrnl
			/// </summary>
			public const string Tojrnl = "TOJRNL";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of SourceJournalProfileReport Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Frjrnl
			/// </summary>
			public const int Frjrnl = 2;

			/// <summary>
			/// Property Indexer for Tojrnl
			/// </summary>
			public const int Tojrnl = 3;

		}

		#endregion

	}
}
