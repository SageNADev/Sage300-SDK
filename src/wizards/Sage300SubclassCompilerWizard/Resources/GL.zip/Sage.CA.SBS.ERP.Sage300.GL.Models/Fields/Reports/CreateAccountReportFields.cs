// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models.Reports
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CreateAccountReport Constants
    /// </summary>
    public partial class CreateAccountReport
    {
        #region ViewName

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "1a8807e3-6eff-4353-bb11-4222fb1b6da1";

        #endregion

        #region List of CreateAccountReport Fields Constants

        /// <summary>
        /// Contains list of CreateAccountReport Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Range
            /// </summary>
            public const string Range = "RANGE";

            /// <summary>
            /// Property for FromAccount
            /// </summary>
            public const string FromAccount = "FROMACCT";

            /// <summary>
            /// Property for ToAccount
            /// </summary>
            public const string ToAccount = "TOACCT";

            /// <summary>
            /// Property for SortBy
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// Property for SelectAccountGroups
            /// </summary>
            public const string SelectAccountGroups = "ACTGRPSB";

            /// <summary>
            /// Property for FromGroupId
            /// </summary>
            public const string FromGroupId = "FRGRPID";

            /// <summary>
            /// Property for ToGroupId
            /// </summary>
            public const string ToGroupId = "TOGRPID";

            /// <summary>
            /// Property for FromSortId
            /// </summary>
            public const string FromSortId = "FRSORTID";

            /// <summary>
            /// Property for ToSortId
            /// </summary>
            public const string ToSortId = "TOSORTID";

            /// <summary>
            /// Property for SegmentName1
            /// </summary>
            public const string SegmentName1 = "SEGNM1";

            /// <summary>
            /// Property for SegmentFrom1
            /// </summary>
            public const string SegmentFrom1 = "SEGFR1";

            /// <summary>
            /// Property for SegmentTo1
            /// </summary>
            public const string SegmentTo1 = "SEGTO1";

            /// <summary>
            /// Property for SegmentName2
            /// </summary>
            public const string SegmentName2 = "SEGNM2";

            /// <summary>
            /// Property for SegmentFrom2
            /// </summary>
            public const string SegmentFrom2 = "SEGFR2";

            /// <summary>
            /// Property for SegmentTo2
            /// </summary>
            public const string SegmentTo2 = "SEGTO2";

            /// <summary>
            /// Property for SegmentName3
            /// </summary>
            public const string SegmentName3 = "SEGNM3";

            /// <summary>
            /// Property for SegmentFrom3
            /// </summary>
            public const string SegmentFrom3 = "SEGFR3";

            /// <summary>
            /// Property for SegmentTo3
            /// </summary>
            public const string SegmentTo3 = "SEGTO3";

            /// <summary>
            /// Property for SegmentName4
            /// </summary>
            public const string SegmentName4 = "SEGNM4";

            /// <summary>
            /// Property for SegmentFrom4
            /// </summary>
            public const string SegmentFrom4 = "SEGFR4";

            /// <summary>
            /// Property for SegmentTo4
            /// </summary>
            public const string SegmentTo4 = "SEGTO4";

            /// <summary>
            /// Property for SegmentName5
            /// </summary>
            public const string SegmentName5 = "SEGNM5";

            /// <summary>
            /// Property for SegmentFrom5
            /// </summary>
            public const string SegmentFrom5 = "SEGFR5";

            /// <summary>
            /// Property for SegmentTo5
            /// </summary>
            public const string SegmentTo5 = "SEGTO5";

            /// <summary>
            /// Property for SegmentName6
            /// </summary>
            public const string SegmentName6 = "SEGNM6";

            /// <summary>
            /// Property for SegmentFrom6
            /// </summary>
            public const string SegmentFrom6 = "SEGFR6";

            /// <summary>
            /// Property for SegmentTo6
            /// </summary>
            public const string SegmentTo6 = "SEGTO6";

            /// <summary>
            /// Property for SegmentName7
            /// </summary>
            public const string SegmentName7 = "SEGNM7";

            /// <summary>
            /// Property for SegmentFrom7
            /// </summary>
            public const string SegmentFrom7 = "SEGFR7";

            /// <summary>
            /// Property for SegmentTo7
            /// </summary>
            public const string SegmentTo7 = "SEGTO7";

            /// <summary>
            /// Property for SegmentName8
            /// </summary>
            public const string SegmentName8 = "SEGNM8";

            /// <summary>
            /// Property for SegmentFrom8
            /// </summary>
            public const string SegmentFrom8 = "SEGFR8";

            /// <summary>
            /// Property for SegmentTo8
            /// </summary>
            public const string SegmentTo8 = "SEGTO8";

            /// <summary>
            /// Property for SegmentName9
            /// </summary>
            public const string SegmentName9 = "SEGNM9";

            /// <summary>
            /// Property for SegmentFrom9
            /// </summary>
            public const string SegmentFrom9 = "SEGFR9";

            /// <summary>
            /// Property for SegmentTo9
            /// </summary>
            public const string SegmentTo9 = "SEGTO9";

            /// <summary>
            /// Property for SegmentName10
            /// </summary>
            public const string SegmentName10 = "SEGNM10";

            /// <summary>
            /// Property for SegmentFrom10
            /// </summary>
            public const string SegmentFrom10 = "SEGFR10";

            /// <summary>
            /// Property for SegmentTo10
            /// </summary>
            public const string SegmentTo10 = "SEGTO10";

            /// <summary>
            /// Property for SegmentCode
            /// </summary>
            public const string SegmentCode = "SCODE";

            /// <summary>
            /// Property for IncludeCurrency
            /// </summary>
            public const string IncludeCurrency = "INCLAVC";

            /// <summary>
            /// Property for IncludeSubledger
            /// </summary>
            public const string IncludeSubledger = "INCLCAS";

            /// <summary>
            /// Property for FromAccountStructureCode
            /// </summary>
            public const string FromAccountStructureCode = "PFRSCODE";

            /// <summary>
            /// Property for CreateUsingStructureCode
            /// </summary>
            public const string CreateUsingStructureCode = "PCRSCODE";

            /// <summary>
            /// Property for PSelectBy
            /// </summary>
            public const string PSelectBy = "PSELECTBY";

            /// <summary>
            /// Property for PAccountFrom
            /// </summary>
            public const string PAccountFrom = "PACCTFR";

            /// <summary>
            /// Property for PAccountTo
            /// </summary>
            public const string PAccountTo = "PACCTTO";

            /// <summary>
            /// Property for PAccountGroupFrom
            /// </summary>
            public const string PAccountGroupFrom = "PACCTGRPFR";

            /// <summary>
            /// Property for PAccountGroupTo
            /// </summary>
            public const string PAccountGroupTo = "PACCTGRPTO";

            /// <summary>
            /// Property for PSortAccountGroupFrom
            /// </summary>
            public const string PSortAccountGroupFrom = "PSORTACCTGRPFR";

            /// <summary>
            /// Property for PSortAccountGroupTo
            /// </summary>
            public const string PSortAccountGroupTo = "PSORTACCTGRPTO";

            /// <summary>
            /// Property for PSegName
            /// </summary>
            public const string PSegName = "PSEGNAME";

            /// <summary>
            /// Property for PSegId
            /// </summary>
            public const string PSegId = "PSEGID";

            /// <summary>
            /// Property for PdfCas
            /// </summary>
            public const string PdfCas = "PDFCAS";

            /// <summary>
            /// Property for PdfAvc
            /// </summary>
            public const string PdfAvc = "PDFAVC";

            /// <summary>
            /// Property for PdfExist
            /// </summary>
            public const string PdfExist = "PDFEXIST";

            /// <summary>
            /// Property for Pseg1
            /// </summary>
            public const string PSeg1 = "PSEG1";

            /// <summary>
            /// Property for Pseg2
            /// </summary>
            public const string PSeg2 = "PSEG2";

            /// <summary>
            /// Property for Pseg3
            /// </summary>
            public const string PSeg3 = "PSEG3";

            /// <summary>
            /// Property for Pseg4
            /// </summary>
            public const string PSeg4 = "PSEG4";

            /// <summary>
            /// Property for Pseg5
            /// </summary>
            public const string PSeg5 = "PSEG5";

            /// <summary>
            /// Property for Pseg6
            /// </summary>
            public const string PSeg6 = "PSEG6";

            /// <summary>
            /// Property for Pseg7
            /// </summary>
            public const string PSeg7 = "PSEG7";

            /// <summary>
            /// Property for Pseg8
            /// </summary>
            public const string PSeg8 = "PSEG8";

            /// <summary>
            /// Property for Pseg9
            /// </summary>
            public const string PSeg9 = "PSEG9";

            /// <summary>
            /// Property for Pnew1
            /// </summary>
            public const string PNew1 = "PNEW1";

            /// <summary>
            /// Property for Pnew2
            /// </summary>
            public const string PNew2 = "PNEW2";

            /// <summary>
            /// Property for Pnew3
            /// </summary>
            public const string PNew3 = "PNEW3";

            /// <summary>
            /// Property for Pnew4
            /// </summary>
            public const string PNew4 = "PNEW4";

            /// <summary>
            /// Property for Pnew5
            /// </summary>
            public const string PNew5 = "PNEW5";

            /// <summary>
            /// Property for Pnew6
            /// </summary>
            public const string PNew6 = "PNEW6";

            /// <summary>
            /// Property for Pnew7
            /// </summary>
            public const string PNew7 = "PNEW7";

            /// <summary>
            /// Property for Pnew8
            /// </summary>
            public const string PNew8 = "PNEW8";

            /// <summary>
            /// Property for Pnew9
            /// </summary>
            public const string PNew9 = "PNEW9";

            /// <summary>
            /// Property for Psegfr1
            /// </summary>
            public const string PSegFrom1 = "PSEGFR1";

            /// <summary>
            /// Property for Psegfr2
            /// </summary>
            public const string PSegFrom2 = "PSEGFR2";

            /// <summary>
            /// Property for Psegfr3
            /// </summary>
            public const string PSegFrom3 = "PSEGFR3";

            /// <summary>
            /// Property for Psegfr4
            /// </summary>
            public const string PSegFrom4 = "PSEGFR4";

            /// <summary>
            /// Property for Psegfr5
            /// </summary>
            public const string PSegFrom5 = "PSEGFR5";

            /// <summary>
            /// Property for Psegfr6
            /// </summary>
            public const string PSegFrom6 = "PSEGFR6";

            /// <summary>
            /// Property for Psegfr7
            /// </summary>
            public const string PSegFrom7 = "PSEGFR7";

            /// <summary>
            /// Property for Psegfr8
            /// </summary>
            public const string PSegFrom8 = "PSEGFR8";

            /// <summary>
            /// Property for Psegfr9
            /// </summary>
            public const string PSegFrom9 = "PSEGFR9";

            /// <summary>
            /// Property for Psegto1
            /// </summary>
            public const string PSegTo1 = "PSEGTO1";

            /// <summary>
            /// Property for Psegto2
            /// </summary>
            public const string PSegTo2 = "PSEGTO2";

            /// <summary>
            /// Property for Psegto3
            /// </summary>
            public const string PSegTo3 = "PSEGTO3";

            /// <summary>
            /// Property for Psegto4
            /// </summary>
            public const string PSegTo4 = "PSEGTO4";

            /// <summary>
            /// Property for Psegto5
            /// </summary>
            public const string PSegTo5 = "PSEGTO5";

            /// <summary>
            /// Property for Psegto6
            /// </summary>
            public const string PSegTo6 = "PSEGTO6";

            /// <summary>
            /// Property for Psegto7
            /// </summary>
            public const string PSegTo7 = "PSEGTO7";

            /// <summary>
            /// Property for Psegto8
            /// </summary>
            public const string PSegTo8 = "PSEGTO8";

            /// <summary>
            /// Property for Psegto9
            /// </summary>
            public const string PSegTo9 = "PSEGTO9";

            /// <summary>
            /// Property for Psegdf1
            /// </summary>
            public const string PSegdf1 = "PSEGDF1";

            /// <summary>
            /// Property for Psegdf2
            /// </summary>
            public const string PSegdf2 = "PSEGDF2";

            /// <summary>
            /// Property for Psegdf3
            /// </summary>
            public const string PSegdf3 = "PSEGDF3";

            /// <summary>
            /// Property for Psegdf4
            /// </summary>
            public const string PSegdf4 = "PSEGDF4";

            /// <summary>
            /// Property for Psegdf5
            /// </summary>
            public const string PSegdf5 = "PSEGDF5";

            /// <summary>
            /// Property for Psegdf6
            /// </summary>
            public const string PSegdf6 = "PSEGDF6";

            /// <summary>
            /// Property for Psegdf7
            /// </summary>
            public const string PSegdf7 = "PSEGDF7";

            /// <summary>
            /// Property for Psegdf8
            /// </summary>
            public const string PSegdf8 = "PSEGDF8";

            /// <summary>
            /// Property for Psegdf9
            /// </summary>
            public const string PSegdf9 = "PSEGDF9";

            /// <summary>
            /// Property for Psegrow
            /// </summary>
            public const string PSegRow = "PSEGROW";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "OPTIONALFIELDS";

            /// <summary>
            /// Property for FromFmtAccount
            /// </summary>
            public const string FromFmtAccount = "FROMFMTACCT";

            /// <summary>
            /// Property for ToFmtAccount
            /// </summary>
            public const string ToFmtAccount = "TOFMTACCT";

            /// <summary>
            /// Property for PFmtAccountFrom
            /// </summary>
            public const string PFmtAccountFrom = "PFMTACCTFR";

            /// <summary>
            /// Property for PFmtAccountTo
            /// </summary>
            public const string PFmtAccountTo = "PFMTACCTTO";

            /// <summary>
            /// Property for SelectionCriteria
            /// </summary>
            public const string SelectionCriteria = "@SELECTION_CRITERIA";

            /// <summary>
            /// Property for GroupTitle
            /// </summary>
            public const string GroupTitle = "GRPTTL";
        }

        #endregion

        #region List of PostingJournals Index Constants

        /// <summary>
        /// Contains list of CreateAccountReport Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Range
            /// </summary>
            public const int Range = 2;

            /// <summary>
            /// Property Indexer for FromAccount
            /// </summary>
            public const int FromAccount = 3;

            /// <summary>
            /// Property Indexer for ToAccount
            /// </summary>
            public const int ToAccount = 4;

            /// <summary>
            /// Property Indexer for SortBy
            /// </summary>
            public const int SortBy = 5;

            /// <summary>
            /// Property Indexer for SelectAccountGroups
            /// </summary>
            public const int SelectAccountGroups = 6;

            /// <summary>
            /// Property Indexer for FromGroupId
            /// </summary>
            public const int FromGroupId = 7;

            /// <summary>
            /// Property Indexer for ToGroupId
            /// </summary>
            public const int ToGroupId = 8;

            /// <summary>
            /// Property Indexer for FromSortId
            /// </summary>
            public const int FromSortId = 9;

            /// <summary>
            /// Property Indexer for ToSortId
            /// </summary>
            public const int ToSortId = 10;

            /// <summary>
            /// Property Indexer for SegmentName1
            /// </summary>
            public const int SegmentName1 = 11;

            /// <summary>
            /// Property Indexer for SegmentFrom1
            /// </summary>
            public const int SegmentFrom1 = 12;

            /// <summary>
            /// Property Indexer for SegmentTo1
            /// </summary>
            public const int SegmentTo1 = 13;

            /// <summary>
            /// Property Indexer for SegmentName2
            /// </summary>
            public const int SegmentName2 = 14;

            /// <summary>
            /// Property Indexer for SegmentFrom2
            /// </summary>
            public const int SegmentFrom2 = 15;

            /// <summary>
            /// Property Indexer for SegmentTo2
            /// </summary>
            public const int SegmentTo2 = 16;

            /// <summary>
            /// Property Indexer for SegmentName3
            /// </summary>
            public const int SegmentName3 = 17;

            /// <summary>
            /// Property Indexer for SegmentFrom3
            /// </summary>
            public const int SegmentFrom3 = 18;

            /// <summary>
            /// Property Indexer for SegmentTo3
            /// </summary>
            public const int SegmentTo3 = 19;

            /// <summary>
            /// Property Indexer for SegmentName4
            /// </summary>
            public const int SegmentName4 = 20;

            /// <summary>
            /// Property Indexer for SegmentFrom4
            /// </summary>
            public const int SegmentFrom4 = 21;

            /// <summary>
            /// Property Indexer for SegmentTo4
            /// </summary>
            public const int SegmentTo4 = 22;

            /// <summary>
            /// Property Indexer for SegmentName5
            /// </summary>
            public const int SegmentName5 = 23;

            /// <summary>
            /// Property Indexer for SegmentFrom5
            /// </summary>
            public const int SegmentFrom5 = 24;

            /// <summary>
            /// Property Indexer for SegmentTo5
            /// </summary>
            public const int SegmentTo5 = 25;

            /// <summary>
            /// Property Indexer for SegmentName6
            /// </summary>
            public const int SegmentName6 = 26;

            /// <summary>
            /// Property Indexer for SegmentFrom6
            /// </summary>
            public const int SegmentFrom6 = 27;

            /// <summary>
            /// Property Indexer for SegmentTo6
            /// </summary>
            public const int SegmentTo6 = 28;

            /// <summary>
            /// Property Indexer for SegmentName7
            /// </summary>
            public const int SegmentName7 = 29;

            /// <summary>
            /// Property Indexer for SegmentFrom7
            /// </summary>
            public const int SegmentFrom7 = 30;

            /// <summary>
            /// Property Indexer for SegmentTo7
            /// </summary>
            public const int SegmentTo7 = 31;

            /// <summary>
            /// Property Indexer for SegmentName8
            /// </summary>
            public const int SegmentName8 = 32;

            /// <summary>
            /// Property Indexer for SegmentFrom8
            /// </summary>
            public const int SegmentFrom8 = 33;

            /// <summary>
            /// Property Indexer for SegmentTo8
            /// </summary>
            public const int SegmentTo8 = 34;

            /// <summary>
            /// Property Indexer for SegmentName9
            /// </summary>
            public const int SegmentName9 = 35;

            /// <summary>
            /// Property Indexer for SegmentFrom9
            /// </summary>
            public const int SegmentFrom9 = 36;

            /// <summary>
            /// Property Indexer for SegmentTo9
            /// </summary>
            public const int SegmentTo9 = 37;

            /// <summary>
            /// Property Indexer for SegmentName10
            /// </summary>
            public const int SegmentName10 = 38;

            /// <summary>
            /// Property Indexer for SegmentFrom10
            /// </summary>
            public const int SegmentFrom10 = 39;

            /// <summary>
            /// Property Indexer for SegmentTo10
            /// </summary>
            public const int SegmentTo10 = 40;

            /// <summary>
            /// Property Indexer for SegmentCode
            /// </summary>
            public const int SegmentCode = 41;

            /// <summary>
            /// Property Indexer for IncludeCurrency
            /// </summary>
            public const int IncludeCurrency = 42;

            /// <summary>
            /// Property Indexer for IncludeSubledger
            /// </summary>
            public const int IncludeSubledger = 43;

            /// <summary>
            /// Property Indexer for FromAccountStructureCode
            /// </summary>
            public const int FromAccountStructureCode = 44;

            /// <summary>
            /// Property Indexer for CreateUsingStructureCode
            /// </summary>
            public const int CreateUsingStructureCode = 45;

            /// <summary>
            /// Property Indexer for PSelectBy
            /// </summary>
            public const int PSelectBy = 46;

            /// <summary>
            /// Property Indexer for PAccountFrom
            /// </summary>
            public const int PAccountFrom = 47;

            /// <summary>
            /// Property Indexer for PAccountTo
            /// </summary>
            public const int PAccountTo = 48;

            /// <summary>
            /// Property Indexer for PAccountGroupFrom
            /// </summary>
            public const int PAccountGroupFrom = 49;

            /// <summary>
            /// Property Indexer for PAccountGroupTo
            /// </summary>
            public const int PAccountGroupTo = 50;

            /// <summary>
            /// Property Indexer for PSortAccountGroupFrom
            /// </summary>
            public const int PSortAccountGroupFrom = 51;

            /// <summary>
            /// Property Indexer for PSortAccountGroupTo
            /// </summary>
            public const int PSortAccountGroupTo = 52;

            /// <summary>
            /// Property Indexer for PSegName
            /// </summary>
            public const int PSegName = 53;

            /// <summary>
            /// Property Indexer for PSegId
            /// </summary>
            public const int PSegId = 54;

            /// <summary>
            /// Property Indexer for PdfCas
            /// </summary>
            public const int PdfCas = 55;

            /// <summary>
            /// Property Indexer for PdfAvc
            /// </summary>
            public const int PdfAvc = 56;

            /// <summary>
            /// Property Indexer for PdfExist
            /// </summary>
            public const int PdfExist = 57;

            /// <summary>
            /// Property Indexer for Pseg1
            /// </summary>
            public const int PSeg1 = 58;

            /// <summary>
            /// Property Indexer for Pseg2
            /// </summary>
            public const int PSeg2 = 59;

            /// <summary>
            /// Property Indexer for Pseg3
            /// </summary>
            public const int PSeg3 = 60;

            /// <summary>
            /// Property Indexer for Pseg4
            /// </summary>
            public const int PSeg4 = 61;

            /// <summary>
            /// Property Indexer for Pseg5
            /// </summary>
            public const int PSeg5 = 62;

            /// <summary>
            /// Property Indexer for Pseg6
            /// </summary>
            public const int PSeg6 = 63;

            /// <summary>
            /// Property Indexer for Pseg7
            /// </summary>
            public const int PSeg7 = 64;

            /// <summary>
            /// Property Indexer for Pseg8
            /// </summary>
            public const int PSeg8 = 65;

            /// <summary>
            /// Property Indexer for Pseg9
            /// </summary>
            public const int PSeg9 = 66;

            /// <summary>
            /// Property Indexer for Pnew1
            /// </summary>
            public const int PNew1 = 67;

            /// <summary>
            /// Property Indexer for Pnew2
            /// </summary>
            public const int PNew2 = 68;

            /// <summary>
            /// Property Indexer for Pnew3
            /// </summary>
            public const int PNew3 = 69;

            /// <summary>
            /// Property Indexer for Pnew4
            /// </summary>
            public const int PNew4 = 70;

            /// <summary>
            /// Property Indexer for Pnew5
            /// </summary>
            public const int PNew5 = 71;

            /// <summary>
            /// Property Indexer for Pnew6
            /// </summary>
            public const int PNew6 = 72;

            /// <summary>
            /// Property Indexer for Pnew7
            /// </summary>
            public const int PNew7 = 73;

            /// <summary>
            /// Property Indexer for Pnew8
            /// </summary>
            public const int PNew8 = 74;

            /// <summary>
            /// Property Indexer for Pnew9
            /// </summary>
            public const int PNew9 = 75;

            /// <summary>
            /// Property Indexer for Psegfr1
            /// </summary>
            public const int PSegFrom1 = 76;

            /// <summary>
            /// Property Indexer for Psegfr2
            /// </summary>
            public const int PSegFrom2 = 77;

            /// <summary>
            /// Property Indexer for Psegfr3
            /// </summary>
            public const int PSegFrom3 = 78;

            /// <summary>
            /// Property Indexer for Psegfr4
            /// </summary>
            public const int PSegFrom4 = 79;

            /// <summary>
            /// Property Indexer for Psegfr5
            /// </summary>
            public const int PSegFrom5 = 80;

            /// <summary>
            /// Property Indexer for Psegfr6
            /// </summary>
            public const int PSegFrom6 = 81;

            /// <summary>
            /// Property Indexer for Psegfr7
            /// </summary>
            public const int PSegFrom7 = 82;

            /// <summary>
            /// Property Indexer for Psegfr8
            /// </summary>
            public const int PSegFrom8 = 83;

            /// <summary>
            /// Property Indexer for Psegfr9
            /// </summary>
            public const int PSegFrom9 = 84;

            /// <summary>
            /// Property Indexer for Psegto1
            /// </summary>
            public const int PSegtTo1 = 85;

            /// <summary>
            /// Property Indexer for Psegto2
            /// </summary>
            public const int PSegtTo2 = 86;

            /// <summary>
            /// Property Indexer for Psegto3
            /// </summary>
            public const int PSegtTo3 = 87;

            /// <summary>
            /// Property Indexer for Psegto4
            /// </summary>
            public const int PSegtTo4 = 88;

            /// <summary>
            /// Property Indexer for Psegto5
            /// </summary>
            public const int PSegtTo5 = 89;

            /// <summary>
            /// Property Indexer for Psegto6
            /// </summary>
            public const int PSegtTo6 = 90;

            /// <summary>
            /// Property Indexer for Psegto7
            /// </summary>
            public const int PSegtTo7 = 91;

            /// <summary>
            /// Property Indexer for Psegto8
            /// </summary>
            public const int PSegtTo8 = 92;

            /// <summary>
            /// Property Indexer for Psegto9
            /// </summary>
            public const int PSegtTo9 = 93;

            /// <summary>
            /// Property Indexer for Psegdf1
            /// </summary>
            public const int PSegdf1 = 94;

            /// <summary>
            /// Property Indexer for Psegdf2
            /// </summary>
            public const int PSegdf2 = 95;

            /// <summary>
            /// Property Indexer for Psegdf3
            /// </summary>
            public const int PSegdf3 = 96;

            /// <summary>
            /// Property Indexer for Psegdf4
            /// </summary>
            public const int PSegdf4 = 97;

            /// <summary>
            /// Property Indexer for Psegdf5
            /// </summary>
            public const int PSegdf5 = 98;

            /// <summary>
            /// Property Indexer for Psegdf6
            /// </summary>
            public const int PSegdf6 = 99;

            /// <summary>
            /// Property Indexer for Psegdf7
            /// </summary>
            public const int PSegdf7 = 100;

            /// <summary>
            /// Property Indexer for Psegdf8
            /// </summary>
            public const int PSegdf8 = 101;

            /// <summary>
            /// Property Indexer for Psegdf9
            /// </summary>
            public const int PSegdf9 = 102;

            /// <summary>
            /// Property Indexer for Psegrow
            /// </summary>
            public const int PSegRow = 103;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 104;

            /// <summary>
            /// Property Indexer for FromFmtAccount
            /// </summary>
            public const int FromFmtAccount = 105;

            /// <summary>
            /// Property Indexer for ToFmtAccount
            /// </summary>
            public const int ToFmtAccount = 106;

            /// <summary>
            /// Property Indexer for PFmtAccountFrom
            /// </summary>
            public const int PFmtAccountFrom = 107;

            /// <summary>
            /// Property Indexer for PFmtAccountTo
            /// </summary>
            public const int PFmtAccountTo = 108;

            /// <summary>
            /// Property Indexer for SelectionCriteria
            /// </summary>
            public const int SelectionCriteria = 109;

            /// <summary>
            /// Property Indexer for GroupTitle
            /// </summary>
            public const int GroupTitle = 110;
        }

        #endregion
    }
}
