﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of SourceCurrencyInqProcessor Constants 
    /// </summary>
    public partial class AccountSourceCurrencyInqProcessor
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0060";

        /// <summary>
        /// Contains list of SourceCurrencyInqProcessor Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for Account 
            /// </summary>
            public const string Account = "ACCTID";
            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FSCSYR";
            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FSCSPERD";
            /// <summary>
            /// Property for RollupSwitch 
            /// </summary>
            public const string RollupSwitch = "ROLLUPSW";
            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "FSCSCURN";
            /// <summary>
            /// Property for CurrencyDescription 
            /// </summary>
            public const string CurrencyDescription = "CURNDESC";
            /// <summary>
            /// Property for SourceBalance 
            /// </summary>
            public const string SourceBalance = "SRCBAL";
            /// <summary>
            /// Property for EquivalentBalance 
            /// </summary>
            public const string EquivalentBalance = "EQUBAL";
            /// <summary>
            /// Property for ReportingBalance 
            /// </summary>
            public const string ReportingBalance = "RPTBAL";

            #endregion
        }

        /// <summary>
        /// Contains list of AccountAllocationInstructions Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for Account 
            /// </summary>
            public const int Account = 1;
            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 2;
            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 3;
            /// <summary>
            /// Property Indexer for RollupSwitch 
            /// </summary>
            public const int RollupSwitch = 4;
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 5;
            /// <summary>
            /// Property Indexer for CurrencyDescription 
            /// </summary>
            public const int CurrencyDescription = 6;
            /// <summary>
            /// Property Indexer for SourceBalance 
            /// </summary>
            public const int SourceBalance = 7;
            /// <summary>
            /// Property Indexer for EquivalentBalance 
            /// </summary>
            public const int EquivalentBalance = 8;
            /// <summary>
            /// Property Indexer for ReportingBalance 
            /// </summary>
            public const int ReportingBalance = 9;
            
            #endregion
        }

    }
}