/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of RollupMemberPreview Constants 
    /// </summary>
    public partial class RollupMemberPreview
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0063";

        /// <summary>
        /// Contains list of RollupMemberPreview Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for SourceAccount 
            /// </summary>
            public const string SourceAccount = "PARENT";
            /// <summary>
            /// Property for Account 
            /// </summary>
            public const string Account = "ACCTID";
            /// <summary>
            /// Property for AddOrDelete 
            /// </summary>
            public const string AddOrDelete = "OPSW";
            /// <summary>
            /// Property for FormattedAccount 
            /// </summary>
            public const string FormattedAccount = "ACCTFMTTD";
            /// <summary>
            /// Property for AccountDescription 
            /// </summary>
            public const string AccountDescription = "ACCTDESC";
            /// <summary>
            /// Property for RollupSwitch 
            /// </summary>
            public const string RollupSwitch = "ROLLUPSW";
            /// <summary>
            /// Property for AccountType 
            /// </summary>
            public const string AccountType = "ACCTTYPE";
            /// <summary>
            /// Property for AccountGroup 
            /// </summary>
            public const string AccountGroup = "ACCTGRPCOD";
            /// <summary>
            /// Property for NormalBalanceDROrCR 
            /// </summary>
            public const string NormalBalanceDrorCr = "ACCTBAL";
            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "ACTIVESW";
            /// <summary>
            /// Property for PosttoAccount 
            /// </summary>
            public const string PosttoAccount = "CONSLDSW";
            /// <summary>
            /// Property for Multicurrency 
            /// </summary>
            public const string Multicurrency = "MCSW";

            #endregion
        }

        /// <summary>
        /// Contains list of RollupMemberPreview Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for SourceAccount 
            /// </summary>
            public const int SourceAccountIndex = 1;
            /// <summary>
            /// Property Indexer for Account 
            /// </summary>
            public const int AccountIndex = 2;
            /// <summary>
            /// Property Indexer for AddOrDelete 
            /// </summary>
            public const int AddOrDeleteIndex = 3;
            /// <summary>
            /// Property Indexer for FormattedAccount 
            /// </summary>
            public const int FormattedAccountIndex = 7;
            /// <summary>
            /// Property Indexer for AccountDescription 
            /// </summary>
            public const int AccountDescriptionIndex = 8;
            /// <summary>
            /// Property Indexer for RollupSwitch 
            /// </summary>
            public const int RollupSwitchIndex = 9;
            /// <summary>
            /// Property Indexer for AccountType 
            /// </summary>
            public const int AccountTypeIndex = 10;
            /// <summary>
            /// Property Indexer for AccountGroup 
            /// </summary>
            public const int AccountGroupIndex = 11;
            /// <summary>
            /// Property Indexer for NormalBalanceDROrCR 
            /// </summary>
            public const int NormalBalanceDrorCrIndex = 12;
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int StatusIndex = 13;
            /// <summary>
            /// Property Indexer for PosttoAccount 
            /// </summary>
            public const int PosttoAccountIndex = 14;
            /// <summary>
            /// Property Indexer for Multicurrency 
            /// </summary>
            public const int MulticurrencyIndex = 15;

            #endregion
        }
    }
}
