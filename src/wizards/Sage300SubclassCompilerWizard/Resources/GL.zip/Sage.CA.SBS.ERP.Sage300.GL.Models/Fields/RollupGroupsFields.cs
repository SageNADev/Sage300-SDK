/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of RollupGroups Constants 
    /// </summary>
    public partial class RollupGroups
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0057";

        /// <summary>
        /// Contains list of RollupGroups Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for RollupAccount 
            /// </summary>
            public const string RollupAccount = "PARENT";
            /// <summary>
            /// Property for MemberAccount 
            /// </summary>
            public const string MemberAccount = "CHILD";
            /// <summary>
            /// Property for processMode 
            /// </summary>
            public const string ProcessMode = "MODE";
            /// <summary>
            /// Property for Hasglachdurecords? 
            /// </summary>
            public const string Hasglachdurecords = "DIRTYSW";
            /// <summary>
            /// Property for FormattedMemberAccount 
            /// </summary>
            public const string FormattedMemberAccount = "FMTCHILD";
            /// <summary>
            /// Property for MemberAccountDescription 
            /// </summary>
            public const string MemberAccountDescription = "CHDDESC";
            /// <summary>
            /// Property for FormattedRollupAccount 
            /// </summary>
            public const string FormattedRollupAccount = "FMTPARENT";
            /// <summary>
            /// Property for MemberAccountRollupSwitch 
            /// </summary>
            public const string MemberAccountRollupSwitch = "ROLLUPSW";
            /// <summary>
            /// Property for MemberAccountType 
            /// </summary>
            public const string MemberAccountType = "ACCTTYPE";
            /// <summary>
            /// Property for MemberAccountGroup 
            /// </summary>
            public const string MemberAccountGroup = "ACCTGRPCOD";
            /// <summary>
            /// Property for IntegrityCheckSwitch 
            /// </summary>
            public const string IntegrityCheckSwitch = "ICKFIXSW";
            /// <summary>
            /// Property for IntegrityCheckErrorCount 
            /// </summary>
            public const string IntegrityCheckErrorCount = "ICKFIXCNT";
            /// <summary>
            /// Property for MemberNormalBalanceDROrCR 
            /// </summary>
            public const string MemberNormalBalanceDrorCr = "ACCTBAL";
            /// <summary>
            /// Property for MemberStatus 
            /// </summary>
            public const string MemberStatus = "ACTIVESW";
            /// <summary>
            /// Property for MemberPosttoAccount 
            /// </summary>
            public const string MemberPosttoAccount = "CONSLDSW";
            /// <summary>
            /// Property for MemberMulticurrency 
            /// </summary>
            public const string MemberMulticurrency = "MCSW";
            /// <summary>
            /// Property for ProcessSwitch 
            /// </summary>
            public const string ProcessSwitch = "PROCESSCMD";

            #endregion
        }

        /// <summary>
        /// Contains list of RollupGroups Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for RollupAccount 
            /// </summary>
            public const int RollupAccount = 1;
            /// <summary>
            /// Property Indexer for MemberAccount 
            /// </summary>
            public const int MemberAccount = 2;
            /// <summary>
            /// Property Indexer for processMode 
            /// </summary>
            public const int ProcessMode = 7;
            /// <summary>
            /// Property Indexer for Hasglachdurecords? 
            /// </summary>
            public const int Hasglachdurecords = 8;
            /// <summary>
            /// Property Indexer for FormattedMemberAccount 
            /// </summary>
            public const int FormattedMemberAccount = 9;
            /// <summary>
            /// Property Indexer for MemberAccountDescription 
            /// </summary>
            public const int MemberAccountDescription = 10;
            /// <summary>
            /// Property Indexer for FormattedRollupAccount 
            /// </summary>
            public const int FormattedRollupAccount = 11;
            /// <summary>
            /// Property Indexer for MemberAccountRollupSwitch 
            /// </summary>
            public const int MemberAccountRollupSwitch = 12;
            /// <summary>
            /// Property Indexer for MemberAccountType 
            /// </summary>
            public const int MemberAccountType = 13;
            /// <summary>
            /// Property Indexer for MemberAccountGroup 
            /// </summary>
            public const int MemberAccountGroup = 14;
            /// <summary>
            /// Property Indexer for IntegrityCheckSwitch 
            /// </summary>
            public const int IntegrityCheckSwitch = 15;
            /// <summary>
            /// Property Indexer for IntegrityCheckErrorCount 
            /// </summary>
            public const int IntegrityCheckErrorCount = 16;
            /// <summary>
            /// Property Indexer for MemberNormalBalanceDROrCR 
            /// </summary>
            public const int MemberNormalBalanceDrorCr = 17;
            /// <summary>
            /// Property Indexer for MemberStatus 
            /// </summary>
            public const int MemberStatus = 18;
            /// <summary>
            /// Property Indexer for MemberPosttoAccount 
            /// </summary>
            public const int MemberPosttoAccount = 19;
            /// <summary>
            /// Property Indexer for MemberMulticurrency 
            /// </summary>
            public const int MemberMulticurrency = 20;
            /// <summary>
            /// Property Indexer for ProcessSwitch 
            /// </summary>
            public const int ProcessSwitch = 21;

            #endregion
        }
    }
}
