﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of JournalHeaders Constants 
    /// </summary>
    public partial class JournalEntry
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0006";

        /// <summary>
        /// Contains list of JournalHeaders Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "BATCHID";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "BTCHENTRY";
            /// <summary>
            /// Property for Originator 
            /// </summary>
            public const string Originator = "ORIGCOMP";
            /// <summary>
            /// Property for SourceLedger 
            /// </summary>
            public const string SourceLedger = "SRCELEDGER";
            /// <summary>
            /// Property for SourceType 
            /// </summary>
            public const string SourceType = "SRCETYPE";
            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FSCSYR";
            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FSCSPERD";
            /// <summary>
            /// Property for AutoReversal 
            /// </summary>
            public const string AutoReversal = "SWREVERSE";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "JRNLDESC";
            /// <summary>
            /// Property for Debits 
            /// </summary>
            public const string Debits = "JRNLDR";
            /// <summary>
            /// Property for Credits 
            /// </summary>
            public const string Credits = "JRNLCR";
            /// <summary>
            /// Property for Quantity 
            /// </summary>
            public const string Quantity = "JRNLQTY";
            /// <summary>
            /// Property for EntryDate 
            /// </summary>
            public const string EntryDate = "DATEENTRY";
            /// <summary>
            /// Property for DrillDownType 
            /// </summary>
            public const string DrillDownType = "DRILSRCTY";
            /// <summary>
            /// Property for DrillDownLinkNumber 
            /// </summary>
            public const string DrillDownLinkNumber = "DRILLDWNLK";
            /// <summary>
            /// Property for DrillDownApplicationSource 
            /// </summary>
            public const string DrillDownApplicationSource = "DRILAPP";
            /// <summary>
            /// Property for OutofBalanceBy 
            /// </summary>
            public const string OutofBalanceBy = "BALANCE";
            /// <summary>
            /// Property for SpecificReversalYear 
            /// </summary>
            public const string SpecificReversalYear = "REVYR";
            /// <summary>
            /// Property for SpecificReversalPeriod 
            /// </summary>
            public const string SpecificReversalPeriod = "REVPERD";
            /// <summary>
            /// Property for ErrorBatch 
            /// </summary>
            public const string ErrorBatch = "ERRBATCH";
            /// <summary>
            /// Property for ErrorEntry 
            /// </summary>
            public const string ErrorEntry = "ERRENTRY";
            /// <summary>
            /// Property for NumberofDetails 
            /// </summary>
            public const string NumberofDetails = "DETAILCNT";
            /// <summary>
            /// Property for Processswitches 
            /// </summary>
            public const string Processswitches = "PROCESSCMD";
            /// <summary>
            /// Property for OrigExists 
            /// </summary>
            public const string OrigExists = "ORIGEXIST";
            /// <summary>
            /// Property for OrigDescription 
            /// </summary>
            public const string OrigDescription = "ORIGDESC";
            /// <summary>
            /// Property for OrigStatus 
            /// </summary>
            public const string OrigStatus = "ORIGSTAT";
            /// <summary>
            /// Property for OrigMulticurrencySwitch 
            /// </summary>
            public const string OrigMulticurrencySwitch = "ORIGMCSW";
            /// <summary>
            /// Property for OrigHomeCurrency 
            /// </summary>
            public const string OrigHomeCurrency = "ORIGCURN";
            /// <summary>
            /// Property for OrigHomeCurrencyDecimals 
            /// </summary>
            public const string OrigHomeCurrencyDecimals = "ORIGDEC";
            /// <summary>
            /// Property for OrigQtySwitch 
            /// </summary>
            public const string OrigQtySwitch = "ORIGQTYSW";
            /// <summary>
            /// Property for OrigQtyDecimals 
            /// </summary>
            public const string OrigQtyDecimals = "ORIGQTYDEC";
            /// <summary>
            /// Property for SourceCodeExists 
            /// </summary>
            public const string SourceCodeExists = "SRCEXIST";
            /// <summary>
            /// Property for SourceCodeDescription 
            /// </summary>
            public const string SourceCodeDescription = "SRCDESC";
            /// <summary>
            /// Property for Entered By 
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";
            /// <summary>
            /// Property for DocumentDate 
            /// </summary>
            public const string DocumentDate = "DOCDATE";
            /// <summary>
            /// Property for Class Type
            /// </summary>
            public const string TransactionType = "CLASSTYPE";
            /// <summary>
            /// Property for  Tax Class 1
            /// </summary>
            public const string TaxVendorClass1 = "TAXVCLSS1";
            /// <summary>
            /// Property for  Tax class 2
            /// </summary>
            public const string TaxVendorClass2 = "TAXVCLSS2";
            /// <summary>
            /// Property for  Tax class 3
            /// </summary>
            public const string TaxVendorClass3 = "TAXVCLSS3";
            /// <summary>
            /// Property for  Tax class 4
            /// </summary>
            public const string TaxVendorClass4 = "TAXVCLSS4";
            /// <summary>
            /// Property for  Tax class 5
            /// </summary>
            public const string TaxVendorClass5 = "TAXVCLSS5";
            /// <summary>
            /// Property for  Tax item class 1
            /// </summary>
            public const string TaxItemClass1 = "TAXICLSS1";
            /// <summary>
            /// Property for  Tax item class 2
            /// </summary>
            public const string TaxItemClass2 = "TAXICLSS2";
            /// <summary>
            /// Property for  Tax item class 3
            /// </summary>
            public const string TaxItemClass3 = "TAXICLSS3";
            /// <summary>
            /// Property for  Tax item class 4
            /// </summary>
            public const string TaxItemClass4 = "TAXICLSS4";
            /// <summary>
            /// Property for  Tax item class 5
            /// </summary>
            public const string TaxItemClass5 = "TAXICLSS5";
            /// <summary>
            /// Property for Tax Base Amount 1
            /// </summary>
            public const string TaxBaseAmount1 = "BASETAX1";
            /// <summary>
            /// Property for Tax Base Amount 2
            /// </summary>
            public const string TaxBaseAmount2 = "BASETAX2";
            /// <summary>
            /// Property for Tax Base Amount 3
            /// </summary>
            public const string TaxBaseAmount3 = "BASETAX3";
            /// <summary>
            /// Property for Tax Base Amount 4
            /// </summary>
            public const string TaxBaseAmount4 = "BASETAX4";
            /// <summary>
            /// Property for Tax Base Amount 5
            /// </summary>
            public const string TaxBaseAmount5 = "BASETAX5";

            /// <summary>
            /// Property for Tax Reporting Rate Type
            /// </summary>
            public const string TaxReportingRateType = "RATETYPERC";
            /// <summary>
            ///  Property for Tax Reporting Rate date
            /// </summary>
            public const string TaxReportingRateDate = "RATEDATERC";
            /// <summary>
            ///  Property for Tax Customer Vendor Number
            /// </summary>
            public const string CustomerVendorNumber = "CUSTVEND";
            /// <summary>
            ///  Property for Tax Document Number
            /// </summary>
            public const string DocumentNumber = "DOCNUMBER";
          

            #endregion
        }

        /// <summary>
        /// Contains list of JournalHeaders Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 1;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 2;
            /// <summary>
            /// Property Indexer for Originator 
            /// </summary>
            public const int Originator = 25;
            /// <summary>
            /// Property Indexer for SourceLedger 
            /// </summary>
            public const int SourceLedger = 3;
            /// <summary>
            /// Property Indexer for SourceType 
            /// </summary>
            public const int SourceType = 4;
            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 5;
            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 6;
            /// <summary>
            /// Property Indexer for RESERVEDJournalEdit 
            /// </summary>
            public const int RESERVEDJournalEdit = 7;
            /// <summary>
            /// Property Indexer for AutoReversal 
            /// </summary>
            public const int AutoReversal = 8;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 9;
            /// <summary>
            /// Property Indexer for Debits 
            /// </summary>
            public const int Debits = 10;
            /// <summary>
            /// Property Indexer for Credits 
            /// </summary>
            public const int Credits = 11;
            /// <summary>
            /// Property Indexer for Quantity 
            /// </summary>
            public const int Quantity = 12;
            /// <summary>
            /// Property Indexer for EntryDate 
            /// </summary>
            public const int EntryDate = 14;
            /// <summary>
            /// Property Indexer for DrillDownType 
            /// </summary>
            public const int DrillDownType = 15;
            /// <summary>
            /// Property Indexer for DrillDownLinkNumber 
            /// </summary>
            public const int DrillDownLinkNumber = 16;
            /// <summary>
            /// Property Indexer for DrillDownApplicationSource 
            /// </summary>
            public const int DrillDownApplicationSource = 17;
            /// <summary>
            /// Property Indexer for OutofBalanceBy 
            /// </summary>
            public const int OutofBalanceBy = 20;
            /// <summary>
            /// Property Indexer for SpecificReversalYear 
            /// </summary>
            public const int SpecificReversalYear = 21;
            /// <summary>
            /// Property Indexer for SpecificReversalPeriod 
            /// </summary>
            public const int SpecificReversalPeriod = 22;
            /// <summary>
            /// Property Indexer for ErrorBatch 
            /// </summary>
            public const int ErrorBatch = 23;
            /// <summary>
            /// Property Indexer for ErrorEntry 
            /// </summary>
            public const int ErrorEntry = 24;
            /// <summary>
            /// Property Indexer for NumberofDetails 
            /// </summary>
            public const int NumberofDetails = 26;
            /// <summary>
            /// Property Indexer for Processswitches 
            /// </summary>
            public const int Processswitches = 27;
            /// <summary>
            /// Property Indexer for Entered By
            /// </summary>
            public const int EnteredBy = 28;
            /// <summary>
            /// Property Indexer for Document Date
            /// </summary>
            public const int DocumentDate = 29;
            /// <summary>
            /// Property Indexer for OrigExists 
            /// </summary>
            public const int OrigExists = 40;
            /// <summary>
            /// Property Indexer for OrigDescription 
            /// </summary>
            public const int OrigDescription = 41;
            /// <summary>
            /// Property Indexer for OrigStatus 
            /// </summary>
            public const int OrigStatus = 42;
            /// <summary>
            /// Property Indexer for OrigMulticurrencySwitch 
            /// </summary>
            public const int OrigMulticurrencySwitch = 43;
            /// <summary>
            /// Property Indexer for OrigHomeCurrency 
            /// </summary>
            public const int OrigHomeCurrency = 44;
            /// <summary>
            /// Property Indexer for OrigHomeCurrencyDecimals 
            /// </summary>
            public const int OrigHomeCurrencyDecimals = 45;
            /// <summary>
            /// Property Indexer for OrigQtySwitch 
            /// </summary>
            public const int OrigQtySwitch = 46;
            /// <summary>
            /// Property Indexer for OrigQtyDecimals 
            /// </summary>
            public const int OrigQtyDecimals = 47;
            /// <summary>
            /// Property Indexer for SourceCodeExists 
            /// </summary>
            public const int SourceCodeExists = 55;
            /// <summary>
            /// Property Indexer for SourceCodeDescription 
            /// </summary>
            public const int SourceCodeDescription = 56;

            /// <summary>
            /// Property Indexer for TaxGroup
            /// </summary>
            public const int TaxGroup = 57;

            /// <summary>
            /// Property Indexer for TaxTransactionType
            /// </summary>
            public const int TaxTransactionType = 58;

            /// <summary>
            /// Property Indexer for DoNotCalculateTax
            /// </summary>
            public const int DoNotCalculateTax = 59;
            /// <summary>
            /// Property Indexer for CustomerVendorNumber
            /// </summary>
            public const int CustomerVendorNumber = 60;

            /// <summary>
            /// Property Indexer for DocumentType
            /// </summary>
            public const int DocumentType = 61;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 62;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 63;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 64;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 65;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 66;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 67;

            /// <summary>
            /// Property Indexer for TaxVendorClass1
            /// </summary>
            public const int TaxVendorClass1 = 68;

            /// <summary>
            /// Property Indexer for TaxVendorClass2
            /// </summary>
            public const int TaxVendorClass2 = 69;

            /// <summary>
            /// Property Indexer for TaxVendorClass3
            /// </summary>
            public const int TaxVendorClass3 = 70;

            /// <summary>
            /// Property Indexer for TaxVendorClass4
            /// </summary>
            public const int TaxVendorClass4 = 71;

            /// <summary>
            /// Property Indexer for TaxVendorClass5
            /// </summary>
            public const int TaxVendorClass5 = 72;

            /// <summary>
            /// Property Indexer for TaxItemClass1
            /// </summary>
            public const int TaxItemClass1 = 73;

            /// <summary>
            /// Property Indexer for TaxItemClass2
            /// </summary>
            public const int TaxItemClass2 = 74;

            /// <summary>
            /// Property Indexer for TaxItemClass3
            /// </summary>
            public const int TaxItemClass3 = 75;

            /// <summary>
            /// Property Indexer for TaxItemClass4
            /// </summary>
            public const int TaxItemClass4 = 76;

            /// <summary>
            /// Property Indexer for TaxItemClass5
            /// </summary>
            public const int TaxItemClass5 = 77;

            /// <summary>
            /// Property Indexer for TaxBaseAmount1
            /// </summary>
            public const int TaxBaseAmount1 = 78;

            /// <summary>
            /// Property Indexer for TaxBaseAmount2
            /// </summary>
            public const int TaxBaseAmount2 = 79;

            /// <summary>
            /// Property Indexer for TaxBaseAmount3
            /// </summary>
            public const int TaxBaseAmount3 = 80;

            /// <summary>
            /// Property Indexer for TaxBaseAmount4
            /// </summary>
            public const int TaxBaseAmount4 = 81;

            /// <summary>
            /// Property Indexer for TaxBaseAmount5
            /// </summary>
            public const int TaxBaseAmount5 = 82;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 83;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 84;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 85;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 86;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 87;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1
            /// </summary>
            public const int TaxExpenseAmount1 = 88;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2
            /// </summary>
            public const int TaxExpenseAmount2 = 89;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3
            /// </summary>
            public const int TaxExpenseAmount3 = 90;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4
            /// </summary>
            public const int TaxExpenseAmount4 = 91;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5
            /// </summary>
            public const int TaxExpenseAmount5 = 92;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1
            /// </summary>
            public const int TaxRecoverableAmount1 = 93;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2
            /// </summary>
            public const int TaxRecoverableAmount2 = 94;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3
            /// </summary>
            public const int TaxRecoverableAmount3 = 95;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4
            /// </summary>
            public const int TaxRecoverableAmount4 = 96;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5
            /// </summary>
            public const int TaxRecoverableAmount5 = 97;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1
            /// </summary>
            public const int TaxAllocatedAmount1 = 98;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2
            /// </summary>
            public const int TaxAllocatedAmount2 = 99;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3
            /// </summary>
            public const int TaxAllocatedAmount3 = 100;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4
            /// </summary>
            public const int TaxAllocatedAmount4 = 101;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5
            /// </summary>
            public const int TaxAllocatedAmount5 = 102;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1
            /// </summary>
            public const int TaxReportingAmount1 = 103;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2
            /// </summary>
            public const int TaxReportingAmount2 = 104;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3
            /// </summary>
            public const int TaxReportingAmount3 = 105;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4
            /// </summary>
            public const int TaxReportingAmount4 = 106;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5
            /// </summary>
            public const int TaxReportingAmount5 = 107;

            /// <summary>
            /// Property Indexer for TaxReportingExpensed1
            /// </summary>
            public const int TaxReportingExpensed1 = 108;

            /// <summary>
            /// Property Indexer for TaxReportingExpensed2
            /// </summary>
            public const int TaxReportingExpensed2 = 109;

            /// <summary>
            /// Property Indexer for TaxReportingExpensed3
            /// </summary>
            public const int TaxReportingExpensed3 = 110;

            /// <summary>
            /// Property Indexer for TaxReportingExpensed4
            /// </summary>
            public const int TaxReportingExpensed4 = 111;

            /// <summary>
            /// Property Indexer for TaxReportingExpensed5
            /// </summary>
            public const int TaxReportingExpensed5 = 112;

            /// <summary>
            /// Property Indexer for TXRECVB1RC
            /// </summary>
            public const int TXRECVB1RC = 113;

            /// <summary>
            /// Property Indexer for TXRECVB2RC
            /// </summary>
            public const int TXRECVB2RC = 114;

            /// <summary>
            /// Property Indexer for TXRECVB3RC
            /// </summary>
            public const int TXRECVB3RC = 115;

            /// <summary>
            /// Property Indexer for TXRECVB4RC
            /// </summary>
            public const int TXRECVB4RC = 116;

            /// <summary>
            /// Property Indexer for TXRECVB5RC
            /// </summary>
            public const int TXRECVB5RC = 117;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 118;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 119;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 120;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 121;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 122;

            /// <summary>
            /// Property Indexer for TaxReportingCurrencyCode
            /// </summary>
            public const int TaxReportingCurrencyCode = 123;

            /// <summary>
            /// Property Indexer for TaxReportingRate
            /// </summary>
            public const int TaxReportingRate = 124;

            /// <summary>
            /// Property Indexer for TaxReportingRateType
            /// </summary>
            public const int TaxReportingRateType = 125;

            /// <summary>
            /// Property Indexer for TaxReportingRateDate
            /// </summary>
            public const int TaxReportingRateDate = 126;

            /// <summary>
            /// Property Indexer for TaxReportingRateOperation
            /// </summary>
            public const int TaxReportingRateOperation = 127;

            /// <summary>
            /// Property Indexer for TaxExpenseAccount1
            /// </summary>
            public const int TaxExpenseAccount1 = 128;

            /// <summary>
            /// Property Indexer for TaxExpenseAccount2
            /// </summary>
            public const int TaxExpenseAccount2 = 129;

            /// <summary>
            /// Property Indexer for TaxExpenseAccount3
            /// </summary>
            public const int TaxExpenseAccount3 = 130;

            /// <summary>
            /// Property Indexer for TaxExpenseAccount4
            /// </summary>
            public const int TaxExpenseAccount4 = 131;

            /// <summary>
            /// Property Indexer for TaxExpenseAccount5
            /// </summary>
            public const int TaxExpenseAccount5 = 132;

            /// <summary>
            /// Property Indexer for TaxRecoverableAccount1
            /// </summary>
            public const int TaxRecoverableAccount1 = 133;

            /// <summary>
            /// Property Indexer for TaxRecoverableAccount2
            /// </summary>
            public const int TaxRecoverableAccount2 = 134;

            /// <summary>
            /// Property Indexer for TaxRecoverableAccount3
            /// </summary>
            public const int TaxRecoverableAccount3 = 135;

            /// <summary>
            /// Property Indexer for TaxRecoverableAccount4
            /// </summary>
            public const int TaxRecoverableAccount4 = 136;

            /// <summary>
            /// Property Indexer for TaxRecoverableAccount5
            /// </summary>
            public const int TaxRecoverableAccount5 = 137;

            /// <summary>
            /// Property Indexer for TaxRate1
            /// </summary>
            public const int TaxRate1 = 138;

            /// <summary>
            /// Property Indexer for TaxRate2
            /// </summary>
            public const int TaxRate2 = 139;

            /// <summary>
            /// Property Indexer for TaxRate3
            /// </summary>
            public const int TaxRate3 = 140;

            /// <summary>
            /// Property Indexer for TaxRate4
            /// </summary>
            public const int TaxRate4 = 141;

            /// <summary>
            /// Property Indexer for TaxRate5
            /// </summary>
            public const int TaxRate5 = 142;

            /// <summary>
            /// Property Indexer for FunctionalTaxAmount1
            /// </summary>
            public const int FunctionalTaxAmount1 = 143;

            /// <summary>
            /// Property Indexer for FunctionalTaxAmount2
            /// </summary>
            public const int FunctionalTaxAmount2 = 144;

            /// <summary>
            /// Property Indexer for FunctionalTaxAmount3
            /// </summary>
            public const int FunctionalTaxAmount3 = 145;

            /// <summary>
            /// Property Indexer for FunctionalTaxAmount4
            /// </summary>
            public const int FunctionalTaxAmount4 = 146;

            /// <summary>
            /// Property Indexer for FunctionalTaxAmount5
            /// </summary>
            public const int FunctionalTaxAmount5 = 147;

            /// <summary>
            /// Property Indexer for FunctionalTaxBaseAmount1
            /// </summary>
            public const int FunctionalTaxBaseAmount1 = 148;

            /// <summary>
            /// Property Indexer for FunctionalTaxBaseAmount2
            /// </summary>
            public const int FunctionalTaxBaseAmount2 = 149;

            /// <summary>
            /// Property Indexer for FunctionalTaxBaseAmount3
            /// </summary>
            public const int FunctionalTaxBaseAmount3 = 150;

            /// <summary>
            /// Property Indexer for FunctionalTaxBaseAmount4
            /// </summary>
            public const int FunctionalTaxBaseAmount4 = 151;

            /// <summary>
            /// Property Indexer for FunctionalTaxBaseAmount5
            /// </summary>
            public const int FunctionalTaxBaseAmount5 = 152;

            /// <summary>
            /// Property Indexer for FunctionalExpensedAmount1
            /// </summary>
            public const int FunctionalExpensedAmount1 = 153;

            /// <summary>
            /// Property Indexer for FunctionalExpensedAmount2
            /// </summary>
            public const int FunctionalExpensedAmount2 = 154;

            /// <summary>
            /// Property Indexer for FunctionalExpensedAmount3
            /// </summary>
            public const int FunctionalExpensedAmount3 = 155;

            /// <summary>
            /// Property Indexer for FunctionalExpensedAmount4
            /// </summary>
            public const int FunctionalExpensedAmount4 = 156;

            /// <summary>
            /// Property Indexer for FunctionalExpensedAmount5
            /// </summary>
            public const int FunctionalExpensedAmount5 = 157;

            /// <summary>
            /// Property Indexer for FunctionalRecoverableAmount1
            /// </summary>
            public const int FunctionalRecoverableAmount1 = 158;

            /// <summary>
            /// Property Indexer for FunctionalRecoverableAmount2
            /// </summary>
            public const int FunctionalRecoverableAmount2 = 159;

            /// <summary>
            /// Property Indexer for FunctionalRecoverableAmount3
            /// </summary>
            public const int FunctionalRecoverableAmount3 = 160;

            /// <summary>
            /// Property Indexer for FunctionalRecoverableAmount4
            /// </summary>
            public const int FunctionalRecoverableAmount4 = 161;

            /// <summary>
            /// Property Indexer for FunctionalRecoverableAmount5
            /// </summary>
            public const int FunctionalRecoverableAmount5 = 162;

            /// <summary>
            /// Property Indexer for FunctionalAllocatedAmount1
            /// </summary>
            public const int FunctionalAllocatedAmount1 = 163;

            /// <summary>
            /// Property Indexer for FunctionalAllocatedAmount2
            /// </summary>
            public const int FunctionalAllocatedAmount2 = 164;

            /// <summary>
            /// Property Indexer for FunctionalAllocatedAmount3
            /// </summary>
            public const int FunctionalAllocatedAmount3 = 165;

            /// <summary>
            /// Property Indexer for FunctionalAllocatedAmount4
            /// </summary>
            public const int FunctionalAllocatedAmount4 = 166;

            /// <summary>
            /// Property Indexer for FunctionalAllocatedAmount5
            /// </summary>
            public const int FunctionalAllocatedAmount5 = 167;

            /// <summary>
            /// Property Indexer for Invoice Total for Tax group currency
            /// </summary>
            public const int InvoiceTotalTaxGroup = 168;
            /// <summary>
            /// Property Indexer for Invoice Tota lFunctional currency
            /// </summary>
            public const int InvoiceTotalFunctional = 169;

            /// <summary>
            /// Property Indexer for TaxGroupDescription
            /// </summary>
            public const int TaxGroupDescription = 170;
            /// <summary>
            /// Property Indexer for Tax Authority1 Description
            /// </summary>
            public const int TaxAuthorityDescription1 = 171;
            /// <summary>
            /// Property Indexer for Tax Authority2 Description
            /// </summary>
            public const int TaxAuthorityDescription2 = 172;
            /// <summary>
            /// Property Indexer for Tax Authority3 Description
            /// </summary>
            public const int TaxAuthorityDescription3 = 173;
            /// <summary>
            /// Property Indexer for Tax Authority4 Description
            /// </summary>
            public const int TaxAuthorityDescription4 = 174;
            /// <summary>
            /// Property Indexer for Tax Authority5 Description
            /// </summary>
            public const int TaxAuthorityDescription5 = 175;
            /// <summary>
            /// Property Indexer for Currency Code Description
            /// </summary>
            public const int CurrencyCodeDescription = 176;
            /// <summary>
            /// Property Indexer for Rate Type Description
            /// </summary>
            public const int RateTypeDescription = 177;
            /// <summary>
            /// Property Indexer for Customer/Vendor Name
            /// </summary>
            public const int CustomerVendorName = 178;
            /// <summary>
            /// Property Indexer for DocumentType2
            /// </summary>
            public const int DocumentType2 = 179;
            #endregion
        }
    }
}
