namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of AccountGroup-SortOrders Constants 
    /// </summary>
	public partial class AccountGroupSortOrders 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "GL0056";

        /// <summary>
        /// Contains list of AccountGroup-SortOrders Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for AccountGroupCode 
        /// </summary>
	    public const string AccountGroupCode  = "ACCTGRPCOD";
	            /// <summary>
        /// Property for NewSortCode 
        /// </summary>
	    public const string NewSortCode  = "SORTCODE";
	            /// <summary>
        /// Property for AccountGroupDescription 
        /// </summary>
	    public const string AccountGroupDescription  = "ACCTGRPDES";
	            /// <summary>
        /// Property for OriginalSortCode 
        /// </summary>
	    public const string OriginalSortCode  = "OLDSORTCOD";
	            /// <summary>
        /// Property for EmptyTableSwitch 
        /// </summary>
	    public const string EmptyTableSwitch  = "IEMPTYTBL";
	            /// <summary>
        /// Property for AccountGroupExistsSwitch 
        /// </summary>
	    public const string AccountGroupExistsSwitch  = "IAGPEXIST";
	            /// <summary>
        /// Property for ProcessCommand 
        /// </summary>
	    public const string ProcessCommand  = "PROCESSCMD";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of AccountGroup-SortOrders Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for AccountGroupCode 
        /// </summary>
	    public const int AccountGroupCode  = 1;
	             /// <summary>
        /// Property Indexer for NewSortCode 
        /// </summary>
	    public const int NewSortCode  = 2;
	             /// <summary>
        /// Property Indexer for AccountGroupDescription 
        /// </summary>
	    public const int AccountGroupDescription  = 10;
	             /// <summary>
        /// Property Indexer for OriginalSortCode 
        /// </summary>
	    public const int OriginalSortCode  = 11;
	             /// <summary>
        /// Property Indexer for EmptyTableSwitch 
        /// </summary>
	    public const int EmptyTableSwitch  = 12;
	             /// <summary>
        /// Property Indexer for AccountGroupExistsSwitch 
        /// </summary>
	    public const int AccountGroupExistsSwitch  = 13;
	             /// <summary>
        /// Property Indexer for ProcessCommand 
        /// </summary>
	    public const int ProcessCommand  = 14;
	     
        #endregion
	    }

	
	}
}
	