﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
// ReSharper disable CheckNamespace


namespace Sage.CA.SBS.ERP.Sage300.GL.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of AccountStructureFields Constants 
    /// </summary>
    public partial class AccountStructure
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "GL0023";

        /// <summary>
        /// Contains list of AccountStructureFields Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for Structure Code 
            /// </summary>
            public const string StructureCode = "ACCTBRKID";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "ABRKDESC";

            /// <summary>
            /// Property for Segment Number1 
            /// </summary>
            public const string SegmentNumber1 = "ABRKID1";

            /// <summary>
            /// Property for Segment1 Starting Position 
            /// </summary>
            public const string Segment1StartingPosition = "ABRKSTRT1";

            /// <summary>
            /// Property for Segment1 Length 
            /// </summary>
            public const string Segment1Length = "ABRKLEN1";

            /// <summary>
            /// RESERVEDAcctseg1validationseq
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctseg1validationseq = "ABRKVSEQ1";

            /// <summary>
            /// Property for Segment Number2 
            /// </summary>
            public const string SegmentNumber2 = "ABRKID2";

            /// <summary>
            /// Property for Segment2 Starting Position 
            /// </summary>
            public const string Segment2StartingPosition = "ABRKSTRT2";

            /// <summary>
            /// Property for Segment2 Length 
            /// </summary>
            public const string Segment2Length = "ABRKLEN2";
           
            /// <summary>
            /// RESERVEDAcctseg2validationseq
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctseg2validationseq = "ABRKVSEQ2";

            /// <summary>
            /// Property for Segment Number3 
            /// </summary>
            public const string SegmentNumber3 = "ABRKID3";

            /// <summary>
            /// Property for Segment3 Starting Position 
            /// </summary>
            public const string Segment3StartingPosition = "ABRKSTRT3";

            /// <summary>
            /// Property for Segment3 Length 
            /// </summary>
            public const string Segment3Length = "ABRKLEN3";

            /// <summary>
            /// RESERVEDAcctseg3validationseq
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctseg3validationseq = "ABRKVSEQ3";

            /// <summary>
            /// Property for Segment Number4 
            /// </summary>
            public const string SegmentNumber4 = "ABRKID4";

            /// <summary>
            /// Property for Segment4 Starting Position 
            /// </summary>
            public const string Segment4StartingPosition = "ABRKSTRT4";

            /// <summary>
            /// Property for Segment4 Length 
            /// </summary>
            public const string Segment4Length = "ABRKLEN4";
            
            /// <summary>
            /// RESERVEDAcctseg4validationseq
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctseg4validationseq = "ABRKVSEQ4";

            /// <summary>
            /// Property for Segment Number5 
            /// </summary>
            public const string SegmentNumber5 = "ABRKID5";

            /// <summary>
            /// Property for Segment5 Starting Position 
            /// </summary>
            public const string Segment5StartingPosition = "ABRKSTRT5";

            /// <summary>
            /// Property for Segment5 Length 
            /// </summary>
            public const string Segment5Length = "ABRKLEN5";
            
            /// <summary>
            /// RESERVEDAcctseg5validationseq
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctseg5validationseq = "ABRKVSEQ5";

            /// <summary>
            /// Property for Segment Number6 
            /// </summary>
            public const string SegmentNumber6 = "ABRKID6";

            /// <summary>
            /// Property for Segment6 Starting Position 
            /// </summary>
            public const string Segment6StartingPosition = "ABRKSTRT6";

            /// <summary>
            /// Property for Segment6 Length 
            /// </summary>
            public const string Segment6Length = "ABRKLEN6";
            
            /// <summary>
            /// RESERVEDAcctseg6validationseq
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctseg6validationseq = "ABRKVSEQ6";

            /// <summary>
            /// Property for Segment Number7 
            /// </summary>
            public const string SegmentNumber7 = "ABRKID7";

            /// <summary>
            /// Property for Segment7 Starting Position 
            /// </summary>
            public const string Segment7StartingPosition = "ABRKSTRT7";

            /// <summary>
            /// Property for Segment7 Length 
            /// </summary>
            public const string Segment7Length = "ABRKLEN7";
            
            /// <summary>
            /// RESERVEDAcctseg7validationseq
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctseg7validationseq = "ABRKVSEQ7";

            /// <summary>
            /// Property for Segment Number8 
            /// </summary>
            public const string SegmentNumber8 = "ABRKID8";

            /// <summary>
            /// Property for Segment8 Starting Position 
            /// </summary>
            public const string Segment8StartingPosition = "ABRKSTRT8";

            /// <summary>
            /// Property for Segment8 Length 
            /// </summary>
            public const string Segment8Length = "ABRKLEN8";
            
            /// <summary>
            /// RESERVEDAcctseg8validationseq
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctseg8validationseq = "ABRKVSEQ8";

            /// <summary>
            /// Property for Segment Number9 
            /// </summary>
            public const string SegmentNumber9 = "ABRKID9";

            /// <summary>
            /// Property for Segment9 Starting Position 
            /// </summary>
            public const string Segment9StartingPosition = "ABRKSTRT9";

            /// <summary>
            /// Property for Segment9 Length 
            /// </summary>
            public const string Segment9Length = "ABRKLEN9";
            
            /// <summary>
            /// RESERVEDAcctseg9validationseq
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctseg9validationseq = "ABRKVSEQ9";

            /// <summary>
            /// Property for Segment Number10 
            /// </summary>
            public const string SegmentNumber10 = "ABRKID10";

            /// <summary>
            /// Property for Segment10 Starting Position 
            /// </summary>
            public const string Segment10StartingPosition = "ABRKSTRT10";
            
            /// <summary>
            /// RESERVEDAcctseg10validationseq
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctseg10validationseq = "ABRKVSEQ10";

            /// <summary>
            /// Property for Segment10 Length 
            /// </summary>
            public const string Segment10Length = "ABRKLEN10";

            /// <summary>
            /// RESERVED Structure Code Title
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDStructureCodeTitle = "ABRKTITLE";

            /// <summary>
            /// RESERVED Structure Code Type
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDStructureCodeType = "ABRKTYPE";

            /// <summary>
            /// RESERVED Account Type
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAccountType = "ACCTTYPE";

            /// <summary>
            /// RESERVEDP AHU sage Count
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDPAHUsageCount = "PAHUSAGE";

            /// <summary>
            /// RESERVED ASTU sage Count
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDASTUsageCount = "ASTUSAGE";

            /// <summary>
            /// RESERVED ADHU Sage Count
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDADHUSageCount = "ADHUSAGE";

            /// <summary>
            /// RESERVED AITU sage Count
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAITUsageCount = "AITUSAGE";

            /// <summary>
            /// RESERVED ASDU sage Count
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDASDUsageCount = "ASDUSAGE";

            /// <summary>
            /// RESERVED Effective Start Date
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDEffectiveStartDate = "DATEEFF";

            /// <summary>
            /// RESERVED Acct Seg 1 Delimiter
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctSeg1Delimiter = "ABLKDELM1";
            
            /// <summary>
            /// RESERVED Acct Seg 2 Delimiter
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctSeg2Delimiter = "ABLKDELM2";
            
            /// <summary>
            /// RESERVED Acct Seg3 Delimiter
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctSeg3Delimiter = "ABLKDELM3";
            
            /// <summary>
            /// RESERVED Acct Seg4 Delimiter
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctSeg4Delimiter = "ABLKDELM4";

            /// <summary>
            /// RESERVED Acct Seg5 Delimiter
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctSeg5Delimiter = "ABLKDELM5";

            /// <summary>
            /// RESERVED Acct Seg6 Delimiter
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctSeg6Delimiter = "ABLKDELM6";

            /// <summary>
            /// RESERVED Acct Seg7 Delimiter
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctSeg7Delimiter = "ABLKDELM7";

            /// <summary>
            /// RESERVED Acct Seg8 Delimiter
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctSeg8Delimiter = "ABLKDELM8";

            /// <summary>
            /// RESERVED Acct Seg9 Delimiter
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctSeg9Delimiter = "ABLKDELM9";

            /// <summary>
            /// RESERVED Acct Seg10 Delimiter
            /// </summary>
            [IsMvcSpecific]
            public const string RESERVEDAcctSeg10Delimiter = "ABLKDELM10";

            #endregion
        }

        /// <summary>
        /// GeneralLedgerOptions Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for StructureCode 
            /// </summary>
            public const int StructureCode = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for SegmentNumber1 
            /// </summary>
            public const int SegmentNumber1 = 3;

            /// <summary>
            /// Property Indexer for Segment1StartingPosition 
            /// </summary>
            public const int Segment1StartingPosition = 4;

            /// <summary>
            /// Property Indexer for Segment1Length 
            /// </summary>
            public const int Segment1Length = 6;

            /// <summary>
            /// Property Indexer for SegmentNumber2 
            /// </summary>
            public const int SegmentNumber2 = 7;

            /// <summary>
            /// Property Indexer for Segment2StartingPosition 
            /// </summary>
            public const int Segment2StartingPosition = 8;

            /// <summary>
            /// Property Indexer for Segment2Length 
            /// </summary>
            public const int Segment2Length = 10;

            /// <summary>
            /// Property Indexer for SegmentNumber3 
            /// </summary>
            public const int SegmentNumber3 = 11;

            /// <summary>
            /// Property Indexer for Segment3StartingPosition 
            /// </summary>
            public const int Segment3StartingPosition = 12;

            /// <summary>
            /// Property Indexer for Segment3Length 
            /// </summary>
            public const int Segment3Length = 14;

            /// <summary>
            /// Property Indexer for SegmentNumber4 
            /// </summary>
            public const int SegmentNumber4 = 15;

            /// <summary>
            /// Property Indexer for Segment4StartingPosition 
            /// </summary>
            public const int Segment4StartingPosition = 16;

            /// <summary>
            /// Property Indexer for Segment4Length 
            /// </summary>
            public const int Segment4Length = 18;

            /// <summary>
            /// Property Indexer for SegmentNumber5 
            /// </summary>
            public const int SegmentNumber5 = 19;

            /// <summary>
            /// Property Indexer for Segment5StartingPosition 
            /// </summary>
            public const int Segment5StartingPosition = 20;

            /// <summary>
            /// Property Indexer for Segment5Length 
            /// </summary>
            public const int Segment5Length = 22;

            /// <summary>
            /// Property Indexer for SegmentNumber6 
            /// </summary>
            public const int SegmentNumber6 = 23;

            /// <summary>
            /// Property Indexer for Segment6StartingPosition 
            /// </summary>
            public const int Segment6StartingPosition = 24;

            /// <summary>
            /// Property Indexer for Segment6Length 
            /// </summary>
            public const int Segment6Length = 26;

            /// <summary>
            /// Property Indexer for SegmentNumber7 
            /// </summary>
            public const int SegmentNumber7 = 27;

            /// <summary>
            /// Property Indexer for Segment7StartingPosition 
            /// </summary>
            public const int Segment7StartingPosition = 28;

            /// <summary>
            /// Property Indexer for Segment7Length 
            /// </summary>
            public const int Segment7Length = 30;

            /// <summary>
            /// Property Indexer for SegmentNumber8 
            /// </summary>
            public const int SegmentNumber8 = 31;

            /// <summary>
            /// Property Indexer for Segment8StartingPosition 
            /// </summary>
            public const int Segment8StartingPosition = 32;

            /// <summary>
            /// Property Indexer for Segment8Length 
            /// </summary>
            public const int Segment8Length = 34;

            /// <summary>
            /// Property Indexer for SegmentNumber9 
            /// </summary>
            public const int SegmentNumber9 = 35;

            /// <summary>
            /// Property Indexer for Segment9StartingPosition 
            /// </summary>
            public const int Segment9StartingPosition = 36;

            /// <summary>
            /// Property Indexer for Segment9Length 
            /// </summary>
            public const int Segment9Length = 38;

            /// <summary>
            /// Property Indexer for SegmentNumber10 
            /// </summary>
            public const int SegmentNumber10 = 39;

            /// <summary>
            /// Property Indexer for Segment10StartingPosition 
            /// </summary>
            public const int Segment10StartingPosition = 40;

            /// <summary>
            /// Property Indexer for Segment10Length 
            /// </summary>
            public const int Segment10Length = 42;

            #endregion
        }
    }
}