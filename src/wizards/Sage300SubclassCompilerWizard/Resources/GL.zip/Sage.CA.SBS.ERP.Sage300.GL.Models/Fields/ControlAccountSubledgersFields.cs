/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ControlAccountSubledgers Constants 
    /// </summary>
    public partial class ControlAccountSubledgers
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0107";

        /// <summary>
        /// Contains list of ControlAccountSubledgers Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for Account 
            /// </summary>
            public const string Account = "ACCTID";
            /// <summary>
            /// Property for Subledger 
            /// </summary>
            public const string Subledger = "SRCELDGID";

            #endregion
        }

        /// <summary>
        /// Contains list of ControlAccountSubledgers Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for Account 
            /// </summary>
            public const int Account = 1;
            /// <summary>
            /// Property Indexer for Subledger 
            /// </summary>
            public const int Subledger = 2;

            #endregion
        }
    }
}
