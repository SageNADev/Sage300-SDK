// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of UserSegmentPermission Constants
    /// </summary>
    public partial class UserSegmentPermission
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0052";

        #region Properties

        /// <summary>
        /// Contains list of UserSegmentPermission Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for UserID
            /// </summary>
            public const string UserID = "USER";

            /// <summary>
            /// Property for LineNo
            /// </summary>
            public const string LineNo = "LINE";

            /// <summary>
            /// Property for Allow
            /// </summary>
            public const string Allow = "SWCANSEE";

            /// <summary>
            /// Property for Segment
            /// </summary>
            public const string Segment = "SEGID";

            /// <summary>
            /// Property for FromSegment
            /// </summary>
            public const string FromSegment = "BEGINID";

            /// <summary>
            /// Property for ToSegment
            /// </summary>
            public const string ToSegment = "ENDID";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of UserSegmentPermission Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for UserID
            /// </summary>
            public const int UserID = 1;

            /// <summary>
            /// Property Indexer for LineNo
            /// </summary>
            public const int LineNo = 2;

            /// <summary>
            /// Property Indexer for Allow
            /// </summary>
            public const int Allow = 3;

            /// <summary>
            /// Property Indexer for Segment
            /// </summary>
            public const int Segment = 4;

            /// <summary>
            /// Property Indexer for FromSegment
            /// </summary>
            public const int FromSegment = 5;

            /// <summary>
            /// Property Indexer for ToSegment
            /// </summary>
            public const int ToSegment = 6;

        }

        #endregion

    }
}
