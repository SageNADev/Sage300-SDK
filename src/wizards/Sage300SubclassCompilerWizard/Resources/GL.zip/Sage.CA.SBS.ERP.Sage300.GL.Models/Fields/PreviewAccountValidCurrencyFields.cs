// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of PreviewAccountValidCurrency Constants
    /// </summary>
    public partial class PreviewAccountValidCurrency
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0047";

        #region Properties

        /// <summary>
        /// Contains list of PreviewACValidCurrencie Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for AccountNumber
            /// </summary>
            public const string AccountNumber = "ACCTID";

            /// <summary>
            /// Property for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CURNID";

            /// <summary>
            /// Property for RevaluationSwitch
            /// </summary>
            public const string RevaluationSwitch = "REVALSW";

            /// <summary>
            /// Property for RevaluationCode
            /// </summary>
            public const string RevaluationCode = "REVALID";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PreviewACValidCurrencie Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for AccountNumber
            /// </summary>
            public const int AccountNumber = 1;

            /// <summary>
            /// Property Indexer for CurrencyCode
            /// </summary>
            public const int CurrencyCode = 2;

            /// <summary>
            /// Property Indexer for RevaluationSwitch
            /// </summary>
            public const int RevaluationSwitch = 3;

            /// <summary>
            /// Property Indexer for RevaluationCode
            /// </summary>
            public const int RevaluationCode = 4;

        }

        #endregion

    }
}
