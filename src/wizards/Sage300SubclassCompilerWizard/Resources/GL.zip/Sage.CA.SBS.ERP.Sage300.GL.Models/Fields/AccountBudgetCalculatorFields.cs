// Copyright (c) 2020 Sage  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of AccountBudgetCalculator Constants
    /// </summary>
    public partial class AccountBudgetCalculator
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "GL0009";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of AccountBudgetCalculator Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for BudgetMethodCode
            /// </summary>
            public const string BudgetMethodCode = "METHODCD";

            /// <summary>
            /// Property for InputAmount
            /// </summary>
            public const string InputAmount = "INAMT";

            /// <summary>
            /// Property for InputIncreaseAmount
            /// </summary>
            public const string InputIncreaseAmount = "INAMTINCR";

            /// <summary>
            /// Property for InputIncreasePercent
            /// </summary>
            public const string InputIncreasePercent = "INRATINCR";

            /// <summary>
            /// Property for PeriodStart
            /// </summary>
            public const string PeriodStart = "PERDSTRT";

            /// <summary>
            /// Property for PeriodEnd
            /// </summary>
            public const string PeriodEnd = "PERDEND";

            /// <summary>
            /// Property for TypeOfUpdate
            /// </summary>
            public const string TypeOfUpdate = "UPDTCODE";

            /// <summary>
            /// Property for Period01InquiryAmount
            /// </summary>
            public const string Period01InquiryAmount = "AMTINQ01";

            /// <summary>
            /// Property for Period02InquiryAmount
            /// </summary>
            public const string Period02InquiryAmount = "AMTINQ02";

            /// <summary>
            /// Property for Period03InquiryAmount
            /// </summary>
            public const string Period03InquiryAmount = "AMTINQ03";

            /// <summary>
            /// Property for Period04InquiryAmount
            /// </summary>
            public const string Period04InquiryAmount = "AMTINQ04";

            /// <summary>
            /// Property for Period05InquiryAmount
            /// </summary>
            public const string Period05InquiryAmount = "AMTINQ05";

            /// <summary>
            /// Property for Period06InquiryAmount
            /// </summary>
            public const string Period06InquiryAmount = "AMTINQ06";

            /// <summary>
            /// Property for Period07InquiryAmount
            /// </summary>
            public const string Period07InquiryAmount = "AMTINQ07";

            /// <summary>
            /// Property for Period08InquiryAmount
            /// </summary>
            public const string Period08InquiryAmount = "AMTINQ08";

            /// <summary>
            /// Property for Period09InquiryAmount
            /// </summary>
            public const string Period09InquiryAmount = "AMTINQ09";

            /// <summary>
            /// Property for Period10InquiryAmount
            /// </summary>
            public const string Period10InquiryAmount = "AMTINQ10";

            /// <summary>
            /// Property for Period11InquiryAmount
            /// </summary>
            public const string Period11InquiryAmount = "AMTINQ11";

            /// <summary>
            /// Property for Period12InquiryAmount
            /// </summary>
            public const string Period12InquiryAmount = "AMTINQ12";

            /// <summary>
            /// Property for Period13InquiryAmount
            /// </summary>
            public const string Period13InquiryAmount = "AMTINQ13";

            /// <summary>
            /// Property for Period14InquiryAmount
            /// </summary>
            public const string Period14InquiryAmount = "AMTINQ14";

            /// <summary>
            /// Property for Period01WorkAmount
            /// </summary>
            public const string Period01WorkAmount = "AMTWRK01";

            /// <summary>
            /// Property for Period02WorkAmount
            /// </summary>
            public const string Period02WorkAmount = "AMTWRK02";

            /// <summary>
            /// Property for Period03WorkAmount
            /// </summary>
            public const string Period03WorkAmount = "AMTWRK03";

            /// <summary>
            /// Property for Period04WorkAmount
            /// </summary>
            public const string Period04WorkAmount = "AMTWRK04";

            /// <summary>
            /// Property for Period05WorkAmount
            /// </summary>
            public const string Period05WorkAmount = "AMTWRK05";

            /// <summary>
            /// Property for Period06WorkAmount
            /// </summary>
            public const string Period06WorkAmount = "AMTWRK06";

            /// <summary>
            /// Property for Period07WorkAmount
            /// </summary>
            public const string Period07WorkAmount = "AMTWRK07";

            /// <summary>
            /// Property for Period08WorkAmount
            /// </summary>
            public const string Period08WorkAmount = "AMTWRK08";

            /// <summary>
            /// Property for Period09WorkAmount
            /// </summary>
            public const string Period09WorkAmount = "AMTWRK09";

            /// <summary>
            /// Property for Period10WorkAmount
            /// </summary>
            public const string Period10WorkAmount = "AMTWRK10";

            /// <summary>
            /// Property for Period11WorkAmount
            /// </summary>
            public const string Period11WorkAmount = "AMTWRK11";

            /// <summary>
            /// Property for Period12WorkAmount
            /// </summary>
            public const string Period12WorkAmount = "AMTWRK12";

            /// <summary>
            /// Property for Period13WorkAmount
            /// </summary>
            public const string Period13WorkAmount = "AMTWRK13";

            /// <summary>
            /// Property for Period14WorkAmount
            /// </summary>
            public const string Period14WorkAmount = "AMTWRK14";

            /// <summary>
            /// Property for TotalAmount
            /// </summary>
            public const string TotalAmount = "AMTTOTAL";

            /// <summary>
            /// Property for BudgetCurrency
            /// </summary>
            public const string BudgetCurrency = "CODECURN";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of AccountBudgetCalculator Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for BudgetMethodCode
            /// </summary>
            public const int BudgetMethodCode = 1;

            /// <summary>
            /// Property Indexer for InputAmount
            /// </summary>
            public const int InputAmount = 2;

            /// <summary>
            /// Property Indexer for InputIncreaseAmount
            /// </summary>
            public const int InputIncreaseAmount = 3;

            /// <summary>
            /// Property Indexer for InputIncreasePercent
            /// </summary>
            public const int InputIncreasePercent = 4;

            /// <summary>
            /// Property Indexer for PeriodStart
            /// </summary>
            public const int PeriodStart = 5;

            /// <summary>
            /// Property Indexer for PeriodEnd
            /// </summary>
            public const int PeriodEnd = 6;

            /// <summary>
            /// Property Indexer for TypeOfUpdate
            /// </summary>
            public const int TypeOfUpdate = 7;

            /// <summary>
            /// Property Indexer for Period01InquiryAmount
            /// </summary>
            public const int Period01InquiryAmount = 8;

            /// <summary>
            /// Property Indexer for Period02InquiryAmount
            /// </summary>
            public const int Period02InquiryAmount = 9;

            /// <summary>
            /// Property Indexer for Period03InquiryAmount
            /// </summary>
            public const int Period03InquiryAmount = 10;

            /// <summary>
            /// Property Indexer for Period04InquiryAmount
            /// </summary>
            public const int Period04InquiryAmount = 11;

            /// <summary>
            /// Property Indexer for Period05InquiryAmount
            /// </summary>
            public const int Period05InquiryAmount = 12;

            /// <summary>
            /// Property Indexer for Period06InquiryAmount
            /// </summary>
            public const int Period06InquiryAmount = 13;

            /// <summary>
            /// Property Indexer for Period07InquiryAmount
            /// </summary>
            public const int Period07InquiryAmount = 14;

            /// <summary>
            /// Property Indexer for Period08InquiryAmount
            /// </summary>
            public const int Period08InquiryAmount = 15;

            /// <summary>
            /// Property Indexer for Period09InquiryAmount
            /// </summary>
            public const int Period09InquiryAmount = 16;

            /// <summary>
            /// Property Indexer for Period10InquiryAmount
            /// </summary>
            public const int Period10InquiryAmount = 17;

            /// <summary>
            /// Property Indexer for Period11InquiryAmount
            /// </summary>
            public const int Period11InquiryAmount = 18;

            /// <summary>
            /// Property Indexer for Period12InquiryAmount
            /// </summary>
            public const int Period12InquiryAmount = 19;

            /// <summary>
            /// Property Indexer for Period13InquiryAmount
            /// </summary>
            public const int Period13InquiryAmount = 20;

            /// <summary>
            /// Property Indexer for Period14InquiryAmount
            /// </summary>
            public const int Period14InquiryAmount = 21;

            /// <summary>
            /// Property Indexer for Period01WorkAmount
            /// </summary>
            public const int Period01WorkAmount = 22;

            /// <summary>
            /// Property Indexer for Period02WorkAmount
            /// </summary>
            public const int Period02WorkAmount = 23;

            /// <summary>
            /// Property Indexer for Period03WorkAmount
            /// </summary>
            public const int Period03WorkAmount = 24;

            /// <summary>
            /// Property Indexer for Period04WorkAmount
            /// </summary>
            public const int Period04WorkAmount = 25;

            /// <summary>
            /// Property Indexer for Period05WorkAmount
            /// </summary>
            public const int Period05WorkAmount = 26;

            /// <summary>
            /// Property Indexer for Period06WorkAmount
            /// </summary>
            public const int Period06WorkAmount = 27;

            /// <summary>
            /// Property Indexer for Period07WorkAmount
            /// </summary>
            public const int Period07WorkAmount = 28;

            /// <summary>
            /// Property Indexer for Period08WorkAmount
            /// </summary>
            public const int Period08WorkAmount = 29;

            /// <summary>
            /// Property Indexer for Period09WorkAmount
            /// </summary>
            public const int Period09WorkAmount = 30;

            /// <summary>
            /// Property Indexer for Period10WorkAmount
            /// </summary>
            public const int Period10WorkAmount = 31;

            /// <summary>
            /// Property Indexer for Period11WorkAmount
            /// </summary>
            public const int Period11WorkAmount = 32;

            /// <summary>
            /// Property Indexer for Period12WorkAmount
            /// </summary>
            public const int Period12WorkAmount = 33;

            /// <summary>
            /// Property Indexer for Period13WorkAmount
            /// </summary>
            public const int Period13WorkAmount = 34;

            /// <summary>
            /// Property Indexer for Period14WorkAmount
            /// </summary>
            public const int Period14WorkAmount = 35;

            /// <summary>
            /// Property Indexer for TotalAmount
            /// </summary>
            public const int TotalAmount = 36;

            /// <summary>
            /// Property Indexer for BudgetCurrency
            /// </summary>
            public const int BudgetCurrency = 37;


        }

        #endregion

    }
}