﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
// ReSharper disable CheckNamespace


namespace Sage.CA.SBS.ERP.Sage300.GL.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Class RecurringJournalHeader.
    /// </summary>
    public partial class RecurringJournalHeader
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "GL0041";

        /// <summary>
        /// Contains list of RecurringJournalHeaders Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for RecurringEntryCode
            /// </summary>
            public const string RecurringEntryCode = "RECID";

            /// <summary>
            /// Property for RecurringEntryDescription
            /// </summary>
            public const string RecurringEntryDescription = "RECDESC";

            /// <summary>
            /// Property for StartDate
            /// </summary>
            public const string StartDate = "DATESTART";

            /// <summary>
            /// Property for ExpirationType
            /// </summary>
            public const string ExpirationType = "SWEXPIRE";

            /// <summary>
            /// Property for ExpirationType String
            /// Added for Finder filter
            /// </summary>
            [IsMvcSpecific]
            public const string ExpirationTypeString = "SWEXPIRE";

            /// <summary>
            /// Property for ExpirationDate
            /// </summary>
            public const string ExpirationDate = "DATEEXPIRY";

            /// <summary>
            /// Property for LastRunDate
            /// </summary>
            public const string LastRunDate = "DATERUN";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "SWACTIVE";

            /// <summary>
            /// Property for Status String
            /// Added for Finder filter
            /// </summary>
            [IsMvcSpecific]
            public const string StatusString = "SWACTIVE";

            /// <summary>
            /// Property for InactiveDate
            /// </summary>
            public const string InactiveDate = "DATEINACT";

            /// <summary>
            /// Property for LastMaintainedDate
            /// </summary>
            public const string LastMaintainedDate = "DATEMAINT";

            /// <summary>
            /// Property for SourceLedger
            /// </summary>
            public const string SourceLedger = "SRCELEDGER";

            /// <summary>
            /// Property for SourceType
            /// </summary>
            public const string SourceType = "SRCETYPE";

            /// <summary>
            /// Property for AutoReversal
            /// </summary>
            public const string AutoReversal = "SWREVERSE";

            /// <summary>
            /// Property for AutoReversal String
            /// Added for Finder filter
            /// </summary>
            [IsMvcSpecific]
            public const string AutoReversalString = "SWREVERSE";

            /// <summary>
            /// Property for JournalEntryDescription
            /// </summary>
            public const string JournalEntryDescription = "JRNLDESC";

            /// <summary>
            /// Property for ExchangeRateSwitch
            /// </summary>
            public const string ExchangeRateSwitch = "SWEXRATE";

            /// <summary>
            /// Property for ExchangeRateSwitch String
            /// Added for Finder filter
            /// </summary>
            [IsMvcSpecific]
            public const string ExchangeRateString = "SWEXRATE";

            /// <summary>
            /// Property for RoundingAccount
            /// </summary>
            public const string RoundingAccount = "RDACCT";

            /// <summary>
            /// Property for Debits
            /// </summary>
            public const string Debits = "RECDR";

            /// <summary>
            /// Property for Credits
            /// </summary>
            public const string Credits = "RECCR";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "RECQTY";

            /// <summary>
            /// Property for Schedule
            /// </summary>
            public const string Schedule = "SCHEDKEY";

            /// <summary>
            /// Property for ScheduleLink
            /// </summary>
            public const string ScheduleLink = "SCHEDLINK";

            /// <summary>
            /// Property for ZeroSourceAmountCounter
            /// </summary>
            public const string ZeroSourceAmountCounter = "ZEROSRCCNT";

            /// <summary>
            /// Property for OutofBalanceBy
            /// </summary>
            public const string OutofBalanceBy = "BALANCE";

            /// <summary>
            /// Property for RecurringEntryGLSecStatus
            /// </summary>
            public const string RecurringEntryGLSecStatus = "GSSTATUS";

            #endregion
        }

        /// <summary>
        /// List of Recurrinf Journal Header Indices
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for RecurringEntryCode
            /// </summary>
            public const int RecurringEntryCode = 1;

            /// <summary>
            /// Property Indexer for RecurringEntryDescription
            /// </summary>
            public const int RecurringEntryDescription = 2;

            /// <summary>
            /// Property Indexer for StartDate
            /// </summary>
            public const int StartDate = 3;

            /// <summary>
            /// Property Indexer for ExpirationType
            /// </summary>
            public const int ExpirationType = 4;

            /// <summary>
            /// Property Indexer for ExpirationDate
            /// </summary>
            public const int ExpirationDate = 5;

            /// <summary>
            /// Property Indexer for LastRunDate
            /// </summary>
            public const int LastRunDate = 6;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 7;

            /// <summary>
            /// Property Indexer for InactiveDate
            /// </summary>
            public const int InactiveDate = 8;

            /// <summary>
            /// Property Indexer for LastMaintainedDate
            /// </summary>
            public const int LastMaintainedDate = 9;

            /// <summary>
            /// Property Indexer for SourceLedger
            /// </summary>
            public const int SourceLedger = 10;

            /// <summary>
            /// Property Indexer for SourceType
            /// </summary>
            public const int SourceType = 11;

            /// <summary>
            /// Property Indexer for AutoReversal
            /// </summary>
            public const int AutoReversal = 12;

            /// <summary>
            /// Property Indexer for JournalEntryDescription
            /// </summary>
            public const int JournalEntryDescription = 13;

            /// <summary>
            /// Property Indexer for ExchangeRateSwitch
            /// </summary>
            public const int ExchangeRateSwitch = 14;

            /// <summary>
            /// Property Indexer for RoundingAccount
            /// </summary>
            public const int RoundingAccount = 15;

            /// <summary>
            /// Property Indexer for Debits
            /// </summary>
            public const int Debits = 16;

            /// <summary>
            /// Property Indexer for Credits
            /// </summary>
            public const int Credits = 17;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 18;

            /// <summary>
            /// Property Indexer for Schedule
            /// </summary>
            public const int Schedule = 20;

            /// <summary>
            /// Property Indexer for ScheduleLink
            /// </summary>
            public const int ScheduleLink = 21;

            /// <summary>
            /// Property Indexer for ZeroSourceAmountCounter
            /// </summary>
            public const int ZeroSourceAmountCounter = 22;

            /// <summary>
            /// Property Indexer for OutofBalanceBy
            /// </summary>
            public const int OutofBalanceBy = 30;

            /// <summary>
            /// Property Indexer for RecurringEntryGLSecStatus
            /// </summary>
            public const int RecurringEntryGLSecStatus = 31;

            #endregion
        }
    }
}