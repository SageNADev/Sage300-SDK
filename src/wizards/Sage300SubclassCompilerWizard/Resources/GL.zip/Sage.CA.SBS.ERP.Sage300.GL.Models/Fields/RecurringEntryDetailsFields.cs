/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of RecurringEntryDetails Constants
    /// </summary>
    public partial class RecurringEntryDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0042";

        /// <summary>
        /// Contains list of RecurringEntryDetails Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for RecurringEntryCode
            /// </summary>
            public const string RecurringEntryCode = "RECID";

            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "TRANSNBR";

            /// <summary>
            /// Property for AccountNumber
            /// </summary>
            public const string AccountNumber = "ACCTID";

            /// <summary>
            /// Property for CompanyId
            /// </summary>
            public const string CompanyId = "COMPANYID";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "TRANSAMT";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "TRANSQTY";

            /// <summary>
            /// Property for SourceCurrencyDecimals
            /// </summary>
            public const string SourceCurrencyDecimals = "SCURNDEC";

            /// <summary>
            /// Property for SourceCurrencyAmount
            /// </summary>
            public const string SourceCurrencyAmount = "SCURNAMT";

            /// <summary>
            /// Property for HomeCurrency
            /// </summary>
            public const string HomeCurrency = "HCURNCODE";

            /// <summary>
            /// Property for CurrencyRateTable
            /// </summary>
            public const string CurrencyRateTable = "RATETYPE";

            /// <summary>
            /// Property for SourceCurrency
            /// </summary>
            public const string SourceCurrency = "SCURNCODE";

            /// <summary>
            /// Property for CurrencyRateDate
            /// </summary>
            public const string CurrencyRateDate = "RATEDATE";

            /// <summary>
            /// Property for CurrencyRate
            /// </summary>
            public const string CurrencyRate = "CONVRATE";

            /// <summary>
            /// Property for CurrencyRateSpread
            /// </summary>
            public const string CurrencyRateSpread = "RATESPREAD";

            /// <summary>
            /// Property for CurrencyRateDateMatching
            /// </summary>
            public const string CurrencyRateDateMatching = "DATEMTCHCD";

            /// <summary>
            /// Property for CurrencyRateOperator
            /// </summary>
            public const string CurrencyRateOperator = "RATEOPER";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "TRANSDESC";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "TRANSREF";

            /// <summary>
            /// Property for RecurringEntryDate
            /// </summary>
            public const string RecurringEntryDate = "TRANSDATE";

            /// <summary>
            /// Property for SourceLedger
            /// </summary>
            public const string SourceLedger = "SRCELDGR";

            /// <summary>
            /// Property for SourceType
            /// </summary>
            public const string SourceType = "SRCETYPE";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for ZeroSourceAmountFlag
            /// </summary>
            public const string ZeroSourceAmountFlag = "ZEROSRCFG";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for Processswitches
            /// </summary>
            [IsMvcSpecific]
            public const string Processswitches = "PROCESSCMD";

            #endregion
        }

        /// <summary>
        /// Class Index.
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for RecurringEntryCode
            /// </summary>
            public const int RecurringEntryCode = 1;

            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 2;

            /// <summary>
            /// Property Indexer for AccountNumber
            /// </summary>
            public const int AccountNumber = 3;

            /// <summary>
            /// Property Indexer for CompanyId
            /// </summary>
            public const int CompanyId = 4;

            /// <summary>
            /// Property Indexer for Amount
            /// </summary>
            public const int Amount = 5;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 6;

            /// <summary>
            /// Property Indexer for SourceCurrencyDecimals
            /// </summary>
            public const int SourceCurrencyDecimals = 7;

            /// <summary>
            /// Property Indexer for SourceCurrencyAmount
            /// </summary>
            public const int SourceCurrencyAmount = 8;

            /// <summary>
            /// Property Indexer for HomeCurrency
            /// </summary>
            public const int HomeCurrency = 9;

            /// <summary>
            /// Property Indexer for CurrencyRateTable
            /// </summary>
            public const int CurrencyRateTable = 10;

            /// <summary>
            /// Property Indexer for SourceCurrency
            /// </summary>
            public const int SourceCurrency = 11;

            /// <summary>
            /// Property Indexer for CurrencyRateDate
            /// </summary>
            public const int CurrencyRateDate = 12;

            /// <summary>
            /// Property Indexer for CurrencyRate
            /// </summary>
            public const int CurrencyRate = 13;

            /// <summary>
            /// Property Indexer for CurrencyRateSpread
            /// </summary>
            public const int CurrencyRateSpread = 14;

            /// <summary>
            /// Property Indexer for CurrencyRateDateMatching
            /// </summary>
            public const int CurrencyRateDateMatching = 15;

            /// <summary>
            /// Property Indexer for CurrencyRateOperator
            /// </summary>
            public const int CurrencyRateOperator = 16;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 17;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 18;

            /// <summary>
            /// Property Indexer for RecurringEntryDate
            /// </summary>
            public const int RecurringEntryDate = 19;

            /// <summary>
            /// Property Indexer for SourceLedger
            /// </summary>
            public const int SourceLedger = 20;

            /// <summary>
            /// Property Indexer for SourceType
            /// </summary>
            public const int SourceType = 21;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 22;

            /// <summary>
            /// Property Indexer for ZeroSourceAmountFlag
            /// </summary>
            public const int ZeroSourceAmountFlag = 23;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 24;

            #endregion
        }
    }
}