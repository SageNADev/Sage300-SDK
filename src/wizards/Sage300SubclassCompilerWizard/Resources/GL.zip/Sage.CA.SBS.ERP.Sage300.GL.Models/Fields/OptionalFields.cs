﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of GLOptionalFields Constants
    /// </summary>
    public partial class OptionalFields
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0500";

        /// <summary>
        /// Contains list of OptionalFields Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for LocationString - For Finder
            /// </summary>
            public const string LocationString = "LOCATION";

            /// <summary>
            /// Property for OptionalField
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for DefaultValue
            /// </summary>
            public const string DefaultValue = "DEFVAL";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Type
            /// Added for finder
            /// </summary>
            public const string TypeString = "TYPE";

            /// <summary>
            /// Property for Length
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Decimals
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for AllowBlank
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";

            /// <summary>
            /// Property for AllowBlank - For Finder
            /// </summary>
            public const string AllowBlankString = "ALLOWNULL";

            /// <summary>
            /// Property for Validate
            /// </summary>
            public const string Validate = "VALIDATE";

            /// <summary>
            /// Property for ValidateString - For Finder
            /// </summary>
            public const string ValidateString = "VALIDATE";

            /// <summary>
            /// Property for AutoInsert
            /// </summary>
            public const string AutoInsert = "INITFLAG";

            /// <summary>
            /// Property for AutoInsertString - For Finder
            /// </summary>
            public const string AutoInsertString = "INITFLAG";

            /// <summary>
            /// Property for Required
            /// </summary>
            public const string Required = "SWREQUIRED";

            /// <summary>
            /// Property for Required String - For Finder
            /// </summary>
            public const string RequiredString = "SWREQUIRED";

            /// <summary>
            /// Property for ValueSet
            /// </summary>
            public const string ValueSet = "SWSET";

            /// <summary>
            /// Property for ValueSetString - For Finder
            /// </summary>
            public const string ValueSetString = "SWSET";

            /// <summary>
            /// Property for TypedDefaultValueFieldIndex
            /// </summary>
            public const string TypedDefaultValueFieldIndex = "DVINDEX";

            /// <summary>
            /// Property for DefaultTextValue
            /// </summary>
            public const string DefaultTextValue = "DVIFTEXT";

            /// <summary>
            /// Property for DefaultAmountValue
            /// </summary>
            public const string DefaultAmountValue = "DVIFMONEY";

            /// <summary>
            /// Property for DefaultNumberValue
            /// </summary>
            public const string DefaultNumberValue = "DVIFNUM";

            /// <summary>
            /// Property for DefaultIntegerValue
            /// </summary>
            public const string DefaultIntegerValue = "DVIFLONG";

            /// <summary>
            /// Property for DefaultYesOrNoValue
            /// </summary>
            public const string DefaultYesOrNoValue = "DVIFBOOL";

            /// <summary>
            /// Property for DefaultYesOrNoValueString - For Finder
            /// </summary>
            public const string DefaultYesOrNoValueString = "DVIFBOOL";

            /// <summary>
            /// Property for DefaultDateValue
            /// </summary>
            public const string DefaultDateValue = "DVIFDATE";

            /// <summary>
            /// Property for DefaultTimeValue
            /// </summary>
            public const string DefaultTimeValue = "DVIFTIME";

            /// <summary>
            /// Property for OptionalFieldDescription
            /// </summary>
            public const string OptionalFieldDescription = "FDESC";

            /// <summary>
            /// Property for DefaultValueDescription
            /// </summary>
            public const string DefaultValueDescription = "VDESC";

            #endregion
        }

        /// <summary>
        /// Class Index.
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 1;

            /// <summary>
            /// Property Indexer for OptionalField
            /// </summary>
            public const int OptionalField = 2;

            /// <summary>
            /// Property Indexer for DefaultValue
            /// </summary>
            public const int DefaultValue = 3;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 4;

            /// <summary>
            /// Property Indexer for Type String
            /// </summary>
            public const int TypeString = 4;

            /// <summary>
            /// Property Indexer for Length
            /// </summary>
            public const int Length = 5;

            /// <summary>
            /// Property Indexer for Decimals
            /// </summary>
            public const int Decimals = 6;

            /// <summary>
            /// Property Indexer for AllowBlank
            /// </summary>
            public const int AllowBlank = 7;

            /// <summary>
            /// Property Indexer for Validate
            /// </summary>
            public const int Validate = 8;

            /// <summary>
            /// Property Indexer for AutoInsert
            /// </summary>
            public const int AutoInsert = 9;

            /// <summary>
            /// Property Indexer for Required
            /// </summary>
            public const int Required = 10;

            /// <summary>
            /// Property Indexer for ValueSet
            /// </summary>
            public const int ValueSet = 11;

            /// <summary>
            /// Property Indexer for TypedDefaultValueFieldIndex
            /// </summary>
            public const int TypedDefaultValueFieldIndex = 20;

            /// <summary>
            /// Property Indexer for DefaultTextValue
            /// </summary>
            public const int DefaultTextValue = 21;

            /// <summary>
            /// Property Indexer for DefaultAmountValue
            /// </summary>
            public const int DefaultAmountValue = 22;

            /// <summary>
            /// Property Indexer for DefaultNumberValue
            /// </summary>
            public const int DefaultNumberValue = 23;

            /// <summary>
            /// Property Indexer for DefaultIntegerValue
            /// </summary>
            public const int DefaultIntegerValue = 24;

            /// <summary>
            /// Property Indexer for DefaultYesOrNoValue
            /// </summary>
            public const int DefaultYesOrNoValue = 25;

            /// <summary>
            /// Property Indexer for DefaultDateValue
            /// </summary>
            public const int DefaultDateValue = 26;

            /// <summary>
            /// Property Indexer for DefaultTimeValue
            /// </summary>
            public const int DefaultTimeValue = 27;

            /// <summary>
            /// Property Indexer for OptionalFieldDescription
            /// </summary>
            public const int OptionalFieldDescription = 28;

            /// <summary>
            /// Property Indexer for DefaultValueDescription
            /// </summary>
            public const int DefaultValueDescription = 29;

            #endregion
        }
    }
}