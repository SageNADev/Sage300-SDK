// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of Account Permissions Constants
    /// </summary>
    public partial class AccountPermissions
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0054";

        #region Properties

        /// <summary>
        /// Contains list of User Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for UserID
            /// </summary>
            public const string UserID = "USER";

            /// <summary>
            /// Property for HasRestrictionRecordsSwitch
            /// </summary>
            public const string HasRestrictionRecordsSwitch = "HASDTLREC";

            /// <summary>
            /// Property for UserName
            /// </summary>
            public const string UserName = "NAME";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of User Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for UserID
            /// </summary>
            public const int UserID = 1;

            /// <summary>
            /// Property Indexer for HasRestrictionRecordsSwitch
            /// </summary>
            public const int HasRestrictionRecordsSwitch = 2;

            /// <summary>
            /// Property Indexer for UserName
            /// </summary>
            public const int UserName = 10;

        }

        #endregion

    }
}
