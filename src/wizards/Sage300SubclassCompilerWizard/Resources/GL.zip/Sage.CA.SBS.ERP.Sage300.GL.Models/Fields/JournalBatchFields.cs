﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */


namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of Batches Constants 
    /// </summary>
    public partial class JournalBatch
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0008";

        /// <summary>
        /// Contains list of Batches Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "BATCHID";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "BTCHENTRY";
            /// <summary>
            /// Property for ActiveSwitch 
            /// </summary>
            public const string ActiveSwitch = "ACTIVESW";
            /// <summary>
            /// Property for ActiveSwitch String
            /// Added for Finder filter
            /// </summary>
            public const string ActiveSwitchString = "ACTIVESW";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "BTCHDESC";
            /// <summary>
            /// Property for SourceLedger 
            /// </summary>
            public const string SourceLedger = "SRCELEDGR";
            /// <summary>
            /// Property for DateCreated 
            /// </summary>
            public const string DateCreated = "DATECREAT";
            /// <summary>
            /// Property for DateLastEdited 
            /// </summary>
            public const string DateLastEdited = "DATEEDIT";
            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string Type = "BATCHTYPE";

            /// <summary>
            /// Property for Type 
            /// Added for finder
            /// </summary>
            public const string TypeString = "BATCHTYPE";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "BATCHSTAT";

            /// <summary>
            /// Property for Status 
            /// Added for finder
            /// </summary>
            public const string StatusString = "BATCHSTAT";
            /// <summary>
            /// Property for PostingSequence 
            /// </summary>
            public const string PostingSequence = "POSTNGSEQ";
            /// <summary>
            /// Property for Debits 
            /// </summary>
            public const string Debits = "DEBITTOT";
            /// <summary>
            /// Property for Credits 
            /// </summary>
            public const string Credits = "CREDITTOT";
            /// <summary>
            /// Property for QuantityTotal 
            /// </summary>
            public const string QuantityTotal = "QTYTOTAL";
            /// <summary>
            /// Property for NumberofEntries 
            /// </summary>
            public const string NumberofEntries = "ENTRYCNT";
            /// <summary>
            /// Property for NextEntryNumber 
            /// </summary>
            public const string NextEntryNumber = "NEXTENTRY";
            /// <summary>
            /// Property for NoofErrors 
            /// </summary>
            public const string NoofErrors = "ERRORCNT";
            /// <summary>
            /// Property for OriginalStatus 
            /// </summary>
            public const string OriginalStatus = "ORIGSTATUS";
            /// <summary>
            /// Property for Printed 
            /// </summary>
            public const string Printed = "SWPRINTED";
            /// <summary>
            /// Property for Printed String
            /// Added for Finder filter
            /// </summary>
            public const string PrintedString = "SWPRINTED";
            /// <summary>
            /// Property for ICTRelated 
            /// </summary>
            public const string ICTRelated = "SWICT";
            /// <summary>
            /// Property for ICTRelated String
            /// Added for Finder filter
            /// </summary>
            public const string ICTRelatedString = "SWICT";
            /// <summary>
            /// Property for RevaluationRecognizedBatch 
            /// </summary>
            public const string RevaluationRecognizedBatch = "SWRVRECOG";
            /// <summary>
            /// Property for RevaluationRecognizedBatch String 
            /// Added for Finder filter
            /// </summary>
            public const string RevaluationRecognizedBatchString = "SWRVRECOG";
            /// <summary>
            /// Property for EligibleforEditSwitch 
            /// </summary>
            public const string EligibleforEditSwitch = "ELIGOPEN";
            /// <summary>
            /// Property for EligibleforEditSwitch String
            /// Added for Finder filter
            /// </summary>
            public const string EligibleforEditSwitchString = "ELIGOPEN";
            /// <summary>
            /// Property for EligibleforDeleteSwitch 
            /// </summary>
            public const string EligibleforDeleteSwitch = "ELIGDEL";
            /// <summary>
            /// Property for EligibleforDeleteSwitch String
            /// Added for Finder filter
            /// </summary>
            public const string EligibleforDeleteSwitchString = "ELIGDEL";
            /// <summary>
            /// Property for EligibleforPostingSwitch 
            /// </summary>
            public const string EligibleforPostingSwitch = "ELIGPOST";
            /// <summary>
            /// Property for EligibleforPostingSwitch String
            /// Added for Finder filter
            /// </summary>
            public const string EligibleforPostingSwitchString = "ELIGPOST";
            /// <summary>
            /// Property for EligibleforPrintingSwitch 
            /// </summary>
            public const string EligibleforPrintingSwitch = "ELIGPRINT";
            /// <summary>
            /// Property for EligibleforPrintingSwitch String
            /// Added for Finder filter
            /// </summary>
            public const string EligibleforPrintingSwitchString = "ELIGPRINT";
            /// <summary>
            /// Property for EligibleforProvPostSwitch 
            /// </summary>
            public const string EligibleforProvPostSwitch = "ELIGPVPST";
            /// <summary>
            /// Property for EligibleforProvPostSwitch String
            /// Added for Finder filter
            /// </summary>
            public const string EligibleforProvPostSwitchString = "ELIGPVPST";
            /// <summary>
            /// Property for ReadytoPost 
            /// </summary>
            public const string ReadytoPost = "RDYTOPOST";
            /// <summary>
            /// Property for ReadytoPost String
            /// Added for Finder filter
            /// </summary>
            public const string ReadytoPostString = "RDYTOPOST";
            /// <summary>
            /// Property for LockBatchSwitch 
            /// </summary>
            public const string LockBatchSwitch = "PROCESSCMD";

            #endregion
        }


        /// <summary>
        /// Contains list of Batches Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 1;
            /// <summary>
            /// Property Indexer for ActiveSwitch 
            /// </summary>
            public const int ActiveSwitch = 2;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;
            /// <summary>
            /// Property Indexer for SourceLedger 
            /// </summary>
            public const int SourceLedger = 4;
            /// <summary>
            /// Property Indexer for DateCreated 
            /// </summary>
            public const int DateCreated = 5;
            /// <summary>
            /// Property Indexer for DateLastEdited 
            /// </summary>
            public const int DateLastEdited = 6;
            /// <summary>
            /// Property Indexer for Type 
            /// </summary>
            public const int Type = 7;
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 8;
            /// <summary>
            /// Property Indexer for PostingSequence 
            /// </summary>
            public const int PostingSequence = 9;
            /// <summary>
            /// Property Indexer for Debits 
            /// </summary>
            public const int Debits = 10;
            /// <summary>
            /// Property Indexer for Credits 
            /// </summary>
            public const int Credits = 11;
            /// <summary>
            /// Property Indexer for QuantityTotal 
            /// </summary>
            public const int QuantityTotal = 12;
            /// <summary>
            /// Property Indexer for NumberofEntries 
            /// </summary>
            public const int NumberofEntries = 13;
            /// <summary>
            /// Property Indexer for NextEntryNumber 
            /// </summary>
            public const int NextEntryNumber = 14;
            /// <summary>
            /// Property Indexer for NoofErrors 
            /// </summary>
            public const int NoofErrors = 15;
            /// <summary>
            /// Property Indexer for OriginalStatus 
            /// </summary>
            public const int OriginalStatus = 16;
            /// <summary>
            /// Property Indexer for Printed 
            /// </summary>
            public const int Printed = 17;
            /// <summary>
            /// Property Indexer for ICTRelated 
            /// </summary>
            public const int ICTRelated = 18;
            /// <summary>
            /// Property Indexer for RevaluationRecognizedBatch 
            /// </summary>
            public const int RevaluationRecognizedBatch = 19;
            /// <summary>
            /// Property Indexer for EligibleforEditSwitch 
            /// </summary>
            public const int EligibleforEditSwitch = 25;
            /// <summary>
            /// Property Indexer for EligibleforDeleteSwitch 
            /// </summary>
            public const int EligibleforDeleteSwitch = 26;
            /// <summary>
            /// Property Indexer for EligibleforPostingSwitch 
            /// </summary>
            public const int EligibleforPostingSwitch = 27;
            /// <summary>
            /// Property Indexer for EligibleforPrintingSwitch 
            /// </summary>
            public const int EligibleforPrintingSwitch = 28;
            /// <summary>
            /// Property Indexer for EligibleforProvPostSwitch 
            /// </summary>
            public const int EligibleforProvPostSwitch = 29;
            /// <summary>
            /// Property Indexer for ReadytoPost 
            /// </summary>
            public const int ReadytoPost = 30;
            /// <summary>
            /// Property Indexer for Reserved 
            /// </summary>
            public const int Reserved = 31;
            /// <summary>
            /// Property Indexer for LockBatchSwitch 
            /// </summary>
            public const int LockBatchSwitch = 32;

            #endregion
        }


    }
}
