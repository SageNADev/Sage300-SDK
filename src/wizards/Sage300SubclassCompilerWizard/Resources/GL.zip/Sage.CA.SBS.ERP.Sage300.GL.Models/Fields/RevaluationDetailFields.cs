// Copyright © 2016 Sage Software, Inc.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of RevaluationDetail Constants
    /// </summary>
    public partial class RevaluationDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "GL0104";


        #region Properties

        /// <summary>
        /// Contains list of RevaluationDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for CurrencycodeTorevalue
            /// </summary>
            public const string CurrencycodeTorevalue = "CURNCYCODE";

            /// <summary>
            /// Property for Defaultrevaluationcode
            /// </summary>
            public const string Defaultrevaluationcode = "DFLTRVLCD";

            /// <summary>
            /// Property for BatchDescription
            /// </summary>
            public const string BatchDescription = "BATCHDESC";

            /// <summary>
            /// Property for Forcerevaluationswitch
            /// </summary>
            public const string Forcerevaluationswitch = "FORCEREVAL";

            /// <summary>
            /// Property for Selectsegmenttype
            /// </summary>
            public const string Selectsegmenttype = "SGMTSLCT";

            /// <summary>
            /// Property for SelectsegmentID
            /// </summary>
            public const string SelectsegmentID = "SGMTID";

            /// <summary>
            /// Property for FromAccountNumber
            /// </summary>
            public const string FromAccountNumber = "FROMACCTID";

            /// <summary>
            /// Property for ToAccountNumber
            /// </summary>
            public const string ToAccountNumber = "TOACCTID";

            /// <summary>
            /// Property for Fromfiscalperiod
            /// </summary>
            public const string Fromfiscalperiod = "FROMPERIOD";

            /// <summary>
            /// Property for Tofiscalperiod
            /// </summary>
            public const string Tofiscalperiod = "TOPERIOD";

            /// <summary>
            /// Property for Fiscalyear
            /// </summary>
            public const string Fiscalyear = "FSCSYR";

            /// <summary>
            /// Property for Journaldate
            /// </summary>
            public const string Journaldate = "JRNLDATE";

            /// <summary>
            /// Property for DateusedForconversion
            /// </summary>
            public const string DateusedForconversion = "CONVDATE";

            /// <summary>
            /// Property for Conversionrate
            /// </summary>
            public const string Conversionrate = "CONVRATE";

            /// <summary>
            /// Property for UnrealizedExchangeGainAccount
            /// </summary>
            public const string UnrealizedExchangeGainAccount = "ACCTGAIN";

            /// <summary>
            /// Property for UnrealizedExchangeLossAccount
            /// </summary>
            public const string UnrealizedExchangeLossAccount = "ACCTLOSS";

            /// <summary>
            /// Property for UnrealizedExchangeGainOptionalFlds
            /// </summary>
            public const string UnrealizedExchangeGainOptionalFlds = "GVALUES";

            /// <summary>
            /// Property for UnrealizedExchangeLossOptionalFlds
            /// </summary>
            public const string UnrealizedExchangeLossOptionalFlds = "LVALUES";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of RevaluationDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for CurrencycodeTorevalue
            /// </summary>
            public const int CurrencycodeTorevalue = 1;

            /// <summary>
            /// Property Indexer for Defaultrevaluationcode
            /// </summary>
            public const int Defaultrevaluationcode = 2;

            /// <summary>
            /// Property Indexer for BatchDescription
            /// </summary>
            public const int BatchDescription = 3;

            /// <summary>
            /// Property Indexer for Forcerevaluationswitch
            /// </summary>
            public const int Forcerevaluationswitch = 4;

            /// <summary>
            /// Property Indexer for Selectsegmenttype
            /// </summary>
            public const int Selectsegmenttype = 5;

            /// <summary>
            /// Property Indexer for SelectsegmentID
            /// </summary>
            public const int SelectsegmentID = 6;

            /// <summary>
            /// Property Indexer for FromAccountNumber
            /// </summary>
            public const int FromAccountNumber = 7;

            /// <summary>
            /// Property Indexer for ToAccountNumber
            /// </summary>
            public const int ToAccountNumber = 8;

            /// <summary>
            /// Property Indexer for Fromfiscalperiod
            /// </summary>
            public const int Fromfiscalperiod = 9;

            /// <summary>
            /// Property Indexer for Tofiscalperiod
            /// </summary>
            public const int Tofiscalperiod = 10;

            /// <summary>
            /// Property Indexer for Fiscalyear
            /// </summary>
            public const int Fiscalyear = 11;

            /// <summary>
            /// Property Indexer for Journaldate
            /// </summary>
            public const int Journaldate = 12;

            /// <summary>
            /// Property Indexer for DateusedForconversion
            /// </summary>
            public const int DateusedForconversion = 13;

            /// <summary>
            /// Property Indexer for Conversionrate
            /// </summary>
            public const int Conversionrate = 14;

            /// <summary>
            /// Property Indexer for UnrealizedExchangeGainAccount
            /// </summary>
            public const int UnrealizedExchangeGainAccount = 15;

            /// <summary>
            /// Property Indexer for UnrealizedExchangeLossAccount
            /// </summary>
            public const int UnrealizedExchangeLossAccount = 16;

            /// <summary>
            /// Property Indexer for UnrealizedExchangeGainOptionalFlds
            /// </summary>
            public const int UnrealizedExchangeGainOptionalFlds = 17;

            /// <summary>
            /// Property Indexer for UnrealizedExchangeLossOptionalFlds
            /// </summary>
            public const int UnrealizedExchangeLossOptionalFlds = 18;


        }

        #endregion

    }
}