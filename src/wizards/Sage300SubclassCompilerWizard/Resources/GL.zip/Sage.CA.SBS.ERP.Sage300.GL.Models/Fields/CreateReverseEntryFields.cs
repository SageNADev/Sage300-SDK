/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of CreateReverseEntry Constants 
    /// </summary>
	public partial class CreateReverseEntry 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0051";

        /// <summary>
        /// Contains list of CreateReverseEntry Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for OptionSwitch 
        /// </summary>
	    public const string OptionSwitch  = "SWOPTION";
	            /// <summary>
        /// Property for SelectedBatchId 
        /// </summary>
	    public const string SelectedBatchId  = "FRBTCHID";
	            /// <summary>
        /// Property for SelectedEntry 
        /// </summary>
	    public const string SelectedEntry  = "FRENTRY";
	            /// <summary>
        /// Property for NewReverseBatchSourceLedger 
        /// </summary>
	    public const string NewReverseBatchSourceLedger  = "SRCELEDGR";
	            /// <summary>
        /// Property for NewReverseBatchType 
        /// </summary>
	    public const string NewReverseBatchType  = "BATCHTYPE";
	            /// <summary>
        /// Property for ReverseBatchId 
        /// </summary>
	    public const string ReverseBatchId  = "BATCHID";
	            /// <summary>
        /// Property for ReverseBatchDescription 
        /// </summary>
	    public const string ReverseBatchDescription  = "BTCHDESC";
	            /// <summary>
        /// Property for ReverseEntryDescription 
        /// </summary>
	    public const string ReverseEntryDescription  = "JRNLDESC";
	            /// <summary>
        /// Property for CreatedReverseEntryNo 
        /// </summary>
	    public const string CreatedReverseEntryNo  = "CRENTRY";
	            /// <summary>
        /// Property for EntryYear 
        /// </summary>
	    public const string EntryYear  = "FSCSYR";
	            /// <summary>
        /// Property for EntryPeriod 
        /// </summary>
	    public const string EntryPeriod  = "FSCSPERD";
	            /// <summary>
        /// Property for AutoReversal 
        /// </summary>
	    public const string AutoReversal  = "SWREVERSE";
	            /// <summary>
        /// Property for SpecificReversalYear 
        /// </summary>
	    public const string SpecificReversalYear  = "REVYR";
	            /// <summary>
        /// Property for SpecificReversalPeriod 
        /// </summary>
	    public const string SpecificReversalPeriod  = "REVPERD";
	            /// <summary>
        /// Property for JournalDescriptionOption 
        /// </summary>
	    public const string JournalDescriptionOption  = "JRNLDESCOP";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of CreateReverseEntry Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for OptionSwitch 
        /// </summary>
	    public const int OptionSwitch  = 1;
	             /// <summary>
        /// Property Indexer for SelectedBatchId 
        /// </summary>
	    public const int SelectedBatchId  = 2;
	             /// <summary>
        /// Property Indexer for SelectedEntry 
        /// </summary>
	    public const int SelectedEntry  = 3;
	             /// <summary>
        /// Property Indexer for NewReverseBatchSourceLedger 
        /// </summary>
	    public const int NewReverseBatchSourceLedger  = 4;
	             /// <summary>
        /// Property Indexer for NewReverseBatchType 
        /// </summary>
	    public const int NewReverseBatchType  = 5;
	             /// <summary>
        /// Property Indexer for ReverseBatchId 
        /// </summary>
	    public const int ReverseBatchId  = 6;
	             /// <summary>
        /// Property Indexer for ReverseBatchDescription 
        /// </summary>
	    public const int ReverseBatchDescription  = 7;
	             /// <summary>
        /// Property Indexer for ReverseEntryDescription 
        /// </summary>
	    public const int ReverseEntryDescription  = 8;
	             /// <summary>
        /// Property Indexer for CreatedReverseEntryNo 
        /// </summary>
	    public const int CreatedReverseEntryNo  = 9;
	             /// <summary>
        /// Property Indexer for EntryYear 
        /// </summary>
	    public const int EntryYear  = 10;
	             /// <summary>
        /// Property Indexer for EntryPeriod 
        /// </summary>
	    public const int EntryPeriod  = 11;
	             /// <summary>
        /// Property Indexer for AutoReversal 
        /// </summary>
	    public const int AutoReversal  = 12;
	             /// <summary>
        /// Property Indexer for SpecificReversalYear 
        /// </summary>
	    public const int SpecificReversalYear  = 13;
	             /// <summary>
        /// Property Indexer for SpecificReversalPeriod 
        /// </summary>
	    public const int SpecificReversalPeriod  = 14;
	             /// <summary>
        /// Property Indexer for JournalDescriptionOption 
        /// </summary>
	    public const int JournalDescriptionOption  = 15;
	     
        #endregion
	    }

	
	}
}
	