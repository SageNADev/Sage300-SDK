// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
	/// <summary>
	/// Contains list of PostedTransaction  Constants
	/// </summary>
	public partial class PostedTransaction
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "GL0018";

		#region Properties

		/// <summary>
		/// Contains list of PostedTransaction Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for AccountNumber
			/// </summary>
			public const string AccountNumber = "ACCTID";

			/// <summary>
			/// Property for FiscalYear
			/// </summary>
			public const string FiscalYear = "FISCALYR";

			/// <summary>
			/// Property for FiscalPeriod
			/// </summary>
			public const string FiscalPeriod = "FISCALPERD";

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property for SRCECURN
			/// </summary>
			public const string SRCECURN = "SRCECURN";

			/// <summary>
			/// Property for SourceLedgerCode
			/// </summary>
			public const string SourceLedgerCode = "SRCELEDGER";

			/// <summary>
			/// Property for SourceTypeCode
			/// </summary>
			public const string SourceTypeCode = "SRCETYPE";

			/// <summary>
			/// Property for PostingSequenceNumber
			/// </summary>
			public const string PostingSequenceNumber = "POSTINGSEQ";

			/// <summary>
			/// Property for DetailCount
			/// </summary>
			public const string DetailCount = "CNTDETAIL";

			/// <summary>
			/// Property for JournalDate
			/// </summary>
			public const string JournalDate = "JRNLDATE";

			/// <summary>
			/// Property for BatchNumber
			/// </summary>
			public const string BatchNumber = "BATCHNBR";

			/// <summary>
			/// Property for JournalEntryNumber
			/// </summary>
			public const string JournalEntryNumber = "ENTRYNBR";

			/// <summary>
			/// Property for JournalTransactionNumber
			/// </summary>
			public const string JournalTransactionNumber = "TRANSNBR";

			/// <summary>
			/// Property for ConsolidationOccurredonPost
			/// </summary>
			public const string ConsolidationOccurredonPost = "CONSOLIDAT";

			/// <summary>
			/// Property for CompanyID
			/// </summary>
			public const string CompanyID = "COMPANYID";

			/// <summary>
			/// Property for JournalDetailDescription
			/// </summary>
			public const string JournalDetailDescription = "JNLDTLDESC";

			/// <summary>
			/// Property for JournalDetailReference
			/// </summary>
			public const string JournalDetailReference = "JNLDTLREF";

			/// <summary>
			/// Property for JournalTransactionAmount
			/// </summary>
			public const string JournalTransactionAmount = "TRANSAMT";

			/// <summary>
			/// Property for JournalTransactionQuantity
			/// </summary>
			public const string JournalTransactionQuantity = "TRANSQTY";

			/// <summary>
			/// Property for NbrOfSourceCurrencyDecimals
			/// </summary>
			public const string NbrOfSourceCurrencyDecimals = "SCURNDEC";

			/// <summary>
			/// Property for SourceCurrencyAmount
			/// </summary>
			public const string SourceCurrencyAmount = "SCURNAMT";

			/// <summary>
			/// Property for HomeCurrencyCode
			/// </summary>
			public const string HomeCurrencyCode = "HCURNCODE";

			/// <summary>
			/// Property for CurrencyRateTableType
			/// </summary>
			public const string CurrencyRateTableType = "RATETYPE";

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property for SCURNCODE
			/// </summary>
			public const string SCURNCODE = "SCURNCODE";

			/// <summary>
			/// Property for DateOfCurrencyRateSelected
			/// </summary>
			public const string DateOfCurrencyRateSelected = "RATEDATE";

			/// <summary>
			/// Property for CurrencyRateForConversion
			/// </summary>
			public const string CurrencyRateForConversion = "CONVRATE";

			/// <summary>
			/// Property for CurrencyRateSpreadAllowed
			/// </summary>
			public const string CurrencyRateSpreadAllowed = "RATESPREAD";

			/// <summary>
			/// Property for CodeForRateDateMatching
			/// </summary>
			public const string CodeForRateDateMatching = "DATEMTCHCD";

			/// <summary>
			/// Property for CurrencyRateOperator
			/// </summary>
			public const string CurrencyRateOperator = "RATEOPER";

			/// <summary>
			/// Property for DrillDownType
			/// </summary>
			public const string DrillDownType = "DRILSRCTY";

			/// <summary>
			/// Property for DrillDownLinkNumber
			/// </summary>
			public const string DrillDownLinkNumber = "DRILLDWNLK";

			/// <summary>
			/// Property for DrillDownApplicationSource
			/// </summary>
			public const string DrillDownApplicationSource = "DRILAPP";

			/// <summary>
			/// Property for ReportCurrencyAmount
			/// </summary>
			public const string ReportCurrencyAmount = "RPTAMT";

			/// <summary>
			/// Property for OptionalFields
			/// </summary>
			public const string OptionalFields = "VALUES";

			/// <summary>
			/// Property for DocumentDate
			/// </summary>
			public const string DocumentDate = "DOCDATE";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of PostedTransaction Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for AccountNumber
			/// </summary>
			public const int AccountNumber = 1;

			/// <summary>
			/// Property Indexer for FiscalYear
			/// </summary>
			public const int FiscalYear = 2;

			/// <summary>
			/// Property Indexer for FiscalPeriod
			/// </summary>
			public const int FiscalPeriod = 3;

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property Indexer for SRCECURN
			/// </summary>
			public const int SRCECURN = 4;

			/// <summary>
			/// Property Indexer for SourceLedgerCode
			/// </summary>
			public const int SourceLedgerCode = 5;

			/// <summary>
			/// Property Indexer for SourceTypeCode
			/// </summary>
			public const int SourceTypeCode = 6;

			/// <summary>
			/// Property Indexer for PostingSequenceNumber
			/// </summary>
			public const int PostingSequenceNumber = 7;

			/// <summary>
			/// Property Indexer for DetailCount
			/// </summary>
			public const int DetailCount = 8;

			/// <summary>
			/// Property Indexer for JournalDate
			/// </summary>
			public const int JournalDate = 9;

			/// <summary>
			/// Property Indexer for BatchNumber
			/// </summary>
			public const int BatchNumber = 10;

			/// <summary>
			/// Property Indexer for JournalEntryNumber
			/// </summary>
			public const int JournalEntryNumber = 11;

			/// <summary>
			/// Property Indexer for JournalTransactionNumber
			/// </summary>
			public const int JournalTransactionNumber = 12;

			/// <summary>
			/// Property Indexer for ConsolidationOccurredonPost
			/// </summary>
			public const int ConsolidationOccurredonPost = 14;

			/// <summary>
			/// Property Indexer for CompanyID
			/// </summary>
			public const int CompanyID = 15;

			/// <summary>
			/// Property Indexer for JournalDetailDescription
			/// </summary>
			public const int JournalDetailDescription = 16;

			/// <summary>
			/// Property Indexer for JournalDetailReference
			/// </summary>
			public const int JournalDetailReference = 17;

			/// <summary>
			/// Property Indexer for JournalTransactionAmount
			/// </summary>
			public const int JournalTransactionAmount = 18;

			/// <summary>
			/// Property Indexer for JournalTransactionQuantity
			/// </summary>
			public const int JournalTransactionQuantity = 19;

			/// <summary>
			/// Property Indexer for NbrOfSourceCurrencyDecimals
			/// </summary>
			public const int NbrOfSourceCurrencyDecimals = 20;

			/// <summary>
			/// Property Indexer for SourceCurrencyAmount
			/// </summary>
			public const int SourceCurrencyAmount = 21;

			/// <summary>
			/// Property Indexer for HomeCurrencyCode
			/// </summary>
			public const int HomeCurrencyCode = 22;

			/// <summary>
			/// Property Indexer for CurrencyRateTableType
			/// </summary>
			public const int CurrencyRateTableType = 23;

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property Indexer for SCURNCODE
			/// </summary>
			public const int SCURNCODE = 24;

			/// <summary>
			/// Property Indexer for DateOfCurrencyRateSelected
			/// </summary>
			public const int DateOfCurrencyRateSelected = 25;

			/// <summary>
			/// Property Indexer for CurrencyRateForConversion
			/// </summary>
			public const int CurrencyRateForConversion = 26;

			/// <summary>
			/// Property Indexer for CurrencyRateSpreadAllowed
			/// </summary>
			public const int CurrencyRateSpreadAllowed = 27;

			/// <summary>
			/// Property Indexer for CodeForRateDateMatching
			/// </summary>
			public const int CodeForRateDateMatching = 28;

			/// <summary>
			/// Property Indexer for CurrencyRateOperator
			/// </summary>
			public const int CurrencyRateOperator = 29;

			/// <summary>
			/// Property Indexer for DrillDownType
			/// </summary>
			public const int DrillDownType = 30;

			/// <summary>
			/// Property Indexer for DrillDownLinkNumber
			/// </summary>
			public const int DrillDownLinkNumber = 31;

			/// <summary>
			/// Property Indexer for DrillDownApplicationSource
			/// </summary>
			public const int DrillDownApplicationSource = 32;

			/// <summary>
			/// Property Indexer for ReportCurrencyAmount
			/// </summary>
			public const int ReportCurrencyAmount = 33;

			/// <summary>
			/// Property Indexer for OptionalFields
			/// </summary>
			public const int OptionalFields = 34;

			/// <summary>
			/// Property Indexer for DocumentDate
			/// </summary>
			public const int DocumentDate = 35;

		}

		#endregion

	}
}
