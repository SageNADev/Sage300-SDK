﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of GeneralLedger Options Constants
    /// </summary>
    public partial class Options
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "GL0005";

        /// <summary>
        /// GeneralLedger Options Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for GLOptionKey 
            /// </summary>
            public const string GLOptionKey = "OPTIONID";

            /// <summary>
            /// Property for Company Phone Number 
            /// </summary>
            public const string CompanyPhoneNumber = "PHONENBR";

            /// <summary>
            /// Property for Company Fax Number
            /// </summary>
            public const string CompanyFaxNumber = "FAX";

            /// <summary>
            /// Property for OrganizationId 
            /// </summary>
            public const string OrganizationId = "COMPANYID";

            /// <summary>
            /// Property for Client Contact Name 
            /// </summary>
            public const string ClientContactName = "CONTACT";

            /// <summary>
            /// Property for Main Account SegmentId 
            /// </summary>
            public const string MainAcctSegmentId = "ACCTSEG";

            /// <summary>
            /// Property for Default Structure Code 
            /// </summary>
            public const string DefaultStructureCode = "ABRKDFLT";

            /// <summary>
            /// Property for Structure Code Delimiter
            /// </summary>
            public const string StructureCodeDelimiter = "ABRKDELM";

            /// <summary>
            /// Property for Batch Edit Allowed 
            /// </summary>
            public const string BatchEditAllowed = "SWBTCHEDIT";

            /// <summary>
            /// Property for Provisional Posting Allowed 
            /// </summary>
            public const string ProvisionalPostingAllowed = "SWPROVPST";

            /// <summary>
            /// Property for Print Batches Prior To Post 
            /// </summary>
            public const string PrintBatchesPriorToPost = "SWPRTPBTCH";

            /// <summary>
            /// Property for Budget1 Lock 
            /// </summary>
            public const string Budget1Lock = "CODELOCK1";

            /// <summary>
            /// Property for Budget2 Lock 
            /// </summary>
            public const string Budget2Lock = "CODELOCK2";

            /// <summary>
            /// Property for Budget3 Lock 
            /// </summary>
            public const string Budget3Lock = "CODELOCK3";

            /// <summary>
            /// Property for Budget4 Lock 
            /// </summary>
            public const string Budget4Lock = "CODELOCK4";

            /// <summary>
            /// Property for Budget5 Lock 
            /// </summary>
            public const string Budget5Lock = "CODELOCK5";

            /// <summary>
            /// Property for Quantity History Allowed 
            /// </summary>
            public const string QuantityHistoryAllowed = "SWQTY";

            /// <summary>
            /// Property for Number Of Decimals For Qty 
            /// </summary>
            public const string NumberOfDecimalsForQty = "QTYDEC";

            /// <summary>
            /// Property for Years Of Summary History Kept 
            /// </summary>
            public const string YearsOfSummaryHistoryKept = "YRSHIST";

            /// <summary>
            /// Property for Last Issued Batch Number 
            /// </summary>
            public const string LastIssuedBatchNumber = "NEXTBTCHNO";

            /// <summary>
            /// Property for Next Actual Post Seq
            /// </summary>
            public const string NextActualPostSeq = "PSTSQ";

            /// <summary>
            /// Property for Next Provisional Post Seq
            /// </summary>
            public const string NextProvisionalPostSeq = "PROVPSTSQ";

            /// <summary>
            /// Property for Last Closed Year
            /// </summary>
            public const string LastClosedYear = "YRCLSLST";

            /// <summary>
            /// Property for Oldest Year Of Fiscal Sets
            /// </summary>
            public const string OldestYearOfFiscalSets = "YRLSTACTL";

            /// <summary>
            /// Property for Oldest Year Of TransDetail 
            /// </summary>
            public const string OldestYearOfTransDetail = "YRNOPSTPR";

            /// <summary>
            /// Property for Default Retained Earning Account
            /// </summary>
            public const string DefaultRetainedEarningAcct = "REACCT";

            /// <summary>
            /// Property for Multi Currency Activated Switch
            /// </summary>
            public const string MultiCurrencyActivatedSwitch = "SWMC";

            /// <summary>
            /// Property for Default Currency Rate Type
            /// </summary>
            public const string DefaultCurrencyRateType = "DFLRATETYP";

            /// <summary>
            /// Property for Account Group Switch
            /// </summary>
            public const string AccountGroupSwitch = "SWACCTGRP";

            /// <summary>
            /// Property for Allow Previous Year Posting
            /// </summary>
            public const string AllowPreviousYearPosting = "SWPRVYRPST";

            /// <summary>
            /// Property for Years Of Detail History Kept
            /// </summary>
            public const string YearsOfDetailHistoryKept = "YRSTRANDTL";

            /// <summary>
            /// Property for Transition Rounding Account
            /// </summary>
            public const string TransitionRoundingAccount = "RPACCT";

            /// <summary>
            /// Property for Source Type 
            /// </summary>
            public const string SourceType = "SRCETYPE";

            /// <summary>
            /// Property for UseGLSecurity
            /// </summary>
            public const string UseGLSecurity = "SWUSESEC";

            /// <summary>
            /// Property for Default Access 
            /// </summary>
            public const string DefaultAccess = "SWDEFACCSS";

            /// <summary>
            /// Property for Current Year 
            /// </summary>
            public const string CurrentYear = "CURRENTYR";

            /// <summary>
            /// Property for Transition Company Stage
            /// </summary>
            public const string TransitionCompanyStage = "SWSTAGE";

            /// <summary>
            /// Property for Maximum Segments Per Account
            /// </summary>
            public const string MaximumSegmentsPerAcct = "SEGSALD";

            /// <summary>
            /// Property for Maximum Account Structures
            /// </summary>
            public const string MaximumAccountStructures = "STRUCTALD";

            /// <summary>
            /// Property for Locked Fiscal Periods Allowed
            /// </summary>
            public const string LockedFiscalPeriodsAllowed = "LCKDFSCPER";

            /// <summary>
            /// Property for IctInstalled
            /// </summary>
            public const string IctInstalled = "SWICT";

            /// <summary>
            /// Property for GSAccount Access Switch 
            /// </summary>
            public const string GSAccountAccessSwitch = "SWGS";

            /// <summary>
            /// Property for Revaluation Method
            /// </summary>
            public const string RevaluationMethod = "GNLSSMTHD";

            #endregion
        }

        /// <summary>
        /// GeneralLedgerOptions Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for GLOption Key
            /// </summary>
            public const int GLOptionKeyIndex = 1;

            /// <summary>
            /// Property Indexer for Company Phone Number 
            /// </summary>
            public const int CompanyPhoneNumberIndex = 2;

            /// <summary>
            /// Property Indexer for Company Fax Number 
            /// </summary>
            public const int CompanyFaxNumberIndex = 3;

            /// <summary>
            /// Property Indexer for OrganizationId 
            /// </summary>
            public const int OrganizationIdIndex = 4;

            /// <summary>
            /// Property Indexer for Client Contact Name 
            /// </summary>
            public const int ClientContactNameIndex = 5;

            /// <summary>
            /// Property Indexer for Main Account SegmentId 
            /// </summary>
            public const int MainAcctSegmentIdIndex = 7;

            /// <summary>
            /// Property Indexer for Default Structure Code 
            /// </summary>
            public const int DefaultStructureCodeIndex = 8;

            /// <summary>
            /// Property Indexer for Structure Code Delimiter 
            /// </summary>
            public const int StructureCodedelimiterIndex = 9;

            /// <summary>
            /// Property Indexer for Batch Edit Allowed 
            /// </summary>
            public const int BatchEditAllowedIndex = 10;

            /// <summary>
            /// Property Indexer for Provisional Posting Allowed 
            /// </summary>
            public const int ProvisionalPostingAllowedIndex = 11;

            /// <summary>
            /// Property Indexer for Print Batches Prior To Post 
            /// </summary>
            public const int PrintBatchesPriorToPostIndex = 12;

            /// <summary>
            /// Property Indexer for Budget1 Lock 
            /// </summary>
            public const int Budget1LockIndex = 13;

            /// <summary>
            /// Property Indexer for Budget2 Lock 
            /// </summary>
            public const int Budget2LockIndex = 14;

            /// <summary>
            /// Property Indexer for Budget3 Lock 
            /// </summary>
            public const int Budget3LockIndex = 15;

            /// <summary>
            /// Property Indexer for Budget4 Lock 
            /// </summary>
            public const int Budget4LockIndex = 16;

            /// <summary>
            /// Property Indexer for Budget5 Lock
            /// </summary>
            public const int Budget5LockIndex = 17;

            /// <summary>
            /// Property Indexer for Quantity History Allowed 
            /// </summary>
            public const int QuantityHistoryAllowedIndex = 19;

            /// <summary>
            /// Property Indexer for Number Of Decimals For Qty 
            /// </summary>
            public const int NumberOfDecimalsForQtyIndex = 20;

            /// <summary>
            /// Property Indexer for Years Of Summary History Kept 
            /// </summary>
            public const int YearsOfSummaryHistoryKeptIndex = 21;

            /// <summary>
            /// Property Indexer for Last Issued Batch Number 
            /// </summary>
            public const int LastIssuedBatchNumberIndex = 23;

            /// <summary>
            /// Property Indexer for Next Actual Post Seq
            /// </summary>
            public const int NextActualPostSeqIndex = 24;

            /// <summary>
            /// Property Indexer for Next Provisional Post Seq
            /// </summary>
            public const int NextProvisionalPostSeqIndex = 25;

            /// <summary>
            /// Property Indexer for Last Closed Year
            /// </summary>
            public const int LastClosedYearIndex = 29;

            /// <summary>
            /// Property Indexer for Oldest Year Of Fiscal Sets
            /// </summary>
            public const int OldestYearOfFiscalSetsIndex = 30;

            /// <summary>
            /// Property Indexer for Oldest Year Of Trans Detail
            /// </summary>
            public const int OldestYearOfTransDetailIndex = 32;

            /// <summary>
            /// Property Indexer for Default Retained Earning Acct
            /// </summary>
            public const int DefaultRetainedEarningAcctIndex = 33;

            /// <summary>
            /// Property Indexer for MultiCurrency Activated Switch
            /// </summary>
            public const int MultiCurrencyActivatedSwitchIndex = 34;

            /// <summary>
            /// Property Indexer for Default Currency Rate Type
            /// </summary>
            public const int DefaultCurrencyRateTypeIndex = 35;

            /// <summary>
            /// Property Indexer for Account Group Switch 
            /// </summary>
            public const int AccountGroupSwitchIndex = 36;

            /// <summary>
            /// Property Indexer for Allow Previous Year Posting
            /// </summary>
            public const int AllowPreviousYearPostingIndex = 37;

            /// <summary>
            /// Property Indexer for Years Of Detail History Kept
            /// </summary>
            public const int YearsOfDetailHistoryKeptIndex = 38;

            /// <summary>
            /// Property Indexer for TransitionRounding Account
            /// </summary>
            public const int TransitionRoundingAccountIndex = 40;

            /// <summary>
            /// Property Indexer for Source Type 
            /// </summary>
            public const int SourceTypeIndex = 41;

            /// <summary>
            /// Property Indexer for UseGLSecurity
            /// </summary>
            public const int UseGLSecurityIndex = 42;

            /// <summary>
            /// Property Indexer for Default Access 
            /// </summary>
            public const int DefaultAccessIndex = 43;

            /// <summary>
            /// Property Indexer for Current Year 
            /// </summary>
            public const int CurrentYearIndex = 80;

            /// <summary>
            /// Property Indexer for Transition Company Stage
            /// </summary>
            public const int TransitionCompanyStageIndex = 81;

            /// <summary>
            /// Property Indexer for Maximum Segments Per Acct
            /// </summary>
            public const int MaximumSegmentsPerAcctIndex = 82;

            /// <summary>
            /// Property Indexer for Maximum Account Structures
            /// </summary>
            public const int MaximumAccountStructuresIndex = 83;

            /// <summary>
            /// Property Indexer for Locked Fiscal Periods Allowed
            /// </summary>
            public const int LockedFiscalPeriodsAllowedIndex = 84;

            /// <summary>
            /// Property Indexer for IctInstalled
            /// </summary>
            public const int IctInstalledIndex = 85;

            /// <summary>
            /// Property Indexer for GSAccount Access Switch
            /// </summary>
            public const int GSAccountAccessSwitchIndex = 86;

            /// <summary>
            /// Property Indexer for Revaluation Method
            /// </summary>
            public const int RevaluationMethodIndex = 87;

            #endregion
        }
    }
}
