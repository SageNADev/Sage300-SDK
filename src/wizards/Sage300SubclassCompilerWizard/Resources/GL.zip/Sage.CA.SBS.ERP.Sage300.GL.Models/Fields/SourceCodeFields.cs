﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of SourceCode Constants 
    /// </summary>
    public partial class SourceCode
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0002";

        /// <summary>
        /// Contains list of SourceCode Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for SourceLedger 
            /// </summary>
            public const string SourceLedger = "SRCELEDGER";

            /// <summary>
            /// Property for SourceType 
            /// </summary>
            public const string SourceType = "SRCETYPE";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "SRCEDESC";

            #endregion
        }

        /// <summary>
        /// Source Codes Index constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Source Ledger 
            /// </summary>
            public const int SourceLedger = 1;

            /// <summary>
            /// Source Type 
            /// </summary>
            public const int SourceType = 2;

            /// <summary>
            /// Description 
            /// </summary>
            public const int Description = 3;

        }
    }
}