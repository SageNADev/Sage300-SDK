﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of AccountGroups Constants
    /// </summary>
    public partial class AccountGroup
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0055";

        /// <summary>
        /// Contains list of AccountGroups Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for AccountGroupCode
            /// </summary>
            public const string AccountGroupCode = "ACCTGRPCOD";

            /// <summary>
            /// Property for AccountGroupDescription
            /// </summary>
            public const string AccountGroupDescription = "ACCTGRPDES";

            /// <summary>
            /// Property for AccountGroupSortCode
            /// </summary>
            public const string AccountGroupSortCode = "SORTCODE";

            /// <summary>
            /// Property for GroupCategory
            /// </summary>
            public const string GroupCategory = "GRPCOD";

            /// <summary>
            /// Property for GroupCategoryString
            /// Added for filters
            /// </summary>
            [IsMvcSpecific]
            public const string GroupCategoryString = "GRPCOD";

            #endregion
        }

        /// <summary>
        /// Contains list of AccountGroups Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for AccountGroupCode
            /// </summary>
            public const int AccountGroupCode = 1;

            /// <summary>
            /// Property Indexer for AccountGroupDescription
            /// </summary>
            public const int AccountGroupDescription = 2;

            /// <summary>
            /// Property Indexer for AccountGroupSortCode
            /// </summary>
            public const int AccountGroupSortCode = 3;

            /// <summary>
            /// Property Indexer for GroupCategory
            /// </summary>
            public const int GroupCategory = 4;

            #endregion
        }

        /// <summary>
        /// Class Keys.
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Property Indexer for AccountGroupCode
            /// </summary>
            public const int AccountGroupCode = 0;

            /// <summary>
            /// Property Indexer for NewSortCode
            /// </summary>
            public const int AccountGroupSortCode = 1;
        }
    }
}