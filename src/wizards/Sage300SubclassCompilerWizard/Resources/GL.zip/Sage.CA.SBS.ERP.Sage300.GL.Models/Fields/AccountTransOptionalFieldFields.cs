// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of AccountTransOptionalField Constants
    /// </summary>
    public partial class AccountTransOptionalField
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0408";

        #region Properties

        /// <summary>
        /// Contains list of AccountTransOptionalField Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for UnformattedAccount
            /// </summary>
            public const string UnformattedAccount = "ACCTID";

            /// <summary>
            /// Property for OptionalField
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for DefaultValue
            /// </summary>
            public const string DefaultValue = "DEFVAL";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Length
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Decimals
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for AllowBlank
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";

            /// <summary>
            /// Property for Validate
            /// </summary>
            public const string Validate = "VALIDATE";

            /// <summary>
            /// Property for AutoInsert
            /// </summary>
            public const string AutoInsert = "INITFLAG";

            /// <summary>
            /// Property for Required
            /// </summary>
            public const string Required = "SWREQUIRED";

            /// <summary>
            /// Property for ValueSet
            /// </summary>
            public const string ValueSet = "SWSET";

            /// <summary>
            /// Property for TypedDefaultValueFieldIndex
            /// </summary>
            public const string TypedDefaultValueFieldIndex = "DVINDEX";

            /// <summary>
            /// Property for DefaultTextValue
            /// </summary>
            public const string DefaultTextValue = "DVIFTEXT";

            /// <summary>
            /// Property for DefaultAmountValue
            /// </summary>
            public const string DefaultAmountValue = "DVIFMONEY";

            /// <summary>
            /// Property for DefaultNumberValue
            /// </summary>
            public const string DefaultNumberValue = "DVIFNUM";

            /// <summary>
            /// Property for DefaultIntegerValue
            /// </summary>
            public const string DefaultIntegerValue = "DVIFLONG";

            /// <summary>
            /// Property for DefaultYesNoValue
            /// </summary>
            public const string DefaultYesNoValue = "DVIFBOOL";

            /// <summary>
            /// Property for DefaultDateValue
            /// </summary>
            public const string DefaultDateValue = "DVIFDATE";

            /// <summary>
            /// Property for DefaultTimeValue
            /// </summary>
            public const string DefaultTimeValue = "DVIFTIME";

            /// <summary>
            /// Property for OptionalFieldDescription
            /// </summary>
            public const string OptionalFieldDescription = "FDESC";

            /// <summary>
            /// Property for ValueDescription
            /// </summary>
            public const string ValueDescription = "VDESC";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of AccountTransOptionalField Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for UnformattedAccount
            /// </summary>
            public const int UnformattedAccount = 1;

            /// <summary>
            /// Property Indexer for OptionalField
            /// </summary>
            public const int OptionalField = 2;

            /// <summary>
            /// Property Indexer for DefaultValue
            /// </summary>
            public const int DefaultValue = 3;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 4;

            /// <summary>
            /// Property Indexer for Length
            /// </summary>
            public const int Length = 5;

            /// <summary>
            /// Property Indexer for Decimals
            /// </summary>
            public const int Decimals = 6;

            /// <summary>
            /// Property Indexer for AllowBlank
            /// </summary>
            public const int AllowBlank = 7;

            /// <summary>
            /// Property Indexer for Validate
            /// </summary>
            public const int Validate = 8;

            /// <summary>
            /// Property Indexer for AutoInsert
            /// </summary>
            public const int AutoInsert = 9;

            /// <summary>
            /// Property Indexer for Required
            /// </summary>
            public const int Required = 10;

            /// <summary>
            /// Property Indexer for ValueSet
            /// </summary>
            public const int ValueSet = 11;

            /// <summary>
            /// Property Indexer for TypedDefaultValueFieldIndex
            /// </summary>
            public const int TypedDefaultValueFieldIndex = 20;

            /// <summary>
            /// Property Indexer for DefaultTextValue
            /// </summary>
            public const int DefaultTextValue = 21;

            /// <summary>
            /// Property Indexer for DefaultAmountValue
            /// </summary>
            public const int DefaultAmountValue = 22;

            /// <summary>
            /// Property Indexer for DefaultNumberValue
            /// </summary>
            public const int DefaultNumberValue = 23;

            /// <summary>
            /// Property Indexer for DefaultIntegerValue
            /// </summary>
            public const int DefaultIntegerValue = 24;

            /// <summary>
            /// Property Indexer for DefaultYesNoValue
            /// </summary>
            public const int DefaultYesNoValue = 25;

            /// <summary>
            /// Property Indexer for DefaultDateValue
            /// </summary>
            public const int DefaultDateValue = 26;

            /// <summary>
            /// Property Indexer for DefaultTimeValue
            /// </summary>
            public const int DefaultTimeValue = 27;

            /// <summary>
            /// Property Indexer for OptionalFieldDescription
            /// </summary>
            public const int OptionalFieldDescription = 28;

            /// <summary>
            /// Property Indexer for ValueDescription
            /// </summary>
            public const int ValueDescription = 29;

        }

        #endregion

    }
}
