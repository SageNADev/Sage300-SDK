/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of AccountFiscalSets Constants.
    /// </summary>
    public partial class AccountFiscalSets
    {
        /// <summary>
        /// View Name.
        /// </summary>
        public const string ViewName = "GL0103";

        /// <summary>
        /// Contains list of AccountFiscalSets Fields Constants.
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for AccountNumber 
            /// </summary>
            public const string AccountNumber = "ACCTID";
            /// <summary>
            /// Property for FiscalSetYear 
            /// </summary>
            public const string FiscalSetYear = "FSCSYR";
            /// <summary>
            /// Property for FiscalSetDesignator 
            /// </summary>
            public const string FiscalSetDesignator = "FSCSDSG";
            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "FSCSCURN";
            /// <summary>
            /// Property for CurrencyType 
            /// </summary>
            public const string CurrencyType = "CURNTYPE";
            /// <summary>
            /// Property for SourceCurrencyDecimals 
            /// </summary>
            public const string SourceCurrencyDecimals = "SCURNDEC";
            /// <summary>
            /// Property for BeginningBalance 
            /// </summary>
            public const string BeginningBalance = "OPENBAL";
            /// <summary>
            /// Property for Period01NetAmount 
            /// </summary>
            public const string Period01NetAmount = "NETPERD1";
            /// <summary>
            /// Property for Period02NetAmount 
            /// </summary>
            public const string Period02NetAmount = "NETPERD2";
            /// <summary>
            /// Property for Period03NetAmount 
            /// </summary>
            public const string Period03NetAmount = "NETPERD3";
            /// <summary>
            /// Property for Period04NetAmount 
            /// </summary>
            public const string Period04NetAmount = "NETPERD4";
            /// <summary>
            /// Property for Period05NetAmount 
            /// </summary>
            public const string Period05NetAmount = "NETPERD5";
            /// <summary>
            /// Property for Period06NetAmount 
            /// </summary>
            public const string Period06NetAmount = "NETPERD6";
            /// <summary>
            /// Property for Period07NetAmount 
            /// </summary>
            public const string Period07NetAmount = "NETPERD7";
            /// <summary>
            /// Property for Period08NetAmount 
            /// </summary>
            public const string Period08NetAmount = "NETPERD8";
            /// <summary>
            /// Property for Period09NetAmount 
            /// </summary>
            public const string Period09NetAmount = "NETPERD9";
            /// <summary>
            /// Property for Period10NetAmount 
            /// </summary>
            public const string Period10NetAmount = "NETPERD10";
            /// <summary>
            /// Property for Period11NetAmount 
            /// </summary>
            public const string Period11NetAmount = "NETPERD11";
            /// <summary>
            /// Property for Period12NetAmount 
            /// </summary>
            public const string Period12NetAmount = "NETPERD12";
            /// <summary>
            /// Property for Period13NetAmount 
            /// </summary>
            public const string Period13NetAmount = "NETPERD13";
            /// <summary>
            /// Property for Period14NetAmount 
            /// </summary>
            public const string Period14NetAmount = "NETPERD14";
            /// <summary>
            /// Property for Period15NetAmount 
            /// </summary>
            public const string Period15NetAmount = "NETPERD15";
            /// <summary>
            /// Property for ActivitySwitch 
            /// </summary>
            public const string ActivitySwitch = "ACTIVITYSW";

            #endregion
        }

        /// <summary>
        /// Contains list of AccountFiscalSets Index Constants.
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for AccountNumber 
            /// </summary>
            public const int AccountNumber = 1;
            /// <summary>
            /// Property Indexer for FiscalSetYear 
            /// </summary>
            public const int FiscalSetYear = 2;
            /// <summary>
            /// Property Indexer for FiscalSetDesignator 
            /// </summary>
            public const int FiscalSetDesignator = 3;
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 4;
            /// <summary>
            /// Property Indexer for CurrencyType 
            /// </summary>
            public const int CurrencyType = 5;
            /// <summary>
            /// Property Indexer for SourceCurrencyDecimals 
            /// </summary>
            public const int SourceCurrencyDecimals = 8;
            /// <summary>
            /// Property Indexer for BeginningBalance 
            /// </summary>
            public const int BeginningBalance = 9;
            /// <summary>
            /// Property Indexer for Period01NetAmount 
            /// </summary>
            public const int Period01NetAmount = 10;
            /// <summary>
            /// Property Indexer for Period02NetAmount 
            /// </summary>
            public const int Period02NetAmount = 11;
            /// <summary>
            /// Property Indexer for Period03NetAmount 
            /// </summary>
            public const int Period03NetAmount = 12;
            /// <summary>
            /// Property Indexer for Period04NetAmount 
            /// </summary>
            public const int Period04NetAmount = 13;
            /// <summary>
            /// Property Indexer for Period05NetAmount 
            /// </summary>
            public const int Period05NetAmount = 14;
            /// <summary>
            /// Property Indexer for Period06NetAmount 
            /// </summary>
            public const int Period06NetAmount = 15;
            /// <summary>
            /// Property Indexer for Period07NetAmount 
            /// </summary>
            public const int Period07NetAmount = 16;
            /// <summary>
            /// Property Indexer for Period08NetAmount 
            /// </summary>
            public const int Period08NetAmount = 17;
            /// <summary>
            /// Property Indexer for Period09NetAmount 
            /// </summary>
            public const int Period09NetAmount = 18;
            /// <summary>
            /// Property Indexer for Period10NetAmount 
            /// </summary>
            public const int Period10NetAmount = 19;
            /// <summary>
            /// Property Indexer for Period11NetAmount 
            /// </summary>
            public const int Period11NetAmount = 20;
            /// <summary>
            /// Property Indexer for Period12NetAmount 
            /// </summary>
            public const int Period12NetAmount = 21;
            /// <summary>
            /// Property Indexer for Period13NetAmount 
            /// </summary>
            public const int Period13NetAmount = 22;
            /// <summary>
            /// Property Indexer for Period14NetAmount 
            /// </summary>
            public const int Period14NetAmount = 23;
            /// <summary>
            /// Property Indexer for Period15NetAmount 
            /// </summary>
            public const int Period15NetAmount = 24;
            /// <summary>
            /// Property Indexer for ActivitySwitch 
            /// </summary>
            public const int ActivitySwitch = 25;

            #endregion
        }
    }
}
