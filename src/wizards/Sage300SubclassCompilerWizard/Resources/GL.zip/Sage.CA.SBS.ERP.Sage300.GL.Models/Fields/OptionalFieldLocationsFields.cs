﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of GLOptionalFieldLocations Constants
    /// </summary>
    public partial class OptionalFieldLocations
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0501";

        /// <summary>
        /// Contains list of OptionalFieldLocations Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for NumberofValues
            /// </summary>
            public const string NumberofValues = "VALUES";

            #endregion
        }

        /// <summary>
        /// Class Index.
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 1;

            /// <summary>
            /// Property Indexer for NumberofValues
            /// </summary>
            public const int NumberofValues = 2;

            #endregion
        }
    }
}