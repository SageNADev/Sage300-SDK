// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of PreviewAccount Constants
    /// </summary>
    public partial class PreviewAccount
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0046";

        #region Properties

        /// <summary>
        /// Contains list of PreviewAccount Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for UnformattedAccount
            /// </summary>
            public const string UnformattedAccount = "ACCTID";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "ACCTDESC";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "ACCTTYPE";

            /// <summary>
            /// Property for NormalBalanceDebitOrCredit
            /// </summary>
            public const string NormalBalanceDebitOrCredit = "ACCTBAL";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "ACTIVESW";

            /// <summary>
            /// Property for ConsolidateJournals
            /// </summary>
            public const string ConsolidateJournals = "CONSLDSW";

            /// <summary>
            /// Property for QuantitiesAllowed
            /// </summary>
            public const string QuantitiesAllowed = "QTYSW";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UOM";

            /// <summary>
            /// Property for AllocationsAllowed
            /// </summary>
            public const string AllocationsAllowed = "ALLOCSW";

            /// <summary>
            /// Property for AllocOffsetAccount
            /// </summary>
            public const string AllocOffsetAccount = "ACCTOFSET";

            /// <summary>
            /// Property for AllocSourceType
            /// </summary>
            public const string AllocSourceType = "ACCTSRTY";

            /// <summary>
            /// Property for Multicurrency
            /// </summary>
            public const string Multicurrency = "MCSW";

            /// <summary>
            /// Property for SpecificCurrency
            /// </summary>
            public const string SpecificCurrency = "SPECSW";

            /// <summary>
            /// Property for AccountGroupCode
            /// </summary>
            public const string AccountGroupCode = "ACCTGRPCOD";

            /// <summary>
            /// Property for ControlAccount
            /// </summary>
            public const string ControlAccount = "CTRLACCTSW";

            /// <summary>
            /// Property for Reserved
            /// </summary>
            public const string Reserved = "SRCELDGID";

            /// <summary>
            /// Property for AllocationPercentTotal
            /// </summary>
            public const string AllocationPercentTotal = "ALLOCTOT";

            /// <summary>
            /// Property for StructureCode
            /// </summary>
            public const string StructureCode = "ABRKID";

            /// <summary>
            /// Property for YearLastClosed
            /// </summary>
            public const string YearLastClosed = "YRACCTCLOS";

            /// <summary>
            /// Property for AccountNumber
            /// </summary>
            public const string AccountNumber = "ACCTFMTTD";

            /// <summary>
            /// Property for AccountSegmentCode1
            /// </summary>
            public const string AccountSegmentCode1 = "ACSEGVAL01";

            /// <summary>
            /// Property for AccountSegmentCode2
            /// </summary>
            public const string AccountSegmentCode2 = "ACSEGVAL02";

            /// <summary>
            /// Property for AccountSegmentCode3
            /// </summary>
            public const string AccountSegmentCode3 = "ACSEGVAL03";

            /// <summary>
            /// Property for AccountSegmentCode4
            /// </summary>
            public const string AccountSegmentCode4 = "ACSEGVAL04";

            /// <summary>
            /// Property for AccountSegmentCode5
            /// </summary>
            public const string AccountSegmentCode5 = "ACSEGVAL05";

            /// <summary>
            /// Property for AccountSegmentCode6
            /// </summary>
            public const string AccountSegmentCode6 = "ACSEGVAL06";

            /// <summary>
            /// Property for AccountSegmentCode7
            /// </summary>
            public const string AccountSegmentCode7 = "ACSEGVAL07";

            /// <summary>
            /// Property for AccountSegmentCode8
            /// </summary>
            public const string AccountSegmentCode8 = "ACSEGVAL08";

            /// <summary>
            /// Property for AccountSegmentCode9
            /// </summary>
            public const string AccountSegmentCode9 = "ACSEGVAL09";

            /// <summary>
            /// Property for AccountSegmentCode10
            /// </summary>
            public const string AccountSegmentCode10 = "ACSEGVAL10";

            /// <summary>
            /// Property for SegmentCode
            /// </summary>
            public const string SegmentCode = "ACCTSEGVAL";

            /// <summary>
            /// Property for AccountGroupSortCode
            /// </summary>
            public const string AccountGroupSortCode = "ACCTGRPSCD";

            /// <summary>
            /// Property for PostToSegmentId
            /// </summary>
            public const string PostToSegmentId = "POSTOSEGID";

            /// <summary>
            /// Property for PostToSegmentIdCopy
            /// </summary>
            public const string PostToSegmentIdCopy = "POSTOSGCPY";

            /// <summary>
            /// Property for DefaultCurrencyCode
            /// </summary>
            public const string DefaultCurrencyCode = "DEFCURNCOD";

            /// <summary>
            /// Property for ProcessSwitch
            /// </summary>
            public const string ProcessSwitch = "PROCESSSW";

            /// <summary>
            /// Property for CreateSwitch
            /// </summary>
            public const string CreateSwitch = "CREATESW";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "OVALUES";

            /// <summary>
            /// Property for TransactionOptionalFields
            /// </summary>
            public const string TransactionOptionalFields = "TOVALUES";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PreviewAccount Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for UnformattedAccount
            /// </summary>
            public const int UnformattedAccount = 1;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 3;

            /// <summary>
            /// Property Indexer for NormalBalanceDebitOrCredit
            /// </summary>
            public const int NormalBalanceDebitOrCredit = 4;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 5;

            /// <summary>
            /// Property Indexer for ConsolidateJournals
            /// </summary>
            public const int ConsolidateJournals = 6;

            /// <summary>
            /// Property Indexer for QuantitiesAllowed
            /// </summary>
            public const int QuantitiesAllowed = 7;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 8;

            /// <summary>
            /// Property Indexer for AllocationsAllowed
            /// </summary>
            public const int AllocationsAllowed = 9;

            /// <summary>
            /// Property Indexer for AllocOffsetAccount
            /// </summary>
            public const int AllocOffsetAccount = 10;

            /// <summary>
            /// Property Indexer for AllocSourceType
            /// </summary>
            public const int AllocSourceType = 11;

            /// <summary>
            /// Property Indexer for Multicurrency
            /// </summary>
            public const int Multicurrency = 12;

            /// <summary>
            /// Property Indexer for SpecificCurrency
            /// </summary>
            public const int SpecificCurrency = 13;

            /// <summary>
            /// Property Indexer for AccountGroupCode
            /// </summary>
            public const int AccountGroupCode = 14;

            /// <summary>
            /// Property Indexer for ControlAccount
            /// </summary>
            public const int ControlAccount = 15;

            /// <summary>
            /// Property Indexer for Reserved
            /// </summary>
            public const int Reserved = 16;

            /// <summary>
            /// Property Indexer for AllocationPercentTotal
            /// </summary>
            public const int AllocationPercentTotal = 17;

            /// <summary>
            /// Property Indexer for StructureCode
            /// </summary>
            public const int StructureCode = 18;

            /// <summary>
            /// Property Indexer for YearLastClosed
            /// </summary>
            public const int YearLastClosed = 19;

            /// <summary>
            /// Property Indexer for AccountNumber
            /// </summary>
            public const int AccountNumber = 20;

            /// <summary>
            /// Property Indexer for AccountSegmentCode1
            /// </summary>
            public const int AccountSegmentCode1 = 21;

            /// <summary>
            /// Property Indexer for AccountSegmentCode2
            /// </summary>
            public const int AccountSegmentCode2 = 22;

            /// <summary>
            /// Property Indexer for AccountSegmentCode3
            /// </summary>
            public const int AccountSegmentCode3 = 23;

            /// <summary>
            /// Property Indexer for AccountSegmentCode4
            /// </summary>
            public const int AccountSegmentCode4 = 24;

            /// <summary>
            /// Property Indexer for AccountSegmentCode5
            /// </summary>
            public const int AccountSegmentCode5 = 25;

            /// <summary>
            /// Property Indexer for AccountSegmentCode6
            /// </summary>
            public const int AccountSegmentCode6 = 26;

            /// <summary>
            /// Property Indexer for AccountSegmentCode7
            /// </summary>
            public const int AccountSegmentCode7 = 27;

            /// <summary>
            /// Property Indexer for AccountSegmentCode8
            /// </summary>
            public const int AccountSegmentCode8 = 28;

            /// <summary>
            /// Property Indexer for AccountSegmentCode9
            /// </summary>
            public const int AccountSegmentCode9 = 29;

            /// <summary>
            /// Property Indexer for AccountSegmentCode10
            /// </summary>
            public const int AccountSegmentCode10 = 30;

            /// <summary>
            /// Property Indexer for SegmentCode
            /// </summary>
            public const int SegmentCode = 31;

            /// <summary>
            /// Property Indexer for AccountGroupSortCode
            /// </summary>
            public const int AccountGroupSortCode = 32;

            /// <summary>
            /// Property Indexer for PostToSegmentId
            /// </summary>
            public const int PostToSegmentId = 33;

            /// <summary>
            /// Property Indexer for PostToSegmentIdCopy
            /// </summary>
            public const int PostToSegmentIdCopy = 34;

            /// <summary>
            /// Property Indexer for DefaultCurrencyCode
            /// </summary>
            public const int DefaultCurrencyCode = 35;

            /// <summary>
            /// Property Indexer for ProcessSwitch
            /// </summary>
            public const int ProcessSwitch = 36;

            /// <summary>
            /// Property Indexer for CreateSwitch
            /// </summary>
            public const int CreateSwitch = 37;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 38;

            /// <summary>
            /// Property Indexer for TransactionOptionalFields
            /// </summary>
            public const int TransactionOptionalFields = 39;

        }

        #endregion
    }
}
