﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.GL.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PostingJournalDetails Constants 
    /// </summary>
    public partial class PostingJournalDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0016";

        /// <summary>
        /// Contains list of PostingJournalDetails Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Postingsequencenumber 
            /// </summary>
            public const string Postingsequencenumber = "POSTINGSEQ";

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "BATCHNBR";

            /// <summary>
            /// Property for Journalentrynumber 
            /// </summary>
            public const string Journalentrynumber = "ENTRYNBR";

            /// <summary>
            /// Property for Journaltransactionnumber 
            /// </summary>
            public const string Journaltransactionnumber = "TRANSNBR";

            /// <summary>
            /// Property for Journaldate 
            /// </summary>
            public const string Journaldate = "JRNLDATE";

            /// <summary>
            /// Property for Fiscalyear 
            /// </summary>
            public const string Fiscalyear = "FISCALYR";

            /// <summary>
            /// Property for Fiscalperiod 
            /// </summary>
            public const string Fiscalperiod = "FISCALPERD";

            /// <summary>
            /// Property for SourceLedgerCode 
            /// </summary>
            public const string SourceLedgerCode = "SRCELEDGER";

            /// <summary>
            /// Property for SourceTypeCode 
            /// </summary>
            public const string SourceTypeCode = "SRCETYPE";

            /// <summary>
            /// Property for Consolidationoccurredonpost 
            /// </summary>
            public const string Consolidationoccurredonpost = "CONSOLIDAT";

            /// <summary>
            /// Property for AccountNumber 
            /// </summary>
            public const string AccountNumber = "ACCTID";

            /// <summary>
            /// Property for CompanyID 
            /// </summary>
            public const string CompanyID = "COMPANYID";

            /// <summary>
            /// Property for Journaldetaildescription 
            /// </summary>
            public const string Journaldetaildescription = "JNLDTLDESC";

            /// <summary>
            /// Property for Journaldetailreference 
            /// </summary>
            public const string Journaldetailreference = "JNLDTLREF";

            /// <summary>
            /// Property for Journaltransactionamount 
            /// </summary>
            public const string Journaltransactionamount = "TRANSAMT";

            /// <summary>
            /// Property for Journaltransactionquantity 
            /// </summary>
            public const string Journaltransactionquantity = "TRANSQTY";

            /// <summary>
            /// Property for Nbrofsourcecurrencydecimals 
            /// </summary>
            public const string Nbrofsourcecurrencydecimals = "SCURNDEC";

            /// <summary>
            /// Property for Sourcecurrencyamount 
            /// </summary>
            public const string Sourcecurrencyamount = "SCURNAMT";

            /// <summary>
            /// Property for Homecurrencycode 
            /// </summary>
            public const string Homecurrencycode = "HCURNCODE";

            /// <summary>
            /// Property for Currencyratetabletype 
            /// </summary>
            public const string Currencyratetabletype = "RATETYPE";

            /// <summary>
            /// Property for Sourcecurrencycode 
            /// </summary>
            public const string Sourcecurrencycode = "SCURNCODE";

            /// <summary>
            /// Property for Dateofcurrencyrateselected 
            /// </summary>
            public const string Dateofcurrencyrateselected = "RATEDATE";

            /// <summary>
            /// Property for Currencyrateforconversion 
            /// </summary>
            public const string Currencyrateforconversion = "CONVRATE";

            /// <summary>
            /// Property for Currencyratespreadallowed 
            /// </summary>
            public const string Currencyratespreadallowed = "RATESPREAD";

            /// <summary>
            /// Property for Codeforratedatematching 
            /// </summary>
            public const string Codeforratedatematching = "DATEMTCHCD";

            /// <summary>
            /// Property for Currencyrateoperator 
            /// </summary>
            public const string Currencyrateoperator = "RATEOPER";

            /// <summary>
            /// Property for Printedstatuscode 
            /// </summary>
            public const string Printedstatuscode = "CODESTATUS";

            /// <summary>
            /// Property for EntryDate 
            /// </summary>
            public const string EntryDate = "DATEENTRY";

            /// <summary>
            /// Property for Reportcurrencyamount 
            /// </summary>
            public const string Reportcurrencyamount = "RPTAMT";

            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for Originator 
            /// </summary>
            public const string Originator = "ORIGCOMP";

            /// <summary>
            /// Property for AutoReversal 
            /// </summary>
            public const string AutoReversal = "SWREVERSE";

            /// <summary>
            /// Property for Destination 
            /// </summary>
            public const string Destination = "DESCOMP";

            /// <summary>
            /// Property for RouteNo 
            /// </summary>
            public const string RouteNo = "ROUTE";

            #endregion
        }

        /// <summary>
        /// Contains list of PostingJournalDetails Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Postingsequencenumber 
            /// </summary>
            public const int Postingsequencenumber = 1;

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;

            /// <summary>
            /// Property Indexer for Journalentrynumber 
            /// </summary>
            public const int Journalentrynumber = 3;

            /// <summary>
            /// Property Indexer for Journaltransactionnumber 
            /// </summary>
            public const int Journaltransactionnumber = 4;

            /// <summary>
            /// Property Indexer for Journaldate 
            /// </summary>
            public const int Journaldate = 5;

            /// <summary>
            /// Property Indexer for Fiscalyear 
            /// </summary>
            public const int Fiscalyear = 6;

            /// <summary>
            /// Property Indexer for Fiscalperiod 
            /// </summary>
            public const int Fiscalperiod = 7;

            /// <summary>
            /// Property Indexer for SourceLedgerCode 
            /// </summary>
            public const int SourceLedgerCode = 8;

            /// <summary>
            /// Property Indexer for SourceTypeCode 
            /// </summary>
            public const int SourceTypeCode = 9;

            /// <summary>
            /// Property Indexer for Consolidationoccurredonpost 
            /// </summary>
            public const int Consolidationoccurredonpost = 11;

            /// <summary>
            /// Property Indexer for AccountNumber 
            /// </summary>
            public const int AccountNumber = 12;

            /// <summary>
            /// Property Indexer for CompanyID 
            /// </summary>
            public const int CompanyID = 13;

            /// <summary>
            /// Property Indexer for Journaldetaildescription 
            /// </summary>
            public const int Journaldetaildescription = 14;

            /// <summary>
            /// Property Indexer for Journaldetailreference 
            /// </summary>
            public const int Journaldetailreference = 15;

            /// <summary>
            /// Property Indexer for Journaltransactionamount 
            /// </summary>
            public const int Journaltransactionamount = 16;

            /// <summary>
            /// Property Indexer for Journaltransactionquantity 
            /// </summary>
            public const int Journaltransactionquantity = 17;

            /// <summary>
            /// Property Indexer for Nbrofsourcecurrencydecimals 
            /// </summary>
            public const int Nbrofsourcecurrencydecimals = 18;

            /// <summary>
            /// Property Indexer for Sourcecurrencyamount 
            /// </summary>
            public const int Sourcecurrencyamount = 19;

            /// <summary>
            /// Property Indexer for Homecurrencycode 
            /// </summary>
            public const int Homecurrencycode = 20;

            /// <summary>
            /// Property Indexer for Currencyratetabletype 
            /// </summary>
            public const int Currencyratetabletype = 21;

            /// <summary>
            /// Property Indexer for Sourcecurrencycode 
            /// </summary>
            public const int Sourcecurrencycode = 22;

            /// <summary>
            /// Property Indexer for Dateofcurrencyrateselected 
            /// </summary>
            public const int Dateofcurrencyrateselected = 23;

            /// <summary>
            /// Property Indexer for Currencyrateforconversion 
            /// </summary>
            public const int Currencyrateforconversion = 24;

            /// <summary>
            /// Property Indexer for Currencyratespreadallowed 
            /// </summary>
            public const int Currencyratespreadallowed = 25;

            /// <summary>
            /// Property Indexer for Codeforratedatematching 
            /// </summary>
            public const int Codeforratedatematching = 26;

            /// <summary>
            /// Property Indexer for Currencyrateoperator 
            /// </summary>
            public const int Currencyrateoperator = 27;

            /// <summary>
            /// Property Indexer for Printedstatuscode 
            /// </summary>
            public const int Printedstatuscode = 28;

            /// <summary>
            /// Property Indexer for EntryDate 
            /// </summary>
            public const int EntryDate = 29;

            /// <summary>
            /// Property Indexer for Reportcurrencyamount 
            /// </summary>
            public const int Reportcurrencyamount = 30;

            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 31;

            /// <summary>
            /// Property Indexer for Originator 
            /// </summary>
            public const int Originator = 32;

            /// <summary>
            /// Property Indexer for AutoReversal 
            /// </summary>
            public const int AutoReversal = 33;

            /// <summary>
            /// Property Indexer for Destination 
            /// </summary>
            public const int Destination = 34;

            /// <summary>
            /// Property Indexer for RouteNo 
            /// </summary>
            public const int RouteNo = 35;

            #endregion
        }
    }
}