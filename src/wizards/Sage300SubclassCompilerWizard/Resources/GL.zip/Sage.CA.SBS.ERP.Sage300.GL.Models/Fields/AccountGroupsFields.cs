﻿namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Contains list of AccountGroups Constants 
    /// </summary>
    public partial class AccountGroups
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "GL0055";

        /// <summary>
        /// Contains list of AccountGroups Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for AccountGroupCode 
            /// </summary>
            public const string AccountGroupCode = "ACCTGRPCOD";
            /// <summary>
            /// Property for AccountGroupDescription 
            /// </summary>
            public const string AccountGroupDescription = "ACCTGRPDES";
            /// <summary>
            /// Property for AccountGroupSortCode 
            /// </summary>
            public const string AccountGroupSortCode = "SORTCODE";
            /// <summary>
            /// Property for GroupCategory 
            /// </summary>
            public const string GroupCategory = "GRPCOD";

            #endregion
        }


        /// <summary>
        /// Contains list of AccountGroups Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for AccountGroupCode 
            /// </summary>
            public const int AccountGroupCode = 1;
            /// <summary>
            /// Property Indexer for AccountGroupDescription 
            /// </summary>
            public const int AccountGroupDescription = 2;
            /// <summary>
            /// Property Indexer for AccountGroupSortCode 
            /// </summary>
            public const int AccountGroupSortCode = 3;
            /// <summary>
            /// Property Indexer for GroupCategory 
            /// </summary>
            public const int GroupCategory = 4;

            #endregion
        }


    }
}
