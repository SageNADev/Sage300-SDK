/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class for SourceJournalProfile
    /// </summary>
    public partial class SourceJournalProfile : ModelBase
    {
        /// <summary>
        /// SourceJournalProfile Constructor
        /// </summary>
        public SourceJournalProfile()
        {
            SourceCodeList = new EnumerableResponse<SourceCode>();
        }

        /// <summary>
        /// Gets or sets SourceCodeList 
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<SourceCode> SourceCodeList { get; set; }

        /// <summary>
        /// Gets or sets SourceJournalName 
        /// </summary>
        [Key]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceJournalName", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceJournalName, Id = Index.SourceJournalName, FieldType = EntityFieldType.Char, Size = 60)]
        public string SourceJournalName { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID01 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID01", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID01, Id = Index.SourceCodeID01, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID01 { get; set; }

        /// <summary>
        /// Gets or sets SourceType01 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType01", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType01, Id = Index.SourceType01, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType01 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID02 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID02", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID02, Id = Index.SourceCodeID02, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID02 { get; set; }

        /// <summary>
        /// Gets or sets SourceType02 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType02", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType02, Id = Index.SourceType02, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType02 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID03 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID03", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID03, Id = Index.SourceCodeID03, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID03 { get; set; }

        /// <summary>
        /// Gets or sets SourceType03 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType03", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType03, Id = Index.SourceType03, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType03 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID04 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID04", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID04, Id = Index.SourceCodeID04, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID04 { get; set; }

        /// <summary>
        /// Gets or sets SourceType04 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType04", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType04, Id = Index.SourceType04, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType04 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID05 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID05", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID05, Id = Index.SourceCodeID05, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID05 { get; set; }

        /// <summary>
        /// Gets or sets SourceType05 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType05", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType05, Id = Index.SourceType05, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType05 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID06 
        /// </summary>
        [ViewField(Name = Fields.SourceCodeID06, Id = Index.SourceCodeID06, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID06 { get; set; }

        /// <summary>
        /// Gets or sets SourceType06 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType06", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType06, Id = Index.SourceType06, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType06 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID07 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID07", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID07, Id = Index.SourceCodeID07, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID07 { get; set; }

        /// <summary>
        /// Gets or sets SourceType07 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType07", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType07, Id = Index.SourceType07, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType07 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID08 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID08", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID08, Id = Index.SourceCodeID08, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID08 { get; set; }

        /// <summary>
        /// Gets or sets SourceType08 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType08", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType08, Id = Index.SourceType08, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType08 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID09 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID09", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID09, Id = Index.SourceCodeID09, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID09 { get; set; }

        /// <summary>
        /// Gets or sets SourceType09 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType09", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType09, Id = Index.SourceType09, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType09 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID10 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID10", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID10, Id = Index.SourceCodeID10, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID10 { get; set; }

        /// <summary>
        /// Gets or sets SourceType10 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType10", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType10, Id = Index.SourceType10, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType10 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID11 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID11", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID11, Id = Index.SourceCodeID11, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID11 { get; set; }

        /// <summary>
        /// Gets or sets SourceType11 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType11", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType11, Id = Index.SourceType11, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType11 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID12 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID12", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID12, Id = Index.SourceCodeID12, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID12 { get; set; }

        /// <summary>
        /// Gets or sets SourceType12 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType12", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType12, Id = Index.SourceType12, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType12 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID13 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID13", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID13, Id = Index.SourceCodeID13, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID13 { get; set; }

        /// <summary>
        /// Gets or sets SourceType13 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType13", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType13, Id = Index.SourceType13, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType13 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID14 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID14", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID14, Id = Index.SourceCodeID14, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID14 { get; set; }

        /// <summary>
        /// Gets or sets SourceType14 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType14", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType14, Id = Index.SourceType14, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType14 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID15 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID15", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID15, Id = Index.SourceCodeID15, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID15 { get; set; }

        /// <summary>
        /// Gets or sets SourceType15 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType15", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType15, Id = Index.SourceType15, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType15 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID16 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID16", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID16, Id = Index.SourceCodeID16, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID16 { get; set; }

        /// <summary>
        /// Gets or sets SourceType16 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType16", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType16, Id = Index.SourceType16, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType16 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID17 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID17", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID17, Id = Index.SourceCodeID17, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID17 { get; set; }

        /// <summary>
        /// Gets or sets SourceType17 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType17", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType17, Id = Index.SourceType17, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType17 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID18 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID18", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID18, Id = Index.SourceCodeID18, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID18 { get; set; }

        /// <summary>
        /// Gets or sets SourceType18 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType18", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType18, Id = Index.SourceType18, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType18 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID19 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID19", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID19, Id = Index.SourceCodeID19, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID19 { get; set; }

        /// <summary>
        /// Gets or sets SourceType19 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType19", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType19, Id = Index.SourceType19, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType19 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID20 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID20", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID20, Id = Index.SourceCodeID20, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID20 { get; set; }

        /// <summary>
        /// Gets or sets SourceType20 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType20", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType20, Id = Index.SourceType20, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType20 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID21 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID21", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID21, Id = Index.SourceCodeID21, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID21 { get; set; }

        /// <summary>
        /// Gets or sets SourceType21 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType21", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType21, Id = Index.SourceType21, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType21 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID22 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID22", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID22, Id = Index.SourceCodeID22, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID22 { get; set; }

        /// <summary>
        /// Gets or sets SourceType22 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType22", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType22, Id = Index.SourceType22, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType22 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID23 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID23", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID23, Id = Index.SourceCodeID23, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID23 { get; set; }

        /// <summary>
        /// Gets or sets SourceType23 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType23", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType23, Id = Index.SourceType23, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType23 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID24 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID24", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID24, Id = Index.SourceCodeID24, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID24 { get; set; }

        /// <summary>
        /// Gets or sets SourceType24 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType24", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType24, Id = Index.SourceType24, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType24 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID25 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID25", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID25, Id = Index.SourceCodeID25, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID25 { get; set; }

        /// <summary>
        /// Gets or sets SourceType25 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType25", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType25, Id = Index.SourceType25, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType25 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID26 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID26", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID26, Id = Index.SourceCodeID26, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID26 { get; set; }

        /// <summary>
        /// Gets or sets SourceType26 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType26", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType26, Id = Index.SourceType26, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType26 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID27 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID27", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID27, Id = Index.SourceCodeID27, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID27 { get; set; }

        /// <summary>
        /// Gets or sets SourceType27 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType27", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType27, Id = Index.SourceType27, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType27 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID28 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID28", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID28, Id = Index.SourceCodeID28, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID28 { get; set; }

        /// <summary>
        /// Gets or sets SourceType28 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType28", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType28, Id = Index.SourceType28, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType28 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID29 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID29", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID29, Id = Index.SourceCodeID29, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID29 { get; set; }

        /// <summary>
        /// Gets or sets SourceType29 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType29", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType29, Id = Index.SourceType29, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType29 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID30 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID30", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID30, Id = Index.SourceCodeID30, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID30 { get; set; }

        /// <summary>
        /// Gets or sets SourceType30 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType30", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType30, Id = Index.SourceType30, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType30 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID31 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID31", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID31, Id = Index.SourceCodeID31, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID31 { get; set; }

        /// <summary>
        /// Gets or sets SourceType31 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType31", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType31, Id = Index.SourceType31, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType31 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID32 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID32", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID32, Id = Index.SourceCodeID32, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID32 { get; set; }

        /// <summary>
        /// Gets or sets SourceType32 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType32", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType32, Id = Index.SourceType32, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType32 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID33 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID33", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID33, Id = Index.SourceCodeID33, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID33 { get; set; }

        /// <summary>
        /// Gets or sets SourceType33 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType33", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType33, Id = Index.SourceType33, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType33 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID34 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID34", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID34, Id = Index.SourceCodeID34, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID34 { get; set; }

        /// <summary>
        /// Gets or sets SourceType34 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType34", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType34, Id = Index.SourceType34, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType34 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID35 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID35", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID35, Id = Index.SourceCodeID35, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID35 { get; set; }

        /// <summary>
        /// Gets or sets SourceType35 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType35", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType35, Id = Index.SourceType35, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType35 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID36 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID36", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID36, Id = Index.SourceCodeID36, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID36 { get; set; }

        /// <summary>
        /// Gets or sets SourceType36 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType36", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType36, Id = Index.SourceType36, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType36 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID37 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID37", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID37, Id = Index.SourceCodeID37, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID37 { get; set; }

        /// <summary>
        /// Gets or sets SourceType37 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType37", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType37, Id = Index.SourceType37, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType37 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID38 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID38", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID38, Id = Index.SourceCodeID38, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID38 { get; set; }

        /// <summary>
        /// Gets or sets SourceType38 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType38", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType38, Id = Index.SourceType38, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType38 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID39 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID39", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID39, Id = Index.SourceCodeID39, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID39 { get; set; }

        /// <summary>
        /// Gets or sets SourceType39 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType39", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType39, Id = Index.SourceType39, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType39 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID40 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID40", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID40, Id = Index.SourceCodeID40, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID40 { get; set; }

        /// <summary>
        /// Gets or sets SourceType40 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType40", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType40, Id = Index.SourceType40, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType40 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID41 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID41", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID41, Id = Index.SourceCodeID41, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID41 { get; set; }

        /// <summary>
        /// Gets or sets SourceType41 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType41", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType41, Id = Index.SourceType41, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType41 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID42 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID42", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID42, Id = Index.SourceCodeID42, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID42 { get; set; }

        /// <summary>
        /// Gets or sets SourceType42 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType42", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType42, Id = Index.SourceType42, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType42 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID43 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID43", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID43, Id = Index.SourceCodeID43, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID43 { get; set; }

        /// <summary>
        /// Gets or sets SourceType43 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType43", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType43, Id = Index.SourceType43, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType43 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID44 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID44", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID44, Id = Index.SourceCodeID44, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID44 { get; set; }

        /// <summary>
        /// Gets or sets SourceType44 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType44", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType44, Id = Index.SourceType44, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType44 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID45 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID45", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID45, Id = Index.SourceCodeID45, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID45 { get; set; }

        /// <summary>
        /// Gets or sets SourceType45 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType45", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType45, Id = Index.SourceType45, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType45 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID46 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID46", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID46, Id = Index.SourceCodeID46, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID46 { get; set; }

        /// <summary>
        /// Gets or sets SourceType46 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType46", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType46, Id = Index.SourceType46, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType46 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID47 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID47", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID47, Id = Index.SourceCodeID47, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID47 { get; set; }

        /// <summary>
        /// Gets or sets SourceType47 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType47", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType47, Id = Index.SourceType47, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType47 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID48 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID48", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID48, Id = Index.SourceCodeID48, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID48 { get; set; }

        /// <summary>
        /// Gets or sets SourceType48 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType48", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType48, Id = Index.SourceType48, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType48 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID49 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID49", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID49, Id = Index.SourceCodeID49, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID49 { get; set; }

        /// <summary>
        /// Gets or sets SourceType49 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType49", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType49, Id = Index.SourceType49, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType49 { get; set; }

        /// <summary>
        /// Gets or sets SourceCodeID50 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCodeID50", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceCodeID50, Id = Index.SourceCodeID50, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceCodeID50 { get; set; }

        /// <summary>
        /// Gets or sets SourceType50 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceType50", ResourceType = typeof(SourceJournalProfilesResx))]
        [ViewField(Name = Fields.SourceType50, Id = Index.SourceType50, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType50 { get; set; }

        #region UI

        /// <summary>
        /// Exist
        /// </summary>
        public bool Exist { get; set; } 

        #endregion
    }
}
