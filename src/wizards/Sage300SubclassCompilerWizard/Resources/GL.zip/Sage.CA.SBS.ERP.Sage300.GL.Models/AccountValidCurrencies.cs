/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class AccountValidCurrencies : ModelBase
    {
        /// <summary>
        /// Constructor for intializing Enum Values
        /// </summary>
        public AccountValidCurrencies()
        {
            RevaluationSwitch = Revaluation.Donotrevalue;
        }

        /// <summary>
        /// Gets or sets AccountNumber 
        /// </summary>
        [Key]
        [Display(Name = "AccountNumber", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCurrency", ResourceType = typeof(AccountsResx))]
        [Key]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RevaluationSwitch 
        /// </summary>
        [Display(Name = "RevaluationSwitch1", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.RevaluationSwitch, Id = Index.RevaluationSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public Revaluation RevaluationSwitch { get; set; }

        /// <summary>
        /// Gets or sets RevaluationSwitch String
        /// </summary>
        public string RevaluationSwitchString
        {
            get { return EnumUtility.GetStringValue(RevaluationSwitch); }
        }

        /// <summary>
        /// Gets or sets RevaluationCode 
        /// </summary>
        [Display(Name = "RevaluationCode", ResourceType = typeof(AccountsResx))]
        [ViewField(Name = Fields.RevaluationCode, Id = Index.RevaluationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RevaluationCode { get; set; }

        /// <summary>
        /// Gets or sets Currency Description 
        /// </summary>
        [Display(Name = "CurrencyDescription", ResourceType = typeof(AccountsResx))]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// IsValidate
        /// </summary>
        public bool IsValidate { get; set; }

        /// <summary>
        /// Gets or sets TextValue 
        /// </summary>
        public string TextValue { get; set; }

    }
}
