/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Class RecurringJournalHeader.
    /// </summary>
    public partial class RecurringJournalHeader : ModelBase
    {
        /// <summary>
        /// Gets or sets the Recurring entry code
        /// </summary>
        /// <value>The recurring entry code.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecurringEntryCode", ResourceType = typeof(RecurringEntriesResx))]
        [Key]
        [ViewField(Name = Fields.RecurringEntryCode, Id = Index.RecurringEntryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string RecurringEntryCode { get; set; }

        /// <summary>
        /// Gets or sets the Recurring entry description
        /// </summary>
        /// <value>The recurring entry description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecurringEntryDescription", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.RecurringEntryDescription, Id = Index.RecurringEntryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RecurringEntryDescription { get; set; }

        /// <summary>
        /// Gets or sets the Start date
        /// </summary>
        /// <value>The start date.</value>
        [Display(Name = "StartDate", ResourceType = typeof(RecurringEntriesResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets the expiration type
        /// </summary>
        /// <value>The type of the expiration.</value>
        [Display(Name = "ExpirationType", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.ExpirationType, Id = Index.ExpirationType, FieldType = EntityFieldType.Int, Size = 2)]
        public ExpirationType ExpirationType { get; set; }

        /// <summary>
        /// To get the string value of the ExpirationType property
        /// Added for Finder filter
        /// </summary>
        /// <value>The ExpirationType string.</value>
        public string ExpirationTypeString
        {
            get { return EnumUtility.GetStringValue(ExpirationType); }
        }

        /// <summary>
        /// Gets or sets the expiration date
        /// </summary>
        /// <value>The expiration date.</value>
        [Display(Name = "ExpirationDate", ResourceType = typeof(RecurringEntriesResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets the last run date
        /// </summary>
        /// <value>The last run date.</value>
        [Display(Name = "LastRunDate", ResourceType = typeof(RecurringEntriesResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [ViewField(Name = Fields.LastRunDate, Id = Index.LastRunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastRunDate { get; set; }

        /// <summary>
        /// Gets or sets the status
        /// </summary>
        /// <value>The status.</value>
        [Display(Name = "Status", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// To get the string value of the Status property
        /// </summary>
        /// <value>The status string.</value>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Recurring Entry Status property for UI
        /// </summary>
        /// <value><c>true</c> if this instance is active; otherwise, <c>false</c>.</value>
        [Display(Name = "InactiveAsOfDate", ResourceType = typeof(CommonResx))]
        public bool IsActive
        {
            get
            {
                if (Status == Status.Inactive)
                {
                    return true;
                }
                return false;
            }
            set { Status = value ? Status.Inactive : Status.Active; }
        }

        /// <summary>
        /// Gets or sets the inactive date
        /// </summary>
        /// <value>The inactive date.</value>
        [Display(Name = "InactiveDate", ResourceType = typeof(RecurringEntriesResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? InactiveDate { get; set; }

        /// <summary>
        /// Get or set Inactive Server Date
        /// </summary>
        public DateTime? InactiveServerDate { get; set; }

        /// <summary>
        /// Gets or sets the last maintained date
        /// </summary>
        /// <value>The last maintained date.</value>
        [Display(Name = "LastMaintainedDate", ResourceType = typeof(RecurringEntriesResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [ViewField(Name = Fields.LastMaintainedDate, Id = Index.LastMaintainedDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastMaintainedDate { get; set; }

        /// <summary>
        /// Gets or sets the source ledger
        /// </summary>
        /// <value>The source ledger.</value>
        [Display(Name = "SourceCode", ResourceType = typeof(GLCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SourceLedger, Id = Index.SourceLedger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceLedger { get; set; }

        /// <summary>
        /// Gets or sets the source type
        /// </summary>
        /// <value>The type of the source.</value>
        [Display(Name = "SourceType", ResourceType = typeof(RecurringEntriesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SourceType, Id = Index.SourceType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceType { get; set; }

        /// <summary>
        /// Gets or sets the source code description
        /// </summary>
        /// <value>The source code description.</value>
        [Display(Name = "SourceCodeDescription", ResourceType = typeof(RecurringEntriesResx))]
        public string SourceCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets the auto reversal
        /// </summary>
        /// <value>The automatic reversal.</value>
        [Display(Name = "AutoReverse", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.AutoReversal, Id = Index.AutoReversal, FieldType = EntityFieldType.Int, Size = 2)]
        public AutoReversal AutoReversal { get; set; }

        /// <summary>
        /// To get the string value of the AutoReversal property
        /// Added for Finder filter
        /// </summary>
        /// <value>The AutoReversal string.</value>
        public string AutoReversalString
        {
            get { return EnumUtility.GetStringValue(AutoReversal); }
        }

        /// <summary>
        /// AutoReverse property for UI
        /// </summary>
        /// <value><c>true</c> if [automatic reverse]; otherwise, <c>false</c>.</value>
        public bool AutoReverse
        {
            get
            {
                if (AutoReversal == AutoReversal.AutoReversalOff)
                {
                    return false;
                }
                return true;
            }
            set { AutoReversal = value ? AutoReversal.AutoReversalOn : AutoReversal.AutoReversalOff; }
        }

        /// <summary>
        /// Gets or sets journal entry description
        /// </summary>
        /// <value>The journal entry description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.JournalEntryDescription, Id = Index.JournalEntryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string JournalEntryDescription { get; set; }

        /// <summary>
        /// Gets or sets exchange rate switch
        /// </summary>
        /// <value>The exchange rate switch.</value>
        [Display(Name = "ExchangeRate", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.ExchangeRateSwitch, Id = Index.ExchangeRateSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public ExchangeRateSwitch ExchangeRateSwitch { get; set; }

        /// <summary>
        /// To get the string value of the ExchangeRate property
        /// Added for Finder filter
        /// </summary>
        /// <value>The ExchangeRate string.</value>
        public string ExchangeRateString
        {
            get { return EnumUtility.GetStringValue(ExchangeRateSwitch); }
        }

        /// <summary>
        /// Gets or sets rounding account
        /// </summary>
        /// <value>The rounding account.</value>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RoundingAccount", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.RoundingAccount, Id = Index.RoundingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RoundingAccount { get; set; }

        /// <summary>
        /// Gets or sets debits
        /// </summary>
        /// <value>The debits.</value>
        [Display(Name = "Debits", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.Debits, Id = Index.Debits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Debits { get; set; }

        /// <summary>
        /// Gets or sets credits
        /// </summary>
        /// <value>The credits.</value>
        [Display(Name = "Credits", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.Credits, Id = Index.Credits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Credits { get; set; }

        /// <summary>
        /// Gets or sets quantity
        /// </summary>
        /// <value>The quantity.</value>
        [Display(Name = "Quantity", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets reseved
        /// </summary>
        /// <value>The reserved.</value>
        [Display(Name = "Reserved", ResourceType = typeof(GLCommonResx))]
        public int Reserved { get; set; }

        /// <summary>
        /// Gets or sets schedule
        /// </summary>
        /// <value>The schedule.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ScheduleCode", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.Schedule, Id = Index.Schedule, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Schedule { get; set; }

        /// <summary>
        /// Gets or sets the source code description
        /// </summary>
        /// <value>The schedule code description.</value>
        [Display(Name = "ScheduleCodeDescription", ResourceType = typeof(RecurringEntriesResx))]
        public string ScheduleCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets schedule link
        /// </summary>
        /// <value>The schedule link.</value>
        [Display(Name = "ScheduleLink", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.ScheduleLink, Id = Index.ScheduleLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ScheduleLink { get; set; }

        /// <summary>
        /// Gets or sets zero source amount counter
        /// </summary>
        /// <value>The zero source amount counter.</value>
        [Display(Name = "ZeroSourceAmountCounter", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.ZeroSourceAmountCounter, Id = Index.ZeroSourceAmountCounter, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ZeroSourceAmountCounter { get; set; }

        /// <summary>
        /// Gets or sets out of balance by
        /// </summary>
        /// <value>The outof balance by.</value>
        [Display(Name = "OutofBalance", ResourceType = typeof(RecurringEntriesResx))]
        [ViewField(Name = Fields.OutofBalanceBy, Id = Index.OutofBalanceBy, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OutofBalanceBy { get; set; }

        /// <summary>
        /// Gets or sets recurring entry GL Sec. Status
        /// </summary>
        /// <value>The recurring entry gl sec status.</value>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RecurringEntryGLSecStatus, Id = Index.RecurringEntryGLSecStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int RecurringEntryGLSecStatus { get; set; }

        /// <summary>
        /// Gets or sets List of GL Recurring entries
        /// </summary>
        /// <value>The recurring entries.</value>
        public EnumerableResponse<RecurringEntryDetail> RecurringEntries { get; set; }

        ///// <summary>
        ///// Gets or sets the property if the company is Multicurrency enabled
        ///// </summary>
        ///// <value><c>true</c> if this instance is multi currency enabled; otherwise, <c>false</c>.</value>
        //public bool IsMultiCurrencyEnabled { get; set; }

        /// <summary>
        /// Gets or sets the entry mode for recurring entry
        /// </summary>
        /// <value>The entry mode.</value>
        public EntryMode EntryMode { get; set; }

        /// <summary>
        /// Gets or sets the Company functional currency
        /// </summary>
        /// <value>The home currency.</value>
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        public short SessionWarnDays { get; set; }
    }

    /// <summary>
    /// Recurring Entry Setup
    /// </summary>
    public class RecurringEntrySetup : ModelBase
    {

        /// <summary>
        /// Has Optional Field license
        /// </summary>
        public bool HasOptionalFields;
    }

}
