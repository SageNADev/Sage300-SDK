/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    /// <summary>
    /// Account group- Sort Order class
    /// </summary>
    public partial class AccountGroupSortOrder : ModelBase
    {
        /// <summary>
        /// Gets or sets AccountGroupCode 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.AccountGroupCode, Id = Index.AccountGroupCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AccountGroupCode { get; set; }

        /// <summary>
        /// Gets or sets NewSortCode 
        /// </summary>
        [Display(Name = "NewSortCode", ResourceType = typeof(AccountGroupsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NewSortCode, Id = Index.NewSortCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string NewSortCode { get; set; }

        /// <summary>
        /// Gets or sets AccountGroupDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AccountGroupDescription, Id = Index.AccountGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string AccountGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets OriginalSortCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OriginalSortCode, Id = Index.OriginalSortCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string OriginalSortCode { get; set; }

        /// <summary>
        /// Gets or sets EmptyTableSwitch 
        /// </summary>
        [ViewField(Name = Fields.EmptyTableSwitch, Id = Index.EmptyTableSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public EmptyTableSwitch EmptyTableSwitch { get; set; }

        /// <summary>
        /// Gets or sets AccountGroupExistsSwitch 
        /// </summary>
        [ViewField(Name = Fields.AccountGroupExistsSwitch, Id = Index.AccountGroupExistsSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public EmptyTableSwitch AccountGroupExistsSwitch { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand 
        /// </summary>
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandAccountGroups ProcessCommand { get; set; }

        /// <summary>
        /// Sort order 
        /// </summary>
        public SortOrder SortOrder { get; set; }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        public long SerialNumber { get; set; }
    }
}
