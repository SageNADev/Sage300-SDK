/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Resources.Forms;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class ControlAccountSubledgers : ModelBase
    {
        /// <summary>
        /// Gets or sets Account 
        /// </summary>
        [ViewField(Name = Fields.Account, Id = Index.Account, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Account { get; set; }

        /// <summary>
        /// Gets or sets Subledger 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Subledger", ResourceType = typeof(AccountsResx))]
        [Key]
        [ViewField(Name = Fields.Subledger, Id = Index.Subledger, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string Subledger { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        [Key]
        public long SerialNumber { get; set; }

    }
}
