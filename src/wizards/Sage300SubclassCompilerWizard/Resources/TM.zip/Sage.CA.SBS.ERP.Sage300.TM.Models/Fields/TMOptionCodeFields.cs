// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.TM.Models
{
    /// <summary>
    /// Contains list of TMOptionCode Constants
    /// </summary>
    public partial class TMOptionCode
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "TM0007";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of TMOptionCode Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for OrganisationId
            /// </summary>
            public const string OrganisationId = "ORGID";

            /// <summary>
            /// Property for Option
            /// </summary>
            public const string Option = "OPTION";

            /// <summary>
            /// Property for Value
            /// </summary>
            public const string Value = "VALUE";

            /// <summary>
            /// Property for DateLastModified
            /// </summary>
            public const string DateLastModified = "DATELASTMN";

            /// <summary>
            /// Property for Required
            /// </summary>
            public const string Required = "REQUIRED";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of TMOptionCode Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for OrganisationId
            /// </summary>
            public const int OrganisationId = 1;

            /// <summary>
            /// Property Indexer for Option
            /// </summary>
            public const int Option = 2;

            /// <summary>
            /// Property Indexer for Value
            /// </summary>
            public const int Value = 3;

            /// <summary>
            /// Property Indexer for DateLastModified
            /// </summary>
            public const int DateLastModified = 4;

            /// <summary>
            /// Property Indexer for Required
            /// </summary>
            public const int Required = 5;


        }

        #endregion

    }
}