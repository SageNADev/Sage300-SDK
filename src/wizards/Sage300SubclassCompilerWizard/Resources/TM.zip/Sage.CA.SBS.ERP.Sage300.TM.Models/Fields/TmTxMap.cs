/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TM.Models
{
    /// <summary>
    /// Contains list of Malaysia GST Tax Codes Constants 
    /// </summary>
    public partial class TmTxMap
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "TM0003";

        /// <summary>
        /// Contains list of Malaysia GST Tax Codes Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Effective Date 
            /// </summary>
            public const string EffDate = "EFFDATE";

            /// <summary>
            /// Property for Tax Code 
            /// </summary>
            public const string TaxRCode = "TAXRCODE";

            /// <summary>
            /// Property for Transaction Type 
            /// </summary>
            public const string TType = "TTYPE";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Desc = "DESC";

            /// <summary>
            /// Property for Remark 
            /// </summary>
            public const string Remark = "REMARK";

            /// <summary>
            /// Property for Deprecated 
            /// </summary>
            public const string Deprecated = "DEPRECATED";

            /// <summary>
            /// Property for Replacement 
            /// </summary>
            public const string ReplacedBy = "REPLACEDBY";

            /// <summary>
            /// Property for Field1 
            /// </summary>
            public const string Field1 = "FIELD1";

            /// <summary>
            /// Property for Field2 
            /// </summary>
            public const string Field2 = "FIELD2";

            /// <summary>
            /// Property for Field3 
            /// </summary>
            public const string Field3 = "FIELD3";

            /// <summary>
            /// Property for Field4 
            /// </summary>
            public const string Field4 = "FIELD4";

            /// <summary>
            /// Property for Field5 
            /// </summary>
            public const string Field5 = "FIELD5";

            #endregion
        }

        /// <summary>
        /// Contains list of Malaysia GST Tax Codes Index Constants
        /// </summary>
        public class Index
        {
            #region Indexes

            /// <summary>
            /// Index for Effective Date 
            /// </summary>
            public const int EffDate = 1;

            /// <summary>
            /// Property for Tax Code 
            /// </summary>
            public const int TaxRCode = 2;

            /// <summary>
            /// Index for Transaction Type 
            /// </summary>
            public const int TType = 3;

            /// <summary>
            /// Index for Description 
            /// </summary>
            public const int Desc = 4;

            /// <summary>
            /// Index for Remark 
            /// </summary>
            public const int Remark = 5;

            /// <summary>
            /// Index for precated 
            /// </summaryint
            public const int Deprecated = 6;

            /// <summary>
            /// Index for placement 
            /// </summaryint
            public const int ReplacedBy = 7;

            /// <summary>
            /// Index for field1 
            /// </summaryint
            public const int Field1 = 8;

            /// <summary>
            /// Index for field2 
            /// </summaryint
            public const int Field2 = 9;

            /// <summary>
            /// Index for field3 
            /// </summaryint
            public const int Field3 = 10;

            /// <summary>
            /// Index for field4 
            /// </summaryint
            public const int Field4 = 11;

            /// <summary>
            /// Index for field5 
            /// </summaryint
            public const int Field5 = 12;

            #endregion
        }
    }
}