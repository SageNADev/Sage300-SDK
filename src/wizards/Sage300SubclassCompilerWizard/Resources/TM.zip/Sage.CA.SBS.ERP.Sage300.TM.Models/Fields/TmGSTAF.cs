/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TM.Models
{
    /// <summary>
    /// Contains list of Malaysia GST Tax Codes Constants 
    /// </summary>
    public partial class TmGSTAF
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "TM0004";

        /// <summary>
        /// Contains list of Malaysia GST Tax Codes Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Form Year
            /// </summary>
            public const string FromYear = "YEARSTART";

            /// <summary>
            /// Property for From Period
            /// </summary>
            public const string FromPeriod = "PERSTART";

            /// <summary>
            /// Property for From Period
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for To Year 
            /// </summary>
            public const string ToYear = "YEAREND";

            /// <summary>
            /// Property for To Period 
            /// </summary>
            public const string ToPeriod = "PERIODEND";

            /// <summary>
            /// Property for To Date
            /// </summary>
            public const string ToDate = "TODATE";

            /// <summary>
            /// Property for Output Filename 
            /// </summary>
            public const string FileName = "FILENAME";


            /// <summary>
            /// Property for Overwrite Mode 
            /// </summary>
            public const string Overwrite = "OVERWRITE";

            /// <summary>
            /// Property for Output Directory 
            /// </summary>
            public const string OutPutDir = "FPATH";

            #endregion
        }

        /// <summary>
        /// Contains list of Malaysia GST Tax Codes Index Constants
        /// </summary>
        public class Index
        {
            #region Indexes

            /// <summary>
            /// Index for Form Year
            /// </summary>
            public const int FromYear = 1;

            /// <summary>
            /// Index for To Year 
            /// </summary>
            public const int ToYear = 2;

            /// <summary>
            /// Index for From Period
            /// </summary>
            public const int FromPeriod = 3;

            /// <summary>
            /// Index for To Period 
            /// </summary>
            public const int ToPeriod = 4;

            /// <summary>
            /// Index for From Period
            /// </summary>
            public const int FromDate = 5;

            /// <summary>
            /// Index for To Date
            /// </summary>
            public const int ToDate = 6;

            /// <summary>
            /// Index for Overwrite Mode  
            /// </summary>
            public const int Overwrite = 7;

            /// <summary>
            /// Index for Output Filename 
            /// </summary>
            public const int FileName = 8;

            /// <summary>
            /// Index for Output Directory 
            /// </summary>
            public const int OutPutDir = 9;

            #endregion
        }
    }
}