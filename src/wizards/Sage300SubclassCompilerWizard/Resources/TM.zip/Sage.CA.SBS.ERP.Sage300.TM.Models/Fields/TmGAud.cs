/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TM.Models
{
    /// <summary>
    /// Contains list of GST F5 Audit Constants 
    /// </summary>
    public partial class TmGAud
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "TS0180";

        /// <summary>
        /// Contains list of GST F5 Audit Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for GST Report Field 
            /// </summary>
            public const string GstRptFld = "GSTRPTFLD";

            /// <summary>
            /// Property for Detail Sequence
            /// </summary>
            public const string DetailSeq = "DETAILSEQ";

            /// <summary>
            /// Property for Uniquifier
            /// </summary>
            public const string Unique = "UNIQUE";

            /// <summary>
            /// Property for Document Date
            /// </summary>
            public const string DocDate = "DOCDATE";

            /// <summary>
            /// Property for Docment Number
            /// </summary>
            public const string DocNumber = "DOCNUMBER";

            /// <summary>
            /// Property for Realized Gain/Loss Reference
            /// </summary>
            public const string RlGaLoXRef = "RLGALOXREF";

            /// <summary>
            /// Property for Tax Authority
            /// </summary>
            public const string Authority = "AUTHORITY";

            /// <summary>
            /// Property for Transaction Type
            /// </summary>
            public const string TType = "TTYPE";

            /// <summary>
            /// Property for Customer/Vendor Class
            /// </summary>
            public const string BuyerClass = "BUYERCLASS";

            /// <summary>
            /// Property for Customer/Vendor Class Description
            /// </summary>
            public const string BuyerClasD = "BUYERCLASD";

            /// <summary>
            /// Property for Item Class
            /// </summary>
            public const string ItemClass = "ITEMCLASS";

            /// <summary>
            /// Property for Item Class Description
            /// </summary>
            public const string ItemClassD = "ITEMCLASSD";

            /// <summary>
            /// Property for Tax Code
            /// </summary>
            public const string TaxRCode = "TAXRCODE";

            /// <summary>
            /// Property for Tax Base Amount
            /// </summary>
            public const string TBaseAmt = "TBASEAMT";

            /// <summary>
            /// Property for Tax Amount
            /// </summary>
            public const string TCurnTax = "TCURNTAX";

            /// <summary>
            /// Property for Documnet Amount
            /// </summary>
            public const string TotalWTax = "TOTALWTAX";

            /// <summary>
            /// Property for Customer/Vendor Number
            /// </summary>
            public const string CustVend = "CUSTVEND";

            /// <summary>Customer/Vendor Name
            /// Property for 
            /// </summary>
            public const string CustVendNm = "CUSTVENDNM";

            /// <summary>
            /// Property for Posting Date 
            /// </summary>
            public const string PostDate = "POSTDATE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Descriptio = "DESCRIPTIO";

            /// <summary>
            /// Property for Fiscal Year
            /// </summary>
            public const string FiscYear = "FISCYEAR";

            /// <summary>
            /// Property for Fiscal Period
            /// </summary>
            public const string FiscPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for Source ID
            /// </summary>
            public const string SrceApp = "SRCEAPP";

            #endregion
        }

        /// <summary>
        /// Contains list of GST F5 Audit Index Constants
        /// </summary>
        public class Index
        {
            #region Indexes

            /// <summary>
            /// Index for GST Report Field
            /// </summary>
            public const int GstRptFld = 1;

            /// <summary>
            /// Index for Detail Sequence
            /// </summary>
            public const int DetailSeq = 2;

            /// <summary>
            /// Index for Uniquifier
            /// </summary>
            public const int Unique = 3;

            /// <summary>
            /// Index for Document Date
            /// </summary>
            public const int DocDate = 4;

            /// <summary>
            /// Index for Document Number
            /// </summary>
            public const int DocNumber = 5;

            /// <summary>
            /// Index for Realized Gain/Loss Reference
            /// </summary>
            public const int RlGaLoXRef = 6;

            /// <summary>
            /// Index for Tax Authority
            /// </summary>
            public const int Authority = 7;

            /// <summary>
            /// Index for Transaction Type
            /// </summary>
            public const int TType = 8;

            /// <summary>
            /// Index for Customer/Vender Class
            /// </summary>
            public const int BuyerClass = 9;

            /// <summary>
            /// Index for Customer/Vendor Class Description
            /// </summary>
            public const int BuyerClasD = 10;

            /// <summary>
            /// Index for Item Class
            /// </summary>
            public const int ItemClass = 11;

            /// <summary>
            /// Index for Item Class Description
            /// </summary>
            public const int ItemClassD = 12;

            /// <summary>
            /// Index for Tax Code
            /// </summary>
            public const int TaxRCode = 13;

            /// <summary>
            /// Index for Tax Base Amount
            /// </summary>
            public const int TBaseAmt = 14;

            /// <summary>
            /// Index for Tax Amount
            /// </summary>
            public const int TCurnTax = 15;

            /// <summary>
            /// Index for Document Amount
            /// </summary>
            public const int TotalWTax = 16;

            /// <summary>
            /// Index for Customer/Vendor Number
            /// </summary>
            public const int CustVend = 17;

            /// <summary>
            /// Index for Customer/Vendor Name
            /// </summary>
            public const int CustVendNm = 18;

            /// <summary>
            /// Index for Posting Date
            /// </summary>
            public const int PostDate = 19;

            /// <summary>
            /// Index for Description
            /// </summary>
            public const int Descriptio = 20;

            /// <summary>
            /// Index for Fiscal Year
            /// </summary>
            public const int FiscYear = 21;

            /// <summary>
            /// Index for Fiscal Period
            /// </summary>
            public const int FiscPeriod = 22;

            /// <summary>
            /// Index for Source ID
            /// </summary>
            public const int SrceApp = 23;

            #endregion
        }
    }
}