/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.TM.Models
{
    /// <summary>
    /// Contains list of GST F5 Processor Constants 
    /// </summary>
    public partial class TmGst03
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "TS0250";

        /// <summary>
        /// Contains list of Malaysia GST Tax Codes Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Form Year
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for From Period
            /// </summary>
            public const string FromPeriod = "FROMPERIOD";

            /// <summary>
            /// Property for To Year 
            /// </summary>
            public const string ToYear = "TOYEAR";

            /// <summary>
            /// Property for To Period 
            /// </summary>
            public const string ToPeriod = "TOPERIOD";

            /// <summary>
            /// Property for Box 1 - Value of Standard Rated 
            /// </summary>
            public const string Box1 = "BOX__1";

            /// <summary>
            /// Property for Box 2 - Value of Zero-Reated Supp 
            /// </summary>
            public const string Box2 = "BOX__2";

            /// <summary>
            /// Property for Box 3 - Value of Exempt Supplies
            /// </summary>
            public const string Box3 = "BOX__3";

            /// <summary>
            /// Property for Box 4 - Value of Total of [1][2][3]
            /// </summary>
            public const string Box4 = "BOX__4";

            /// <summary>
            /// Property for Box 5 - Value of Total of Taxable Purchas
            /// </summary>
            public const string Box5 = "BOX__5";

            /// <summary>
            /// Property for Box 6 - Value of Output Tax Due
            /// </summary>
            public const string Box6 = "BOX__6";

            /// <summary>
            /// Property for Box 7 - Value of Input Tax and Refunds CI 
            /// </summary>
            public const string Box7 = "BOX__7";

            /// <summary>
            /// Property for Box 8 - Value of Net Payable to IRAS 
            /// </summary>
            public const string Box8 = "BOX__8";

            /// <summary>
            /// Property for Box 9 - Value of Goods Imported
            /// </summary>
            public const string Box9 = "BOX__9";

            /// <summary>
            /// Property for Box 10 - Value of GST Refunded to Tourist 
            /// </summary>
            public const string Box10 = "BOX_10";

            /// <summary>
            /// Property for Box 11 - Value of GST Claim for Bad Debt
            /// </summary>
            public const string Box11 = "BOX_11";

            /// <summary>
            /// Property for Box 12 - Value of GST Pre-registration CI
            /// </summary>
            public const string Box12 = "BOX_12";

            /// <summary>
            /// Property for Box 13 - Value of Revenue for The Account
            /// </summary>
            public const string Box13 = "BOX_13";

            /// <summary>
            /// Property for Input Tax from Transactions
            /// </summary>
            public const string InputTax = "INPUTTAX";

            /// <summary>
            /// Property for Output Tax from Transactions 
            /// </summary>
            public const string OutputTax = "OUTPUTTAX";

            /// <summary>
            /// Property for Tax on Recovered Bad Debt 
            /// </summary>
            public const string RecoverTax = "RECOVERTAX";

            /// <summary>
            /// Property for Box 3 before Exchange Adjustment
            /// </summary>
            public const string Box3Pre = "BOX__3PRE";

            /// <summary>
            /// Property for Realized Exchange Gain/Loss(Fun 
            /// </summary>
            public const string RlGainLoss = "RLGAINLOSS";

            #endregion
        }

        /// <summary>
        /// Contains list of Malaysia GST Tax Codes Index Constants
        /// </summary>
        public class Index
        {
            #region Indexes

            /// <summary>
            /// Index for Form Year
            /// </summary>
            public const int FromYear = 1;

            /// <summary>
            /// Index for From Period
            /// </summary>
            public const int FromPeriod = 2;

            /// <summary>
            /// Index for To Year 
            /// </summary>
            public const int ToYear = 3;

            /// <summary>
            /// Index for To Period 
            /// </summary>
            public const int ToPeriod = 4;

            /// <summary>
            /// Index for Box 1 - Value of Standard Rated 
            /// </summary>
            public const int Box1 = 5;

            /// <summary>
            /// Index for Box 2 - Value of Zero-Reated Supp 
            /// </summary>
            public const int Box2 = 6;

            /// <summary>
            /// Index for Box 3 - Value of Exempt Supplies
            /// </summary>
            public const int Box3 = 7;

            /// <summary>
            /// Index for Box 4 - Value of Total of [1][2][3]
            /// </summary>
            public const int Box4 = 8;

            /// <summary>
            /// Index for Box 5 - Value of Total of Taxable Purchas
            /// </summary>
            public const int Box5 = 9;

            /// <summary>
            /// Index for Box 6 - Value of Output Tax Due
            /// </summary>
            public const int Box6 = 10;

            /// <summary>
            /// Index for Box 7 - Value of Input Tax and Refunds CI 
            /// </summary>
            public const int Box7 = 11;

            /// <summary>
            /// Index for Box 8 - Value of Net Payable to IRAS 
            /// </summary>
            public const int Box8 = 12;

            /// <summary>
            /// Index for Box 9 - Value of Goods Imported
            /// </summary>
            public const int Box9 = 13;

            /// <summary>
            /// Index for Box 10 - Value of GST Refunded to Tourist 
            /// </summary>
            public const int Box10 = 14;

            /// <summary>
            /// Index for Box 11 - Value of GST Claim for Bad Debt
            /// </summary>
            public const int Box11 = 15;

            /// <summary>
            /// Index for Box 12 - Value of GST Pre-registration CI
            /// </summary>
            public const int Box12 = 16;

            /// <summary>
            /// Index for Box 13 - Value of Revenue for The Account
            /// </summary>
            public const int Box13 = 17;

            /// <summary>
            /// Index for Input Tax from Transactions
            /// </summary>
            public const int InputTax = 18;

            /// <summary>
            /// Index for Output Tax from Transactions 
            /// </summary>
            public const int OutputTax = 19;

            /// <summary>
            /// Index for Tax on Recovered Bad Debt 
            /// </summary>
            public const int RecoverTax = 20;

            /// <summary>
            /// Index for Box 3 before Exchange Adjustment 
            /// </summary>
            public const int Box3Pre = 21;

            /// <summary>
            /// Index for Realized Exchange Gain/Loss(Fun 
            /// </summary>
            public const int RlGainLoss = 22;

            #endregion
        }
    }
}