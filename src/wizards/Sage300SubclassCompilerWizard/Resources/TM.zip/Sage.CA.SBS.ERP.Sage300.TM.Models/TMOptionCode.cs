// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.TM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.TM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TM.Models
{
    /// <summary>
    /// Partial class for TMOptionCode
    /// </summary>
    public partial class TMOptionCode : ModelBase
    {
        /// <summary>
        /// Gets or sets OrganisationId
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrganisationId", ResourceType = typeof (TMOptionCodeResx))]
        public string OrganisationId { get; set; }

        /// <summary>
        /// Gets or sets Option
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(100, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Option", ResourceType = typeof (TMOptionCodeResx))]
        public string Option { get; set; }

        /// <summary>
        /// Gets or sets Value
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Value", ResourceType = typeof (TMOptionCodeResx))]
        public DateTime Value { get; set; }

        /// <summary>
        /// Gets or sets DateLastModified
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastModified", ResourceType = typeof (TMOptionCodeResx))]
        public DateTime DateLastModified { get; set; }

        /// <summary>
        /// Gets or sets Required
        /// </summary>
        [Display(Name = "Required", ResourceType = typeof (TMOptionCodeResx))]
        public int Required { get; set; }

        #region UI Strings

        #endregion
    }
}