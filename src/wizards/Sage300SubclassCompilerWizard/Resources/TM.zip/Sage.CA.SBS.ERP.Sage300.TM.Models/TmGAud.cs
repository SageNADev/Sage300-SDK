/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.TM.Models.Enums.Gst03Audit;
using Sage.CA.SBS.ERP.Sage300.TM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TM.Models
{
    /// <summary>
    /// Class GST 03 Audit.
    /// </summary>
    public partial class TmGAud : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the GST 03 Audit
        /// </summary>
        public TmGAud()
        {
        }

        /// <summary>
        /// Gets or set GST Report Field 
        /// </summary>
        public string GstRptFld {get; set;}

        /// <summary>
        /// Gets or set Detail Sequence
        /// </summary>
        public decimal DetailSeq {get; set;}

        /// <summary>
        /// Gets or set Uniquifier
        /// </summary>
        public decimal Unique {get; set;}

        /// <summary>
        /// Gets or set Document Date
        /// </summary>
        [Display(Name = "DocDate", ResourceType = typeof(Gst03AuditResx))]
        public DateTime DocDate {get; set;}

        /// <summary>
        /// Gets or set Docment Number
        /// </summary>
        [Display(Name = "DocNumber", ResourceType = typeof(Gst03AuditResx))]
        public string DocNumber {get; set;}

        /// <summary>
        /// Gets or set Realized Gain/Loss Reference
        /// </summary>
        [Display(Name = "RlGaLoXRef", ResourceType = typeof(Gst03AuditResx))]
        public string RlGaLoXRef {get; set;}

        /// <summary>
        /// Gets or set Tax Authority
        /// </summary>
        [Display(Name = "Authority", ResourceType = typeof(Gst03AuditResx))]
        public string Authority {get; set;}

        /// <summary>
        /// Gets or set Transaction Type
        /// </summary>
        [Display(Name = "TType", ResourceType = typeof(Gst03AuditResx))]
        public string TType {get; set;}

        /// <summary>
        /// Gets or set Customer/Vendor Class Description
        /// </summary>
        [Display(Name = "BuyerClass", ResourceType = typeof(Gst03AuditResx))]
        public string BuyerClasD {get; set;}

        /// <summary>
        /// Gets or set Item Class Description
        /// </summary>
        [Display(Name = "ItemClass", ResourceType = typeof(Gst03AuditResx))]
        public string ItemClassD {get; set;}

        /// <summary>
        /// Gets or set Tax Code
        /// </summary>
        [Display(Name = "TaxRCode", ResourceType = typeof(Gst03AuditResx))]
        public string TaxRCode {get; set;}

        /// <summary>
        /// Gets or set Tax Base Amount
        /// </summary>
        [Display(Name = "TBaseAmt", ResourceType = typeof(Gst03AuditResx))]
        public decimal TBaseAmt {get; set;}

        /// <summary>
        /// Gets or set Tax Amount
        /// </summary>
        [Display(Name = "TCurnTax", ResourceType = typeof(Gst03AuditResx))]
        public decimal TCurnTax {get; set;}

        /// <summary>
        /// Gets or set Documnet Amount
        /// </summary>
        [Display(Name = "TotalWTax", ResourceType = typeof(Gst03AuditResx))]
        public decimal TotalWTax {get; set;}

        /// <summary>
        /// Gets or set Customer/Vendor Number
        /// </summary>
        [Display(Name = "CustVend", ResourceType = typeof(Gst03AuditResx))]
        public string CustVend {get; set;}

        /// <summary>Customer/Vendor Name
        /// Gets or set 
        /// </summary>
        [Display(Name = "CustVendNm", ResourceType = typeof(Gst03AuditResx))]
        public string CustVendNm {get; set;}

        /// <summary>
        /// Gets or set Posting Date 
        /// </summary>
        [Display(Name = "PostDate", ResourceType = typeof(Gst03AuditResx))]
        public DateTime PostDate {get; set;}

        /// <summary>
        /// Gets or set Description
        /// </summary>
        [Display(Name = "Descriptio", ResourceType = typeof(Gst03AuditResx))]
        public string Descriptio {get; set;}

        /// <summary>
        /// Gets or set Fiscal Year
        /// </summary>
        [Display(Name = "FiscYear", ResourceType = typeof(Gst03AuditResx))]
        public string FiscYear {get; set;}

        /// <summary>
        /// Gets or set Fiscal Period
        /// </summary>
        [Display(Name = "FiscPeriod", ResourceType = typeof(Gst03AuditResx))]
        public int FiscPeriod {get; set;}

        /// <summary>
        /// Gets or set Source ID
        /// </summary>
        [Display(Name = "SrceApp", ResourceType = typeof(Gst03AuditResx))]
        public string SrceApp {get; set;}

    }
}