/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.TM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TM.Models
{
    /// <summary>
    /// Class GST 03 Processor.
    /// </summary>
    public partial class TmGst03 : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the GST F5
        /// </summary>
        public TmGst03()
        {
        }

        /// <summary>
        /// Gets or set Form Year
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromYear { get; set; } = "2020";

        /// <summary>
        /// Gets or set From Period
        /// </summary>
        [MaxLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FromPeriod { get; set; } = 9;

        /// <summary>
        /// Gets or set To Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToYear { get; set; } = "2020";

        /// <summary>
        /// Gets or set To Period 
        /// </summary>
        [MaxLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int ToPeriod { get; set; } = 9;

        /// <summary>
        /// Gets or set Box 1 - Value of Standard Rated 
        /// </summary>
        [Display(Name = nameof(Gst03Resx.Box1), ResourceType = typeof(Gst03Resx))]
        public decimal Box1 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 2 - Value of Zero-Reated Supp 
        /// </summary>
        [Display(Name = nameof(Gst03Resx.Box2), ResourceType = typeof(Gst03Resx))]
        public decimal Box2 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 3 - Value of Exempt Supplies
        /// </summary>
        [Display(Name = "Box3", ResourceType = typeof(Gst03Resx))]
        public decimal Box3 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 4 - Value of Total of [1][2][3]
        /// </summary>
        [Display(Name = "Box4", ResourceType = typeof(Gst03Resx))]
        public decimal Box4 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 5 - Value of Total of Taxable Purchas
        /// </summary>
        [Display(Name = "Box5", ResourceType = typeof(Gst03Resx))]
        public decimal Box5 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 6 - Value of Output Tax Due
        /// </summary>
        [Display(Name = "Box6", ResourceType = typeof(Gst03Resx))]
        public decimal Box6 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 7 - Value of Input Tax and Refunds CI 
        /// </summary>
        [Display(Name = "Box7", ResourceType = typeof(Gst03Resx))]
        public decimal Box7 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 8 - Value of Net Payable to IRAS 
        /// </summary>
        [Display(Name = "Box8", ResourceType = typeof(Gst03Resx))]
        public decimal Box8 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 9 - Value of Goods Imported
        /// </summary>
        [Display(Name = "Box9", ResourceType = typeof(Gst03Resx))]
        public decimal Box9 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 10 - Value of GST Refunded to Tourist 
        /// </summary>
        [Display(Name = "Box10", ResourceType = typeof(Gst03Resx))]
        public decimal Box10 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 11 - Value of GST Claim for Bad Debt
        /// </summary>
        [Display(Name = "Box11", ResourceType = typeof(Gst03Resx))]
        public decimal Box11 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 12 - Value of GST Pre-registration CI
        /// </summary>
        [Display(Name = "Box12", ResourceType = typeof(Gst03Resx))]
        public decimal Box12 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 13 - Value of Revenue for The Account
        /// </summary>
        [Display(Name = "Box13", ResourceType = typeof(Gst03Resx))]
        public decimal Box13 { get; set; } = 0;

        /// <summary>
        /// Gets or set Input Tax from Transactions
        /// </summary>
        [Display(Name = "InputTax", ResourceType = typeof(Gst03Resx))]
        public decimal InputTax { get; set; } = 0;

        /// <summary>
        /// Gets or set Output Tax from Transactions 
        /// </summary>
        [Display(Name = "OutputTax", ResourceType = typeof(Gst03Resx))]
        public decimal OutputTax { get; set; } = 0;

        /// <summary>
        /// Gets or set Tax on Recovered Bad Debt 
        /// </summary>
        [Display(Name = "RecoverTax", ResourceType = typeof(Gst03Resx))]
        public decimal RecoverTax { get; set; } = 0;

        /// <summary>
        /// Gets or set Tax on Recovered Bad Debt 
        /// </summary>
        public decimal Box3Pre = 0;

        /// <summary>
        /// Gets or set Realized Exchange Gain/Loss(Fun 
        /// </summary>
        public decimal RlGainLoss = 0;

    }
}