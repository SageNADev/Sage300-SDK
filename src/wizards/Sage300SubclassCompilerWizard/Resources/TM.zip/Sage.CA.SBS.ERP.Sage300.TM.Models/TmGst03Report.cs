/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.TM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TM.Models
{
    /// <summary>
    /// Class GST 03 Report.
    /// </summary>
    public partial class TmGst03Report : ReportBase
    {
        /// <summary>
        /// Initializes a new instance of the GST F5
        /// </summary>
        public TmGst03Report()
        {
        }

        /// <summary>
        /// Gets or set Tax Number
        /// </summary>
        public string TaxNumber { get; set; }

        /// <summary>
        /// Gets or set Legal Name
        /// </summary>
        public string LegalName { get; set; }

        /// <summary>
        /// Gets or set Accpac User Id
        /// </summary>
        public string AccpacUserId { get; set; }

        /// <summary>
        /// Get or set Business Registration Number
        /// </summary>
        public string BusRegNo { get; set; }
        /// <summary>
        /// Gets or set Form Year
        /// </summary>
        public string FromYear { get; set; } = "2020";

        /// <summary>
        /// Gets or set From Period
        /// </summary>
        public string FromPeriod { get; set; }

        /// <summary>
        /// Gets or set To Year 
        /// </summary>
        public string ToYear { get; set; } = "2020";

        /// <summary>
        /// Gets or set To Period 
        /// </summary>
        public string ToPeriod { get; set; }

        /// <summary>
        /// Gets or set Box 1 - Value of Standard Rated 
        /// </summary>
        public decimal Box1 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 2 - Value of Zero-Reated Supp 
        /// </summary>
        public decimal Box2 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 3 - Value of Exempt Supplies
        /// </summary>
        public decimal Box3 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 4 - Value of Total of [1][2][3]
        /// </summary>
        public decimal Box4 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 5 - Value of Total of Taxable Purchas
        /// </summary>
        public decimal Box5 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 6 - Value of Output Tax Due
        /// </summary>
        public decimal Box6 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 7 - Value of Input Tax and Refunds CI 
        /// </summary>
        public decimal Box7 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 8 - Value of Net Payable to IRAS 
        /// </summary>
        public decimal Box8 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 9 - Value of Goods Imported
        /// </summary>
        public decimal Box9 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 10 - Value of GST Refunded to Tourist 
        /// </summary>
        public decimal Box10 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 11 - Value of GST Claim for Bad Debt
        /// </summary>
        public decimal Box11 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 12 - Value of GST Pre-registration CI
        /// </summary>
        public decimal Box12 { get; set; } = 0;

        /// <summary>
        /// Gets or set Box 13 - Value of Revenue for The Account
        /// </summary>
        public decimal Box13 { get; set; } = 0;
    }
}