﻿// /* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TM.Resources;

namespace Sage.CA.SBS.ERP.Sage300.TM.Models.Enums.Gst03Audit
{
    /// <summary>
    /// Enum Transaction Type
    /// </summary>
    public enum TransactionType
    {
        /// <summary>
        /// For Exchange
        /// </summary>
        [EnumValue("Exchange", typeof(EnumerationsResx))]
        Exchange = 0,

        /// <summary>
        /// For Sales
        /// </summary>
        [EnumValue("Sales", typeof(EnumerationsResx))]
        Sales = 1,

        /// <summary>
        /// For Purchase
        /// </summary>
        [EnumValue("Purchase", typeof(EnumerationsResx))]
        Purchase = 2
    }
}