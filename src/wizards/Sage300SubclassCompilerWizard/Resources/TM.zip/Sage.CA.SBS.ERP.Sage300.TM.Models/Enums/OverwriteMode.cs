﻿// /* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TM.Resources;

namespace Sage.CA.SBS.ERP.Sage300.TM.Models.Enums
{
    /// <summary>
    /// Enum Transaction Type
    /// </summary>
    public enum OverwriteMode
    {
        /// <summary>
        /// For Halt When Filenames Exists
        /// </summary>
        HaltOverwrite,

        /// <summary>
        /// For Force File Overwrite
        /// </summary>
        ForceOverwrite
    }
}