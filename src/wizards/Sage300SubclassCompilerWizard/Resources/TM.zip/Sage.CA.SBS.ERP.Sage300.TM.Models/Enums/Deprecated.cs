﻿// /* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.TM.Resources;

namespace Sage.CA.SBS.ERP.Sage300.TM.Models.Enums
{
    /// <summary>
    /// Enum Deprecated
    /// </summary>
    public enum Deprecated
    {
        /// <summary>
        /// For Sales
        /// </summary>
        [EnumValue("Yes", typeof(EnumerationsResx))]
        No = 0,

        /// <summary>
        /// For Purchase
        /// </summary>
        [EnumValue("Yes", typeof(EnumerationsResx))]
        Yes = 1
    }
}