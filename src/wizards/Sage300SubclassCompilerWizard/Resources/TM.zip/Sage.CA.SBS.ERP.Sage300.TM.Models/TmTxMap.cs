/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.TM.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.TM.Models
{
    /// <summary>
    /// Class Malaysia GST Tax Codes.
    /// </summary>
    public partial class TmTxMap : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of Malaysia GST Tax Codes
        /// </summary>
        public TmTxMap()
        {
        }

        /// <summary>
        /// Gets or sets Effective Date 
        /// </summary>
        [Key]
        public DateTime EffDate { get; set; }

        /// <summary>
        /// Gets or sets Tax Code 
        /// </summary>
        [Key]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TaxRCode { get; set; }

        /// <summary>
        /// Gets or sets Transaction Type 
        /// </summary>
        [Key]
        public TransactionType TType { get; set; } = TransactionType.Sales;

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Desc { get; set; }

        /// <summary>
        /// Gets or sets Remark 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Remark { get; set; }

        /// <summary>
        /// Gets or sets Deprecated 
        /// </summary>
        public Deprecated Deprecated { get; set; } = Deprecated.No;

        /// <summary>
        /// Gets or sets Replacement 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ReplacedBy { get; set; }

        /// <summary>
        /// Gets or sets Field1 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Field1 { get; set; }

        /// <summary>
        /// Gets or sets Field2 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Field2 { get; set; }

        /// <summary>
        /// Gets or sets Field3 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Field3 { get; set; }

        /// <summary>
        /// Gets or sets Field4 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Field4 { get; set; }

        /// <summary>
        /// Gets or sets Field5 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Field5 { get; set; }

        public string TTypeString
        {
            get { return EnumUtility.GetStringValue(TType); }
        }

        public string DeprecatedString
        {
            get { return EnumUtility.GetStringValue(Deprecated); }
        }
    }
}