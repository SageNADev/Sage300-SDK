// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.MT.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.MT.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.MT.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.MT.Models
{
    /// <summary>
    /// Partial class for OptionalFieldHeader
    /// </summary>
    public partial class OptionalFieldHeader : ModelBase
    {
        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof (OptionalFieldHeaderResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.MT.Models.Enums.Location Location { get; set; }

        /// <summary>
        /// Gets or sets NumberOfValues
        /// </summary>
        [Display(Name = "NumberOfValues", ResourceType = typeof (OptionalFieldHeaderResx))]
        [ViewField(Name = Fields.NumberOfValues, Id = Index.NumberOfValues, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfValues { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Location string value
        /// </summary>
        public string LocationString
        {
         get { return EnumUtility.GetStringValue(Location); }
        }

        /// <summary>
        /// List of Optional Details
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<OptionalFieldDetail> OptionalFieldDetails { get; set; } = new EnumerableResponse<OptionalFieldDetail>();


        #endregion
    }
}
