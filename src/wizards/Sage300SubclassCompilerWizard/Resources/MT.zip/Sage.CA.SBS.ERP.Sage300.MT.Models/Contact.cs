// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.MT.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.MT.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.MT.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.MT.Models
{
    /// <summary>
    /// Partial class for Contact
    /// </summary>
    public partial class Contact : ModelBase
    {
        /// <summary>
        /// Gets or sets ContactCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactCode", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.ContactCode, Id = Index.ContactCode, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ContactCode { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.MT.Models.Enums.Status Status { get; set; } = Status.Active;

        /// <summary>
        /// Gets or sets DateLastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastMaintained", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Salutation
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salutation", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.Salutation, Id = Index.Salutation, FieldType = EntityFieldType.Char, Size = 10)]
        public string Salutation { get; set; }

        /// <summary>
        /// Gets or sets FirstName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FirstName", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.FirstName, Id = Index.FirstName, FieldType = EntityFieldType.Char, Size = 60)]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets MiddleName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiddleName", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.MiddleName, Id = Index.MiddleName, FieldType = EntityFieldType.Char, Size = 60)]
        public string MiddleName { get; set; }

        /// <summary>
        /// Gets or sets LastName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastName", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.LastName, Id = Index.LastName, FieldType = EntityFieldType.Char, Size = 60)]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets Title
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Title", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.Title, Id = Index.Title, FieldType = EntityFieldType.Char, Size = 60)]
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.StateProvince, Id = Index.StateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateProvince { get; set; }

        /// <summary>
        /// Gets or sets ZipPostalCode
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.ZipPostalCode, Id = Index.ZipPostalCode, FieldType = EntityFieldType.Char, Size = 30)]
        public string ZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets ConsentsToReceiveEmail
        /// </summary>
        [Display(Name = "ConsentsToReceiveEmail", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.ConsentsToReceiveEmail, Id = Index.ConsentsToReceiveEmail, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.MT.Models.Enums.ConsentsToReceiveEmail ConsentsToReceiveEmail { get; set; } =
            ConsentsToReceiveEmail.No;

        /// <summary>
        /// Gets or sets PhoneNumber1
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PhoneNumber1", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.PhoneNumber1, Id = Index.PhoneNumber1, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber1 { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber2
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PhoneNumber2", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.PhoneNumber2, Id = Index.PhoneNumber2, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber2 { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber3
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PhoneNumber3", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.PhoneNumber3, Id = Index.PhoneNumber3, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber3 { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FaxNumber", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 255)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets Comment1
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment1", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.Comment1, Id = Index.Comment1, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment1 { get; set; }

        /// <summary>
        /// Gets or sets Comment2
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment2", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.Comment2, Id = Index.Comment2, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment2 { get; set; }

        /// <summary>
        /// Gets or sets WebSite
        /// </summary>
        [StringLength(100, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WebSite", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.WebSite, Id = Index.WebSite, FieldType = EntityFieldType.Char, Size = 100)]
        public string WebSite { get; set; }

        /// <summary>
        /// Gets or sets CrmPersonId
        /// </summary>
        [ViewField(Name = Fields.CrmPersonId, Id = Index.CrmPersonId, FieldType = EntityFieldType.Long, Size = 4)]
        public int CrmPersonId { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets DisplayName
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DisplayName", ResourceType = typeof(ContactResx))]
        [ViewField(Name = Fields.DisplayName, Id = Index.DisplayName, FieldType = EntityFieldType.Char, Size = 255)]
        public string DisplayName { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets ConsentsToReceiveEmail string value
        /// </summary>
        public string ConsentsToReceiveEmailString
        {
            get { return EnumUtility.GetStringValue(ConsentsToReceiveEmail); }
        }

        #endregion
    }
}
