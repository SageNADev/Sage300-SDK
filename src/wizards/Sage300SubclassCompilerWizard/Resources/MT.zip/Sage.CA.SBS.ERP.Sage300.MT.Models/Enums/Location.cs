// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.MT.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.MT.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.MT.Models.Enums
{
    /// <summary>
    /// Enum for Location
    /// </summary>
    public enum Location
    {
        /// <summary>
        /// Gets or sets Contacts
        /// </summary>
        [EnumValue("Contacts", typeof(OptionalFieldDetailsResx))]
        Contacts = 0,
    }
}