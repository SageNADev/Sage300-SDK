// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.MT.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.MT.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.MT.Models.Enums
{
    /// <summary>
    /// Enum for ValueSet
    /// </summary>
    public enum ValueSet
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>
        [EnumValue("No", typeof(ContactOptionalFieldValueResx))]
        No = 0,
        /// <summary>
        /// Gets or sets Yes
        /// </summary>
        [EnumValue("Yes", typeof(ContactOptionalFieldValueResx))]
        Yes = 1,
        /// <summary>
        /// Gets or sets NotApplicable
        /// </summary>
        [EnumValue("NotApplicable", typeof(ContactOptionalFieldValueResx))]
        NotApplicable = 99
    }
}