// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.MT.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.MT.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.MT.Models.Enums
{
    /// <summary>
    /// Enum for Status
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// Gets or sets Inactive
        /// </summary>
        [EnumValue("Inactive", typeof(ContactResx))]
        Inactive = 0,
        /// <summary>
        /// Gets or sets Active
        /// </summary>
        [EnumValue("Active", typeof(ContactResx))]
        Active = 1
    }
}