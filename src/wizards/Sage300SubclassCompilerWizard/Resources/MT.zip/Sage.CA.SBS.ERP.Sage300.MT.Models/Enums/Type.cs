// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.MT.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.MT.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.MT.Models.Enums
{
    /// <summary>
    /// Enum for Type
    /// </summary>
    public enum Type
    {
        /// <summary>
        /// Gets or sets Text
        /// </summary>
        [EnumValue("Text", typeof(ContactOptionalFieldValueResx))]
        Text = 1,
        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [EnumValue("Amount", typeof(ContactOptionalFieldValueResx))]
        Amount = 100,
        /// <summary>
        /// Gets or sets Number
        /// </summary>
        [EnumValue("Number", typeof(ContactOptionalFieldValueResx))]
        Number = 6,
        /// <summary>
        /// Gets or sets Integer
        /// </summary>
        [EnumValue("Integer", typeof(ContactOptionalFieldValueResx))]
        Integer = 8,
        /// <summary>
        /// Gets or sets YesNo
        /// </summary>
        [EnumValue("YesNo", typeof(ContactOptionalFieldValueResx))]
        YesNo = 9,
        /// <summary>
        /// Gets or sets Date
        /// </summary>
        [EnumValue("Date", typeof(ContactOptionalFieldValueResx))]
        Date = 3,
        /// <summary>
        /// Gets or sets Time
        /// </summary>
        [EnumValue("Time", typeof(ContactOptionalFieldValueResx))]
        Time = 4
    }
}