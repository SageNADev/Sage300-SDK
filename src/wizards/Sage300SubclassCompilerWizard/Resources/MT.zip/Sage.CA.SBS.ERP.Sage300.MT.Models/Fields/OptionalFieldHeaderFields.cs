// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.MT.Models
{
    /// <summary>
    /// Contains list of OptionalFieldHeader Constants
    /// </summary>
    public partial class OptionalFieldHeader
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "MT0410";


        #region Properties

        /// <summary>
        /// Contains list of OptionalFieldHeader Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for NumberOfValues
            /// </summary>
            public const string NumberOfValues = "VALUES";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of OptionalFieldHeader Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 1;

            /// <summary>
            /// Property Indexer for NumberOfValues
            /// </summary>
            public const int NumberOfValues = 2;


        }

        #endregion

    }
}