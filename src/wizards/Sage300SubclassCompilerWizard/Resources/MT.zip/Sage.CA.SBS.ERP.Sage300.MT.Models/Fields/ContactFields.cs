// Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.MT.Models
{
    /// <summary>
    /// Contains list of Contact Constants
    /// </summary>
    public partial class Contact
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "MT0100";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of Contact Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ContactCode
            /// </summary>
            public const string ContactCode = "IDCONTACT";

            /// <summary>
            /// Property for InactiveDate
            /// </summary>
            public const string InactiveDate = "DATEINAC";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "SWACTV";

            /// <summary>
            /// Property for DateLastMaintained
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for Salutation
            /// </summary>
            public const string Salutation = "SALUTATION";

            /// <summary>
            /// Property for FirstName
            /// </summary>
            public const string FirstName = "FIRSTNAME";

            /// <summary>
            /// Property for MiddleName
            /// </summary>
            public const string MiddleName = "MIDDLENAME";

            /// <summary>
            /// Property for LastName
            /// </summary>
            public const string LastName = "LASTNAME";

            /// <summary>
            /// Property for Title
            /// </summary>
            public const string Title = "TITLE";

            /// <summary>
            /// Property for AddressLine1
            /// </summary>
            public const string AddressLine1 = "TEXTSTRE1";

            /// <summary>
            /// Property for AddressLine2
            /// </summary>
            public const string AddressLine2 = "TEXTSTRE2";

            /// <summary>
            /// Property for AddressLine3
            /// </summary>
            public const string AddressLine3 = "TEXTSTRE3";

            /// <summary>
            /// Property for AddressLine4
            /// </summary>
            public const string AddressLine4 = "TEXTSTRE4";

            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "NAMECITY";

            /// <summary>
            /// Property for StateProvince
            /// </summary>
            public const string StateProvince = "CODESTTE";

            /// <summary>
            /// Property for ZipPostalCode
            /// </summary>
            public const string ZipPostalCode = "CODEPSTL";

            /// <summary>
            /// Property for Country
            /// </summary>
            public const string Country = "CODECTRY";

            /// <summary>
            /// Property for ConsentsToReceiveEmail
            /// </summary>
            public const string ConsentsToReceiveEmail = "SWOKEMAIL";

            /// <summary>
            /// Property for PhoneNumber1
            /// </summary>
            public const string PhoneNumber1 = "TEXTPHON1";

            /// <summary>
            /// Property for PhoneNumber2
            /// </summary>
            public const string PhoneNumber2 = "TEXTPHON2";

            /// <summary>
            /// Property for PhoneNumber3
            /// </summary>
            public const string PhoneNumber3 = "TEXTPHON3";

            /// <summary>
            /// Property for FaxNumber
            /// </summary>
            public const string FaxNumber = "TEXTFAX";

            /// <summary>
            /// Property for Email
            /// </summary>
            public const string Email = "EMAIL";

            /// <summary>
            /// Property for Comment1
            /// </summary>
            public const string Comment1 = "COMMENT1";

            /// <summary>
            /// Property for Comment2
            /// </summary>
            public const string Comment2 = "COMMENT2";

            /// <summary>
            /// Property for WebSite
            /// </summary>
            public const string WebSite = "WEBSITE";

            /// <summary>
            /// Property for CrmPersonId
            /// </summary>
            public const string CrmPersonId = "CRMPRSNID";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for DisplayName
            /// </summary>
            public const string DisplayName = "DISPLAYNAM";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Contact Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ContactCode
            /// </summary>
            public const int ContactCode = 1;

            /// <summary>
            /// Property Indexer for InactiveDate
            /// </summary>
            public const int InactiveDate = 2;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 3;

            /// <summary>
            /// Property Indexer for DateLastMaintained
            /// </summary>
            public const int DateLastMaintained = 4;

            /// <summary>
            /// Property Indexer for Salutation
            /// </summary>
            public const int Salutation = 5;

            /// <summary>
            /// Property Indexer for FirstName
            /// </summary>
            public const int FirstName = 6;

            /// <summary>
            /// Property Indexer for MiddleName
            /// </summary>
            public const int MiddleName = 7;

            /// <summary>
            /// Property Indexer for LastName
            /// </summary>
            public const int LastName = 8;

            /// <summary>
            /// Property Indexer for Title
            /// </summary>
            public const int Title = 9;

            /// <summary>
            /// Property Indexer for AddressLine1
            /// </summary>
            public const int AddressLine1 = 10;

            /// <summary>
            /// Property Indexer for AddressLine2
            /// </summary>
            public const int AddressLine2 = 11;

            /// <summary>
            /// Property Indexer for AddressLine3
            /// </summary>
            public const int AddressLine3 = 12;

            /// <summary>
            /// Property Indexer for AddressLine4
            /// </summary>
            public const int AddressLine4 = 13;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 14;

            /// <summary>
            /// Property Indexer for StateProvince
            /// </summary>
            public const int StateProvince = 15;

            /// <summary>
            /// Property Indexer for ZipPostalCode
            /// </summary>
            public const int ZipPostalCode = 16;

            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 17;

            /// <summary>
            /// Property Indexer for ConsentsToReceiveEmail
            /// </summary>
            public const int ConsentsToReceiveEmail = 18;

            /// <summary>
            /// Property Indexer for PhoneNumber1
            /// </summary>
            public const int PhoneNumber1 = 19;

            /// <summary>
            /// Property Indexer for PhoneNumber2
            /// </summary>
            public const int PhoneNumber2 = 20;

            /// <summary>
            /// Property Indexer for PhoneNumber3
            /// </summary>
            public const int PhoneNumber3 = 21;

            /// <summary>
            /// Property Indexer for FaxNumber
            /// </summary>
            public const int FaxNumber = 22;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 23;

            /// <summary>
            /// Property Indexer for Comment1
            /// </summary>
            public const int Comment1 = 24;

            /// <summary>
            /// Property Indexer for Comment2
            /// </summary>
            public const int Comment2 = 25;

            /// <summary>
            /// Property Indexer for WebSite
            /// </summary>
            public const int WebSite = 26;

            /// <summary>
            /// Property Indexer for CrmPersonId
            /// </summary>
            public const int CrmPersonId = 27;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 28;

            /// <summary>
            /// Property Indexer for DisplayName
            /// </summary>
            public const int DisplayName = 150;


        }

        #endregion

    }
}