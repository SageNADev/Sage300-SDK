// Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.MT.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.MT.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.MT.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.MT.Models
{
    /// <summary>
    /// Partial class for OptionalFieldDetail
    /// </summary>
    public partial class OptionalFieldDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.MT.Models.Enums.Location Location { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets DefaultValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValue", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.DefaultValue, Id = Index.DefaultValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultValue { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public OptionalFieldType Type { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.MT.Models.Enums.AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.MT.Models.Enums.Validate Validate { get; set; }

        /// <summary>
        /// Gets or sets AutoInsert
        /// </summary>
        [Display(Name = "AutoInsert", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.AutoInsert, Id = Index.AutoInsert, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.MT.Models.Enums.AutoInsert AutoInsert { get; set; }

        /// <summary>
        /// Gets or sets Required
        /// </summary>
        [Display(Name = "Required", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.Required, Id = Index.Required, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.MT.Models.Enums.Required Required { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.MT.Models.Enums.ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets TypedDefaultValueFieldIndex
        /// </summary>
        [Display(Name = "TypedDefaultValueFieldIndex", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.TypedDefaultValueFieldIndex, Id = Index.TypedDefaultValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public int TypedDefaultValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets DefaultTextValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultTextValue", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.DefaultTextValue, Id = Index.DefaultTextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultTextValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultAmountValue
        /// </summary>
        [Display(Name = "DefaultMoneyValue", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.DefaultAmountValue, Id = Index.DefaultAmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DefaultAmountValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultNumberValue
        /// </summary>
        [Display(Name = "DefaultNumberValue", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.DefaultNumberValue, Id = Index.DefaultNumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DefaultNumberValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultIntegerValue
        /// </summary>
        [Display(Name = "DefaultIntegerValue", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.DefaultIntegerValue, Id = Index.DefaultIntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public int DefaultIntegerValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultYesNoValue
        /// </summary>
        [Display(Name = "DefaultYesNoValue", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.DefaultYesNoValue, Id = Index.DefaultYesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.MT.Models.Enums.DefaultYesNoValue DefaultYesNoValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultDateValue
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultDateValue", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.DefaultDateValue, Id = Index.DefaultDateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public string DefaultDateValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultTimeValue
        /// </summary>
        [Display(Name = "DefaultTimeValue", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.DefaultTimeValue, Id = Index.DefaultTimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime DefaultTimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultValueDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValueDescription", ResourceType = typeof (OptionalFieldDetailsResx))]
        [ViewField(Name = Fields.DefaultValueDescription, Id = Index.DefaultValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultValueDescription { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Location string value
        /// </summary>
        [IgnoreExportImport]
        public string LocationString
        {
         get { return EnumUtility.GetStringValue(Location); }
        }

        /// <summary>
        /// Gets Type string value
        /// </summary>
        [IgnoreExportImport]
        public string TypeString
        {
         get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets AllowBlank string value
        /// </summary>
        [IgnoreExportImport]
        public string AllowBlankString
        {
         get { return EnumUtility.GetStringValue(AllowBlank); }
        }

        /// <summary>
        /// Gets Validate string value
        /// </summary>
        [IgnoreExportImport]
        public string ValidateString
        {
         get { return EnumUtility.GetStringValue(Validate); }
        }

        /// <summary>
        /// Gets AutoInsert string value
        /// </summary>
        [IgnoreExportImport]
        public string AutoInsertString
        {
         get { return EnumUtility.GetStringValue(AutoInsert); }
        }

        /// <summary>
        /// Gets Required string value
        /// </summary>
        [IgnoreExportImport]
        public string RequiredString
        {
         get { return EnumUtility.GetStringValue(Required); }
        }

        /// <summary>
        /// Gets ValueSet string value
        /// </summary>
        [IgnoreExportImport]
        public string ValueSetString
        {
         get { return EnumUtility.GetStringValue(ValueSet); }
        }

        /// <summary>
        /// Gets DefaultYesNoValue string value
        /// </summary>
        [IgnoreExportImport]
        public string DefaultYesNoValueString
        {
         get { return EnumUtility.GetStringValue(DefaultYesNoValue); }
        }

        #endregion

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number.</value>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }

        
        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFields DefaultOptionFieldValue { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFieldsValue DefaultOptionField { get; set; }

    }
}
