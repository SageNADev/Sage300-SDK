// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CompanyOption
    /// </summary>
    public partial class CompanyOption : ModelBase
    {
        /// <summary>
        /// Gets or sets OptionRecordID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionRecordID", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.OptionRecordID, Id = Index.OptionRecordID, FieldType = EntityFieldType.Char, Size = 4, Mask = "%-4N")]
        public string OptionRecordID { get; set; }

        /// <summary>
        /// Gets or sets PayrollCountryCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayrollCountryCode", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.PayrollCountryCode, Id = Index.PayrollCountryCode, FieldType = EntityFieldType.Char, Size = 3)]
        public string PayrollCountryCode { get; set; }

        /// <summary>
        /// Gets or sets ContactPersonsName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactPersonsName", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.ContactPersonsName, Id = Index.ContactPersonsName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactPersonsName { get; set; }

        /// <summary>
        /// Gets or sets ContactsPhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactsPhoneNumber", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.ContactsPhoneNumber, Id = Index.ContactsPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets ContactsFaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactsFaxNumber", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.ContactsFaxNumber, Id = Index.ContactsFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets PrintZeroNetChecks
        /// </summary>
        [Display(Name = "PrintZeroNetChecks", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.PrintZeroNetChecks, Id = Index.PrintZeroNetChecks, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PrintZeroNetChecks { get; set; }

        /// <summary>
        /// Gets or sets MinimumWage
        /// </summary>
        [Display(Name = "MinimumWage", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.MinimumWage, Id = Index.MinimumWage, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MinimumWage { get; set; }

        /// <summary>
        /// Gets or sets MaximumAnnualPartTimeHours
        /// </summary>
        [Display(Name = "MaximumAnnualPartTimeHours", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.MaximumAnnualPartTimeHours, Id = Index.MaximumAnnualPartTimeHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal MaximumAnnualPartTimeHours { get; set; }

        /// <summary>
        /// Gets or sets YearsOfHistoryToKeep
        /// </summary>
        [Display(Name = "YearsOfHistoryToKeep", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.YearsOfHistoryToKeep, Id = Index.YearsOfHistoryToKeep, FieldType = EntityFieldType.Int, Size = 2)]
        public short YearsOfHistoryToKeep { get; set; }

        /// <summary>
        /// Gets or sets ExceptionForIncreasePercent
        /// </summary>
        [Display(Name = "ExceptionForIncreasePercent", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.ExceptionForIncreasePercent, Id = Index.ExceptionForIncreasePercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal ExceptionForIncreasePercent { get; set; }

        /// <summary>
        /// Gets or sets ExceptionForDollarIncrease
        /// </summary>
        [Display(Name = "ExceptionForDollarIncrease", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.ExceptionForDollarIncrease, Id = Index.ExceptionForDollarIncrease, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExceptionForDollarIncrease { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDecimalPlacesForHou
        /// </summary>
        [Display(Name = "NumberOfDecimalPlacesForHou", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.NumberOfDecimalPlacesForHou, Id = Index.NumberOfDecimalPlacesForHou, FieldType = EntityFieldType.Int, Size = 2)]
        public short NumberOfDecimalPlacesForHou { get; set; }

        /// <summary>
        /// Gets or sets TimecardFractionalHours
        /// </summary>
        [Display(Name = "TimecardFractionalHours", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.TimecardFractionalHours, Id = Index.TimecardFractionalHours, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.TimecardFractionalHours TimecardFractionalHours { get; set; }

        /// <summary>
        /// Gets or sets HoursPerPayFrequencyInDaily
        /// </summary>
        [Display(Name = "HoursPerPayFrequencyInDaily", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.HoursPerPayFrequencyInDaily, Id = Index.HoursPerPayFrequencyInDaily, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerPayFrequencyInDaily { get; set; }

        /// <summary>
        /// Gets or sets HoursPerPayFrequencyInWeekl
        /// </summary>
        [Display(Name = "HoursPerPayFrequencyInWeekl", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.HoursPerPayFrequencyInWeekl, Id = Index.HoursPerPayFrequencyInWeekl, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerPayFrequencyInWeekl { get; set; }

        /// <summary>
        /// Gets or sets HoursPerPayFrequencyInBiwee
        /// </summary>
        [Display(Name = "HoursPerPayFrequencyInBiwee", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.HoursPerPayFrequencyInBiwee, Id = Index.HoursPerPayFrequencyInBiwee, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerPayFrequencyInBiwee { get; set; }

        /// <summary>
        /// Gets or sets HoursPerPayFrequencyInSemim
        /// </summary>
        [Display(Name = "HoursPerPayFrequencyInSemim", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.HoursPerPayFrequencyInSemim, Id = Index.HoursPerPayFrequencyInSemim, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerPayFrequencyInSemim { get; set; }

        /// <summary>
        /// Gets or sets HoursPerPayFrequencyInMonth
        /// </summary>
        [Display(Name = "HoursPerPayFrequencyInMonth", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.HoursPerPayFrequencyInMonth, Id = Index.HoursPerPayFrequencyInMonth, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerPayFrequencyInMonth { get; set; }

        /// <summary>
        /// Gets or sets HoursPerPayFrequencyInQuart
        /// </summary>
        [Display(Name = "HoursPerPayFrequencyInQuart", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.HoursPerPayFrequencyInQuart, Id = Index.HoursPerPayFrequencyInQuart, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerPayFrequencyInQuart { get; set; }

        /// <summary>
        /// Gets or sets HoursPerPayFrequencyIn10Pe
        /// </summary>
        [Display(Name = "HoursPerPayFrequencyIn10Pe", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.HoursPerPayFrequencyIn10Pe, Id = Index.HoursPerPayFrequencyIn10Pe, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerPayFrequencyIn10Pe { get; set; }

        /// <summary>
        /// Gets or sets HoursPerPayFrequencyIn13Pe
        /// </summary>
        [Display(Name = "HoursPerPayFrequencyIn13Pe", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.HoursPerPayFrequencyIn13Pe, Id = Index.HoursPerPayFrequencyIn13Pe, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerPayFrequencyIn13Pe { get; set; }

        /// <summary>
        /// Gets or sets HoursPerPayFrequencyIn22Pe
        /// </summary>
        [Display(Name = "HoursPerPayFrequencyIn22Pe", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.HoursPerPayFrequencyIn22Pe, Id = Index.HoursPerPayFrequencyIn22Pe, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerPayFrequencyIn22Pe { get; set; }

        /// <summary>
        /// Gets or sets DailyPayPeriodsPerYear
        /// </summary>
        [Display(Name = "DailyPayPeriodsPerYear", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.DailyPayPeriodsPerYear, Id = Index.DailyPayPeriodsPerYear, FieldType = EntityFieldType.Int, Size = 2)]
        public short DailyPayPeriodsPerYear { get; set; }

        /// <summary>
        /// Gets or sets WeeklyPayPeriodsPerYear
        /// </summary>
        [Display(Name = "WeeklyPayPeriodsPerYear", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.WeeklyPayPeriodsPerYear, Id = Index.WeeklyPayPeriodsPerYear, FieldType = EntityFieldType.Int, Size = 2)]
        public short WeeklyPayPeriodsPerYear { get; set; }

        /// <summary>
        /// Gets or sets BiweeklyPayPeriodsPerYear
        /// </summary>
        [Display(Name = "BiweeklyPayPeriodsPerYear", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.BiweeklyPayPeriodsPerYear, Id = Index.BiweeklyPayPeriodsPerYear, FieldType = EntityFieldType.Int, Size = 2)]
        public short BiweeklyPayPeriodsPerYear { get; set; }

        /// <summary>
        /// Gets or sets CreateGLTransOrNot
        /// </summary>
        [Display(Name = "CreateGLTransOrNot", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.CreateGLTransOrNot, Id = Index.CreateGLTransOrNot, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.CreateGLTransOrNot CreateGLTransOrNot { get; set; }

        /// <summary>
        /// Gets or sets GLTransAppendToBatch
        /// </summary>
        [Display(Name = "GLTransAppendToBatch", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLTransAppendToBatch, Id = Index.GLTransAppendToBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.GLTransAppendToBatch GLTransAppendToBatch { get; set; }

        /// <summary>
        /// Gets or sets GLBatchType
        /// </summary>
        [Display(Name = "GLBatchType", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLBatchType, Id = Index.GLBatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.GLBatchType GLBatchType { get; set; }

        /// <summary>
        /// Gets or sets CheckOrPeriodEndDate
        /// </summary>
        [Display(Name = "CheckOrPeriodEndDate", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.CheckOrPeriodEndDate, Id = Index.CheckOrPeriodEndDate, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.CheckOrPeriodEndDate CheckOrPeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets SalaryAndWagesPayableAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SalaryAndWagesPayableAccount", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.SalaryAndWagesPayableAccount, Id = Index.SalaryAndWagesPayableAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string SalaryAndWagesPayableAccount { get; set; }

        /// <summary>
        /// Gets or sets SuspenseAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SuspenseAccount", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.SuspenseAccount, Id = Index.SuspenseAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string SuspenseAccount { get; set; }

        /// <summary>
        /// Gets or sets CostCenterSwitch
        /// </summary>
        [Display(Name = "CostCenterSwitch", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.CostCenterSwitch, Id = Index.CostCenterSwitch, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CostCenterSwitch { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentOne
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentOne", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSegmentOne, Id = Index.GLSegmentOne, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentOne { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentTwo
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentTwo", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSegmentTwo, Id = Index.GLSegmentTwo, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentTwo { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentThree
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentThree", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSegmentThree, Id = Index.GLSegmentThree, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentThree { get; set; }

        /// <summary>
        /// Gets or sets ActiveSegmentReplaceOption
        /// </summary>
        [Display(Name = "ActiveSegmentReplaceOption", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.ActiveSegmentReplaceOption, Id = Index.ActiveSegmentReplaceOption, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.ActiveSegmentReplaceOption ActiveSegmentReplaceOption { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentFour
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentFour", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSegmentFour, Id = Index.GLSegmentFour, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentFour { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentFive
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentFive", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSegmentFive, Id = Index.GLSegmentFive, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentFive { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentSix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentSix", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSegmentSix, Id = Index.GLSegmentSix, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentSix { get; set; }

        /// <summary>
        /// Gets or sets GLSEG1CALC
        /// </summary>
        [Display(Name = "GLSEG1CALC", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSEG1CALC, Id = Index.GLSEG1CALC, FieldType = EntityFieldType.Int, Size = 2)]
        public int GLSEG1CALC { get; set; }

        /// <summary>
        /// Gets or sets GLSEG2CALC
        /// </summary>
        [Display(Name = "GLSEG2CALC", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSEG2CALC, Id = Index.GLSEG2CALC, FieldType = EntityFieldType.Int, Size = 2)]
        public int GLSEG2CALC { get; set; }

        /// <summary>
        /// Gets or sets GLSEG3CALC
        /// </summary>
        [Display(Name = "GLSEG3CALC", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSEG3CALC, Id = Index.GLSEG3CALC, FieldType = EntityFieldType.Int, Size = 2)]
        public int GLSEG3CALC { get; set; }

        /// <summary>
        /// Gets or sets GLSEG4CALC
        /// </summary>
        [Display(Name = "GLSEG4CALC", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSEG4CALC, Id = Index.GLSEG4CALC, FieldType = EntityFieldType.Int, Size = 2)]
        public int GLSEG4CALC { get; set; }

        /// <summary>
        /// Gets or sets GLSEG5CALC
        /// </summary>
        [Display(Name = "GLSEG5CALC", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSEG5CALC, Id = Index.GLSEG5CALC, FieldType = EntityFieldType.Int, Size = 2)]
        public int GLSEG5CALC { get; set; }

        /// <summary>
        /// Gets or sets GLSEG6CALC
        /// </summary>
        [Display(Name = "GLSEG6CALC", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.GLSEG6CALC, Id = Index.GLSEG6CALC, FieldType = EntityFieldType.Int, Size = 2)]
        public int GLSEG6CALC { get; set; }

        /// <summary>
        /// Gets or sets ActiveEmployees
        /// </summary>
        [Display(Name = "ActiveEmployees", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.ActiveEmployees, Id = Index.ActiveEmployees, FieldType = EntityFieldType.Long, Size = 4)]
        public int ActiveEmployees { get; set; }

        /// <summary>
        /// Gets or sets DefaultBank
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultBank", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.DefaultBank, Id = Index.DefaultBank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string DefaultBank { get; set; }

        /// <summary>
        /// Gets or sets DefaultMCCheckStockCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultMCCheckStockCode", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.DefaultMCCheckStockCode, Id = Index.DefaultMCCheckStockCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultMCCheckStockCode { get; set; }

        /// <summary>
        /// Gets or sets PayrollCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayrollCurrency", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.PayrollCurrency, Id = Index.PayrollCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3C")]
        public string PayrollCurrency { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2C")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRoundingDifferenceAcc
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExchangeRoundingDifferenceAcc", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.ExchangeRoundingDifferenceAcc, Id = Index.ExchangeRoundingDifferenceAcc, FieldType = EntityFieldType.Char, Size = 45)]
        public string ExchangeRoundingDifferenceAcc { get; set; }

        /// <summary>
        /// Gets or sets UseOriginalDatesWhenReversin
        /// </summary>
        [Display(Name = "UseOriginalDatesWhenReversin", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.UseOriginalDatesWhenReversin, Id = Index.UseOriginalDatesWhenReversin, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseOriginalDatesWhenReversin { get; set; }

        /// <summary>
        /// Gets or sets PJCCostCenterOverride
        /// </summary>
        [Display(Name = "PJCCostCenterOverride", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.PJCCostCenterOverride, Id = Index.PJCCostCenterOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PJCCostCenterOverride { get; set; }

        /// <summary>
        /// Gets or sets PrintMaskedSSN
        /// </summary>
        [Display(Name = "PrintMaskedSSN", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.PrintMaskedSSN, Id = Index.PrintMaskedSSN, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PrintMaskedSSN { get; set; }

        /// <summary>
        /// Gets or sets EmployeeLevelSecurityFlag
        /// </summary>
        [Display(Name = "EmployeeLevelSecurityFlag", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.EmployeeLevelSecurityFlag, Id = Index.EmployeeLevelSecurityFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EmployeeLevelSecurityFlag { get; set; }

        /// <summary>
        /// Gets or sets TaxNumber
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxNumber", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.TaxNumber, Id = Index.TaxNumber, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-15C")]
        public string TaxNumber { get; set; }

        /// <summary>
        /// Gets or sets WCStartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WCStartDate", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.WCStartDate, Id = Index.WCStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WCStartDate { get; set; }

        /// <summary>
        /// Gets or sets EstablishmentNumber
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EstablishmentNumber", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.EstablishmentNumber, Id = Index.EstablishmentNumber, FieldType = EntityFieldType.Char, Size = 20)]
        public string EstablishmentNumber { get; set; }

        /// <summary>
        /// Gets or sets NAICSCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NAICSCode", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.NAICSCode, Id = Index.NAICSCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string NAICSCode { get; set; }

        /// <summary>
        /// Gets or sets DefaultNumberOfDaysForFollo
        /// </summary>
        [Display(Name = "DefaultNumberOfDaysForFollo", ResourceType = typeof (CompanyOptionResx))]
        [ViewField(Name = Fields.DefaultNumberOfDaysForFollo, Id = Index.DefaultNumberOfDaysForFollo, FieldType = EntityFieldType.Int, Size = 2)]
        public short DefaultNumberOfDaysForFollo { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets TimecardFractionalHours string value
        /// </summary>
        public string TimecardFractionalHoursString => EnumUtility.GetStringValue(TimecardFractionalHours);

        /// <summary>
        /// Gets CreateGLTransOrNot string value
        /// </summary>
        public string CreateGLTransOrNotString => EnumUtility.GetStringValue(CreateGLTransOrNot);

        /// <summary>
        /// Gets GLTransAppendToBatch string value
        /// </summary>
        public string GLTransAppendToBatchString => EnumUtility.GetStringValue(GLTransAppendToBatch);

        /// <summary>
        /// Gets GLBatchType string value
        /// </summary>
        public string GLBatchTypeString => EnumUtility.GetStringValue(GLBatchType);

        /// <summary>
        /// Gets CheckOrPeriodEndDate string value
        /// </summary>
        public string CheckOrPeriodEndDateString => EnumUtility.GetStringValue(CheckOrPeriodEndDate);

        /// <summary>
        /// Gets ActiveSegmentReplaceOption string value
        /// </summary>
        public string ActiveSegmentReplaceOptionString => EnumUtility.GetStringValue(ActiveSegmentReplaceOption);

        #endregion
    }
}
