// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for TimecardJobDetail
    /// </summary>
    public partial class TimecardJobDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets Timecard
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Timecard", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.Timecard, Id = Index.Timecard, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Timecard { get; set; }

        /// <summary>
        /// Gets or sets TimecardLineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TimecardLineNumber", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.TimecardLineNumber, Id = Index.TimecardLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short TimecardLineNumber { get; set; }

        /// <summary>
        /// Gets or sets JobLineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "JobLineNumber", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.JobLineNumber, Id = Index.JobLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short JobLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ContractCode
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractCode", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Customer", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3C")]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets StartTime
        /// </summary>
        [Display(Name = "StartTime", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.StartTime, Id = Index.StartTime, FieldType = EntityFieldType.Int, Size = 2)]
        public short StartTime { get; set; }

        /// <summary>
        /// Gets or sets StopTime
        /// </summary>
        [Display(Name = "StopTime", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.StopTime, Id = Index.StopTime, FieldType = EntityFieldType.Int, Size = 2)]
        public short StopTime { get; set; }

        /// <summary>
        /// Gets or sets Hours
        /// </summary>
        [Display(Name = "Hours", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.Hours, Id = Index.Hours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal Hours { get; set; }

        /// <summary>
        /// Gets or sets PiecesSalesAmt
        /// </summary>
        [Display(Name = "PiecesSalesAmt", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.PiecesSalesAmt, Id = Index.PiecesSalesAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PiecesSalesAmt { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ARItemUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemUOM", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.ARItemUOM, Id = Index.ARItemUOM, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string ARItemUOM { get; set; }

        /// <summary>
        /// Gets or sets RegularWIPCOSAcct
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RegularWIPCOSAcct", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.RegularWIPCOSAcct, Id = Index.RegularWIPCOSAcct, FieldType = EntityFieldType.Char, Size = 45)]
        public string RegularWIPCOSAcct { get; set; }

        /// <summary>
        /// Gets or sets OvertimeWIPCOSAcct
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OvertimeWIPCOSAcct", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.OvertimeWIPCOSAcct, Id = Index.OvertimeWIPCOSAcct, FieldType = EntityFieldType.Char, Size = 45)]
        public string OvertimeWIPCOSAcct { get; set; }

        /// <summary>
        /// Gets or sets ShiftWIPCOSAcct
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiftWIPCOSAcct", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.ShiftWIPCOSAcct, Id = Index.ShiftWIPCOSAcct, FieldType = EntityFieldType.Char, Size = 45)]
        public string ShiftWIPCOSAcct { get; set; }

        /// <summary>
        /// Gets or sets OvertimeHoursOverride
        /// </summary>
        [Display(Name = "OvertimeHoursOverride", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.OvertimeHoursOverride, Id = Index.OvertimeHoursOverride, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal OvertimeHoursOverride { get; set; }

        /// <summary>
        /// Gets or sets OvertimeBillingRateOverride
        /// </summary>
        [Display(Name = "OvertimeBillingRateOverride", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.OvertimeBillingRateOverride, Id = Index.OvertimeBillingRateOverride, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OvertimeBillingRateOverride { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }
        
        /// <summary>
        /// Gets or sets ProjectStyle
        /// </summary>
        [Display(Name = "ProjectStyle", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectStyle ProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets UnformattedContractCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedContractCode", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.UnformattedContractCode, Id = Index.UnformattedContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string UnformattedContractCode { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDescription
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyDescription", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 30)]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets AllowCostCenterOverrides
        /// </summary>
        [Display(Name = "AllowCostCenterOverrides", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.AllowCostCenterOverrides, Id = Index.AllowCostCenterOverrides, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowCostCenterOverrides { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public JobDetailProcessControlCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets ResourceDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ResourceDescription", ResourceType = typeof (TimecardJobDetailResx))]
        [ViewField(Name = Fields.ResourceDescription, Id = Index.ResourceDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ResourceDescription { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString => EnumUtility.GetStringValue(BillingType);

        /// <summary>
        /// Gets ProjectStyle string value
        /// </summary>
        public string ProjectStyleString => EnumUtility.GetStringValue(ProjectStyle);

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString => EnumUtility.GetStringValue(ProjectType);

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString => EnumUtility.GetStringValue(AccountingMethod);

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString => EnumUtility.GetStringValue(CostClass);

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

        #endregion
    }
}
