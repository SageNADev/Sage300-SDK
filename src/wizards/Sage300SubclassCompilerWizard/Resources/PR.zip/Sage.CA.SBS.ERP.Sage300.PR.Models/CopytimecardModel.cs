﻿// Copyright (c) 2025 The Sage Group plc or its licensors. All rights reserved.
#region Namespace
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    public partial class Copytimecard : ModelBase
    {
        /// <summary>
        /// The character 'Z' is assigned to the constant variable 'Z'.
        /// </summary>
        private const char Z = 'Z';

        /// <summary>
        /// The constant variable 'ToEmployeeLength' is assigned the value 12.
        /// This constant represents the length used when initializing the 'ToEmployee' property.
        /// </summary>
        private const int ToEmployeeLength = 12;

        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Display(Name = "Employee", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Int, Size = 2)]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [Display(Name = "PeriodEndDate", ResourceType = typeof(CopytimecardResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets Timecard
        /// </summary>
        public string Timecard { get; set; }

        /// <summary>
        /// Gets or sets AssignTimecardNumber
        /// </summary>
        [Display(Name = "AssignTimecardNumber", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.AssignTimecardNumber, Id = Index.AssignTimecardNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public string AssignTimecardNumber { get; set; }

        /// <summary>
        /// Gets or sets ReuseTimecard
        /// </summary>
        [Display(Name = "ReuseTimecard", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.ReuseTimecard, Id = Index.ReuseTimecard, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ReuseTimecard { get; set; }

        /// <summary>
        /// Gets or sets AssignPeriodEndDate
        /// </summary>
        [Display(Name = "AssignPeriodEndDate", ResourceType =typeof(CopytimecardResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AssignPeriodEndDate, Id = Index.AssignPeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? AssignPeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets AssignActiveStatus
        /// </summary>
        [Display(Name = "AssignActiveStatus", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.AssignActiveStatus, Id = Index.AssignActiveStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public bool AssignActiveStatus { get; set; }

        /// <summary>
        /// Gets or sets AssignSeparateCheckFlag
        /// </summary>
        [Display(Name = "AssignSeparateCheckFlag", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.AssignSeparateCheckFlag, Id = Index.AssignSeparateCheckFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public bool AssignSeparateCheckFlag { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Int, Size = 15)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Chooseby
        /// </summary>
        [Display(Name = "Chooseby", ResourceType = typeof(CopytimecardResx))]
        public int Chooseby { get; set; }

        /// <summary>
        /// Gets or sets SelectionList
        /// </summary>
        [Display(Name = "SelectionList", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.SelectionList, Id = Index.SelectionList, FieldType = EntityFieldType.Int, Size = 2)]
        public string SelectionList { get; set; }

        /// <summary>
        /// Gets or sets FromEmployee
        /// </summary>
        [Display(Name = "FromEmployee", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.FromEmployee, Id = Index.FromEmployee, FieldType = EntityFieldType.Int, Size = 2)]
        public string FromEmployee { get; set; }

        /// <summary>
        /// Gets or sets ToEmployee
        /// </summary>
        [Display(Name = "ToEmployee", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.ToEmployee, Id = Index.ToEmployee, FieldType = EntityFieldType.Int, Size = 2)]
        public string ToEmployee { get; set; }

        /// <summary>
        /// Gets or sets Class
        /// </summary>
        [Display(Name = "Class", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.CopyClass, Id = Index.CopyClass, FieldType = EntityFieldType.Int, Size = 2)]     
        public Enums.CopyClass Class { get; set; }

        /// <summary>
        /// Gets or sets FromClassCode
        /// </summary>
        [Display(Name = "FromClassCode", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.FromClassCode, Id = Index.ToEmployee, FieldType = EntityFieldType.Int, Size = 2)]
        public string FromClassCode { get; set; }

        /// <summary>
        /// Gets or sets ToClassCode
        /// </summary>
        [Display(Name = "ToClassCode", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.ToClassCode, Id = Index.ToEmployee, FieldType = EntityFieldType.Int, Size = 2)]
        public string ToClassCode { get; set; }

        /// <summary>
        /// Gets or sets Ignoreinvaliddetails
        /// </summary>
        [Display(Name = "Ignoreinvaliddetails", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.Ignoreinvaliddetails, Id = Index.Ignoreinvaliddetails, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Ignoreinvaliddetails { get; set; }

        /// <summary>
        /// Gets or sets SkipEmployeesInvalidData
        /// </summary>
        [Display(Name = "SkipEmployeesInvalidData", ResourceType = typeof(CopytimecardResx))]
        [ViewField(Name = Fields.SkipEmployeesInvalidData, Id = Index.SkipEmployeesInvalidData, FieldType = EntityFieldType.Int, Size = 2)]
        public bool SkipEmployeesInvalidData { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        public int ProcessCommandCode { get; set; }
  
    }
}
