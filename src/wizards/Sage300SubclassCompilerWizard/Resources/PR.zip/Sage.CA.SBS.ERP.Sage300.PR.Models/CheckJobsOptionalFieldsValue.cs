// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CheckJobsOptionalFieldsValue
    /// </summary>
    public partial class CheckJobsOptionalFieldsValue : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets EntrySequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntrySequence", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.EntrySequence, Id = Index.EntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int EntrySequence { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Category Category { get; set; }

        /// <summary>
        /// Gets or sets EarningDeduction
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningDeduction", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.EarningDeduction, Id = Index.EarningDeduction, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EarningDeduction { get; set; }

        /// <summary>
        /// Gets or sets LineType
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineType", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.LineType LineType { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short LineNumber { get; set; }

        /// <summary>
        /// Gets or sets JobLineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "JobLineNumber", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.JobLineNumber, Id = Index.JobLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short JobLineNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Value
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Value", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets TYPE
        /// </summary>
        [Display(Name = "OptionalFieldType", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.OptionalFieldType, Id = Index.OptionalFieldType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.OptionalFieldType OptionalFieldType { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public short Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public short Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public Enums.AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public Enums.Validate Validate { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets TypedValueFieldIndex
        /// </summary>
        [Display(Name = "TypedValueFieldIndex", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public int TypedValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets TextValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TextValue", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string TextValue { get; set; }

        /// <summary>
        /// Gets or sets AmountValue
        /// </summary>
        [Display(Name = "AmountValue", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountValue { get; set; }

        /// <summary>
        /// Gets or sets NumberValue
        /// </summary>
        [Display(Name = "NumberValue", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NumberValue { get; set; }

        /// <summary>
        /// Gets or sets IntegerValue
        /// </summary>
        [Display(Name = "IntegerValue", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public int IntegerValue { get; set; }

        /// <summary>
        /// Gets or sets YesNoValue
        /// </summary>
        [Display(Name = "YesNoValue", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.YesNoValue, Id = Index.YesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.YesNoValue YesNoValue { get; set; }

        /// <summary>
        /// Gets or sets DateValue
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateValue", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateValue { get; set; }

        /// <summary>
        /// Gets or sets TimeValue
        /// </summary>
        [Display(Name = "TimeValue", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan TimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ValueDescription", ResourceType = typeof (CheckJobsOptionalFieldsValueResx))]
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Category string value
        /// </summary>
        public string CategoryString => EnumUtility.GetStringValue(Category);

        /// <summary>
        /// Gets LineType string value
        /// </summary>
        public string LineTypeString => EnumUtility.GetStringValue(LineType);

        /// <summary>
        /// Gets OptionalFieldType string value
        /// </summary>
        public string OptionalFieldTypeString => EnumUtility.GetStringValue(OptionalFieldType);

        /// <summary>
        /// Gets AllowBlank string value
        /// </summary>
        public string AllowBlankString => EnumUtility.GetStringValue(AllowBlank);

        /// <summary>
        /// Gets Validate string value
        /// </summary>
        public string ValidateString => EnumUtility.GetStringValue(Validate);

        /// <summary>
        /// Gets ValueSet string value
        /// </summary>
        public string ValueSetString => EnumUtility.GetStringValue(ValueSet);

        /// <summary>
        /// Gets YesNoValue string value
        /// </summary>
        public string YesNoValueString => EnumUtility.GetStringValue(YesNoValue);

        #endregion
    }
}
