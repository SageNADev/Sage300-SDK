// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EarningsDeduction
    /// </summary>
    public partial class EarningsDeduction : ModelBase
    {
        /// <summary>
        /// Gets or sets EarningDeduction
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningDeduction", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EarningDeduction, Id = Index.EarningDeduction, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EarningDeduction { get; set; }

        /// <summary>
        /// Gets or sets EarningDeductionDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningDeductionDescription", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EarningDeductionDescription, Id = Index.EarningDeductionDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string EarningDeductionDescription { get; set; }

        /// <summary>
        /// Gets or sets EarningDeductionShortDescript
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningDeductionShortDescript", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EarningDeductionShortDescript, Id = Index.EarningDeductionShortDescript, FieldType = EntityFieldType.Char, Size = 15)]
        public string EarningDeductionShortDescript { get; set; }

        /// <summary>
        /// Gets or sets Inactive
        /// </summary>
        [Display(Name = "Inactive", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.Inactive, Id = Index.Inactive, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Inactive { get; set; }

        /// <summary>
        /// Gets or sets InactiveAsOf
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveAsOf", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.InactiveAsOf, Id = Index.InactiveAsOf, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveAsOf { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [Display(Name = "Category", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.Category Category { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.Type Type { get; set; }

        /// <summary>
        /// Gets or sets Frequency
        /// </summary>
        [Display(Name = "Frequency", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.Frequency, Id = Index.Frequency, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.Frequency Frequency { get; set; }

        /// <summary>
        /// Gets or sets Starts
        /// </summary>
        [Display(Name = "Starts", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.Starts, Id = Index.Starts, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.Starts Starts { get; set; }

        /// <summary>
        /// Gets or sets StartMonth
        /// </summary>
        [Display(Name = "StartMonth", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.StartMonth, Id = Index.StartMonth, FieldType = EntityFieldType.Int, Size = 2)]
        public short StartMonth { get; set; }

        /// <summary>
        /// Gets or sets StartDay
        /// </summary>
        [Display(Name = "StartDay", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.StartDay, Id = Index.StartDay, FieldType = EntityFieldType.Int, Size = 2)]
        public short StartDay { get; set; }

        /// <summary>
        /// Gets or sets Ends
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Ends", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.Ends, Id = Index.Ends, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Ends { get; set; }

        /// <summary>
        /// Gets or sets PrintOnCheck
        /// </summary>
        [Display(Name = "PrintOnCheck", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PrintOnCheck, Id = Index.PrintOnCheck, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PrintOnCheck { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDPrintIfCurrentZero
        /// </summary>
        [Display(Name = "RESERVEDPrintIfCurrentZero", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.RESERVEDPrintIfCurrentZero, Id = Index.RESERVEDPrintIfCurrentZero, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RESERVEDPrintIfCurrentZero { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDPrintYTDIfCurrentZe
        /// </summary>
        [Display(Name = "RESERVEDPrintYTDIfCurrentZe", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.RESERVEDPrintYTDIfCurrentZe, Id = Index.RESERVEDPrintYTDIfCurrentZe, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RESERVEDPrintYTDIfCurrentZe { get; set; }

        /// <summary>
        /// Gets or sets EmployeeCalculationMethod
        /// </summary>
        [Display(Name = "EmployeeCalculationMethod", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeCalculationMethod, Id = Index.EmployeeCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployeeCalculationMethod EmployeeCalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets EmployeeW2Box
        /// </summary>
        [Display(Name = "EmployeeW2Box", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeW2Box, Id = Index.EmployeeW2Box, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployeeW2Box EmployeeW2Box { get; set; }

        /// <summary>
        /// Gets or sets EmployeeRate
        /// </summary>
        [Display(Name = "EmployeeRate", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeRate, Id = Index.EmployeeRate, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployeeRate { get; set; }

        /// <summary>
        /// Gets or sets EmployeeAnnualMaximum
        /// </summary>
        [Display(Name = "EmployeeAnnualMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeAnnualMaximum, Id = Index.EmployeeAnnualMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeAnnualMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeDailyMinimum
        /// </summary>
        [Display(Name = "EmployeeDailyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeDailyMinimum, Id = Index.EmployeeDailyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeDailyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeDailyMaximum
        /// </summary>
        [Display(Name = "EmployeeDailyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeDailyMaximum, Id = Index.EmployeeDailyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeDailyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeWeeklyMinimum
        /// </summary>
        [Display(Name = "EmployeeWeeklyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeWeeklyMinimum, Id = Index.EmployeeWeeklyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeWeeklyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeWeeklyMaximum
        /// </summary>
        [Display(Name = "EmployeeWeeklyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeWeeklyMaximum, Id = Index.EmployeeWeeklyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeWeeklyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeBiweeklyMinimum
        /// </summary>
        [Display(Name = "EmployeeBiweeklyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeBiweeklyMinimum, Id = Index.EmployeeBiweeklyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeBiweeklyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeBiweeklyMaximum
        /// </summary>
        [Display(Name = "EmployeeBiweeklyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeBiweeklyMaximum, Id = Index.EmployeeBiweeklyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeBiweeklyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSemimonthlyMinimum
        /// </summary>
        [Display(Name = "EmployeeSemimonthlyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeSemimonthlyMinimum, Id = Index.EmployeeSemimonthlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeSemimonthlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSemimonthlyMaximum
        /// </summary>
        [Display(Name = "EmployeeSemimonthlyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeSemimonthlyMaximum, Id = Index.EmployeeSemimonthlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeSemimonthlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeMonthlyMinimum
        /// </summary>
        [Display(Name = "EmployeeMonthlyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeMonthlyMinimum, Id = Index.EmployeeMonthlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeMonthlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeMonthlyMaximum
        /// </summary>
        [Display(Name = "EmployeeMonthlyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeMonthlyMaximum, Id = Index.EmployeeMonthlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeMonthlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeQuarterlyMinimum
        /// </summary>
        [Display(Name = "EmployeeQuarterlyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeQuarterlyMinimum, Id = Index.EmployeeQuarterlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeQuarterlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeQuarterlyMaximum
        /// </summary>
        [Display(Name = "EmployeeQuarterlyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeQuarterlyMaximum, Id = Index.EmployeeQuarterlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeQuarterlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTenPeriodYearMinimum
        /// </summary>
        [Display(Name = "EmployeeTenPeriodYearMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeTenPeriodYearMinimum, Id = Index.EmployeeTenPeriodYearMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeTenPeriodYearMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTenPeriodYearMaximum
        /// </summary>
        [Display(Name = "EmployeeTenPeriodYearMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeTenPeriodYearMaximum, Id = Index.EmployeeTenPeriodYearMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeTenPeriodYearMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeThirteenPeriodYearMi
        /// </summary>
        [Display(Name = "EmployeeThirteenPeriodYearMi", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeThirteenPeriodYearMi, Id = Index.EmployeeThirteenPeriodYearMi, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeThirteenPeriodYearMi { get; set; }

        /// <summary>
        /// Gets or sets EmployeeThirteenPeriodYearMa
        /// </summary>
        [Display(Name = "EmployeeThirteenPeriodYearMa", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeThirteenPeriodYearMa, Id = Index.EmployeeThirteenPeriodYearMa, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeThirteenPeriodYearMa { get; set; }

        /// <summary>
        /// Gets or sets E22PPPYMIN
        /// </summary>
        [Display(Name = "E22PPPYMIN", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.E22PPPYMIN, Id = Index.E22PPPYMIN, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal E22PPPYMIN { get; set; }

        /// <summary>
        /// Gets or sets E22PPPYMAX
        /// </summary>
        [Display(Name = "E22PPPYMAX", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.E22PPPYMAX, Id = Index.E22PPPYMAX, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal E22PPPYMAX { get; set; }

        /// <summary>
        /// Gets or sets EmployeeBaseLimit
        /// </summary>
        [Display(Name = "EmployeeBaseLimit", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeBaseLimit, Id = Index.EmployeeBaseLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployeeBaseLimit EmployeeBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets WageBracket1
        /// </summary>
        [Display(Name = "WageBracket1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket1, Id = Index.WageBracket1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket1 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount1
        /// </summary>
        [Display(Name = "AddAmount1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount1, Id = Index.AddAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess1
        /// </summary>
        [Display(Name = "PercntOfExcess1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess1, Id = Index.PercntOfExcess1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess1 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket2
        /// </summary>
        [Display(Name = "WageBracket2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket2, Id = Index.WageBracket2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket2 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount2
        /// </summary>
        [Display(Name = "AddAmount2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount2, Id = Index.AddAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess2
        /// </summary>
        [Display(Name = "PercntOfExcess2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess2, Id = Index.PercntOfExcess2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess2 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket3
        /// </summary>
        [Display(Name = "WageBracket3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket3, Id = Index.WageBracket3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket3 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount3
        /// </summary>
        [Display(Name = "AddAmount3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount3, Id = Index.AddAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess3
        /// </summary>
        [Display(Name = "PercntOfExcess3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess3, Id = Index.PercntOfExcess3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess3 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket4
        /// </summary>
        [Display(Name = "WageBracket4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket4, Id = Index.WageBracket4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket4 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount4
        /// </summary>
        [Display(Name = "AddAmount4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount4, Id = Index.AddAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess4
        /// </summary>
        [Display(Name = "PercntOfExcess4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess4, Id = Index.PercntOfExcess4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess4 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket5
        /// </summary>
        [Display(Name = "WageBracket5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket5, Id = Index.WageBracket5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket5 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount5
        /// </summary>
        [Display(Name = "AddAmount5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount5, Id = Index.AddAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess5
        /// </summary>
        [Display(Name = "PercntOfExcess5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess5, Id = Index.PercntOfExcess5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess5 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket6
        /// </summary>
        [Display(Name = "WageBracket6", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket6, Id = Index.WageBracket6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket6 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount6
        /// </summary>
        [Display(Name = "AddAmount6", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount6, Id = Index.AddAmount6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount6 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess6
        /// </summary>
        [Display(Name = "PercntOfExcess6", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess6, Id = Index.PercntOfExcess6, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess6 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket7
        /// </summary>
        [Display(Name = "WageBracket7", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket7, Id = Index.WageBracket7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket7 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount7
        /// </summary>
        [Display(Name = "AddAmount7", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount7, Id = Index.AddAmount7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount7 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess7
        /// </summary>
        [Display(Name = "PercntOfExcess7", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess7, Id = Index.PercntOfExcess7, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess7 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket8
        /// </summary>
        [Display(Name = "WageBracket8", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket8, Id = Index.WageBracket8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket8 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount8
        /// </summary>
        [Display(Name = "AddAmount8", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount8, Id = Index.AddAmount8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount8 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess8
        /// </summary>
        [Display(Name = "PercntOfExcess8", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess8, Id = Index.PercntOfExcess8, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess8 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket9
        /// </summary>
        [Display(Name = "WageBracket9", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket9, Id = Index.WageBracket9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket9 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount9
        /// </summary>
        [Display(Name = "AddAmount9", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount9, Id = Index.AddAmount9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount9 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess9
        /// </summary>
        [Display(Name = "PercntOfExcess9", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess9, Id = Index.PercntOfExcess9, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess9 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket10
        /// </summary>
        [Display(Name = "WageBracket10", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket10, Id = Index.WageBracket10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket10 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount10
        /// </summary>
        [Display(Name = "AddAmount10", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount10, Id = Index.AddAmount10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount10 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess10
        /// </summary>
        [Display(Name = "PercntOfExcess10", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess10, Id = Index.PercntOfExcess10, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess10 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket11
        /// </summary>
        [Display(Name = "WageBracket11", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket11, Id = Index.WageBracket11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket11 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount11
        /// </summary>
        [Display(Name = "AddAmount11", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount11, Id = Index.AddAmount11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount11 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess11
        /// </summary>
        [Display(Name = "PercntOfExcess11", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess11, Id = Index.PercntOfExcess11, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess11 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket12
        /// </summary>
        [Display(Name = "WageBracket12", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket12, Id = Index.WageBracket12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket12 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount12
        /// </summary>
        [Display(Name = "AddAmount12", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount12, Id = Index.AddAmount12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount12 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess12
        /// </summary>
        [Display(Name = "PercntOfExcess12", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess12, Id = Index.PercntOfExcess12, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess12 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket13
        /// </summary>
        [Display(Name = "WageBracket13", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket13, Id = Index.WageBracket13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket13 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount13
        /// </summary>
        [Display(Name = "AddAmount13", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount13, Id = Index.AddAmount13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount13 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess13
        /// </summary>
        [Display(Name = "PercntOfExcess13", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess13, Id = Index.PercntOfExcess13, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess13 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket14
        /// </summary>
        [Display(Name = "WageBracket14", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket14, Id = Index.WageBracket14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket14 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount14
        /// </summary>
        [Display(Name = "AddAmount14", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount14, Id = Index.AddAmount14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount14 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess14
        /// </summary>
        [Display(Name = "PercntOfExcess14", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess14, Id = Index.PercntOfExcess14, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess14 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket15
        /// </summary>
        [Display(Name = "WageBracket15", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket15, Id = Index.WageBracket15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket15 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount15
        /// </summary>
        [Display(Name = "AddAmount15", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount15, Id = Index.AddAmount15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount15 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess15
        /// </summary>
        [Display(Name = "PercntOfExcess15", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess15, Id = Index.PercntOfExcess15, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess15 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket16
        /// </summary>
        [Display(Name = "WageBracket16", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket16, Id = Index.WageBracket16, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket16 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount16
        /// </summary>
        [Display(Name = "AddAmount16", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount16, Id = Index.AddAmount16, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount16 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess16
        /// </summary>
        [Display(Name = "PercntOfExcess16", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess16, Id = Index.PercntOfExcess16, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess16 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket17
        /// </summary>
        [Display(Name = "WageBracket17", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket17, Id = Index.WageBracket17, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket17 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount17
        /// </summary>
        [Display(Name = "AddAmount17", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount17, Id = Index.AddAmount17, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount17 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess17
        /// </summary>
        [Display(Name = "PercntOfExcess17", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess17, Id = Index.PercntOfExcess17, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess17 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket18
        /// </summary>
        [Display(Name = "WageBracket18", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket18, Id = Index.WageBracket18, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket18 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount18
        /// </summary>
        [Display(Name = "AddAmount18", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount18, Id = Index.AddAmount18, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount18 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess18
        /// </summary>
        [Display(Name = "PercntOfExcess18", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess18, Id = Index.PercntOfExcess18, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess18 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket19
        /// </summary>
        [Display(Name = "WageBracket19", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket19, Id = Index.WageBracket19, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket19 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount19
        /// </summary>
        [Display(Name = "AddAmount19", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount19, Id = Index.AddAmount19, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount19 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess19
        /// </summary>
        [Display(Name = "PercntOfExcess19", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess19, Id = Index.PercntOfExcess19, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess19 { get; set; }

        /// <summary>
        /// Gets or sets WageBracket20
        /// </summary>
        [Display(Name = "WageBracket20", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WageBracket20, Id = Index.WageBracket20, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageBracket20 { get; set; }

        /// <summary>
        /// Gets or sets AddAmount20
        /// </summary>
        [Display(Name = "AddAmount20", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AddAmount20, Id = Index.AddAmount20, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AddAmount20 { get; set; }

        /// <summary>
        /// Gets or sets PercntOfExcess20
        /// </summary>
        [Display(Name = "PercntOfExcess20", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PercntOfExcess20, Id = Index.PercntOfExcess20, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercntOfExcess20 { get; set; }

        /// <summary>
        /// Gets or sets EmployerCalculationMethod
        /// </summary>
        [Display(Name = "EmployerCalculationMethod", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerCalculationMethod, Id = Index.EmployerCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployerCalculationMethod EmployerCalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets EmployerW2Box
        /// </summary>
        [Display(Name = "EmployerW2Box", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerW2Box, Id = Index.EmployerW2Box, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployerW2Box EmployerW2Box { get; set; }

        /// <summary>
        /// Gets or sets EmployerRate
        /// </summary>
        [Display(Name = "EmployerRate", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerRate, Id = Index.EmployerRate, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployerRate { get; set; }

        /// <summary>
        /// Gets or sets EmployerAnnualMaximum
        /// </summary>
        [Display(Name = "EmployerAnnualMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerAnnualMaximum, Id = Index.EmployerAnnualMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerAnnualMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerDailyMinimum
        /// </summary>
        [Display(Name = "EmployerDailyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerDailyMinimum, Id = Index.EmployerDailyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerDailyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerDailyMaximum
        /// </summary>
        [Display(Name = "EmployerDailyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerDailyMaximum, Id = Index.EmployerDailyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerDailyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerWeeklyMinimum
        /// </summary>
        [Display(Name = "EmployerWeeklyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerWeeklyMinimum, Id = Index.EmployerWeeklyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerWeeklyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerWeeklyMaximum
        /// </summary>
        [Display(Name = "EmployerWeeklyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerWeeklyMaximum, Id = Index.EmployerWeeklyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerWeeklyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerBiweeklyMinimum
        /// </summary>
        [Display(Name = "EmployerBiweeklyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerBiweeklyMinimum, Id = Index.EmployerBiweeklyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerBiweeklyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerBiweeklyMaximum
        /// </summary>
        [Display(Name = "EmployerBiweeklyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerBiweeklyMaximum, Id = Index.EmployerBiweeklyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerBiweeklyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerSemimonthlyMinimum
        /// </summary>
        [Display(Name = "EmployerSemimonthlyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerSemimonthlyMinimum, Id = Index.EmployerSemimonthlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerSemimonthlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerSemimonthlyMaximum
        /// </summary>
        [Display(Name = "EmployerSemimonthlyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerSemimonthlyMaximum, Id = Index.EmployerSemimonthlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerSemimonthlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerMonthlyMinimum
        /// </summary>
        [Display(Name = "EmployerMonthlyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerMonthlyMinimum, Id = Index.EmployerMonthlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerMonthlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerMonthlyMaximum
        /// </summary>
        [Display(Name = "EmployerMonthlyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerMonthlyMaximum, Id = Index.EmployerMonthlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerMonthlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerQuarterlyMinimum
        /// </summary>
        [Display(Name = "EmployerQuarterlyMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerQuarterlyMinimum, Id = Index.EmployerQuarterlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerQuarterlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerQuarterlyMaximum
        /// </summary>
        [Display(Name = "EmployerQuarterlyMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerQuarterlyMaximum, Id = Index.EmployerQuarterlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerQuarterlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerTenPerYearMinimum
        /// </summary>
        [Display(Name = "EmployerTenPerYearMinimum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerTenPerYearMinimum, Id = Index.EmployerTenPerYearMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerTenPerYearMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerTenPerYearMaximum
        /// </summary>
        [Display(Name = "EmployerTenPerYearMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerTenPerYearMaximum, Id = Index.EmployerTenPerYearMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerTenPerYearMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerThirteenPerYearMinim
        /// </summary>
        [Display(Name = "EmployerThirteenPerYearMinim", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerThirteenPerYearMinim, Id = Index.EmployerThirteenPerYearMinim, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerThirteenPerYearMinim { get; set; }

        /// <summary>
        /// Gets or sets EmployerThirteenPerYearMaxim
        /// </summary>
        [Display(Name = "EmployerThirteenPerYearMaxim", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerThirteenPerYearMaxim, Id = Index.EmployerThirteenPerYearMaxim, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerThirteenPerYearMaxim { get; set; }

        /// <summary>
        /// Gets or sets EmployerTwentytwoPerYearMini
        /// </summary>
        [Display(Name = "EmployerTwentytwoPerYearMini", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerTwentytwoPerYearMini, Id = Index.EmployerTwentytwoPerYearMini, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerTwentytwoPerYearMini { get; set; }

        /// <summary>
        /// Gets or sets EmployerTwentytwoPerYearMaxi
        /// </summary>
        [Display(Name = "EmployerTwentytwoPerYearMaxi", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerTwentytwoPerYearMaxi, Id = Index.EmployerTwentytwoPerYearMaxi, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerTwentytwoPerYearMaxi { get; set; }

        /// <summary>
        /// Gets or sets EmployerBaseLimit
        /// </summary>
        [Display(Name = "EmployerBaseLimit", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerBaseLimit, Id = Index.EmployerBaseLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployerBaseLimit EmployerBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets SubjectToWorkersCompensation
        /// </summary>
        [Display(Name = "SubjectToWorkersCompensation", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.SubjectToWorkersCompensation, Id = Index.SubjectToWorkersCompensation, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SubjectToWorkersCompensation { get; set; }

        /// <summary>
        /// Gets or sets CommissionAmount1
        /// </summary>
        [Display(Name = "CommissionAmount1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionAmount1, Id = Index.CommissionAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommissionAmount1 { get; set; }

        /// <summary>
        /// Gets or sets CommissionPct1
        /// </summary>
        [Display(Name = "CommissionPct1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionPct1, Id = Index.CommissionPct1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionPct1 { get; set; }

        /// <summary>
        /// Gets or sets CommissionAmount2
        /// </summary>
        [Display(Name = "CommissionAmount2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionAmount2, Id = Index.CommissionAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommissionAmount2 { get; set; }

        /// <summary>
        /// Gets or sets CommissionPct2
        /// </summary>
        [Display(Name = "CommissionPct2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionPct2, Id = Index.CommissionPct2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionPct2 { get; set; }

        /// <summary>
        /// Gets or sets CommissionAmount3
        /// </summary>
        [Display(Name = "CommissionAmount3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionAmount3, Id = Index.CommissionAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommissionAmount3 { get; set; }

        /// <summary>
        /// Gets or sets CommissionPct3
        /// </summary>
        [Display(Name = "CommissionPct3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionPct3, Id = Index.CommissionPct3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionPct3 { get; set; }

        /// <summary>
        /// Gets or sets CommissionAmount4
        /// </summary>
        [Display(Name = "CommissionAmount4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionAmount4, Id = Index.CommissionAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommissionAmount4 { get; set; }

        /// <summary>
        /// Gets or sets CommissionPct4
        /// </summary>
        [Display(Name = "CommissionPct4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionPct4, Id = Index.CommissionPct4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionPct4 { get; set; }

        /// <summary>
        /// Gets or sets CommissionAmount5
        /// </summary>
        [Display(Name = "CommissionAmount5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionAmount5, Id = Index.CommissionAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommissionAmount5 { get; set; }

        /// <summary>
        /// Gets or sets CommissionPct5
        /// </summary>
        [Display(Name = "CommissionPct5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionPct5, Id = Index.CommissionPct5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionPct5 { get; set; }

        /// <summary>
        /// Gets or sets CommissionAmountExcess
        /// </summary>
        [Display(Name = "CommissionAmountExcess", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CommissionAmountExcess, Id = Index.CommissionAmountExcess, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionAmountExcess { get; set; }

        /// <summary>
        /// Gets or sets PieceCount1
        /// </summary>
        [Display(Name = "PieceCount1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PieceCount1, Id = Index.PieceCount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PieceCount1 { get; set; }

        /// <summary>
        /// Gets or sets PieceAmount1
        /// </summary>
        [Display(Name = "PieceAmount1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PieceAmount1, Id = Index.PieceAmount1, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal PieceAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PieceCount2
        /// </summary>
        [Display(Name = "PieceCount2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PieceCount2, Id = Index.PieceCount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PieceCount2 { get; set; }

        /// <summary>
        /// Gets or sets PieceAmount2
        /// </summary>
        [Display(Name = "PieceAmount2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PieceAmount2, Id = Index.PieceAmount2, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal PieceAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PieceCount3
        /// </summary>
        [Display(Name = "PieceCount3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PieceCount3, Id = Index.PieceCount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PieceCount3 { get; set; }

        /// <summary>
        /// Gets or sets PieceAmount3
        /// </summary>
        [Display(Name = "PieceAmount3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PieceAmount3, Id = Index.PieceAmount3, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal PieceAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PieceCount4
        /// </summary>
        [Display(Name = "PieceCount4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PieceCount4, Id = Index.PieceCount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PieceCount4 { get; set; }

        /// <summary>
        /// Gets or sets PieceAmount4
        /// </summary>
        [Display(Name = "PieceAmount4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PieceAmount4, Id = Index.PieceAmount4, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal PieceAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PieceCount5
        /// </summary>
        [Display(Name = "PieceCount5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PieceCount5, Id = Index.PieceCount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PieceCount5 { get; set; }

        /// <summary>
        /// Gets or sets PieceAmount5
        /// </summary>
        [Display(Name = "PieceAmount5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PieceAmount5, Id = Index.PieceAmount5, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal PieceAmount5 { get; set; }

        /// <summary>
        /// Gets or sets MaxPieceRateAmount
        /// </summary>
        [Display(Name = "MaxPieceRateAmount", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxPieceRateAmount, Id = Index.MaxPieceRateAmount, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal MaxPieceRateAmount { get; set; }

        /// <summary>
        /// Gets or sets TipDisbursement
        /// </summary>
        [Display(Name = "TipDisbursement", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.TipDisbursement, Id = Index.TipDisbursement, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TipDisbursement { get; set; }

        /// <summary>
        /// Gets or sets RepaymentDeduction
        /// </summary>
        [Display(Name = "RepaymentDeduction", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.RepaymentDeduction, Id = Index.RepaymentDeduction, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RepaymentDeduction { get; set; }

        /// <summary>
        /// Gets or sets AdvanceToBeRepaid
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdvanceToBeRepaid", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AdvanceToBeRepaid, Id = Index.AdvanceToBeRepaid, FieldType = EntityFieldType.Char, Size = 6)]
        public string AdvanceToBeRepaid { get; set; }

        /// <summary>
        /// Gets or sets Carryover
        /// </summary>
        [Display(Name = "Carryover", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.Carryover, Id = Index.Carryover, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.Carryover Carryover { get; set; }

        /// <summary>
        /// Gets or sets CarryOverDay
        /// </summary>
        [Display(Name = "CarryOverDay", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CarryOverDay, Id = Index.CarryOverDay, FieldType = EntityFieldType.Int, Size = 2)]
        public short CarryOverDay { get; set; }

        /// <summary>
        /// Gets or sets CarryOverMonth
        /// </summary>
        [Display(Name = "CarryOverMonth", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CarryOverMonth, Id = Index.CarryOverMonth, FieldType = EntityFieldType.Int, Size = 2)]
        public short CarryOverMonth { get; set; }

        /// <summary>
        /// Gets or sets PostLiab
        /// </summary>
        [Display(Name = "PostLiab", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PostLiab, Id = Index.PostLiab, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PostLiab { get; set; }

        /// <summary>
        /// Gets or sets ServiceYear1
        /// </summary>
        [Display(Name = "ServiceYear1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ServiceYear1, Id = Index.ServiceYear1, FieldType = EntityFieldType.Int, Size = 2)]
        public short ServiceYear1 { get; set; }

        /// <summary>
        /// Gets or sets BeginningHours1
        /// </summary>
        [Display(Name = "BeginningHours1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BeginningHours1, Id = Index.BeginningHours1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningHours1 { get; set; }

        /// <summary>
        /// Gets or sets IncrementHours1
        /// </summary>
        [Display(Name = "IncrementHours1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncrementHours1, Id = Index.IncrementHours1, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal IncrementHours1 { get; set; }

        /// <summary>
        /// Gets or sets MaxAnnualAccrual1
        /// </summary>
        [Display(Name = "MaxAnnualAccrual1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxAnnualAccrual1, Id = Index.MaxAnnualAccrual1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxAnnualAccrual1 { get; set; }

        /// <summary>
        /// Gets or sets MaxCarryOverHours1
        /// </summary>
        [Display(Name = "MaxCarryOverHours1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxCarryOverHours1, Id = Index.MaxCarryOverHours1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxCarryOverHours1 { get; set; }

        /// <summary>
        /// Gets or sets ServiceYear2
        /// </summary>
        [Display(Name = "ServiceYear2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ServiceYear2, Id = Index.ServiceYear2, FieldType = EntityFieldType.Int, Size = 2)]
        public short ServiceYear2 { get; set; }

        /// <summary>
        /// Gets or sets BeginningHours2
        /// </summary>
        [Display(Name = "BeginningHours2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BeginningHours2, Id = Index.BeginningHours2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningHours2 { get; set; }

        /// <summary>
        /// Gets or sets IncrementHours2
        /// </summary>
        [Display(Name = "IncrementHours2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncrementHours2, Id = Index.IncrementHours2, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal IncrementHours2 { get; set; }

        /// <summary>
        /// Gets or sets MaxAnnualAccrual2
        /// </summary>
        [Display(Name = "MaxAnnualAccrual2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxAnnualAccrual2, Id = Index.MaxAnnualAccrual2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxAnnualAccrual2 { get; set; }

        /// <summary>
        /// Gets or sets MaxCarryOverHours2
        /// </summary>
        [Display(Name = "MaxCarryOverHours2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxCarryOverHours2, Id = Index.MaxCarryOverHours2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxCarryOverHours2 { get; set; }

        /// <summary>
        /// Gets or sets ServiceYear3
        /// </summary>
        [Display(Name = "ServiceYear3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ServiceYear3, Id = Index.ServiceYear3, FieldType = EntityFieldType.Int, Size = 2)]
        public short ServiceYear3 { get; set; }

        /// <summary>
        /// Gets or sets BeginningHours3
        /// </summary>
        [Display(Name = "BeginningHours3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BeginningHours3, Id = Index.BeginningHours3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningHours3 { get; set; }

        /// <summary>
        /// Gets or sets IncrementHours3
        /// </summary>
        [Display(Name = "IncrementHours3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncrementHours3, Id = Index.IncrementHours3, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal IncrementHours3 { get; set; }

        /// <summary>
        /// Gets or sets MaxAnnualAccrual3
        /// </summary>
        [Display(Name = "MaxAnnualAccrual3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxAnnualAccrual3, Id = Index.MaxAnnualAccrual3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxAnnualAccrual3 { get; set; }

        /// <summary>
        /// Gets or sets MaxCarryOverHours3
        /// </summary>
        [Display(Name = "MaxCarryOverHours3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxCarryOverHours3, Id = Index.MaxCarryOverHours3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxCarryOverHours3 { get; set; }

        /// <summary>
        /// Gets or sets ServiceYear4
        /// </summary>
        [Display(Name = "ServiceYear4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ServiceYear4, Id = Index.ServiceYear4, FieldType = EntityFieldType.Int, Size = 2)]
        public short ServiceYear4 { get; set; }

        /// <summary>
        /// Gets or sets BeginningHours4
        /// </summary>
        [Display(Name = "BeginningHours4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BeginningHours4, Id = Index.BeginningHours4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningHours4 { get; set; }

        /// <summary>
        /// Gets or sets IncrementHours4
        /// </summary>
        [Display(Name = "IncrementHours4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncrementHours4, Id = Index.IncrementHours4, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal IncrementHours4 { get; set; }

        /// <summary>
        /// Gets or sets MaxAnnualAccrual4
        /// </summary>
        [Display(Name = "MaxAnnualAccrual4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxAnnualAccrual4, Id = Index.MaxAnnualAccrual4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxAnnualAccrual4 { get; set; }

        /// <summary>
        /// Gets or sets MaxCarryOverHours4
        /// </summary>
        [Display(Name = "MaxCarryOverHours4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxCarryOverHours4, Id = Index.MaxCarryOverHours4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxCarryOverHours4 { get; set; }

        /// <summary>
        /// Gets or sets Level
        /// </summary>
        [Display(Name = "Level", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.Level, Id = Index.Level, FieldType = EntityFieldType.Int, Size = 2)]
        public short Level { get; set; }

        /// <summary>
        /// Gets or sets BaseHoursListUse
        /// </summary>
        [Display(Name = "BaseHoursListUse", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BaseHoursListUse, Id = Index.BaseHoursListUse, FieldType = EntityFieldType.Int, Size = 2)]
        public short BaseHoursListUse { get; set; }

        /// <summary>
        /// Gets or sets BaseHoursRegular
        /// </summary>
        [Display(Name = "BaseHoursRegular", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BaseHoursRegular, Id = Index.BaseHoursRegular, FieldType = EntityFieldType.Int, Size = 2)]
        public short BaseHoursRegular { get; set; }

        /// <summary>
        /// Gets or sets BaseHoursOvertime
        /// </summary>
        [Display(Name = "BaseHoursOvertime", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BaseHoursOvertime, Id = Index.BaseHoursOvertime, FieldType = EntityFieldType.Int, Size = 2)]
        public short BaseHoursOvertime { get; set; }

        /// <summary>
        /// Gets or sets BaseEarningsListUse
        /// </summary>
        [Display(Name = "BaseEarningsListUse", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BaseEarningsListUse, Id = Index.BaseEarningsListUse, FieldType = EntityFieldType.Int, Size = 2)]
        public short BaseEarningsListUse { get; set; }

        /// <summary>
        /// Gets or sets BaseEarningsRegular
        /// </summary>
        [Display(Name = "BaseEarningsRegular", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BaseEarningsRegular, Id = Index.BaseEarningsRegular, FieldType = EntityFieldType.Int, Size = 2)]
        public short BaseEarningsRegular { get; set; }

        /// <summary>
        /// Gets or sets BaseEarningsOvertime
        /// </summary>
        [Display(Name = "BaseEarningsOvertime", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BaseEarningsOvertime, Id = Index.BaseEarningsOvertime, FieldType = EntityFieldType.Int, Size = 2)]
        public short BaseEarningsOvertime { get; set; }

        /// <summary>
        /// Gets or sets BaseEarningsShift
        /// </summary>
        [Display(Name = "BaseEarningsShift", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BaseEarningsShift, Id = Index.BaseEarningsShift, FieldType = EntityFieldType.Int, Size = 2)]
        public short BaseEarningsShift { get; set; }

        /// <summary>
        /// Gets or sets BaseDeductionsListUse
        /// </summary>
        [Display(Name = "BaseDeductionsListUse", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BaseDeductionsListUse, Id = Index.BaseDeductionsListUse, FieldType = EntityFieldType.Int, Size = 2)]
        public short BaseDeductionsListUse { get; set; }

        /// <summary>
        /// Gets or sets BaseTaxListUse
        /// </summary>
        [Display(Name = "BaseTaxListUse", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BaseTaxListUse, Id = Index.BaseTaxListUse, FieldType = EntityFieldType.Int, Size = 2)]
        public short BaseTaxListUse { get; set; }

        /// <summary>
        /// Gets or sets ListUseOfTypeOfTaxableWage
        /// </summary>
        [Display(Name = "ListUseOfTypeOfTaxableWage", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ListUseOfTypeOfTaxableWage, Id = Index.ListUseOfTypeOfTaxableWage, FieldType = EntityFieldType.Int, Size = 2)]
        public short ListUseOfTypeOfTaxableWage { get; set; }

        /// <summary>
        /// Gets or sets WithholdingMethodForTaxableW
        /// </summary>
        [Display(Name = "WithholdingMethodForTaxableW", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.WithholdingMethodForTaxableW, Id = Index.WithholdingMethodForTaxableW, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.WithholdingMethodForTaxableW WithholdingMethodForTaxableW { get; set; }

        /// <summary>
        /// Gets or sets TakeDeductionBeforeListUse
        /// </summary>
        [Display(Name = "TakeDeductionBeforeListUse", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.TakeDeductionBeforeListUse, Id = Index.TakeDeductionBeforeListUse, FieldType = EntityFieldType.Int, Size = 2)]
        public short TakeDeductionBeforeListUse { get; set; }

        /// <summary>
        /// Gets or sets ET4BOX
        /// </summary>
        [Display(Name = "ET4BOX", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ET4BOX, Id = Index.ET4BOX, FieldType = EntityFieldType.Int, Size = 2)]
        public short ET4BOX { get; set; }

        /// <summary>
        /// Gets or sets RT4BOX
        /// </summary>
        [Display(Name = "RT4BOX", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.RT4BOX, Id = Index.RT4BOX, FieldType = EntityFieldType.Int, Size = 2)]
        public short RT4BOX { get; set; }

        /// <summary>
        /// Gets or sets ER1BOX
        /// </summary>
        [Display(Name = "ER1BOX", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ER1BOX, Id = Index.ER1BOX, FieldType = EntityFieldType.Int, Size = 2)]
        public short ER1BOX { get; set; }

        /// <summary>
        /// Gets or sets RR1BOX
        /// </summary>
        [Display(Name = "RR1BOX", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.RR1BOX, Id = Index.RR1BOX, FieldType = EntityFieldType.Int, Size = 2)]
        public short RR1BOX { get; set; }

        /// <summary>
        /// Gets or sets EASSOCW2SW
        /// </summary>
        [Display(Name = "EASSOCW2SW", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EASSOCW2SW, Id = Index.EASSOCW2SW, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EASSOCW2SW { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EASSOCTAX
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EASSOCTAX", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EASSOCTAX, Id = Index.EASSOCTAX, FieldType = EntityFieldType.Char, Size = 6)]
        public string EASSOCTAX { get; set; }

        /// <summary>
        /// Gets or sets RASSOCW2SW
        /// </summary>
        [Display(Name = "RASSOCW2SW", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.RASSOCW2SW, Id = Index.RASSOCW2SW, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RASSOCW2SW { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RASSOCTAX
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RASSOCTAX", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.RASSOCTAX, Id = Index.RASSOCTAX, FieldType = EntityFieldType.Char, Size = 6)]
        public string RASSOCTAX { get; set; }

        /// <summary>
        /// Gets or sets PostBenefit
        /// </summary>
        [Display(Name = "PostBenefit", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PostBenefit, Id = Index.PostBenefit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PostBenefit { get; set; }

        /// <summary>
        /// Gets or sets PayAccrual
        /// </summary>
        [Display(Name = "PayAccrual", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.PayAccrual, Id = Index.PayAccrual, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PayAccrual { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets NONPERPYMT
        /// </summary>
        [Display(Name = "NONPERPYMT", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.NONPERPYMT, Id = Index.NONPERPYMT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool NONPERPYMT { get; set; }

        /// <summary>
        /// Gets or sets LinkedEarning
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LinkedEarning", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.LinkedEarning, Id = Index.LinkedEarning, FieldType = EntityFieldType.Char, Size = 6)]
        public string LinkedEarning { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }
        
        /// <summary>
        /// Gets or sets IncludeInFLSAOvertimeCalc
        /// </summary>
        [Display(Name = "IncludeInFLSAOvertimeCalc", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncludeInFLSAOvertimeCalc, Id = Index.IncludeInFLSAOvertimeCalc, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IncludeInFLSAOvertimeCalc { get; set; }

        /// <summary>
        /// Gets or sets ProgressiveCalcCommissions
        /// </summary>
        [Display(Name = "ProgressiveCalcCommissions", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ProgressiveCalcCommissions, Id = Index.ProgressiveCalcCommissions, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ProgressiveCalcCommissions { get; set; }

        /// <summary>
        /// Gets or sets AnnualizedWageBrackets
        /// </summary>
        [Display(Name = "AnnualizedWageBrackets", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.AnnualizedWageBrackets, Id = Index.AnnualizedWageBrackets, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AnnualizedWageBrackets { get; set; }

        /// <summary>
        /// Gets or sets ProgressiveCalcWageBrackets
        /// </summary>
        [Display(Name = "ProgressiveCalcWageBrackets", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ProgressiveCalcWageBrackets, Id = Index.ProgressiveCalcWageBrackets, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ProgressiveCalcWageBrackets { get; set; }

        /// <summary>
        /// Gets or sets ProgressiveCalcPieceRate
        /// </summary>
        [Display(Name = "ProgressiveCalcPieceRate", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ProgressiveCalcPieceRate, Id = Index.ProgressiveCalcPieceRate, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ProgressiveCalcPieceRate { get; set; }

        /// <summary>
        /// Gets or sets EmployeeLifetimeMaximum
        /// </summary>
        [Display(Name = "EmployeeLifetimeMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeLifetimeMaximum, Id = Index.EmployeeLifetimeMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeLifetimeMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerLifetimeMaximum
        /// </summary>
        [Display(Name = "EmployerLifetimeMaximum", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerLifetimeMaximum, Id = Index.EmployerLifetimeMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerLifetimeMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSecRateEffective
        /// </summary>
        [Display(Name = "EmployeeSecRateEffective", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeSecRateEffective, Id = Index.EmployeeSecRateEffective, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployeeSecRateEffective EmployeeSecRateEffective { get; set; }

        /// <summary>
        /// Gets or sets EmployerSecRateEffective
        /// </summary>
        [Display(Name = "EmployerSecRateEffective", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerSecRateEffective, Id = Index.EmployerSecRateEffective, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployerSecRateEffective EmployerSecRateEffective { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSecondaryRate
        /// </summary>
        [Display(Name = "EmployeeSecondaryRate", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployeeSecondaryRate, Id = Index.EmployeeSecondaryRate, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployeeSecondaryRate { get; set; }

        /// <summary>
        /// Gets or sets EmployerSecondaryRate
        /// </summary>
        [Display(Name = "EmployerSecondaryRate", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.EmployerSecondaryRate, Id = Index.EmployerSecondaryRate, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployerSecondaryRate { get; set; }

        /// <summary>
        /// Gets or sets ServiceYear5
        /// </summary>
        [Display(Name = "ServiceYear5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ServiceYear5, Id = Index.ServiceYear5, FieldType = EntityFieldType.Int, Size = 2)]
        public short ServiceYear5 { get; set; }

        /// <summary>
        /// Gets or sets BeginningHours5
        /// </summary>
        [Display(Name = "BeginningHours5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BeginningHours5, Id = Index.BeginningHours5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningHours5 { get; set; }

        /// <summary>
        /// Gets or sets IncrementHours5
        /// </summary>
        [Display(Name = "IncrementHours5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncrementHours5, Id = Index.IncrementHours5, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal IncrementHours5 { get; set; }

        /// <summary>
        /// Gets or sets MaxAnnualAccrual5
        /// </summary>
        [Display(Name = "MaxAnnualAccrual5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxAnnualAccrual5, Id = Index.MaxAnnualAccrual5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxAnnualAccrual5 { get; set; }

        /// <summary>
        /// Gets or sets MaxCarryOverHours5
        /// </summary>
        [Display(Name = "MaxCarryOverHours5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxCarryOverHours5, Id = Index.MaxCarryOverHours5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxCarryOverHours5 { get; set; }

        /// <summary>
        /// Gets or sets ServiceYear6
        /// </summary>
        [Display(Name = "ServiceYear6", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ServiceYear6, Id = Index.ServiceYear6, FieldType = EntityFieldType.Int, Size = 2)]
        public short ServiceYear6 { get; set; }

        /// <summary>
        /// Gets or sets BeginningHours6
        /// </summary>
        [Display(Name = "BeginningHours6", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BeginningHours6, Id = Index.BeginningHours6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningHours6 { get; set; }

        /// <summary>
        /// Gets or sets IncrementHours6
        /// </summary>
        [Display(Name = "IncrementHours6", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncrementHours6, Id = Index.IncrementHours6, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal IncrementHours6 { get; set; }

        /// <summary>
        /// Gets or sets MaxAnnualAccrual6
        /// </summary>
        [Display(Name = "MaxAnnualAccrual6", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxAnnualAccrual6, Id = Index.MaxAnnualAccrual6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxAnnualAccrual6 { get; set; }

        /// <summary>
        /// Gets or sets MaxCarryOverHours6
        /// </summary>
        [Display(Name = "MaxCarryOverHours6", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxCarryOverHours6, Id = Index.MaxCarryOverHours6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxCarryOverHours6 { get; set; }

        /// <summary>
        /// Gets or sets ServiceYear7
        /// </summary>
        [Display(Name = "ServiceYear7", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ServiceYear7, Id = Index.ServiceYear7, FieldType = EntityFieldType.Int, Size = 2)]
        public short ServiceYear7 { get; set; }

        /// <summary>
        /// Gets or sets BeginningHours7
        /// </summary>
        [Display(Name = "BeginningHours7", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BeginningHours7, Id = Index.BeginningHours7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningHours7 { get; set; }

        /// <summary>
        /// Gets or sets IncrementHours7
        /// </summary>
        [Display(Name = "IncrementHours7", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncrementHours7, Id = Index.IncrementHours7, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal IncrementHours7 { get; set; }

        /// <summary>
        /// Gets or sets MaxAnnualAccrual7
        /// </summary>
        [Display(Name = "MaxAnnualAccrual7", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxAnnualAccrual7, Id = Index.MaxAnnualAccrual7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxAnnualAccrual7 { get; set; }

        /// <summary>
        /// Gets or sets MaxCarryOverHours7
        /// </summary>
        [Display(Name = "MaxCarryOverHours7", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxCarryOverHours7, Id = Index.MaxCarryOverHours7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxCarryOverHours7 { get; set; }

        /// <summary>
        /// Gets or sets ServiceYear8
        /// </summary>
        [Display(Name = "ServiceYear8", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ServiceYear8, Id = Index.ServiceYear8, FieldType = EntityFieldType.Int, Size = 2)]
        public short ServiceYear8 { get; set; }

        /// <summary>
        /// Gets or sets BeginningHours8
        /// </summary>
        [Display(Name = "BeginningHours8", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BeginningHours8, Id = Index.BeginningHours8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningHours8 { get; set; }

        /// <summary>
        /// Gets or sets IncrementHours8
        /// </summary>
        [Display(Name = "IncrementHours8", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncrementHours8, Id = Index.IncrementHours8, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal IncrementHours8 { get; set; }

        /// <summary>
        /// Gets or sets MaxAnnualAccrual8
        /// </summary>
        [Display(Name = "MaxAnnualAccrual8", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxAnnualAccrual8, Id = Index.MaxAnnualAccrual8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxAnnualAccrual8 { get; set; }

        /// <summary>
        /// Gets or sets MaxCarryOverHours8
        /// </summary>
        [Display(Name = "MaxCarryOverHours8", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxCarryOverHours8, Id = Index.MaxCarryOverHours8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxCarryOverHours8 { get; set; }

        /// <summary>
        /// Gets or sets ServiceYear9
        /// </summary>
        [Display(Name = "ServiceYear9", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ServiceYear9, Id = Index.ServiceYear9, FieldType = EntityFieldType.Int, Size = 2)]
        public short ServiceYear9 { get; set; }

        /// <summary>
        /// Gets or sets BeginningHours9
        /// </summary>
        [Display(Name = "BeginningHours9", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BeginningHours9, Id = Index.BeginningHours9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningHours9 { get; set; }

        /// <summary>
        /// Gets or sets IncrementHours9
        /// </summary>
        [Display(Name = "IncrementHours9", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncrementHours9, Id = Index.IncrementHours9, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal IncrementHours9 { get; set; }

        /// <summary>
        /// Gets or sets MaxAnnualAccrual9
        /// </summary>
        [Display(Name = "MaxAnnualAccrual9", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxAnnualAccrual9, Id = Index.MaxAnnualAccrual9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxAnnualAccrual9 { get; set; }

        /// <summary>
        /// Gets or sets MaxCarryOverHours9
        /// </summary>
        [Display(Name = "MaxCarryOverHours9", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxCarryOverHours9, Id = Index.MaxCarryOverHours9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxCarryOverHours9 { get; set; }

        /// <summary>
        /// Gets or sets ServiceYear10
        /// </summary>
        [Display(Name = "ServiceYear10", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ServiceYear10, Id = Index.ServiceYear10, FieldType = EntityFieldType.Int, Size = 2)]
        public short ServiceYear10 { get; set; }

        /// <summary>
        /// Gets or sets BeginningHours10
        /// </summary>
        [Display(Name = "BeginningHours10", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BeginningHours10, Id = Index.BeginningHours10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningHours10 { get; set; }

        /// <summary>
        /// Gets or sets IncrementHours10
        /// </summary>
        [Display(Name = "IncrementHours10", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.IncrementHours10, Id = Index.IncrementHours10, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal IncrementHours10 { get; set; }

        /// <summary>
        /// Gets or sets MaxAnnualAccrual10
        /// </summary>
        [Display(Name = "MaxAnnualAccrual10", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxAnnualAccrual10, Id = Index.MaxAnnualAccrual10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxAnnualAccrual10 { get; set; }

        /// <summary>
        /// Gets or sets MaxCarryOverHours10
        /// </summary>
        [Display(Name = "MaxCarryOverHours10", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.MaxCarryOverHours10, Id = Index.MaxCarryOverHours10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaxCarryOverHours10 { get; set; }

        /// <summary>
        /// Gets or sets CostCenterOverrideBasedOnCa
        /// </summary>
        [Display(Name = "CostCenterOverrideBasedOnCa", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CostCenterOverrideBasedOnCa, Id = Index.CostCenterOverrideBasedOnCa, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CostCenterOverrideBasedOnCa { get; set; }

        /// <summary>
        /// Gets or sets BillingRates
        /// </summary>
        [Display(Name = "BillingRates", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BillingRates, Id = Index.BillingRates, FieldType = EntityFieldType.Long, Size = 4)]
        public int BillingRates { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage1
        /// </summary>
        [Display(Name = "BillingPercentage1", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BillingPercentage1, Id = Index.BillingPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage2
        /// </summary>
        [Display(Name = "BillingPercentage2", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BillingPercentage2, Id = Index.BillingPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage3
        /// </summary>
        [Display(Name = "BillingPercentage3", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BillingPercentage3, Id = Index.BillingPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage4
        /// </summary>
        [Display(Name = "BillingPercentage4", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BillingPercentage4, Id = Index.BillingPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage5
        /// </summary>
        [Display(Name = "BillingPercentage5", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BillingPercentage5, Id = Index.BillingPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage6
        /// </summary>
        [Display(Name = "BillingPercentage6", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.BillingPercentage6, Id = Index.BillingPercentage6, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage6 { get; set; }

        /// <summary>
        /// Gets or sets CalculationMaxCarryOverBasedOnR
        /// </summary>
        [Display(Name = "CalculationMaxCarryOverBasedOnR", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CalculationMaxCarryOverBasedOnR, Id = Index.CalculationMaxCarryOverBasedOnR, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CalculationMaxCarryOverBasedOnR { get; set; }

        /// <summary>
        /// Gets or sets CapAccrualAtMaxAccrual
        /// </summary>
        [Display(Name = "CapAccrualAtMaxAccrual", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.CapAccrualAtMaxAccrual, Id = Index.CapAccrualAtMaxAccrual, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CapAccrualAtMaxAccrual { get; set; }

        /// <summary>
        /// Gets or sets ReportAs
        /// </summary>
        [Display(Name = "ReportAs", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ReportAs, Id = Index.ReportAs, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.ReportAs ReportAs { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDCDNOnly
        /// </summary>
        [Display(Name = "RESERVEDCDNOnly", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.RESERVEDCDNOnly, Id = Index.RESERVEDCDNOnly, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.RESERVEDCDNOnly RESERVEDCDNOnly { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (EarningsDeductionResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployeeCommandCode ProcessCommandCode { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Category string value
        /// </summary>
        public string CategoryString => EnumUtility.GetStringValue(Category);

        /// <summary>
        /// Gets Type string value
        /// </summary>
        public string TypeString => EnumUtility.GetStringValue(Type);

        /// <summary>
        /// Gets Frequency string value
        /// </summary>
        public string FrequencyString => EnumUtility.GetStringValue(Frequency);

        /// <summary>
        /// Gets Starts string value
        /// </summary>
        public string StartsString => EnumUtility.GetStringValue(Starts);

        /// <summary>
        /// Gets EmployeeCalculationMethod string value
        /// </summary>
        public string EmployeeCalculationMethodString => EnumUtility.GetStringValue(EmployeeCalculationMethod);

        /// <summary>
        /// Gets EmployeeW2Box string value
        /// </summary>
        public string EmployeeW2BoxString => EnumUtility.GetStringValue(EmployeeW2Box);

        /// <summary>
        /// Gets EmployeeBaseLimit string value
        /// </summary>
        public string EmployeeBaseLimitString => EnumUtility.GetStringValue(EmployeeBaseLimit);

        /// <summary>
        /// Gets EmployerCalculationMethod string value
        /// </summary>
        public string EmployerCalculationMethodString => EnumUtility.GetStringValue(EmployerCalculationMethod);

        /// <summary>
        /// Gets EmployerW2Box string value
        /// </summary>
        public string EmployerW2BoxString => EnumUtility.GetStringValue(EmployerW2Box);

        /// <summary>
        /// Gets EmployerBaseLimit string value
        /// </summary>
        public string EmployerBaseLimitString => EnumUtility.GetStringValue(EmployerBaseLimit);

        /// <summary>
        /// Gets Carryover string value
        /// </summary>
        public string CarryoverString => EnumUtility.GetStringValue(Carryover);

        /// <summary>
        /// Gets WithholdingMethodForTaxableW string value
        /// </summary>
        public string WithholdingMethodForTaxableWString => EnumUtility.GetStringValue(WithholdingMethodForTaxableW);

        /// <summary>
        /// Gets EmployeeSecRateEffective string value
        /// </summary>
        public string EmployeeSecRateEffectiveString => EnumUtility.GetStringValue(EmployeeSecRateEffective);

        /// <summary>
        /// Gets EmployerSecRateEffective string value
        /// </summary>
        public string EmployerSecRateEffectiveString => EnumUtility.GetStringValue(EmployerSecRateEffective);

        /// <summary>
        /// Gets ReportAs string value
        /// </summary>
        public string ReportAsString => EnumUtility.GetStringValue(ReportAs);

        /// <summary>
        /// Gets RESERVEDCDNOnly string value
        /// </summary>
        public string RESERVEDCDNOnlyString => EnumUtility.GetStringValue(RESERVEDCDNOnly);

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

        #endregion
    }
}
