// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CheckHeader
    /// </summary>
    public partial class CheckHeader : SqlModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeCheck", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets EntrySequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntrySequence", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.EntrySequence, Id = Index.EntrySequence, FieldType = EntityFieldType.Long, Size = 9)]
        public int EntrySequence { get; set; }

        /// <summary>
        /// Gets or sets TypeOfCheck
        /// </summary>
        [Display(Name = "TypeOfCheck", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.TypeOfCheck, Id = Index.TypeOfCheck, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.TypeOfCheck TypeOfCheck { get; set; }

        /// <summary>
        /// Gets or sets TypeOfCheckDocument
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TypeOfCheckDocument", ResourceType = typeof(PRCommonResx))]
        [ViewField(Name = Fields.TypeOfCheck, Id = Index.TypeOfCheck, FieldType = EntityFieldType.Char, Size = 8)]
        public string TypeOfCheckDocument { get; set; }

        /// <summary>
        /// Gets or sets BankID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankID", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.BankID, Id = Index.BankID, FieldType = EntityFieldType.Char, Size = 8)]
        public string BankID { get; set; }

        /// <summary>
        /// Gets or sets EFTStatus
        /// </summary>
        [Display(Name = "EFTStatus", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.EFTStatus, Id = Index.EFTStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.EFTStatus EFTStatus { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber
        /// </summary>
        [Display(Name = "CheckNumber", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets CheckDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckDate", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string CheckDate { get; set; }

        /// <summary>
        /// Gets or sets PeriodStartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodStartDate", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.PeriodStartDate, Id = Index.PeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets TimesLateThisPeriodTimecard
        /// </summary>
        [Display(Name = "TimesLateThisPeriodTimecard", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.TimesLateThisPeriodTimecard, Id = Index.TimesLateThisPeriodTimecard, FieldType = EntityFieldType.Int, Size = 2)]
        public short TimesLateThisPeriodTimecard { get; set; }

        /// <summary>
        /// Gets or sets CheckStatus
        /// </summary>
        [Display(Name = "CheckStatus", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.CheckStatus, Id = Index.CheckStatus, FieldType = EntityFieldType.Char, Size = 8)]
        public string CheckStatus { get; set; }

        /// <summary>
        /// Gets or sets PRPostStatus
        /// </summary>
        [Display(Name = "PRPostStatus", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.PRPostStatus, Id = Index.PRPostStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.PRPostStatus PRPostStatus { get; set; }

        /// <summary>
        /// Gets or sets PostingStatus
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PRPostStatus", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.PRPostStatus, Id = Index.PRPostStatus, FieldType = EntityFieldType.Char, Size = 8)]
        public string PostingStatus { get; set; }
        /// <summary>
        /// Gets or sets PayFrequency
        /// </summary>
        [Display(Name = "PayFrequency", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.PayFrequency, Id = Index.PayFrequency, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.PayFrequency PayFrequency { get; set; }

        /// <summary>
        /// Gets or sets Class1
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Class1", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.Class1, Id = Index.Class1, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Class1 { get; set; }

        /// <summary>
        /// Gets or sets Class2
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Class2", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.Class2, Id = Index.Class2, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Class2 { get; set; }

        /// <summary>
        /// Gets or sets Class3
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Class3", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.Class3, Id = Index.Class3, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Class3 { get; set; }

        /// <summary>
        /// Gets or sets Class4
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Class4", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.Class4, Id = Index.Class4, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Class4 { get; set; }

        /// <summary>
        /// Gets or sets BankSerialNumber
        /// </summary>
        [Display(Name = "BankSerialNumber", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.BankSerialNumber, Id = Index.BankSerialNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int BankSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets CalculationSequence
        /// </summary>
        [Display(Name = "CalculationSequence", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.CalculationSequence, Id = Index.CalculationSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int CalculationSequence { get; set; }

        /// <summary>
        /// Gets or sets PostingSequence
        /// </summary>
        [Display(Name = "PostingSequence", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int PostingSequence { get; set; }

        /// <summary>
        /// Gets or sets PayrollPeriod
        /// </summary>
        [Display(Name = "PayrollPeriod", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.PayrollPeriod, Id = Index.PayrollPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public short PayrollPeriod { get; set; }

        /// <summary>
        /// Gets or sets TransactionAmt
        /// </summary>
        [Display(Name = "TransactionAmt", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.TransactionAmt, Id = Index.TransactionAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionAmt { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentOne
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentOne", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.GLSegmentOne, Id = Index.GLSegmentOne, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentOne { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentTwo
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentTwo", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.GLSegmentTwo, Id = Index.GLSegmentTwo, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentTwo { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentThree
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentThree", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.GLSegmentThree, Id = Index.GLSegmentThree, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentThree { get; set; }

        /// <summary>
        /// Gets or sets BankGeneralLedgerAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankGeneralLedgerAccount", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.BankGeneralLedgerAccount, Id = Index.BankGeneralLedgerAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string BankGeneralLedgerAccount { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDCdnOnly
        /// </summary>
        [Display(Name = "RESERVEDCdnOnly", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.RESERVEDCdnOnly, Id = Index.RESERVEDCdnOnly, FieldType = EntityFieldType.Int, Size = 2)]
        public short RESERVEDCdnOnly { get; set; }

        /// <summary>
        /// Gets or sets EmployeeEIID
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeEIID", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.EmployeeEIID, Id = Index.EmployeeEIID, FieldType = EntityFieldType.Char, Size = 6)]
        public string EmployeeEIID { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator
        /// </summary>
        [Display(Name = "RateOperator", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public short RateOperator { get; set; }

        /// <summary>
        /// Gets or sets EFTRunSequence
        /// </summary>
        [Display(Name = "EFTRunSequence", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.EFTRunSequence, Id = Index.EFTRunSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int EFTRunSequence { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets GLDrilldownLink
        /// </summary>
        [Display(Name = "GLDrilldownLink", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.GLDrilldownLink, Id = Index.GLDrilldownLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal GLDrilldownLink { get; set; }

        /// <summary>
        /// Gets or sets OvertimeOverride
        /// </summary>
        [Display(Name = "OvertimeOverride", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.OvertimeOverride, Id = Index.OvertimeOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OvertimeOverride { get; set; }

        /// <summary>
        /// Gets or sets OvertimeCalculation
        /// </summary>
        [Display(Name = "OvertimeCalculation", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.OvertimeCalculation, Id = Index.OvertimeCalculation, FieldType = EntityFieldType.Int, Size = 2)]
        // public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.OvertimeCalculation OvertimeCalculation { get; set; }
        public string OvertimeCalculation { get; set; }
        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool JobRelated { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExchangeRateDate", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.ExchangeRateDate, Id = Index.ExchangeRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExchangeRateDate { get; set; }

        /// <summary>
        /// Gets or sets OriginalType
        /// </summary>
        [Display(Name = "OriginalType", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.OriginalType, Id = Index.OriginalType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.OriginalType OriginalType { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentFour
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentFour", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.GLSegmentFour, Id = Index.GLSegmentFour, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentFour { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentFive
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentFive", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.GLSegmentFive, Id = Index.GLSegmentFive, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentFive { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentSix
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentSix", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.GLSegmentSix, Id = Index.GLSegmentSix, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentSix { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Models.Enums.ProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets NextLineNumber
        /// </summary>
        [Display(Name = "NextLineNumber", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.NextLineNumber, Id = Index.NextLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short NextLineNumber { get; set; }

        /// <summary>
        /// Gets or sets SecurityFlag
        /// </summary>
        [Display(Name = "SecurityFlag", ResourceType = typeof(CheckHeaderResx))]
        [ViewField(Name = Fields.SecurityFlag, Id = Index.SecurityFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public short SecurityFlag { get; set; }

    }
}
