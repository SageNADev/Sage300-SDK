// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeTaxField
    /// </summary>
    public partial class EmployeeTaxField : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets TaxCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxCode", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.TaxCode, Id = Index.TaxCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string TaxCode { get; set; }

        /// <summary>
        /// Gets or sets FieldUseType
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FieldUseType", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.FieldUseType, Id = Index.FieldUseType, FieldType = EntityFieldType.Int, Size = 2)]
        public short FieldUseType { get; set; }

        /// <summary>
        /// Gets or sets FieldSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FieldSequence", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.FieldSequence, Id = Index.FieldSequence, FieldType = EntityFieldType.Int, Size = 2)]
        public short FieldSequence { get; set; }

        /// <summary>
        /// Gets or sets TaxTableFieldNumber
        /// </summary>
        [Display(Name = "TaxTableFieldNumber", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.TaxTableFieldNumber, Id = Index.TaxTableFieldNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxTableFieldNumber { get; set; }

        /// <summary>
        /// Gets or sets FieldDataType
        /// </summary>
        [Display(Name = "FieldDataType", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.FieldDataType, Id = Index.FieldDataType, FieldType = EntityFieldType.Int, Size = 2)]
        public short FieldDataType { get; set; }

        /// <summary>
        /// Gets or sets FieldLength
        /// </summary>
        [Display(Name = "FieldLength", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.FieldLength, Id = Index.FieldLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short FieldLength { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDecimalPlaces
        /// </summary>
        [Display(Name = "NumberOfDecimalPlaces", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.NumberOfDecimalPlaces, Id = Index.NumberOfDecimalPlaces, FieldType = EntityFieldType.Int, Size = 2)]
        public short NumberOfDecimalPlaces { get; set; }

        /// <summary>
        /// Gets or sets Value
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Value", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 24)]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets ParameterName
        /// </summary>
        [StringLength(32, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ParameterName", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.ParameterName, Id = Index.ParameterName, FieldType = EntityFieldType.Char, Size = 32)]
        public string ParameterName { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTemplate
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeTemplate", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.EmployeeTemplate, Id = Index.EmployeeTemplate, FieldType = EntityFieldType.Char, Size = 12)]
        public string EmployeeTemplate { get; set; }

        /// <summary>
        /// Gets or sets TextValue
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TextValue", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 24)]
        public string TextValue { get; set; }

        /// <summary>
        /// Gets or sets BinaryValue
        /// </summary>
        [Display(Name = "BinaryValue", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.BinaryValue, Id = Index.BinaryValue, FieldType = EntityFieldType.Byte, Size = 24)]
        public byte[] BinaryValue { get; set; }

        /// <summary>
        /// Gets or sets DateValue
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateValue", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateValue { get; set; }

        /// <summary>
        /// Gets or sets TimeValue
        /// </summary>
        [Display(Name = "TimeValue", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan TimeValue { get; set; }

        /// <summary>
        /// Gets or sets NumberValue
        /// </summary>
        [Display(Name = "NumberValue", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Real, Size = 8)]
        public double NumberValue { get; set; }

        /// <summary>
        /// Gets or sets AmountValue
        /// </summary>
        [Display(Name = "AmountValue", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal AmountValue { get; set; }

        /// <summary>
        /// Gets or sets IntegerValue
        /// </summary>
        [Display(Name = "IntegerValue", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Int, Size = 2)]
        public short IntegerValue { get; set; }

        /// <summary>
        /// Gets or sets LongValue
        /// </summary>
        [Display(Name = "LongValue", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.LongValue, Id = Index.LongValue, FieldType = EntityFieldType.Long, Size = 4)]
        public int LongValue { get; set; }

        /// <summary>
        /// Gets or sets YesNoValue
        /// </summary>
        [Display(Name = "YesNoValue", ResourceType = typeof (EmployeeTaxFieldResx))]
        [ViewField(Name = Fields.YesNoValue, Id = Index.YesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool YesNoValue { get; set; }

        #region UI Strings

        #endregion
    }
}
