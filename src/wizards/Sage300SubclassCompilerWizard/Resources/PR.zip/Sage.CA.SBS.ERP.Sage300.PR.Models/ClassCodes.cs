// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for ClassCodes
    /// </summary>
    public partial class ClassCodesModel : ModelBase
    {
        /// <summary>
        /// Gets or sets Class
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Class", ResourceType = typeof (ClassCodesResx))]
        [ViewField(Name = Fields.Class, Id = Index.Class, FieldType = EntityFieldType.Int, Size = 2)]
        public short Class { get; set; }

        /// <summary>
        /// Gets or sets ClassCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ClassCode", ResourceType = typeof (ClassCodesResx))]
        [ViewField(Name = Fields.ClassCode, Id = Index.ClassCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ClassCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (ClassCodesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 20)]
        public string Description { get; set; }

        #region UI Strings

        #endregion
    }
}
