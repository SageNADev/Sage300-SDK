    // Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

    #region Namespace

    using System;
    using System.ComponentModel.DataAnnotations;
    using Sage.CA.SBS.ERP.Sage300.Common.Models;
    using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
    using Sage.CA.SBS.ERP.Sage300.Common.Resources;
    using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
    using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
    using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

    #endregion

    namespace Sage.CA.SBS.ERP.Sage300.PR.Models
    {
        /// <summary>
        /// Partial class for TimecardHeader
        /// </summary>
        public partial class TimecardHeader : ModelBase
        {
            /// <summary>
            /// Gets or sets Employee
            /// </summary>
            [Key]
            [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
            [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "Employee", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
            public string Employee { get; set; }

            /// <summary>
            /// Gets or sets PeriodEndDate
            /// </summary>
            [Key]
            [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "PeriodEndDate", ResourceType = typeof (PRCommonResx))]
            [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
            public DateTime? PeriodEndDate { get; set; }

            /// <summary>
            /// Gets or sets Timecard
            /// </summary>
            [Key]
            [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
            [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "Timecard", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.Timecard, Id = Index.Timecard, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
            public string Timecard { get; set; }

            /// <summary>
            /// Gets or sets Description
            /// </summary>
            [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "Description", ResourceType = typeof (PRCommonResx))]
            [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 15)]
            public string Description { get; set; }

            /// <summary>
            /// Gets or sets TimesLate
            /// </summary>
            [Display(Name = "TimesLate", ResourceType = typeof (PRCommonResx))]
            [ViewField(Name = Fields.TimesLate, Id = Index.TimesLate, FieldType = EntityFieldType.Int, Size = 2)]
            public short TimesLate { get; set; }

            /// <summary>
            /// Gets or sets Reusable
            /// </summary>
            [Display(Name = "ReuseTimecard", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.Reusable, Id = Index.Reusable, FieldType = EntityFieldType.Bool, Size = 2)]
            public bool Reusable { get; set; }

            /// <summary>
            /// Gets or sets ActiveFlag
            /// </summary>
            [Display(Name = "Active", ResourceType = typeof (PRCommonResx))]
            [ViewField(Name = Fields.ActiveFlag, Id = Index.ActiveFlag, FieldType = EntityFieldType.Bool, Size = 2)]
            public bool ActiveFlag { get; set; }

            /// <summary>
            /// Gets or sets SeparateCheckFlag
            /// </summary>
            [Display(Name = "SeparateCheckFlag", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.SeparateCheckFlag, Id = Index.SeparateCheckFlag, FieldType = EntityFieldType.Bool, Size = 2)]
            public bool SeparateCheckFlag { get; set; }

            /// <summary>
            /// Gets or sets ProcessedFlag
            /// </summary>
            [Display(Name = "ProcessedFlag", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.ProcessedFlag, Id = Index.ProcessedFlag, FieldType = EntityFieldType.Bool, Size = 2)]
            public bool ProcessedFlag { get; set; }

            /// <summary>
            /// Gets or sets RegularHours
            /// </summary>
            [Display(Name = "RegularHours", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.RegularHours, Id = Index.RegularHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal RegularHours { get; set; }

            /// <summary>
            /// Gets or sets ShiftHours
            /// </summary>
            [Display(Name = "ShiftHours", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.ShiftHours, Id = Index.ShiftHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal ShiftHours { get; set; }

            /// <summary>
            /// Gets or sets VacationHoursPaid
            /// </summary>
            [Display(Name = "VacationHoursPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.VacationHoursPaid, Id = Index.VacationHoursPaid, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal VacationHoursPaid { get; set; }

            /// <summary>
            /// Gets or sets VacationHoursAccrued
            /// </summary>
            [Display(Name = "VacationHoursAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.VacationHoursAccrued, Id = Index.VacationHoursAccrued, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal VacationHoursAccrued { get; set; }

            /// <summary>
            /// Gets or sets SickHoursPaid
            /// </summary>
            [Display(Name = "SickHoursPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.SickHoursPaid, Id = Index.SickHoursPaid, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal SickHoursPaid { get; set; }

            /// <summary>
            /// Gets or sets SickHoursAccrued
            /// </summary>
            [Display(Name = "SickHoursAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.SickHoursAccrued, Id = Index.SickHoursAccrued, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal SickHoursAccrued { get; set; }

            /// <summary>
            /// Gets or sets CompensatoryTimeHoursPaid
            /// </summary>
            [Display(Name = "CompensatoryTimeHoursPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.CompensatoryTimeHoursPaid, Id = Index.CompensatoryTimeHoursPaid, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal CompensatoryTimeHoursPaid { get; set; }

            /// <summary>
            /// Gets or sets CompTimeHoursAccrued
            /// </summary>
            [Display(Name = "CompTimeHoursAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.CompTimeHoursAccrued, Id = Index.CompTimeHoursAccrued, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal CompTimeHoursAccrued { get; set; }

            /// <summary>
            /// Gets or sets VacationDollarsPaid
            /// </summary>
            [Display(Name = "VacationDollarsPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.VacationDollarsPaid, Id = Index.VacationDollarsPaid, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal VacationDollarsPaid { get; set; }

            /// <summary>
            /// Gets or sets VacationDollarsAccrued
            /// </summary>
            [Display(Name = "VacationDollarsAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.VacationDollarsAccrued, Id = Index.VacationDollarsAccrued, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal VacationDollarsAccrued { get; set; }

            /// <summary>
            /// Gets or sets SickTimeDollarsPaid
            /// </summary>
            [Display(Name = "SickTimeDollarsPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.SickTimeDollarsPaid, Id = Index.SickTimeDollarsPaid, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal SickTimeDollarsPaid { get; set; }

            /// <summary>
            /// Gets or sets SickTimeDollarsAccrued
            /// </summary>
            [Display(Name = "SickTimeDollarsAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.SickTimeDollarsAccrued, Id = Index.SickTimeDollarsAccrued, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal SickTimeDollarsAccrued { get; set; }

            /// <summary>
            /// Gets or sets CompTimeDollarsPaid
            /// </summary>
            [Display(Name = "CompTimeDollarsPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.CompTimeDollarsPaid, Id = Index.CompTimeDollarsPaid, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal CompTimeDollarsPaid { get; set; }

            /// <summary>
            /// Gets or sets CompTimeDollarsAccrued
            /// </summary>
            [Display(Name = "CompTimeDollarsAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.CompTimeDollarsAccrued, Id = Index.CompTimeDollarsAccrued, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal CompTimeDollarsAccrued { get; set; }

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Gets or sets CDISIHRSP
            /// </summary>
            [Display(Name = "CDISIHRSP", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.CDISIHRSP, Id = Index.CDISIHRSP, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal CDISIHRSP { get; set; }

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Gets or sets CDISIHRSA
            /// </summary>
            [Display(Name = "CDISIHRSA", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.CDISIHRSA, Id = Index.CDISIHRSA, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal CDISIHRSA { get; set; }

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Gets or sets CDISIAMTP
            /// </summary>
            [Display(Name = "CDISIAMTP", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.CDISIAMTP, Id = Index.CDISIAMTP, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal CDISIAMTP { get; set; }

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Gets or sets CDISIAMTA
            /// </summary>
            [Display(Name = "CDISIAMTA", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.CDISIAMTA, Id = Index.CDISIAMTA, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal CDISIAMTA { get; set; }

            /// <summary>
            /// Gets or sets LastName
            /// </summary>
            [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "LastName", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.LastName, Id = Index.LastName, FieldType = EntityFieldType.Char, Size = 20)]
            public string LastName { get; set; }

            /// <summary>
            /// Gets or sets FirstName
            /// </summary>
            [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "FirstName", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.FirstName, Id = Index.FirstName, FieldType = EntityFieldType.Char, Size = 15)]
            public string FirstName { get; set; }

            /// <summary>
            /// Gets or sets MiddleName
            /// </summary>
            [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "MiddleName", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.MiddleName, Id = Index.MiddleName, FieldType = EntityFieldType.Char, Size = 15)]
            public string MiddleName { get; set; }

            /// <summary>
            /// Gets or sets TotalRegularHours
            /// </summary>
            [Display(Name = "TotalRegularHours", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalRegularHours, Id = Index.TotalRegularHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal TotalRegularHours { get; set; }

            /// <summary>
            /// Gets or sets TotalShiftHours
            /// </summary>
            [Display(Name = "TotalShiftHours", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalShiftHours, Id = Index.TotalShiftHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal TotalShiftHours { get; set; }

            /// <summary>
            /// Gets or sets TotalVacationHoursPaid
            /// </summary>
            [Display(Name = "TotalVacationHoursPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalVacationHoursPaid, Id = Index.TotalVacationHoursPaid, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal TotalVacationHoursPaid { get; set; }

            /// <summary>
            /// Gets or sets TotalVacationHoursAccrued
            /// </summary>
            [Display(Name = "TotalVacationHoursAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalVacationHoursAccrued, Id = Index.TotalVacationHoursAccrued, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal TotalVacationHoursAccrued { get; set; }

            /// <summary>
            /// Gets or sets TotalSickHoursPaid
            /// </summary>
            [Display(Name = "TotalSickHoursPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalSickHoursPaid, Id = Index.TotalSickHoursPaid, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal TotalSickHoursPaid { get; set; }

            /// <summary>
            /// Gets or sets TotalSickHoursAccrued
            /// </summary>
            [Display(Name = "TotalSickHoursAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalSickHoursAccrued, Id = Index.TotalSickHoursAccrued, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal TotalSickHoursAccrued { get; set; }

            /// <summary>
            /// Gets or sets TotalCompTimeHoursPaid
            /// </summary>
            [Display(Name = "TotalCompTimeHoursPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalCompTimeHoursPaid, Id = Index.TotalCompTimeHoursPaid, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal TotalCompTimeHoursPaid { get; set; }

            /// <summary>
            /// Gets or sets TotalCompTimeHoursAccrued
            /// </summary>
            [Display(Name = "TotalCompTimeHoursAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalCompTimeHoursAccrued, Id = Index.TotalCompTimeHoursAccrued, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal TotalCompTimeHoursAccrued { get; set; }

            /// <summary>
            /// Gets or sets TotalVacationDollarsPaid
            /// </summary>
            [Display(Name = "TotalVacationDollarsPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalVacationDollarsPaid, Id = Index.TotalVacationDollarsPaid, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal TotalVacationDollarsPaid { get; set; }

            /// <summary>
            /// Gets or sets TotalVacationDollarsAccrued
            /// </summary>
            [Display(Name = "TotalVacationDollarsAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalVacationDollarsAccrued, Id = Index.TotalVacationDollarsAccrued, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal TotalVacationDollarsAccrued { get; set; }

            /// <summary>
            /// Gets or sets TotalSickTimeDollarsPaid
            /// </summary>
            [Display(Name = "TotalSickTimeDollarsPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalSickTimeDollarsPaid, Id = Index.TotalSickTimeDollarsPaid, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal TotalSickTimeDollarsPaid { get; set; }

            /// <summary>
            /// Gets or sets TotalSickTimeDollarsAccrued
            /// </summary>
            [Display(Name = "TotalSickTimeDollarsAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalSickTimeDollarsAccrued, Id = Index.TotalSickTimeDollarsAccrued, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal TotalSickTimeDollarsAccrued { get; set; }

            /// <summary>
            /// Gets or sets TotalCompTimeDollarsPaid
            /// </summary>
            [Display(Name = "TotalCompTimeDollarsPaid", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalCompTimeDollarsPaid, Id = Index.TotalCompTimeDollarsPaid, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal TotalCompTimeDollarsPaid { get; set; }

            /// <summary>
            /// Gets or sets TotalCompTimeDollarsAccrued
            /// </summary>
            [Display(Name = "TotalCompTimeDollarsAccrued", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalCompTimeDollarsAccrued, Id = Index.TotalCompTimeDollarsAccrued, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal TotalCompTimeDollarsAccrued { get; set; }

            /// <summary>
            /// Gets or sets INTERNALUSEKeyAction
            /// </summary>
            [Display(Name = "INTERNALUSEKeyAction", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.INTERNALUSEKeyAction, Id = Index.INTERNALUSEKeyAction, FieldType = EntityFieldType.Int, Size = 2)]
            public short INTERNALUSEKeyAction { get; set; }

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Gets or sets GDISIHRSP
            /// </summary>
            [Display(Name = "GDISIHRSP", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.GDISIHRSP, Id = Index.GDISIHRSP, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal GDISIHRSP { get; set; }

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Gets or sets GDISIHRSA
            /// </summary>
            [Display(Name = "GDISIHRSA", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.GDISIHRSA, Id = Index.GDISIHRSA, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal GDISIHRSA { get; set; }

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Gets or sets GDISIAMTP
            /// </summary>
            [Display(Name = "GDISIAMTP", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.GDISIAMTP, Id = Index.GDISIAMTP, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal GDISIAMTP { get; set; }

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Gets or sets GDISIAMTA
            /// </summary>
            [Display(Name = "GDISIAMTA", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.GDISIAMTA, Id = Index.GDISIAMTA, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
            public decimal GDISIAMTA { get; set; }

            /// <summary>
            /// Gets or sets HireDate
            /// </summary>
            [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "HireDate", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.HireDate, Id = Index.HireDate, FieldType = EntityFieldType.Date, Size = 5)]
            public DateTime HireDate { get; set; }

            /// <summary>
            /// Gets or sets TerminationDate
            /// </summary>
            [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "TerminationDate", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TerminationDate, Id = Index.TerminationDate, FieldType = EntityFieldType.Date, Size = 5)]
            public DateTime TerminationDate { get; set; }

            /// <summary>
            /// Gets or sets PartTime
            /// </summary>
            [Display(Name = "PartTime", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.PartTime, Id = Index.PartTime, FieldType = EntityFieldType.Bool, Size = 2)]
            public bool PartTime { get; set; }

            /// <summary>
            /// Gets or sets PayFrequency
            /// </summary>
            [Display(Name = "PayFrequency", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.PayFrequency, Id = Index.PayFrequency, FieldType = EntityFieldType.Int, Size = 2)]
            public short PayFrequency { get; set; }

            /// <summary>
            /// Gets or sets OvertimeSchedule
            /// </summary>
            [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "OvertimeSchedule", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.OvertimeSchedule, Id = Index.OvertimeSchedule, FieldType = EntityFieldType.Char, Size = 6)]
            public string OvertimeSchedule { get; set; }

            /// <summary>
            /// Gets or sets CompTimeID
            /// </summary>
            [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "CompTimeID", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.CompTimeID, Id = Index.CompTimeID, FieldType = EntityFieldType.Char, Size = 6)]
            public string CompTimeID { get; set; }

            /// <summary>
            /// Gets or sets ShiftDifferentialSchedule
            /// </summary>
            [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "ShiftDifferentialSchedule", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.ShiftDifferentialSchedule, Id = Index.ShiftDifferentialSchedule, FieldType = EntityFieldType.Char, Size = 6)]
            public string ShiftDifferentialSchedule { get; set; }

            /// <summary>
            /// Gets or sets ShiftNumber
            /// </summary>
            [Display(Name = "ShiftNumber", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.ShiftNumber, Id = Index.ShiftNumber, FieldType = EntityFieldType.Int, Size = 2)]
            public short ShiftNumber { get; set; }

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Gets or sets WORKPROV
            /// </summary>
            [Display(Name = "WORKPROV", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.WORKPROV, Id = Index.WORKPROV, FieldType = EntityFieldType.Int, Size = 2)]
            public short WORKPROV { get; set; }

            /// <summary>
            /// Gets or sets EmploymentStatus
            /// </summary>
            [Display(Name = "EmploymentStatus", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.EmploymentStatus, Id = Index.EmploymentStatus, FieldType = EntityFieldType.Int, Size = 2)]
            public short EmploymentStatus { get; set; }

            /// <summary>
            /// Gets or sets InactiveDate
            /// </summary>
            [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "InactiveDate", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
            public DateTime InactiveDate { get; set; }

            /// <summary>
            /// Gets or sets ProcessCommandCode
            /// </summary>
            [Display(Name = "Type", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
            public TimecardProcessCommandCode ProcessCommandCode { get; set; }

            /// <summary>
            /// Gets or sets TotalOvertimeHours
            /// </summary>
            [Display(Name = "TotalOvertimeHours", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalOvertimeHours, Id = Index.TotalOvertimeHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal TotalOvertimeHours { get; set; }

            /// <summary>
            /// Gets or sets OvertimeCalculation
            /// </summary>
            [Display(Name = "OvertimeCalculation", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.OvertimeCalculation, Id = Index.OvertimeCalculation, FieldType = EntityFieldType.Int, Size = 2)]
            public short OvertimeCalculation { get; set; }

            /// <summary>
            /// Gets or sets RegularHoursPerDay
            /// </summary>
            [Display(Name = "RegularHoursPerDay", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.RegularHoursPerDay, Id = Index.RegularHoursPerDay, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal RegularHoursPerDay { get; set; }

            /// <summary>
            /// Gets or sets WorkClassification
            /// </summary>
            [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "WorkClassification", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.WorkClassification, Id = Index.WorkClassification, FieldType = EntityFieldType.Char, Size = 6)]
            public string WorkClassification { get; set; }

            /// <summary>
            /// Gets or sets TotalJobs
            /// </summary>
            [Display(Name = "TotalJobs", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TotalJobs, Id = Index.TotalJobs, FieldType = EntityFieldType.Long, Size = 4)]
            public int TotalJobs { get; set; }

            /// <summary>
            /// Gets or sets SecurityFlag
            /// </summary>
            [Display(Name = "SecurityFlag", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.SecurityFlag, Id = Index.SecurityFlag, FieldType = EntityFieldType.Int, Size = 2)]
            public short SecurityFlag { get; set; }

            /// <summary>
            /// Gets or sets CalcOTOnAWeeklyBasis
            /// </summary>
            [Display(Name = "CalcOTOnAWeeklyBasis", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.CalcOTOnAWeeklyBasis, Id = Index.CalcOTOnAWeeklyBasis, FieldType = EntityFieldType.Bool, Size = 2)]
            public bool CalcOTOnAWeeklyBasis { get; set; }

            /// <summary>
            /// Gets or sets NumberOfOptionalFields
            /// </summary>
            [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
            public int NumberOfOptionalFields { get; set; }

            /// <summary>
            ///  Gets or sets HasOptionalFields
            /// </summary>
            public bool HasOptionalFields { get; set; }
        
            /// <summary>
            /// Gets or sets OvertimeOverride
            /// </summary>
            [Display(Name = "OvertimeOverride", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.OvertimeOverride, Id = Index.OvertimeOverride, FieldType = EntityFieldType.Bool, Size = 2)]
            public bool OvertimeOverride { get; set; }

            /// <summary>
            /// Gets or sets OvertimeHours
            /// </summary>
            [Display(Name = "OvertimeHours", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.OvertimeHours, Id = Index.OvertimeHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
            public decimal OvertimeHours { get; set; }

            /// <summary>
            /// Gets or sets TimecardLines
            /// </summary>
            [Display(Name = "TimecardLines", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.TimecardLines, Id = Index.TimecardLines, FieldType = EntityFieldType.Int, Size = 2)]
            public short TimecardLines { get; set; }

            /// <summary>
            /// Gets or sets JobRelated
            /// </summary>
            [Display(Name = "JobRelated", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
            public bool JobRelated { get; set; }

            /// <summary>
            /// Gets or sets SourceApplication
            /// </summary>
            [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
            [Display(Name = "SourceApplication", ResourceType = typeof (TimecardHeaderResx))]
            [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
            public string SourceApplication { get; set; }

            #region UI Strings

            /// <summary>
            /// Gets ProcessCommandCode string value
            /// </summary>
            public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

            #endregion
        }
    }
