/* Copyright (c) 1994-2024 Sage Software, Inc.  All rights reserved. */

#region

using System.Collections;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Class OptionalFieldLocations.
    /// </summary>
    public partial class OptionalFieldLocations : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OptionalFieldLocations"/> class.
        /// </summary>
        public OptionalFieldLocations()
        {
            OptionalFields = new EnumerableResponse<OptionalFields>();
        }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        /// <value>The location.</value>
        [Display(Name = "TypeCount", ResourceType = typeof(OptionalFieldsResx))]
        [Key]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public OptionalFieldLocation Location { get; set; }

        /// <summary>
        /// Gets or sets NumberofValues
        /// </summary>
        /// <value>The numberof values.</value>
        [Display(Name = "NumberofValues", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.NumberofValues, Id = Index.NumberofValues, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofValues { get; set; }

        /// <summary>
        /// To get Language list from Enum
        /// </summary>
        /// <value>The location list.</value>
        public IEnumerable LocationList
        {
            get { return EnumUtility.GetItems<OptionalFieldLocation>(OptionalFieldLocation.Employee); }
        }

        /// <summary>
        /// Gets or sets OptFields
        /// </summary>
        /// <value>The optional fields.</value>
        public EnumerableResponse<OptionalFields> OptionalFields { get; set; }
    }
}
