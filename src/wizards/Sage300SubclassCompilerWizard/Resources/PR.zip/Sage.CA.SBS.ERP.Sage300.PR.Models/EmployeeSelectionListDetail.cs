// Copyright (c) 2024 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using System.Collections.Generic;

#endregion


namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeSelectionList
    /// </summary>
    public partial class EmployeeSelectionListDetailModel : SqlModelBase
    {
        /// <summary>
        /// Gets or sets EmployeeList
        /// </summary>
        [Key]
        [ViewField(Name = Fields.EmployeeSelectionList, Id = Index.EmployeeSelectionList, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EmployeeSelectionList { get; set; }

        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

    }
}