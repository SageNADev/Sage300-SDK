// Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeEarningsDeduction
    /// </summary>
    public partial class EmployeeEarningsDeduction : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets EmployeeEarningDeduction
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeEarningDeduction", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeeEarningDeduction, Id = Index.EmployeeEarningDeduction, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EmployeeEarningDeduction { get; set; }

        /// <summary>
        /// Gets or sets Calculate
        /// </summary>
        [Display(Name = "Calculate", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.Calculate, Id = Index.Calculate, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Calculate { get; set; }

        /// <summary>
        /// Gets or sets StartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartDate", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets EndDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndDate", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EndDate, Id = Index.EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? EndDate { get; set; }


        /// <summary>
        /// Gets or sets SegmentName1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentName1", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.SegmentName1, Id = Index.SegmentName1, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentName1 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentName2", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.SegmentName2, Id = Index.SegmentName2, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentName2 { get; set; }

        /// <summary>
        /// Gets or sets SegmentName3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentName3", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.SegmentName3, Id = Index.SegmentName3, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentName3 { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets EmployeeRateAmountPercent
        /// </summary>
        [Display(Name = "EmployeeRateAmtPct", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeeRateAmountPercent, Id = Index.EmployeeRateAmountPercent, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployeeRateAmountPercent { get; set; }

        /// <summary>
        /// Gets or sets EmployerAmtPct
        /// </summary>
        [Display(Name = "EmployerAmtPct", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerRateAmountPercent, Id = Index.EmployerRateAmountPercent, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployerRateAmountPercent { get; set; }

        /// <summary>
        /// Gets or sets WorkersCompensationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkersCompensationCode", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.WorkersCompensationCode, Id = Index.WorkersCompensationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string WorkersCompensationCode { get; set; }

        /// <summary>
        /// Gets or sets AdvanceToBeRepaid
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdvanceToBeRepaid", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.AdvanceToBeRepaid, Id = Index.AdvanceToBeRepaid, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AdvanceToBeRepaid { get; set; }

        /// <summary>
        /// Gets or sets Carryover
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Carryover", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.Carryover, Id = Index.Carryover, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? Carryover { get; set; }

        /// <summary>
        /// Gets or sets Balance
        /// </summary>
        [Display(Name = "Balance", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.Balance, Id = Index.Balance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Balance { get; set; }

        /// <summary>
        /// Gets or sets Accrued
        /// </summary>
        [Display(Name = "Accrued", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.Accrued, Id = Index.Accrued, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Accrued { get; set; }

        /// <summary>
        /// Gets or sets Paid
        /// </summary>
        [Display(Name = "Paid", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.Paid, Id = Index.Paid, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Paid { get; set; }

        /// <summary>
        /// Gets or sets DefaultHours
        /// </summary>
        [Display(Name = "DefaultHours", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.DefaultHours, Id = Index.DefaultHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal DefaultHours { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [Display(Name = "Category", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.CategoryCode Category { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EarningDeductionTaxType, Id = Index.EarningDeductionTaxType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.EarningDeductionTaxType EarningDeductionTaxType { get; set; }

        /// <summary>
        /// Gets or sets AmountPaid
        /// </summary>
        [Display(Name = "AmountPaid", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.AmountPaid, Id = Index.AmountPaid, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountPaid { get; set; }

        /// <summary>
        /// Gets or sets AvailableInEmployeeTimecards
        /// </summary>
        [Display(Name = "AvailableInEmployeeTimecards", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.AvailableInEmployeeTimecards, Id = Index.AvailableInEmployeeTimecards, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AvailableInEmployeeTimecards { get; set; }

        /// <summary>
        /// Gets or sets WorkersCompGroup
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkersCompGroup", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.WorkersCompensationGroup, Id = Index.WorkersCompensationGroup, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string WorkersCompensationGroup { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets IncludeInFLSAOvertimeCalc
        /// </summary>
        [Display(Name = "IncludeinFLSACalculation", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.IncludeInRegularRateOvertimeCalc, Id = Index.IncludeInRegularRateOvertimeCalc, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IncludeInRegularRateOvertimeCalc { get; set; }

        /// <summary>
        /// Gets or sets EmployeePeriodMinimum
        /// </summary>
        [Display(Name = "EmployeePeriodMinimum", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeePeriodMinimum, Id = Index.EmployeePeriodMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeePeriodMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeePeriodMaximum
        /// </summary>
        [Display(Name = "EmployeePeriodMaximum", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeePeriodMaximum, Id = Index.EmployeePeriodMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeePeriodMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeAnnualMaximum
        /// </summary>
        [Display(Name = "EmployeeAnnualMaximum", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeeAnnualMaximum, Id = Index.EmployeeAnnualMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeAnnualMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeLifetimeMaximum
        /// </summary>
        [Display(Name = "EmployeeLifetimeMaximum", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeeLifetimeMaximum, Id = Index.EmployeeLifetimeMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeLifetimeMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeLifetimeAccumulation
        /// </summary>
        [Display(Name = "EmployeeLifetimeAccumulation", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeeLifetimeAccumulation, Id = Index.EmployeeLifetimeAccumulation, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeLifetimeAccumulation { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSecondaryRateAmountPercent
        /// </summary>
        [Display(Name = "EmployeeSecondaryRateAmtPct", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeeSecondaryRateAmountPercent, Id = Index.EmployeeSecondaryRateAmountPercent, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployeeSecondaryRateAmountPercent { get; set; }

        /// <summary>
        /// Gets or sets EmployerPeriodMinimum
        /// </summary>
        [Display(Name = "EmployerPeriodMinimum", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerPeriodMinimum, Id = Index.EmployerPeriodMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerPeriodMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerPeriodMaximum
        /// </summary>
        [Display(Name = "EmployerPeriodMaximum", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerPeriodMaximum, Id = Index.EmployerPeriodMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerPeriodMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerAnnualMaximum
        /// </summary>
        [Display(Name = "EmployerAnnualMaximum", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerAnnualMaximum, Id = Index.EmployerAnnualMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerAnnualMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerLifetimeMaximum
        /// </summary>
        [Display(Name = "EmployerLifetimeMaximum", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerLifetimeMaximum, Id = Index.EmployerLifetimeMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerLifetimeMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerLifetimeAccumulation
        /// </summary>
        [Display(Name = "EmployerLifetimeAccumulation", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerLifetimeAccumulation, Id = Index.EmployerLifetimeAccumulation, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerLifetimeAccumulation { get; set; }

        /// <summary>
        /// Gets or sets EmployerSecondaryAmountPercent
        /// </summary>
        [Display(Name = "EmployerSecondaryAmtPct", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerSecondaryAmountPercent, Id = Index.EmployerSecondaryAmountPercent, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployerSecondaryAmountPercent { get; set; }

        /// <summary>
        /// Gets or sets TemplateEmployee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TemplateEmployee", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.TemplateEmployee, Id = Index.TemplateEmployee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TemplateEmployee { get; set; }

        /// <summary>
        /// Gets or sets EmployeeCalcMethod
        /// </summary>
        [Display(Name = "EmployeeCalcMethod", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeeCalcMethod, Id = Index.EmployeeCalcMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployeeCalcMethod { get; set; }

        /// <summary>
        /// Gets or sets EmployerCalcMethod
        /// </summary>
        [Display(Name = "EmployerCalcMethod", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerCalcMethod, Id = Index.EmployerCalcMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployerCalcMethod { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.EmployeeCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets EarningDeductionDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningDeductionDescription", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EarningDeductionDescription, Id = Index.EarningDeductionDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string EarningDeductionDescription { get; set; }

        /// <summary>
        /// Gets or sets EmployeeBaseLimit
        /// </summary>
        [Display(Name = "EmployeeBaseLimit", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeeBaseLimit, Id = Index.EmployeeBaseLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployeeBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets EmployerBaseLimit
        /// </summary>
        [Display(Name = "EmployerBaseLimit", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerBaseLimit, Id = Index.EmployerBaseLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployerBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSecondaryRateEffective
        /// </summary>
        [Display(Name = "EmployeeSecondaryRateEffectiv", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployeeSecondaryRateEffective, Id = Index.EmployeeSecondaryRateEffective, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployeeSecondaryRateEffective { get; set; }

        /// <summary>
        /// Gets or sets EmployerSecondaryRateEffective
        /// </summary>
        [Display(Name = "EmployerSecondaryRateEffectiv", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerSecondaryRateEffective, Id = Index.EmployerSecondaryRateEffective, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployerSecondaryRateEffective { get; set; }

        /// <summary>
        /// Gets or sets BillingRates
        /// </summary>
        [Display(Name = "BillingRates", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.BillingRates, Id = Index.BillingRates, FieldType = EntityFieldType.Long, Size = 4)]
        //public int BillingRates { get; set; }
        public bool BillingRates { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage1
        /// </summary>
        [Display(Name = "BillingPercentage1", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.BillingPercentage1, Id = Index.BillingPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage2
        /// </summary>
        [Display(Name = "BillingPercentage2", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.BillingPercentage2, Id = Index.BillingPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage3
        /// </summary>
        [Display(Name = "BillingPercentage3", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.BillingPercentage3, Id = Index.BillingPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage4
        /// </summary>
        [Display(Name = "BillingPercentage4", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.BillingPercentage4, Id = Index.BillingPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage5
        /// </summary>
        [Display(Name = "BillingPercentage5", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.BillingPercentage5, Id = Index.BillingPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets BillingPercentage6
        /// </summary>
        [Display(Name = "BillingPercentage6", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.BillingPercentage6, Id = Index.BillingPercentage6, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingPercentage6 { get; set; }

        /// <summary>
        /// Gets or sets JobsAllocationBasedOnCalcBase
        /// </summary>
        [Display(Name = "JobsAllocatedBasedonCalcBase", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.JobsAllocationBasedOnCalcBase, Id = Index.JobsAllocationBasedOnCalcBase, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool JobsAllocationBasedOnCalcBase { get; set; }

        /// <summary>
        /// Gets or sets ReservedSegmentName4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RESERVEDSegmentName4", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.ReservedSegmentName4, Id = Index.ReservedSegmentName4, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ReservedSegmentName4 { get; set; }

        /// <summary>
        /// Gets or sets ReservedSegmentName5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RESERVEDSegmentName5", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.ReservedSegmentName5, Id = Index.ReservedSegmentName5, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ReservedSegmentName5 { get; set; }

        /// <summary>
        /// Gets or sets ReservedSegmentName6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RESERVEDSegmentName6", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.ReservedSegmentName6, Id = Index.ReservedSegmentName6, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string ReservedSegmentName6 { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Category string value
        /// </summary>
        public string CategoryString => EnumUtility.GetStringValue(Category);

        /// <summary>
        /// Gets Type string value
        /// </summary>
        public string TypeString => EnumUtility.GetStringValue(EarningDeductionTaxType);

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

        #endregion
    }
}
