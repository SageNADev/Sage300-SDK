// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms; 

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeTimecardHeader
    /// </summary>
    public partial class EmployeeTimecardHeader : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets EndDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndDate", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.EndDate, Id = Index.EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 15)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.Status Status { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets UniqueKeyField
        /// </summary>
        [Display(Name = "UniqueKeyField", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.UniqueKeyField, Id = Index.UniqueKeyField, FieldType = EntityFieldType.Int, Size = 2)]
        public short UniqueKeyField { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool JobRelated { get; set; }

        /// <summary>
        /// Gets or sets StartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartDate", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Gets or sets TotalHours
        /// </summary>
        [Display(Name = "TotalHours", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.TotalHours, Id = Index.TotalHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal TotalHours { get; set; }

        /// <summary>
        /// Gets or sets TotalTips
        /// </summary>
        [Display(Name = "TotalTips", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.TotalTips, Id = Index.TotalTips, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTips { get; set; }

        /// <summary>
        /// Gets or sets TotalExpenses
        /// </summary>
        [Display(Name = "TotalExpenses", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.TotalExpenses, Id = Index.TotalExpenses, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalExpenses { get; set; }

        /// <summary>
        /// Gets or sets ProcessControlCode
        /// </summary>
        [Display(Name = "ProcessControlCode", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.ProcessControlCode, Id = Index.ProcessControlCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessControlCode ProcessControlCode { get; set; }

        /// <summary>
        /// Gets or sets DefaultShiftSchedule
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultShiftSchedule", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.DefaultShiftSchedule, Id = Index.DefaultShiftSchedule, FieldType = EntityFieldType.Char, Size = 6)]
        public string DefaultShiftSchedule { get; set; }

        /// <summary>
        /// Gets or sets DefaultShiftNumber
        /// </summary>
        [Display(Name = "DefaultShiftNumber", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.DefaultShiftNumber, Id = Index.DefaultShiftNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short DefaultShiftNumber { get; set; }

        /// <summary>
        /// Gets or sets PartTime
        /// </summary>
        [Display(Name = "PartTime", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.PartTime, Id = Index.PartTime, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PartTime { get; set; }

        /// <summary>
        /// Gets or sets EmploymentStatus
        /// </summary>
        [Display(Name = "EmploymentStatus", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.EmploymentStatus, Id = Index.EmploymentStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmploymentStatus { get; set; }

        /// <summary>
        /// Gets or sets HireDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "HireDate", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.HireDate, Id = Index.HireDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime HireDate { get; set; }

        /// <summary>
        /// Gets or sets TerminationDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TerminationDate", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.TerminationDate, Id = Index.TerminationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TerminationDate { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets TotalPieces
        /// </summary>
        [Display(Name = "TotalPieces", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.TotalPieces, Id = Index.TotalPieces, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalPieces { get; set; }

        /// <summary>
        /// Gets or sets TotalSales
        /// </summary>
        [Display(Name = "TotalSales", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.TotalSales, Id = Index.TotalSales, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalSales { get; set; }

        /// <summary>
        /// Gets or sets WorkClassification
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkClassification", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.WorkClassification, Id = Index.WorkClassification, FieldType = EntityFieldType.Char, Size = 6)]
        public string WorkClassification { get; set; }

        /// <summary>
        /// Gets or sets TotalJobs
        /// </summary>
        [Display(Name = "TotalJobs", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.TotalJobs, Id = Index.TotalJobs, FieldType = EntityFieldType.Long, Size = 4)]
        public int TotalJobs { get; set; }

        /// <summary>
        /// Gets or sets TotalSickPayments
        /// </summary>
        [Display(Name = "TotalSickPayments", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.TotalSickPayments, Id = Index.TotalSickPayments, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal TotalSickPayments { get; set; }

        /// <summary>
        /// Gets or sets TotalVacationPayments
        /// </summary>
        [Display(Name = "TotalVacationPayments", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.TotalVacationPayments, Id = Index.TotalVacationPayments, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal TotalVacationPayments { get; set; }

        /// <summary>
        /// Gets or sets UserSec
        /// </summary>
        [Display(Name = "UserSec", ResourceType = typeof (EmployeeTimecardResx))]
        [ViewField(Name = Fields.UserSec, Id = Index.UserSec, FieldType = EntityFieldType.Int, Size = 2)]
        public short UserSec { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
         get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets ProcessControlCode string value
        /// </summary>
        public string ProcessControlCodeString
        {
         get { return EnumUtility.GetStringValue(ProcessControlCode); }
        }

        #endregion
    }
}
