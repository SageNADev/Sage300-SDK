// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CheckEFTDetail
    /// </summary>
    public partial class CheckEFTDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets EntrySequenceByEmployee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntrySequenceByEmployee", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.EntrySequenceByEmployee, Id = Index.EntrySequenceByEmployee, FieldType = EntityFieldType.Long, Size = 4)]
        public int EntrySequenceByEmployee { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.CategoryCode CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets UniqueKeyField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UniqueKeyField", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.UniqueKeyField, Id = Index.UniqueKeyField, FieldType = EntityFieldType.Int, Size = 2)]
        public short UniqueKeyField { get; set; }

        /// <summary>
        /// Gets or sets BankAccountCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankAccountCode", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.BankAccountCode, Id = Index.BankAccountCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BankAccountCode { get; set; }

        /// <summary>
        /// Gets or sets PresentationListTypePay
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PresentationListTypePay", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.PresentationListTypePay, Id = Index.PresentationListTypePay, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.PresentationListTypePay PresentationListTypePay { get; set; }

        /// <summary>
        /// Gets or sets BaseAmount
        /// </summary>
        [Display(Name = "BaseAmount", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.BaseAmount, Id = Index.BaseAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BaseAmount { get; set; }

        /// <summary>
        /// Gets or sets AmtPctToBeDeposited
        /// </summary>
        [Display(Name = "AmtPctToBeDeposited", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.AmtPctToBeDeposited, Id = Index.AmtPctToBeDeposited, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal AmtPctToBeDeposited { get; set; }

        /// <summary>
        /// Gets or sets DepositAmount
        /// </summary>
        [Display(Name = "DepositAmount", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.DepositAmount, Id = Index.DepositAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositAmount { get; set; }

        /// <summary>
        /// Gets or sets PrintCategory
        /// </summary>
        [Display(Name = "PrintCategory", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.PrintCategory, Id = Index.PrintCategory, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.PrintCategory PrintCategory { get; set; }

        /// <summary>
        /// Gets or sets PrintLineType
        /// </summary>
        [Display(Name = "PrintLineType", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.PrintLineType, Id = Index.PrintLineType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.PrintLineType PrintLineType { get; set; }

        /// <summary>
        /// Gets or sets PrintLineContents
        /// </summary>
        [Display(Name = "PrintLineContents", ResourceType = typeof (CheckEFTDetailResx))]
        [ViewField(Name = Fields.PrintLineContents, Id = Index.PrintLineContents, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.PrintLineContents PrintLineContents { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets CategoryCode string value
        /// </summary>
        public string CategoryCodeString => EnumUtility.GetStringValue(CategoryCode);

        /// <summary>
        /// Gets PresentationListTypePay string value
        /// </summary>
        public string PresentationListTypePayString => EnumUtility.GetStringValue(PresentationListTypePay);

        /// <summary>
        /// Gets PrintCategory string value
        /// </summary>
        public string PrintCategoryString => EnumUtility.GetStringValue(PrintCategory);

        /// <summary>
        /// Gets PrintLineType string value
        /// </summary>
        public string PrintLineTypeString => EnumUtility.GetStringValue(PrintLineType);

        /// <summary>
        /// Gets PrintLineContents string value
        /// </summary>
        public string PrintLineContentsString => EnumUtility.GetStringValue(PrintLineContents);

        #endregion
    }
}
