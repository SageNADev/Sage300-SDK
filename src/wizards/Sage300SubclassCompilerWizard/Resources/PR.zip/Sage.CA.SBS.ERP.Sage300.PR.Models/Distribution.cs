// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for Distribution
    /// </summary>
    public partial class Distribution : ModelBase
    {
        /// <summary>
        /// Gets or sets EarningDeduction
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningDeduction", ResourceType = typeof (DistributionResx))]
        [ViewField(Name = Fields.EarningDeduction, Id = Index.EarningDeduction, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EarningDeduction { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof (DistributionResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets DistributionDescription
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionDescription", ResourceType = typeof (DistributionResx))]
        [ViewField(Name = Fields.DistributionDescription, Id = Index.DistributionDescription, FieldType = EntityFieldType.Char, Size = 15)]
        public string DistributionDescription { get; set; }

        /// <summary>
        /// Gets or sets RegularExpenseGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RegularExpenseGLAccount", ResourceType = typeof (DistributionResx))]
        [ViewField(Name = Fields.RegularExpenseGLAccount, Id = Index.RegularExpenseGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string RegularExpenseGLAccount { get; set; }

        /// <summary>
        /// Gets or sets OvertimeExpenseGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OvertimeExpenseGLAccount", ResourceType = typeof (DistributionResx))]
        [ViewField(Name = Fields.OvertimeExpenseGLAccount, Id = Index.OvertimeExpenseGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string OvertimeExpenseGLAccount { get; set; }

        /// <summary>
        /// Gets or sets ShiftDifferentialExpGLAcct
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiftDifferentialExpGLAcct", ResourceType = typeof (DistributionResx))]
        [ViewField(Name = Fields.ShiftDifferentialExpGLAcct, Id = Index.ShiftDifferentialExpGLAcct, FieldType = EntityFieldType.Char, Size = 45)]
        public string ShiftDifferentialExpGLAcct { get; set; }

        /// <summary>
        /// Gets or sets EmployeeLiabilityGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeLiabilityGLAccount", ResourceType = typeof (DistributionResx))]
        [ViewField(Name = Fields.EmployeeLiabilityGLAccount, Id = Index.EmployeeLiabilityGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string EmployeeLiabilityGLAccount { get; set; }

        /// <summary>
        /// Gets or sets EmployerLiabilityGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployerLiabilityGLAccount", ResourceType = typeof (DistributionResx))]
        [ViewField(Name = Fields.EmployerLiabilityGLAccount, Id = Index.EmployerLiabilityGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string EmployerLiabilityGLAccount { get; set; }

        /// <summary>
        /// Gets or sets AdvancesReceivableGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdvancesReceivableGLAccount", ResourceType = typeof (DistributionResx))]
        [ViewField(Name = Fields.AdvancesReceivableGLAccount, Id = Index.AdvancesReceivableGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string AdvancesReceivableGLAccount { get; set; }

        #region UI Strings

        #endregion
    }
}
