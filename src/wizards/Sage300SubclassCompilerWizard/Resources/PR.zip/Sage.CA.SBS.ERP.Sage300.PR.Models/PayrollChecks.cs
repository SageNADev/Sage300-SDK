﻿// Copyright (c) 2023-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for PayrollChecks
    /// </summary>
    public partial class PayrollChecks : ModelBase
    {
        /// <summary>
        /// Gets or sets Bank
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Bank", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.Bank, Id = Index.Bank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Bank { get; set; }

        /// <summary>
        /// Gets or sets BankName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankName", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.BankName, Id = Index.BankName, FieldType = EntityFieldType.Char, Size = 60)]
        public string BankName { get; set; }

        /// <summary>
        /// Gets or sets CheckStockForm
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckStockForm", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.CheckStockForm, Id = Index.CheckStockForm, FieldType = EntityFieldType.Char, Size = 6)]
        public string CheckStockForm { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayPeriodEndDate", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets DetailLevel
        /// </summary>
        [Display(Name = "DetailLevel", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.DetailLevel, Id = Index.DetailLevel, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.DetailLevel DetailLevel { get; set; }

        /// <summary>
        /// Gets or sets SortChecksBy
        /// </summary>
        [Display(Name = "SortChecksBy", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.SortChecksBy, Id = Index.SortChecksBy, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.SortChecksBy SortChecksBy { get; set; }

        /// <summary>
        /// Gets or sets ThenBy
        /// </summary>
        [Display(Name = "ThenBy", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.ThenBy, Id = Index.ThenBy, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.ThenChecksBy ThenBy { get; set; }

        /// <summary>
        /// Gets or sets Class
        /// </summary>
        [Display(Name = "Class", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.Class, Id = Index.Class, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.ClassCodes Class { get; set; }

        /// <summary>
        /// Gets or sets CheckMessage1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckMessage1", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.CheckMessage1, Id = Index.CheckMessage1, FieldType = EntityFieldType.Char, Size = 60)]
        public string CheckMessage1 { get; set; }

        /// <summary>
        /// Gets or sets CheckMessage2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckMessage2", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.CheckMessage2, Id = Index.CheckMessage2, FieldType = EntityFieldType.Char, Size = 60)]
        public string CheckMessage2 { get; set; }

        /// <summary>
        /// Gets or sets ChecksStatus
        /// </summary>
        [Display(Name = "ChecksStatus", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.ChecksStatus, Id = Index.ChecksStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public PrintCheckStatus ChecksStatus { get; set; }

        /// <summary>
        /// Gets or sets PostManualChecksFlag
        /// </summary>
        [Display(Name = "PostManualChecksFlag", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.PostManualChecksFlag, Id = Index.PostManualChecksFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PostManualChecksFlag { get; set; }

        /// <summary>
        /// Gets or sets Restart
        /// </summary>
        [Display(Name = "Restart", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.Restart, Id = Index.Restart, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Restart { get; set; }

        /// <summary>
        /// Gets or sets ProcessState
        /// </summary>
        [Display(Name = "ProcessState", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.ProcessState, Id = Index.ProcessState, FieldType = EntityFieldType.Int, Size = 2)]
        public RestartState ProcessState { get; set; }

        /// <summary>
        /// Gets or sets BKReturnStatus
        /// </summary>
        [Display(Name = "BKReturnStatus", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.BKReturnStatus, Id = Index.BKReturnStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int BKReturnStatus { get; set; }

        /// <summary>
        /// Gets or sets BKAppRunNumber
        /// </summary>
        [Display(Name = "BKAppRunNumber", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.BKAppRunNumber, Id = Index.BKAppRunNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long BKAppRunNumber { get; set; }

        /// <summary>
        /// Gets or sets PayrollCheckRunType
        /// </summary>
        [Display(Name = "PayrollCheckRunType", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.PayrollCheckRunType, Id = Index.PayrollCheckRunType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.RunType? PayrollCheckRunType { get; set; }

        /// <summary>
        /// Gets or sets PrintSSNFlag
        /// </summary>
        [Display(Name = "PrintSSNFlag", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.PrintSSNFlag, Id = Index.PrintSSNFlag, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PrintSSNFlag { get; set; }

        /// <summary>
        /// Gets or sets CalculationSequence
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CalculationSequence", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.CalculationSequence, Id = Index.CalculationSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long CalculationSequence { get; set; }

        /// <summary>
        /// Gets or sets FirstAvailableSeq
        /// </summary>
        [Display(Name = "FirstAvailableSeq", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.FirstAvailableSeq, Id = Index.FirstAvailableSeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long FirstAvailableSeq { get; set; }

        /// <summary>
        /// Gets or sets LastAvailableSeq
        /// </summary>
        [Display(Name = "LastAvailableSeq", ResourceType = typeof(PayrollChecksResx))]
        [ViewField(Name = Fields.LastAvailableSeq, Id = Index.LastAvailableSeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long LastAvailableSeq { get; set; }
    }
}
