// Copyright (c) 1994-2023 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CalculatePayroll
    /// </summary>
    public partial class CalculatePayroll : ModelBase
    {
        /// <summary>
        /// Gets or sets BeginningEmployee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BeginningEmployee", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BeginningEmployee, Id = Index.BeginningEmployee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string BeginningEmployee { get; set; }

        /// <summary>
        /// Gets or sets EndingEmployee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndingEmployee", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EndingEmployee, Id = Index.EndingEmployee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string EndingEmployee { get; set; }

        /// <summary>
        /// Gets or sets BeginningClass1
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BeginningClass1", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BeginningClass1, Id = Index.BeginningClass1, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BeginningClass1 { get; set; }

        /// <summary>
        /// Gets or sets EndingClass1
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndingClass1", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EndingClass1, Id = Index.EndingClass1, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EndingClass1 { get; set; }

        /// <summary>
        /// Gets or sets BeginningClass2
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BeginningClass2", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BeginningClass2, Id = Index.BeginningClass2, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BeginningClass2 { get; set; }

        /// <summary>
        /// Gets or sets EndingClass2
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndingClass2", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EndingClass2, Id = Index.EndingClass2, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EndingClass2 { get; set; }

        /// <summary>
        /// Gets or sets BeginningClass3
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BeginningClass3", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BeginningClass3, Id = Index.BeginningClass3, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BeginningClass3 { get; set; }

        /// <summary>
        /// Gets or sets EndingClass3
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndingClass3", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EndingClass3, Id = Index.EndingClass3, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EndingClass3 { get; set; }

        /// <summary>
        /// Gets or sets BeginningClass4
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BeginningClass4", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BeginningClass4, Id = Index.BeginningClass4, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BeginningClass4 { get; set; }

        /// <summary>
        /// Gets or sets EndingClass4
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndingClass4", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EndingClass4, Id = Index.EndingClass4, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EndingClass4 { get; set; }

        /// <summary>
        /// Gets or sets SelectionList
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectionList", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.SelectionList, Id = Index.SelectionList, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string SelectionList { get; set; }

        /// <summary>
        /// Gets or sets PayrollRunDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayrollRunDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.PayrollRunDate, Id = Index.PayrollRunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PayrollRunDate { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets CheckDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.CheckDate, Id = Index.CheckDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CheckDate { get; set; }

        /// <summary>
        /// Gets or sets PayrollPeriod
        /// </summary>
        [Display(Name = "PayrollPeriod", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.PayrollPeriod, Id = Index.PayrollPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public short PayrollPeriod { get; set; }

        /// <summary>
        /// Gets or sets AdvancesOnly
        /// </summary>
        [Display(Name = "AdvancesOnly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.AdvancesOnly, Id = Index.AdvancesOnly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AdvancesOnly { get; set; }

        /// <summary>
        /// Gets or sets DeleteCurrentActivity
        /// </summary>
        [Display(Name = "DeleteCurrentActivity", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DeleteCurrentActivity, Id = Index.DeleteCurrentActivity, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DeleteCurrentActivity { get; set; }

        /// <summary>
        /// Gets or sets EmpDaily
        /// </summary>
        [Display(Name = "EmpDaily", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EmpDaily, Id = Index.EmpDaily, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EmpDaily { get; set; }

        /// <summary>
        /// Gets or sets EmpWeekly
        /// </summary>
        [Display(Name = "EmpWeekly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EmpWeekly, Id = Index.EmpWeekly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EmpWeekly { get; set; }

        /// <summary>
        /// Gets or sets EmpBiweekly
        /// </summary>
        [Display(Name = "EmpBiweekly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EmpBiweekly, Id = Index.EmpBiweekly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EmpBiweekly { get; set; }

        /// <summary>
        /// Gets or sets EmpSemimonthly
        /// </summary>
        [Display(Name = "EmpSemimonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EmpSemimonthly, Id = Index.EmpSemimonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EmpSemimonthly { get; set; }

        /// <summary>
        /// Gets or sets Emp22Periods
        /// </summary>
        [Display(Name = "Emp22Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Emp22Periods, Id = Index.Emp22Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Emp22Periods { get; set; }

        /// <summary>
        /// Gets or sets Emp13Periods
        /// </summary>
        [Display(Name = "Emp13Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Emp13Periods, Id = Index.Emp13Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Emp13Periods { get; set; }

        /// <summary>
        /// Gets or sets EmpMonthly
        /// </summary>
        [Display(Name = "EmpMonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EmpMonthly, Id = Index.EmpMonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EmpMonthly { get; set; }

        /// <summary>
        /// Gets or sets Emp10Periods
        /// </summary>
        [Display(Name = "Emp10Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Emp10Periods, Id = Index.Emp10Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Emp10Periods { get; set; }

        /// <summary>
        /// Gets or sets EmpQuarterly
        /// </summary>
        [Display(Name = "EmpQuarterly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.EmpQuarterly, Id = Index.EmpQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EmpQuarterly { get; set; }

        /// <summary>
        /// Gets or sets DailyEDDaily
        /// </summary>
        [Display(Name = "DailyEDDaily", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DailyEDDaily, Id = Index.DailyEDDaily, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DailyEDDaily { get; set; }

        /// <summary>
        /// Gets or sets DailyEDWeekly
        /// </summary>
        [Display(Name = "DailyEDWeekly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DailyEDWeekly, Id = Index.DailyEDWeekly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DailyEDWeekly { get; set; }

        /// <summary>
        /// Gets or sets DailyEDBiweekly
        /// </summary>
        [Display(Name = "DailyEDBiweekly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DailyEDBiweekly, Id = Index.DailyEDBiweekly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DailyEDBiweekly { get; set; }

        /// <summary>
        /// Gets or sets DailyEDSemimonthly
        /// </summary>
        [Display(Name = "DailyEDSemimonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DailyEDSemimonthly, Id = Index.DailyEDSemimonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DailyEDSemimonthly { get; set; }

        /// <summary>
        /// Gets or sets DailyED22Periods
        /// </summary>
        [Display(Name = "DailyED22Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DailyED22Periods, Id = Index.DailyED22Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DailyED22Periods { get; set; }

        /// <summary>
        /// Gets or sets DailyED13Periods
        /// </summary>
        [Display(Name = "DailyED13Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DailyED13Periods, Id = Index.DailyED13Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DailyED13Periods { get; set; }

        /// <summary>
        /// Gets or sets DailyEDMonthly
        /// </summary>
        [Display(Name = "DailyEDMonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DailyEDMonthly, Id = Index.DailyEDMonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DailyEDMonthly { get; set; }

        /// <summary>
        /// Gets or sets DailyED10Periods
        /// </summary>
        [Display(Name = "DailyED10Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DailyED10Periods, Id = Index.DailyED10Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DailyED10Periods { get; set; }

        /// <summary>
        /// Gets or sets DailyEDQuarterly
        /// </summary>
        [Display(Name = "DailyEDQuarterly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DailyEDQuarterly, Id = Index.DailyEDQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DailyEDQuarterly { get; set; }

        /// <summary>
        /// Gets or sets WeeklyEDWeekly
        /// </summary>
        [Display(Name = "WeeklyEDWeekly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.WeeklyEDWeekly, Id = Index.WeeklyEDWeekly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool WeeklyEDWeekly { get; set; }

        /// <summary>
        /// Gets or sets WeeklyEDBiweekly
        /// </summary>
        [Display(Name = "WeeklyEDBiweekly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.WeeklyEDBiweekly, Id = Index.WeeklyEDBiweekly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool WeeklyEDBiweekly { get; set; }

        /// <summary>
        /// Gets or sets WeeklyEDSemimonthly
        /// </summary>
        [Display(Name = "WeeklyEDSemimonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.WeeklyEDSemimonthly, Id = Index.WeeklyEDSemimonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool WeeklyEDSemimonthly { get; set; }

        /// <summary>
        /// Gets or sets WeeklyED22Periods
        /// </summary>
        [Display(Name = "WeeklyED22Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.WeeklyED22Periods, Id = Index.WeeklyED22Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool WeeklyED22Periods { get; set; }

        /// <summary>
        /// Gets or sets WeeklyED13Periods
        /// </summary>
        [Display(Name = "WeeklyED13Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.WeeklyED13Periods, Id = Index.WeeklyED13Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool WeeklyED13Periods { get; set; }

        /// <summary>
        /// Gets or sets WeeklyEDMonthly
        /// </summary>
        [Display(Name = "WeeklyEDMonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.WeeklyEDMonthly, Id = Index.WeeklyEDMonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool WeeklyEDMonthly { get; set; }

        /// <summary>
        /// Gets or sets WeeklyED10Periods
        /// </summary>
        [Display(Name = "WeeklyED10Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.WeeklyED10Periods, Id = Index.WeeklyED10Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool WeeklyED10Periods { get; set; }

        /// <summary>
        /// Gets or sets WeeklyEDQuarterly
        /// </summary>
        [Display(Name = "WeeklyEDQuarterly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.WeeklyEDQuarterly, Id = Index.WeeklyEDQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool WeeklyEDQuarterly { get; set; }

        /// <summary>
        /// Gets or sets BiweeklyEDBiweekly
        /// </summary>
        [Display(Name = "BiweeklyEDBiweekly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BiweeklyEDBiweekly, Id = Index.BiweeklyEDBiweekly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool BiweeklyEDBiweekly { get; set; }

        /// <summary>
        /// Gets or sets BiweeklyEDSemimonthly
        /// </summary>
        [Display(Name = "BiweeklyEDSemimonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BiweeklyEDSemimonthly, Id = Index.BiweeklyEDSemimonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool BiweeklyEDSemimonthly { get; set; }

        /// <summary>
        /// Gets or sets BiweeklyED22Periods
        /// </summary>
        [Display(Name = "BiweeklyED22Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BiweeklyED22Periods, Id = Index.BiweeklyED22Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool BiweeklyED22Periods { get; set; }

        /// <summary>
        /// Gets or sets BiweeklyED13Periods
        /// </summary>
        [Display(Name = "BiweeklyED13Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BiweeklyED13Periods, Id = Index.BiweeklyED13Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool BiweeklyED13Periods { get; set; }

        /// <summary>
        /// Gets or sets BiweeklyEDMonthly
        /// </summary>
        [Display(Name = "BiweeklyEDMonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BiweeklyEDMonthly, Id = Index.BiweeklyEDMonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool BiweeklyEDMonthly { get; set; }

        /// <summary>
        /// Gets or sets BiweeklyED10Periods
        /// </summary>
        [Display(Name = "BiweeklyED10Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BiweeklyED10Periods, Id = Index.BiweeklyED10Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool BiweeklyED10Periods { get; set; }

        /// <summary>
        /// Gets or sets BiweeklyEDQuarterly
        /// </summary>
        [Display(Name = "BiweeklyEDQuarterly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BiweeklyEDQuarterly, Id = Index.BiweeklyEDQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool BiweeklyEDQuarterly { get; set; }

        /// <summary>
        /// Gets or sets SemimonthlyEDSemimonthly
        /// </summary>
        [Display(Name = "SemimonthlyEDSemimonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.SemimonthlyEDSemimonthly, Id = Index.SemimonthlyEDSemimonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SemimonthlyEDSemimonthly { get; set; }

        /// <summary>
        /// Gets or sets SemimonthlyED22Periods
        /// </summary>
        [Display(Name = "SemimonthlyED22Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.SemimonthlyED22Periods, Id = Index.SemimonthlyED22Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SemimonthlyED22Periods { get; set; }

        /// <summary>
        /// Gets or sets SemimonthlyED13Periods
        /// </summary>
        [Display(Name = "SemimonthlyED13Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.SemimonthlyED13Periods, Id = Index.SemimonthlyED13Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SemimonthlyED13Periods { get; set; }

        /// <summary>
        /// Gets or sets SemimonthlyEDMonthly
        /// </summary>
        [Display(Name = "SemimonthlyEDMonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.SemimonthlyEDMonthly, Id = Index.SemimonthlyEDMonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SemimonthlyEDMonthly { get; set; }

        /// <summary>
        /// Gets or sets SemimonthlyED10Periods
        /// </summary>
        [Display(Name = "SemimonthlyED10Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.SemimonthlyED10Periods, Id = Index.SemimonthlyED10Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SemimonthlyED10Periods { get; set; }

        /// <summary>
        /// Gets or sets SemimonthlyEDQuarterly
        /// </summary>
        [Display(Name = "SemimonthlyEDQuarterly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.SemimonthlyEDQuarterly, Id = Index.SemimonthlyEDQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SemimonthlyEDQuarterly { get; set; }

        /// <summary>
        /// Gets or sets Num22PeriodsED22Periods
        /// </summary>
        [Display(Name = "Num22PeriodsED22Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num22PeriodsED22Periods, Id = Index.Num22PeriodsED22Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num22PeriodsED22Periods { get; set; }

        /// <summary>
        /// Gets or sets Num22PeriodsED13Periods
        /// </summary>
        [Display(Name = "Num22PeriodsED13Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num22PeriodsED13Periods, Id = Index.Num22PeriodsED13Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num22PeriodsED13Periods { get; set; }

        /// <summary>
        /// Gets or sets Num22PeriodsEDMonthly
        /// </summary>
        [Display(Name = "Num22PeriodsEDMonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num22PeriodsEDMonthly, Id = Index.Num22PeriodsEDMonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num22PeriodsEDMonthly { get; set; }

        /// <summary>
        /// Gets or sets Num22PeriodsED10Periods
        /// </summary>
        [Display(Name = "Num22PeriodsED10Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num22PeriodsED10Periods, Id = Index.Num22PeriodsED10Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num22PeriodsED10Periods { get; set; }

        /// <summary>
        /// Gets or sets Num22PeriodsEDQuarterly
        /// </summary>
        [Display(Name = "Num22PeriodsEDQuarterly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num22PeriodsEDQuarterly, Id = Index.Num22PeriodsEDQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num22PeriodsEDQuarterly { get; set; }

        /// <summary>
        /// Gets or sets Num13PeriodsED13Periods
        /// </summary>
        [Display(Name = "Num13PeriodsED13Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num13PeriodsED13Periods, Id = Index.Num13PeriodsED13Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num13PeriodsED13Periods { get; set; }

        /// <summary>
        /// Gets or sets Num13PeriodsEDMonthly
        /// </summary>
        [Display(Name = "Num13PeriodsEDMonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num13PeriodsEDMonthly, Id = Index.Num13PeriodsEDMonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num13PeriodsEDMonthly { get; set; }

        /// <summary>
        /// Gets or sets Num13PeriodsED10Periods
        /// </summary>
        [Display(Name = "Num13PeriodsED10Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num13PeriodsED10Periods, Id = Index.Num13PeriodsED10Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num13PeriodsED10Periods { get; set; }

        /// <summary>
        /// Gets or sets Num13PeriodsEDQuarterly
        /// </summary>
        [Display(Name = "Num13PeriodsEDQuarterly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num13PeriodsEDQuarterly, Id = Index.Num13PeriodsEDQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num13PeriodsEDQuarterly { get; set; }

        /// <summary>
        /// Gets or sets MonthlyPeriodsEDMonthly
        /// </summary>
        [Display(Name = "MonthlyPeriodsEDMonthly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.MonthlyPeriodsEDMonthly, Id = Index.MonthlyPeriodsEDMonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool MonthlyPeriodsEDMonthly { get; set; }

        /// <summary>
        /// Gets or sets MonthlyPeriodsED10Periods
        /// </summary>
        [Display(Name = "MonthlyPeriodsED10Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.MonthlyPeriodsED10Periods, Id = Index.MonthlyPeriodsED10Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool MonthlyPeriodsED10Periods { get; set; }

        /// <summary>
        /// Gets or sets MonthlyPeriodsEDQuarterly
        /// </summary>
        [Display(Name = "MonthlyPeriodsEDQuarterly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.MonthlyPeriodsEDQuarterly, Id = Index.MonthlyPeriodsEDQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool MonthlyPeriodsEDQuarterly { get; set; }

        /// <summary>
        /// Gets or sets Num10PeriodsED10Periods
        /// </summary>
        [Display(Name = "Num10PeriodsED10Periods", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num10PeriodsED10Periods, Id = Index.Num10PeriodsED10Periods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num10PeriodsED10Periods { get; set; }

        /// <summary>
        /// Gets or sets Num10PeriodsEDQuarterly
        /// </summary>
        [Display(Name = "Num10PeriodsEDQuarterly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num10PeriodsEDQuarterly, Id = Index.Num10PeriodsEDQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Num10PeriodsEDQuarterly { get; set; }

        /// <summary>
        /// Gets or sets QuarterlyEDQuarterly
        /// </summary>
        [Display(Name = "QuarterlyEDQuarterly", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.QuarterlyEDQuarterly, Id = Index.QuarterlyEDQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool QuarterlyEDQuarterly { get; set; }

        /// <summary>
        /// Gets or sets DailyPeriodStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DailyPeriodStartDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DailyPeriodStartDate, Id = Index.DailyPeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DailyPeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets WeeklyPeriodStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WeeklyPeriodStartDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.WeeklyPeriodStartDate, Id = Index.WeeklyPeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? WeeklyPeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets BiweeklyPeriodStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BiweeklyPeriodStartDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.BiweeklyPeriodStartDate, Id = Index.BiweeklyPeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BiweeklyPeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets SemimonthlyPeriodStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SemimonthlyPeriodStartDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.SemimonthlyPeriodStartDate, Id = Index.SemimonthlyPeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? SemimonthlyPeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets Num22PeriodsPeriodStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Num22PeriodsPeriodStartDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num22PeriodsPeriodStartDate, Id = Index.Num22PeriodsPeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? Num22PeriodsPeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets Num13PeriodsPeriodStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Num13PeriodsPeriodStartDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num13PeriodsPeriodStartDate, Id = Index.Num13PeriodsPeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? Num13PeriodsPeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets MonthlyPeriodStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MonthlyPeriodStartDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.MonthlyPeriodStartDate, Id = Index.MonthlyPeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? MonthlyPeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets Num10PeriodsPeriodStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Num10PeriodsPeriodStartDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.Num10PeriodsPeriodStartDate, Id = Index.Num10PeriodsPeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? Num10PeriodsPeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets QuarterlyPeriodStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "QuarterlyPeriodStartDate", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.QuarterlyPeriodStartDate, Id = Index.QuarterlyPeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? QuarterlyPeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets DoEFTCalculation
        /// </summary>
        [Display(Name = "DoEFTCalculation", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DoEFTCalculation, Id = Index.DoEFTCalculation, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DoEFTCalculation { get; set; }

        /// <summary>
        /// Gets or sets CalculationOption
        /// </summary>
        [Display(Name = "CalculationOption", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.CalculationOption, Id = Index.CalculationOption, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.CalculationOption CalculationOption { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets DummyField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DummyField", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DummyField, Id = Index.DummyField, FieldType = EntityFieldType.Int, Size = 2)]
        public short DummyField { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.ProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets TaxVersion
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxVersion", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.TaxVersion, Id = Index.TaxVersion, FieldType = EntityFieldType.Char, Size = 80)]
        public string TaxVersion { get; set; }

        #region Newly Added Properties

        /// <summary>
        /// Gets or sets PayrollOptionalFields
        /// </summary>
        [IgnoreExportImport]
        public List<CalculatePayrollOptionalField> CalculatePayrollOptionalFields { get; set; }

        #endregion

        #region UI Strings

        /// <summary>
        /// Gets CalculationOption string value
        /// </summary>
        public string CalculationOptionString => EnumUtility.GetStringValue(CalculationOption);

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

        #endregion
    }
}
