// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeActivity
    /// </summary>
    public partial class EmployeeActivity : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets ProcessAction
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ProcessAction, Id = Index.ProcessAction, FieldType = EntityFieldType.Char, Size = 5)]
        public string ProcessAction { get; set; }

        /// <summary>
        /// Gets or sets Month
        /// </summary>
        [Display(Name = "Month", ResourceType = typeof(EmployeeActivityResx))]
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Month, Id = Index.Month, FieldType = EntityFieldType.Char, Size = 9)]
        public string Month { get; set; }

        /// <summary>
        /// Gets or sets Year
        /// </summary>
        [Display(Name = "Year", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Int, Size = 2)]
        public int Year { get; set; }

        /// <summary>
        /// Gets or sets TypeOfCheckDocument
        /// </summary>
        [Display(Name = "TypeOfCheckDocument", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 8)]
        public Enums.TypeOfCheckDocument DocumentType { get; set; }

        /// <summary>
        /// Gets or sets PRPostStatus
        /// </summary>
        [Display(Name = "PostingStatus", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.PostingStatus, Id = Index.PostingStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.PRPostStatus PostingStatus { get; set; }

        /// <summary>
        /// Gets or sets FromDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromDate", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.FromDate, Id = Index.FromDate, FieldType = EntityFieldType.Date, Size = 10)]
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or sets ToDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToDate", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ToDate, Id = Index.ToDate, FieldType = EntityFieldType.Date, Size = 10)]
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Gets or sets RegularEarningsMTD
        /// </summary>
        [Display(Name = "RegularEarningsMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.RegularEarningsMTD, Id = Index.RegularEarningsMTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal RegularEarningsMTD { get; set; }

        /// <summary>
        /// Gets or sets RegularEarningsQTD
        /// </summary>
        [Display(Name = "RegularEarningsQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.RegularEarningsQTD, Id = Index.RegularEarningsQTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal RegularEarningsQTD { get; set; }

        /// <summary>
        /// Gets or sets RegularEarningsYTD
        /// </summary>
        [Display(Name = "RegularEarningsYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.RegularEarningsYTD, Id = Index.RegularEarningsYTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal RegularEarningsYTD { get; set; }

        /// <summary>
        /// Gets or sets OvertimeEarningsMTD
        /// </summary>
        [Display(Name = "OvertimeEarningsMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.OverTimeEarningsMTD, Id = Index.OverTimeEarningsMTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal OverTimeEarningsMTD { get; set; }

        /// <summary>
������� /// Gets or sets OvertimeEarningsQTD
������� /// </summary>
        [Display(Name = "OvertimeEarningsQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.OverTimeEarningsQTD, Id = Index.OverTimeEarningsQTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal OverTimeEarningsQTD { get; set; }

        /// <summary>
        /// Gets or sets OvertimeEarningsYTD
        /// </summary>
        [Display(Name = "OvertimeEarningsYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.OverTimeEarningsYTD, Id = Index.OverTimeEarningsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal OverTimeEarningsYTD { get; set; }

        /// <summary>
        /// Gets or sets ShiftEarningsMTD
        /// </summary>
        [Display(Name = "ShiftEarningsMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ShiftEarningsMTD, Id = Index.ShiftEarningsMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal ShiftEarningsMTD { get; set; }

        /// <summary>
        /// Gets or sets ShiftEarningsQTD
        /// </summary>
        [Display(Name = "ShiftEarningsQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ShiftEarningsQTD, Id = Index.ShiftEarningsQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal ShiftEarningsQTD { get; set; }

        /// <summary>
        /// Gets or sets ShiftEarningsYTD
        /// </summary>
        [Display(Name = "ShiftEarningsYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ShiftEarningsYTD, Id = Index.ShiftEarningsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal ShiftEarningsYTD { get; set; }

        /// <summary>
        /// Gets or sets AccrualsPaidMTD
        /// </summary>
        [Display(Name = "AccrualsPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccrualsPaidMTD, Id = Index.AccrualsPaidMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccrualsPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets AccrualsPaidQTD
        /// </summary>
        [Display(Name = "AccrualsPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccrualsPaidQTD, Id = Index.AccrualsPaidQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccrualsPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets AccrualsPaidYTD
        /// </summary>
        [Display(Name = "AccrualsPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccrualsPaidYTD, Id = Index.AccrualsPaidYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccrualsPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets CashBenefitsMTD
        /// </summary>
        [Display(Name = "CashBenefitsMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.CashBenefitsMTD, Id = Index.CashBenefitsMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal CashBenefitsMTD { get; set; }

        /// <summary>
        /// Gets or sets CashBenefitsQTD
        /// </summary>
        [Display(Name = "CashBenefitsQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.CashBenefitsQTD, Id = Index.CashBenefitsQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal CashBenefitsQTD { get; set; }

        /// <summary>
        /// Gets or sets CashBenefitsYTD
        /// </summary>
        [Display(Name = "CashBenefitsYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.CashBenefitsYTD, Id = Index.CashBenefitsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal CashBenefitsYTD { get; set; }

        /// <summary>
        /// Gets or sets TotalEarningsMTD
        /// </summary>
        [Display(Name = "TotalEarningsMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalEarningsMTD, Id = Index.TotalEarningsMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalEarningsMTD { get; set; }

        /// <summary>
        /// Gets or sets TotalEarningsQTD
        /// </summary>
        [Display(Name = "TotalEarningsQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalEarningsQTD, Id = Index.TotalEarningsQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalEarningsQTD { get; set; }

        /// <summary>
        /// Gets or sets TotalEarningsYTD
        /// </summary>
        [Display(Name = "TotalEarningsYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalEarningsYTD, Id = Index.TotalEarningsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalEarningsYTD { get; set; }

        /// <summary>
        /// Gets or sets ExpenseReimbursementsMTD
        /// </summary>
        [Display(Name = "ExpenseReimbursementsMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ExpenseReimbursementsMTD, Id = Index.ExpenseReimbursementsMTD, FieldType = EntityFieldType.Decimal, Size = 10,Precision = 2)]
        public decimal ExpenseReimbursementsMTD { get; set; }

        /// <summary>
        /// Gets or sets ExpenseReimbursementsQTD
        /// </summary>
        [Display(Name = "ExpenseReimbursementsQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ExpenseReimbursementsQTD, Id = Index.ExpenseReimbursementsQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal ExpenseReimbursementsQTD { get; set; }

        /// <summary>
        /// Gets or sets ExpenseReimbursementsYTD
        /// </summary>
        [Display(Name = "ExpenseReimbursementsYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ExpenseReimbursementsYTD, Id = Index.ExpenseReimbursementsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal ExpenseReimbursementsYTD { get; set; }

        /// <summary>
        /// Gets or sets CashAdvancesMTD
        /// </summary>
        [Display(Name = "CashAdvancesMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.CashAdvancesMTD, Id = Index.CashAdvancesMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal CashAdvancesMTD { get; set; }

        /// <summary>
        /// Gets or sets CashAdvancesQTD
        /// </summary>
        [Display(Name = "CashAdvancesQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.CashAdvancesQTD, Id = Index.CashAdvancesQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal CashAdvancesQTD { get; set; }

        /// <summary>
        /// Gets or sets CashAdvancesYTD
        /// </summary>
        [Display(Name = "CashAdvancesYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.CashAdvancesYTD, Id = Index.CashAdvancesYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal CashAdvancesYTD { get; set; }

        /// <summary>
        /// Gets or sets DeductionsandTaxesMTD
        /// </summary>
        [Display(Name = "DeductionsandTaxesMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.DeductionsAndTaxesMTD, Id = Index.DeductionsAndTaxesMTD, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 2)]
        public decimal DeductionsAndTaxesMTD { get; set; }

        /// <summary>
        /// Gets or sets DeductionsandTaxesQTD
        /// </summary>
        [Display(Name = "DeductionsandTaxesQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.DeductionsAndTaxesQTD, Id = Index.DeductionsAndTaxesQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal DeductionsAndTaxesQTD { get; set; }

        /// <summary>
        /// Gets or sets DeductionsandTaxesYTD
        /// </summary>
        [Display(Name = "DeductionsandTaxesYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.DeductionsAndTaxesYTD, Id = Index.DeductionsAndTaxesYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal DeductionsAndTaxesYTD { get; set; }

        /// <summary>
        /// Gets or sets NetPayMTD
        /// </summary>
        [Display(Name = "NetPayMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.NetPayMTD, Id = Index.NetPayMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal NetPayMTD { get; set; }

        /// <summary>
        /// Gets or sets NetPayQTD
        /// </summary>
        [Display(Name = "NetPayQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.NetPayQTD, Id = Index.NetPayQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal NetPayQTD { get; set; }

        /// <summary>
        /// Gets or sets NetPayYTD
        /// </summary>
        [Display(Name = "NetPayYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.NetPayYTD, Id = Index.NetPayYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal NetPayYTD { get; set; }

        /// <summary>
        /// Gets or sets NoncashIncomeMTD
        /// </summary>
        [Display(Name = "NoncashIncomeMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.NonCashIncomeMTD, Id = Index.NonCashIncomeMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal NonCashIncomeMTD { get; set; }

        /// <summary>
        /// Gets or sets NoncashIncomeQTD
        /// </summary>
        [Display(Name = "NoncashIncomeQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.NonCashIncomeQTD, Id = Index.NonCashIncomeQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal NonCashIncomeQTD { get; set; }

        /// <summary>
        /// Gets or sets NoncashIncomeYTD
        /// </summary>
        [Display(Name = "NoncashIncomeYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.NonCashIncomeYTD, Id = Index.NonCashIncomeYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal NonCashIncomeYTD { get; set; }

        /// <summary>
        /// Gets or sets NoncashAdvancesMTD
        /// </summary>
        [Display(Name = "NoncashAdvancesMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.NonCashAdvancesMTD, Id = Index.NonCashAdvancesMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal NonCashAdvancesMTD { get; set; }

        /// <summary>
        /// Gets or sets NoncashAdvancesQTD
        /// </summary>
        [Display(Name = "NoncashAdvancesQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.NonCashAdvancesQTD, Id = Index.NonCashAdvancesQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal NonCashAdvancesQTD { get; set; }

        /// <summary>
        /// Gets or sets NoncashAdvancesYTD
        /// </summary>
        [Display(Name = "NoncashAdvancesYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.NonCashAdvancesYTD, Id = Index.NonCashAdvancesYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal NonCashAdvancesYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedAmountsMTD
        /// </summary>
        [Display(Name = "AccruedAmountsMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedAmountsMTD, Id = Index.AccruedAmountsMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedAmountsMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedAmountsQTD
        /// </summary>
        [Display(Name = "AccruedAmountsQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedAmountsQTD, Id = Index.AccruedAmountsQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedAmountsQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedAmountsYTD
        /// </summary>
        [Display(Name = "AccruedAmountsYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedAmountsYTD, Id = Index.AccruedAmountsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedAmountsYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedHoursMTD
        /// </summary>
        [Display(Name = "AccruedHoursMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedHoursMTD, Id = Index.AccruedHoursMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedHoursMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedHoursQTD
        /// </summary>
        [Display(Name = "AccruedHoursQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedHoursQTD, Id = Index.AccruedHoursQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedHoursQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedHoursYTD
        /// </summary>
        [Display(Name = "AccruedHoursYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedHoursYTD, Id = Index.AccruedHoursYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedHoursYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedHoursPaidMTD
        /// </summary>
        [Display(Name = "AccruedHoursPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedHoursPaidMTD, Id = Index.AccruedHoursPaidMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedHoursPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedHoursPaidQTD
        /// </summary>
        [Display(Name = "AccruedHoursPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedHoursPaidQTD, Id = Index.AccruedHoursPaidQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedHoursPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedHoursPaidYTD
        /// </summary>
        [Display(Name = "AccruedHoursPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedHoursPaidYTD, Id = Index.AccruedHoursPaidYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedHoursPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets RegularHoursPaidMTD
        /// </summary>
        [Display(Name = "RegularHoursPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.RegularHoursPaidMTD, Id = Index.RegularHoursPaidMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal RegularHoursPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets RegularHoursPaidQTD
        /// </summary>
        [Display(Name = "RegularHoursPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.RegularHoursPaidQTD, Id = Index.RegularHoursPaidQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal RegularHoursPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets RegularHoursPaidYTD
        /// </summary>
        [Display(Name = "RegularHoursPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.RegularHoursPaidYTD, Id = Index.RegularHoursPaidYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal RegularHoursPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets OvertimeHoursPaidMTD
        /// </summary>
        [Display(Name = "OvertimeHoursPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.OvertimeHoursPaidMTD, Id = Index.OvertimeHoursPaidMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal OvertimeHoursPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets OvertimeHoursPaidQTD
        /// </summary>
        [Display(Name = "OvertimeHoursPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.OvertimeHoursPaidQTD, Id = Index.OvertimeHoursPaidQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal OvertimeHoursPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets OvertimeHoursPaidYTD
        /// </summary>
        [Display(Name = "OvertimeHoursPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.OvertimeHoursPaidYTD, Id = Index.OvertimeHoursPaidYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal OvertimeHoursPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets ShiftHoursPaidMTD
        /// </summary>
        [Display(Name = "ShiftHoursPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ShiftHoursPaidMTD, Id = Index.ShiftHoursPaidMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal ShiftHoursPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets ShiftHoursPaidQTD
        /// </summary>
        [Display(Name = "ShiftHoursPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ShiftHoursPaidQTD, Id = Index.ShiftHoursPaidQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal ShiftHoursPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets ShiftHoursPaidYTD
        /// </summary>
        [Display(Name = "ShiftHoursPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.ShiftHoursPaidYTD, Id = Index.ShiftHoursPaidYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal ShiftHoursPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets TotalHoursPaidMTD
        /// </summary>
        [Display(Name = "TotalHoursPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalHoursPaidMTD, Id = Index.TotalHoursPaidMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalHoursPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets TotalHoursPaidQTD
        /// </summary>
        [Display(Name = "TotalHoursPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalHoursPaidQTD, Id = Index.TotalHoursPaidQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalHoursPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets TotalHoursPaidYTD
        /// </summary>
        [Display(Name = "TotalHoursPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalHoursPaidYTD, Id = Index.TotalHoursPaidYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalHoursPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets TotalChecks
        /// </summary>
        [Display(Name = "TotalChecks", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalChecks, Id = Index.TotalChecks, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalChecks { get; set; }

        /// <summary>
        /// Gets or sets TotalEarnings
        /// </summary>
        [Display(Name = "TotalEarnings", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalEarnings, Id = Index.TotalEarnings, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalEarnings { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxes
        /// </summary>
        [Display(Name = "TotalTaxes", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalTaxes, Id = Index.TotalTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalTaxes { get; set; }

        /// <summary>
        /// Gets or sets TotalDeductions
        /// </summary>
        [Display(Name = "TotalDeductions", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalDeductions, Id = Index.TotalDeductions, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalDeductions { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets EntrySequence
        /// </summary>
        [Display(Name = "EntrySequence", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.EntrySequence, Id = Index.EntrySequence, FieldType = EntityFieldType.Long, Size = 4, Precision = 2)]
        public long EntrySequence { get; set; }

        /// <summary>
        /// Gets or sets TotalCashAdvances
        /// </summary>
        [Display(Name = "TotalCashAdvances", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalCashAdvances, Id = Index.TotalCashAdvances, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalCashAdvances { get; set; }

        /// <summary>
        /// Gets or sets TotalAdvanceRepayments
        /// </summary>
        [Display(Name = "TotalAdvanceRepayments", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.TotalAdvanceRepayments, Id = Index.TotalAdvanceRepayments, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal TotalAdvanceRepayments { get; set; }

        /// <summary>
        /// Gets or sets AccruedVacAmountsMTD
        /// </summary>
        [Display(Name = "AccruedVacAmountsMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedVacAmountsMTD, Id = Index.AccruedVacAmountsMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedVacAmountsMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedVacAmountsQTD
        /// </summary>
        [Display(Name = "AccruedVacAmountsQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedVacAmountsQTD, Id = Index.AccruedVacAmountsQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedVacAmountsQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedVacAmountsYTD
        /// </summary>
        [Display(Name = "AccruedVacAmountsYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedVacAmountsYTD, Id = Index.AccruedVacAmountsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedVacAmountsYTD { get; set; }

        /// <summary>
        /// Gets or sets VacationAmtPaidMTD
        /// </summary>
        [Display(Name = "VacationAmtPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.VacationAmtPaidMTD, Id = Index.VacationAmtPaidMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal VacationAmtPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets VacationAmtPaidQTD
        /// </summary>
        [Display(Name = "VacationAmtPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.VacationAmtPaidQTD, Id = Index.VacationAmtPaidQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal VacationAmtPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets VacationAmtPaidYTD
        /// </summary>
        [Display(Name = "VacationAmtPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.VacationAmtPaidYTD, Id = Index.VacationAmtPaidYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal VacationAmtPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedVacHoursMTD
        /// </summary>
        [Display(Name = "AccruedVacHoursMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedVacHoursMTD, Id = Index.AccruedVacHoursMTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedVacHoursMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedVacHoursQTD
        /// </summary>
        [Display(Name = "AccruedVacHoursQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedVacHoursQTD, Id = Index.AccruedVacHoursQTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedVacHoursQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedVacHoursYTD
        /// </summary>
        [Display(Name = "AccruedVacHoursYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedVacHoursYTD, Id = Index.AccruedVacHoursYTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedVacHoursYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedVacHoursPaidMTD
        /// </summary>
        [Display(Name = "AccruedVacHoursPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedVacHoursPaidMTD, Id = Index.AccruedVacHoursPaidMTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedVacHoursPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedVacHoursPaidQTD
        /// </summary>
        [Display(Name = "AccruedVacHoursPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedVacHoursPaidQTD, Id = Index.AccruedVacHoursPaidQTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedVacHoursPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedVacHoursPaidYTD
        /// </summary>
        [Display(Name = "AccruedVacHoursPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedVacHoursPaidYTD, Id = Index.AccruedVacHoursPaidYTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedVacHoursPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedSickAmountsMTD
        /// </summary>
        [Display(Name = "AccruedSickAmountsMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedSickAmountsMTD, Id = Index.AccruedSickAmountsMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedSickAmountsMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedSickAmountsQTD
        /// </summary>
        [Display(Name = "AccruedSickAmountsQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedSickAmountsQTD, Id = Index.AccruedSickAmountsQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedSickAmountsQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedSickAmountsYTD
        /// </summary>
        [Display(Name = "AccruedSickAmountsYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedSickAmountsYTD, Id = Index.AccruedSickAmountsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedSickAmountsYTD { get; set; }

        /// <summary>
        /// Gets or sets SickAmtPaidMTD
        /// </summary>
        [Display(Name = "SickAmtPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.SickAmtPaidMTD, Id = Index.SickAmtPaidMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal SickAmtPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets SickAmtPaidQTD
        /// </summary>
        [Display(Name = "SickAmtPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.SickAmtPaidQTD, Id = Index.SickAmtPaidQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal SickAmtPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets SickAmtPaidYTD
        /// </summary>
        [Display(Name = "SickAmtPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.SickAmtPaidYTD, Id = Index.SickAmtPaidYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal SickAmtPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedSickHoursMTD
        /// </summary>
        [Display(Name = "AccruedSickHoursMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedSickHoursMTD, Id = Index.AccruedSickHoursMTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedSickHoursMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedSickHoursQTD
        /// </summary>
        [Display(Name = "AccruedSickHoursQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedSickHoursQTD, Id = Index.AccruedSickHoursQTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedSickHoursQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedSickHoursYTD
        /// </summary>
        [Display(Name = "AccruedSickHoursYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedSickHoursYTD, Id = Index.AccruedSickHoursYTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedSickHoursYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedSickHoursPaidMTD
        /// </summary>
        [Display(Name = "AccruedSickHoursPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedSickHoursPaidMTD, Id = Index.AccruedSickHoursPaidMTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedSickHoursPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedSickHoursPaidQTD
        /// </summary>
        [Display(Name = "AccruedSickHoursPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedSickHoursPaidQTD, Id = Index.AccruedSickHoursPaidQTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedSickHoursPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedSickHoursPaidYTD
        /// </summary>
        [Display(Name = "AccruedSickHoursPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedSickHoursPaidYTD, Id = Index.AccruedSickHoursPaidYTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedSickHoursPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedCompTimeAmtMTD
        /// </summary>
        [Display(Name = "AccruedCompTimeAmtMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedCompTimeAmtMTD, Id = Index.AccruedCompTimeAmtMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedCompTimeAmtMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedCompTimeAmtQTD
        /// </summary>
        [Display(Name = "AccruedCompTimeAmtQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedCompTimeAmtQTD, Id = Index.AccruedCompTimeAmtQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedCompTimeAmtQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedCompTimeAmtYTD
        /// </summary>
        [Display(Name = "AccruedCompTimeAmtYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedCompTimeAmtYTD, Id = Index.AccruedCompTimeAmtYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal AccruedCompTimeAmtYTD { get; set; }

        /// <summary>
        /// Gets or sets CompTimeAmtPaidMTD
        /// </summary>
        [Display(Name = "CompTimeAmtPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.CompTimeAmtPaidMTD, Id = Index.CompTimeAmtPaidMTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal CompTimeAmtPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets CompTimeAmtPaidQTD
        /// </summary>
        [Display(Name = "CompTimeAmtPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.CompTimeAmtPaidQTD, Id = Index.CompTimeAmtPaidQTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal CompTimeAmtPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets CompTimeAmtPaidYTD
        /// </summary>
        [Display(Name = "CompTimeAmtPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.CompTimeAmtPaidYTD, Id = Index.CompTimeAmtPaidYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal CompTimeAmtPaidYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedCompHoursMTD
        /// </summary>
        [Display(Name = "AccruedCompHoursMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedCompHoursMTD, Id = Index.AccruedCompHoursMTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedCompHoursMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedCompHoursQTD
        /// </summary>
        [Display(Name = "AccruedCompHoursQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedCompHoursQTD, Id = Index.AccruedCompHoursQTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedCompHoursQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedCompHoursYTD
        /// </summary>
        [Display(Name = "AccruedCompHoursYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedCompHoursYTD, Id = Index.AccruedCompHoursYTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedCompHoursYTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedCompHoursPaidMTD
        /// </summary>
        [Display(Name = "AccruedCompHoursPaidMTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedCompHoursPaidMTD, Id = Index.AccruedCompHoursPaidMTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedCompHoursPaidMTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedCompHoursPaidQTD
        /// </summary>
        [Display(Name = "AccruedCompHoursPaidQTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedCompHoursPaidQTD, Id = Index.AccruedCompHoursPaidQTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedCompHoursPaidQTD { get; set; }

        /// <summary>
        /// Gets or sets AccruedCompHoursPaidYTD
        /// </summary>
        [Display(Name = "AccruedCompHoursPaidYTD", ResourceType = typeof(EmployeeActivityResx))]
        [ViewField(Name = Fields.AccruedCompHoursPaidYTD, Id = Index.AccruedCompHoursPaidYTD, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal AccruedCompHoursPaidYTD { get; set; }
    }
}

