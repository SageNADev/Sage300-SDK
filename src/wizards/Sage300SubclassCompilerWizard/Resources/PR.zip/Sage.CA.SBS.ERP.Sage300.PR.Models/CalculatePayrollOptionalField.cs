// Copyright (c) 1994-2023 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PR.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CalculatePayrollOptionalField
    /// Listing fields for CLCO table view "~~0137" (except audit fields)
    /// </summary>
    public partial class CalculatePayrollOptionalField : ModelBase
    {
        /// <summary>
        /// Gets or sets DummyField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DummyField", ResourceType = typeof (CalculatePayrollResx))]
        [ViewField(Name = Fields.DummyField, Id = Index.DummyField, FieldType = EntityFieldType.Int, Size = 2)]
        public short DummyField { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Display(Name = "OptionalField", ResourceType = typeof(CalculatePayrollResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Value
        /// </summary>
        [Display(Name = "Value", ResourceType = typeof(CalculatePayrollResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(CalculatePayrollResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public int Type { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(CalculatePayrollResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(CalculatePayrollResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(CalculatePayrollResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public int AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(CalculatePayrollResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public int Validate { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(CalculatePayrollResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public int ValueSet { get; set; }

    }
}
