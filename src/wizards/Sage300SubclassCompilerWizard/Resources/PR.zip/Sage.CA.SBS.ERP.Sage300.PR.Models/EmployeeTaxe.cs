// Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeTaxe
    /// </summary>
    public partial class EmployeeTaxe : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets TaxCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxCode", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.TaxCode, Id = Index.TaxCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TaxCode { get; set; }

        // Add the Message property
        public string Message { get; set; }


        /// <summary>
        /// Gets or sets ExtraWithholding
        /// </summary>
        [Display(Name = "ExtraWithholding", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.ExtraWithholding, Id = Index.ExtraWithholding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtraWithholding { get; set; }

        /// <summary>
        /// Gets or sets WithholdingMethod
        /// </summary>
        [Display(Name = "WithholdingMethod", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.WithholdingMethod, Id = Index.WithholdingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.WithholdingMethod WithholdingMethod { get; set; }

        /// <summary>
        /// Gets or sets AmountPercentOverride
        /// </summary>
        [Display(Name = "AmountPercentOverride", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.AmountPercentOverride, Id = Index.AmountPercentOverride, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal AmountPercentOverride { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSEOccasionalTax
        /// </summary>
        [Display(Name = "INTERNALUSEOccasionalTax", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.INTERNALUSEOccasionalTax, Id = Index.INTERNALUSEOccasionalTax, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool INTERNALUSEOccasionalTax { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSETaxTableEffecti
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "INTERNALUSETaxTableEffecti", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.INTERNALUSETaxTableEffecti, Id = Index.INTERNALUSETaxTableEffecti, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime INTERNALUSETaxTableEffecti { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EMPPARMVER
        /// </summary>
        [Display(Name = "EMPPARMVER", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.EMPPARMVER, Id = Index.EMPPARMVER, FieldType = EntityFieldType.Int, Size = 2)]
        public short EMPPARMVER { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EMPPARMCNT
        /// </summary>
        [Display(Name = "EMPPARMCNT", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.EMPPARMCNT, Id = Index.EMPPARMCNT, FieldType = EntityFieldType.Int, Size = 2)]
        public short EMPPARMCNT { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSECategory
        /// </summary>
        [Display(Name = "INTERNALUSECategory", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.INTERNALUSECategory, Id = Index.INTERNALUSECategory, FieldType = EntityFieldType.Int, Size = 2)]
        public short INTERNALUSECategory { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSETaxType
        /// </summary>
        [Display(Name = "INTERNALUSETaxType", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.INTERNALUSETaxType, Id = Index.INTERNALUSETaxType, FieldType = EntityFieldType.Int, Size = 2)]
        public short INTERNALUSETaxType { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }
        
        /// <summary>
        /// Gets or sets INTERNALUSETemplate
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "INTERNALUSETemplate", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.INTERNALUSETemplate, Id = Index.INTERNALUSETemplate, FieldType = EntityFieldType.Char, Size = 12)]
        public string INTERNALUSETemplate { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSEOperationCode
        /// </summary>
        [Display(Name = "INTERNALUSEOperationCode", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.INTERNALUSEOperationCode, Id = Index.INTERNALUSEOperationCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.INTERNALUSEOperationCode INTERNALUSEOperationCode { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxDescription", ResourceType = typeof (EmployeeTaxInfoResx))]
        [ViewField(Name = Fields.TaxDescription, Id = Index.TaxDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxDescription { get; set; }

        #region Newly Added Properties

        /// <summary>
        /// Gets or sets TaxParamFields
        /// </summary>
        [IgnoreExportImport]
        public List<TaxParamField> TaxParamFields { get; set; }

        /// <summary>
        /// Gets or sets IsCALCMTHDEditable
        /// </summary>
        [IgnoreExportImport]
        public bool IsCALCMTHDEditable { get; set; }

        /// <summary>
        /// Gets or sets IsSTANDARDEditable
        /// </summary>
        [IgnoreExportImport]
        public bool IsSTANDARDEditable { get; set; }

        /// <summary>
        /// Gets or sets IsAMTPCTEditable
        /// </summary>
        [IgnoreExportImport]
        public bool IsAMTPCTEditable { get; set; }

        /// <summary>
        /// Gets or sets ModelStatus
        /// </summary>
        [IgnoreExportImport]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.INTERNALUSEModelState ModelState { get; set; }

        #endregion

        #region UI Strings

        /// <summary>
        /// Gets WithholdingMethod string value
        /// </summary>
        public string WithholdingMethodString => EnumUtility.GetStringValue(WithholdingMethod);

        /// <summary>
        /// Gets INTERNALUSEOperationCode string value
        /// </summary>
        public string INTERNALUSEOperationCodeString => EnumUtility.GetStringValue(INTERNALUSEOperationCode);

        #endregion
    }
}
