// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CompanyPayrollTaxe
    /// </summary>
    public partial class CompanyPayrollTaxe : ModelBase
    {
        /// <summary>
        /// Gets or sets Tax
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Tax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Tax, Id = Index.Tax, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Tax { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [Display(Name = "Category", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Int, Size = 2)]
        public short Category { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.Type Type { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ShortDescription
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShortDescription", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.ShortDescription, Id = Index.ShortDescription, FieldType = EntityFieldType.Char, Size = 15)]
        public string ShortDescription { get; set; }

        /// <summary>
        /// Gets or sets ReportingID
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReportingID", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.ReportingID, Id = Index.ReportingID, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-15C")]
        public string ReportingID { get; set; }

        /// <summary>
        /// Gets or sets TaxInactive
        /// </summary>
        [Display(Name = "TaxInactive", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxInactive, Id = Index.TaxInactive, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxInactive { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets BaseMultiplier
        /// </summary>
        [Display(Name = "BaseMultiplier", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.BaseMultiplier, Id = Index.BaseMultiplier, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BaseMultiplier { get; set; }

        /// <summary>
        /// Gets or sets SurtaxMultiplier
        /// </summary>
        [Display(Name = "SurtaxMultiplier", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.SurtaxMultiplier, Id = Index.SurtaxMultiplier, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SurtaxMultiplier { get; set; }

        /// <summary>
        /// Gets or sets RoundTax
        /// </summary>
        [Display(Name = "RoundTax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.RoundTax, Id = Index.RoundTax, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RoundTax { get; set; }

        /// <summary>
        /// Gets or sets DailyPayPeriodsPerYear
        /// </summary>
        [Display(Name = "DailyPayPeriodsPerYear", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.DailyPayPeriodsPerYear, Id = Index.DailyPayPeriodsPerYear, FieldType = EntityFieldType.Int, Size = 2)]
        public short DailyPayPeriodsPerYear { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDTaxCredits
        /// </summary>
        [Display(Name = "RESERVEDTaxCredits", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.RESERVEDTaxCredits, Id = Index.RESERVEDTaxCredits, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RESERVEDTaxCredits { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDTaxCreditPercent
        /// </summary>
        [Display(Name = "RESERVEDTaxCreditPercent", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.RESERVEDTaxCreditPercent, Id = Index.RESERVEDTaxCreditPercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal RESERVEDTaxCreditPercent { get; set; }

        /// <summary>
        /// Gets or sets StandardDeduction
        /// </summary>
        [Display(Name = "StandardDeduction", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.StandardDeduction, Id = Index.StandardDeduction, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StandardDeduction { get; set; }

        /// <summary>
        /// Gets or sets STDARDDED2
        /// </summary>
        [Display(Name = "STDARDDED2", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.STDARDDED2, Id = Index.STDARDDED2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal STDARDDED2 { get; set; }

        /// <summary>
        /// Gets or sets STDARDDED3
        /// </summary>
        [Display(Name = "STDARDDED3", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.STDARDDED3, Id = Index.STDARDDED3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal STDARDDED3 { get; set; }

        /// <summary>
        /// Gets or sets STDARDDED4
        /// </summary>
        [Display(Name = "STDARDDED4", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.STDARDDED4, Id = Index.STDARDDED4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal STDARDDED4 { get; set; }

        /// <summary>
        /// Gets or sets AmountPerExemption
        /// </summary>
        [Display(Name = "AmountPerExemption", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.AmountPerExemption, Id = Index.AmountPerExemption, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountPerExemption { get; set; }

        /// <summary>
        /// Gets or sets EXMPTNAMT2
        /// </summary>
        [Display(Name = "EXMPTNAMT2", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EXMPTNAMT2, Id = Index.EXMPTNAMT2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EXMPTNAMT2 { get; set; }

        /// <summary>
        /// Gets or sets EXMPTNAMT3
        /// </summary>
        [Display(Name = "EXMPTNAMT3", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EXMPTNAMT3, Id = Index.EXMPTNAMT3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EXMPTNAMT3 { get; set; }

        /// <summary>
        /// Gets or sets EXMPTNAMT4
        /// </summary>
        [Display(Name = "EXMPTNAMT4", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EXMPTNAMT4, Id = Index.EXMPTNAMT4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EXMPTNAMT4 { get; set; }

        /// <summary>
        /// Gets or sets TaxCreditExemptionSwitch
        /// </summary>
        [Display(Name = "TaxCreditExemptionSwitch", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxCreditExemptionSwitch, Id = Index.TaxCreditExemptionSwitch, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxCreditExemptionSwitch { get; set; }

        /// <summary>
        /// Gets or sets AnnualMaximumHours
        /// </summary>
        [Display(Name = "AnnualMaximumHours", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.AnnualMaximumHours, Id = Index.AnnualMaximumHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal AnnualMaximumHours { get; set; }

        /// <summary>
        /// Gets or sets AnnualMaximumEarnings
        /// </summary>
        [Display(Name = "AnnualMaximumEarnings", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.AnnualMaximumEarnings, Id = Index.AnnualMaximumEarnings, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AnnualMaximumEarnings { get; set; }

        /// <summary>
        /// Gets or sets AnnualMinimumEarnings
        /// </summary>
        [Display(Name = "AnnualMinimumEarnings", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.AnnualMinimumEarnings, Id = Index.AnnualMinimumEarnings, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AnnualMinimumEarnings { get; set; }

        /// <summary>
        /// Gets or sets W2BoxType
        /// </summary>
        [Display(Name = "W2BoxType", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.W2BoxType, Id = Index.W2BoxType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.W2BoxType W2BoxType { get; set; }

        /// <summary>
        /// Gets or sets CombineWithTax
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CombineWithTax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.CombineWithTax, Id = Index.CombineWithTax, FieldType = EntityFieldType.Char, Size = 6)]
        public string CombineWithTax { get; set; }

        /// <summary>
        /// Gets or sets AssociateWithW2Printing
        /// </summary>
        [Display(Name = "AssociateWithW2Printing", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.AssociateWithW2Printing, Id = Index.AssociateWithW2Printing, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AssociateWithW2Printing { get; set; }

        /// <summary>
        /// Gets or sets AssociatedTax
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AssociatedTax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.AssociatedTax, Id = Index.AssociatedTax, FieldType = EntityFieldType.Char, Size = 6)]
        public string AssociatedTax { get; set; }

        /// <summary>
        /// Gets or sets EmployeeCalculationMethod
        /// </summary>
        [Display(Name = "EmployeeCalculationMethod", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeCalculationMethod, Id = Index.EmployeeCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployeeCalculationMethod EmployeeCalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSupplementalRate
        /// </summary>
        [Display(Name = "EmployeeSupplementalRate", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeSupplementalRate, Id = Index.EmployeeSupplementalRate, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal EmployeeSupplementalRate { get; set; }

        /// <summary>
        /// Gets or sets EmployeeBaseTax
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeBaseTax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeBaseTax, Id = Index.EmployeeBaseTax, FieldType = EntityFieldType.Char, Size = 6)]
        public string EmployeeBaseTax { get; set; }

        /// <summary>
        /// Gets or sets EmployeeAmountPercent
        /// </summary>
        [Display(Name = "EmployeeAmountPercent", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeAmountPercent, Id = Index.EmployeeAmountPercent, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployeeAmountPercent { get; set; }

        /// <summary>
        /// Gets or sets EmployeeLimit
        /// </summary>
        [Display(Name = "EmployeeLimit", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeLimit, Id = Index.EmployeeLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployeeLimit EmployeeLimit { get; set; }

        /// <summary>
        /// Gets or sets EmployeeAnnualMaximum
        /// </summary>
        [Display(Name = "EmployeeAnnualMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeAnnualMaximum, Id = Index.EmployeeAnnualMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeAnnualMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeMinimumWeeksWorked
        /// </summary>
        [Display(Name = "EmployeeMinimumWeeksWorked", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeMinimumWeeksWorked, Id = Index.EmployeeMinimumWeeksWorked, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EmployeeMinimumWeeksWorked { get; set; }

        /// <summary>
        /// Gets or sets EmployeeDailyMinimum
        /// </summary>
        [Display(Name = "EmployeeDailyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeDailyMinimum, Id = Index.EmployeeDailyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeDailyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeDailyMaximum
        /// </summary>
        [Display(Name = "EmployeeDailyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeDailyMaximum, Id = Index.EmployeeDailyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeDailyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeWeeklyMinimum
        /// </summary>
        [Display(Name = "EmployeeWeeklyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeWeeklyMinimum, Id = Index.EmployeeWeeklyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeWeeklyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeWeeklyMaximum
        /// </summary>
        [Display(Name = "EmployeeWeeklyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeWeeklyMaximum, Id = Index.EmployeeWeeklyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeWeeklyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeBiweeklyMinimum
        /// </summary>
        [Display(Name = "EmployeeBiweeklyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeBiweeklyMinimum, Id = Index.EmployeeBiweeklyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeBiweeklyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeBiweeklyMaximum
        /// </summary>
        [Display(Name = "EmployeeBiweeklyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeBiweeklyMaximum, Id = Index.EmployeeBiweeklyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeBiweeklyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSemimonthlyMinimum
        /// </summary>
        [Display(Name = "EmployeeSemimonthlyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeSemimonthlyMinimum, Id = Index.EmployeeSemimonthlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeSemimonthlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSemimonthlyMaximum
        /// </summary>
        [Display(Name = "EmployeeSemimonthlyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeSemimonthlyMaximum, Id = Index.EmployeeSemimonthlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeSemimonthlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeMonthlyMinimum
        /// </summary>
        [Display(Name = "EmployeeMonthlyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeMonthlyMinimum, Id = Index.EmployeeMonthlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeMonthlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeMonthlyMaximum
        /// </summary>
        [Display(Name = "EmployeeMonthlyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeMonthlyMaximum, Id = Index.EmployeeMonthlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeMonthlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeQuarterlyMinimum
        /// </summary>
        [Display(Name = "EmployeeQuarterlyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeQuarterlyMinimum, Id = Index.EmployeeQuarterlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeQuarterlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployeeQuarterlyMaximum
        /// </summary>
        [Display(Name = "EmployeeQuarterlyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployeeQuarterlyMaximum, Id = Index.EmployeeQuarterlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeQuarterlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets Employee10PayPeriodsYearMin
        /// </summary>
        [Display(Name = "Employee10PayPeriodsYearMin", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employee10PayPeriodsYearMin, Id = Index.Employee10PayPeriodsYearMin, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employee10PayPeriodsYearMin { get; set; }

        /// <summary>
        /// Gets or sets Employee10PayPeriodsYearMax
        /// </summary>
        [Display(Name = "Employee10PayPeriodsYearMax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employee10PayPeriodsYearMax, Id = Index.Employee10PayPeriodsYearMax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employee10PayPeriodsYearMax { get; set; }

        /// <summary>
        /// Gets or sets Employee13PayPeriodsYearMin
        /// </summary>
        [Display(Name = "Employee13PayPeriodsYearMin", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employee13PayPeriodsYearMin, Id = Index.Employee13PayPeriodsYearMin, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employee13PayPeriodsYearMin { get; set; }

        /// <summary>
        /// Gets or sets Employee13PayPeriodsYearMax
        /// </summary>
        [Display(Name = "Employee13PayPeriodsYearMax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employee13PayPeriodsYearMax, Id = Index.Employee13PayPeriodsYearMax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employee13PayPeriodsYearMax { get; set; }

        /// <summary>
        /// Gets or sets Employee22PayPeriodsYearMin
        /// </summary>
        [Display(Name = "Employee22PayPeriodsYearMin", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employee22PayPeriodsYearMin, Id = Index.Employee22PayPeriodsYearMin, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employee22PayPeriodsYearMin { get; set; }

        /// <summary>
        /// Gets or sets Employee22PayPeriodsYearMax
        /// </summary>
        [Display(Name = "Employee22PayPeriodsYearMax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employee22PayPeriodsYearMax, Id = Index.Employee22PayPeriodsYearMax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employee22PayPeriodsYearMax { get; set; }

        /// <summary>
        /// Gets or sets EmployerCalculationMethod
        /// </summary>
        [Display(Name = "EmployerCalculationMethod", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerCalculationMethod, Id = Index.EmployerCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployerCalculationMethod EmployerCalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets EmployerBaseTax
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployerBaseTax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerBaseTax, Id = Index.EmployerBaseTax, FieldType = EntityFieldType.Char, Size = 6)]
        public string EmployerBaseTax { get; set; }

        /// <summary>
        /// Gets or sets EmployerAmountPercent
        /// </summary>
        [Display(Name = "EmployerAmountPercent", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerAmountPercent, Id = Index.EmployerAmountPercent, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployerAmountPercent { get; set; }

        /// <summary>
        /// Gets or sets EmployerLimit
        /// </summary>
        [Display(Name = "EmployerLimit", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerLimit, Id = Index.EmployerLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployerLimit EmployerLimit { get; set; }

        /// <summary>
        /// Gets or sets EmployerAnnualMaximum
        /// </summary>
        [Display(Name = "EmployerAnnualMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerAnnualMaximum, Id = Index.EmployerAnnualMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerAnnualMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerMinimumWeeksWorked
        /// </summary>
        [Display(Name = "EmployerMinimumWeeksWorked", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerMinimumWeeksWorked, Id = Index.EmployerMinimumWeeksWorked, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EmployerMinimumWeeksWorked { get; set; }

        /// <summary>
        /// Gets or sets EmployerDailyMinimum
        /// </summary>
        [Display(Name = "EmployerDailyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerDailyMinimum, Id = Index.EmployerDailyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerDailyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerDailyMaximum
        /// </summary>
        [Display(Name = "EmployerDailyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerDailyMaximum, Id = Index.EmployerDailyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerDailyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerWeeklyMinimum
        /// </summary>
        [Display(Name = "EmployerWeeklyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerWeeklyMinimum, Id = Index.EmployerWeeklyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerWeeklyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerWeeklyMaximum
        /// </summary>
        [Display(Name = "EmployerWeeklyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerWeeklyMaximum, Id = Index.EmployerWeeklyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerWeeklyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerBiweeklyMinimum
        /// </summary>
        [Display(Name = "EmployerBiweeklyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerBiweeklyMinimum, Id = Index.EmployerBiweeklyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerBiweeklyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerBiweeklyMaximum
        /// </summary>
        [Display(Name = "EmployerBiweeklyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerBiweeklyMaximum, Id = Index.EmployerBiweeklyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerBiweeklyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerSemimonthlyMinimum
        /// </summary>
        [Display(Name = "EmployerSemimonthlyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerSemimonthlyMinimum, Id = Index.EmployerSemimonthlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerSemimonthlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerSemimonthlyMaximum
        /// </summary>
        [Display(Name = "EmployerSemimonthlyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerSemimonthlyMaximum, Id = Index.EmployerSemimonthlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerSemimonthlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerMonthlyMinimum
        /// </summary>
        [Display(Name = "EmployerMonthlyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerMonthlyMinimum, Id = Index.EmployerMonthlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerMonthlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerMonthlyMaximum
        /// </summary>
        [Display(Name = "EmployerMonthlyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerMonthlyMaximum, Id = Index.EmployerMonthlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerMonthlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets EmployerQuarterlyMinimum
        /// </summary>
        [Display(Name = "EmployerQuarterlyMinimum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerQuarterlyMinimum, Id = Index.EmployerQuarterlyMinimum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerQuarterlyMinimum { get; set; }

        /// <summary>
        /// Gets or sets EmployerQuarterlyMaximum
        /// </summary>
        [Display(Name = "EmployerQuarterlyMaximum", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.EmployerQuarterlyMaximum, Id = Index.EmployerQuarterlyMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerQuarterlyMaximum { get; set; }

        /// <summary>
        /// Gets or sets Employer10PayPeriodsYearMin
        /// </summary>
        [Display(Name = "Employer10PayPeriodsYearMin", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employer10PayPeriodsYearMin, Id = Index.Employer10PayPeriodsYearMin, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employer10PayPeriodsYearMin { get; set; }

        /// <summary>
        /// Gets or sets Employer10PayPeriodsYearMax
        /// </summary>
        [Display(Name = "Employer10PayPeriodsYearMax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employer10PayPeriodsYearMax, Id = Index.Employer10PayPeriodsYearMax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employer10PayPeriodsYearMax { get; set; }

        /// <summary>
        /// Gets or sets Employer13PayPeriodsYearMin
        /// </summary>
        [Display(Name = "Employer13PayPeriodsYearMin", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employer13PayPeriodsYearMin, Id = Index.Employer13PayPeriodsYearMin, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employer13PayPeriodsYearMin { get; set; }

        /// <summary>
        /// Gets or sets Employer13PayPeriodsYearMax
        /// </summary>
        [Display(Name = "Employer13PayPeriodsYearMax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employer13PayPeriodsYearMax, Id = Index.Employer13PayPeriodsYearMax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employer13PayPeriodsYearMax { get; set; }

        /// <summary>
        /// Gets or sets Employer22PayPeriodsYearMin
        /// </summary>
        [Display(Name = "Employer22PayPeriodsYearMin", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employer22PayPeriodsYearMin, Id = Index.Employer22PayPeriodsYearMin, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employer22PayPeriodsYearMin { get; set; }

        /// <summary>
        /// Gets or sets Employer22PayPeriodsYearMax
        /// </summary>
        [Display(Name = "Employer22PayPeriodsYearMax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Employer22PayPeriodsYearMax, Id = Index.Employer22PayPeriodsYearMax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Employer22PayPeriodsYearMax { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket1
        /// </summary>
        [Display(Name = "WageCeilingForBracket1", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket1, Id = Index.WageCeilingForBracket1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket1
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket1", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket1, Id = Index.TaxAddAmountForBracket1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket1 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket1
        /// </summary>
        [Display(Name = "TaxPercentageForBracket1", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket1, Id = Index.TaxPercentageForBracket1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket1 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket2
        /// </summary>
        [Display(Name = "WageCeilingForBracket2", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket2, Id = Index.WageCeilingForBracket2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket2
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket2", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket2, Id = Index.TaxAddAmountForBracket2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket2 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket2
        /// </summary>
        [Display(Name = "TaxPercentageForBracket2", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket2, Id = Index.TaxPercentageForBracket2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket2 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket3
        /// </summary>
        [Display(Name = "WageCeilingForBracket3", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket3, Id = Index.WageCeilingForBracket3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket3
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket3", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket3, Id = Index.TaxAddAmountForBracket3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket3 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket3
        /// </summary>
        [Display(Name = "TaxPercentageForBracket3", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket3, Id = Index.TaxPercentageForBracket3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket3 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket4
        /// </summary>
        [Display(Name = "WageCeilingForBracket4", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket4, Id = Index.WageCeilingForBracket4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket4
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket4", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket4, Id = Index.TaxAddAmountForBracket4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket4 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket4
        /// </summary>
        [Display(Name = "TaxPercentageForBracket4", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket4, Id = Index.TaxPercentageForBracket4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket4 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket5
        /// </summary>
        [Display(Name = "WageCeilingForBracket5", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket5, Id = Index.WageCeilingForBracket5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket5
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket5", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket5, Id = Index.TaxAddAmountForBracket5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket5 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket5
        /// </summary>
        [Display(Name = "TaxPercentageForBracket5", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket5, Id = Index.TaxPercentageForBracket5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket5 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket6
        /// </summary>
        [Display(Name = "WageCeilingForBracket6", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket6, Id = Index.WageCeilingForBracket6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket6 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket6
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket6", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket6, Id = Index.TaxAddAmountForBracket6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket6 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket6
        /// </summary>
        [Display(Name = "TaxPercentageForBracket6", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket6, Id = Index.TaxPercentageForBracket6, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket6 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket7
        /// </summary>
        [Display(Name = "WageCeilingForBracket7", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket7, Id = Index.WageCeilingForBracket7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket7 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket7
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket7", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket7, Id = Index.TaxAddAmountForBracket7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket7 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket7
        /// </summary>
        [Display(Name = "TaxPercentageForBracket7", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket7, Id = Index.TaxPercentageForBracket7, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket7 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket8
        /// </summary>
        [Display(Name = "WageCeilingForBracket8", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket8, Id = Index.WageCeilingForBracket8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket8 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket8
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket8", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket8, Id = Index.TaxAddAmountForBracket8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket8 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket8
        /// </summary>
        [Display(Name = "TaxPercentageForBracket8", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket8, Id = Index.TaxPercentageForBracket8, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket8 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket9
        /// </summary>
        [Display(Name = "WageCeilingForBracket9", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket9, Id = Index.WageCeilingForBracket9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket9 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket9
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket9", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket9, Id = Index.TaxAddAmountForBracket9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket9 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket9
        /// </summary>
        [Display(Name = "TaxPercentageForBracket9", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket9, Id = Index.TaxPercentageForBracket9, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket9 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket10
        /// </summary>
        [Display(Name = "WageCeilingForBracket10", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket10, Id = Index.WageCeilingForBracket10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket10 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket10
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket10", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket10, Id = Index.TaxAddAmountForBracket10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket10 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket10
        /// </summary>
        [Display(Name = "TaxPercentageForBracket10", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket10, Id = Index.TaxPercentageForBracket10, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket10 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket11
        /// </summary>
        [Display(Name = "WageCeilingForBracket11", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket11, Id = Index.WageCeilingForBracket11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket11 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket11
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket11", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket11, Id = Index.TaxAddAmountForBracket11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket11 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket11
        /// </summary>
        [Display(Name = "TaxPercentageForBracket11", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket11, Id = Index.TaxPercentageForBracket11, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket11 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket12
        /// </summary>
        [Display(Name = "WageCeilingForBracket12", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket12, Id = Index.WageCeilingForBracket12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket12 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket12
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket12", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket12, Id = Index.TaxAddAmountForBracket12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket12 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket12
        /// </summary>
        [Display(Name = "TaxPercentageForBracket12", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket12, Id = Index.TaxPercentageForBracket12, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket12 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket13
        /// </summary>
        [Display(Name = "WageCeilingForBracket13", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket13, Id = Index.WageCeilingForBracket13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket13 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket13
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket13", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket13, Id = Index.TaxAddAmountForBracket13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket13 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket13
        /// </summary>
        [Display(Name = "TaxPercentageForBracket13", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket13, Id = Index.TaxPercentageForBracket13, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket13 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket14
        /// </summary>
        [Display(Name = "WageCeilingForBracket14", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket14, Id = Index.WageCeilingForBracket14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket14 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket14
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket14", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket14, Id = Index.TaxAddAmountForBracket14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket14 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket14
        /// </summary>
        [Display(Name = "TaxPercentageForBracket14", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket14, Id = Index.TaxPercentageForBracket14, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket14 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket15
        /// </summary>
        [Display(Name = "WageCeilingForBracket15", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket15, Id = Index.WageCeilingForBracket15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket15 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket15
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket15", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket15, Id = Index.TaxAddAmountForBracket15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket15 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket15
        /// </summary>
        [Display(Name = "TaxPercentageForBracket15", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket15, Id = Index.TaxPercentageForBracket15, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket15 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket16
        /// </summary>
        [Display(Name = "WageCeilingForBracket16", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket16, Id = Index.WageCeilingForBracket16, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket16 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket16
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket16", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket16, Id = Index.TaxAddAmountForBracket16, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket16 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket16
        /// </summary>
        [Display(Name = "TaxPercentageForBracket16", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket16, Id = Index.TaxPercentageForBracket16, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket16 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket17
        /// </summary>
        [Display(Name = "WageCeilingForBracket17", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket17, Id = Index.WageCeilingForBracket17, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket17 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket17
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket17", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket17, Id = Index.TaxAddAmountForBracket17, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket17 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket17
        /// </summary>
        [Display(Name = "TaxPercentageForBracket17", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket17, Id = Index.TaxPercentageForBracket17, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket17 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket18
        /// </summary>
        [Display(Name = "WageCeilingForBracket18", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket18, Id = Index.WageCeilingForBracket18, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket18 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket18
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket18", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket18, Id = Index.TaxAddAmountForBracket18, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket18 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket18
        /// </summary>
        [Display(Name = "TaxPercentageForBracket18", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket18, Id = Index.TaxPercentageForBracket18, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket18 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket19
        /// </summary>
        [Display(Name = "WageCeilingForBracket19", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket19, Id = Index.WageCeilingForBracket19, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket19 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket19
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket19", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket19, Id = Index.TaxAddAmountForBracket19, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket19 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket19
        /// </summary>
        [Display(Name = "TaxPercentageForBracket19", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket19, Id = Index.TaxPercentageForBracket19, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket19 { get; set; }

        /// <summary>
        /// Gets or sets WageCeilingForBracket20
        /// </summary>
        [Display(Name = "WageCeilingForBracket20", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WageCeilingForBracket20, Id = Index.WageCeilingForBracket20, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WageCeilingForBracket20 { get; set; }

        /// <summary>
        /// Gets or sets TaxAddAmountForBracket20
        /// </summary>
        [Display(Name = "TaxAddAmountForBracket20", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxAddAmountForBracket20, Id = Index.TaxAddAmountForBracket20, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAddAmountForBracket20 { get; set; }

        /// <summary>
        /// Gets or sets TaxPercentageForBracket20
        /// </summary>
        [Display(Name = "TaxPercentageForBracket20", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.TaxPercentageForBracket20, Id = Index.TaxPercentageForBracket20, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxPercentageForBracket20 { get; set; }

        /// <summary>
        /// Gets or sets Level
        /// </summary>
        [Display(Name = "Level", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.Level, Id = Index.Level, FieldType = EntityFieldType.Int, Size = 2)]
        public short Level { get; set; }

        /// <summary>
        /// Gets or sets ListUsageForBaseHoursInclud
        /// </summary>
        [Display(Name = "ListUsageForBaseHoursInclud", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.ListUsageForBaseHoursInclud, Id = Index.ListUsageForBaseHoursInclud, FieldType = EntityFieldType.Int, Size = 2)]
        public short ListUsageForBaseHoursInclud { get; set; }

        /// <summary>
        /// Gets or sets ListUsageForBaseEarningsInc
        /// </summary>
        [Display(Name = "ListUsageForBaseEarningsInc", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.ListUsageForBaseEarningsInc, Id = Index.ListUsageForBaseEarningsInc, FieldType = EntityFieldType.Int, Size = 2)]
        public short ListUsageForBaseEarningsInc { get; set; }

        /// <summary>
        /// Gets or sets WithholdingMethodForBaseEarn
        /// </summary>
        [Display(Name = "WithholdingMethodForBaseEarn", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.WithholdingMethodForBaseEarn, Id = Index.WithholdingMethodForBaseEarn, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.WithholdingMethodForBaseEarn WithholdingMethodForBaseEarn { get; set; }

        /// <summary>
        /// Gets or sets ListUsageForBaseDeductionsI
        /// </summary>
        [Display(Name = "ListUsageForBaseDeductionsI", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.ListUsageForBaseDeductionsI, Id = Index.ListUsageForBaseDeductionsI, FieldType = EntityFieldType.Int, Size = 2)]
        public short ListUsageForBaseDeductionsI { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSETaxTableEffecti
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "INTERNALUSETaxTableEffecti", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.INTERNALUSETaxTableEffecti, Id = Index.INTERNALUSETaxTableEffecti, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime INTERNALUSETaxTableEffecti { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSETaxTableFIPSNu
        /// </summary>
        [Display(Name = "INTERNALUSETaxTableFIPSNu", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.INTERNALUSETaxTableFIPSNu, Id = Index.INTERNALUSETaxTableFIPSNu, FieldType = EntityFieldType.Int, Size = 2)]
        public short INTERNALUSETaxTableFIPSNu { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSETaxTableFIPSCo
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "INTERNALUSETaxTableFIPSCo", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.INTERNALUSETaxTableFIPSCo, Id = Index.INTERNALUSETaxTableFIPSCo, FieldType = EntityFieldType.Char, Size = 2)]
        public string INTERNALUSETaxTableFIPSCo { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CFGPARMVER
        /// </summary>
        [Display(Name = "CFGPARMVER", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.CFGPARMVER, Id = Index.CFGPARMVER, FieldType = EntityFieldType.Int, Size = 2)]
        public short CFGPARMVER { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CFGPARMCNT
        /// </summary>
        [Display(Name = "CFGPARMCNT", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.CFGPARMCNT, Id = Index.CFGPARMCNT, FieldType = EntityFieldType.Int, Size = 2)]
        public short CFGPARMCNT { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSETaxCalculationA
        /// </summary>
        [Display(Name = "INTERNALUSETaxCalculationA", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.INTERNALUSETaxCalculationA, Id = Index.INTERNALUSETaxCalculationA, FieldType = EntityFieldType.Long, Size = 4)]
        public int INTERNALUSETaxCalculationA { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSETaxYTDTracking
        /// </summary>
        [Display(Name = "INTERNALUSETaxYTDTracking", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.INTERNALUSETaxYTDTracking, Id = Index.INTERNALUSETaxYTDTracking, FieldType = EntityFieldType.Long, Size = 4)]
        public int INTERNALUSETaxYTDTracking { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployeeCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }
        
        /// <summary>
        /// Gets or sets AutomaticallyUpdateLocalTax
        /// </summary>
        [Display(Name = "AutomaticallyUpdateLocalTax", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.AutomaticallyUpdateLocalTax, Id = Index.AutomaticallyUpdateLocalTax, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AutomaticallyUpdateLocalTax { get; set; }

        /// <summary>
        /// Gets or sets State
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "State", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.State, Id = Index.State, FieldType = EntityFieldType.Char, Size = 30, Mask = "%-2C")]
        public string State { get; set; }

        /// <summary>
        /// Gets or sets LocalTaxCode
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocalTaxCode", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.LocalTaxCode, Id = Index.LocalTaxCode, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10n")]
        public string LocalTaxCode { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDAatrixTaxType
        /// </summary>
        [Display(Name = "RESERVEDAatrixTaxType", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.RESERVEDAatrixTaxType, Id = Index.RESERVEDAatrixTaxType, FieldType = EntityFieldType.Int, Size = 2)]
        public short RESERVEDAatrixTaxType { get; set; }

        /// <summary>
        /// Gets or sets AutomaticallyPopulateEmployee
        /// </summary>
        [Display(Name = "AutomaticallyPopulateEmployee", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.AutomaticallyPopulateEmployee, Id = Index.AutomaticallyPopulateEmployee, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AutomaticallyPopulateEmployee { get; set; }

        /// <summary>
        /// Gets or sets DefaultDistributionCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultDistributionCode", ResourceType = typeof (CompanyPayrollTaxeResx))]
        [ViewField(Name = Fields.DefaultDistributionCode, Id = Index.DefaultDistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultDistributionCode { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Type string value
        /// </summary>
        public string TypeString => EnumUtility.GetStringValue(Type);

        /// <summary>
        /// Gets W2BoxType string value
        /// </summary>
        public string W2BoxTypeString => EnumUtility.GetStringValue(W2BoxType);

        /// <summary>
        /// Gets EmployeeCalculationMethod string value
        /// </summary>
        public string EmployeeCalculationMethodString => EnumUtility.GetStringValue(EmployeeCalculationMethod);

        /// <summary>
        /// Gets EmployeeLimit string value
        /// </summary>
        public string EmployeeLimitString => EnumUtility.GetStringValue(EmployeeLimit);

        /// <summary>
        /// Gets EmployerCalculationMethod string value
        /// </summary>
        public string EmployerCalculationMethodString => EnumUtility.GetStringValue(EmployerCalculationMethod);

        /// <summary>
        /// Gets EmployerLimit string value
        /// </summary>
        public string EmployerLimitString => EnumUtility.GetStringValue(EmployerLimit);

        /// <summary>
        /// Gets WithholdingMethodForBaseEarn string value
        /// </summary>
        public string WithholdingMethodForBaseEarnString => EnumUtility.GetStringValue(WithholdingMethodForBaseEarn);

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

        #endregion
    }
}
