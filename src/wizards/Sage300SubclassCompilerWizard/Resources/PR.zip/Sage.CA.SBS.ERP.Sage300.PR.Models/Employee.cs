// Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for Employees
    /// </summary>
    public partial class Employees : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTemplate
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeTemplate", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EmployeeTemplate, Id = Index.EmployeeTemplate, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string EmployeeTemplate { get; set; }

        /// <summary>
        /// Gets or sets LastName
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastName", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.LastName, Id = Index.LastName, FieldType = EntityFieldType.Char, Size = 20)]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets FirstName
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FirstName", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.FirstName, Id = Index.FirstName, FieldType = EntityFieldType.Char, Size = 15)]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets MiddleName
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MiddleName", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.MiddleName, Id = Index.MiddleName, FieldType = EntityFieldType.Char, Size = 15)]
        public string MiddleName { get; set; }

        /// <summary>
        /// Gets or sets FullName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FullName", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.FullName, Id = Index.FullName, FieldType = EntityFieldType.Char, Size = 60)]
        public string FullName { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.StateProvince, Id = Index.StateProvince, FieldType = EntityFieldType.Char, Size = 30, Mask = "%-2A")]
        public string StateProvince { get; set; }

        /// <summary>
        /// Gets or sets ZIPCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZIPCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ZIPCode, Id = Index.ZIPCode, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-5d-%-4d")]
        public string ZIPCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets SocialSecurityNumber
        /// </summary>
        [StringLength(11, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SocialSecurityNumber", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SocialSecurityNumber, Id = Index.SocialSecurityNumber, FieldType = EntityFieldType.Char, Size = 11, Mask = "%-3d-%-2d-%-4d")]
        public string SocialSecurityNumber { get; set; }

        /// <summary>
        /// Gets or sets BirthDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BirthDate", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.BirthDate, Id = Index.BirthDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BirthDate { get; set; }

        /// <summary>
        /// Gets or sets EmploymentStatus
        /// </summary>
        [Display(Name = "EmploymentStatus", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EmploymentStatus, Id = Index.EmploymentStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmploymentStatus EmploymentStatus { get; set; }

        /// <summary>
        /// Gets or sets HireDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "HireDate", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.HireDate, Id = Index.HireDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? HireDate { get; set; }

        /// <summary>
        /// Gets or sets TerminationDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TerminationDate", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.TerminationDate, Id = Index.TerminationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? TerminationDate { get; set; }

        /// <summary>
        /// Gets or sets Position
        /// </summary>
        [StringLength(25, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Position", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Position, Id = Index.Position, FieldType = EntityFieldType.Char, Size = 25)]
        public string Position { get; set; }

        /// <summary>
        /// Gets or sets PartTime
        /// </summary>
        [Display(Name = "PartTime", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.PartTime, Id = Index.PartTime, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PartTime { get; set; }

        /// <summary>
        /// Gets or sets PayFrequency
        /// </summary>
        [Display(Name = "PayFrequency", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.PayFrequency, Id = Index.PayFrequency, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.PayFrequency PayFrequency { get; set; }

        /// <summary>
        /// Gets or sets CheckLanguage
        /// </summary>
        [Display(Name = "CheckLanguage", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CheckLanguage, Id = Index.CheckLanguage, FieldType = EntityFieldType.Int, Size = 2)]
        public int CheckLanguage { get; set; }

        /// <summary>
        /// Gets or sets HoursPerPeriod
        /// </summary>
        [Display(Name = "HoursPerPeriod", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.HoursPerPeriod, Id = Index.HoursPerPeriod, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerPeriod { get; set; }

        /// <summary>
        /// Gets or sets WorkersCompensationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkersCompensationCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkersCompensationCode, Id = Index.WorkersCompensationCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string WorkersCompensationCode { get; set; }

        /// <summary>
        /// Gets or sets OvertimeSchedule
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OvertimeSchedule", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.OvertimeSchedule, Id = Index.OvertimeSchedule, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string OvertimeSchedule { get; set; }

        /// <summary>
        /// Gets or sets ShiftDifferentialSchedule
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiftDifferentialSchedule", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ShiftDifferentialSchedule, Id = Index.ShiftDifferentialSchedule, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShiftDifferentialSchedule { get; set; }

        /// <summary>
        /// Gets or sets ShiftNumber
        /// </summary>
        [Display(Name = "ShiftNumber", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ShiftNumber, Id = Index.ShiftNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short ShiftNumber { get; set; }

        /// <summary>
        /// Gets or sets TimesLate
        /// </summary>
        [Display(Name = "TimesLate", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.TimesLate, Id = Index.TimesLate, FieldType = EntityFieldType.Int, Size = 2)]
        public short TimesLate { get; set; }

        /// <summary>
        /// Gets or sets EntrySequence
        /// </summary>
        [Display(Name = "EntrySequence", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EntrySequence, Id = Index.EntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int EntrySequence { get; set; }

        /// <summary>
        /// Gets or sets Class1
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Class1", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Class1, Id = Index.Class1, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Class1 { get; set; }

        /// <summary>
        /// Gets or sets Class2
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Class2", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Class2, Id = Index.Class2, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Class2 { get; set; }

        /// <summary>
        /// Gets or sets Class3
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Class3", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Class3, Id = Index.Class3, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Class3 { get; set; }

        /// <summary>
        /// Gets or sets Class4
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Class4", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Class4, Id = Index.Class4, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Class4 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentCode1", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SegmentCode1, Id = Index.SegmentCode1, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentCode1 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentCode2", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SegmentCode2, Id = Index.SegmentCode2, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentCode2 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentCode3", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SegmentCode3, Id = Index.SegmentCode3, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode3 { get; set; }

        /// <summary>
        /// Gets or sets Phone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Phone, Id = Index.Phone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string Phone { get; set; }

        /// <summary>
        /// Gets or sets Manager
        /// </summary>
        [StringLength(25, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Manager", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Manager, Id = Index.Manager, FieldType = EntityFieldType.Char, Size = 25)]
        public string Manager { get; set; }

        /// <summary>
        /// Gets or sets LastReviewDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastReviewDate", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.LastReviewDate, Id = Index.LastReviewDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastReviewDate { get; set; }

        /// <summary>
        /// Gets or sets DateOfLastRaise
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateOfLastRaise", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.DateOfLastRaise, Id = Index.DateOfLastRaise, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateOfLastRaise { get; set; }

        /// <summary>
        /// Gets or sets AlternateAddressLine1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AlternateAddressLine1", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AlternateAddressLine1, Id = Index.AlternateAddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AlternateAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AlternateAddressLine2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AlternateAddressLine2", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AlternateAddressLine2, Id = Index.AlternateAddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AlternateAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AlternateAddressLine3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AlternateAddressLine3", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AlternateAddressLine3, Id = Index.AlternateAddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AlternateAddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AlternateAddressLine4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AlternateAddressLine4", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AlternateAddressLine4, Id = Index.AlternateAddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AlternateAddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets AlternateCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AlternateCity", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AlternateCity, Id = Index.AlternateCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string AlternateCity { get; set; }

        /// <summary>
        /// Gets or sets AlternateStateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AlternateStateProvince", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AlternateStateProvince, Id = Index.AlternateStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string AlternateStateProvince { get; set; }

        /// <summary>
        /// Gets or sets AlternateZIPPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AlternateZIPPostalCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AlternateZIPPostalCode, Id = Index.AlternateZIPPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string AlternateZIPPostalCode { get; set; }

        /// <summary>
        /// Gets or sets AlternateCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AlternateCountry", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.AlternateCountry, Id = Index.AlternateCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string AlternateCountry { get; set; }

        /// <summary>
        /// Gets or sets Gender
        /// </summary>
        [Display(Name = "Gender", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Gender, Id = Index.Gender, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.Gender Gender { get; set; }

        /// <summary>
        /// Gets or sets EmergencyContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmergencyContact", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EmergencyContact, Id = Index.EmergencyContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string EmergencyContact { get; set; }

        /// <summary>
        /// Gets or sets EmergencyPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmergencyPhone", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EmergencyPhone, Id = Index.EmergencyPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string EmergencyPhone { get; set; }

        /// <summary>
        /// Gets or sets MinimumWage
        /// </summary>
        [Display(Name = "MinimumWage", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.MinimumWage, Id = Index.MinimumWage, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MinimumWage { get; set; }

        /// <summary>
        /// Gets or sets VacationID
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VacationID", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.VacationID, Id = Index.VacationID, FieldType = EntityFieldType.Char, Size = 6)]
        public string VacationID { get; set; }

        /// <summary>
        /// Gets or sets SickPayID
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SickPayID", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SickPayID, Id = Index.SickPayID, FieldType = EntityFieldType.Char, Size = 6)]
        public string SickPayID { get; set; }

        /// <summary>
        /// Gets or sets CompTimeID
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompTimeID", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CompTimeID, Id = Index.CompTimeID, FieldType = EntityFieldType.Char, Size = 6)]
        public string CompTimeID { get; set; }

        /// <summary>
        /// Gets or sets SSNFormat
        /// </summary>
        [Display(Name = "SSNFormat", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SSNFormat, Id = Index.SSNFormat, FieldType = EntityFieldType.Int, Size = 2)]
        public short SSNFormat { get; set; }

        /// <summary>
        /// Gets or sets Disability
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Disability", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Disability, Id = Index.Disability, FieldType = EntityFieldType.Char, Size = 6)]
        public string Disability { get; set; }

        /// <summary>
        /// Gets or sets RPP
        /// </summary>
        [StringLength(7, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RPP", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.RPP, Id = Index.RPP, FieldType = EntityFieldType.Char, Size = 7)]
        public string RPP { get; set; }

        /// <summary>
        /// Gets or sets StateOfHire
        /// </summary>
        [Display(Name = "StateOfHire", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.StateOfHire, Id = Index.StateOfHire, FieldType = EntityFieldType.Int, Size = 2)]
        public StateOfHire StateOfHire { get; set; }

        /// <summary>
        /// Gets or sets TimecardUserID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TimecardUserID", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.TimecardUserID, Id = Index.TimecardUserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string TimecardUserID { get; set; }

        /// <summary>
        /// Gets or sets DirectDeposit
        /// </summary>
        [Display(Name = "DirectDeposit", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.DirectDeposit, Id = Index.DirectDeposit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DirectDeposit { get; set; }

        /// <summary>
        /// Gets or sets BankTransferName
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankTransferName", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.BankTransferName, Id = Index.BankTransferName, FieldType = EntityFieldType.Char, Size = 30, Mask = "%-22c")]
        public string BankTransferName { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 19, Mask = "%-15c")]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets DiscretionaryData
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DiscretionaryData", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.DiscretionaryData, Id = Index.DiscretionaryData, FieldType = EntityFieldType.Char, Size = 2)]
        public string DiscretionaryData { get; set; }

        /// <summary>
        /// Gets or sets WorkersCompGroup
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkersCompGroup", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkersCompGroup, Id = Index.WorkersCompGroup, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string WorkersCompGroup { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }
        
        /// <summary>
        /// Gets or sets RegularHoursPerDay
        /// </summary>
        [Display(Name = "RegularHoursPerDay", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.RegularHoursPerDay, Id = Index.RegularHoursPerDay, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal RegularHoursPerDay { get; set; }

        /// <summary>
        /// Gets or sets OvertimeCalculation
        /// </summary>
        [Display(Name = "OvertimeCalculation", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.OvertimeCalculation, Id = Index.OvertimeCalculation, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.OvertimeCalculation OvertimeCalculation { get; set; }

        /// <summary>
        /// Gets or sets CountryCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CountryCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CountryCode, Id = Index.CountryCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-2C")]
        public string CountryCode { get; set; }

        /// <summary>
        /// Gets or sets WorkClassificationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkClassificationCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkClassificationCode, Id = Index.WorkClassificationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string WorkClassificationCode { get; set; }

        /// <summary>
        /// Gets or sets HoursPerWeek
        /// </summary>
        [Display(Name = "HoursPerWeek", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.HoursPerWeek, Id = Index.HoursPerWeek, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursPerWeek { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets CalcOTOnAWeeklyBasis
        /// </summary>
        [Display(Name = "CalcOTOnAWeeklyBasis", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CalcOTOnAWeeklyBasis, Id = Index.CalcOTOnAWeeklyBasis, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CalcOTOnAWeeklyBasis { get; set; }

        /// <summary>
        /// Gets or sets USCitizen
        /// </summary>
        [Display(Name = "USCitizen", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.USCitizen, Id = Index.USCitizen, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool USCitizen { get; set; }

        /// <summary>
        /// Gets or sets WorkLocation
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkLocation", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkLocation, Id = Index.WorkLocation, FieldType = EntityFieldType.Char, Size = 50)]
        public string WorkLocation { get; set; }

        /// <summary>
        /// Gets or sets WorkLocationAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkLocationAddress2", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkLocationAddress2, Id = Index.WorkLocationAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string WorkLocationAddress2 { get; set; }

        /// <summary>
        /// Gets or sets WorkLocationAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkLocationAddress3", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkLocationAddress3, Id = Index.WorkLocationAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string WorkLocationAddress3 { get; set; }

        /// <summary>
        /// Gets or sets WorkLocationAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkLocationAddress4", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkLocationAddress4, Id = Index.WorkLocationAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string WorkLocationAddress4 { get; set; }

        /// <summary>
        /// Gets or sets WorkLocationCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkLocationCity", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkLocationCity, Id = Index.WorkLocationCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string WorkLocationCity { get; set; }

        /// <summary>
        /// Gets or sets WorkLocationStateProv
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkLocationStateProv", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkLocationStateProv, Id = Index.WorkLocationStateProv, FieldType = EntityFieldType.Char, Size = 30, Mask = "%-30c")]
        public string WorkLocationStateProv { get; set; }

        /// <summary>
        /// Gets or sets WorkLocationZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkLocationZipPostalCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkLocationZipPostalCode, Id = Index.WorkLocationZipPostalCode, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-20c")]
        public string WorkLocationZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets WorkLocationCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkLocationCountry", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.WorkLocationCountry, Id = Index.WorkLocationCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string WorkLocationCountry { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDSegmentCode4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RESERVEDSegmentCode4", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.RESERVEDSegmentCode4, Id = Index.RESERVEDSegmentCode4, FieldType = EntityFieldType.Char, Size = 15)]
        public string RESERVEDSegmentCode4 { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDSegmentCode5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RESERVEDSegmentCode5", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.RESERVEDSegmentCode5, Id = Index.RESERVEDSegmentCode5, FieldType = EntityFieldType.Char, Size = 15)]
        public string RESERVEDSegmentCode5 { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDSegmentCode6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RESERVEDSegmentCode6", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.RESERVEDSegmentCode6, Id = Index.RESERVEDSegmentCode6, FieldType = EntityFieldType.Char, Size = 15)]
        public string RESERVEDSegmentCode6 { get; set; }

        /// <summary>
        /// Gets or sets SyncMasterGUID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SyncMasterGUID", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SyncMasterGUID, Id = Index.SyncMasterGUID, FieldType = EntityFieldType.Char, Size = 36)]
        public string SyncMasterGUID { get; set; }

        /// <summary>
        /// Gets or sets EmployeeElectronicW2Consent
        /// </summary>
        [Display(Name = "EmployeeElectronicW2Consent", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EmployeeElectronicW2Consent, Id = Index.EmployeeElectronicW2Consent, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EmployeeElectronicW2Consent { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployeeCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSecurityFlag1
        /// </summary>
        [Display(Name = "EmployeeSecurityFlag1", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EmployeeSecurityFlag1, Id = Index.EmployeeSecurityFlag1, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployeeSecurityFlag1 { get; set; }

        /// <summary>
        /// Gets or sets EmployeeSecurityFlag2
        /// </summary>
        [Display(Name = "EmployeeSecurityFlag2", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EmployeeSecurityFlag2, Id = Index.EmployeeSecurityFlag2, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployeeSecurityFlag2 { get; set; }

        /// <summary>
        /// Gets or sets INTERNALUSESelectionList
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "INTERNALUSESelectionList", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.INTERNALUSESelectionList, Id = Index.INTERNALUSESelectionList, FieldType = EntityFieldType.Char, Size = 8)]
        public string INTERNALUSESelectionList { get; set; }

        /// <summary>
        /// Gets or sets JobCategory
        /// </summary>
        [Display(Name = "JobCategory", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.JobCategory, Id = Index.JobCategory, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.JobCategory JobCategory { get; set; }

        /// <summary>
        /// Gets or sets Ethnicity
        /// </summary>
        [Display(Name = "Ethnicity", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Ethnicity, Id = Index.Ethnicity, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.Ethnicity Ethnicity { get; set; }

        /// <summary>
        /// Gets or sets CAEthnicity
        /// </summary>
        [Display(Name = "CAEthnicity", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CAEthnicity, Id = Index.CAEthnicity, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.CAEthnicity CAEthnicity { get; set; }

        /// <summary>
        /// Gets or sets EmployerDental
        /// </summary>
        [Display(Name = "EmployerDental", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.EmployerDental, Id = Index.EmployerDental, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EmployerDental EmployerDental { get; set; }

        /// <summary>
        /// Gets or sets PayerDental
        /// </summary>
        [Display(Name = "PayerDental", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.PayerDental, Id = Index.PayerDental, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.PayerDental PayerDental { get; set; }

        /// <summary>
        /// Gets or sets WorkLocationCounty
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkLocationCounty", ResourceType = typeof(EmployeeResx))]
        [ViewField(Name = Fields.WorkLocationCounty, Id = Index.WorkLocationCounty, FieldType = EntityFieldType.Char, Size = 30)]
        public string WorkLocationCounty { get; set; }

        /// <summary>
        /// Gets or sets IsNew
        /// </summary>
        [IgnoreExportImport]
        public bool IsNew { get; set; }

        /// <summary>
        /// Gets or sets IsHQActivated
        /// </summary>
        [IgnoreExportImport]
        public bool IsHQActivated { get; set; }

        /// <summary>
        /// Gets or sets IsHQSynced
        /// </summary>
        [IgnoreExportImport]
        public bool IsHQSynced { get; set; }

        /// <summary>
        /// Gets or sets EmployeeNotes
        /// </summary>
        [IgnoreExportImport]
        public string EmployeeNotes { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets EmploymentStatus string value
        /// </summary>
        public string EmploymentStatusString => EnumUtility.GetStringValue(EmploymentStatus);

        /// <summary>
        /// Gets PayFrequency string value
        /// </summary>
        public string PayFrequencyString => EnumUtility.GetStringValue(PayFrequency);

        /// <summary>
        /// Gets Gender string value
        /// </summary>
        public string GenderString => EnumUtility.GetStringValue(Gender);

        /// <summary>
        /// Gets OvertimeCalculation string value
        /// </summary>
        public string OvertimeCalculationString => EnumUtility.GetStringValue(OvertimeCalculation);

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

        /// <summary>
        /// Gets JobCategory string value
        /// </summary>
        public string JobCategoryString => EnumUtility.GetStringValue(JobCategory);

        /// <summary>
        /// Gets Ethnicity string value
        /// </summary>
        public string EthnicityString => EnumUtility.GetStringValue(Ethnicity);

        /// <summary>
        /// Gets CAEthnicity string value
        /// </summary>
        public string CAEthnicityString => EnumUtility.GetStringValue(CAEthnicity);

        /// <summary>
        /// Gets EmployerDental string value
        /// </summary>
        public string EmployerDentalString => EnumUtility.GetStringValue(EmployerDental);

        /// <summary>
        /// Gets PayerDental string value
        /// </summary>
        public string PayerDentalString => EnumUtility.GetStringValue(PayerDental);

        #endregion
    }
}
