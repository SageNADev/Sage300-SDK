// Copyright (c) 2025 The Sage Group plc or its licensors.  All rights reserved.
#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CombineEFTFile
    /// </summary>
    public partial class CombineEFTFile : ModelBase
    {
        /// <summary>
        /// Gets or sets CompanyEFTBank
        /// </summary>
        [Display(Name = "CompanyEFTBank", ResourceType = typeof(CombineEFTFileResx))]
        [ViewField(Name = Fields.CompanyEFTBank, Id = Index.CompanyEFTBank, FieldType = EntityFieldType.Char, Size = 8)]
        public string CompanyEFTBank { get; set; }

        /// <summary>
        /// Gets or sets BankName
        /// </summary>
        [Display(Name = "BankName", ResourceType = typeof(CombineEFTFileResx))]
        [ViewField(Name = Fields.BankName, Id = Index.BankName, FieldType = EntityFieldType.Char, Size = 60)]
        public string BankName { get; set; }

        /// <summary>
        /// Gets or sets FileCreationFromDate
        /// </summary>
        [Display(Name = "FileCreationFromDate", ResourceType = typeof(CombineEFTFileResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FileCreationFromDate, Id = Index.FileCreationFromDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? FileCreationFromDate { get; set; }

        /// <summary>
        /// Gets or sets FileCreationToDate
        /// </summary>
        [Display(Name = "FileCreationToDate", ResourceType = typeof(CombineEFTFileResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FileCreationToDate, Id = Index.FileCreationToDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? FileCreationToDate { get; set; }

        /// <summary>
        /// Gets or sets UnprocessedFilesOnly
        /// </summary>
        [Display(Name = "UnprocessedFilesOnly", ResourceType = typeof(CombineEFTFileResx))]
        [ViewField(Name = Fields.UnprocessedFilesOnly, Id = Index.UnprocessedFilesOnly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UnprocessedFilesOnly { get; set; }

        /// <summary>
        /// Gets or sets FileCreationNumber
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FileCreationNumber", ResourceType = typeof(CombineEFTFileResx))]
        [ViewField(Name = Fields.FileCreationNumber, Id = Index.FileCreationNumber, FieldType = EntityFieldType.Char, Size = 4)]
        public string FileCreationNumber { get; set; }

        /// <summary>
        /// Gets or sets FileCreationDescription
        /// </summary>
        [Display(Name = "FileCreationDescription", ResourceType = typeof(CombineEFTFileResx))]
        [ViewField(Name = Fields.FileCreationDescription, Id = Index.FileCreationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string FileCreationDescription { get; set; }

        /// <summary>
        /// Gets or sets FileCreationDate
        /// </summary>
        [Display(Name = "FileCreationDate", ResourceType = typeof(CombineEFTFileResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FileCreationDate, Id = Index.FileCreationDate, FieldType = EntityFieldType.Char, Size = 5)]
        public DateTime? FileCreationDate { get; set; }

        /// <summary>
        /// Gets or sets FileExtension
        /// </summary>
        [Display(Name = "FileExtension", ResourceType = typeof(CombineEFTFileResx))]
        [ViewField(Name = Fields.FileExtension, Id = Index.FileExtension, FieldType = EntityFieldType.Char, Size = 3)]
        public string FileExtension { get; set; }

        /// <summary>
        /// Gets or sets FileName
        /// </summary>
        [Display(Name = "FileName", ResourceType = typeof(CombineEFTFileResx))]
        [ViewField(Name = Fields.FileName, Id = Index.FileName, FieldType = EntityFieldType.Char, Size = 32)]
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets LocalFilePath
        /// </summary>
        [Display(Name = "LocalFilePath", ResourceType = typeof(CombineEFTFileResx))]
        [ViewField(Name = Fields.LocalFilePath, Id = Index.LocalFilePath, FieldType = EntityFieldType.Char, Size = 128)]
        public string LocalFilePath { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(CombineEFTFileResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets CombineRunSequence
        /// </summary>
        [Display(Name = "CombineRunSequence", ResourceType = typeof(CombineEFTFileResx))]
        [ViewField(Name = Fields.CombineRunSequence, Id = Index.CombineRunSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long CombineRunSequence { get; set; }

    }
}



