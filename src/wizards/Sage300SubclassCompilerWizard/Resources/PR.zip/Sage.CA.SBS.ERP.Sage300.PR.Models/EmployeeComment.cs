// Copyright (c) 2023-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeComment
    /// </summary>
    public partial class EmployeeComment : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets DateEntered
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateEntered", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.DateEntered, Id = Index.DateEntered, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateEntered { get; set; }

        /// <summary>
        /// Gets or sets Uniquifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Uniquifier", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Uniquifier, Id = Index.Uniquifier, FieldType = EntityFieldType.Long, Size = 4)]
        public int Uniquifier { get; set; }

        /// <summary>
        /// Gets or sets ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpiryDate", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ExpiryDate, Id = Index.ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets FollowUpDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FollowUpDate", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.FollowUpDate, Id = Index.FollowUpDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FollowUpDate { get; set; }

        /// <summary>
        /// Gets or sets UserID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets CommentType
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommentType", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CommentType, Id = Index.CommentType, FieldType = EntityFieldType.Char, Size = 8)]
        public string CommentType { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [StringLength(2500, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 2500)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets ReservedComment0
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReservedComment0", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ReservedComment0, Id = Index.ReservedComment0, FieldType = EntityFieldType.Char, Size = 250)]
        public string ReservedComment0 { get; set; }

        /// <summary>
        /// Gets or sets ReservedComment1
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReservedComment1", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ReservedComment1, Id = Index.ReservedComment1, FieldType = EntityFieldType.Char, Size = 250)]
        public string ReservedComment1 { get; set; }

        /// <summary>
        /// Gets or sets ReservedComment2
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReservedComment2", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ReservedComment2, Id = Index.ReservedComment2, FieldType = EntityFieldType.Char, Size = 250)]
        public string ReservedComment2 { get; set; }

        /// <summary>
        /// Gets or sets ReservedComment3
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReservedComment3", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ReservedComment3, Id = Index.ReservedComment3, FieldType = EntityFieldType.Char, Size = 250)]
        public string ReservedComment3 { get; set; }

        /// <summary>
        /// Gets or sets ReservedComment4
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReservedComment4", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ReservedComment4, Id = Index.ReservedComment4, FieldType = EntityFieldType.Char, Size = 250)]
        public string ReservedComment4 { get; set; }

        /// <summary>
        /// Gets or sets ReservedComment5
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReservedComment5", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ReservedComment5, Id = Index.ReservedComment5, FieldType = EntityFieldType.Char, Size = 250)]
        public string ReservedComment5 { get; set; }

        /// <summary>
        /// Gets or sets ReservedComment6
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReservedComment6", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ReservedComment6, Id = Index.ReservedComment6, FieldType = EntityFieldType.Char, Size = 250)]
        public string ReservedComment6 { get; set; }

        /// <summary>
        /// Gets or sets ReservedComment7
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReservedComment7", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ReservedComment7, Id = Index.ReservedComment7, FieldType = EntityFieldType.Char, Size = 250)]
        public string ReservedComment7 { get; set; }

        /// <summary>
        /// Gets or sets ReservedComment8
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReservedComment8", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ReservedComment8, Id = Index.ReservedComment8, FieldType = EntityFieldType.Char, Size = 250)]
        public string ReservedComment8 { get; set; }

        /// <summary>
        /// Gets or sets ReservedComment9
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReservedComment9", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ReservedComment9, Id = Index.ReservedComment9, FieldType = EntityFieldType.Char, Size = 250)]
        public string ReservedComment9 { get; set; }

        #region UI Strings

        #endregion
    }
}
