// Copyright (c) 2024 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using System.Collections.Generic;

#endregion


namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeSelectionList
    /// </summary>
    public partial class EmployeeSelectionListModel : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EmployeeSelectionList"/> class.
        /// </summary>
        public EmployeeSelectionListModel()
        {
            OptionalField = new EnumerableResponse<OptionalFields>();
        }

        /// <summary>
        /// Gets or sets EmployeeList
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeSelectionList", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.EmployeeList, Id = Index.EmployeeList, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EmployeeList { get; set; }

        /// <summary>
        /// Gets or sets EmployeeListDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeListDesc", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.EmployeeListDesc, Id = Index.EmployeeListDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string EmployeeListDesc { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets CombineEmplSelListID1
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CombineSelList1", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.CombineSelList1, Id = Index.CombineSelList1, FieldType = EntityFieldType.Char, Size = 8)]
        public string CombineSelList1 { get; set; }

        /// <summary>
        /// Gets or sets CombineEmplSelListID2
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CombineSelList2", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.CombineSelList2, Id = Index.CombineSelList2, FieldType = EntityFieldType.Char, Size = 8)]
        public string CombineSelList2 { get; set; }

        /// <summary>
        /// Gets or sets FrequencyDaily
        /// </summary>
        [Display(Name = "FrequencyDaily", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.FrequencyDaily, Id = Index.FrequencyDaily, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FrequencyDaily { get; set; }

        /// <summary>
        /// Gets or sets FrequencyWeekly
        /// </summary>
        [Display(Name = "FrequencyWeekly", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.FrequencyWeekly, Id = Index.FrequencyDaily, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FrequencyWeekly { get; set; }

        /// <summary>
        /// Gets or sets FrequencyBiweekly
        /// </summary>
        [Display(Name = "FrequencyBiweekly", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.FrequencyBiweekly, Id = Index.FrequencyBiweekly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FrequencyBiweekly { get; set; }

        /// <summary>
        /// Gets or sets FrequencySemimonthly
        /// </summary>
        [Display(Name = "FrequencySemimonthly", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.FrequencySemimonthly, Id = Index.FrequencySemimonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FrequencySemimonthly { get; set; }

        /// <summary>
        /// Gets or sets Frequency22Year
        /// </summary>
        [Display(Name = "Frequency22Year", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.Frequency22Year, Id = Index.Frequency22Year, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Frequency22Year { get; set; }

        /// <summary>
        /// Gets or sets Frequency13Year
        /// </summary>
        [Display(Name = "Frequency13Year", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.Frequency13Year, Id = Index.Frequency13Year, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Frequency13Year { get; set; }

        /// <summary>
        /// Gets or sets FrequencyMonthly
        /// </summary>
        [Display(Name = "FrequencyMonthly", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.FrequencyMonthly, Id = Index.FrequencyMonthly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FrequencyMonthly { get; set; }

        /// <summary>
        /// Gets or sets Frequency10Year
        /// </summary>
        [Display(Name = "Frequency10Year", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.Frequency10Year, Id = Index.Frequency10Year, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Frequency10Year { get; set; }

        /// <summary>
        /// Gets or sets FrequencyQuarterly
        /// </summary>
        [Display(Name = "FrequencyQuarterly", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.FrequencyDaily, Id = Index.FrequencyQuarterly, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FrequencyQuarterly { get; set; }

        /// <summary>
        /// Gets or sets Active
        /// </summary>
        [Display(Name = "Active", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.Active, Id = Index.Active, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Active { get; set; }

        /// <summary>
        /// Gets or sets Inactive
        /// </summary>
        [Display(Name = "Inactive", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.Inactive, Id = Index.Inactive, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Inactive { get; set; }

        /// <summary>
        /// Gets or sets InactROE
        /// </summary>
        [Display(Name = "InactROE", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.InactROE, Id = Index.InactROE, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InactROE { get; set; }

        /// <summary>
        /// Gets or sets Terminated
        /// </summary>
        [Display(Name = "Terminated", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.Terminated, Id = Index.Terminated, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Terminated { get; set; }

        /// <summary>
        /// Gets or sets TERMROE
        /// </summary>
        [Display(Name = "TermROE", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.TermROE, Id = Index.TermROE, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TermROE { get; set; }

        /// <summary>
        /// Gets or sets PartTime
        /// </summary>
        [Display(Name = "PartTime", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.PartTime, Id = Index.PartTime, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PartTime { get; set; }

        /// <summary>
        /// Gets or sets FullTime
        /// </summary>
        [Display(Name = "FullTime", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.FullTime, Id = Index.FullTime, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FullTime { get; set; }

        /// <summary>
        /// Gets or sets DirectDeposit
        /// </summary>
        [Display(Name = "DirectDeposit", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.DirectDeposit, Id = Index.DirectDeposit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DirectDeposit { get; set; }

        /// <summary>
        /// Gets or sets NonDirectDeposit
        /// </summary>
        [Display(Name = "NonDirectDeposit", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.NonDirectDeposit, Id = Index.NonDirectDeposit, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool NonDirectDeposit { get; set; }

        /// <summary>
        /// Gets or sets Position
        /// </summary>
        [StringLength(25, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Position", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.Position, Id = Index.Position, FieldType = EntityFieldType.Char, Size = 25)]
        public string Position { get; set; }

        /// <summary>
        /// Gets or sets Manager
        /// </summary>
        [StringLength(25, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Manager", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.Manager, Id = Index.Manager, FieldType = EntityFieldType.Char, Size = 25)]
        public string Manager { get; set; }

        /// <summary>
        /// Gets or sets SelectItem1
        /// </summary>
        [Display(Name = "SelectItem1", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem1, Id = Index.SelectItem1, FieldType = EntityFieldType.Int, Size = 2)]
        public short SelectItem1 { get; set; }

        /// <summary>
        /// Gets or sets SelectSubItem1
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectSubItem1", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectSubItem1, Id = Index.SelectSubItem1, FieldType = EntityFieldType.Char, Size = 6)]
        public string SelectSubItem1 { get; set; }

        /// <summary>
        /// Gets or sets SelectItem1From
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectItem1From", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem1From, Id = Index.SelectItem1From, FieldType = EntityFieldType.Char, Size = 60)]
        public string SelectItem1From { get; set; }

        /// <summary>
        /// Gets or sets SelectItem1To
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectItem1To", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem1To, Id = Index.SelectItem1To, FieldType = EntityFieldType.Char, Size = 60)]
        public string SelectItem1To { get; set; }

        /// <summary>
        /// Gets or sets SelectItem2
        /// </summary>
        [Display(Name = "SelectItem2", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem2, Id = Index.SelectItem2, FieldType = EntityFieldType.Int, Size = 2)]
        public short SelectItem2 { get; set; }

        /// <summary>
        /// Gets or sets SelectSubItem2
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectSubItem2", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectSubItem2, Id = Index.SelectSubItem2, FieldType = EntityFieldType.Char, Size = 6)]
        public string SelectSubItem2 { get; set; }

        /// <summary>
        /// Gets or sets SelectItem2From
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectItem2From", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem2From, Id = Index.SelectItem2From, FieldType = EntityFieldType.Char, Size = 60)]
        public string SelectItem2From { get; set; }

        /// <summary>
        /// Gets or sets SelectItem2To
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectItem2To", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem2To, Id = Index.SelectItem2To, FieldType = EntityFieldType.Char, Size = 60)]
        public string SelectItem2To { get; set; }

        /// <summary>
        /// Gets or sets SelectItem3
        /// </summary>
        [Display(Name = "SelectItem3", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem3, Id = Index.SelectItem3, FieldType = EntityFieldType.Int, Size = 2)]
        public short SelectItem3 { get; set; }

        /// <summary>
        /// Gets or sets SelectSubItem3
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectSubItem3", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectSubItem3, Id = Index.SelectSubItem3, FieldType = EntityFieldType.Char, Size = 6)]
        public string SelectSubItem3 { get; set; }

        /// <summary>
        /// Gets or sets SelectItem3From
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectItem3From", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem3From, Id = Index.SelectItem3From, FieldType = EntityFieldType.Char, Size = 60)]
        public string SelectItem3From { get; set; }

        /// <summary>
        /// Gets or sets SelectItem3To
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectItem3To", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem3To, Id = Index.SelectItem3To, FieldType = EntityFieldType.Char, Size = 60)]
        public string SelectItem3To { get; set; }

        /// <summary>
        /// Gets or sets SelectItem4
        /// </summary>
        [Display(Name = "SelectItem4", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem4, Id = Index.SelectItem4, FieldType = EntityFieldType.Int, Size = 2)]
        public short SelectItem4 { get; set; }

        /// <summary>
        /// Gets or sets SelectSubItem4
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectSubItem4", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectSubItem4, Id = Index.SelectSubItem4, FieldType = EntityFieldType.Char, Size = 6)]
        public string SelectSubItem4 { get; set; }

        /// <summary>
        /// Gets or sets SelectItem4From
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectItem4From", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem4From, Id = Index.SelectItem4From, FieldType = EntityFieldType.Char, Size = 60)]
        public string SelectItem4From { get; set; }

        /// <summary>
        /// Gets or sets SelectItem4To
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectItem4To", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SelectItem4To, Id = Index.SelectItem4To, FieldType = EntityFieldType.Char, Size = 60)]
        public string SelectItem4To { get; set; }

        /// <summary>
        /// Gets or sets OptFld1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptFld1", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.OptFld1, Id = Index.OptFld1, FieldType = EntityFieldType.Char, Size = 12)]
        public string OptFld1 { get; set; }

        /// <summary>
        /// Gets or sets OptFld1From
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptFld1From", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.OptFld1From, Id = Index.OptFld1From, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptFld1From { get; set; }

        /// <summary>
        /// Gets or sets OptFld1To
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptFld1To", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.OptFld1To, Id = Index.OptFld1To, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptFld1To { get; set; }

        /// <summary>
        /// Gets or sets OptFld2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptFld2", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.OptFld2, Id = Index.OptFld2, FieldType = EntityFieldType.Char, Size = 12)]
        public string OptFld2 { get; set; }

        /// <summary>
        /// Gets or sets OptFld2From
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptFld2From", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.OptFld2From, Id = Index.OptFld2From, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptFld2From { get; set; }

        /// <summary>
        /// Gets or sets OptFld2To
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptFld2To", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.OptFld2To, Id = Index.OptFld2To, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptFld2To { get; set; }

        /// <summary>
        /// Gets or sets OptFld3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptFld3", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.OptFld3, Id = Index.OptFld3, FieldType = EntityFieldType.Char, Size = 12)]
        public string OptFld3 { get; set; }

        /// <summary>
        /// Gets or sets OptFld3From
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptFld3From", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.OptFld3From, Id = Index.OptFld3From, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptFld3From { get; set; }

        /// <summary>
        /// Gets or sets OptFld3To
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptFld3To", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.OptFld3To, Id = Index.OptFld3To, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptFld3To { get; set; }

        /// <summary>
        /// Gets or sets ListTotal
        /// </summary>
        [Display(Name = "ListTotal", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.ListTotal, Id = Index.ListTotal, FieldType = EntityFieldType.Int, Size = 2)]
        public short ListTotal { get; set; }

        /// <summary>
        /// Gets or sets SecurityFlag
        /// </summary>
        [Display(Name = "SecurityFlag", ResourceType = typeof(EmployeeSelectionListResx))]
        [ViewField(Name = Fields.SecurityFlag, Id = Index.SecurityFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public short SecurityFlag { get; set; }

        /// <summary>
        /// Gets or sets Employees
        /// </summary>
        public List<string> Employees { get; set; }

        /// <summary>
        /// Gets or Sets Optionalfields
        /// </summary>
        public string Optionalfields { get; set; }

        /// <summary>
        /// Gets or sets the optional fields inforamtion
        /// </summary>
        /// <value>The optional field.</value>
        public EnumerableResponse<OptionalFields> OptionalField { get; set; }

        /// <summary>
        /// Gets or sets optional grid visibility
        /// </summary>
        /// <value><c>true</c> if this instance is optional grid visible; otherwise, <c>false</c>.</value>
        public bool IsOptionalGridVisible { get; set; }

        /// <summary>
        /// Gets or sets insert error message
        /// <value>Error message</value>
        public string ErrorMessage { get; set; }
    }

    // The purpose of creating the following two classes is to pass all the criteria screen values for processing and to obtain the filter values.

    /// <summary>
    /// Combined data model containing employee selection data and criteria filter items.
    /// </summary>
    public class CombinedData
    {
        public EmployeeSelectionListModel ModelData { get; set; }
        public List<FilterItem> FilterItems { get; set; }
        public List<OptionalFieldData> optionalFieldData { get; set; }
    }

    /// <summary>
    /// A filteritem class contains  key, selected value, and range values.
    /// </summary>
    public class FilterItem
    {
        public string Key { get; set; }
        public string SelectedValue { get; set; }
        public string TxtValue { get; set; }
        public string TxtToValue { get; set; }
        public string TxtFromValue { get; set; }
    }

    /// <summary>
    /// A class for OptionalFieldData
    /// </summary>
    public class OptionalFieldData
    {
        public string SelectOptionalField { get; set; }
        public string SelectOptionalFieldFromValue { get; set; }
        public string SelectOptionalFieldToValue { get; set; }
        public int SelectOptionalFieldType { get; set; }
    }
}