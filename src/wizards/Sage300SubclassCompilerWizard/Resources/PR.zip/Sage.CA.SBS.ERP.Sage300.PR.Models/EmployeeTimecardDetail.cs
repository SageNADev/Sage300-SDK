// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms; 
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeTimecardDetail
    /// </summary>
    public partial class EmployeeTimecardDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets EndDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndDate", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.EndDate, Id = Index.EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Gets or sets PayDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayDate", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.PayDate, Id = Index.PayDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PayDate { get; set; }

        /// <summary>
        /// Gets or sets EarningExpTipAccrualCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningExpTipAccrualCode", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.EarningExpTipAccrualCode, Id = Index.EarningExpTipAccrualCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EarningExpTipAccrualCode { get; set; }

        /// <summary>
        /// Gets or sets UniqueKeyField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UniqueKeyField", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.UniqueKeyField, Id = Index.UniqueKeyField, FieldType = EntityFieldType.Int, Size = 2)]
        public short UniqueKeyField { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [Display(Name = "Category", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Int, Size = 2)]
        public Category Category { get; set; }

        /// <summary>
        /// Gets or sets StartTime
        /// </summary>
        [Display(Name = "StartTime", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.StartTime, Id = Index.StartTime, FieldType = EntityFieldType.Int, Size = 2)]
        public short StartTime { get; set; }

        /// <summary>
        /// Gets or sets StopTime
        /// </summary>
        [Display(Name = "StopTime", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.StopTime, Id = Index.StopTime, FieldType = EntityFieldType.Int, Size = 2)]
        public short StopTime { get; set; }

        /// <summary>
        /// Gets or sets HoursWorked
        /// </summary>
        [Display(Name = "HoursWorked", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.HoursWorked, Id = Index.HoursWorked, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal HoursWorked { get; set; }

        /// <summary>
        /// Gets or sets TipsExpensePiecesSalesAmount
        /// </summary>
        [Display(Name = "TipsExpensePiecesSalesAmount", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.TipsExpensePiecesSalesAmount, Id = Index.TipsExpensePiecesSalesAmount, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal TipsExpensePiecesSalesAmount { get; set; }

        /// <summary>
        /// Gets or sets ShiftDifferentialSchedule
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiftDifferentialSchedule", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.ShiftDifferentialSchedule, Id = Index.ShiftDifferentialSchedule, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShiftDifferentialSchedule { get; set; }

        /// <summary>
        /// Gets or sets ShiftNumber
        /// </summary>
        [Display(Name = "ShiftNumber", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.ShiftNumber, Id = Index.ShiftNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short ShiftNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets PooledTips
        /// </summary>
        [Display(Name = "PooledTips", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.PooledTips, Id = Index.PooledTips, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PooledTips { get; set; }

        /// <summary>
        /// Gets or sets TipsBasedOn
        /// </summary>
        [Display(Name = "TipsBasedOn", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.TipsBasedOn, Id = Index.TipsBasedOn, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TipsBasedOn { get; set; }

        /// <summary>
        /// Gets or sets Jobs
        /// </summary>
        [Display(Name = "Jobs", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.Jobs, Id = Index.Jobs, FieldType = EntityFieldType.Long, Size = 4)]
        public int Jobs { get; set; }

        /// <summary>
        /// Gets or sets WorkClassificationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkClassificationCode", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.WorkClassificationCode, Id = Index.WorkClassificationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string WorkClassificationCode { get; set; }

        /// <summary>
        /// Gets or sets TotalJobHours
        /// </summary>
        [Display(Name = "TotalJobHours", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.TotalJobHours, Id = Index.TotalJobHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal TotalJobHours { get; set; }

        /// <summary>
        /// Gets or sets TotalJobPiecesSalesAmt
        /// </summary>
        [Display(Name = "TotalJobPiecesSalesAmt", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.TotalJobPiecesSalesAmt, Id = Index.TotalJobPiecesSalesAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalJobPiecesSalesAmt { get; set; }

        /// <summary>
        /// Gets or sets DayOfTheWeek
        /// </summary>
        [Display(Name = "DayOfTheWeek", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.DayOfTheWeek, Id = Index.DayOfTheWeek, FieldType = EntityFieldType.Int, Size = 2)]
        public DayOftheWeek DayOfTheWeek { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets CalculationMethod
        /// </summary>
        [Display(Name = "CalculationMethod", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.CalculationMethod, Id = Index.CalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public short CalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets EarnDedCategory
        /// </summary>
        [Display(Name = "EarnDedCategory", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.EarnDedCategory, Id = Index.EarnDedCategory, FieldType = EntityFieldType.Int, Size = 2)]
        public short EarnDedCategory { get; set; }

        /// <summary>
        /// Gets or sets EarnDedType
        /// </summary>
        [Display(Name = "EarnDedType", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.EarnDedType, Id = Index.EarnDedType, FieldType = EntityFieldType.Int, Size = 2)]
        public short EarnDedType { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentOne
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentOne", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentOne, Id = Index.GLSegmentOne, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentOne { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentTwo
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentTwo", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentTwo, Id = Index.GLSegmentTwo, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentTwo { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentThree
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentThree", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentThree, Id = Index.GLSegmentThree, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentThree { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentNameOne
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentNameOne", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentNameOne, Id = Index.GLSegmentNameOne, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentNameOne { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentDescriptionOne
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentDescriptionOne", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentDescriptionOne, Id = Index.GLSegmentDescriptionOne, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLSegmentDescriptionOne { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentNameTwo
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentNameTwo", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentNameTwo, Id = Index.GLSegmentNameTwo, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentNameTwo { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentDescriptionTwo
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentDescriptionTwo", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentDescriptionTwo, Id = Index.GLSegmentDescriptionTwo, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLSegmentDescriptionTwo { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentNameThree
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentNameThree", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentNameThree, Id = Index.GLSegmentNameThree, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentNameThree { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentDescriptionThree
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentDescriptionThree", ResourceType = typeof (EmployeeTimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentDescriptionThree, Id = Index.GLSegmentDescriptionThree, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLSegmentDescriptionThree { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Category string value
        /// </summary>
        public string CategoryString
        {
         get { return EnumUtility.GetStringValue(Category); }
        }

        /// <summary>
        /// Gets DayOfTheWeek string value
        /// </summary>
        public string DayOfTheWeekString
        {
         get { return EnumUtility.GetStringValue(DayOfTheWeek); }
        }

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString
        {
         get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        #endregion
    }
}
