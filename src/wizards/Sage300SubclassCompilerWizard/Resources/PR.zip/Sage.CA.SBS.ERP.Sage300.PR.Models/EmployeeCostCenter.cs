// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeNote
    /// </summary>
    public partial class EmployeeCostCenterField : ModelBase
    {
        /// <summary>
        /// Gets or sets PropertyID
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Number", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Number, Id = Index.Number, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Number { get; set; }

        /// <summary>
        /// Gets or sets SegmentDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets SegmentValue
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Value", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 15)]
        public string Value { get; set; }

        #region UI Strings


        #endregion
    }
}
