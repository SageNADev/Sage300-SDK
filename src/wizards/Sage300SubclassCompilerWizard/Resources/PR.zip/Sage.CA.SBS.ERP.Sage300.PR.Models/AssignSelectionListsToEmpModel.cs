// Copyright (c) 2025 The Sage Group plc or its licensors. All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for AssignSelectionListsToEmp
    /// </summary>
    public partial class AssignSelectionListsToEmp : ModelBase
    {
        public AssignSelectionListsToEmp()
        {
            NonMemberListModel = new List<AssignSelectionListsToEmp>();
            MemberListModel = new List<AssignSelectionListsToEmp>();
        }
        #region Properties

        /// <summary>
        /// Gets or sets the field for EmployeeList.
        /// </summary>
        [ViewField(Name = Fields.EmployeeList, Id = Index.EmployeeList, FieldType = EntityFieldType.Int, Size = 2)]
        public string EmployeeList { get; set; }

        ///// <summary>
        ///// Gets or sets the Employee.
        ///// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "-%6N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets the field for NonMemberListModel.
        /// </summary>
        public IEnumerable<AssignSelectionListsToEmp> NonMemberListModel { get; set; }

        /// <summary>
        /// Gets or sets the field for MemberListModel.
        /// </summary>
        public IEnumerable<AssignSelectionListsToEmp> MemberListModel { get; set; }

        /// <summary>
        /// Gets or sets the field for Data.
        /// </summary>
        public AssignSelectionListsToEmp Data { get; set; }
        #endregion
    }
}
