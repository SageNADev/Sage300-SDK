// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for AssignAudit
    /// </summary>
    public partial class AssignAudit : ModelBase
    {

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 8)]
        public Enums.ProcessCommand ProcessCommandCode { get; set; }
    }
}
