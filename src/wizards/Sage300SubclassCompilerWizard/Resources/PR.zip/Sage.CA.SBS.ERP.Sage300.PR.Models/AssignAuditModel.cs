// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for AssignAudit
    /// </summary>
    public partial class AssignAudit : ModelBase
    {
        private const char Z = 'Z';

        private const int ToEmployeeLength = 12;

        private const int ToClassLength = 6;

        /// <summary>
        /// Gets or sets What2Chg
        /// </summary>
        [ViewField(Name = Fields.What2Change, Id = Index.What2Chg, FieldType = EntityFieldType.Int, Size = 2)]
        public int What2Chg { get; set; }

        /// <summary>
        /// Gets or sets ID2Change
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ID2Change", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.ID2Change, Id = Index.ID2Change, FieldType = EntityFieldType.Char, Size = 6, Mask = "-%6N")]
        public string ID2Change { get; set; }

        /// <summary>
        /// Gets or sets IdName
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "IdName", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.IdName, Id = Index.IdName, FieldType = EntityFieldType.Char, Size = 60)]
        public string IdName { get; set; }

        /// <summary>
        /// Gets or sets IdName
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EBrowse", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.EBrowse, Id = Index.EBrowse, FieldType = EntityFieldType.Char, Size = 250)]
        public string EBrowse { get; set; }

        /// <summary>
        /// Gets or sets SelType
        /// </summary>
        [Display(Name = "SelType", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.SelType, Id = Index.SelType, FieldType = EntityFieldType.Int, Size = 8)]
        public Enums.EmployeeSelectionType SelType { get; set; }

        /// <summary>
        /// Gets or sets EmpListID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmpListID", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.EmpListID, Id = Index.EmpListID, FieldType = EntityFieldType.Char, Size = 8)]
        public string EmpListID { get; set; }

        /// <summary>
        /// Gets or sets FEmployee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FEmployee", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.FEmployee, Id = Index.FEmployee, FieldType = EntityFieldType.Char, Size = 12)]
        public string FEmployee { get; set; }

        /// <summary>
        /// Gets or sets TEmployee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TEmployee", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.TEmployee, Id = Index.TEmployee, FieldType = EntityFieldType.Char, Size = 12)]
        public string TEmployee { get; set; }

        /// <summary>
        /// Gets or sets Class
        /// </summary>
        [Display(Name = "Class", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.Class, Id = Index.Class, FieldType = EntityFieldType.Int, Size = 2)]
        public int Class { get; set; }

        /// <summary>
        /// Gets or sets FClassCod
        /// </summary>
        [Display(Name = "FClassCod", ResourceType = typeof(AssignAuditResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FClassCod, Id = Index.FClassCod, FieldType = EntityFieldType.Char, Size = 6)]
        public string FClassCod { get; set; }

        /// <summary>
        /// Gets or sets TClassCod
        /// </summary>
        [Display(Name = "TClassCod", ResourceType = typeof(AssignAuditResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TClassCod, Id = Index.TClassCod, FieldType = EntityFieldType.Char, Size = 6)]
        public string TClassCod { get; set; }

        /// <summary>
        /// Gets or sets UseDefault
        /// </summary>
        [Display(Name = "UseEmployeeDefaults", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.UseDefault, Id = Index.UseDefault, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseDefault { get; set; }

        /// <summary>
        /// Gets or sets EmpUpdated
        /// </summary>
        [ViewField(Name = Fields.EmpUpdated, Id = Index.EmpUpdated, FieldType = EntityFieldType.Long, Size = 4)]
        public long EmpUpdated { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 8)]
        public Enums.ProcessCommand ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets CurrCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrCode, Id = Index.CurrCode, FieldType = EntityFieldType.Char, Size = 3)]
        public string CurrCode { get; set; }

        /// <summary>
        /// Gets or sets CurrDesc
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrDesc, Id = Index.CurrDesc, FieldType = EntityFieldType.Char, Size = 30)]
        public string CurrDesc { get; set; }

        /// <summary>
        /// Default Parameterless Constructor
        /// </summary>
        public AssignAudit()
        {
            TEmployee = CommonUtil.Repeat(Z, ToEmployeeLength);
            TClassCod = CommonUtil.Repeat(Z, ToClassLength);
        }
    }
}
