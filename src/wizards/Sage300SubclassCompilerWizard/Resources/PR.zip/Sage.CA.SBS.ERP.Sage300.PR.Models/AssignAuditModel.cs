// Copyright (c) 2023 The Sage Group plc or its licensors. All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for AssignAudit
    /// </summary>
    public partial class AssignAudit : ModelBase
    {
        #region Constants

        private const char DefaultChar = 'Z';
        private const int EmployeeLength = 12;
        private const int ClassCodeLength = 6;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the field for What to Change.
        /// </summary>
        [ViewField(Name = Fields.WhatToChange, Id = Index.WhatToChange, FieldType = EntityFieldType.Int, Size = 2)]
        public int WhatToChange { get; set; }

        /// <summary>
        /// Gets or sets the Earn/Ded or Tax to Change.
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ID2Change", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.IdToChange, Id = Index.IdToChange, FieldType = EntityFieldType.Char, Size = 6, Mask = "-%6N")]
        public string IdToChange { get; set; }

        /// <summary>
        /// Gets or sets the Earn/Ded or Tax Name.
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "IdName", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.IdName, Id = Index.IdName, FieldType = EntityFieldType.Char, Size = 60)]
        public string IdName { get; set; }

        /// <summary>
        /// Gets or sets the Employee Browse Filter.
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EBrowse", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.EmployeeBrowseFilter, Id = Index.EmployeeBrowseFilter, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmployeeBrowseFilter { get; set; }

        /// <summary>
        /// Gets or sets the Employee Selection Type.
        /// </summary>
        [Display(Name = "SelType", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.SelectionType, Id = Index.SelectionType, FieldType = EntityFieldType.Int, Size = 8)]
        public Enums.EmployeeSelectionType SelectionType { get; set; }

        /// <summary>
        /// Gets or sets the Employee List ID.
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmpListID", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.EmployeeListId, Id = Index.EmployeeListId, FieldType = EntityFieldType.Char, Size = 8)]
        public string EmployeeListId { get; set; }

        /// <summary>
        /// Gets or sets the From Employee.
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FEmployee", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.FromEmployee, Id = Index.FromEmployee, FieldType = EntityFieldType.Char, Size = 12)]
        public string FromEmployee { get; set; }

        /// <summary>
        /// Gets or sets the To Employee.
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TEmployee", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.ToEmployee, Id = Index.ToEmployee, FieldType = EntityFieldType.Char, Size = 12)]
        public string ToEmployee { get; set; }

        /// <summary>
        /// Gets or sets the Class.
        /// </summary>
        [Display(Name = "Class", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.Class, Id = Index.Class, FieldType = EntityFieldType.Int, Size = 2)]
        public int Class { get; set; }

        /// <summary>
        /// Gets or sets the From Class Code.
        /// </summary>
        [Display(Name = "FClassCod", ResourceType = typeof(AssignAuditResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromClassCode, Id = Index.FromClassCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string FromClassCode { get; set; }

        /// <summary>
        /// Gets or sets the To Class Code.
        /// </summary>
        [Display(Name = "TClassCod", ResourceType = typeof(AssignAuditResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToClassCode, Id = Index.ToClassCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string ToClassCode { get; set; }

        /// <summary>
        /// Gets or sets the Use Employee Defaults flag.
        /// </summary>
        [Display(Name = "UseEmployeeDefaults", ResourceType = typeof(AssignAuditResx))]
        [ViewField(Name = Fields.UseEmployeeDefaults, Id = Index.UseEmployeeDefaults, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseEmployeeDefaults { get; set; }

        /// <summary>
        /// Gets or sets the number of Employees Updated.
        /// </summary>
        [ViewField(Name = Fields.EmployeesUpdated, Id = Index.EmployeesUpdated, FieldType = EntityFieldType.Long, Size = 4)]
        public long EmployeesUpdated { get; set; }

        /// <summary>
        /// Gets or sets the Process Command Code.
        /// </summary>
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 8)]
        public Enums.ProcessCommand ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets the Currency Code.
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3)]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets the Currency Description.
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 30)]
        public string CurrencyDescription { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Default Parameterless Constructor
        /// </summary>
        public AssignAudit()
        {
            ToEmployee = CommonUtil.Repeat(DefaultChar, EmployeeLength);
            ToClassCode = CommonUtil.Repeat(DefaultChar, ClassCodeLength);
        }

        #endregion
    }
}
