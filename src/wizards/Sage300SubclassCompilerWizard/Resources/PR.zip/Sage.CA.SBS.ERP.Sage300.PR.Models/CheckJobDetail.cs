// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CheckJobDetail
    /// </summary>
    public partial class CheckJobDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets EntrySequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntrySequence", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.EntrySequence, Id = Index.EntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int EntrySequence { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Category Category { get; set; }

        /// <summary>
        /// Gets or sets EarningDeduction
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningDeduction", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.EarningDeduction, Id = Index.EarningDeduction, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EarningDeduction { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineType", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.LineType LineType { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short LineNumber { get; set; }

        /// <summary>
        /// Gets or sets JobLineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "JobLineNumber", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.JobLineNumber, Id = Index.JobLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short JobLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ContractCode
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractCode", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Customer", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3C")]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets StartTime
        /// </summary>
        [Display(Name = "StartTime", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.StartTime, Id = Index.StartTime, FieldType = EntityFieldType.Int, Size = 2)]
        public short StartTime { get; set; }

        /// <summary>
        /// Gets or sets StopTime
        /// </summary>
        [Display(Name = "StopTime", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.StopTime, Id = Index.StopTime, FieldType = EntityFieldType.Int, Size = 2)]
        public short StopTime { get; set; }

        /// <summary>
        /// Gets or sets Hours
        /// </summary>
        [Display(Name = "Hours", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.Hours, Id = Index.Hours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal Hours { get; set; }

        /// <summary>
        /// Gets or sets PiecesSalesAmt
        /// </summary>
        [Display(Name = "PiecesSalesAmt", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.PiecesSalesAmt, Id = Index.PiecesSalesAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PiecesSalesAmt { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ARItemUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemUOM", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.ARItemUOM, Id = Index.ARItemUOM, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string ARItemUOM { get; set; }

        /// <summary>
        /// Gets or sets WIPCOSAcct
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WIPCOSAcct", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.WIPCOSAcct, Id = Index.WIPCOSAcct, FieldType = EntityFieldType.Char, Size = 45)]
        public string WIPCOSAcct { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }
        
        /// <summary>
        /// Gets or sets CurrencyDescription
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyDescription", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 30)]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets UnformattedContractCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedContractCode", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.UnformattedContractCode, Id = Index.UnformattedContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string UnformattedContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectStyle
        /// </summary>
        [Display(Name = "ProjectStyle", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.ProjectStyle ProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets ExtendedBillingAmount
        /// </summary>
        [Display(Name = "ExtendedBillingAmount", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.ExtendedBillingAmount, Id = Index.ExtendedBillingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedBillingAmount { get; set; }

        /// <summary>
        /// Gets or sets EmployeeExtendedAmount
        /// </summary>
        [Display(Name = "EmployeeExtendedAmount", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.EmployeeExtendedAmount, Id = Index.EmployeeExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeExtendedAmount { get; set; }

        /// <summary>
        /// Gets or sets OverheadAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OverheadAccount", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.OverheadAccount, Id = Index.OverheadAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string OverheadAccount { get; set; }

        /// <summary>
        /// Gets or sets LaborBurdenAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LaborBurdenAccount", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.LaborBurdenAccount, Id = Index.LaborBurdenAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string LaborBurdenAccount { get; set; }

        /// <summary>
        /// Gets or sets FCOverheadAmount
        /// </summary>
        [Display(Name = "FCOverheadAmount", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.FCOverheadAmount, Id = Index.FCOverheadAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FCOverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets OverheadAmount
        /// </summary>
        [Display(Name = "OverheadAmount", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.OverheadAmount, Id = Index.OverheadAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets FCLaborBurdenAmount
        /// </summary>
        [Display(Name = "FCLaborBurdenAmount", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.FCLaborBurdenAmount, Id = Index.FCLaborBurdenAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FCLaborBurdenAmount { get; set; }

        /// <summary>
        /// Gets or sets LaborBurdenAmount
        /// </summary>
        [Display(Name = "LaborBurdenAmount", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.LaborBurdenAmount, Id = Index.LaborBurdenAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LaborBurdenAmount { get; set; }

        /// <summary>
        /// Gets or sets PJCTransactionNumber
        /// </summary>
        [Display(Name = "PJCTransactionNumber", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.PJCTransactionNumber, Id = Index.PJCTransactionNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int PJCTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets ResourceDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ResourceDescription", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.ResourceDescription, Id = Index.ResourceDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ResourceDescription { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (CheckJobDetailResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.ProcessCommandCode ProcessCommandCode { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Category string value
        /// </summary>
        public string CategoryString => EnumUtility.GetStringValue(Category);

        /// <summary>
        /// Gets LineType string value
        /// </summary>
        public string LineTypeString => EnumUtility.GetStringValue(LineType);

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString => EnumUtility.GetStringValue(BillingType);

        /// <summary>
        /// Gets ProjectStyle string value
        /// </summary>
        public string ProjectStyleString => EnumUtility.GetStringValue(ProjectStyle);

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString => EnumUtility.GetStringValue(ProjectType);

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString => EnumUtility.GetStringValue(AccountingMethod);

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString => EnumUtility.GetStringValue(CostClass);

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

        #endregion
    }
}
