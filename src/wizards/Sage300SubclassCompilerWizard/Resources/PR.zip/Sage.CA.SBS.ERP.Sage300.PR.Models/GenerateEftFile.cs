    // Copyright (c) 2023-2024 The Sage Group plc or its licensors.  All rights reserved.

    #region Namespace

    using System;
    using System.ComponentModel.DataAnnotations;
    using Sage.CA.SBS.ERP.Sage300.Common.Models;
    using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
    using Sage.CA.SBS.ERP.Sage300.Common.Resources;
    using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
    using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

    #endregion

    namespace Sage.CA.SBS.ERP.Sage300.PR.Models
    {
    /// <summary>
    /// Partial class for GenerateEftFile
    /// </summary>
    public partial class GenerateEFTFile : ModelBase
    {
        /// <summary>
        /// The character 'Z' is assigned to the constant variable 'Z'.
        /// </summary>
        private const char Z = 'Z';

        /// <summary>
        /// The constant variable 'ToEmployeeLength' is assigned the value 12.
        /// This constant represents the length used when initializing the 'ToEmployee' property.
        /// </summary>
        private const int ToEmployeeLength = 12;

        /// <summary>
        /// Gets or sets EFTFileType
        /// </summary>
        [Display(Name = "EFTFileType", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.EFTFileType, Id = Index.EFTFileType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.EFTRunType EFTFileType { get; set; }

        /// <summary>
        /// Gets or sets RunSequence
        /// </summary>
        [Key]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RunSequence", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.RunSequence, Id = Index.RunSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long RunSequence { get; set; }

        /// <summary>
        /// Gets or sets CompanyEFTBank
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompanyEFTBank", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.CompanyEFTBank, Id = Index.CompanyEFTBank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string CompanyEFTBank { get; set; }

        /// <summary>
        /// Gets or sets SelectionList
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectionList", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.SelectionList, Id = Index.SelectionList, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string SelectionList { get; set; }

        /// <summary>
        /// Gets or sets FromEmployee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromEmployee", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.FromEmployee, Id = Index.FromEmployee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string FromEmployee { get; set; }

        /// <summary>
        /// Gets or sets ToEmployee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToEmployee", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.ToEmployee, Id = Index.ToEmployee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string ToEmployee { get; set; }

        /// <summary>
        /// Gets or sets FromPeriodEndDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromPeriodEndDate", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.FromPeriodEndDate, Id = Index.FromPeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? FromPeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets ToPeriodEndDate
        /// </summary>
        [Key]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToPeriodEndDate", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.ToPeriodEndDate, Id = Index.ToPeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ToPeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets UseDefaultFundsAvailableDate
        /// </summary>
        [Display(Name = "EffectiveEntryDate", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.UseDefaultFundsAvailableDate, Id = Index.UseDefaultFundsAvailableDate, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.UseDefDate UseDefaultFundsAvailableDate { get; set; }

        /// <summary>
        /// Gets or sets DefaultFundsAvailableDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultFundsAvailableDate", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.DefaultFundsAvailableDate, Id = Index.DefaultFundsAvailableDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DefaultFundsAvailableDate { get; set; }

        /// <summary>
        /// Gets or sets FileCreationDate
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FileCreationDate", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.FileCreationDate, Id = Index.FileCreationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FileCreationDate { get; set; }

        /// <summary>
        /// Gets or sets FileCreationNumber
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FileCreationNo", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.FileCreationNo, Id = Index.FileCreationNo, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FileCreationNo { get; set; }

        /// <summary>
        /// Gets or sets FileIDModifier
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FileIdModifier", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.FileIdModifier, Id = Index.FileIdModifier, FieldType = EntityFieldType.Char, Size = 1, Mask = "%-1N")]
        public string FileIdModifier { get; set; }

        /// <summary>
        /// Gets or sets EntryDescription
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryDescription", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.EntryDescription, Id = Index.EntryDescription, FieldType = EntityFieldType.Char, Size = 10)]
        public string EntryDescription { get; set; }

        /// <summary>
        /// Gets or sets EFTRunSequence
        /// </summary>
        [Display(Name = "EFTRunSequence", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.EFTRunSequence, Id = Index.EFTRunSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long EFTRunSequence { get; set; }

        /// <summary>
        /// Gets or sets ReturnSequence
        /// </summary>
        [Display(Name = "ReturnSequence", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.ReturnSequence, Id = Index.ReturnSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long ReturnSequence { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets EFTType
        /// </summary>
        [Display(Name = "EFTType", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.EFTType, Id = Index.EFTType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.EFTType EFTType { get; set; }

        /// <summary>
        /// Gets or sets CaseState
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CaseState", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.CaseState, Id = Index.CaseState, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string CaseState { get; set; }

        /// <summary>
        /// Gets or sets RegenratePreviousCSEFT
        /// </summary>
        [Display(Name = "RegenratePreviousCSEFT", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.RegenratePreviousCSEFT, Id = Index.RegenratePreviousCSEFT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RegenratePreviousCSEFT { get; set; }

        /// <summary>
        /// Gets or sets TransactionsType
        /// </summary>
        [Display(Name = "TransactionsType", ResourceType = typeof(GenerateEFTFileResx))]
        [ViewField(Name = Fields.TransactionsType, Id = Index.TransactionsType, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransactionsType { get; set; }

        /// <summary>
        /// Represents the EFT file generation constructor.
        /// </summary>
        public GenerateEFTFile()

        {
            ToEmployee = CommonUtil.Repeat(Z, ToEmployeeLength);
        }

        #region Report Related properties

        /// <summary>
        /// Gets or sets the Report File
        /// </summary>
        public string ReportFile { get; set; }

        /// <summary>
        /// Gets or sets the Report GUID
        /// </summary>
        public Guid ReportToken { get; set; }

        #endregion
    }
    }



