// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeEFTBanks
    /// </summary>
    public partial class EmployeeEFTBanks : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets EmployeeEFTBank
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeEFTBank", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.EmployeeEFTBank, Id = Index.EmployeeEFTBank, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EmployeeEFTBank { get; set; }

        /// <summary>
        /// Gets or sets EmployeeEFTBankDescription
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeEFTBankDescription", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.EmployeeEFTBankDescription, Id = Index.EmployeeEFTBankDescription, FieldType = EntityFieldType.Char, Size = 15)]
        public string EmployeeEFTBankDescription { get; set; }

        /// <summary>
        /// Gets or sets ReceivingDFIID
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceivingDFIID", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.ReceivingDFIID, Id = Index.ReceivingDFIID, FieldType = EntityFieldType.Char, Size = 9, Mask = "%-9d")]
        public string ReceivingDFIID { get; set; }

        /// <summary>
        /// Gets or sets AccountNumber
        /// </summary>
        [StringLength(18, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountNumber", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 18, Mask = "%-17c")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionCode
        /// </summary>
        [Display(Name = "TransactionCode", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.TransactionCode, Id = Index.TransactionCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.TransactionCode TransactionCode { get; set; }

        /// <summary>
        /// Gets or sets EFTCalculationType
        /// </summary>
        [Display(Name = "EFTCalculationType", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.EFTCalculationType, Id = Index.EFTCalculationType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.EFTCalculationType EFTCalculationType { get; set; }

        /// <summary>
        /// Gets or sets AmtPctToBeDeposited
        /// </summary>
        [Display(Name = "AmtPctToBeDeposited", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.AmtPctToBeDeposited, Id = Index.AmtPctToBeDeposited, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal AmtPctToBeDeposited { get; set; }

        /// <summary>
        /// Gets or sets StartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartDate", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets EndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndDate", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.EndDate, Id = Index.EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Gets or sets DestinationCountry
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DestinationCountry", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.DestinationCountry, Id = Index.DestinationCountry, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-2C")]
        public string DestinationCountry { get; set; }

        /// <summary>
        /// Gets or sets DestinationCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DestinationCurrency", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.DestinationCurrency, Id = Index.DestinationCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3C")]
        public string DestinationCurrency { get; set; }

        /// <summary>
        /// Gets or sets BankIDQualifier
        /// </summary>
        [Display(Name = "BankIDQualifier", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.BankIDQualifier, Id = Index.BankIDQualifier, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.BankIDQualifier BankIDQualifier { get; set; }

        /// <summary>
        /// Gets or sets PrenoteStatus
        /// </summary>
        [Display(Name = "PrenoteStatus", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.PrenoteStatus, Id = Index.PrenoteStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.PrenoteStatus PrenoteStatus { get; set; }

        /// <summary>
        /// Gets or sets SyncTransactionGUID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SyncTransactionGUID", ResourceType = typeof (EmployeeEFTBankResx))]
        [ViewField(Name = Fields.SyncTransactionGUID, Id = Index.SyncTransactionGUID, FieldType = EntityFieldType.Char, Size = 36)]
        public string SyncTransactionGUID { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets TransactionCode string value
        /// </summary>
        public string TransactionCodeString => EnumUtility.GetStringValue(TransactionCode);

        /// <summary>
        /// Gets EFTCalculationType string value
        /// </summary>
        public string EFTCalculationTypeString => EnumUtility.GetStringValue(EFTCalculationType);

        /// <summary>
        /// Gets BankIDQualifier string value
        /// </summary>
        public string BankIDQualifierString => EnumUtility.GetStringValue(BankIDQualifier);

        /// <summary>
        /// Gets PrenoteStatus string value
        /// </summary>
        public string PrenoteStatusString => EnumUtility.GetStringValue(PrenoteStatus);

        #endregion
    }
}
