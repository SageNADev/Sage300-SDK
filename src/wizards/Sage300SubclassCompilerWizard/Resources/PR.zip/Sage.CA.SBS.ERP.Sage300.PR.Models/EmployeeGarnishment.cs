// Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms; 
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeGarnishment
    /// </summary>
    public partial class EmployeeGarnishment : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets DeductionCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DeductionCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.DeductionCode, Id = Index.DeductionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DeductionCode { get; set; }

        /// <summary>
        /// Gets or sets DeductionsDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DeductionsDescription", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.DeductionsDescription, Id = Index.DeductionsDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DeductionsDescription { get; set; }

        /// <summary>
        /// Gets or sets EFTStatus
        /// </summary>
        [Display(Name = "EFTStatus", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EFTStatus, Id = Index.EFTStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public EFTStatus EFTStatus { get; set; }

        /// <summary>
        /// Gets or sets SDURoutingNumber
        /// </summary>
        [StringLength(9, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SDURoutingNumber", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SDURoutingNumber, Id = Index.SDURoutingNumber, FieldType = EntityFieldType.Char, Size = 9)]
        public string SDURoutingNumber { get; set; }

        /// <summary>
        /// Gets or sets SDUAccountNumber
        /// </summary>
        [StringLength(18, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SDUAccountNumber", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SDUAccountNumber, Id = Index.SDUAccountNumber, FieldType = EntityFieldType.Char, Size = 18, Mask = "%-17c")]
        public string SDUAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets TranscationCode
        /// </summary>
        [Display(Name = "TranscationCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.TranscationCode, Id = Index.TranscationCode, FieldType = EntityFieldType.Int, Size = 2)]
        public TranscationCode TranscationCode { get; set; }

        /// <summary>
        /// Gets or sets SDUName
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SDUName", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.SDUName, Id = Index.SDUName, FieldType = EntityFieldType.Char, Size = 30, Mask = "%-22c")]
        public string SDUName { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(19, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 19, Mask = "%-15c")]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets DiscretionaryData
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DiscretionaryData", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.DiscretionaryData, Id = Index.DiscretionaryData, FieldType = EntityFieldType.Char, Size = 2)]
        public string DiscretionaryData { get; set; }

        /// <summary>
        /// Gets or sets CaseIdentifier
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CaseIdentifier", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CaseIdentifier, Id = Index.CaseIdentifier, FieldType = EntityFieldType.Char, Size = 20)]
        public string CaseIdentifier { get; set; }

        /// <summary>
        /// Gets or sets CaseState
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CaseState", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CaseState, Id = Index.CaseState, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string CaseState { get; set; }

        /// <summary>
        /// Gets or sets CaseJurisdiction
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CaseJurisdiction", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CaseJurisdiction, Id = Index.CaseJurisdiction, FieldType = EntityFieldType.Char, Size = 30)]
        public string CaseJurisdiction { get; set; }

        /// <summary>
        /// Gets or sets FIPSCode
        /// </summary>
        [StringLength(7, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FIPSCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.FIPSCode, Id = Index.FIPSCode, FieldType = EntityFieldType.Char, Size = 7, Mask = "%-7d")]
        public string FIPSCode { get; set; }

        /// <summary>
        /// Gets or sets CustodialParent
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustodialParent", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CustodialParent, Id = Index.CustodialParent, FieldType = EntityFieldType.Char, Size = 30)]
        public string CustodialParent { get; set; }

        /// <summary>
        /// Gets or sets IsFamilyHealthInsuranceAvailable
        /// </summary>
        [Display(Name = "IsFamilyHealthInsuranceAvailable", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.IsFamilyHealthInsuranceAvailable, Id = Index.IsFamilyHealthInsuranceAvailable, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IsFamilyHealthInsuranceAvailable { get; set; }

        /// <summary>
        /// Gets or sets IsFamilyHealthInsuranceRequired
        /// </summary>
        [Display(Name = "IsFamilyHealthInsuranceRequired", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.IsFamilyHealthInsuranceRequired, Id = Index.IsFamilyHealthInsuranceRequired, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IsFamilyHealthInsuranceRequired { get; set; }

        /// <summary>
        /// Gets or sets DateOfOrder
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateOfOrder", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.DateOfOrder, Id = Index.DateOfOrder, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateOfOrder { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets EFTStatus string value
        /// </summary>
        public string EFTStatusString
        {
         get { return EnumUtility.GetStringValue(EFTStatus); }
        }

        /// <summary>
        /// Gets TranscationCode string value
        /// </summary>
        public string TranscationCodeString
        {
         get { return EnumUtility.GetStringValue(TranscationCode); }
        }

        #endregion
    }
}
