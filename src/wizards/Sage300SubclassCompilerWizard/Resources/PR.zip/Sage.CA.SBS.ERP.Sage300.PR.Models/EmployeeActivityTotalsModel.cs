// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    ///  EmployeeActivityTotalsModel class
    /// </summary>
    public class EmployeeActivityTotalsModel
    {
        /// <summary>
        /// Gets or sets TotalEarnings
        /// </summary>
        public decimal TotalEarnings { get; set; }

        /// <summary>
        /// Gets or sets TotalDeduction
        /// </summary>
        public decimal TotalDeduction { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxes
        /// </summary>
        public decimal TotalTaxes { get; set; }

        /// <summary>
        /// Gets or sets TotalChecks
        /// </summary>
        public decimal TotalChecks { get; set; }

    }
}
