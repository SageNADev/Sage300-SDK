// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CheckDetail
    /// </summary>
    public partial class CheckDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets EntrySequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntrySequence", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EntrySequence, Id = Index.EntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int EntrySequence { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Category Category { get; set; }

        /// <summary>
        /// Gets or sets EarningDeductionTax
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningDeductionTax", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EarningDeductionTax, Id = Index.EarningDeductionTax, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EarningDeductionTax { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineType", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.LineType LineType { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short LineNumber { get; set; }

        /// <summary>
        /// Gets or sets EarningDeductionTaxType
        /// </summary>
        [Display(Name = "EarningDeductionTaxType", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EarningDeductionTaxType, Id = Index.EarningDeductionTaxType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.EarningDeductionTaxType EarningDeductionTaxType { get; set; }

        /// <summary>
        /// Gets or sets EarningDeductionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningDeductionDate", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EarningDeductionDate, Id = Index.EarningDeductionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime EarningDeductionDate { get; set; }

        /// <summary>
        /// Gets or sets Hours
        /// </summary>
        [Display(Name = "Hours", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.Hours, Id = Index.Hours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal Hours { get; set; }

        /// <summary>
        /// Gets or sets EmployeePiecesSalesBase
        /// </summary>
        [Display(Name = "EmployeePiecesSalesBase", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EmployeePiecesSalesBase, Id = Index.EmployeePiecesSalesBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeePiecesSalesBase { get; set; }

        /// <summary>
        /// Gets or sets EmployeeRateAmtPct
        /// </summary>
        [Display(Name = "EmployeeRateAmtPct", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EmployeeRateAmtPct, Id = Index.EmployeeRateAmtPct, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployeeRateAmtPct { get; set; }

        /// <summary>
        /// Gets or sets EmployeeExtendedAmount
        /// </summary>
        [Display(Name = "EmployeeExtendedAmount", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EmployeeExtendedAmount, Id = Index.EmployeeExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployeeExtendedAmount { get; set; }

        /// <summary>
        /// Gets or sets RegularRate
        /// </summary>
        [Display(Name = "RegularRate", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.RegularRate, Id = Index.RegularRate, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal RegularRate { get; set; }

        /// <summary>
        /// Gets or sets EmployerPiecesBase
        /// </summary>
        [Display(Name = "EmployerPiecesBase", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EmployerPiecesBase, Id = Index.EmployerPiecesBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerPiecesBase { get; set; }

        /// <summary>
        /// Gets or sets EmployerAmtPct
        /// </summary>
        [Display(Name = "EmployerAmtPct", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EmployerAmtPct, Id = Index.EmployerAmtPct, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployerAmtPct { get; set; }

        /// <summary>
        /// Gets or sets EmployerExtendedAmount
        /// </summary>
        [Display(Name = "EmployerExtendedAmount", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EmployerExtendedAmount, Id = Index.EmployerExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EmployerExtendedAmount { get; set; }

        /// <summary>
        /// Gets or sets RegularPayExpenseGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RegularPayExpenseGLAccount", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.RegularPayExpenseGLAccount, Id = Index.RegularPayExpenseGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string RegularPayExpenseGLAccount { get; set; }

        /// <summary>
        /// Gets or sets EmployeeLiabilityGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeLiabilityGLAccount", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EmployeeLiabilityGLAccount, Id = Index.EmployeeLiabilityGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string EmployeeLiabilityGLAccount { get; set; }

        /// <summary>
        /// Gets or sets EmployerLiabilityGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployerLiabilityGLAccount", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EmployerLiabilityGLAccount, Id = Index.EmployerLiabilityGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string EmployerLiabilityGLAccount { get; set; }

        /// <summary>
        /// Gets or sets WorkersCompensationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkersCompensationCode", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.WorkersCompensationCode, Id = Index.WorkersCompensationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string WorkersCompensationCode { get; set; }

        /// <summary>
        /// Gets or sets CostCenterSegmentOne
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCenterSegmentOne", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.CostCenterSegmentOne, Id = Index.CostCenterSegmentOne, FieldType = EntityFieldType.Char, Size = 15)]
        public string CostCenterSegmentOne { get; set; }

        /// <summary>
        /// Gets or sets CostCenterSegmentTwo
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCenterSegmentTwo", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.CostCenterSegmentTwo, Id = Index.CostCenterSegmentTwo, FieldType = EntityFieldType.Char, Size = 15)]
        public string CostCenterSegmentTwo { get; set; }

        /// <summary>
        /// Gets or sets CostCenterSegmentThree
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCenterSegmentThree", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.CostCenterSegmentThree, Id = Index.CostCenterSegmentThree, FieldType = EntityFieldType.Char, Size = 15)]
        public string CostCenterSegmentThree { get; set; }

        /// <summary>
        /// Gets or sets DetailWasPartiallyTakenOrNo
        /// </summary>
        [Display(Name = "DetailWasPartiallyTakenOrNo", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.DetailWasPartiallyTakenOrNo, Id = Index.DetailWasPartiallyTakenOrNo, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DetailWasPartiallyTakenOrNo { get; set; }

        /// <summary>
        /// Gets or sets WeeksWorked
        /// </summary>
        [Display(Name = "WeeksWorked", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.WeeksWorked, Id = Index.WeeksWorked, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal WeeksWorked { get; set; }

        /// <summary>
        /// Gets or sets EarnSubjToTaxNoCeiling
        /// </summary>
        [Display(Name = "EarnSubjToTaxNoCeiling", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EarnSubjToTaxNoCeiling, Id = Index.EarnSubjToTaxNoCeiling, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EarnSubjToTaxNoCeiling { get; set; }

        /// <summary>
        /// Gets or sets EarnSubjToTax
        /// </summary>
        [Display(Name = "EarnSubjToTax", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EarnSubjToTax, Id = Index.EarnSubjToTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EarnSubjToTax { get; set; }

        /// <summary>
        /// Gets or sets NoCeilingTips
        /// </summary>
        [Display(Name = "NoCeilingTips", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.NoCeilingTips, Id = Index.NoCeilingTips, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NoCeilingTips { get; set; }

        /// <summary>
        /// Gets or sets CeilingTips
        /// </summary>
        [Display(Name = "CeilingTips", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.CeilingTips, Id = Index.CeilingTips, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CeilingTips { get; set; }

        /// <summary>
        /// Gets or sets TaxOnTips
        /// </summary>
        [Display(Name = "TaxOnTips", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.TaxOnTips, Id = Index.TaxOnTips, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxOnTips { get; set; }

        /// <summary>
        /// Gets or sets UncollectedTaxOnTips
        /// </summary>
        [Display(Name = "UncollectedTaxOnTips", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.UncollectedTaxOnTips, Id = Index.UncollectedTaxOnTips, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UncollectedTaxOnTips { get; set; }

        /// <summary>
        /// Gets or sets PrintCategory
        /// </summary>
        [Display(Name = "PrintCategory", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.PrintCategory, Id = Index.PrintCategory, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.PrintCategory PrintCategory { get; set; }

        /// <summary>
        /// Gets or sets PrintLineType
        /// </summary>
        [Display(Name = "PrintLineType", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.PrintLineType, Id = Index.PrintLineType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.PrintLineType PrintLineType { get; set; }

        /// <summary>
        /// Gets or sets PrintLineContents
        /// </summary>
        [Display(Name = "PrintLineContents", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.PrintLineContents, Id = Index.PrintLineContents, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.PrintLineContents PrintLineContents { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TAXNONPER
        /// </summary>
        [Display(Name = "TAXNONPER", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.TAXNONPER, Id = Index.TAXNONPER, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXNONPER { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TAXEARNBD
        /// </summary>
        [Display(Name = "TAXEARNBD", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.TAXEARNBD, Id = Index.TAXEARNBD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXEARNBD { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets POOLEDTIPS
        /// </summary>
        [Display(Name = "POOLEDTIPS", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.POOLEDTIPS, Id = Index.POOLEDTIPS, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POOLEDTIPS { get; set; }

        /// <summary>
        /// Gets or sets DetailDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DetailDate", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.DetailDate, Id = Index.DetailDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DetailDate { get; set; }

        /// <summary>
        /// Gets or sets StartTime
        /// </summary>
        [Display(Name = "StartTime", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.StartTime, Id = Index.StartTime, FieldType = EntityFieldType.Int, Size = 2)]
        public short StartTime { get; set; }

        /// <summary>
        /// Gets or sets StopTime
        /// </summary>
        [Display(Name = "StopTime", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.StopTime, Id = Index.StopTime, FieldType = EntityFieldType.Int, Size = 2)]
        public short StopTime { get; set; }

        /// <summary>
        /// Gets or sets WorkersCompGroup
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkersCompGroup", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.WorkersCompGroup, Id = Index.WorkersCompGroup, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string WorkersCompGroup { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }
        
        /// <summary>
        /// Gets or sets IncludedInFLSAOvertimeCalc
        /// </summary>
        [Display(Name = "IncludedInFLSAOvertimeCalc", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.IncludedInFLSAOvertimeCalc, Id = Index.IncludedInFLSAOvertimeCalc, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IncludedInFLSAOvertimeCalc { get; set; }

        /// <summary>
        /// Gets or sets DaysWorked
        /// </summary>
        [Display(Name = "DaysWorked", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.DaysWorked, Id = Index.DaysWorked, FieldType = EntityFieldType.Int, Size = 2)]
        public short DaysWorked { get; set; }

        /// <summary>
        /// Gets or sets OvertimeSchedule
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OvertimeSchedule", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.OvertimeSchedule, Id = Index.OvertimeSchedule, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string OvertimeSchedule { get; set; }

        /// <summary>
        /// Gets or sets OvertimeHoursOverride
        /// </summary>
        [Display(Name = "OvertimeHoursOverride", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.OvertimeHoursOverride, Id = Index.OvertimeHoursOverride, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal OvertimeHoursOverride { get; set; }

        /// <summary>
        /// Gets or sets StraightTimeEarnings
        /// </summary>
        [Display(Name = "StraightTimeEarnings", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.StraightTimeEarnings, Id = Index.StraightTimeEarnings, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StraightTimeEarnings { get; set; }

        /// <summary>
        /// Gets or sets OvertimeRateMultiplier
        /// </summary>
        [Display(Name = "OvertimeRateMultiplier", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.OvertimeRateMultiplier, Id = Index.OvertimeRateMultiplier, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal OvertimeRateMultiplier { get; set; }

        /// <summary>
        /// Gets or sets Jobs
        /// </summary>
        [Display(Name = "Jobs", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.Jobs, Id = Index.Jobs, FieldType = EntityFieldType.Long, Size = 4)]
        public int Jobs { get; set; }

        /// <summary>
        /// Gets or sets WorkClassificationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkClassificationCode", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.WorkClassificationCode, Id = Index.WorkClassificationCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string WorkClassificationCode { get; set; }

        /// <summary>
        /// Gets or sets LocalTaxCode
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocalTaxCode", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.LocalTaxCode, Id = Index.LocalTaxCode, FieldType = EntityFieldType.Char, Size = 10)]
        public string LocalTaxCode { get; set; }

        /// <summary>
        /// Gets or sets WCBase
        /// </summary>
        [Display(Name = "WCBase", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.WCBase, Id = Index.WCBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WCBase { get; set; }

        /// <summary>
        /// Gets or sets WCRate
        /// </summary>
        [Display(Name = "WCRate", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.WCRate, Id = Index.WCRate, FieldType = EntityFieldType.Decimal, Size = 6, Precision = 6)]
        public decimal WCRate { get; set; }

        /// <summary>
        /// Gets or sets WCAssessment
        /// </summary>
        [Display(Name = "WCAssessment", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.WCAssessment, Id = Index.WCAssessment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal WCAssessment { get; set; }

        /// <summary>
        /// Gets or sets WCExpenseAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WCExpenseAccount", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.WCExpenseAccount, Id = Index.WCExpenseAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string WCExpenseAccount { get; set; }

        /// <summary>
        /// Gets or sets WCLiabilityAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WCLiabilityAccount", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.WCLiabilityAccount, Id = Index.WCLiabilityAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string WCLiabilityAccount { get; set; }

        /// <summary>
        /// Gets or sets ChildSupportEFTStatus
        /// </summary>
        [Display(Name = "ChildSupportEFTStatus", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.ChildSupportEFTStatus, Id = Index.ChildSupportEFTStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.ChildSupportEFTStatus ChildSupportEFTStatus { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets DistributionDescription
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionDescription", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.DistributionDescription, Id = Index.DistributionDescription, FieldType = EntityFieldType.Char, Size = 15)]
        public string DistributionDescription { get; set; }

        /// <summary>
        /// Gets or sets CostCenterSegmentFour
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCenterSegmentFour", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.CostCenterSegmentFour, Id = Index.CostCenterSegmentFour, FieldType = EntityFieldType.Char, Size = 15)]
        public string CostCenterSegmentFour { get; set; }

        /// <summary>
        /// Gets or sets CostCenterSegmentFix
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCenterSegmentFix", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.CostCenterSegmentFix, Id = Index.CostCenterSegmentFix, FieldType = EntityFieldType.Char, Size = 15)]
        public string CostCenterSegmentFix { get; set; }

        /// <summary>
        /// Gets or sets CostCenterSegmentSix
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCenterSegmentSix", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.CostCenterSegmentSix, Id = Index.CostCenterSegmentSix, FieldType = EntityFieldType.Char, Size = 15)]
        public string CostCenterSegmentSix { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TAXNONDED
        /// </summary>
        [Display(Name = "TAXNONDED", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.TAXNONDED, Id = Index.TAXNONDED, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXNONDED { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TAXREPAY
        /// </summary>
        [Display(Name = "TAXREPAY", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.TAXREPAY, Id = Index.TAXREPAY, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXREPAY { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.ProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets DetailType
        /// </summary>
        [Display(Name = "DetailType", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.DetailType, Id = Index.DetailType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.DetailType DetailType { get; set; }

        /// <summary>
        /// Gets or sets EmployeeCalculationMethod
        /// </summary>
        [Display(Name = "EmployeeCalculationMethod", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EmployeeCalculationMethod, Id = Index.EmployeeCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployeeCalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets EmployerCalculationMethod
        /// </summary>
        [Display(Name = "EmployerCalculationMethod", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.EmployerCalculationMethod, Id = Index.EmployerCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployerCalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets HistoryEntryTaxSide
        /// </summary>
        [Display(Name = "HistoryEntryTaxSide", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.HistoryEntryTaxSide, Id = Index.HistoryEntryTaxSide, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.HistoryEntryTaxSide HistoryEntryTaxSide { get; set; }

        /// <summary>
        /// Gets or sets NoCeilingWage
        /// </summary>
        [Display(Name = "NoCeilingWage", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.NoCeilingWage, Id = Index.NoCeilingWage, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NoCeilingWage { get; set; }

        /// <summary>
        /// Gets or sets CeilingWage
        /// </summary>
        [Display(Name = "CeilingWage", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.CeilingWage, Id = Index.CeilingWage, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CeilingWage { get; set; }

        /// <summary>
        /// Gets or sets CheckDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckDate", ResourceType = typeof (CheckDetailResx))]
        [ViewField(Name = Fields.CheckDate, Id = Index.CheckDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CheckDate { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Category string value
        /// </summary>
        public string CategoryString => EnumUtility.GetStringValue(Category);

        /// <summary>
        /// Gets LineType string value
        /// </summary>
        public string LineTypeString => EnumUtility.GetStringValue(LineType);

        /// <summary>
        /// Gets EarningDeductionTaxType string value
        /// </summary>
        public string EarningDeductionTaxTypeString => EnumUtility.GetStringValue(EarningDeductionTaxType);

        /// <summary>
        /// Gets PrintCategory string value
        /// </summary>
        public string PrintCategoryString => EnumUtility.GetStringValue(PrintCategory);

        /// <summary>
        /// Gets PrintLineType string value
        /// </summary>
        public string PrintLineTypeString => EnumUtility.GetStringValue(PrintLineType);

        /// <summary>
        /// Gets PrintLineContents string value
        /// </summary>
        public string PrintLineContentsString => EnumUtility.GetStringValue(PrintLineContents);

        /// <summary>
        /// Gets ChildSupportEFTStatus string value
        /// </summary>
        public string ChildSupportEFTStatusString => EnumUtility.GetStringValue(ChildSupportEFTStatus);

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

        /// <summary>
        /// Gets DetailType string value
        /// </summary>
        public string DetailTypeString => EnumUtility.GetStringValue(DetailType);

        /// <summary>
        /// Gets HistoryEntryTaxSide string value
        /// </summary>
        public string HistoryEntryTaxSideString => EnumUtility.GetStringValue(HistoryEntryTaxSide);

        #endregion
    }
}
