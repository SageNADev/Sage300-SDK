﻿// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for TimecardModel
    /// </summary>
    public class TimecardModel : ModelBase
    {

        private const char Z = 'Z';

        private const int ToEmployeeLength = 12;

        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromEmployee", ResourceType = typeof(TimecardHeaderResx))]
        public string FromEmployee { get; set; }

        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToEmployee", ResourceType = typeof(TimecardHeaderResx))]
        public string ToEmployee { get; set; }


        /// <summary>
        /// Gets or sets Timecard
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Timecard", ResourceType = typeof(TimecardHeaderResx))]
        public string Timecard { get; set; }

        /// <summary>
        /// Gets or sets PRPostStatus
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(TimecardHeaderResx))]
        public TimecardType Type { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof(TimecardHeaderResx))]
        public DateTime? PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [Display(Name = "Active", ResourceType = typeof(TimecardHeaderResx))]
        public bool Active { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [Display(Name = "Inactive", ResourceType = typeof(TimecardHeaderResx))]
        public bool Inactive { get; set; }

        /// <summary>
        /// Default Parameterless Constructor
        /// </summary>
        public TimecardModel()
        {
            ToEmployee = CommonUtil.Repeat(Z, ToEmployeeLength);
        }
    }
}
