// Copyright (c) 2023-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for EmployeeBillingDetail
    /// </summary>
    public partial class EmployeeBillingDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets EarningCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EarningCode, Id = Index.EarningCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EarningCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3C")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets BillingRate1
        /// </summary>
        [Display(Name = "BillingRate1", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.BillingRate1, Id = Index.BillingRate1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate1 { get; set; }

        /// <summary>
        /// Gets or sets BillingRate2
        /// </summary>
        [Display(Name = "BillingRate2", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.BillingRate2, Id = Index.BillingRate2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate2 { get; set; }

        /// <summary>
        /// Gets or sets BillingRate3
        /// </summary>
        [Display(Name = "BillingRate3", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.BillingRate3, Id = Index.BillingRate3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate3 { get; set; }

        /// <summary>
        /// Gets or sets BillingRate4
        /// </summary>
        [Display(Name = "BillingRate4", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.BillingRate4, Id = Index.BillingRate4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate4 { get; set; }

        /// <summary>
        /// Gets or sets BillingRate5
        /// </summary>
        [Display(Name = "BillingRate5", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.BillingRate5, Id = Index.BillingRate5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate5 { get; set; }

        /// <summary>
        /// Gets or sets BillingRate6
        /// </summary>
        [Display(Name = "BillingRate6", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.BillingRate6, Id = Index.BillingRate6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate6 { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDescription
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyDescription", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 30)]
        public string CurrencyDescription { get; set; }

        #region UI Strings

        #endregion
    }
}
