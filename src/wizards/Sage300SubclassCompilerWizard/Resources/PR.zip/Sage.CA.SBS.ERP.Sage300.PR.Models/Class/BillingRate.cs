﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Class
{
    public class BillingRate
    {
        public decimal Billingrate1 { get; set; }
        public decimal Billingrate2 { get; set; }
        public decimal Billingrate3 { get; set; }
        public decimal Billingrate4 { get; set; }
        public decimal Billingrate5 { get; set; }
        public decimal Billingrate6 { get; set; }
        public string CurrencyCode { get; set; }
    }
}
