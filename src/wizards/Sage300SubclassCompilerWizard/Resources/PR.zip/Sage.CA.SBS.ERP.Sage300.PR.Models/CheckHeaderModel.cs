// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for CheckHeader
    /// </summary>
    public class CheckHeaderModel : ModelBase
    {

        private const char Z = 'Z';

        private const int ToEmployeeLength = 12;

        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromEmployee", ResourceType = typeof (PRCommonResx))]
        public string FromEmployee { get; set; }

        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToEmployee", ResourceType = typeof(PRCommonResx))]
        public string ToEmployee { get; set; }

       
        /// <summary>
        /// Gets or sets TypeOfCheck
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof (PRCommonResx))]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.TypeOfCheck DocumentType { get; set; }

        /// <summary>
        /// Gets or sets PRPostStatus
        /// </summary>
        [Display(Name = "PostingStatus", ResourceType = typeof(PRCommonResx))]
        public Sage.CA.SBS.ERP.Sage300.PR.Models.Enums.PRPostStatus PostingStatus { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromCheckDate", ResourceType = typeof (PRCommonResx))]
        public DateTime? FromCheckDate { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToCheckDate", ResourceType = typeof (PRCommonResx))]
        public DateTime? ToCheckDate { get; set; }

        /// <summary>
        /// Default Parameterless Constructor
        /// </summary>
        public CheckHeaderModel()
        {
            ToEmployee = CommonUtil.Repeat(Z, ToEmployeeLength);
        }
    }
}
