// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeBillingDetail Constants
    /// </summary>
    public partial class EmployeeBillingDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0041";


        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeBillingDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for EarningCode
            /// </summary>
            public const string EarningCode = "EARNDED";

            /// <summary>
            /// Property for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CURRCODE";

            /// <summary>
            /// Property for BillingRate1
            /// </summary>
            public const string BillingRate1 = "BILLRATE1";

            /// <summary>
            /// Property for BillingRate2
            /// </summary>
            public const string BillingRate2 = "BILLRATE2";

            /// <summary>
            /// Property for BillingRate3
            /// </summary>
            public const string BillingRate3 = "BILLRATE3";

            /// <summary>
            /// Property for BillingRate4
            /// </summary>
            public const string BillingRate4 = "BILLRATE4";

            /// <summary>
            /// Property for BillingRate5
            /// </summary>
            public const string BillingRate5 = "BILLRATE5";

            /// <summary>
            /// Property for BillingRate6
            /// </summary>
            public const string BillingRate6 = "BILLRATE6";

            /// <summary>
            /// Property for CurrencyDescription
            /// </summary>
            public const string CurrencyDescription = "CURRDESC";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeBillingDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for EarningCode
            /// </summary>
            public const int EarningCode = 2;

            /// <summary>
            /// Property Indexer for CurrencyCode
            /// </summary>
            public const int CurrencyCode = 3;

            /// <summary>
            /// Property Indexer for BillingRate1
            /// </summary>
            public const int BillingRate1 = 4;

            /// <summary>
            /// Property Indexer for BillingRate2
            /// </summary>
            public const int BillingRate2 = 5;

            /// <summary>
            /// Property Indexer for BillingRate3
            /// </summary>
            public const int BillingRate3 = 6;

            /// <summary>
            /// Property Indexer for BillingRate4
            /// </summary>
            public const int BillingRate4 = 7;

            /// <summary>
            /// Property Indexer for BillingRate5
            /// </summary>
            public const int BillingRate5 = 8;

            /// <summary>
            /// Property Indexer for BillingRate6
            /// </summary>
            public const int BillingRate6 = 9;

            /// <summary>
            /// Property Indexer for CurrencyDescription
            /// </summary>
            public const int CurrencyDescription = 20;


        }

        #endregion

    }
}
