// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of TimecardDetail Constants
    /// </summary>
    public partial class TimecardDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0032";


        #region Fields Properties

        /// <summary>
        /// Contains list of TimecardDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "PEREND";

            /// <summary>
            /// Property for Timecard
            /// </summary>
            public const string Timecard = "TIMECARD";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENUM";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for EarningsDeduction
            /// </summary>
            public const string EarningsDeduction = "EARNDED";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "EARDEDTYPE";

            /// <summary>
            /// Property for Date
            /// </summary>
            public const string Date = "EARDEDDATE";

            /// <summary>
            /// Property for StartTime
            /// </summary>
            public const string StartTime = "STARTTIME";

            /// <summary>
            /// Property for StopTime
            /// </summary>
            public const string StopTime = "STOPTIME";

            /// <summary>
            /// Property for GLSegmentOne
            /// </summary>
            public const string GLSegmentOne = "GLSEG1";

            /// <summary>
            /// Property for GLSegmentTwo
            /// </summary>
            public const string GLSegmentTwo = "GLSEG2";

            /// <summary>
            /// Property for GLSegmentThree
            /// </summary>
            public const string GLSegmentThree = "GLSEG3";

            /// <summary>
            /// Property for Hours
            /// </summary>
            public const string Hours = "HOURS";

            /// <summary>
            /// Property for CalculationMethod
            /// </summary>
            public const string CalculationMethod = "CALCMETH";

            /// <summary>
            /// Property for BaseLimit
            /// </summary>
            public const string BaseLimit = "LIMITBASE";

            /// <summary>
            /// Property for PiecesSalesBase
            /// </summary>
            public const string PiecesSalesBase = "CNTBASE";

            /// <summary>
            /// Property for EDTaxRateAmtPercent
            /// </summary>
            public const string EDTaxRateAmtPercent = "RATE";

            /// <summary>
            /// Property for PayAccrueHours
            /// </summary>
            public const string PayAccrueHours = "PAYORACCR";

            /// <summary>
            /// Property for RegularPayExpenseGLAccount
            /// </summary>
            public const string RegularPayExpenseGLAccount = "EXPACCT";

            /// <summary>
            /// Property for LiabilityGLAccount
            /// </summary>
            public const string LiabilityGLAccount = "LIABACCT";

            /// <summary>
            /// Property for OvertimeExpenseGLAccount
            /// </summary>
            public const string OvertimeExpenseGLAccount = "OTACCT";

            /// <summary>
            /// Property for ShiftDifferentialGLAccount
            /// </summary>
            public const string ShiftDifferentialGLAccount = "SHIFTACCT";

            /// <summary>
            /// Property for AssetAccount
            /// </summary>
            public const string AssetAccount = "ASSETACCT";

            /// <summary>
            /// Property for OvertimeSchedule
            /// </summary>
            public const string OvertimeSchedule = "OTSCHED";

            /// <summary>
            /// Property for ShiftDifferentialSchedule
            /// </summary>
            public const string ShiftDifferentialSchedule = "SHIFTSCHED";

            /// <summary>
            /// Property for ShiftNumber
            /// </summary>
            public const string ShiftNumber = "SHIFTNUM";

            /// <summary>
            /// Property for WorkersCompensationCode
            /// </summary>
            public const string WorkersCompensationCode = "WCC";

            /// <summary>
            /// Property for WeeksWorked
            /// </summary>
            public const string WeeksWorked = "TAXWEEKS";

            /// <summary>
            /// Property for TaxAnnualizationFactor
            /// </summary>
            public const string TaxAnnualizationFactor = "TAXANNLIZ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for INTERNALUSE
            /// </summary>
            public const string INTERNALUSE = "WEEKLYNTRY";

            /// <summary>
            /// Property for EntryType
            /// </summary>
            public const string EntryType = "ENTRYTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for POOLEDTIPS
            /// </summary>
            public const string POOLEDTIPS = "POOLEDTIPS";

            /// <summary>
            /// Property for EDTaxDescription
            /// </summary>
            public const string EDTaxDescription = "DESC";

            /// <summary>
            /// Property for GLSegmentNameOne
            /// </summary>
            public const string GLSegmentNameOne = "GLSEGID1";

            /// <summary>
            /// Property for GLSegmentDescriptionOne
            /// </summary>
            public const string GLSegmentDescriptionOne = "GLSEGDESC1";

            /// <summary>
            /// Property for GLSegmentNameTwo
            /// </summary>
            public const string GLSegmentNameTwo = "GLSEGID2";

            /// <summary>
            /// Property for GLSegmentDescriptionTwo
            /// </summary>
            public const string GLSegmentDescriptionTwo = "GLSEGDESC2";

            /// <summary>
            /// Property for GLSegmentNameThree
            /// </summary>
            public const string GLSegmentNameThree = "GLSEGID3";

            /// <summary>
            /// Property for GLSegmentDescriptionThree
            /// </summary>
            public const string GLSegmentDescriptionThree = "GLSEGDESC3";

            /// <summary>
            /// Property for INTERNALUSEKeyAction
            /// </summary>
            public const string INTERNALUSEKeyAction = "KEYACTION";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for WORKPROV
            /// </summary>
            public const string WORKPROV = "WORKPROV";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for INTERNALUSENewKeyEmployee
            /// </summary>
            public const string INTERNALUSENewKeyEmployee = "NKEMPLOYEE";

            /// <summary>
            /// Property for INTERNALUSENewKeyPeriodEn
            /// </summary>
            public const string INTERNALUSENewKeyPeriodEn = "NKPEREND";

            /// <summary>
            /// Property for INTERNALUSENewKeyTimecard
            /// </summary>
            public const string INTERNALUSENewKeyTimecard = "NKTIMECARD";

            /// <summary>
            /// Property for INTERNALUSENewKeyLineNumb
            /// </summary>
            public const string INTERNALUSENewKeyLineNumb = "NKLINENUM";

            /// <summary>
            /// Property for RESERVEDGLSegmentNameFour
            /// </summary>
            public const string RESERVEDGLSegmentNameFour = "GLSEGID4";

            /// <summary>
            /// Property for GLSEGDESC4
            /// </summary>
            public const string GLSEGDESC4 = "GLSEGDESC4";

            /// <summary>
            /// Property for RESERVEDGLSegmentNameFive
            /// </summary>
            public const string RESERVEDGLSegmentNameFive = "GLSEGID5";

            /// <summary>
            /// Property for GLSEGDESC5
            /// </summary>
            public const string GLSEGDESC5 = "GLSEGDESC5";

            /// <summary>
            /// Property for RESERVEDGLSegmentNameSix
            /// </summary>
            public const string RESERVEDGLSegmentNameSix = "GLSEGID6";

            /// <summary>
            /// Property for GLSEGDESC6
            /// </summary>
            public const string GLSEGDESC6 = "GLSEGDESC6";

            /// <summary>
            /// Property for DaysWorked
            /// </summary>
            public const string DaysWorked = "DAYS";

            /// <summary>
            /// Property for WorkersCompGroup
            /// </summary>
            public const string WorkersCompGroup = "WCCGROUP";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for OvertimeHoursOverride
            /// </summary>
            public const string OvertimeHoursOverride = "OTHOURS";

            /// <summary>
            /// Property for OvertimeRateOverride
            /// </summary>
            public const string OvertimeRateOverride = "OTRATE";

            /// <summary>
            /// Property for IncludeInFLSAOvertimeCalc
            /// </summary>
            public const string IncludeInFLSAOvertimeCalc = "SWFLSA";

            /// <summary>
            /// Property for DistributionCode
            /// </summary>
            public const string DistributionCode = "DISTCODE";

            /// <summary>
            /// Property for EmployerExpenseGLAccount
            /// </summary>
            public const string EmployerExpenseGLAccount = "REXPACCT";

            /// <summary>
            /// Property for EmployerLiabilityGLAccount
            /// </summary>
            public const string EmployerLiabilityGLAccount = "RLIABACCT";

            /// <summary>
            /// Property for JobsAllocBasedOnCalcBase
            /// </summary>
            public const string JobsAllocBasedOnCalcBase = "SWALLOCJOB";

            /// <summary>
            /// Property for Jobs
            /// </summary>
            public const string Jobs = "JOBS";

            /// <summary>
            /// Property for WorkClassificationCode
            /// </summary>
            public const string WorkClassificationCode = "WORKCODE";

            /// <summary>
            /// Property for TotalJobHours
            /// </summary>
            public const string TotalJobHours = "JOBHOURS";

            /// <summary>
            /// Property for TotalJobPiecesSalesAmt
            /// </summary>
            public const string TotalJobPiecesSalesAmt = "JOBBASE";

            /// <summary>
            /// Property for EmployerCalculationMethod
            /// </summary>
            public const string EmployerCalculationMethod = "RCALCMETH";

            /// <summary>
            /// Property for EmployerBaseLimit
            /// </summary>
            public const string EmployerBaseLimit = "RLIMITBASE";

            /// <summary>
            /// Property for OverrideEmployerRateAmtPct
            /// </summary>
            public const string OverrideEmployerRateAmtPct = "RRATEOVER";

            /// <summary>
            /// Property for EmployerRateAmtPct
            /// </summary>
            public const string EmployerRateAmtPct = "RRATE";

            /// <summary>
            /// Property for DefaultEmployerRateAmtPct
            /// </summary>
            public const string DefaultEmployerRateAmtPct = "DEFRRATE";

            /// <summary>
            /// Property for RESERVEDGLSegmentFour
            /// </summary>
            public const string RESERVEDGLSegmentFour = "GLSEG4";

            /// <summary>
            /// Property for RESERVEDGLSegmentFive
            /// </summary>
            public const string RESERVEDGLSegmentFive = "GLSEG5";

            /// <summary>
            /// Property for RESERVEDGLSegmentSix
            /// </summary>
            public const string RESERVEDGLSegmentSix = "GLSEG6";

        }

        #endregion
        #region Index Properties

        /// <summary>
        /// Contains list of TimecardDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 2;

            /// <summary>
            /// Property Indexer for Timecard
            /// </summary>
            public const int Timecard = 3;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 4;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 5;

            /// <summary>
            /// Property Indexer for EarningsDeduction
            /// </summary>
            public const int EarningsDeduction = 6;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 7;

            /// <summary>
            /// Property Indexer for Date
            /// </summary>
            public const int Date = 8;

            /// <summary>
            /// Property Indexer for StartTime
            /// </summary>
            public const int StartTime = 9;

            /// <summary>
            /// Property Indexer for StopTime
            /// </summary>
            public const int StopTime = 10;

            /// <summary>
            /// Property Indexer for GLSegmentOne
            /// </summary>
            public const int GLSegmentOne = 11;

            /// <summary>
            /// Property Indexer for GLSegmentTwo
            /// </summary>
            public const int GLSegmentTwo = 12;

            /// <summary>
            /// Property Indexer for GLSegmentThree
            /// </summary>
            public const int GLSegmentThree = 13;

            /// <summary>
            /// Property Indexer for Hours
            /// </summary>
            public const int Hours = 14;

            /// <summary>
            /// Property Indexer for CalculationMethod
            /// </summary>
            public const int CalculationMethod = 15;

            /// <summary>
            /// Property Indexer for BaseLimit
            /// </summary>
            public const int BaseLimit = 16;

            /// <summary>
            /// Property Indexer for PiecesSalesBase
            /// </summary>
            public const int PiecesSalesBase = 17;

            /// <summary>
            /// Property Indexer for EDTaxRateAmtPercent
            /// </summary>
            public const int EDTaxRateAmtPercent = 18;

            /// <summary>
            /// Property Indexer for PayAccrueHours
            /// </summary>
            public const int PayAccrueHours = 19;

            /// <summary>
            /// Property Indexer for RegularPayExpenseGLAccount
            /// </summary>
            public const int RegularPayExpenseGLAccount = 20;

            /// <summary>
            /// Property Indexer for LiabilityGLAccount
            /// </summary>
            public const int LiabilityGLAccount = 21;

            /// <summary>
            /// Property Indexer for OvertimeExpenseGLAccount
            /// </summary>
            public const int OvertimeExpenseGLAccount = 22;

            /// <summary>
            /// Property Indexer for ShiftDifferentialGLAccount
            /// </summary>
            public const int ShiftDifferentialGLAccount = 23;

            /// <summary>
            /// Property Indexer for AssetAccount
            /// </summary>
            public const int AssetAccount = 24;

            /// <summary>
            /// Property Indexer for OvertimeSchedule
            /// </summary>
            public const int OvertimeSchedule = 25;

            /// <summary>
            /// Property Indexer for ShiftDifferentialSchedule
            /// </summary>
            public const int ShiftDifferentialSchedule = 26;

            /// <summary>
            /// Property Indexer for ShiftNumber
            /// </summary>
            public const int ShiftNumber = 27;

            /// <summary>
            /// Property Indexer for WorkersCompensationCode
            /// </summary>
            public const int WorkersCompensationCode = 28;

            /// <summary>
            /// Property Indexer for WeeksWorked
            /// </summary>
            public const int WeeksWorked = 29;

            /// <summary>
            /// Property Indexer for TaxAnnualizationFactor
            /// </summary>
            public const int TaxAnnualizationFactor = 30;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for INTERNALUSE
            /// </summary>
            public const int INTERNALUSE = 31;

            /// <summary>
            /// Property Indexer for EntryType
            /// </summary>
            public const int EntryType = 32;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for POOLEDTIPS
            /// </summary>
            public const int POOLEDTIPS = 33;

            /// <summary>
            /// Property Indexer for EDTaxDescription
            /// </summary>
            public const int EDTaxDescription = 34;

            /// <summary>
            /// Property Indexer for GLSegmentNameOne
            /// </summary>
            public const int GLSegmentNameOne = 35;

            /// <summary>
            /// Property Indexer for GLSegmentDescriptionOne
            /// </summary>
            public const int GLSegmentDescriptionOne = 36;

            /// <summary>
            /// Property Indexer for GLSegmentNameTwo
            /// </summary>
            public const int GLSegmentNameTwo = 37;

            /// <summary>
            /// Property Indexer for GLSegmentDescriptionTwo
            /// </summary>
            public const int GLSegmentDescriptionTwo = 38;

            /// <summary>
            /// Property Indexer for GLSegmentNameThree
            /// </summary>
            public const int GLSegmentNameThree = 39;

            /// <summary>
            /// Property Indexer for GLSegmentDescriptionThree
            /// </summary>
            public const int GLSegmentDescriptionThree = 40;

            /// <summary>
            /// Property Indexer for INTERNALUSEKeyAction
            /// </summary>
            public const int INTERNALUSEKeyAction = 41;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for WORKPROV
            /// </summary>
            public const int WORKPROV = 42;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 43;

            /// <summary>
            /// Property Indexer for INTERNALUSENewKeyEmployee
            /// </summary>
            public const int INTERNALUSENewKeyEmployee = 44;

            /// <summary>
            /// Property Indexer for INTERNALUSENewKeyPeriodEn
            /// </summary>
            public const int INTERNALUSENewKeyPeriodEn = 45;

            /// <summary>
            /// Property Indexer for INTERNALUSENewKeyTimecard
            /// </summary>
            public const int INTERNALUSENewKeyTimecard = 46;

            /// <summary>
            /// Property Indexer for INTERNALUSENewKeyLineNumb
            /// </summary>
            public const int INTERNALUSENewKeyLineNumb = 47;

            /// <summary>
            /// Property Indexer for RESERVEDGLSegmentNameFour
            /// </summary>
            public const int RESERVEDGLSegmentNameFour = 48;

            /// <summary>
            /// Property Indexer for GLSEGDESC4
            /// </summary>
            public const int GLSEGDESC4 = 49;

            /// <summary>
            /// Property Indexer for RESERVEDGLSegmentNameFive
            /// </summary>
            public const int RESERVEDGLSegmentNameFive = 50;

            /// <summary>
            /// Property Indexer for GLSEGDESC5
            /// </summary>
            public const int GLSEGDESC5 = 51;

            /// <summary>
            /// Property Indexer for RESERVEDGLSegmentNameSix
            /// </summary>
            public const int RESERVEDGLSegmentNameSix = 52;

            /// <summary>
            /// Property Indexer for GLSEGDESC6
            /// </summary>
            public const int GLSEGDESC6 = 53;

            /// <summary>
            /// Property Indexer for DaysWorked
            /// </summary>
            public const int DaysWorked = 100;

            /// <summary>
            /// Property Indexer for WorkersCompGroup
            /// </summary>
            public const int WorkersCompGroup = 108;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 109;

            /// <summary>
            /// Property Indexer for OvertimeHoursOverride
            /// </summary>
            public const int OvertimeHoursOverride = 110;

            /// <summary>
            /// Property Indexer for OvertimeRateOverride
            /// </summary>
            public const int OvertimeRateOverride = 111;

            /// <summary>
            /// Property Indexer for IncludeInFLSAOvertimeCalc
            /// </summary>
            public const int IncludeInFLSAOvertimeCalc = 112;

            /// <summary>
            /// Property Indexer for DistributionCode
            /// </summary>
            public const int DistributionCode = 113;

            /// <summary>
            /// Property Indexer for EmployerExpenseGLAccount
            /// </summary>
            public const int EmployerExpenseGLAccount = 114;

            /// <summary>
            /// Property Indexer for EmployerLiabilityGLAccount
            /// </summary>
            public const int EmployerLiabilityGLAccount = 115;

            /// <summary>
            /// Property Indexer for JobsAllocBasedOnCalcBase
            /// </summary>
            public const int JobsAllocBasedOnCalcBase = 116;

            /// <summary>
            /// Property Indexer for Jobs
            /// </summary>
            public const int Jobs = 117;

            /// <summary>
            /// Property Indexer for WorkClassificationCode
            /// </summary>
            public const int WorkClassificationCode = 118;

            /// <summary>
            /// Property Indexer for TotalJobHours
            /// </summary>
            public const int TotalJobHours = 119;

            /// <summary>
            /// Property Indexer for TotalJobPiecesSalesAmt
            /// </summary>
            public const int TotalJobPiecesSalesAmt = 120;

            /// <summary>
            /// Property Indexer for EmployerCalculationMethod
            /// </summary>
            public const int EmployerCalculationMethod = 121;

            /// <summary>
            /// Property Indexer for EmployerBaseLimit
            /// </summary>
            public const int EmployerBaseLimit = 122;

            /// <summary>
            /// Property Indexer for OverrideEmployerRateAmtPct
            /// </summary>
            public const int OverrideEmployerRateAmtPct = 123;

            /// <summary>
            /// Property Indexer for EmployerRateAmtPct
            /// </summary>
            public const int EmployerRateAmtPct = 124;

            /// <summary>
            /// Property Indexer for DefaultEmployerRateAmtPct
            /// </summary>
            public const int DefaultEmployerRateAmtPct = 125;

            /// <summary>
            /// Property Indexer for RESERVEDGLSegmentFour
            /// </summary>
            public const int RESERVEDGLSegmentFour = 126;

            /// <summary>
            /// Property Indexer for RESERVEDGLSegmentFive
            /// </summary>
            public const int RESERVEDGLSegmentFive = 127;

            /// <summary>
            /// Property Indexer for RESERVEDGLSegmentSix
            /// </summary>
            public const int RESERVEDGLSegmentSix = 128;


        }

        #endregion

    }
}