// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of CompanyPayrollTaxe Constants
    /// </summary>
    public partial class CompanyPayrollTaxe
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0029";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"ROUNDTAXSW", "RoundTax"},
                    {"DAILYPPY", "DailyPayPeriodsPerYear"},
                    {"STDARDDED1", "StandardDeduction"},
                    {"EXMPTNAMT1", "AmountPerExemption"},
                    {"EXMPTCRSW", "TaxCreditExemptionSwitch"},
                    {"ANNMAXHRS", "AnnualMaximumHours"},
                    {"ANNMAXERN", "AnnualMaximumEarnings"},
                    {"ANNUALMIN", "AnnualMinimumEarnings"},
                    {"W2BOXTYP", "W2BoxType"},
                    {"W2WITHTAX", "CombineWithTax"},
                    {"ASSOCW2SW", "AssociateWithW2Printing"},
                    {"ASSOCTAX", "AssociatedTax"},
                    {"ECALCMTHD", "EmployeeCalculationMethod"},
                    {"ESUPPRATE", "EmployeeSupplementalRate"},
                    {"EBASETAX", "EmployeeBaseTax"},
                    {"EAMTORPCT", "EmployeeAmountPercent"},
                    {"ELIMITON", "EmployeeLimit"},
                    {"EANNUALMAX", "EmployeeAnnualMaximum"},
                    {"ECLCMINWRK", "EmployeeMinimumWeeksWorked"},
                    {"EDAILYMIN", "EmployeeDailyMinimum"},
                    {"EDAILYMAX", "EmployeeDailyMaximum"},
                    {"EWEEKLYMIN", "EmployeeWeeklyMinimum"},
                    {"EWEEKLYMAX", "EmployeeWeeklyMaximum"},
                    {"EBIWKLYMIN", "EmployeeBiweeklyMinimum"},
                    {"EBIWKLYMAX", "EmployeeBiweeklyMaximum"},
                    {"ESEMIMNMIN", "EmployeeSemimonthlyMinimum"},
                    {"ESEMIMNMAX", "EmployeeSemimonthlyMaximum"},
                    {"EMNTHLYMIN", "EmployeeMonthlyMinimum"},
                    {"EMNTHLYMAX", "EmployeeMonthlyMaximum"},
                    {"EQRTRLYMIN", "EmployeeQuarterlyMinimum"},
                    {"EQRTRLYMAX", "EmployeeQuarterlyMaximum"},
                    {"E10PPPYMIN", "Employee10PayPeriodsYearMin"},
                    {"E10PPPYMAX", "Employee10PayPeriodsYearMax"},
                    {"E13PPPYMIN", "Employee13PayPeriodsYearMin"},
                    {"E13PPPYMAX", "Employee13PayPeriodsYearMax"},
                    {"E22PPPYMIN", "Employee22PayPeriodsYearMin"},
                    {"E22PPPYMAX", "Employee22PayPeriodsYearMax"},
                    {"RCALCMTHD", "EmployerCalculationMethod"},
                    {"RBASETAX", "EmployerBaseTax"},
                    {"RAMTORPCT", "EmployerAmountPercent"},
                    {"RLIMITON", "EmployerLimit"},
                    {"RANNUALMAX", "EmployerAnnualMaximum"},
                    {"RCLCMINWRK", "EmployerMinimumWeeksWorked"},
                    {"RDAILYMIN", "EmployerDailyMinimum"},
                    {"RDAILYMAX", "EmployerDailyMaximum"},
                    {"RWEEKLYMIN", "EmployerWeeklyMinimum"},
                    {"RWEEKLYMAX", "EmployerWeeklyMaximum"},
                    {"RBIWKLYMIN", "EmployerBiweeklyMinimum"},
                    {"RBIWKLYMAX", "EmployerBiweeklyMaximum"},
                    {"RSEMIMNMIN", "EmployerSemimonthlyMinimum"},
                    {"RSEMIMNMAX", "EmployerSemimonthlyMaximum"},
                    {"RMNTHLYMIN", "EmployerMonthlyMinimum"},
                    {"RMNTHLYMAX", "EmployerMonthlyMaximum"},
                    {"RQRTRLYMIN", "EmployerQuarterlyMinimum"},
                    {"RQRTRLYMAX", "EmployerQuarterlyMaximum"},
                    {"R10PPPYMIN", "Employer10PayPeriodsYearMin"},
                    {"R10PPPYMAX", "Employer10PayPeriodsYearMax"},
                    {"R13PPPYMIN", "Employer13PayPeriodsYearMin"},
                    {"R13PPPYMAX", "Employer13PayPeriodsYearMax"},
                    {"R22PPPYMIN", "Employer22PayPeriodsYearMin"},
                    {"R22PPPYMAX", "Employer22PayPeriodsYearMax"},
                    {"WGBRACK1", "WageCeilingForBracket1"},
                    {"WGADDAMT1", "TaxAddAmountForBracket1"},
                    {"WGPCTOVR1", "TaxPercentageForBracket1"},
                    {"WGBRACK2", "WageCeilingForBracket2"},
                    {"WGADDAMT2", "TaxAddAmountForBracket2"},
                    {"WGPCTOVR2", "TaxPercentageForBracket2"},
                    {"WGBRACK3", "WageCeilingForBracket3"},
                    {"WGADDAMT3", "TaxAddAmountForBracket3"},
                    {"WGPCTOVR3", "TaxPercentageForBracket3"},
                    {"WGBRACK4", "WageCeilingForBracket4"},
                    {"WGADDAMT4", "TaxAddAmountForBracket4"},
                    {"WGPCTOVR4", "TaxPercentageForBracket4"},
                    {"WGBRACK5", "WageCeilingForBracket5"},
                    {"WGADDAMT5", "TaxAddAmountForBracket5"},
                    {"WGPCTOVR5", "TaxPercentageForBracket5"},
                    {"WGBRACK6", "WageCeilingForBracket6"},
                    {"WGADDAMT6", "TaxAddAmountForBracket6"},
                    {"WGPCTOVR6", "TaxPercentageForBracket6"},
                    {"WGBRACK7", "WageCeilingForBracket7"},
                    {"WGADDAMT7", "TaxAddAmountForBracket7"},
                    {"WGPCTOVR7", "TaxPercentageForBracket7"},
                    {"WGBRACK8", "WageCeilingForBracket8"},
                    {"WGADDAMT8", "TaxAddAmountForBracket8"},
                    {"WGPCTOVR8", "TaxPercentageForBracket8"},
                    {"WGBRACK9", "WageCeilingForBracket9"},
                    {"WGADDAMT9", "TaxAddAmountForBracket9"},
                    {"WGPCTOVR9", "TaxPercentageForBracket9"},
                    {"WGBRACK10", "WageCeilingForBracket10"},
                    {"WGADDAMT10", "TaxAddAmountForBracket10"},
                    {"WGPCTOVR10", "TaxPercentageForBracket10"},
                    {"WGBRACK11", "WageCeilingForBracket11"},
                    {"WGADDAMT11", "TaxAddAmountForBracket11"},
                    {"WGPCTOVR11", "TaxPercentageForBracket11"},
                    {"WGBRACK12", "WageCeilingForBracket12"},
                    {"WGADDAMT12", "TaxAddAmountForBracket12"},
                    {"WGPCTOVR12", "TaxPercentageForBracket12"},
                    {"WGBRACK13", "WageCeilingForBracket13"},
                    {"WGADDAMT13", "TaxAddAmountForBracket13"},
                    {"WGPCTOVR13", "TaxPercentageForBracket13"},
                    {"WGBRACK14", "WageCeilingForBracket14"},
                    {"WGADDAMT14", "TaxAddAmountForBracket14"},
                    {"WGPCTOVR14", "TaxPercentageForBracket14"},
                    {"WGBRACK15", "WageCeilingForBracket15"},
                    {"WGADDAMT15", "TaxAddAmountForBracket15"},
                    {"WGPCTOVR15", "TaxPercentageForBracket15"},
                    {"WGBRACK16", "WageCeilingForBracket16"},
                    {"WGADDAMT16", "TaxAddAmountForBracket16"},
                    {"WGPCTOVR16", "TaxPercentageForBracket16"},
                    {"WGBRACK17", "WageCeilingForBracket17"},
                    {"WGADDAMT17", "TaxAddAmountForBracket17"},
                    {"WGPCTOVR17", "TaxPercentageForBracket17"},
                    {"WGBRACK18", "WageCeilingForBracket18"},
                    {"WGADDAMT18", "TaxAddAmountForBracket18"},
                    {"WGPCTOVR18", "TaxPercentageForBracket18"},
                    {"WGBRACK19", "WageCeilingForBracket19"},
                    {"WGADDAMT19", "TaxAddAmountForBracket19"},
                    {"WGPCTOVR19", "TaxPercentageForBracket19"},
                    {"WGBRACK20", "WageCeilingForBracket20"},
                    {"WGADDAMT20", "TaxAddAmountForBracket20"},
                    {"WGPCTOVR20", "TaxPercentageForBracket20"},
                    {"LEVEL", "Level"},
                    {"LISTUSEBHI", "ListUsageForBaseHoursInclud"},
                    {"LISTUSEBEI", "ListUsageForBaseEarningsInc"},
                    {"WHMETHBEI", "WithholdingMethodForBaseEarn"},
                    {"LISTUSEBDI", "ListUsageForBaseDeductionsI"},
                    {"AUTOUPDATE", "AutomaticallyUpdateLocalTax"},
                    {"LOCSTATE", "State"},
                    {"LOCTAXCODE", "LocalTaxCode"},
                    {"ATXTYPE", "RESERVEDAatrixTaxType"},
                    {"EMPDEFAULT", "AutomaticallyPopulateEmployee"},
                    {"EMPDEFDIST", "DefaultDistributionCode"},
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of CompanyPayrollTaxe Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Tax
            /// </summary>
            public const string Tax = "TAXID";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "TAXTYPE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "LONGDESC";

            /// <summary>
            /// Property for ShortDescription
            /// </summary>
            public const string ShortDescription = "SHORTDESC";

            /// <summary>
            /// Property for ReportingID
            /// </summary>
            public const string ReportingID = "REPORTID";

            /// <summary>
            /// Property for TaxInactive
            /// </summary>
            public const string TaxInactive = "ACTIVESW";

            /// <summary>
            /// Property for InactiveDate
            /// </summary>
            public const string InactiveDate = "INACTASOF";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "LASTMAINT";

            /// <summary>
            /// Property for BaseMultiplier
            /// </summary>
            public const string BaseMultiplier = "BASEMULT";

            /// <summary>
            /// Property for SurtaxMultiplier
            /// </summary>
            public const string SurtaxMultiplier = "SURTAXMULT";

            /// <summary>
            /// Property for RoundTax
            /// </summary>
            public const string RoundTax = "ROUNDTAXSW";

            /// <summary>
            /// Property for DailyPayPeriodsPerYear
            /// </summary>
            public const string DailyPayPeriodsPerYear = "DAILYPPY";

            /// <summary>
            /// Property for RESERVEDTaxCredits
            /// </summary>
            public const string RESERVEDTaxCredits = "TAXCREDITS";

            /// <summary>
            /// Property for RESERVEDTaxCreditPercent
            /// </summary>
            public const string RESERVEDTaxCreditPercent = "TAXCRPCNT";

            /// <summary>
            /// Property for StandardDeduction
            /// </summary>
            public const string StandardDeduction = "STDARDDED1";

            /// <summary>
            /// Property for STDARDDED2
            /// </summary>
            public const string STDARDDED2 = "STDARDDED2";

            /// <summary>
            /// Property for STDARDDED3
            /// </summary>
            public const string STDARDDED3 = "STDARDDED3";

            /// <summary>
            /// Property for STDARDDED4
            /// </summary>
            public const string STDARDDED4 = "STDARDDED4";

            /// <summary>
            /// Property for AmountPerExemption
            /// </summary>
            public const string AmountPerExemption = "EXMPTNAMT1";

            /// <summary>
            /// Property for EXMPTNAMT2
            /// </summary>
            public const string EXMPTNAMT2 = "EXMPTNAMT2";

            /// <summary>
            /// Property for EXMPTNAMT3
            /// </summary>
            public const string EXMPTNAMT3 = "EXMPTNAMT3";

            /// <summary>
            /// Property for EXMPTNAMT4
            /// </summary>
            public const string EXMPTNAMT4 = "EXMPTNAMT4";

            /// <summary>
            /// Property for TaxCreditExemptionSwitch
            /// </summary>
            public const string TaxCreditExemptionSwitch = "EXMPTCRSW";

            /// <summary>
            /// Property for AnnualMaximumHours
            /// </summary>
            public const string AnnualMaximumHours = "ANNMAXHRS";

            /// <summary>
            /// Property for AnnualMaximumEarnings
            /// </summary>
            public const string AnnualMaximumEarnings = "ANNMAXERN";

            /// <summary>
            /// Property for AnnualMinimumEarnings
            /// </summary>
            public const string AnnualMinimumEarnings = "ANNUALMIN";

            /// <summary>
            /// Property for W2BoxType
            /// </summary>
            public const string W2BoxType = "W2BOXTYP";

            /// <summary>
            /// Property for CombineWithTax
            /// </summary>
            public const string CombineWithTax = "W2WITHTAX";

            /// <summary>
            /// Property for AssociateWithW2Printing
            /// </summary>
            public const string AssociateWithW2Printing = "ASSOCW2SW";

            /// <summary>
            /// Property for AssociatedTax
            /// </summary>
            public const string AssociatedTax = "ASSOCTAX";

            /// <summary>
            /// Property for EmployeeCalculationMethod
            /// </summary>
            public const string EmployeeCalculationMethod = "ECALCMTHD";

            /// <summary>
            /// Property for EmployeeSupplementalRate
            /// </summary>
            public const string EmployeeSupplementalRate = "ESUPPRATE";

            /// <summary>
            /// Property for EmployeeBaseTax
            /// </summary>
            public const string EmployeeBaseTax = "EBASETAX";

            /// <summary>
            /// Property for EmployeeAmountPercent
            /// </summary>
            public const string EmployeeAmountPercent = "EAMTORPCT";

            /// <summary>
            /// Property for EmployeeLimit
            /// </summary>
            public const string EmployeeLimit = "ELIMITON";

            /// <summary>
            /// Property for EmployeeAnnualMaximum
            /// </summary>
            public const string EmployeeAnnualMaximum = "EANNUALMAX";

            /// <summary>
            /// Property for EmployeeMinimumWeeksWorked
            /// </summary>
            public const string EmployeeMinimumWeeksWorked = "ECLCMINWRK";

            /// <summary>
            /// Property for EmployeeDailyMinimum
            /// </summary>
            public const string EmployeeDailyMinimum = "EDAILYMIN";

            /// <summary>
            /// Property for EmployeeDailyMaximum
            /// </summary>
            public const string EmployeeDailyMaximum = "EDAILYMAX";

            /// <summary>
            /// Property for EmployeeWeeklyMinimum
            /// </summary>
            public const string EmployeeWeeklyMinimum = "EWEEKLYMIN";

            /// <summary>
            /// Property for EmployeeWeeklyMaximum
            /// </summary>
            public const string EmployeeWeeklyMaximum = "EWEEKLYMAX";

            /// <summary>
            /// Property for EmployeeBiweeklyMinimum
            /// </summary>
            public const string EmployeeBiweeklyMinimum = "EBIWKLYMIN";

            /// <summary>
            /// Property for EmployeeBiweeklyMaximum
            /// </summary>
            public const string EmployeeBiweeklyMaximum = "EBIWKLYMAX";

            /// <summary>
            /// Property for EmployeeSemimonthlyMinimum
            /// </summary>
            public const string EmployeeSemimonthlyMinimum = "ESEMIMNMIN";

            /// <summary>
            /// Property for EmployeeSemimonthlyMaximum
            /// </summary>
            public const string EmployeeSemimonthlyMaximum = "ESEMIMNMAX";

            /// <summary>
            /// Property for EmployeeMonthlyMinimum
            /// </summary>
            public const string EmployeeMonthlyMinimum = "EMNTHLYMIN";

            /// <summary>
            /// Property for EmployeeMonthlyMaximum
            /// </summary>
            public const string EmployeeMonthlyMaximum = "EMNTHLYMAX";

            /// <summary>
            /// Property for EmployeeQuarterlyMinimum
            /// </summary>
            public const string EmployeeQuarterlyMinimum = "EQRTRLYMIN";

            /// <summary>
            /// Property for EmployeeQuarterlyMaximum
            /// </summary>
            public const string EmployeeQuarterlyMaximum = "EQRTRLYMAX";

            /// <summary>
            /// Property for Employee10PayPeriodsYearMin
            /// </summary>
            public const string Employee10PayPeriodsYearMin = "E10PPPYMIN";

            /// <summary>
            /// Property for Employee10PayPeriodsYearMax
            /// </summary>
            public const string Employee10PayPeriodsYearMax = "E10PPPYMAX";

            /// <summary>
            /// Property for Employee13PayPeriodsYearMin
            /// </summary>
            public const string Employee13PayPeriodsYearMin = "E13PPPYMIN";

            /// <summary>
            /// Property for Employee13PayPeriodsYearMax
            /// </summary>
            public const string Employee13PayPeriodsYearMax = "E13PPPYMAX";

            /// <summary>
            /// Property for Employee22PayPeriodsYearMin
            /// </summary>
            public const string Employee22PayPeriodsYearMin = "E22PPPYMIN";

            /// <summary>
            /// Property for Employee22PayPeriodsYearMax
            /// </summary>
            public const string Employee22PayPeriodsYearMax = "E22PPPYMAX";

            /// <summary>
            /// Property for EmployerCalculationMethod
            /// </summary>
            public const string EmployerCalculationMethod = "RCALCMTHD";

            /// <summary>
            /// Property for EmployerBaseTax
            /// </summary>
            public const string EmployerBaseTax = "RBASETAX";

            /// <summary>
            /// Property for EmployerAmountPercent
            /// </summary>
            public const string EmployerAmountPercent = "RAMTORPCT";

            /// <summary>
            /// Property for EmployerLimit
            /// </summary>
            public const string EmployerLimit = "RLIMITON";

            /// <summary>
            /// Property for EmployerAnnualMaximum
            /// </summary>
            public const string EmployerAnnualMaximum = "RANNUALMAX";

            /// <summary>
            /// Property for EmployerMinimumWeeksWorked
            /// </summary>
            public const string EmployerMinimumWeeksWorked = "RCLCMINWRK";

            /// <summary>
            /// Property for EmployerDailyMinimum
            /// </summary>
            public const string EmployerDailyMinimum = "RDAILYMIN";

            /// <summary>
            /// Property for EmployerDailyMaximum
            /// </summary>
            public const string EmployerDailyMaximum = "RDAILYMAX";

            /// <summary>
            /// Property for EmployerWeeklyMinimum
            /// </summary>
            public const string EmployerWeeklyMinimum = "RWEEKLYMIN";

            /// <summary>
            /// Property for EmployerWeeklyMaximum
            /// </summary>
            public const string EmployerWeeklyMaximum = "RWEEKLYMAX";

            /// <summary>
            /// Property for EmployerBiweeklyMinimum
            /// </summary>
            public const string EmployerBiweeklyMinimum = "RBIWKLYMIN";

            /// <summary>
            /// Property for EmployerBiweeklyMaximum
            /// </summary>
            public const string EmployerBiweeklyMaximum = "RBIWKLYMAX";

            /// <summary>
            /// Property for EmployerSemimonthlyMinimum
            /// </summary>
            public const string EmployerSemimonthlyMinimum = "RSEMIMNMIN";

            /// <summary>
            /// Property for EmployerSemimonthlyMaximum
            /// </summary>
            public const string EmployerSemimonthlyMaximum = "RSEMIMNMAX";

            /// <summary>
            /// Property for EmployerMonthlyMinimum
            /// </summary>
            public const string EmployerMonthlyMinimum = "RMNTHLYMIN";

            /// <summary>
            /// Property for EmployerMonthlyMaximum
            /// </summary>
            public const string EmployerMonthlyMaximum = "RMNTHLYMAX";

            /// <summary>
            /// Property for EmployerQuarterlyMinimum
            /// </summary>
            public const string EmployerQuarterlyMinimum = "RQRTRLYMIN";

            /// <summary>
            /// Property for EmployerQuarterlyMaximum
            /// </summary>
            public const string EmployerQuarterlyMaximum = "RQRTRLYMAX";

            /// <summary>
            /// Property for Employer10PayPeriodsYearMin
            /// </summary>
            public const string Employer10PayPeriodsYearMin = "R10PPPYMIN";

            /// <summary>
            /// Property for Employer10PayPeriodsYearMax
            /// </summary>
            public const string Employer10PayPeriodsYearMax = "R10PPPYMAX";

            /// <summary>
            /// Property for Employer13PayPeriodsYearMin
            /// </summary>
            public const string Employer13PayPeriodsYearMin = "R13PPPYMIN";

            /// <summary>
            /// Property for Employer13PayPeriodsYearMax
            /// </summary>
            public const string Employer13PayPeriodsYearMax = "R13PPPYMAX";

            /// <summary>
            /// Property for Employer22PayPeriodsYearMin
            /// </summary>
            public const string Employer22PayPeriodsYearMin = "R22PPPYMIN";

            /// <summary>
            /// Property for Employer22PayPeriodsYearMax
            /// </summary>
            public const string Employer22PayPeriodsYearMax = "R22PPPYMAX";

            /// <summary>
            /// Property for WageCeilingForBracket1
            /// </summary>
            public const string WageCeilingForBracket1 = "WGBRACK1";

            /// <summary>
            /// Property for TaxAddAmountForBracket1
            /// </summary>
            public const string TaxAddAmountForBracket1 = "WGADDAMT1";

            /// <summary>
            /// Property for TaxPercentageForBracket1
            /// </summary>
            public const string TaxPercentageForBracket1 = "WGPCTOVR1";

            /// <summary>
            /// Property for WageCeilingForBracket2
            /// </summary>
            public const string WageCeilingForBracket2 = "WGBRACK2";

            /// <summary>
            /// Property for TaxAddAmountForBracket2
            /// </summary>
            public const string TaxAddAmountForBracket2 = "WGADDAMT2";

            /// <summary>
            /// Property for TaxPercentageForBracket2
            /// </summary>
            public const string TaxPercentageForBracket2 = "WGPCTOVR2";

            /// <summary>
            /// Property for WageCeilingForBracket3
            /// </summary>
            public const string WageCeilingForBracket3 = "WGBRACK3";

            /// <summary>
            /// Property for TaxAddAmountForBracket3
            /// </summary>
            public const string TaxAddAmountForBracket3 = "WGADDAMT3";

            /// <summary>
            /// Property for TaxPercentageForBracket3
            /// </summary>
            public const string TaxPercentageForBracket3 = "WGPCTOVR3";

            /// <summary>
            /// Property for WageCeilingForBracket4
            /// </summary>
            public const string WageCeilingForBracket4 = "WGBRACK4";

            /// <summary>
            /// Property for TaxAddAmountForBracket4
            /// </summary>
            public const string TaxAddAmountForBracket4 = "WGADDAMT4";

            /// <summary>
            /// Property for TaxPercentageForBracket4
            /// </summary>
            public const string TaxPercentageForBracket4 = "WGPCTOVR4";

            /// <summary>
            /// Property for WageCeilingForBracket5
            /// </summary>
            public const string WageCeilingForBracket5 = "WGBRACK5";

            /// <summary>
            /// Property for TaxAddAmountForBracket5
            /// </summary>
            public const string TaxAddAmountForBracket5 = "WGADDAMT5";

            /// <summary>
            /// Property for TaxPercentageForBracket5
            /// </summary>
            public const string TaxPercentageForBracket5 = "WGPCTOVR5";

            /// <summary>
            /// Property for WageCeilingForBracket6
            /// </summary>
            public const string WageCeilingForBracket6 = "WGBRACK6";

            /// <summary>
            /// Property for TaxAddAmountForBracket6
            /// </summary>
            public const string TaxAddAmountForBracket6 = "WGADDAMT6";

            /// <summary>
            /// Property for TaxPercentageForBracket6
            /// </summary>
            public const string TaxPercentageForBracket6 = "WGPCTOVR6";

            /// <summary>
            /// Property for WageCeilingForBracket7
            /// </summary>
            public const string WageCeilingForBracket7 = "WGBRACK7";

            /// <summary>
            /// Property for TaxAddAmountForBracket7
            /// </summary>
            public const string TaxAddAmountForBracket7 = "WGADDAMT7";

            /// <summary>
            /// Property for TaxPercentageForBracket7
            /// </summary>
            public const string TaxPercentageForBracket7 = "WGPCTOVR7";

            /// <summary>
            /// Property for WageCeilingForBracket8
            /// </summary>
            public const string WageCeilingForBracket8 = "WGBRACK8";

            /// <summary>
            /// Property for TaxAddAmountForBracket8
            /// </summary>
            public const string TaxAddAmountForBracket8 = "WGADDAMT8";

            /// <summary>
            /// Property for TaxPercentageForBracket8
            /// </summary>
            public const string TaxPercentageForBracket8 = "WGPCTOVR8";

            /// <summary>
            /// Property for WageCeilingForBracket9
            /// </summary>
            public const string WageCeilingForBracket9 = "WGBRACK9";

            /// <summary>
            /// Property for TaxAddAmountForBracket9
            /// </summary>
            public const string TaxAddAmountForBracket9 = "WGADDAMT9";

            /// <summary>
            /// Property for TaxPercentageForBracket9
            /// </summary>
            public const string TaxPercentageForBracket9 = "WGPCTOVR9";

            /// <summary>
            /// Property for WageCeilingForBracket10
            /// </summary>
            public const string WageCeilingForBracket10 = "WGBRACK10";

            /// <summary>
            /// Property for TaxAddAmountForBracket10
            /// </summary>
            public const string TaxAddAmountForBracket10 = "WGADDAMT10";

            /// <summary>
            /// Property for TaxPercentageForBracket10
            /// </summary>
            public const string TaxPercentageForBracket10 = "WGPCTOVR10";

            /// <summary>
            /// Property for WageCeilingForBracket11
            /// </summary>
            public const string WageCeilingForBracket11 = "WGBRACK11";

            /// <summary>
            /// Property for TaxAddAmountForBracket11
            /// </summary>
            public const string TaxAddAmountForBracket11 = "WGADDAMT11";

            /// <summary>
            /// Property for TaxPercentageForBracket11
            /// </summary>
            public const string TaxPercentageForBracket11 = "WGPCTOVR11";

            /// <summary>
            /// Property for WageCeilingForBracket12
            /// </summary>
            public const string WageCeilingForBracket12 = "WGBRACK12";

            /// <summary>
            /// Property for TaxAddAmountForBracket12
            /// </summary>
            public const string TaxAddAmountForBracket12 = "WGADDAMT12";

            /// <summary>
            /// Property for TaxPercentageForBracket12
            /// </summary>
            public const string TaxPercentageForBracket12 = "WGPCTOVR12";

            /// <summary>
            /// Property for WageCeilingForBracket13
            /// </summary>
            public const string WageCeilingForBracket13 = "WGBRACK13";

            /// <summary>
            /// Property for TaxAddAmountForBracket13
            /// </summary>
            public const string TaxAddAmountForBracket13 = "WGADDAMT13";

            /// <summary>
            /// Property for TaxPercentageForBracket13
            /// </summary>
            public const string TaxPercentageForBracket13 = "WGPCTOVR13";

            /// <summary>
            /// Property for WageCeilingForBracket14
            /// </summary>
            public const string WageCeilingForBracket14 = "WGBRACK14";

            /// <summary>
            /// Property for TaxAddAmountForBracket14
            /// </summary>
            public const string TaxAddAmountForBracket14 = "WGADDAMT14";

            /// <summary>
            /// Property for TaxPercentageForBracket14
            /// </summary>
            public const string TaxPercentageForBracket14 = "WGPCTOVR14";

            /// <summary>
            /// Property for WageCeilingForBracket15
            /// </summary>
            public const string WageCeilingForBracket15 = "WGBRACK15";

            /// <summary>
            /// Property for TaxAddAmountForBracket15
            /// </summary>
            public const string TaxAddAmountForBracket15 = "WGADDAMT15";

            /// <summary>
            /// Property for TaxPercentageForBracket15
            /// </summary>
            public const string TaxPercentageForBracket15 = "WGPCTOVR15";

            /// <summary>
            /// Property for WageCeilingForBracket16
            /// </summary>
            public const string WageCeilingForBracket16 = "WGBRACK16";

            /// <summary>
            /// Property for TaxAddAmountForBracket16
            /// </summary>
            public const string TaxAddAmountForBracket16 = "WGADDAMT16";

            /// <summary>
            /// Property for TaxPercentageForBracket16
            /// </summary>
            public const string TaxPercentageForBracket16 = "WGPCTOVR16";

            /// <summary>
            /// Property for WageCeilingForBracket17
            /// </summary>
            public const string WageCeilingForBracket17 = "WGBRACK17";

            /// <summary>
            /// Property for TaxAddAmountForBracket17
            /// </summary>
            public const string TaxAddAmountForBracket17 = "WGADDAMT17";

            /// <summary>
            /// Property for TaxPercentageForBracket17
            /// </summary>
            public const string TaxPercentageForBracket17 = "WGPCTOVR17";

            /// <summary>
            /// Property for WageCeilingForBracket18
            /// </summary>
            public const string WageCeilingForBracket18 = "WGBRACK18";

            /// <summary>
            /// Property for TaxAddAmountForBracket18
            /// </summary>
            public const string TaxAddAmountForBracket18 = "WGADDAMT18";

            /// <summary>
            /// Property for TaxPercentageForBracket18
            /// </summary>
            public const string TaxPercentageForBracket18 = "WGPCTOVR18";

            /// <summary>
            /// Property for WageCeilingForBracket19
            /// </summary>
            public const string WageCeilingForBracket19 = "WGBRACK19";

            /// <summary>
            /// Property for TaxAddAmountForBracket19
            /// </summary>
            public const string TaxAddAmountForBracket19 = "WGADDAMT19";

            /// <summary>
            /// Property for TaxPercentageForBracket19
            /// </summary>
            public const string TaxPercentageForBracket19 = "WGPCTOVR19";

            /// <summary>
            /// Property for WageCeilingForBracket20
            /// </summary>
            public const string WageCeilingForBracket20 = "WGBRACK20";

            /// <summary>
            /// Property for TaxAddAmountForBracket20
            /// </summary>
            public const string TaxAddAmountForBracket20 = "WGADDAMT20";

            /// <summary>
            /// Property for TaxPercentageForBracket20
            /// </summary>
            public const string TaxPercentageForBracket20 = "WGPCTOVR20";

            /// <summary>
            /// Property for Level
            /// </summary>
            public const string Level = "LEVEL";

            /// <summary>
            /// Property for ListUsageForBaseHoursInclud
            /// </summary>
            public const string ListUsageForBaseHoursInclud = "LISTUSEBHI";

            /// <summary>
            /// Property for ListUsageForBaseEarningsInc
            /// </summary>
            public const string ListUsageForBaseEarningsInc = "LISTUSEBEI";

            /// <summary>
            /// Property for WithholdingMethodForBaseEarn
            /// </summary>
            public const string WithholdingMethodForBaseEarn = "WHMETHBEI";

            /// <summary>
            /// Property for ListUsageForBaseDeductionsI
            /// </summary>
            public const string ListUsageForBaseDeductionsI = "LISTUSEBDI";

            /// <summary>
            /// Property for INTERNALUSETaxTableEffecti
            /// </summary>
            public const string INTERNALUSETaxTableEffecti = "EFFECTDATE";

            /// <summary>
            /// Property for INTERNALUSETaxTableFIPSNu
            /// </summary>
            public const string INTERNALUSETaxTableFIPSNu = "FIPSNBR";

            /// <summary>
            /// Property for INTERNALUSETaxTableFIPSCo
            /// </summary>
            public const string INTERNALUSETaxTableFIPSCo = "FIPSCODE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CFGPARMVER
            /// </summary>
            public const string CFGPARMVER = "CFGPARMVER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CFGPARMCNT
            /// </summary>
            public const string CFGPARMCNT = "CFGPARMCNT";

            /// <summary>
            /// Property for INTERNALUSETaxCalculationA
            /// </summary>
            public const string INTERNALUSETaxCalculationA = "CALCATTRIB";

            /// <summary>
            /// Property for INTERNALUSETaxYTDTracking
            /// </summary>
            public const string INTERNALUSETaxYTDTracking = "TRAKATTRIB";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for AutomaticallyUpdateLocalTax
            /// </summary>
            public const string AutomaticallyUpdateLocalTax = "AUTOUPDATE";

            /// <summary>
            /// Property for State
            /// </summary>
            public const string State = "LOCSTATE";

            /// <summary>
            /// Property for LocalTaxCode
            /// </summary>
            public const string LocalTaxCode = "LOCTAXCODE";

            /// <summary>
            /// Property for RESERVEDAatrixTaxType
            /// </summary>
            public const string RESERVEDAatrixTaxType = "ATXTYPE";

            /// <summary>
            /// Property for AutomaticallyPopulateEmployee
            /// </summary>
            public const string AutomaticallyPopulateEmployee = "EMPDEFAULT";

            /// <summary>
            /// Property for DefaultDistributionCode
            /// </summary>
            public const string DefaultDistributionCode = "EMPDEFDIST";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of CompanyPayrollTaxe Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Tax
            /// </summary>
            public const int Tax = 1;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 2;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 3;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 4;

            /// <summary>
            /// Property Indexer for ShortDescription
            /// </summary>
            public const int ShortDescription = 5;

            /// <summary>
            /// Property Indexer for ReportingID
            /// </summary>
            public const int ReportingID = 6;

            /// <summary>
            /// Property Indexer for TaxInactive
            /// </summary>
            public const int TaxInactive = 7;

            /// <summary>
            /// Property Indexer for InactiveDate
            /// </summary>
            public const int InactiveDate = 8;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 9;

            /// <summary>
            /// Property Indexer for BaseMultiplier
            /// </summary>
            public const int BaseMultiplier = 10;

            /// <summary>
            /// Property Indexer for SurtaxMultiplier
            /// </summary>
            public const int SurtaxMultiplier = 11;

            /// <summary>
            /// Property Indexer for RoundTax
            /// </summary>
            public const int RoundTax = 12;

            /// <summary>
            /// Property Indexer for DailyPayPeriodsPerYear
            /// </summary>
            public const int DailyPayPeriodsPerYear = 13;

            /// <summary>
            /// Property Indexer for RESERVEDTaxCredits
            /// </summary>
            public const int RESERVEDTaxCredits = 14;

            /// <summary>
            /// Property Indexer for RESERVEDTaxCreditPercent
            /// </summary>
            public const int RESERVEDTaxCreditPercent = 15;

            /// <summary>
            /// Property Indexer for StandardDeduction
            /// </summary>
            public const int StandardDeduction = 16;

            /// <summary>
            /// Property Indexer for STDARDDED2
            /// </summary>
            public const int STDARDDED2 = 17;

            /// <summary>
            /// Property Indexer for STDARDDED3
            /// </summary>
            public const int STDARDDED3 = 18;

            /// <summary>
            /// Property Indexer for STDARDDED4
            /// </summary>
            public const int STDARDDED4 = 19;

            /// <summary>
            /// Property Indexer for AmountPerExemption
            /// </summary>
            public const int AmountPerExemption = 20;

            /// <summary>
            /// Property Indexer for EXMPTNAMT2
            /// </summary>
            public const int EXMPTNAMT2 = 21;

            /// <summary>
            /// Property Indexer for EXMPTNAMT3
            /// </summary>
            public const int EXMPTNAMT3 = 22;

            /// <summary>
            /// Property Indexer for EXMPTNAMT4
            /// </summary>
            public const int EXMPTNAMT4 = 23;

            /// <summary>
            /// Property Indexer for TaxCreditExemptionSwitch
            /// </summary>
            public const int TaxCreditExemptionSwitch = 24;

            /// <summary>
            /// Property Indexer for AnnualMaximumHours
            /// </summary>
            public const int AnnualMaximumHours = 25;

            /// <summary>
            /// Property Indexer for AnnualMaximumEarnings
            /// </summary>
            public const int AnnualMaximumEarnings = 26;

            /// <summary>
            /// Property Indexer for AnnualMinimumEarnings
            /// </summary>
            public const int AnnualMinimumEarnings = 27;

            /// <summary>
            /// Property Indexer for W2BoxType
            /// </summary>
            public const int W2BoxType = 28;

            /// <summary>
            /// Property Indexer for CombineWithTax
            /// </summary>
            public const int CombineWithTax = 29;

            /// <summary>
            /// Property Indexer for AssociateWithW2Printing
            /// </summary>
            public const int AssociateWithW2Printing = 30;

            /// <summary>
            /// Property Indexer for AssociatedTax
            /// </summary>
            public const int AssociatedTax = 31;

            /// <summary>
            /// Property Indexer for EmployeeCalculationMethod
            /// </summary>
            public const int EmployeeCalculationMethod = 32;

            /// <summary>
            /// Property Indexer for EmployeeSupplementalRate
            /// </summary>
            public const int EmployeeSupplementalRate = 33;

            /// <summary>
            /// Property Indexer for EmployeeBaseTax
            /// </summary>
            public const int EmployeeBaseTax = 34;

            /// <summary>
            /// Property Indexer for EmployeeAmountPercent
            /// </summary>
            public const int EmployeeAmountPercent = 35;

            /// <summary>
            /// Property Indexer for EmployeeLimit
            /// </summary>
            public const int EmployeeLimit = 36;

            /// <summary>
            /// Property Indexer for EmployeeAnnualMaximum
            /// </summary>
            public const int EmployeeAnnualMaximum = 37;

            /// <summary>
            /// Property Indexer for EmployeeMinimumWeeksWorked
            /// </summary>
            public const int EmployeeMinimumWeeksWorked = 38;

            /// <summary>
            /// Property Indexer for EmployeeDailyMinimum
            /// </summary>
            public const int EmployeeDailyMinimum = 39;

            /// <summary>
            /// Property Indexer for EmployeeDailyMaximum
            /// </summary>
            public const int EmployeeDailyMaximum = 40;

            /// <summary>
            /// Property Indexer for EmployeeWeeklyMinimum
            /// </summary>
            public const int EmployeeWeeklyMinimum = 41;

            /// <summary>
            /// Property Indexer for EmployeeWeeklyMaximum
            /// </summary>
            public const int EmployeeWeeklyMaximum = 42;

            /// <summary>
            /// Property Indexer for EmployeeBiweeklyMinimum
            /// </summary>
            public const int EmployeeBiweeklyMinimum = 43;

            /// <summary>
            /// Property Indexer for EmployeeBiweeklyMaximum
            /// </summary>
            public const int EmployeeBiweeklyMaximum = 44;

            /// <summary>
            /// Property Indexer for EmployeeSemimonthlyMinimum
            /// </summary>
            public const int EmployeeSemimonthlyMinimum = 45;

            /// <summary>
            /// Property Indexer for EmployeeSemimonthlyMaximum
            /// </summary>
            public const int EmployeeSemimonthlyMaximum = 46;

            /// <summary>
            /// Property Indexer for EmployeeMonthlyMinimum
            /// </summary>
            public const int EmployeeMonthlyMinimum = 47;

            /// <summary>
            /// Property Indexer for EmployeeMonthlyMaximum
            /// </summary>
            public const int EmployeeMonthlyMaximum = 48;

            /// <summary>
            /// Property Indexer for EmployeeQuarterlyMinimum
            /// </summary>
            public const int EmployeeQuarterlyMinimum = 49;

            /// <summary>
            /// Property Indexer for EmployeeQuarterlyMaximum
            /// </summary>
            public const int EmployeeQuarterlyMaximum = 50;

            /// <summary>
            /// Property Indexer for Employee10PayPeriodsYearMin
            /// </summary>
            public const int Employee10PayPeriodsYearMin = 51;

            /// <summary>
            /// Property Indexer for Employee10PayPeriodsYearMax
            /// </summary>
            public const int Employee10PayPeriodsYearMax = 52;

            /// <summary>
            /// Property Indexer for Employee13PayPeriodsYearMin
            /// </summary>
            public const int Employee13PayPeriodsYearMin = 53;

            /// <summary>
            /// Property Indexer for Employee13PayPeriodsYearMax
            /// </summary>
            public const int Employee13PayPeriodsYearMax = 54;

            /// <summary>
            /// Property Indexer for Employee22PayPeriodsYearMin
            /// </summary>
            public const int Employee22PayPeriodsYearMin = 55;

            /// <summary>
            /// Property Indexer for Employee22PayPeriodsYearMax
            /// </summary>
            public const int Employee22PayPeriodsYearMax = 56;

            /// <summary>
            /// Property Indexer for EmployerCalculationMethod
            /// </summary>
            public const int EmployerCalculationMethod = 57;

            /// <summary>
            /// Property Indexer for EmployerBaseTax
            /// </summary>
            public const int EmployerBaseTax = 58;

            /// <summary>
            /// Property Indexer for EmployerAmountPercent
            /// </summary>
            public const int EmployerAmountPercent = 59;

            /// <summary>
            /// Property Indexer for EmployerLimit
            /// </summary>
            public const int EmployerLimit = 60;

            /// <summary>
            /// Property Indexer for EmployerAnnualMaximum
            /// </summary>
            public const int EmployerAnnualMaximum = 61;

            /// <summary>
            /// Property Indexer for EmployerMinimumWeeksWorked
            /// </summary>
            public const int EmployerMinimumWeeksWorked = 62;

            /// <summary>
            /// Property Indexer for EmployerDailyMinimum
            /// </summary>
            public const int EmployerDailyMinimum = 63;

            /// <summary>
            /// Property Indexer for EmployerDailyMaximum
            /// </summary>
            public const int EmployerDailyMaximum = 64;

            /// <summary>
            /// Property Indexer for EmployerWeeklyMinimum
            /// </summary>
            public const int EmployerWeeklyMinimum = 65;

            /// <summary>
            /// Property Indexer for EmployerWeeklyMaximum
            /// </summary>
            public const int EmployerWeeklyMaximum = 66;

            /// <summary>
            /// Property Indexer for EmployerBiweeklyMinimum
            /// </summary>
            public const int EmployerBiweeklyMinimum = 67;

            /// <summary>
            /// Property Indexer for EmployerBiweeklyMaximum
            /// </summary>
            public const int EmployerBiweeklyMaximum = 68;

            /// <summary>
            /// Property Indexer for EmployerSemimonthlyMinimum
            /// </summary>
            public const int EmployerSemimonthlyMinimum = 69;

            /// <summary>
            /// Property Indexer for EmployerSemimonthlyMaximum
            /// </summary>
            public const int EmployerSemimonthlyMaximum = 70;

            /// <summary>
            /// Property Indexer for EmployerMonthlyMinimum
            /// </summary>
            public const int EmployerMonthlyMinimum = 71;

            /// <summary>
            /// Property Indexer for EmployerMonthlyMaximum
            /// </summary>
            public const int EmployerMonthlyMaximum = 72;

            /// <summary>
            /// Property Indexer for EmployerQuarterlyMinimum
            /// </summary>
            public const int EmployerQuarterlyMinimum = 73;

            /// <summary>
            /// Property Indexer for EmployerQuarterlyMaximum
            /// </summary>
            public const int EmployerQuarterlyMaximum = 74;

            /// <summary>
            /// Property Indexer for Employer10PayPeriodsYearMin
            /// </summary>
            public const int Employer10PayPeriodsYearMin = 75;

            /// <summary>
            /// Property Indexer for Employer10PayPeriodsYearMax
            /// </summary>
            public const int Employer10PayPeriodsYearMax = 76;

            /// <summary>
            /// Property Indexer for Employer13PayPeriodsYearMin
            /// </summary>
            public const int Employer13PayPeriodsYearMin = 77;

            /// <summary>
            /// Property Indexer for Employer13PayPeriodsYearMax
            /// </summary>
            public const int Employer13PayPeriodsYearMax = 78;

            /// <summary>
            /// Property Indexer for Employer22PayPeriodsYearMin
            /// </summary>
            public const int Employer22PayPeriodsYearMin = 79;

            /// <summary>
            /// Property Indexer for Employer22PayPeriodsYearMax
            /// </summary>
            public const int Employer22PayPeriodsYearMax = 80;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket1
            /// </summary>
            public const int WageCeilingForBracket1 = 81;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket1
            /// </summary>
            public const int TaxAddAmountForBracket1 = 82;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket1
            /// </summary>
            public const int TaxPercentageForBracket1 = 83;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket2
            /// </summary>
            public const int WageCeilingForBracket2 = 84;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket2
            /// </summary>
            public const int TaxAddAmountForBracket2 = 85;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket2
            /// </summary>
            public const int TaxPercentageForBracket2 = 86;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket3
            /// </summary>
            public const int WageCeilingForBracket3 = 87;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket3
            /// </summary>
            public const int TaxAddAmountForBracket3 = 88;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket3
            /// </summary>
            public const int TaxPercentageForBracket3 = 89;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket4
            /// </summary>
            public const int WageCeilingForBracket4 = 90;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket4
            /// </summary>
            public const int TaxAddAmountForBracket4 = 91;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket4
            /// </summary>
            public const int TaxPercentageForBracket4 = 92;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket5
            /// </summary>
            public const int WageCeilingForBracket5 = 93;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket5
            /// </summary>
            public const int TaxAddAmountForBracket5 = 94;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket5
            /// </summary>
            public const int TaxPercentageForBracket5 = 95;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket6
            /// </summary>
            public const int WageCeilingForBracket6 = 96;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket6
            /// </summary>
            public const int TaxAddAmountForBracket6 = 97;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket6
            /// </summary>
            public const int TaxPercentageForBracket6 = 98;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket7
            /// </summary>
            public const int WageCeilingForBracket7 = 99;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket7
            /// </summary>
            public const int TaxAddAmountForBracket7 = 100;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket7
            /// </summary>
            public const int TaxPercentageForBracket7 = 101;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket8
            /// </summary>
            public const int WageCeilingForBracket8 = 102;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket8
            /// </summary>
            public const int TaxAddAmountForBracket8 = 103;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket8
            /// </summary>
            public const int TaxPercentageForBracket8 = 104;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket9
            /// </summary>
            public const int WageCeilingForBracket9 = 105;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket9
            /// </summary>
            public const int TaxAddAmountForBracket9 = 106;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket9
            /// </summary>
            public const int TaxPercentageForBracket9 = 107;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket10
            /// </summary>
            public const int WageCeilingForBracket10 = 108;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket10
            /// </summary>
            public const int TaxAddAmountForBracket10 = 109;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket10
            /// </summary>
            public const int TaxPercentageForBracket10 = 110;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket11
            /// </summary>
            public const int WageCeilingForBracket11 = 111;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket11
            /// </summary>
            public const int TaxAddAmountForBracket11 = 112;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket11
            /// </summary>
            public const int TaxPercentageForBracket11 = 113;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket12
            /// </summary>
            public const int WageCeilingForBracket12 = 114;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket12
            /// </summary>
            public const int TaxAddAmountForBracket12 = 115;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket12
            /// </summary>
            public const int TaxPercentageForBracket12 = 116;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket13
            /// </summary>
            public const int WageCeilingForBracket13 = 117;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket13
            /// </summary>
            public const int TaxAddAmountForBracket13 = 118;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket13
            /// </summary>
            public const int TaxPercentageForBracket13 = 119;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket14
            /// </summary>
            public const int WageCeilingForBracket14 = 120;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket14
            /// </summary>
            public const int TaxAddAmountForBracket14 = 121;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket14
            /// </summary>
            public const int TaxPercentageForBracket14 = 122;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket15
            /// </summary>
            public const int WageCeilingForBracket15 = 123;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket15
            /// </summary>
            public const int TaxAddAmountForBracket15 = 124;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket15
            /// </summary>
            public const int TaxPercentageForBracket15 = 125;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket16
            /// </summary>
            public const int WageCeilingForBracket16 = 126;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket16
            /// </summary>
            public const int TaxAddAmountForBracket16 = 127;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket16
            /// </summary>
            public const int TaxPercentageForBracket16 = 128;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket17
            /// </summary>
            public const int WageCeilingForBracket17 = 129;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket17
            /// </summary>
            public const int TaxAddAmountForBracket17 = 130;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket17
            /// </summary>
            public const int TaxPercentageForBracket17 = 131;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket18
            /// </summary>
            public const int WageCeilingForBracket18 = 132;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket18
            /// </summary>
            public const int TaxAddAmountForBracket18 = 133;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket18
            /// </summary>
            public const int TaxPercentageForBracket18 = 134;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket19
            /// </summary>
            public const int WageCeilingForBracket19 = 135;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket19
            /// </summary>
            public const int TaxAddAmountForBracket19 = 136;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket19
            /// </summary>
            public const int TaxPercentageForBracket19 = 137;

            /// <summary>
            /// Property Indexer for WageCeilingForBracket20
            /// </summary>
            public const int WageCeilingForBracket20 = 138;

            /// <summary>
            /// Property Indexer for TaxAddAmountForBracket20
            /// </summary>
            public const int TaxAddAmountForBracket20 = 139;

            /// <summary>
            /// Property Indexer for TaxPercentageForBracket20
            /// </summary>
            public const int TaxPercentageForBracket20 = 140;

            /// <summary>
            /// Property Indexer for Level
            /// </summary>
            public const int Level = 141;

            /// <summary>
            /// Property Indexer for ListUsageForBaseHoursInclud
            /// </summary>
            public const int ListUsageForBaseHoursInclud = 142;

            /// <summary>
            /// Property Indexer for ListUsageForBaseEarningsInc
            /// </summary>
            public const int ListUsageForBaseEarningsInc = 143;

            /// <summary>
            /// Property Indexer for WithholdingMethodForBaseEarn
            /// </summary>
            public const int WithholdingMethodForBaseEarn = 144;

            /// <summary>
            /// Property Indexer for ListUsageForBaseDeductionsI
            /// </summary>
            public const int ListUsageForBaseDeductionsI = 145;

            /// <summary>
            /// Property Indexer for INTERNALUSETaxTableEffecti
            /// </summary>
            public const int INTERNALUSETaxTableEffecti = 146;

            /// <summary>
            /// Property Indexer for INTERNALUSETaxTableFIPSNu
            /// </summary>
            public const int INTERNALUSETaxTableFIPSNu = 147;

            /// <summary>
            /// Property Indexer for INTERNALUSETaxTableFIPSCo
            /// </summary>
            public const int INTERNALUSETaxTableFIPSCo = 148;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CFGPARMVER
            /// </summary>
            public const int CFGPARMVER = 149;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CFGPARMCNT
            /// </summary>
            public const int CFGPARMCNT = 150;

            /// <summary>
            /// Property Indexer for INTERNALUSETaxCalculationA
            /// </summary>
            public const int INTERNALUSETaxCalculationA = 151;

            /// <summary>
            /// Property Indexer for INTERNALUSETaxYTDTracking
            /// </summary>
            public const int INTERNALUSETaxYTDTracking = 152;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 153;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 170;

            /// <summary>
            /// Property Indexer for AutomaticallyUpdateLocalTax
            /// </summary>
            public const int AutomaticallyUpdateLocalTax = 171;

            /// <summary>
            /// Property Indexer for State
            /// </summary>
            public const int State = 172;

            /// <summary>
            /// Property Indexer for LocalTaxCode
            /// </summary>
            public const int LocalTaxCode = 173;

            /// <summary>
            /// Property Indexer for RESERVEDAatrixTaxType
            /// </summary>
            public const int RESERVEDAatrixTaxType = 174;

            /// <summary>
            /// Property Indexer for AutomaticallyPopulateEmployee
            /// </summary>
            public const int AutomaticallyPopulateEmployee = 175;

            /// <summary>
            /// Property Indexer for DefaultDistributionCode
            /// </summary>
            public const int DefaultDistributionCode = 176;


        }

        #endregion

    }
}
