// Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of WorkClassificationCodes Constants
    /// </summary>
    public partial class WorkClassificationCodes
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0027";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of WorkClassificationCodes Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for WorkClassificationCode
            /// </summary>
            public const string WorkClassificationCode = "WORKCODE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "WORKDESC";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "LASTMAINT";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of WorkClassificationCodes Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for WorkClassificationCode
            /// </summary>
            public const int WorkClassificationCode = 1;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 3;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 4;


        }

        #endregion

    }
}