// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeTaxe Constants
    /// </summary>
    public partial class EmployeeTaxe
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0010";


        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeTaxe Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for TaxCode
            /// </summary>
            public const string TaxCode = "TAXID";

            /// <summary>
            /// Property for ExtraWithholding
            /// </summary>
            public const string ExtraWithholding = "EXTRAWH";

            /// <summary>
            /// Property for WithholdingMethod
            /// </summary>
            public const string WithholdingMethod = "CALCMTHD";

            /// <summary>
            /// Property for AmountPercentOverride
            /// </summary>
            public const string AmountPercentOverride = "OVERRATE";

            /// <summary>
            /// Property for DistributionCode
            /// </summary>
            public const string DistributionCode = "DISTCODE";

            /// <summary>
            /// Property for INTERNALUSEOccasionalTax
            /// </summary>
            public const string INTERNALUSEOccasionalTax = "OCCASIONAL";

            /// <summary>
            /// Property for INTERNALUSETaxTableEffecti
            /// </summary>
            public const string INTERNALUSETaxTableEffecti = "EFFECTDATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EMPPARMVER
            /// </summary>
            public const string EMPPARMVER = "EMPPARMVER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EMPPARMCNT
            /// </summary>
            public const string EMPPARMCNT = "EMPPARMCNT";

            /// <summary>
            /// Property for INTERNALUSECategory
            /// </summary>
            public const string INTERNALUSECategory = "CATEGORY";

            /// <summary>
            /// Property for INTERNALUSETaxType
            /// </summary>
            public const string INTERNALUSETaxType = "TAXTYPE";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for INTERNALUSETemplate
            /// </summary>
            public const string INTERNALUSETemplate = "TEMPLATE";

            /// <summary>
            /// Property for INTERNALUSEOperationCode
            /// </summary>
            public const string INTERNALUSEOperationCode = "OPCODE";

            /// <summary>
            /// Property for TaxDescription
            /// </summary>
            public const string TaxDescription = "DESC";

            /// <summary>
            /// Property for Message
            /// </summary>
            public string Message { get; set; }

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeTaxe Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for TaxCode
            /// </summary>
            public const int TaxCode = 2;

            /// <summary>
            /// Property Indexer for ExtraWithholding
            /// </summary>
            public const int ExtraWithholding = 3;

            /// <summary>
            /// Property Indexer for WithholdingMethod
            /// </summary>
            public const int WithholdingMethod = 4;

            /// <summary>
            /// Property Indexer for AmountPercentOverride
            /// </summary>
            public const int AmountPercentOverride = 5;

            /// <summary>
            /// Property Indexer for DistributionCode
            /// </summary>
            public const int DistributionCode = 6;

            /// <summary>
            /// Property Indexer for INTERNALUSEOccasionalTax
            /// </summary>
            public const int INTERNALUSEOccasionalTax = 7;

            /// <summary>
            /// Property Indexer for INTERNALUSETaxTableEffecti
            /// </summary>
            public const int INTERNALUSETaxTableEffecti = 8;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EMPPARMVER
            /// </summary>
            public const int EMPPARMVER = 9;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EMPPARMCNT
            /// </summary>
            public const int EMPPARMCNT = 10;

            /// <summary>
            /// Property Indexer for INTERNALUSECategory
            /// </summary>
            public const int INTERNALUSECategory = 12;

            /// <summary>
            /// Property Indexer for INTERNALUSETaxType
            /// </summary>
            public const int INTERNALUSETaxType = 13;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 14;

            /// <summary>
            /// Property Indexer for INTERNALUSETemplate
            /// </summary>
            public const int INTERNALUSETemplate = 50;

            /// <summary>
            /// Property Indexer for INTERNALUSEOperationCode
            /// </summary>
            public const int INTERNALUSEOperationCode = 51;

            /// <summary>
            /// Property Indexer for TaxDescription
            /// </summary>
            public const int TaxDescription = 52;


        }

        #endregion

    }
}
