// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of CompanyOption Constants
    /// </summary>
    public partial class CompanyOption
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0023";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"TCARDTIME", "TimecardFractionalHours"},
                    {"GLSEG1", "GLSegmentOne"},
                    {"GLSEG2", "GLSegmentTwo"},
                    {"GLSEG3", "GLSegmentThree"},
                    {"GLSEG4", "GLSegmentFour"},
                    {"GLSEG5", "GLSegmentFive"},
                    {"GLSEG6", "GLSegmentSix"},
                    {"PJCCOSTCTR", "PJCCostCenterOverride"},
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of CompanyOption Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for OptionRecordID
            /// </summary>
            public const string OptionRecordID = "PROPTID";

            /// <summary>
            /// Property for PayrollCountryCode
            /// </summary>
            public const string PayrollCountryCode = "CNTRYCODE";

            /// <summary>
            /// Property for ContactPersonsName
            /// </summary>
            public const string ContactPersonsName = "CONTACT";

            /// <summary>
            /// Property for ContactsPhoneNumber
            /// </summary>
            public const string ContactsPhoneNumber = "PHONENBR";

            /// <summary>
            /// Property for ContactsFaxNumber
            /// </summary>
            public const string ContactsFaxNumber = "FAXNBR";

            /// <summary>
            /// Property for PrintZeroNetChecks
            /// </summary>
            public const string PrintZeroNetChecks = "PRTNONETSW";

            /// <summary>
            /// Property for MinimumWage
            /// </summary>
            public const string MinimumWage = "MINWAGE";

            /// <summary>
            /// Property for MaximumAnnualPartTimeHours
            /// </summary>
            public const string MaximumAnnualPartTimeHours = "MAXPTHRS";

            /// <summary>
            /// Property for YearsOfHistoryToKeep
            /// </summary>
            public const string YearsOfHistoryToKeep = "YEARSHIST";

            /// <summary>
            /// Property for ExceptionForIncreasePercent
            /// </summary>
            public const string ExceptionForIncreasePercent = "EXCPTPCT";

            /// <summary>
            /// Property for ExceptionForDollarIncrease
            /// </summary>
            public const string ExceptionForDollarIncrease = "EXCPTDLR";

            /// <summary>
            /// Property for NumberOfDecimalPlacesForHou
            /// </summary>
            public const string NumberOfDecimalPlacesForHou = "HRLYRTEDEC";

            /// <summary>
            /// Property for TimecardFractionalHours
            /// </summary>
            public const string TimecardFractionalHours = "TCARDTIME";

            /// <summary>
            /// Property for HoursPerPayFrequencyInDaily
            /// </summary>
            public const string HoursPerPayFrequencyInDaily = "DAILYHRS";

            /// <summary>
            /// Property for HoursPerPayFrequencyInWeekl
            /// </summary>
            public const string HoursPerPayFrequencyInWeekl = "WEEKLYHRS";

            /// <summary>
            /// Property for HoursPerPayFrequencyInBiwee
            /// </summary>
            public const string HoursPerPayFrequencyInBiwee = "BIWKLYHRS";

            /// <summary>
            /// Property for HoursPerPayFrequencyInSemim
            /// </summary>
            public const string HoursPerPayFrequencyInSemim = "SEMIMONHRS";

            /// <summary>
            /// Property for HoursPerPayFrequencyInMonth
            /// </summary>
            public const string HoursPerPayFrequencyInMonth = "MONTHLYHRS";

            /// <summary>
            /// Property for HoursPerPayFrequencyInQuart
            /// </summary>
            public const string HoursPerPayFrequencyInQuart = "QRTRLYHRS";

            /// <summary>
            /// Property for HoursPerPayFrequencyIn10Pe
            /// </summary>
            public const string HoursPerPayFrequencyIn10Pe = "PP10PYHRS";

            /// <summary>
            /// Property for HoursPerPayFrequencyIn13Pe
            /// </summary>
            public const string HoursPerPayFrequencyIn13Pe = "PP13PYHRS";

            /// <summary>
            /// Property for HoursPerPayFrequencyIn22Pe
            /// </summary>
            public const string HoursPerPayFrequencyIn22Pe = "PP22PYHRS";

            /// <summary>
            /// Property for DailyPayPeriodsPerYear
            /// </summary>
            public const string DailyPayPeriodsPerYear = "DAILYPPPY";

            /// <summary>
            /// Property for WeeklyPayPeriodsPerYear
            /// </summary>
            public const string WeeklyPayPeriodsPerYear = "WEEKLYPPPY";

            /// <summary>
            /// Property for BiweeklyPayPeriodsPerYear
            /// </summary>
            public const string BiweeklyPayPeriodsPerYear = "BIWKLYPPPY";

            /// <summary>
            /// Property for CreateGLTransOrNot
            /// </summary>
            public const string CreateGLTransOrNot = "GLONLINESW";

            /// <summary>
            /// Property for GLTransAppendToBatch
            /// </summary>
            public const string GLTransAppendToBatch = "APPENDGLSW";

            /// <summary>
            /// Property for GLBatchType
            /// </summary>
            public const string GLBatchType = "GLBTCHTYPE";

            /// <summary>
            /// Property for CheckOrPeriodEndDate
            /// </summary>
            public const string CheckOrPeriodEndDate = "POSTDATCOD";

            /// <summary>
            /// Property for SalaryAndWagesPayableAccount
            /// </summary>
            public const string SalaryAndWagesPayableAccount = "SALPAYACCT";

            /// <summary>
            /// Property for SuspenseAccount
            /// </summary>
            public const string SuspenseAccount = "SUSPACCT";

            /// <summary>
            /// Property for CostCenterSwitch
            /// </summary>
            public const string CostCenterSwitch = "COSTCTRSW";

            /// <summary>
            /// Property for GLSegmentOne
            /// </summary>
            public const string GLSegmentOne = "GLSEG1";

            /// <summary>
            /// Property for GLSegmentTwo
            /// </summary>
            public const string GLSegmentTwo = "GLSEG2";

            /// <summary>
            /// Property for GLSegmentThree
            /// </summary>
            public const string GLSegmentThree = "GLSEG3";

            /// <summary>
            /// Property for ActiveSegmentReplaceOption
            /// </summary>
            public const string ActiveSegmentReplaceOption = "GLSEGREPOP";

            /// <summary>
            /// Property for GLSegmentFour
            /// </summary>
            public const string GLSegmentFour = "GLSEG4";

            /// <summary>
            /// Property for GLSegmentFive
            /// </summary>
            public const string GLSegmentFive = "GLSEG5";

            /// <summary>
            /// Property for GLSegmentSix
            /// </summary>
            public const string GLSegmentSix = "GLSEG6";

            /// <summary>
            /// Property for GLSEG1CALC
            /// </summary>
            public const string GLSEG1CALC = "GLSEG1CALC";

            /// <summary>
            /// Property for GLSEG2CALC
            /// </summary>
            public const string GLSEG2CALC = "GLSEG2CALC";

            /// <summary>
            /// Property for GLSEG3CALC
            /// </summary>
            public const string GLSEG3CALC = "GLSEG3CALC";

            /// <summary>
            /// Property for GLSEG4CALC
            /// </summary>
            public const string GLSEG4CALC = "GLSEG4CALC";

            /// <summary>
            /// Property for GLSEG5CALC
            /// </summary>
            public const string GLSEG5CALC = "GLSEG5CALC";

            /// <summary>
            /// Property for GLSEG6CALC
            /// </summary>
            public const string GLSEG6CALC = "GLSEG6CALC";

            /// <summary>
            /// Property for ActiveEmployees
            /// </summary>
            public const string ActiveEmployees = "ACTIVEEMPS";

            /// <summary>
            /// Property for DefaultBank
            /// </summary>
            public const string DefaultBank = "DEFBANK";

            /// <summary>
            /// Property for DefaultMCCheckStockCode
            /// </summary>
            public const string DefaultMCCheckStockCode = "DEFFORM";

            /// <summary>
            /// Property for PayrollCurrency
            /// </summary>
            public const string PayrollCurrency = "PRCURR";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for ExchangeRoundingDifferenceAcc
            /// </summary>
            public const string ExchangeRoundingDifferenceAcc = "EXDIFFACCT";

            /// <summary>
            /// Property for UseOriginalDatesWhenReversin
            /// </summary>
            public const string UseOriginalDatesWhenReversin = "ORGDTRVSE";

            /// <summary>
            /// Property for PJCCostCenterOverride
            /// </summary>
            public const string PJCCostCenterOverride = "PJCCOSTCTR";

            /// <summary>
            /// Property for PrintMaskedSSN
            /// </summary>
            public const string PrintMaskedSSN = "PRINTSIN";

            /// <summary>
            /// Property for EmployeeLevelSecurityFlag
            /// </summary>
            public const string EmployeeLevelSecurityFlag = "EMPLSEC";

            /// <summary>
            /// Property for TaxNumber
            /// </summary>
            public const string TaxNumber = "TAXNUMBER";

            /// <summary>
            /// Property for WCStartDate
            /// </summary>
            public const string WCStartDate = "WCSTART";

            /// <summary>
            /// Property for EstablishmentNumber
            /// </summary>
            public const string EstablishmentNumber = "EEOESTNUM";

            /// <summary>
            /// Property for NAICSCode
            /// </summary>
            public const string NAICSCode = "EEONAICS";

            /// <summary>
            /// Property for DefaultNumberOfDaysForFollo
            /// </summary>
            public const string DefaultNumberOfDaysForFollo = "FLUPDAYS";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of CompanyOption Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for OptionRecordID
            /// </summary>
            public const int OptionRecordID = 1;

            /// <summary>
            /// Property Indexer for PayrollCountryCode
            /// </summary>
            public const int PayrollCountryCode = 2;

            /// <summary>
            /// Property Indexer for ContactPersonsName
            /// </summary>
            public const int ContactPersonsName = 3;

            /// <summary>
            /// Property Indexer for ContactsPhoneNumber
            /// </summary>
            public const int ContactsPhoneNumber = 4;

            /// <summary>
            /// Property Indexer for ContactsFaxNumber
            /// </summary>
            public const int ContactsFaxNumber = 5;

            /// <summary>
            /// Property Indexer for PrintZeroNetChecks
            /// </summary>
            public const int PrintZeroNetChecks = 6;

            /// <summary>
            /// Property Indexer for MinimumWage
            /// </summary>
            public const int MinimumWage = 7;

            /// <summary>
            /// Property Indexer for MaximumAnnualPartTimeHours
            /// </summary>
            public const int MaximumAnnualPartTimeHours = 8;

            /// <summary>
            /// Property Indexer for YearsOfHistoryToKeep
            /// </summary>
            public const int YearsOfHistoryToKeep = 9;

            /// <summary>
            /// Property Indexer for ExceptionForIncreasePercent
            /// </summary>
            public const int ExceptionForIncreasePercent = 10;

            /// <summary>
            /// Property Indexer for ExceptionForDollarIncrease
            /// </summary>
            public const int ExceptionForDollarIncrease = 11;

            /// <summary>
            /// Property Indexer for NumberOfDecimalPlacesForHou
            /// </summary>
            public const int NumberOfDecimalPlacesForHou = 12;

            /// <summary>
            /// Property Indexer for TimecardFractionalHours
            /// </summary>
            public const int TimecardFractionalHours = 13;

            /// <summary>
            /// Property Indexer for HoursPerPayFrequencyInDaily
            /// </summary>
            public const int HoursPerPayFrequencyInDaily = 14;

            /// <summary>
            /// Property Indexer for HoursPerPayFrequencyInWeekl
            /// </summary>
            public const int HoursPerPayFrequencyInWeekl = 15;

            /// <summary>
            /// Property Indexer for HoursPerPayFrequencyInBiwee
            /// </summary>
            public const int HoursPerPayFrequencyInBiwee = 16;

            /// <summary>
            /// Property Indexer for HoursPerPayFrequencyInSemim
            /// </summary>
            public const int HoursPerPayFrequencyInSemim = 17;

            /// <summary>
            /// Property Indexer for HoursPerPayFrequencyInMonth
            /// </summary>
            public const int HoursPerPayFrequencyInMonth = 18;

            /// <summary>
            /// Property Indexer for HoursPerPayFrequencyInQuart
            /// </summary>
            public const int HoursPerPayFrequencyInQuart = 19;

            /// <summary>
            /// Property Indexer for HoursPerPayFrequencyIn10Pe
            /// </summary>
            public const int HoursPerPayFrequencyIn10Pe = 20;

            /// <summary>
            /// Property Indexer for HoursPerPayFrequencyIn13Pe
            /// </summary>
            public const int HoursPerPayFrequencyIn13Pe = 21;

            /// <summary>
            /// Property Indexer for HoursPerPayFrequencyIn22Pe
            /// </summary>
            public const int HoursPerPayFrequencyIn22Pe = 22;

            /// <summary>
            /// Property Indexer for DailyPayPeriodsPerYear
            /// </summary>
            public const int DailyPayPeriodsPerYear = 23;

            /// <summary>
            /// Property Indexer for WeeklyPayPeriodsPerYear
            /// </summary>
            public const int WeeklyPayPeriodsPerYear = 24;

            /// <summary>
            /// Property Indexer for BiweeklyPayPeriodsPerYear
            /// </summary>
            public const int BiweeklyPayPeriodsPerYear = 25;

            /// <summary>
            /// Property Indexer for CreateGLTransOrNot
            /// </summary>
            public const int CreateGLTransOrNot = 26;

            /// <summary>
            /// Property Indexer for GLTransAppendToBatch
            /// </summary>
            public const int GLTransAppendToBatch = 27;

            /// <summary>
            /// Property Indexer for GLBatchType
            /// </summary>
            public const int GLBatchType = 28;

            /// <summary>
            /// Property Indexer for CheckOrPeriodEndDate
            /// </summary>
            public const int CheckOrPeriodEndDate = 29;

            /// <summary>
            /// Property Indexer for SalaryAndWagesPayableAccount
            /// </summary>
            public const int SalaryAndWagesPayableAccount = 32;

            /// <summary>
            /// Property Indexer for SuspenseAccount
            /// </summary>
            public const int SuspenseAccount = 33;

            /// <summary>
            /// Property Indexer for CostCenterSwitch
            /// </summary>
            public const int CostCenterSwitch = 34;

            /// <summary>
            /// Property Indexer for GLSegmentOne
            /// </summary>
            public const int GLSegmentOne = 35;

            /// <summary>
            /// Property Indexer for GLSegmentTwo
            /// </summary>
            public const int GLSegmentTwo = 36;

            /// <summary>
            /// Property Indexer for GLSegmentThree
            /// </summary>
            public const int GLSegmentThree = 37;

            /// <summary>
            /// Property Indexer for ActiveSegmentReplaceOption
            /// </summary>
            public const int ActiveSegmentReplaceOption = 38;

            /// <summary>
            /// Property Indexer for GLSegmentFour
            /// </summary>
            public const int GLSegmentFour = 39;

            /// <summary>
            /// Property Indexer for GLSegmentFive
            /// </summary>
            public const int GLSegmentFive = 40;

            /// <summary>
            /// Property Indexer for GLSegmentSix
            /// </summary>
            public const int GLSegmentSix = 41;

            /// <summary>
            /// Property Indexer for GLSEG1CALC
            /// </summary>
            public const int GLSEG1CALC = 63;

            /// <summary>
            /// Property Indexer for GLSEG2CALC
            /// </summary>
            public const int GLSEG2CALC = 64;

            /// <summary>
            /// Property Indexer for GLSEG3CALC
            /// </summary>
            public const int GLSEG3CALC = 65;

            /// <summary>
            /// Property Indexer for GLSEG4CALC
            /// </summary>
            public const int GLSEG4CALC = 66;

            /// <summary>
            /// Property Indexer for GLSEG5CALC
            /// </summary>
            public const int GLSEG5CALC = 67;

            /// <summary>
            /// Property Indexer for GLSEG6CALC
            /// </summary>
            public const int GLSEG6CALC = 68;

            /// <summary>
            /// Property Indexer for ActiveEmployees
            /// </summary>
            public const int ActiveEmployees = 75;

            /// <summary>
            /// Property Indexer for DefaultBank
            /// </summary>
            public const int DefaultBank = 100;

            /// <summary>
            /// Property Indexer for DefaultMCCheckStockCode
            /// </summary>
            public const int DefaultMCCheckStockCode = 101;

            /// <summary>
            /// Property Indexer for PayrollCurrency
            /// </summary>
            public const int PayrollCurrency = 102;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 103;

            /// <summary>
            /// Property Indexer for ExchangeRoundingDifferenceAcc
            /// </summary>
            public const int ExchangeRoundingDifferenceAcc = 104;

            /// <summary>
            /// Property Indexer for UseOriginalDatesWhenReversin
            /// </summary>
            public const int UseOriginalDatesWhenReversin = 105;

            /// <summary>
            /// Property Indexer for PJCCostCenterOverride
            /// </summary>
            public const int PJCCostCenterOverride = 106;

            /// <summary>
            /// Property Indexer for PrintMaskedSSN
            /// </summary>
            public const int PrintMaskedSSN = 107;

            /// <summary>
            /// Property Indexer for EmployeeLevelSecurityFlag
            /// </summary>
            public const int EmployeeLevelSecurityFlag = 108;

            /// <summary>
            /// Property Indexer for TaxNumber
            /// </summary>
            public const int TaxNumber = 109;

            /// <summary>
            /// Property Indexer for WCStartDate
            /// </summary>
            public const int WCStartDate = 110;

            /// <summary>
            /// Property Indexer for EstablishmentNumber
            /// </summary>
            public const int EstablishmentNumber = 111;

            /// <summary>
            /// Property Indexer for NAICSCode
            /// </summary>
            public const int NAICSCode = 112;

            /// <summary>
            /// Property Indexer for DefaultNumberOfDaysForFollo
            /// </summary>
            public const int DefaultNumberOfDaysForFollo = 113;


        }

        #endregion

    }
}