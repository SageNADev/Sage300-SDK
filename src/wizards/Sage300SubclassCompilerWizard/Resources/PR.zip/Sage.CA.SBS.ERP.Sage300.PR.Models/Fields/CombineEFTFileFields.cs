// Copyright (c) 1994-2025 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of CombineEFTFile Constants
    /// </summary>
    public partial class CombineEFTFile
    {
        /// <summary>
        /// Entity Name with prefix added later
        /// </summary>
        public const string EntityName = "~~0211";

        #region Fields Properties

        /// <summary>
        /// Contains list of CombineEFTFile Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for CompanyEFTBank
            /// </summary>
            public const string CompanyEFTBank = "BANKID";

            /// <summary>
            /// Property for BankName
            /// </summary>
            public const string BankName = "BANKNAME";

            /// <summary>
            /// Property for FileCreationFromDate
            /// </summary>
            public const string FileCreationFromDate = "DATEFROM";

            /// <summary>
            /// Property for FileCreationToDate
            /// </summary>
            public const string FileCreationToDate = "DATETO";

            /// <summary>
            /// Property for UnprocessedFilesOnly
            /// </summary>
            public const string UnprocessedFilesOnly = "UNUSED";

            /// <summary>
            /// Property for FileCreationNumber
            /// </summary>
            public const string FileCreationNumber = "MERGENUM";

            /// <summary>
            /// Property for FileCreationDescription
            /// </summary>
            public const string FileCreationDescription = "MERGEDESC";

            /// <summary>
            /// Property for FileCreationDate
            /// </summary>
            public const string FileCreationDate = "MERGEDATE";

            /// <summary>
            /// Property for FileExtension
            /// </summary>
            public const string FileExtension = "MERGEEXT";

            /// <summary>
            /// Property for FileName
            /// </summary>
            public const string FileName = "FILENAME";

            /// <summary>
            /// Property for LocalFilePath
            /// </summary>
            public const string LocalFilePath = "MERGEPATH";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for CombineRunSequence
            /// </summary>
            public const string CombineRunSequence = "COMBRUNSEQ";

            //Report parameters

            public const string FromSequence = "FROMSEQ";

            public const string ToSequence = "TOSEQ";

            public const string FromNumber = "FROMNUMBER";

            public const string ToNumber = "TONUMBER";

            public const string FromDate = "FROMDATE";

            public const string ToDate = "TODATE";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of CombineEFTFile Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for CompanyEFTBank
            /// </summary>
            public const int CompanyEFTBank = 1;

            /// <summary>
            /// Property Indexer for BankName
            /// </summary>
            public const int BankName = 2;

            /// <summary>
            /// Property Indexer for FileCreationFromDate
            /// </summary>
            public const int FileCreationFromDate = 3;

            /// <summary>
            /// Property Indexer for FileCreationToDate
            /// </summary>
            public const int FileCreationToDate = 4;

            /// <summary>
            /// Property Indexer for UnprocessedFilesOnly
            /// </summary>
            public const int UnprocessedFilesOnly = 5;

            /// <summary>
            /// Property Indexer for FileCreationNumber
            /// </summary>
            public const int FileCreationNumber = 6;

            /// <summary>
            /// Property Indexer for FileCreationDescription
            /// </summary>
            public const int FileCreationDescription = 7;

            /// <summary>
            /// Property Indexer for FileCreationDate
            /// </summary>
            public const int FileCreationDate = 8;

            /// <summary>
            /// Property Indexer for FileExtension
            /// </summary>
            public const int FileExtension = 9;

            /// <summary>
            /// Property Indexer for FileName
            /// </summary>
            public const int FileName = 10;

            /// <summary>
            /// Property Indexer for LocalFilePath
            /// </summary>
            public const int LocalFilePath = 11;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 12;

            /// <summary>
            /// Property Indexer for CombineRunSequence
            /// </summary>
            public const int CombineRunSequence = 13;

        }
        #endregion
    }
}