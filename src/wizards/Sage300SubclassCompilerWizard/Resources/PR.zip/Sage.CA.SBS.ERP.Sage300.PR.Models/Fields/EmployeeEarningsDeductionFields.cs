// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeEarningsDeduction Constants
    /// </summary>
    public partial class EmployeeEarningsDeduction
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0008";


        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeEarningsDeduction Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for EmployeeEarningDeduction
            /// </summary>
            public const string EmployeeEarningDeduction = "EARNDED";

            /// <summary>
            /// Property for Calculate
            /// </summary>
            public const string Calculate = "CALCULATE";

            /// <summary>
            /// Property for StartDate
            /// </summary>
            public const string StartDate = "STARTS";

            /// <summary>
            /// Property for EndDate
            /// </summary>
            public const string EndDate = "ENDS";

            /// <summary>
            /// Property for SegmentName1
            /// </summary>
            public const string SegmentName1 = "GLSEG1";

            /// <summary>
            /// Property for SegmentName2
            /// </summary>
            public const string SegmentName2 = "GLSEG2";

            /// <summary>
            /// Property for SegmentName3
            /// </summary>
            public const string SegmentName3 = "GLSEG3";

            /// <summary>
            /// Property for DistributionCode
            /// </summary>
            public const string DistributionCode = "DISTCODE";

            /// <summary>
            /// Property for EmployeeRateAmtPct
            /// </summary>
            public const string EmployeeRateAmtPct = "ERATE";

            /// <summary>
            /// Property for EmployerAmtPct
            /// </summary>
            public const string EmployerAmtPct = "RRATE";

            /// <summary>
            /// Property for WorkersCompensationCode
            /// </summary>
            public const string WorkersCompensationCode = "WCC";

            /// <summary>
            /// Property for AdvanceToBeRepaid
            /// </summary>
            public const string AdvanceToBeRepaid = "REPAYID";

            /// <summary>
            /// Property for Carryover
            /// </summary>
            public const string Carryover = "CARRYDATE";

            /// <summary>
            /// Property for Balance
            /// </summary>
            public const string Balance = "BALANCE";

            /// <summary>
            /// Property for Accrued
            /// </summary>
            public const string Accrued = "ACCRUED";

            /// <summary>
            /// Property for Paid
            /// </summary>
            public const string Paid = "PAID";

            /// <summary>
            /// Property for DefaultHours
            /// </summary>
            public const string DefaultHours = "DEFAULTHRS";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            ///// <summary>
            ///// Property for Type
            ///// </summary>
            //public const string EarDedType = "EARDEDTYPE";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string EarningDeductionTaxType = "EARDEDTYPE";

            /// <summary>
            /// Property for AmountPaid
            /// </summary>
            public const string AmountPaid = "AMTPAID";

            /// <summary>
            /// Property for AvailableInEmployeeTimecards
            /// </summary>
            public const string AvailableInEmployeeTimecards = "USERTC";

            /// <summary>
            /// Property for WorkersCompGroup
            /// </summary>
            public const string WorkersCompGroup = "WCCGROUP";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for IncludeInFLSAOvertimeCalc
            /// </summary>
            public const string IncludeInFLSAOvertimeCalc = "SWFLSA";

            /// <summary>
            /// Property for EmployeePeriodMinimum
            /// </summary>
            public const string EmployeePeriodMinimum = "EPERIODMIN";

            /// <summary>
            /// Property for EmployeePeriodMaximum
            /// </summary>
            public const string EmployeePeriodMaximum = "EPERIODMAX";

            /// <summary>
            /// Property for EmployeeAnnualMaximum
            /// </summary>
            public const string EmployeeAnnualMaximum = "EANNUALMAX";

            /// <summary>
            /// Property for EmployeeLifetimeMaximum
            /// </summary>
            public const string EmployeeLifetimeMaximum = "ELIFETMMAX";

            /// <summary>
            /// Property for EmployeeLifetimeAccumulation
            /// </summary>
            public const string EmployeeLifetimeAccumulation = "ELTDAMT";

            /// <summary>
            /// Property for EmployeeSecondaryRateAmtPct
            /// </summary>
            public const string EmployeeSecondaryRateAmtPct = "E2NDRATE";

            /// <summary>
            /// Property for EmployerPeriodMinimum
            /// </summary>
            public const string EmployerPeriodMinimum = "RPERIODMIN";

            /// <summary>
            /// Property for EmployerPeriodMaximum
            /// </summary>
            public const string EmployerPeriodMaximum = "RPERIODMAX";

            /// <summary>
            /// Property for EmployerAnnualMaximum
            /// </summary>
            public const string EmployerAnnualMaximum = "RANNUALMAX";

            /// <summary>
            /// Property for EmployerLifetimeMaximum
            /// </summary>
            public const string EmployerLifetimeMaximum = "RLIFETMMAX";

            /// <summary>
            /// Property for EmployerLifetimeAccumulation
            /// </summary>
            public const string EmployerLifetimeAccumulation = "RLTDAMT";

            /// <summary>
            /// Property for EmployerSecondaryAmtPct
            /// </summary>
            public const string EmployerSecondaryAmtPct = "R2NDRATE";

            /// <summary>
            /// Property for TemplateEmployee
            /// </summary>
            public const string TemplateEmployee = "TEMPLATE";

            /// <summary>
            /// Property for EmployeeCalcMethod
            /// </summary>
            public const string EmployeeCalcMethod = "ECALCMETH";

            /// <summary>
            /// Property for EmployerCalcMethod
            /// </summary>
            public const string EmployerCalcMethod = "RCALCMETH";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for EarningDeductionDescription
            /// </summary>
            public const string EarningDeductionDescription = "DESC";

            /// <summary>
            /// Property for EmployeeBaseLimit
            /// </summary>
            public const string EmployeeBaseLimit = "ELIMITBASE";

            /// <summary>
            /// Property for EmployerBaseLimit
            /// </summary>
            public const string EmployerBaseLimit = "RLIMITBASE";

            /// <summary>
            /// Property for EmployeeSecondaryRateEffectiv
            /// </summary>
            public const string EmployeeSecondaryRateEffectiv = "E2NDRATEIN";

            /// <summary>
            /// Property for EmployerSecondaryRateEffectiv
            /// </summary>
            public const string EmployerSecondaryRateEffectiv = "R2NDRATEIN";

            /// <summary>
            /// Property for BillingRates
            /// </summary>
            public const string BillingRates = "BILLINGS";

            /// <summary>
            /// Property for BillingPercentage1
            /// </summary>
            public const string BillingPercentage1 = "BILLPCT1";

            /// <summary>
            /// Property for BillingPercentage2
            /// </summary>
            public const string BillingPercentage2 = "BILLPCT2";

            /// <summary>
            /// Property for BillingPercentage3
            /// </summary>
            public const string BillingPercentage3 = "BILLPCT3";

            /// <summary>
            /// Property for BillingPercentage4
            /// </summary>
            public const string BillingPercentage4 = "BILLPCT4";

            /// <summary>
            /// Property for BillingPercentage5
            /// </summary>
            public const string BillingPercentage5 = "BILLPCT5";

            /// <summary>
            /// Property for BillingPercentage6
            /// </summary>
            public const string BillingPercentage6 = "BILLPCT6";

            /// <summary>
            /// Property for JobsAllocBasedOnCalcBase
            /// </summary>
            public const string JobsAllocBasedOnCalcBase = "SWALLOCJOB";

            /// <summary>
            /// Property for RESERVEDSegmentName4
            /// </summary>
            public const string RESERVEDSegmentName4 = "GLSEG4";

            /// <summary>
            /// Property for RESERVEDSegmentName5
            /// </summary>
            public const string RESERVEDSegmentName5 = "GLSEG5";

            /// <summary>
            /// Property for RESERVEDSegmentName6
            /// </summary>
            public const string RESERVEDSegmentName6 = "GLSEG6";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeEarningsDeduction Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for EmployeeEarningDeduction
            /// </summary>
            public const int EmployeeEarningDeduction = 2;

            /// <summary>
            /// Property Indexer for Calculate
            /// </summary>
            public const int Calculate = 3;

            /// <summary>
            /// Property Indexer for StartDate
            /// </summary>
            public const int StartDate = 4;

            /// <summary>
            /// Property Indexer for EndDate
            /// </summary>
            public const int EndDate = 5;

            /// <summary>
            /// Property Indexer for SegmentName1
            /// </summary>
            public const int SegmentName1 = 6;

            /// <summary>
            /// Property Indexer for SegmentName2
            /// </summary>
            public const int SegmentName2 = 7;

            /// <summary>
            /// Property Indexer for SegmentName3
            /// </summary>
            public const int SegmentName3 = 8;

            /// <summary>
            /// Property Indexer for DistributionCode
            /// </summary>
            public const int DistributionCode = 9;

            /// <summary>
            /// Property Indexer for EmployeeRateAmtPct
            /// </summary>
            public const int EmployeeRateAmtPct = 10;

            /// <summary>
            /// Property Indexer for EmployerAmtPct
            /// </summary>
            public const int EmployerAmtPct = 11;

            /// <summary>
            /// Property Indexer for WorkersCompensationCode
            /// </summary>
            public const int WorkersCompensationCode = 12;

            /// <summary>
            /// Property Indexer for AdvanceToBeRepaid
            /// </summary>
            public const int AdvanceToBeRepaid = 13;

            /// <summary>
            /// Property Indexer for Carryover
            /// </summary>
            public const int Carryover = 14;

            /// <summary>
            /// Property Indexer for Balance
            /// </summary>
            public const int Balance = 15;

            /// <summary>
            /// Property Indexer for Accrued
            /// </summary>
            public const int Accrued = 16;

            /// <summary>
            /// Property Indexer for Paid
            /// </summary>
            public const int Paid = 17;

            /// <summary>
            /// Property Indexer for DefaultHours
            /// </summary>
            public const int DefaultHours = 18;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 20;

            ///// <summary>
            ///// Property Indexer for EarDedType
            ///// </summary>
            //public const int EarDedType = 21;

            /// <summary>
            /// Property Indexer for EarDedType
            /// </summary>
            public const int EarningDeductionTaxType = 21;
            
            /// <summary>
            /// Property Indexer for AmountPaid
            /// </summary>
            public const int AmountPaid = 22;

            /// <summary>
            /// Property Indexer for AvailableInEmployeeTimecards
            /// </summary>
            public const int AvailableInEmployeeTimecards = 23;

            /// <summary>
            /// Property Indexer for WorkersCompGroup
            /// </summary>
            public const int WorkersCompGroup = 24;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 25;

            /// <summary>
            /// Property Indexer for IncludeInFLSAOvertimeCalc
            /// </summary>
            public const int IncludeInFLSAOvertimeCalc = 26;

            /// <summary>
            /// Property Indexer for EmployeePeriodMinimum
            /// </summary>
            public const int EmployeePeriodMinimum = 27;

            /// <summary>
            /// Property Indexer for EmployeePeriodMaximum
            /// </summary>
            public const int EmployeePeriodMaximum = 28;

            /// <summary>
            /// Property Indexer for EmployeeAnnualMaximum
            /// </summary>
            public const int EmployeeAnnualMaximum = 29;

            /// <summary>
            /// Property Indexer for EmployeeLifetimeMaximum
            /// </summary>
            public const int EmployeeLifetimeMaximum = 30;

            /// <summary>
            /// Property Indexer for EmployeeLifetimeAccumulation
            /// </summary>
            public const int EmployeeLifetimeAccumulation = 31;

            /// <summary>
            /// Property Indexer for EmployeeSecondaryRateAmtPct
            /// </summary>
            public const int EmployeeSecondaryRateAmtPct = 32;

            /// <summary>
            /// Property Indexer for EmployerPeriodMinimum
            /// </summary>
            public const int EmployerPeriodMinimum = 33;

            /// <summary>
            /// Property Indexer for EmployerPeriodMaximum
            /// </summary>
            public const int EmployerPeriodMaximum = 34;

            /// <summary>
            /// Property Indexer for EmployerAnnualMaximum
            /// </summary>
            public const int EmployerAnnualMaximum = 35;

            /// <summary>
            /// Property Indexer for EmployerLifetimeMaximum
            /// </summary>
            public const int EmployerLifetimeMaximum = 36;

            /// <summary>
            /// Property Indexer for EmployerLifetimeAccumulation
            /// </summary>
            public const int EmployerLifetimeAccumulation = 37;

            /// <summary>
            /// Property Indexer for EmployerSecondaryAmtPct
            /// </summary>
            public const int EmployerSecondaryAmtPct = 38;

            /// <summary>
            /// Property Indexer for TemplateEmployee
            /// </summary>
            public const int TemplateEmployee = 41;

            /// <summary>
            /// Property Indexer for EmployeeCalcMethod
            /// </summary>
            public const int EmployeeCalcMethod = 42;

            /// <summary>
            /// Property Indexer for EmployerCalcMethod
            /// </summary>
            public const int EmployerCalcMethod = 43;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 44;

            /// <summary>
            /// Property Indexer for EarningDeductionDescription
            /// </summary>
            public const int EarningDeductionDescription = 45;

            /// <summary>
            /// Property Indexer for EmployeeBaseLimit
            /// </summary>
            public const int EmployeeBaseLimit = 46;

            /// <summary>
            /// Property Indexer for EmployerBaseLimit
            /// </summary>
            public const int EmployerBaseLimit = 47;

            /// <summary>
            /// Property Indexer for EmployeeSecondaryRateEffectiv
            /// </summary>
            public const int EmployeeSecondaryRateEffectiv = 48;

            /// <summary>
            /// Property Indexer for EmployerSecondaryRateEffectiv
            /// </summary>
            public const int EmployerSecondaryRateEffectiv = 49;

            /// <summary>
            /// Property Indexer for BillingRates
            /// </summary>
            public const int BillingRates = 60;

            /// <summary>
            /// Property Indexer for BillingPercentage1
            /// </summary>
            public const int BillingPercentage1 = 61;

            /// <summary>
            /// Property Indexer for BillingPercentage2
            /// </summary>
            public const int BillingPercentage2 = 62;

            /// <summary>
            /// Property Indexer for BillingPercentage3
            /// </summary>
            public const int BillingPercentage3 = 63;

            /// <summary>
            /// Property Indexer for BillingPercentage4
            /// </summary>
            public const int BillingPercentage4 = 64;

            /// <summary>
            /// Property Indexer for BillingPercentage5
            /// </summary>
            public const int BillingPercentage5 = 65;

            /// <summary>
            /// Property Indexer for BillingPercentage6
            /// </summary>
            public const int BillingPercentage6 = 66;

            /// <summary>
            /// Property Indexer for JobsAllocBasedOnCalcBase
            /// </summary>
            public const int JobsAllocBasedOnCalcBase = 67;

            /// <summary>
            /// Property Indexer for RESERVEDSegmentName4
            /// </summary>
            public const int RESERVEDSegmentName4 = 68;

            /// <summary>
            /// Property Indexer for RESERVEDSegmentName5
            /// </summary>
            public const int RESERVEDSegmentName5 = 69;

            /// <summary>
            /// Property Indexer for RESERVEDSegmentName6
            /// </summary>
            public const int RESERVEDSegmentName6 = 70;


        }

        #endregion

    }
}
