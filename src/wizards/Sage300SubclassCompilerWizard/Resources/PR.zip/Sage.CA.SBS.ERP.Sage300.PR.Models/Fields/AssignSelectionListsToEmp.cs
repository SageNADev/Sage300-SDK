namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of AssignSelectionListsToEmp Constants
    /// </summary>
    public partial class AssignSelectionListsToEmp
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0046";

        #region Fields Properties

        /// <summary>
        /// Contains list of AssignSelectionListsToEmp Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for EmployeeList
            /// </summary>
            public const string EmployeeList = "EMPLISTID";

            /// <summary>
            /// Property for From Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";
           
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of AssignSelectionListsToEmp Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property for EmployeeList
            /// </summary>
            public const int EmployeeList = 1;

            /// <summary>
            /// Property for EMPLOYEE
            /// </summary>
            public const int Employee = 2;
          
        }
        #endregion
    }
}
