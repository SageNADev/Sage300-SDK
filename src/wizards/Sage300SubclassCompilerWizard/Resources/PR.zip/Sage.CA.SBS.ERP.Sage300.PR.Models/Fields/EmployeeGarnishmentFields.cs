// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeGarnishment Constants
    /// </summary>
    public partial class EmployeeGarnishment
    {
        /// <summary>
        ///  Entity Name with prefix added later
        /// </summary>
        public const string EntityName = "~~0118";

        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeGarnishment Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for DeductionCode
            /// </summary>
            public const string DeductionCode = "DEDCODE";

            /// <summary>
            /// Property for DeductionsBlank
            /// (this is a misimplementation of the business view logic
            /// </summary>
            public const string DeductionsBlank = "DEDDESC";

            /// <summary>
            /// Property for EFTStatus
            /// </summary>
            public const string EFTStatus = "EFTSTATUS";

            /// <summary>
            /// Property for SDURoutingNumber
            /// </summary>
            public const string SDURoutingNumber = "INSTITUTID";

            /// <summary>
            /// Property for SDUAccountNumber
            /// </summary>
            public const string SDUAccountNumber = "ACCTNUM";

            /// <summary>
            /// Property for TranscationCode
            /// </summary>
            public const string TranscationCode = "TRANSCODE";

            /// <summary>
            /// Property for SDUName
            /// </summary>
            public const string SDUName = "TRNSFRNAME";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for DiscretionaryData
            /// </summary>
            public const string DiscretionaryData = "DISCREDATA";

            /// <summary>
            /// Property for CaseIdentifier
            /// </summary>
            public const string CaseIdentifier = "CASEID";

            /// <summary>
            /// Property for CaseState
            /// </summary>
            public const string CaseState = "CASESTATE";

            /// <summary>
            /// Property for CaseJurisdiction
            /// </summary>
            public const string CaseJurisdiction = "JURISDICTN";

            /// <summary>
            /// Property for FIPSCode
            /// </summary>
            public const string FIPSCode = "FIPSCODE";

            /// <summary>
            /// Property for CustodialParent
            /// </summary>
            public const string CustodialParent = "CUSTPARENT";

            /// <summary>
            /// Property for IsFamilyHealthInsuranceAvailable
            /// </summary>
            public const string IsFamilyHealthInsuranceAvailable = "MEDINSUAVL";

            /// <summary>
            /// Property for IsFamilyHealthInsuranceRequired
            /// </summary>
            public const string IsFamilyHealthInsuranceRequired = "MEDINSUREQ";

            /// <summary>
            /// Property for DateOfOrder
            /// </summary>
            public const string DateOfOrder = "ORDERDATE";

            /// <summary>
            /// Property for DeductionsDescription
            /// </summary>
            public const string DeductionsDescription = "ERNDEDDESC";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeGarnishment Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for DeductionCode
            /// </summary>
            public const int DeductionCode = 2;

            /// <summary>
            /// Property Indexer for DeductionsBlank
            /// </summary>
            public const int DeductionsBlank = 3;

            /// <summary>
            /// Property Indexer for EFTStatus
            /// </summary>
            public const int EFTStatus = 4;

            /// <summary>
            /// Property Indexer for SDURoutingNumber
            /// </summary>
            public const int SDURoutingNumber = 5;

            /// <summary>
            /// Property Indexer for SDUAccountNumber
            /// </summary>
            public const int SDUAccountNumber = 6;

            /// <summary>
            /// Property Indexer for TranscationCode
            /// </summary>
            public const int TranscationCode = 7;

            /// <summary>
            /// Property Indexer for SDUName
            /// </summary>
            public const int SDUName = 8;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 9;

            /// <summary>
            /// Property Indexer for DiscretionaryData
            /// </summary>
            public const int DiscretionaryData = 10;

            /// <summary>
            /// Property Indexer for CaseIdentifier
            /// </summary>
            public const int CaseIdentifier = 11;

            /// <summary>
            /// Property Indexer for CaseState
            /// </summary>
            public const int CaseState = 12;

            /// <summary>
            /// Property Indexer for CaseJurisdiction
            /// </summary>
            public const int CaseJurisdiction = 13;

            /// <summary>
            /// Property Indexer for FIPSCode
            /// </summary>
            public const int FIPSCode = 14;

            /// <summary>
            /// Property Indexer for CustodialParent
            /// </summary>
            public const int CustodialParent = 15;

            /// <summary>
            /// Property Indexer for IsFamilyHealthInsuranceAvailable
            /// </summary>
            public const int IsFamilyHealthInsuranceAvailable = 16;

            /// <summary>
            /// Property Indexer for IsFamilyHealthInsuranceRequired
            /// </summary>
            public const int IsFamilyHealthInsuranceRequired = 17;

            /// <summary>
            /// Property Indexer for DateOfOrder
            /// </summary>
            public const int DateOfOrder = 18;

            /// <summary>
            /// Property Indexer for DeductionsDescription
            /// </summary>
            public const int DeductionsDescription = 101;


        }

        #endregion

    }
}
