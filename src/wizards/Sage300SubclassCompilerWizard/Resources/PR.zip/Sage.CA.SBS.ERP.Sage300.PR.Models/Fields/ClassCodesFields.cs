// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of Class Codes Constants
    /// </summary>
    public partial class ClassCodesModel
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0006";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of Class Codes Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Class
            /// </summary>
            public const string Class = "CLASS";

            /// <summary>
            /// Property for ClassCode
            /// </summary>
            public const string ClassCode = "CLASSCODE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "CLASSDESC";

        }

        #endregion
        #region Index Properties

        /// <summary>
        /// Contains list of Class Codes Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Class
            /// </summary>
            public const int Class = 1;

            /// <summary>
            /// Property Indexer for ClassCode
            /// </summary>
            public const int ClassCode = 2;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 3;


        }

        #endregion

    }
}