namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of AssignAudit Constants
    /// </summary>
    public partial class AssignAudit
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0058";

        #region Fields Properties

        /// <summary>
        /// Contains list of AssignAudit Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for What to Globally Modify
            /// </summary>
            public const string WhatToChange = "WHAT2CHG";

            /// <summary>
            /// Property for Earn/Ded or Tax to Change
            /// </summary>
            public const string IdToChange = "ID2CHANGE";

            /// <summary>
            /// Property for Earn/Ded or Tax Name
            /// </summary>
            public const string IdName = "IDNAME";

            /// <summary>
            /// Property for Employee Selection Type
            /// </summary>
            public const string SelectionType = "SELTYPE";

            /// <summary>
            /// Property for Employee Browse Filter
            /// </summary>
            public const string EmployeeBrowseFilter = "EBROWSE";

            /// <summary>
            /// Property for Selection List
            /// </summary>
            public const string EmployeeListId = "EMPLISTID";

            /// <summary>
            /// Property for From Employee
            /// </summary>
            public const string FromEmployee = "FEMPLOYEE";

            /// <summary>
            /// Property for To Employee
            /// </summary>
            public const string ToEmployee = "TEMPLOYEE";

            /// <summary>
            /// Property for Class
            /// </summary>
            public const string Class = "CLASS";

            /// <summary>
            /// Property for From Class Code
            /// </summary>
            public const string FromClassCode = "FCLASSCOD";

            /// <summary>
            /// Property for To Class Code
            /// </summary>
            public const string ToClassCode = "TCLASSCOD";

            /// <summary>
            /// Property for Use Employee Defaults
            /// </summary>
            public const string UseEmployeeDefaults = "USEDEFAULT";

            /// <summary>
            /// Property for Employees Updated
            /// </summary>
            public const string EmployeesUpdated = "EMPUPDATED";

            /// <summary>
            /// Property for Process Command Code
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for Currency Code
            /// </summary>
            public const string CurrencyCode = "CURRCODE";

            /// <summary>
            /// Property for Currency Description
            /// </summary>
            public const string CurrencyDescription = "CURRDESC";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of AssignAudit Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property for What to Globally Modify
            /// </summary>
            public const int WhatToChange = 1;

            /// <summary>
            /// Property for Earn/Ded or Tax to Change
            /// </summary>
            public const int IdToChange = 2;

            /// <summary>
            /// Property for Earn/Ded or Tax Name
            /// </summary>
            public const int IdName = 3;

            /// <summary>
            /// Property for Employee Selection Type
            /// </summary>
            public const int EmployeeBrowseFilter = 4;

            /// <summary>
            /// Property for Employee Browse Filter
            /// </summary>
            public const int SelectionType = 5;

            /// <summary>
            /// Property for Selection List
            /// </summary>
            public const int EmployeeListId = 6;

            /// <summary>
            /// Property for From Employee
            /// </summary>
            public const int FromEmployee = 7;

            /// <summary>
            /// Property for To Employee
            /// </summary>
            public const int ToEmployee = 8;

            /// <summary>
            /// Property for Class
            /// </summary>
            public const int Class = 9;

            /// <summary>
            /// Property for From Class Code
            /// </summary>
            public const int FromClassCode = 10;

            /// <summary>
            /// Property for To Class Code
            /// </summary>
            public const int ToClassCode = 11;

            /// <summary>
            /// Property for Use Employee Defaults
            /// </summary>
            public const int UseEmployeeDefaults = 12;

            /// <summary>
            /// Property for Employees Updated
            /// </summary>
            public const int EmployeesUpdated = 13;

            /// <summary>
            /// Property for Process Command Code
            /// </summary>
            public const int ProcessCommandCode = 14;

            /// <summary>
            /// Property for Currency Code
            /// </summary>
            public const int CurrencyCode = 15;

            /// <summary>
            /// Property for Currency Description
            /// </summary>
            public const int CurrencyDescription = 16;
        }

        #endregion

    }
}
