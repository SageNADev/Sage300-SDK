// Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of AssignAudit Constants
    /// </summary>
    public partial class AssignAudit
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0058";

        #region Fields Properties

        /// <summary>
        /// Contains list of AssignAudit Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for What to Globally Modify
            /// </summary>
            public const string What2Change = "WHAT2CHG";

            /// <summary>
            /// Property for Earn/Ded or Tax to Change
            /// </summary>
            public const string ID2Change = "ID2CHANGE";

            /// <summary>
            /// Property for Earn/Ded or Tax Name
            /// </summary>
            public const string IdName = "IDNAME";

            /// <summary>
            /// Property for Employee Selection Type
            /// </summary>
            public const string SelType = "SELTYPE";

            /// <summary>
            /// Property for Employee Browse Filter
            /// </summary>
            public const string EBrowse = "EBROWSE";

            /// <summary>
            /// Property for Selection List
            /// </summary>
            public const string EmpListID = "EMPLISTID";

            /// <summary>
            /// Property for From Employee
            /// </summary>
            public const string FEmployee = "FEMPLOYEE";

            /// <summary>
            /// Property for To Employee
            /// </summary>
            public const string TEmployee = "TEMPLOYEE";

            /// <summary>
            /// Property for Class
            /// </summary>
            public const string Class = "CLASS";

            /// <summary>
            /// Property for From Class Code
            /// </summary>
            public const string FClassCod = "FCLASSCOD";

            /// <summary>
            /// Property for To Class Code
            /// </summary>
            public const string TClassCod = "TCLASSCOD";

            /// <summary>
            /// Property for Use Employee Defaults
            /// </summary>
            public const string UseDefault = "USEDEFAULT";

            /// <summary>
            /// Property for Employees Updated
            /// </summary>
            public const string EmpUpdated = "EMPUPDATED";
            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for Currency Code
            /// </summary>
            public const string CurrCode = "CURRCODE";
            /// <summary>
            /// Property for Currency Description
            /// </summary>
            public const string CurrDesc = "CURRDESC";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of AssignAudit Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property for What to Globally Modify
            /// </summary>
            public const int What2Chg = 1;

            /// <summary>
            /// Property for Earn/Ded or Tax to Change
            /// </summary>
            public const int ID2Change = 2;

            /// <summary>
            /// Property for Earn/Ded or Tax Name
            /// </summary>
            public const int IdName = 3;

            /// <summary>
            /// Property for Employee Selection Type
            /// </summary>
            public const int SelType = 4;

            /// <summary>
            /// Property for Employee Browse Filter
            /// </summary>
            public const int EBrowse = 5;

            /// <summary>
            /// Property for Selection List
            /// </summary>
            public const int EmpListID = 6;

            /// <summary>
            /// Property for From Employee
            /// </summary>
            public const int FEmployee = 7;

            /// <summary>
            /// Property for To Employee
            /// </summary>
            public const int TEmployee = 8;

            /// <summary>
            /// Property for Class
            /// </summary>
            public const int Class = 9;

            /// <summary>
            /// Property for From Class Code
            /// </summary>
            public const int FClassCod = 10;

            /// <summary>
            /// Property for To Class Code
            /// </summary>
            public const int TClassCod = 11;

            /// <summary>
            /// Property for Use Employee Defaults
            /// </summary>
            public const int UseDefault = 12;

            /// <summary>
            /// Property for Employees Updated
            /// </summary>
            public const int EmpUpdated = 13;
            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 14;

            /// <summary>
            /// Property for Currency Code
            /// </summary>
            public const int CurrCode = 15;
            /// <summary>
            /// Property for Currency Description
            /// </summary>
            public const int CurrDesc = 16;

        }

        #endregion

    }
}