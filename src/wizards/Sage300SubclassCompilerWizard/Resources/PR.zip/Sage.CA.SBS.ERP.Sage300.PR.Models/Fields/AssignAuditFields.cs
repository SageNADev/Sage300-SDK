// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of AssignAudit Constants
    /// </summary>
    public partial class AssignAudit
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0058";

        #region Fields Properties

        /// <summary>
        /// Contains list of AssignAudit Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for WHAT2CHG
            /// </summary>
            public const string What2Change = "WHAT2CHG";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of AssignAudit Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 14;

        }

        #endregion

    }
}