// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of Employe Selection List Constants
    /// </summary>
    public partial class EmployeeSelectionListModel
    {
        /// <summary>
        /// Entity Name with prefix added later
        /// </summary>
        public const string EntityName = "~~0045";

        #region Fields Properties

        /// <summary>
        /// Contains list of Employee Selection List Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee List
            /// </summary>
            public const string EmployeeList = "EMPLISTID";

            /// <summary>
            /// Property for Employee List Description
            /// </summary>
            public const string EmployeeListDesc = "EMPLISTDSC";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "LASTMAINT";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for CombineEmplSelListID1
            /// </summary>
            public const string CombineSelList1 = "COMBLIST1";

            /// <summary>
            /// Property for CombineEmplSelListID2
            /// </summary>
            public const string CombineSelList2 = "COMBLIST2";

            /// <summary>
            /// Property for FrequencyDaily
            /// </summary>
            public const string FrequencyDaily = "DAILY";

            /// <summary>
            /// Property for FrequencyWeekly
            /// </summary>
            public const string FrequencyWeekly = "WEEKLY";

            /// <summary>
            /// Property for FrequencyBiweekly
            /// </summary>
            public const string FrequencyBiweekly = "BIWEEKLY";

            /// <summary>
            /// Property for FrequencySemimonthly
            /// </summary>
            public const string FrequencySemimonthly = "SEMIMONTH";

            /// <summary>
            /// Property for Frequency22Year
            /// </summary>
            public const string Frequency22Year = "B22YEAR";

            /// <summary>
            /// Property for Frequency13Year
            /// </summary>
            public const string Frequency13Year = "B13YEAR";

            /// <summary>
            /// Property for FrequencyMonthly
            /// </summary>
            public const string FrequencyMonthly = "MONTHLY";

            /// <summary>
            /// Property for Frequency10Year
            /// </summary>
            public const string Frequency10Year = "B10YEAR";

            /// <summary>
            /// Property for FrequencyQuarterly
            /// </summary>
            public const string FrequencyQuarterly = "QUARTERLY";

            /// <summary>
            /// Property for Active
            /// </summary>
            public const string Active = "ACTIVE";

            /// <summary>
            /// Property for Inactive
            /// </summary>
            public const string Inactive = "INACTIVE";

            /// <summary>
            /// Property for InactROE
            /// </summary>
            public const string InactROE = "INACTROE";

            /// <summary>
            /// Property for Terminated
            /// </summary>
            public const string Terminated = "TERMINATED";

            /// <summary>
            /// Property for TERMROE
            /// </summary>
            public const string TermROE = "TERMROE";

            /// <summary>
            /// Property for PartTime
            /// </summary>
            public const string PartTime = "PARTTIME";

            /// <summary>
            /// Property for FullTime
            /// </summary>
            public const string FullTime = "FULLTIME";

            /// <summary>
            /// Property for DirectDeposit
            /// </summary>
            public const string DirectDeposit = "DDEPOSIT";

            /// <summary>
            /// Property for NonDirectDeposit
            /// </summary>
            public const string NonDirectDeposit = "NODDEPOSIT";

            /// <summary>
            /// Property for Position
            /// </summary>
            public const string Position = "POSITION";

            /// <summary>
            /// Property for Manager
            /// </summary>
            public const string Manager = "SUPERVISOR";

            /// <summary>
            /// Property for SelectItem1
            /// </summary>
            public const string SelectItem1 = "SELITEM1";

            /// <summary>
            /// Property for SelectSubItem1
            /// </summary>
            public const string SelectSubItem1 = "SELSUB1";

            /// <summary>
            /// Property for SelectItem1From
            /// </summary>
            public const string SelectItem1From = "SELFROM1";

            /// <summary>
            /// Property for SelectItem1To
            /// </summary>
            public const string SelectItem1To = "SELTO1";

            /// <summary>
            /// Property for SelectItem2
            /// </summary>
            public const string SelectItem2 = "SELITEM2";

            /// <summary>
            /// Property for SelectSubItem2
            /// </summary>
            public const string SelectSubItem2 = "SELSUB2";

            /// <summary>
            /// Property for SelectItem2From
            /// </summary>
            public const string SelectItem2From = "SELFROM2";

            /// <summary>
            /// Property for SelectItem2To
            /// </summary>
            public const string SelectItem2To = "SELTO2";

            /// <summary>
            /// Property for SelectItem3
            /// </summary>
            public const string SelectItem3 = "SELITEM3";

            /// <summary>
            /// Property for SelectSubItem3
            /// </summary>
            public const string SelectSubItem3 = "SELSUB3";

            /// <summary>
            /// Property for SelectItem3From
            /// </summary>
            public const string SelectItem3From = "SELFROM3";

            /// <summary>
            /// Property for SelectItem3To
            /// </summary>
            public const string SelectItem3To = "SELTO3";

            /// <summary>
            /// Property for SelectItem4
            /// </summary>
            public const string SelectItem4 = "SELITEM4";

            /// <summary>
            /// Property for SelectSubItem4
            /// </summary>
            public const string SelectSubItem4 = "SELSUB4";

            /// <summary>
            /// Property for SelectItem4From
            /// </summary>
            public const string SelectItem4From = "SELFROM4";

            /// <summary>
            /// Property for SelectItem4To
            /// </summary>
            public const string SelectItem4To = "SELTO4";

            /// <summary>
            /// Property for OptFld1
            /// </summary>
            public const string OptFld1 = "OPTFIELD1";

            /// <summary>
            /// Property for OptFld1From
            /// </summary>
            public const string OptFld1From = "OPTFRVAL1";

            /// <summary>
            /// Property for OptFld1To
            /// </summary>
            public const string OptFld1To = "OPTTOVAL1";

            /// <summary>
            /// Property for OptFld2
            /// </summary>
            public const string OptFld2 = "OPTFIELD2";

            /// <summary>
            /// Property for OptFld2From
            /// </summary>
            public const string OptFld2From = "OPTFRVAL2";

            /// <summary>
            /// Property for OptFld2To
            /// </summary>
            public const string OptFld2To = "OPTTOVAL2";

            /// <summary>
            /// Property for OptFld3
            /// </summary>
            public const string OptFld3 = "OPTFIELD3";

            /// <summary>
            /// Property for OptFld3From
            /// </summary>
            public const string OptFld3From = "OPTFRVAL3";

            /// <summary>
            /// Property for OptFld3To
            /// </summary>
            public const string OptFld3To = "OPTTOVAL3";

            /// <summary>
            /// Property for ListTotal
            /// </summary>
            public const string ListTotal = "LISTCOUNT";

            /// <summary>
            /// Property for SecurityFlag
            /// </summary>
            public const string SecurityFlag = "NOUSERSEC";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of Employe Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee List
            /// </summary>
            public const int EmployeeList = 1;

            /// <summary>
            /// Property Indexer for Employee List Description
            /// </summary>
            public const int EmployeeListDesc = 2;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 3;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 4;

            /// <summary>
            /// Property Indexer for CombineEmplSelListID1
            /// </summary>
            public const int CombineSelList1 = 5;

            /// <summary>
            /// Property Indexer for CombineEmplSelListID2
            /// </summary>
            public const int CombineSelList2 = 6;

            /// <summary>
            /// Property Indexer for FrequencyDaily
            /// </summary>
            public const int FrequencyDaily = 7;

            /// <summary>
            /// Property Indexer for FrequencyWeekly
            /// </summary>
            public const int FrequencyWeekly = 8;

            /// <summary>
            /// Property Indexer for FrequencyBiweekly
            /// </summary>
            public const int FrequencyBiweekly = 9;

            /// <summary>
            /// Property Indexer for FrequencySemimonthly
            /// </summary>
            public const int FrequencySemimonthly = 10;

            /// <summary>
            /// Property Indexer for Frequency22Year
            /// </summary>
            public const int Frequency22Year = 11;

            /// <summary>
            /// Property Indexer for Frequency13Year
            /// </summary>
            public const int Frequency13Year = 12;

            /// <summary>
            /// Property Indexer for FrequencyMonthly
            /// </summary>
            public const int FrequencyMonthly = 13;

            /// <summary>
            /// Property Indexer for Frequency10Year
            /// </summary>
            public const int Frequency10Year = 14;

            /// <summary>
            /// Property Indexer for FrequencyQuarterly
            /// </summary>
            public const int FrequencyQuarterly = 15;

            /// <summary>
            /// Property Indexer for Active
            /// </summary>
            public const int Active = 16;

            /// <summary>
            /// Property Indexer for Inactive
            /// </summary>
            public const int Inactive = 17;

            /// <summary>
            /// Property Indexer for InactROE
            /// </summary>
            public const int InactROE = 18;

            /// <summary>
            /// Property Indexer for Terminated
            /// </summary>
            public const int Terminated = 19;

            /// <summary>
            /// Property Indexer for TERMROE
            /// </summary>
            public const int TermROE = 20;

            /// <summary>
            /// Property Indexer for PartTime
            /// </summary>
            public const int PartTime = 21;

            /// <summary>
            /// Property Indexer for FullTime
            /// </summary>
            public const int FullTime = 22;

            /// <summary>
            /// Property Indexer for DirectDeposit
            /// </summary>
            public const int DirectDeposit = 23;

            /// <summary>
            /// Property Indexer for NonDirectDeposit
            /// </summary>
            public const int NonDirectDeposit = 24;

            /// <summary>
            /// Property Indexer for Position
            /// </summary>
            public const int Position = 25;

            /// <summary>
            /// Property Indexer for Manager
            /// </summary>
            public const int Manager = 26;

            /// <summary>
            /// Property Indexer for SelectItem1
            /// </summary>
            public const int SelectItem1 = 27;

            /// <summary>
            /// Property Indexer for SelectSubItem1
            /// </summary>
            public const int SelectSubItem1 = 28;

            /// <summary>
            /// Property Indexer for SelectItem1From
            /// </summary>
            public const int SelectItem1From = 29;

            /// <summary>
            /// Property Indexer for SelectItem1To
            /// </summary>
            public const int SelectItem1To = 30;

            /// <summary>
            /// Property Indexer for SelectItem2
            /// </summary>
            public const int SelectItem2 = 31;

            /// <summary>
            /// Property Indexer for SelectSubItem2
            /// </summary>
            public const int SelectSubItem2 = 32;

            /// <summary>
            /// Property Indexer for SelectItem2From
            /// </summary>
            public const int SelectItem2From = 33;

            /// <summary>
            /// Property Indexer for SelectItem2To
            /// </summary>
            public const int SelectItem2To = 34;

            /// <summary>
            /// Property Indexer for SelectItem3
            /// </summary>
            public const int SelectItem3 = 35;

            /// <summary>
            /// Property Indexer for SelectSubItem3
            /// </summary>
            public const int SelectSubItem3 = 36;

            /// <summary>
            /// Property Indexer for SelectItem3From
            /// </summary>
            public const int SelectItem3From = 37;

            /// <summary>
            /// Property Indexer for SelectItem3To
            /// </summary>
            public const int SelectItem3To = 38;

            /// <summary>
            /// Property Indexer for SelectItem4
            /// </summary>
            public const int SelectItem4 = 39;

            /// <summary>
            /// Property Indexer for SelectSubItem4
            /// </summary>
            public const int SelectSubItem4 = 40;

            /// <summary>
            /// Property Indexer for SelectItem4From
            /// </summary>
            public const int SelectItem4From = 41;

            /// <summary>
            /// Property Indexer for SelectItem4To
            /// </summary>
            public const int SelectItem4To = 42;

            /// <summary>
            /// Property Indexer for OptFld1
            /// </summary>
            public const int OptFld1 = 43;

            /// <summary>
            /// Property Indexer for OptFld1From
            /// </summary>
            public const int OptFld1From = 44;

            /// <summary>
            /// Property Indexer for OptFld1To
            /// </summary>
            public const int OptFld1To = 45;

            /// <summary>
            /// Property Indexer for OptFld2
            /// </summary>
            public const int OptFld2 = 46;

            /// <summary>
            /// Property Indexer for OptFld2From
            /// </summary>
            public const int OptFld2From = 47;

            /// <summary>
            /// Property Indexer for OptFld2To
            /// </summary>
            public const int OptFld2To = 48;

            /// <summary>
            /// Property Indexer for OptFld3
            /// </summary>
            public const int OptFld3 = 49;

            /// <summary>
            /// Property Indexer for OptFld3From
            /// </summary>
            public const int OptFld3From = 50;

            /// <summary>
            /// Property Indexer for OptFld3To
            /// </summary>
            public const int OptFld3To = 51;

            /// <summary>
            /// Property Indexer for ListTotal
            /// </summary>
            public const int ListTotal = 52;

            /// <summary>
            /// Property Indexer for SecurityFlag
            /// </summary>
            public const int SecurityFlag = 53;
        }

        #endregion

    }
}