// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeEFTBanks Constants
    /// </summary>
    public partial class EmployeeEFTBanks
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0201";


        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeEFTBanks Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for EmployeeEFTBank
            /// </summary>
            public const string EmployeeEFTBank = "BKACCTCODE";

            /// <summary>
            /// Property for EmployeeEFTBankDescription
            /// </summary>
            public const string EmployeeEFTBankDescription = "BKACCTDESC";

            /// <summary>
            /// Property for ReceivingDFIID
            /// </summary>
            public const string ReceivingDFIID = "INSTITUTID";

            /// <summary>
            /// Property for AccountNumber
            /// </summary>
            public const string AccountNumber = "ACCTNUM";

            /// <summary>
            /// Property for TransactionCode
            /// </summary>
            public const string TransactionCode = "TRANSCODE";

            /// <summary>
            /// Property for EFTCalculationType
            /// </summary>
            public const string EFTCalculationType = "EFTCALCTYP";

            /// <summary>
            /// Property for AmtPctToBeDeposited
            /// </summary>
            public const string AmtPctToBeDeposited = "AMTPCT";

            /// <summary>
            /// Property for StartDate
            /// </summary>
            public const string StartDate = "STARTDATE";

            /// <summary>
            /// Property for EndDate
            /// </summary>
            public const string EndDate = "ENDDATE";

            /// <summary>
            /// Property for DestinationCountry
            /// </summary>
            public const string DestinationCountry = "DCOUNTRY";

            /// <summary>
            /// Property for DestinationCurrency
            /// </summary>
            public const string DestinationCurrency = "DCURRENCY";

            /// <summary>
            /// Property for BankIDQualifier
            /// </summary>
            public const string BankIDQualifier = "BKIDQUALIF";

            /// <summary>
            /// Property for PrenoteStatus
            /// </summary>
            public const string PrenoteStatus = "PRENOTE";

            /// <summary>
            /// Property for SyncTransactionGUID
            /// </summary>
            public const string SyncTransactionGUID = "TRANSGUID";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeEFTBanks Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for EmployeeEFTBank
            /// </summary>
            public const int EmployeeEFTBank = 2;

            /// <summary>
            /// Property Indexer for EmployeeEFTBankDescription
            /// </summary>
            public const int EmployeeEFTBankDescription = 3;

            /// <summary>
            /// Property Indexer for ReceivingDFIID
            /// </summary>
            public const int ReceivingDFIID = 4;

            /// <summary>
            /// Property Indexer for AccountNumber
            /// </summary>
            public const int AccountNumber = 5;

            /// <summary>
            /// Property Indexer for TransactionCode
            /// </summary>
            public const int TransactionCode = 6;

            /// <summary>
            /// Property Indexer for EFTCalculationType
            /// </summary>
            public const int EFTCalculationType = 7;

            /// <summary>
            /// Property Indexer for AmtPctToBeDeposited
            /// </summary>
            public const int AmtPctToBeDeposited = 8;

            /// <summary>
            /// Property Indexer for StartDate
            /// </summary>
            public const int StartDate = 9;

            /// <summary>
            /// Property Indexer for EndDate
            /// </summary>
            public const int EndDate = 10;

            /// <summary>
            /// Property Indexer for DestinationCountry
            /// </summary>
            public const int DestinationCountry = 11;

            /// <summary>
            /// Property Indexer for DestinationCurrency
            /// </summary>
            public const int DestinationCurrency = 12;

            /// <summary>
            /// Property Indexer for BankIDQualifier
            /// </summary>
            public const int BankIDQualifier = 13;

            /// <summary>
            /// Property Indexer for PrenoteStatus
            /// </summary>
            public const int PrenoteStatus = 14;

            /// <summary>
            /// Property Indexer for SyncTransactionGUID
            /// </summary>
            public const int SyncTransactionGUID = 15;


        }

        #endregion

    }
}
