// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeCostCenterField Constants
    /// </summary>
    public partial class EmployeeCostCenterField
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "GL0022";


        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeCostCenterField Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for SegmentNumber
            /// </summary>
            public const string Number = "NUMBER";

            /// <summary>
            /// Property for SegmentName
            /// </summary>
            public const string Description = "DESCRIPTION";

            /// <summary>
            /// Property for SegmentValue
            /// </summary>
            public const string Value = "VALUE";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeCostCenterField Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for SegmentNumber
            /// </summary>
            public const int Number = 1;

            /// <summary>
            /// Property Indexer for SegmentDescription
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for SegmentValue
            /// </summary>
            public const int Value = 3;
        }

        #endregion

    }
}
