// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeTaxField Constants
    /// </summary>
    public partial class EmployeeTaxField
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0062";


        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeTaxField Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for TaxCode
            /// </summary>
            public const string TaxCode = "TAXID";

            /// <summary>
            /// Property for FieldUseType
            /// </summary>
            public const string FieldUseType = "PARMUSE";

            /// <summary>
            /// Property for FieldSequence
            /// </summary>
            public const string FieldSequence = "PARMSEQ";

            /// <summary>
            /// Property for TaxTableFieldNumber
            /// </summary>
            public const string TaxTableFieldNumber = "PARMNBR";

            /// <summary>
            /// Property for FieldDataType
            /// </summary>
            public const string FieldDataType = "PARMTYPE";

            /// <summary>
            /// Property for FieldLength
            /// </summary>
            public const string FieldLength = "PARMLEN";

            /// <summary>
            /// Property for NumberOfDecimalPlaces
            /// </summary>
            public const string NumberOfDecimalPlaces = "PARMDECS";

            /// <summary>
            /// Property for Value
            /// </summary>
            public const string Value = "PARMVAL";

            /// <summary>
            /// Property for ParameterName
            /// </summary>
            public const string ParameterName = "PARMNAME";

            /// <summary>
            /// Property for EmployeeTemplate
            /// </summary>
            public const string EmployeeTemplate = "TEMPLATE";

            /// <summary>
            /// Property for TextValue
            /// </summary>
            public const string TextValue = "VALSTR";

            /// <summary>
            /// Property for BinaryValue
            /// </summary>
            public const string BinaryValue = "VALBIN";

            /// <summary>
            /// Property for DateValue
            /// </summary>
            public const string DateValue = "VALDATE";

            /// <summary>
            /// Property for TimeValue
            /// </summary>
            public const string TimeValue = "VALTIME";

            /// <summary>
            /// Property for NumberValue
            /// </summary>
            public const string NumberValue = "VALREAL";

            /// <summary>
            /// Property for AmountValue
            /// </summary>
            public const string AmountValue = "VALBCD";

            /// <summary>
            /// Property for IntegerValue
            /// </summary>
            public const string IntegerValue = "VALINT";

            /// <summary>
            /// Property for LongValue
            /// </summary>
            public const string LongValue = "VALLONG";

            /// <summary>
            /// Property for YesNoValue
            /// </summary>
            public const string YesNoValue = "VALBOOL";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeTaxField Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for TaxCode
            /// </summary>
            public const int TaxCode = 2;

            /// <summary>
            /// Property Indexer for FieldUseType
            /// </summary>
            public const int FieldUseType = 3;

            /// <summary>
            /// Property Indexer for FieldSequence
            /// </summary>
            public const int FieldSequence = 4;

            /// <summary>
            /// Property Indexer for TaxTableFieldNumber
            /// </summary>
            public const int TaxTableFieldNumber = 5;

            /// <summary>
            /// Property Indexer for FieldDataType
            /// </summary>
            public const int FieldDataType = 6;

            /// <summary>
            /// Property Indexer for FieldLength
            /// </summary>
            public const int FieldLength = 7;

            /// <summary>
            /// Property Indexer for NumberOfDecimalPlaces
            /// </summary>
            public const int NumberOfDecimalPlaces = 8;

            /// <summary>
            /// Property Indexer for Value
            /// </summary>
            public const int Value = 9;

            /// <summary>
            /// Property Indexer for ParameterName
            /// </summary>
            public const int ParameterName = 31;

            /// <summary>
            /// Property Indexer for EmployeeTemplate
            /// </summary>
            public const int EmployeeTemplate = 32;

            /// <summary>
            /// Property Indexer for TextValue
            /// </summary>
            public const int TextValue = 33;

            /// <summary>
            /// Property Indexer for BinaryValue
            /// </summary>
            public const int BinaryValue = 34;

            /// <summary>
            /// Property Indexer for DateValue
            /// </summary>
            public const int DateValue = 35;

            /// <summary>
            /// Property Indexer for TimeValue
            /// </summary>
            public const int TimeValue = 36;

            /// <summary>
            /// Property Indexer for NumberValue
            /// </summary>
            public const int NumberValue = 37;

            /// <summary>
            /// Property Indexer for AmountValue
            /// </summary>
            public const int AmountValue = 38;

            /// <summary>
            /// Property Indexer for IntegerValue
            /// </summary>
            public const int IntegerValue = 39;

            /// <summary>
            /// Property Indexer for LongValue
            /// </summary>
            public const int LongValue = 40;

            /// <summary>
            /// Property Indexer for YesNoValue
            /// </summary>
            public const int YesNoValue = 41;


        }

        #endregion

    }
}
