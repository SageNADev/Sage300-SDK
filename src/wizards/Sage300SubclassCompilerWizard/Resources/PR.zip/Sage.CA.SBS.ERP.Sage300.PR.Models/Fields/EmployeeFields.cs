// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of Employees Constants
    /// </summary>
    public partial class Employees
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0014";


        #region Fields Properties

        /// <summary>
        /// Contains list of Employees Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "LASTMAINT";

            /// <summary>
            /// Property for EmployeeTemplate
            /// </summary>
            public const string EmployeeTemplate = "TEMPLATE";

            /// <summary>
            /// Property for LastName
            /// </summary>
            public const string LastName = "LASTNAME";

            /// <summary>
            /// Property for FirstName
            /// </summary>
            public const string FirstName = "FIRSTNAME";

            /// <summary>
            /// Property for MiddleName
            /// </summary>
            public const string MiddleName = "MIDDLENAME";

            /// <summary>
            /// Property for FullName
            /// </summary>
            public const string FullName = "FULLNAME";

            /// <summary>
            /// Property for AddressLine1
            /// </summary>
            public const string AddressLine1 = "ADDRESS1";

            /// <summary>
            /// Property for AddressLine2
            /// </summary>
            public const string AddressLine2 = "ADDRESS2";

            /// <summary>
            /// Property for AddressLine3
            /// </summary>
            public const string AddressLine3 = "ADDRESS3";

            /// <summary>
            /// Property for AddressLine4
            /// </summary>
            public const string AddressLine4 = "ADDRESS4";

            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "CITY";

            /// <summary>
            /// Property for StateProvince
            /// </summary>
            public const string StateProvince = "STATE";

            /// <summary>
            /// Property for ZIPCode
            /// </summary>
            public const string ZIPCode = "ZIP";

            /// <summary>
            /// Property for Country
            /// </summary>
            public const string Country = "COUNTRY";

            /// <summary>
            /// Property for SocialSecurityNumber
            /// </summary>
            public const string SocialSecurityNumber = "SSN";

            /// <summary>
            /// Property for BirthDate
            /// </summary>
            public const string BirthDate = "BIRTHDATE";

            /// <summary>
            /// Property for EmploymentStatus
            /// </summary>
            public const string EmploymentStatus = "STATUS";

            /// <summary>
            /// Property for HireDate
            /// </summary>
            public const string HireDate = "HIREDATE";

            /// <summary>
            /// Property for TerminationDate
            /// </summary>
            public const string TerminationDate = "FIREDATE";

            /// <summary>
            /// Property for Position
            /// </summary>
            public const string Position = "POSITION";

            /// <summary>
            /// Property for PartTime
            /// </summary>
            public const string PartTime = "PARTTIME";

            /// <summary>
            /// Property for PayFrequency
            /// </summary>
            public const string PayFrequency = "PAYFREQ";

            /// <summary>
            /// Property for CheckLanguage
            /// </summary>
            public const string CheckLanguage = "CHECKLANG";

            /// <summary>
            /// Property for HoursPerPeriod
            /// </summary>
            public const string HoursPerPeriod = "HRSPERPER";

            /// <summary>
            /// Property for WorkersCompensationCode
            /// </summary>
            public const string WorkersCompensationCode = "WCC";

            /// <summary>
            /// Property for OvertimeSchedule
            /// </summary>
            public const string OvertimeSchedule = "OTSCHED";

            /// <summary>
            /// Property for ShiftDifferentialSchedule
            /// </summary>
            public const string ShiftDifferentialSchedule = "SHIFTSCHED";

            /// <summary>
            /// Property for ShiftNumber
            /// </summary>
            public const string ShiftNumber = "SHIFTNUM";

            /// <summary>
            /// Property for TimesLate
            /// </summary>
            public const string TimesLate = "TIMESLATE";

            /// <summary>
            /// Property for EntrySequence
            /// </summary>
            public const string EntrySequence = "ENTRYSEQ";

            /// <summary>
            /// Property for Class1
            /// </summary>
            public const string Class1 = "CLASS1";

            /// <summary>
            /// Property for Class2
            /// </summary>
            public const string Class2 = "CLASS2";

            /// <summary>
            /// Property for Class3
            /// </summary>
            public const string Class3 = "CLASS3";

            /// <summary>
            /// Property for Class4
            /// </summary>
            public const string Class4 = "CLASS4";

            /// <summary>
            /// Property for SegmentCode1
            /// </summary>
            public const string SegmentCode1 = "GLSEG1";

            /// <summary>
            /// Property for SegmentCode2
            /// </summary>
            public const string SegmentCode2 = "GLSEG2";

            /// <summary>
            /// Property for SegmentCode3
            /// </summary>
            public const string SegmentCode3 = "GLSEG3";

            /// <summary>
            /// Property for Phone
            /// </summary>
            public const string Phone = "PHONE";

            /// <summary>
            /// Property for Manager
            /// </summary>
            public const string Manager = "SUPERVSR";

            /// <summary>
            /// Property for LastReviewDate
            /// </summary>
            public const string LastReviewDate = "REVWDATE";

            /// <summary>
            /// Property for DateOfLastRaise
            /// </summary>
            public const string DateOfLastRaise = "LASTRAISE";

            /// <summary>
            /// Property for AlternateAddressLine1
            /// </summary>
            public const string AlternateAddressLine1 = "ALTADDR1";

            /// <summary>
            /// Property for AlternateAddressLine2
            /// </summary>
            public const string AlternateAddressLine2 = "ALTADDR2";

            /// <summary>
            /// Property for AlternateAddressLine3
            /// </summary>
            public const string AlternateAddressLine3 = "ALTADDR3";

            /// <summary>
            /// Property for AlternateAddressLine4
            /// </summary>
            public const string AlternateAddressLine4 = "ALTADDR4";

            /// <summary>
            /// Property for AlternateCity
            /// </summary>
            public const string AlternateCity = "ALTCITY";

            /// <summary>
            /// Property for AlternateStateProvince
            /// </summary>
            public const string AlternateStateProvince = "ALTSTATE";

            /// <summary>
            /// Property for AlternateZIPPostalCode
            /// </summary>
            public const string AlternateZIPPostalCode = "ALTZIP";

            /// <summary>
            /// Property for AlternateCountry
            /// </summary>
            public const string AlternateCountry = "ALTCNTRY";

            /// <summary>
            /// Property for Gender
            /// </summary>
            public const string Gender = "GENDER";

            /// <summary>
            /// Property for EmergencyContact
            /// </summary>
            public const string EmergencyContact = "EMERNAME";

            /// <summary>
            /// Property for EmergencyPhone
            /// </summary>
            public const string EmergencyPhone = "EMERPHON";

            /// <summary>
            /// Property for MinimumWage
            /// </summary>
            public const string MinimumWage = "MINWAGE";

            /// <summary>
            /// Property for VacationID
            /// </summary>
            public const string VacationID = "VACATION";

            /// <summary>
            /// Property for SickPayID
            /// </summary>
            public const string SickPayID = "SICK";

            /// <summary>
            /// Property for CompTimeID
            /// </summary>
            public const string CompTimeID = "COMPTIME";

            /// <summary>
            /// Property for SSNFormat
            /// </summary>
            public const string SSNFormat = "SSNFORMAT";

            /// <summary>
            /// Property for Disability
            /// </summary>
            public const string Disability = "Disability";

            /// <summary>
            /// Property for RPP
            /// </summary>
            public const string RPP = "RPP";

            /// <summary>
            /// Property for StateOfHire
            /// </summary>
            public const string StateOfHire = "WORKPROV";

            /// <summary>
            /// Property for TimecardUserID
            /// </summary>
            public const string TimecardUserID = "TCUSERID";

            /// <summary>
            /// Property for DirectDeposit
            /// </summary>
            public const string DirectDeposit = "DEPOSIT";

            /// <summary>
            /// Property for BankTransferName
            /// </summary>
            public const string BankTransferName = "TRNSFRNAME";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for DiscretionaryData
            /// </summary>
            public const string DiscretionaryData = "DISCREDATA";

            /// <summary>
            /// Property for WorkersCompGroup
            /// </summary>
            public const string WorkersCompGroup = "WCCGROUP";

            /// <summary>
            /// Property for InactiveDate
            /// </summary>
            public const string InactiveDate = "INACTDATE";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for RegularHoursPerDay
            /// </summary>
            public const string RegularHoursPerDay = "HRSPERDAY";

            /// <summary>
            /// Property for OvertimeCalculation
            /// </summary>
            public const string OvertimeCalculation = "OTCALCTYPE";

            /// <summary>
            /// Property for CountryCode
            /// </summary>
            public const string CountryCode = "CNTRYCODE";

            /// <summary>
            /// Property for WorkClassificationCode
            /// </summary>
            public const string WorkClassificationCode = "WORKCODE";

            /// <summary>
            /// Property for HoursPerWeek
            /// </summary>
            public const string HoursPerWeek = "HRSPERWEEK";

            /// <summary>
            /// Property for SourceApplication
            /// </summary>
            public const string SourceApplication = "SRCEAPPL";

            /// <summary>
            /// Property for Email
            /// </summary>
            public const string Email = "EMAIL";

            /// <summary>
            /// Property for CalcOTOnAWeeklyBasis
            /// </summary>
            public const string CalcOTOnAWeeklyBasis = "WKLYFLSA";

            /// <summary>
            /// Property for USCitizen
            /// </summary>
            public const string USCitizen = "USCITIZEN";

            /// <summary>
            /// Property for WorkLocation
            /// </summary>
            public const string WorkLocation = "WORKLOC";

            /// <summary>
            /// Property for WorkLocationAddress2
            /// </summary>
            public const string WorkLocationAddress2 = "WLADDR2";

            /// <summary>
            /// Property for WorkLocationAddress3
            /// </summary>
            public const string WorkLocationAddress3 = "WLADDR3";

            /// <summary>
            /// Property for WorkLocationAddress4
            /// </summary>
            public const string WorkLocationAddress4 = "WLADDR4";

            /// <summary>
            /// Property for WorkLocationCity
            /// </summary>
            public const string WorkLocationCity = "WLCITY";

            /// <summary>
            /// Property for WorkLocationStateProv
            /// </summary>
            public const string WorkLocationStateProv = "WLSTATE";

            /// <summary>
            /// Property for WorkLocationZipPostalCode
            /// </summary>
            public const string WorkLocationZipPostalCode = "WLPOSTAL";

            /// <summary>
            /// Property for WorkLocationCountry
            /// </summary>
            public const string WorkLocationCountry = "WLCOUNTRY";

            /// <summary>
            /// Property for RESERVEDSegmentCode4
            /// </summary>
            public const string RESERVEDSegmentCode4 = "GLSEG4";

            /// <summary>
            /// Property for RESERVEDSegmentCode5
            /// </summary>
            public const string RESERVEDSegmentCode5 = "GLSEG5";

            /// <summary>
            /// Property for RESERVEDSegmentCode6
            /// </summary>
            public const string RESERVEDSegmentCode6 = "GLSEG6";

            /// <summary>
            /// Property for SyncMasterGUID
            /// </summary>
            public const string SyncMasterGUID = "MASTGUID";

            /// <summary>
            /// Property for EmployeeElectronicW2Consent
            /// </summary>
            public const string EmployeeElectronicW2Consent = "ELECW2";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for EmployeeSecurityFlag1
            /// </summary>
            public const string EmployeeSecurityFlag1 = "USERSEC";

            /// <summary>
            /// Property for EmployeeSecurityFlag2
            /// </summary>
            public const string EmployeeSecurityFlag2 = "NOUSERSEC";

            /// <summary>
            /// Property for INTERNALUSESelectionList
            /// </summary>
            public const string INTERNALUSESelectionList = "SELECTLIST";

            /// <summary>
            /// Property for JobCategory
            /// </summary>
            public const string JobCategory = "EEOJOBCATE";

            /// <summary>
            /// Property for Ethnicity
            /// </summary>
            public const string Ethnicity = "EEOETHNIC";

            /// <summary>
            /// Property for CAEthnicity
            /// </summary>
            public const string CAEthnicity = "CAEEOETHN";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of Employees Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 2;

            /// <summary>
            /// Property Indexer for EmployeeTemplate
            /// </summary>
            public const int EmployeeTemplate = 3;

            /// <summary>
            /// Property Indexer for LastName
            /// </summary>
            public const int LastName = 4;

            /// <summary>
            /// Property Indexer for FirstName
            /// </summary>
            public const int FirstName = 5;

            /// <summary>
            /// Property Indexer for MiddleName
            /// </summary>
            public const int MiddleName = 6;

            /// <summary>
            /// Property Indexer for FullName
            /// </summary>
            public const int FullName = 7;

            /// <summary>
            /// Property Indexer for AddressLine1
            /// </summary>
            public const int AddressLine1 = 8;

            /// <summary>
            /// Property Indexer for AddressLine2
            /// </summary>
            public const int AddressLine2 = 9;

            /// <summary>
            /// Property Indexer for AddressLine3
            /// </summary>
            public const int AddressLine3 = 10;

            /// <summary>
            /// Property Indexer for AddressLine4
            /// </summary>
            public const int AddressLine4 = 11;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 12;

            /// <summary>
            /// Property Indexer for StateProvince
            /// </summary>
            public const int StateProvince = 13;

            /// <summary>
            /// Property Indexer for ZIPCode
            /// </summary>
            public const int ZIPCode = 14;

            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 15;

            /// <summary>
            /// Property Indexer for SocialSecurityNumber
            /// </summary>
            public const int SocialSecurityNumber = 16;

            /// <summary>
            /// Property Indexer for BirthDate
            /// </summary>
            public const int BirthDate = 17;

            /// <summary>
            /// Property Indexer for EmploymentStatus
            /// </summary>
            public const int EmploymentStatus = 18;

            /// <summary>
            /// Property Indexer for HireDate
            /// </summary>
            public const int HireDate = 19;

            /// <summary>
            /// Property Indexer for TerminationDate
            /// </summary>
            public const int TerminationDate = 20;

            /// <summary>
            /// Property Indexer for Position
            /// </summary>
            public const int Position = 21;

            /// <summary>
            /// Property Indexer for PartTime
            /// </summary>
            public const int PartTime = 22;

            /// <summary>
            /// Property Indexer for PayFrequency
            /// </summary>
            public const int PayFrequency = 23;

            /// <summary>
            /// Property Indexer for CheckLanguage
            /// </summary>
            public const int CheckLanguage = 24;

            /// <summary>
            /// Property Indexer for HoursPerPeriod
            /// </summary>
            public const int HoursPerPeriod = 25;

            /// <summary>
            /// Property Indexer for WorkersCompensationCode
            /// </summary>
            public const int WorkersCompensationCode = 26;

            /// <summary>
            /// Property Indexer for OvertimeSchedule
            /// </summary>
            public const int OvertimeSchedule = 27;

            /// <summary>
            /// Property Indexer for ShiftDifferentialSchedule
            /// </summary>
            public const int ShiftDifferentialSchedule = 28;

            /// <summary>
            /// Property Indexer for ShiftNumber
            /// </summary>
            public const int ShiftNumber = 29;

            /// <summary>
            /// Property Indexer for TimesLate
            /// </summary>
            public const int TimesLate = 30;

            /// <summary>
            /// Property Indexer for EntrySequence
            /// </summary>
            public const int EntrySequence = 31;

            /// <summary>
            /// Property Indexer for Class1
            /// </summary>
            public const int Class1 = 32;

            /// <summary>
            /// Property Indexer for Class2
            /// </summary>
            public const int Class2 = 33;

            /// <summary>
            /// Property Indexer for Class3
            /// </summary>
            public const int Class3 = 34;

            /// <summary>
            /// Property Indexer for Class4
            /// </summary>
            public const int Class4 = 35;

            /// <summary>
            /// Property Indexer for SegmentCode1
            /// </summary>
            public const int SegmentCode1 = 36;

            /// <summary>
            /// Property Indexer for SegmentCode2
            /// </summary>
            public const int SegmentCode2 = 37;

            /// <summary>
            /// Property Indexer for SegmentCode3
            /// </summary>
            public const int SegmentCode3 = 38;

            /// <summary>
            /// Property Indexer for Phone
            /// </summary>
            public const int Phone = 39;

            /// <summary>
            /// Property Indexer for Manager
            /// </summary>
            public const int Manager = 40;

            /// <summary>
            /// Property Indexer for LastReviewDate
            /// </summary>
            public const int LastReviewDate = 41;

            /// <summary>
            /// Property Indexer for DateOfLastRaise
            /// </summary>
            public const int DateOfLastRaise = 42;

            /// <summary>
            /// Property Indexer for AlternateAddressLine1
            /// </summary>
            public const int AlternateAddressLine1 = 43;

            /// <summary>
            /// Property Indexer for AlternateAddressLine2
            /// </summary>
            public const int AlternateAddressLine2 = 44;

            /// <summary>
            /// Property Indexer for AlternateAddressLine3
            /// </summary>
            public const int AlternateAddressLine3 = 45;

            /// <summary>
            /// Property Indexer for AlternateAddressLine4
            /// </summary>
            public const int AlternateAddressLine4 = 46;

            /// <summary>
            /// Property Indexer for AlternateCity
            /// </summary>
            public const int AlternateCity = 47;

            /// <summary>
            /// Property Indexer for AlternateStateProvince
            /// </summary>
            public const int AlternateStateProvince = 48;

            /// <summary>
            /// Property Indexer for AlternateZIPPostalCode
            /// </summary>
            public const int AlternateZIPPostalCode = 49;

            /// <summary>
            /// Property Indexer for AlternateCountry
            /// </summary>
            public const int AlternateCountry = 50;

            /// <summary>
            /// Property Indexer for Gender
            /// </summary>
            public const int Gender = 51;

            /// <summary>
            /// Property Indexer for EmergencyContact
            /// </summary>
            public const int EmergencyContact = 52;

            /// <summary>
            /// Property Indexer for EmergencyPhone
            /// </summary>
            public const int EmergencyPhone = 53;

            /// <summary>
            /// Property Indexer for MinimumWage
            /// </summary>
            public const int MinimumWage = 62;

            /// <summary>
            /// Property Indexer for VacationID
            /// </summary>
            public const int VacationID = 63;

            /// <summary>
            /// Property Indexer for SickPayID
            /// </summary>
            public const int SickPayID = 64;

            /// <summary>
            /// Property Indexer for CompTimeID
            /// </summary>
            public const int CompTimeID = 65;

            /// <summary>
            /// Property Indexer for SSNFormat
            /// </summary>
            public const int SSNFormat = 66;

            /// <summary>
            /// Property Indexer for Disability
            /// </summary>
            public const int Disability = 67;

            /// <summary>
            /// Property Indexer for RPP
            /// </summary>
            public const int RPP = 68;

            /// <summary>
            /// Property Indexer for StateOfHire
            /// </summary>
            public const int StateOfHire = 69;

            /// <summary>
            /// Property Indexer for TimecardUserID
            /// </summary>
            public const int TimecardUserID = 70;

            /// <summary>
            /// Property Indexer for DirectDeposit
            /// </summary>
            public const int DirectDeposit = 71;

            /// <summary>
            /// Property Indexer for BankTransferName
            /// </summary>
            public const int BankTransferName = 72;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 73;

            /// <summary>
            /// Property Indexer for DiscretionaryData
            /// </summary>
            public const int DiscretionaryData = 74;

            /// <summary>
            /// Property Indexer for WorkersCompGroup
            /// </summary>
            public const int WorkersCompGroup = 75;

            /// <summary>
            /// Property Indexer for InactiveDate
            /// </summary>
            public const int InactiveDate = 76;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 77;

            /// <summary>
            /// Property Indexer for RegularHoursPerDay
            /// </summary>
            public const int RegularHoursPerDay = 78;

            /// <summary>
            /// Property Indexer for OvertimeCalculation
            /// </summary>
            public const int OvertimeCalculation = 79;

            /// <summary>
            /// Property Indexer for CountryCode
            /// </summary>
            public const int CountryCode = 80;

            /// <summary>
            /// Property Indexer for WorkClassificationCode
            /// </summary>
            public const int WorkClassificationCode = 81;

            /// <summary>
            /// Property Indexer for HoursPerWeek
            /// </summary>
            public const int HoursPerWeek = 82;

            /// <summary>
            /// Property Indexer for SourceApplication
            /// </summary>
            public const int SourceApplication = 83;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 84;

            /// <summary>
            /// Property Indexer for CalcOTOnAWeeklyBasis
            /// </summary>
            public const int CalcOTOnAWeeklyBasis = 85;

            /// <summary>
            /// Property Indexer for USCitizen
            /// </summary>
            public const int USCitizen = 86;

            /// <summary>
            /// Property Indexer for WorkLocation
            /// </summary>
            public const int WorkLocation = 87;

            /// <summary>
            /// Property Indexer for WorkLocationAddress2
            /// </summary>
            public const int WorkLocationAddress2 = 88;

            /// <summary>
            /// Property Indexer for WorkLocationAddress3
            /// </summary>
            public const int WorkLocationAddress3 = 89;

            /// <summary>
            /// Property Indexer for WorkLocationAddress4
            /// </summary>
            public const int WorkLocationAddress4 = 90;

            /// <summary>
            /// Property Indexer for WorkLocationCity
            /// </summary>
            public const int WorkLocationCity = 91;

            /// <summary>
            /// Property Indexer for WorkLocationStateProv
            /// </summary>
            public const int WorkLocationStateProv = 92;

            /// <summary>
            /// Property Indexer for WorkLocationZipPostalCode
            /// </summary>
            public const int WorkLocationZipPostalCode = 93;

            /// <summary>
            /// Property Indexer for WorkLocationCountry
            /// </summary>
            public const int WorkLocationCountry = 94;

            /// <summary>
            /// Property Indexer for RESERVEDSegmentCode4
            /// </summary>
            public const int RESERVEDSegmentCode4 = 95;

            /// <summary>
            /// Property Indexer for RESERVEDSegmentCode5
            /// </summary>
            public const int RESERVEDSegmentCode5 = 96;

            /// <summary>
            /// Property Indexer for RESERVEDSegmentCode6
            /// </summary>
            public const int RESERVEDSegmentCode6 = 97;

            /// <summary>
            /// Property Indexer for SyncMasterGUID
            /// </summary>
            public const int SyncMasterGUID = 98;

            /// <summary>
            /// Property Indexer for EmployeeElectronicW2Consent
            /// </summary>
            public const int EmployeeElectronicW2Consent = 99;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 100;

            /// <summary>
            /// Property Indexer for EmployeeSecurityFlag1
            /// </summary>
            public const int EmployeeSecurityFlag1 = 101;

            /// <summary>
            /// Property Indexer for EmployeeSecurityFlag2
            /// </summary>
            public const int EmployeeSecurityFlag2 = 102;

            /// <summary>
            /// Property Indexer for INTERNALUSESelectionList
            /// </summary>
            public const int INTERNALUSESelectionList = 103;

            /// <summary>
            /// Property Indexer for JobCategory
            /// </summary>
            public const int JobCategory = 104;

            /// <summary>
            /// Property Indexer for Ethnicity
            /// </summary>
            public const int Ethnicity = 105;

            /// <summary>
            /// Property Indexer for CAEthnicity
            /// </summary>
            public const int CAEthnicity = 106;


        }

        #endregion

    }
}
