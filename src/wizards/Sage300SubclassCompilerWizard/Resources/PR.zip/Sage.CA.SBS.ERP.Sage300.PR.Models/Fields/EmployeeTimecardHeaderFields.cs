// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeTimecardHeader Constants
    /// </summary>
    public partial class EmployeeTimecardHeader
    {
        /// <summary>
        /// Entity Name with prefix added later
        /// </summary>
        public const string EntityName = "~~0102";

        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeTimecardHeader Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for EndDate
            /// </summary>
            public const string EndDate = "ENDDATE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "TCARDDESC";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "STATUS";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for UniqueKeyField
            /// </summary>
            public const string UniqueKeyField = "UNIQUE";

            /// <summary>
            /// Property for JobRelated
            /// </summary>
            public const string JobRelated = "SWJOB";

            /// <summary>
            /// Property for StartDate
            /// </summary>
            public const string StartDate = "STARTDATE";

            /// <summary>
            /// Property for TotalHours
            /// </summary>
            public const string TotalHours = "TOTALHOURS";

            /// <summary>
            /// Property for TotalTips
            /// </summary>
            public const string TotalTips = "TOTALTIPS";

            /// <summary>
            /// Property for TotalExpenses
            /// </summary>
            public const string TotalExpenses = "TOTALEXP";

            /// <summary>
            /// Property for ProcessControlCode
            /// </summary>
            public const string ProcessControlCode = "OPCODE";

            /// <summary>
            /// Property for DefaultShiftSchedule
            /// </summary>
            public const string DefaultShiftSchedule = "SHIFTSCHED";

            /// <summary>
            /// Property for DefaultShiftNumber
            /// </summary>
            public const string DefaultShiftNumber = "SHIFTNUM";

            /// <summary>
            /// Property for PartTime
            /// </summary>
            public const string PartTime = "PARTTIME";

            /// <summary>
            /// Property for EmploymentStatus
            /// </summary>
            public const string EmploymentStatus = "EMPSTATUS";

            /// <summary>
            /// Property for HireDate
            /// </summary>
            public const string HireDate = "HIREDATE";

            /// <summary>
            /// Property for TerminationDate
            /// </summary>
            public const string TerminationDate = "FIREDATE";

            /// <summary>
            /// Property for InactiveDate
            /// </summary>
            public const string InactiveDate = "INACTDATE";

            /// <summary>
            /// Property for TotalPieces
            /// </summary>
            public const string TotalPieces = "TOTALPIECE";

            /// <summary>
            /// Property for TotalSales
            /// </summary>
            public const string TotalSales = "TOTALSALES";

            /// <summary>
            /// Property for WorkClassification
            /// </summary>
            public const string WorkClassification = "WORKCODE";

            /// <summary>
            /// Property for TotalJobs
            /// </summary>
            public const string TotalJobs = "TOTALJOBS";

            /// <summary>
            /// Property for TotalSickPayments
            /// </summary>
            public const string TotalSickPayments = "TOTALSICK";

            /// <summary>
            /// Property for TotalVacationPayments
            /// </summary>
            public const string TotalVacationPayments = "TOTALVAC";

            /// <summary>
            /// Property for UserSec
            /// </summary>
            public const string UserSec = "USERSEC";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeTimecardHeader Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for EndDate
            /// </summary>
            public const int EndDate = 2;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 3;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 4;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 5;

            /// <summary>
            /// Property Indexer for UniqueKeyField
            /// </summary>
            public const int UniqueKeyField = 6;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 7;

            /// <summary>
            /// Property Indexer for StartDate
            /// </summary>
            public const int StartDate = 20;

            /// <summary>
            /// Property Indexer for TotalHours
            /// </summary>
            public const int TotalHours = 21;

            /// <summary>
            /// Property Indexer for TotalTips
            /// </summary>
            public const int TotalTips = 22;

            /// <summary>
            /// Property Indexer for TotalExpenses
            /// </summary>
            public const int TotalExpenses = 23;

            /// <summary>
            /// Property Indexer for ProcessControlCode
            /// </summary>
            public const int ProcessControlCode = 24;

            /// <summary>
            /// Property Indexer for DefaultShiftSchedule
            /// </summary>
            public const int DefaultShiftSchedule = 25;

            /// <summary>
            /// Property Indexer for DefaultShiftNumber
            /// </summary>
            public const int DefaultShiftNumber = 26;

            /// <summary>
            /// Property Indexer for PartTime
            /// </summary>
            public const int PartTime = 27;

            /// <summary>
            /// Property Indexer for EmploymentStatus
            /// </summary>
            public const int EmploymentStatus = 28;

            /// <summary>
            /// Property Indexer for HireDate
            /// </summary>
            public const int HireDate = 29;

            /// <summary>
            /// Property Indexer for TerminationDate
            /// </summary>
            public const int TerminationDate = 30;

            /// <summary>
            /// Property Indexer for InactiveDate
            /// </summary>
            public const int InactiveDate = 31;

            /// <summary>
            /// Property Indexer for TotalPieces
            /// </summary>
            public const int TotalPieces = 32;

            /// <summary>
            /// Property Indexer for TotalSales
            /// </summary>
            public const int TotalSales = 33;

            /// <summary>
            /// Property Indexer for WorkClassification
            /// </summary>
            public const int WorkClassification = 34;

            /// <summary>
            /// Property Indexer for TotalJobs
            /// </summary>
            public const int TotalJobs = 35;

            /// <summary>
            /// Property Indexer for TotalSickPayments
            /// </summary>
            public const int TotalSickPayments = 36;

            /// <summary>
            /// Property Indexer for TotalVacationPayments
            /// </summary>
            public const int TotalVacationPayments = 37;

            /// <summary>
            /// Property Indexer for UserSec
            /// </summary>
            public const int UserSec = 38;


        }

        #endregion

    }
}