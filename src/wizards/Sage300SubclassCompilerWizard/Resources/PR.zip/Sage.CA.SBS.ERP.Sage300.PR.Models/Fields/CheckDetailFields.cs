// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of CheckDetail Constants
    /// </summary>
    public partial class CheckDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0049";

        #region Fields Properties

        /// <summary>
        /// Contains list of CheckDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "PEREND";

            /// <summary>
            /// Property for EntrySequence
            /// </summary>
            public const string EntrySequence = "ENTRYSEQ";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for EarningDeductionTax
            /// </summary>
            public const string EarningDeductionTax = "EARNDED";

            /// <summary>
            /// Property for LineType
            /// </summary>
            public const string LineType = "LINETYPE";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for EarningDeductionTaxType
            /// </summary>
            public const string EarningDeductionTaxType = "EARDEDTYPE";

            /// <summary>
            /// Property for EarningDeductionDate
            /// </summary>
            public const string EarningDeductionDate = "EARDEDDATE";

            /// <summary>
            /// Property for Hours
            /// </summary>
            public const string Hours = "HOURS";

            /// <summary>
            /// Property for EmployeePiecesSalesBase
            /// </summary>
            public const string EmployeePiecesSalesBase = "ECNTBASE";

            /// <summary>
            /// Property for EmployeeRateAmtPct
            /// </summary>
            public const string EmployeeRateAmtPct = "ERATE";

            /// <summary>
            /// Property for EmployeeExtendedAmount
            /// </summary>
            public const string EmployeeExtendedAmount = "EEXTEND";

            /// <summary>
            /// Property for RegularRate
            /// </summary>
            public const string RegularRate = "EREGRATE";

            /// <summary>
            /// Property for EmployerPiecesBase
            /// </summary>
            public const string EmployerPiecesBase = "RCNTBASE";

            /// <summary>
            /// Property for EmployerAmtPct
            /// </summary>
            public const string EmployerAmtPct = "RRATE";

            /// <summary>
            /// Property for EmployerExtendedAmount
            /// </summary>
            public const string EmployerExtendedAmount = "REXTEND";

            /// <summary>
            /// Property for RegularPayExpenseGLAccount
            /// </summary>
            public const string RegularPayExpenseGLAccount = "EXPACCT";

            /// <summary>
            /// Property for EmployeeLiabilityGLAccount
            /// </summary>
            public const string EmployeeLiabilityGLAccount = "ELIABACCT";

            /// <summary>
            /// Property for EmployerLiabilityGLAccount
            /// </summary>
            public const string EmployerLiabilityGLAccount = "RLIABACCT";

            /// <summary>
            /// Property for WorkersCompensationCode
            /// </summary>
            public const string WorkersCompensationCode = "WCC";

            /// <summary>
            /// Property for CostCenterSegmentOne
            /// </summary>
            public const string CostCenterSegmentOne = "GLSEG1";

            /// <summary>
            /// Property for CostCenterSegmentTwo
            /// </summary>
            public const string CostCenterSegmentTwo = "GLSEG2";

            /// <summary>
            /// Property for CostCenterSegmentThree
            /// </summary>
            public const string CostCenterSegmentThree = "GLSEG3";

            /// <summary>
            /// Property for DetailWasPartiallyTakenOrNo
            /// </summary>
            public const string DetailWasPartiallyTakenOrNo = "PARTIAL";

            /// <summary>
            /// Property for WeeksWorked
            /// </summary>
            public const string WeeksWorked = "TAXWEEKS";

            /// <summary>
            /// Property for EarnSubjToTaxNoCeiling
            /// </summary>
            public const string EarnSubjToTaxNoCeiling = "TAXEARNS";

            /// <summary>
            /// Property for EarnSubjToTax
            /// </summary>
            public const string EarnSubjToTax = "TXEARNCEIL";

            /// <summary>
            /// Property for NoCeilingTips
            /// </summary>
            public const string NoCeilingTips = "TAXTIPS";

            /// <summary>
            /// Property for CeilingTips
            /// </summary>
            public const string CeilingTips = "TXTIPSCEIL";

            /// <summary>
            /// Property for TaxOnTips
            /// </summary>
            public const string TaxOnTips = "TAXONTIPS";

            /// <summary>
            /// Property for UncollectedTaxOnTips
            /// </summary>
            public const string UncollectedTaxOnTips = "UNCOLLTAX";

            /// <summary>
            /// Property for PrintCategory
            /// </summary>
            public const string PrintCategory = "PCATEGORY";

            /// <summary>
            /// Property for PrintLineType
            /// </summary>
            public const string PrintLineType = "PLINETYPE";

            /// <summary>
            /// Property for PrintLineContents
            /// </summary>
            public const string PrintLineContents = "PCONTENTS";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TAXNONPER
            /// </summary>
            public const string TAXNONPER = "TAXNONPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TAXEARNBD
            /// </summary>
            public const string TAXEARNBD = "TAXEARNBD";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for POOLEDTIPS
            /// </summary>
            public const string POOLEDTIPS = "POOLEDTIPS";

            /// <summary>
            /// Property for DetailDate
            /// </summary>
            public const string DetailDate = "DETAILDATE";

            /// <summary>
            /// Property for StartTime
            /// </summary>
            public const string StartTime = "STARTTIME";

            /// <summary>
            /// Property for StopTime
            /// </summary>
            public const string StopTime = "STOPTIME";

            /// <summary>
            /// Property for WorkersCompGroup
            /// </summary>
            public const string WorkersCompGroup = "WCCGROUP";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for IncludedInFLSAOvertimeCalc
            /// </summary>
            public const string IncludedInFLSAOvertimeCalc = "SWFLSA";

            /// <summary>
            /// Property for DaysWorked
            /// </summary>
            public const string DaysWorked = "DAYS";

            /// <summary>
            /// Property for OvertimeSchedule
            /// </summary>
            public const string OvertimeSchedule = "OTSCHED";

            /// <summary>
            /// Property for OvertimeHoursOverride
            /// </summary>
            public const string OvertimeHoursOverride = "OTHOURS";

            /// <summary>
            /// Property for StraightTimeEarnings
            /// </summary>
            public const string StraightTimeEarnings = "STAMOUNT";

            /// <summary>
            /// Property for OvertimeRateMultiplier
            /// </summary>
            public const string OvertimeRateMultiplier = "PREMIUMRT";

            /// <summary>
            /// Property for Jobs
            /// </summary>
            public const string Jobs = "JOBS";

            /// <summary>
            /// Property for WorkClassificationCode
            /// </summary>
            public const string WorkClassificationCode = "WORKCODE";

            /// <summary>
            /// Property for LocalTaxCode
            /// </summary>
            public const string LocalTaxCode = "LOCTAXCODE";

            /// <summary>
            /// Property for WCBase
            /// </summary>
            public const string WCBase = "WCBASE";

            /// <summary>
            /// Property for WCRate
            /// </summary>
            public const string WCRate = "WCRATE";

            /// <summary>
            /// Property for WCAssessment
            /// </summary>
            public const string WCAssessment = "WCEXTEND";

            /// <summary>
            /// Property for WCExpenseAccount
            /// </summary>
            public const string WCExpenseAccount = "WCEXPACCT";

            /// <summary>
            /// Property for WCLiabilityAccount
            /// </summary>
            public const string WCLiabilityAccount = "WCLIABACCT";

            /// <summary>
            /// Property for ChildSupportEFTStatus
            /// </summary>
            public const string ChildSupportEFTStatus = "CSEFTSTAT";

            /// <summary>
            /// Property for DistributionCode
            /// </summary>
            public const string DistributionCode = "DISTCODE";

            /// <summary>
            /// Property for DistributionDescription
            /// </summary>
            public const string DistributionDescription = "DISTRNAME";

            /// <summary>
            /// Property for CostCenterSegmentFour
            /// </summary>
            public const string CostCenterSegmentFour = "GLSEG4";

            /// <summary>
            /// Property for CostCenterSegmentFix
            /// </summary>
            public const string CostCenterSegmentFix = "GLSEG5";

            /// <summary>
            /// Property for CostCenterSegmentSix
            /// </summary>
            public const string CostCenterSegmentSix = "GLSEG6";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TAXNONDED
            /// </summary>
            public const string TAXNONDED = "TAXNONDED";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TAXREPAY
            /// </summary>
            public const string TAXREPAY = "TAXREPAY";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for DetailType
            /// </summary>
            public const string DetailType = "DTLTYPE";

            /// <summary>
            /// Property for EmployeeCalculationMethod
            /// </summary>
            public const string EmployeeCalculationMethod = "ECALCMETH";

            /// <summary>
            /// Property for EmployerCalculationMethod
            /// </summary>
            public const string EmployerCalculationMethod = "RCALCMETH";

            /// <summary>
            /// Property for HistoryEntryTaxSide
            /// </summary>
            public const string HistoryEntryTaxSide = "HTAXSIDE";

            /// <summary>
            /// Property for NoCeilingWage
            /// </summary>
            public const string NoCeilingWage = "TAXEARNSNT";

            /// <summary>
            /// Property for CeilingWage
            /// </summary>
            public const string CeilingWage = "TXEARNCLNT";

            /// <summary>
            /// Property for CheckDate
            /// </summary>
            public const string CheckDate = "CHECKDATE";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of CheckDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 2;

            /// <summary>
            /// Property Indexer for EntrySequence
            /// </summary>
            public const int EntrySequence = 3;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 4;

            /// <summary>
            /// Property Indexer for EarningDeductionTax
            /// </summary>
            public const int EarningDeductionTax = 5;

            /// <summary>
            /// Property Indexer for LineType
            /// </summary>
            public const int LineType = 6;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 7;

            /// <summary>
            /// Property Indexer for EarningDeductionTaxType
            /// </summary>
            public const int EarningDeductionTaxType = 8;

            /// <summary>
            /// Property Indexer for EarningDeductionDate
            /// </summary>
            public const int EarningDeductionDate = 9;

            /// <summary>
            /// Property Indexer for Hours
            /// </summary>
            public const int Hours = 10;

            /// <summary>
            /// Property Indexer for EmployeePiecesSalesBase
            /// </summary>
            public const int EmployeePiecesSalesBase = 11;

            /// <summary>
            /// Property Indexer for EmployeeRateAmtPct
            /// </summary>
            public const int EmployeeRateAmtPct = 12;

            /// <summary>
            /// Property Indexer for EmployeeExtendedAmount
            /// </summary>
            public const int EmployeeExtendedAmount = 13;

            /// <summary>
            /// Property Indexer for RegularRate
            /// </summary>
            public const int RegularRate = 14;

            /// <summary>
            /// Property Indexer for EmployerPiecesBase
            /// </summary>
            public const int EmployerPiecesBase = 15;

            /// <summary>
            /// Property Indexer for EmployerAmtPct
            /// </summary>
            public const int EmployerAmtPct = 16;

            /// <summary>
            /// Property Indexer for EmployerExtendedAmount
            /// </summary>
            public const int EmployerExtendedAmount = 17;

            /// <summary>
            /// Property Indexer for RegularPayExpenseGLAccount
            /// </summary>
            public const int RegularPayExpenseGLAccount = 18;

            /// <summary>
            /// Property Indexer for EmployeeLiabilityGLAccount
            /// </summary>
            public const int EmployeeLiabilityGLAccount = 19;

            /// <summary>
            /// Property Indexer for EmployerLiabilityGLAccount
            /// </summary>
            public const int EmployerLiabilityGLAccount = 20;

            /// <summary>
            /// Property Indexer for WorkersCompensationCode
            /// </summary>
            public const int WorkersCompensationCode = 21;

            /// <summary>
            /// Property Indexer for CostCenterSegmentOne
            /// </summary>
            public const int CostCenterSegmentOne = 22;

            /// <summary>
            /// Property Indexer for CostCenterSegmentTwo
            /// </summary>
            public const int CostCenterSegmentTwo = 23;

            /// <summary>
            /// Property Indexer for CostCenterSegmentThree
            /// </summary>
            public const int CostCenterSegmentThree = 24;

            /// <summary>
            /// Property Indexer for DetailWasPartiallyTakenOrNo
            /// </summary>
            public const int DetailWasPartiallyTakenOrNo = 25;

            /// <summary>
            /// Property Indexer for WeeksWorked
            /// </summary>
            public const int WeeksWorked = 26;

            /// <summary>
            /// Property Indexer for EarnSubjToTaxNoCeiling
            /// </summary>
            public const int EarnSubjToTaxNoCeiling = 27;

            /// <summary>
            /// Property Indexer for EarnSubjToTax
            /// </summary>
            public const int EarnSubjToTax = 28;

            /// <summary>
            /// Property Indexer for NoCeilingTips
            /// </summary>
            public const int NoCeilingTips = 29;

            /// <summary>
            /// Property Indexer for CeilingTips
            /// </summary>
            public const int CeilingTips = 30;

            /// <summary>
            /// Property Indexer for TaxOnTips
            /// </summary>
            public const int TaxOnTips = 31;

            /// <summary>
            /// Property Indexer for UncollectedTaxOnTips
            /// </summary>
            public const int UncollectedTaxOnTips = 32;

            /// <summary>
            /// Property Indexer for PrintCategory
            /// </summary>
            public const int PrintCategory = 33;

            /// <summary>
            /// Property Indexer for PrintLineType
            /// </summary>
            public const int PrintLineType = 34;

            /// <summary>
            /// Property Indexer for PrintLineContents
            /// </summary>
            public const int PrintLineContents = 35;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TAXNONPER
            /// </summary>
            public const int TAXNONPER = 36;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TAXEARNBD
            /// </summary>
            public const int TAXEARNBD = 37;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for POOLEDTIPS
            /// </summary>
            public const int POOLEDTIPS = 38;

            /// <summary>
            /// Property Indexer for DetailDate
            /// </summary>
            public const int DetailDate = 39;

            /// <summary>
            /// Property Indexer for StartTime
            /// </summary>
            public const int StartTime = 40;

            /// <summary>
            /// Property Indexer for StopTime
            /// </summary>
            public const int StopTime = 41;

            /// <summary>
            /// Property Indexer for WorkersCompGroup
            /// </summary>
            public const int WorkersCompGroup = 42;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 43;

            /// <summary>
            /// Property Indexer for IncludedInFLSAOvertimeCalc
            /// </summary>
            public const int IncludedInFLSAOvertimeCalc = 44;

            /// <summary>
            /// Property Indexer for DaysWorked
            /// </summary>
            public const int DaysWorked = 45;

            /// <summary>
            /// Property Indexer for OvertimeSchedule
            /// </summary>
            public const int OvertimeSchedule = 46;

            /// <summary>
            /// Property Indexer for OvertimeHoursOverride
            /// </summary>
            public const int OvertimeHoursOverride = 47;

            /// <summary>
            /// Property Indexer for StraightTimeEarnings
            /// </summary>
            public const int StraightTimeEarnings = 48;

            /// <summary>
            /// Property Indexer for OvertimeRateMultiplier
            /// </summary>
            public const int OvertimeRateMultiplier = 49;

            /// <summary>
            /// Property Indexer for Jobs
            /// </summary>
            public const int Jobs = 50;

            /// <summary>
            /// Property Indexer for WorkClassificationCode
            /// </summary>
            public const int WorkClassificationCode = 51;

            /// <summary>
            /// Property Indexer for LocalTaxCode
            /// </summary>
            public const int LocalTaxCode = 52;

            /// <summary>
            /// Property Indexer for WCBase
            /// </summary>
            public const int WCBase = 53;

            /// <summary>
            /// Property Indexer for WCRate
            /// </summary>
            public const int WCRate = 54;

            /// <summary>
            /// Property Indexer for WCAssessment
            /// </summary>
            public const int WCAssessment = 55;

            /// <summary>
            /// Property Indexer for WCExpenseAccount
            /// </summary>
            public const int WCExpenseAccount = 56;

            /// <summary>
            /// Property Indexer for WCLiabilityAccount
            /// </summary>
            public const int WCLiabilityAccount = 57;

            /// <summary>
            /// Property Indexer for ChildSupportEFTStatus
            /// </summary>
            public const int ChildSupportEFTStatus = 58;

            /// <summary>
            /// Property Indexer for DistributionCode
            /// </summary>
            public const int DistributionCode = 59;

            /// <summary>
            /// Property Indexer for DistributionDescription
            /// </summary>
            public const int DistributionDescription = 60;

            /// <summary>
            /// Property Indexer for CostCenterSegmentFour
            /// </summary>
            public const int CostCenterSegmentFour = 61;

            /// <summary>
            /// Property Indexer for CostCenterSegmentFix
            /// </summary>
            public const int CostCenterSegmentFix = 62;

            /// <summary>
            /// Property Indexer for CostCenterSegmentSix
            /// </summary>
            public const int CostCenterSegmentSix = 63;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TAXNONDED
            /// </summary>
            public const int TAXNONDED = 64;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TAXREPAY
            /// </summary>
            public const int TAXREPAY = 65;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 100;

            /// <summary>
            /// Property Indexer for DetailType
            /// </summary>
            public const int DetailType = 101;

            /// <summary>
            /// Property Indexer for EmployeeCalculationMethod
            /// </summary>
            public const int EmployeeCalculationMethod = 102;

            /// <summary>
            /// Property Indexer for EmployerCalculationMethod
            /// </summary>
            public const int EmployerCalculationMethod = 103;

            /// <summary>
            /// Property Indexer for HistoryEntryTaxSide
            /// </summary>
            public const int HistoryEntryTaxSide = 104;

            /// <summary>
            /// Property Indexer for NoCeilingWage
            /// </summary>
            public const int NoCeilingWage = 105;

            /// <summary>
            /// Property Indexer for CeilingWage
            /// </summary>
            public const int CeilingWage = 106;

            /// <summary>
            /// Property Indexer for CheckDate
            /// </summary>
            public const int CheckDate = 107;


        }

        #endregion

    }
}