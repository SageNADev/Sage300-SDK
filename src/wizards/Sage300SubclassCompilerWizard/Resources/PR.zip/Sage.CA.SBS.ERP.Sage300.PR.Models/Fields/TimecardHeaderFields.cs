    // Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

    #region Namespace

    #endregion

    namespace Sage.CA.SBS.ERP.Sage300.PR.Models
    {
        /// <summary>
        /// Contains list of TimecardHeader Constants
        /// </summary>
        public partial class TimecardHeader
        {
            /// <summary>
            /// Entity Name
            /// </summary>
            public const string EntityName = "~~0031";


            #region Fields Properties

            /// <summary>
            /// Contains list of TimecardHeader Field Constants
            /// </summary>
            public class Fields
            {
                /// <summary>
                /// Property for Employee
                /// </summary>
                public const string Employee = "EMPLOYEE";

                /// <summary>
                /// Property for PeriodEndDate
                /// </summary>
                public const string PeriodEndDate = "PEREND";

                /// <summary>
                /// Property for Timecard
                /// </summary>
                public const string Timecard = "TIMECARD";

                /// <summary>
                /// Property for Description
                /// </summary>
                public const string Description = "TCARDDESC";

                /// <summary>
                /// Property for TimesLate
                /// </summary>
                public const string TimesLate = "TIMESLATE";

                /// <summary>
                /// Property for Reusable
                /// </summary>
                public const string Reusable = "REUSECARD";

                /// <summary>
                /// Property for ActiveFlag
                /// </summary>
                public const string ActiveFlag = "ACTIVE";

                /// <summary>
                /// Property for SeparateCheckFlag
                /// </summary>
                public const string SeparateCheckFlag = "SEPARATECK";

                /// <summary>
                /// Property for ProcessedFlag
                /// </summary>
                public const string ProcessedFlag = "PROCESSED";

                /// <summary>
                /// Property for RegularHours
                /// </summary>
                public const string RegularHours = "CREGHRS";

                /// <summary>
                /// Property for ShiftHours
                /// </summary>
                public const string ShiftHours = "CSHIFTHRS";

                /// <summary>
                /// Property for VacationHoursPaid
                /// </summary>
                public const string VacationHoursPaid = "CVACHRSP";

                /// <summary>
                /// Property for VacationHoursAccrued
                /// </summary>
                public const string VacationHoursAccrued = "CVACHRSA";

                /// <summary>
                /// Property for SickHoursPaid
                /// </summary>
                public const string SickHoursPaid = "CSICKHRSP";

                /// <summary>
                /// Property for SickHoursAccrued
                /// </summary>
                public const string SickHoursAccrued = "CSICKHRSA";

                /// <summary>
                /// Property for CompensatoryTimeHoursPaid
                /// </summary>
                public const string CompensatoryTimeHoursPaid = "CCOMPHRSP";

                /// <summary>
                /// Property for CompTimeHoursAccrued
                /// </summary>
                public const string CompTimeHoursAccrued = "CCOMPHRSA";

                /// <summary>
                /// Property for VacationDollarsPaid
                /// </summary>
                public const string VacationDollarsPaid = "CVACAMTP";

                /// <summary>
                /// Property for VacationDollarsAccrued
                /// </summary>
                public const string VacationDollarsAccrued = "CVACAMTA";

                /// <summary>
                /// Property for SickTimeDollarsPaid
                /// </summary>
                public const string SickTimeDollarsPaid = "CSICKAMTP";

                /// <summary>
                /// Property for SickTimeDollarsAccrued
                /// </summary>
                public const string SickTimeDollarsAccrued = "CSICKAMTA";

                /// <summary>
                /// Property for CompTimeDollarsPaid
                /// </summary>
                public const string CompTimeDollarsPaid = "CCOMPAMTP";

                /// <summary>
                /// Property for CompTimeDollarsAccrued
                /// </summary>
                public const string CompTimeDollarsAccrued = "CCOMPAMTA";

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property for CDISIHRSP
                /// </summary>
                public const string CDISIHRSP = "CDISIHRSP";

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property for CDISIHRSA
                /// </summary>
                public const string CDISIHRSA = "CDISIHRSA";

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property for CDISIAMTP
                /// </summary>
                public const string CDISIAMTP = "CDISIAMTP";

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property for CDISIAMTA
                /// </summary>
                public const string CDISIAMTA = "CDISIAMTA";

                /// <summary>
                /// Property for LastName
                /// </summary>
                public const string LastName = "LASTNAME";

                /// <summary>
                /// Property for FirstName
                /// </summary>
                public const string FirstName = "FIRSTNAME";

                /// <summary>
                /// Property for MiddleName
                /// </summary>
                public const string MiddleName = "MIDDLENAME";

                /// <summary>
                /// Property for TotalRegularHours
                /// </summary>
                public const string TotalRegularHours = "GREGHRS";

                /// <summary>
                /// Property for TotalShiftHours
                /// </summary>
                public const string TotalShiftHours = "GSHIFTHRS";

                /// <summary>
                /// Property for TotalVacationHoursPaid
                /// </summary>
                public const string TotalVacationHoursPaid = "GVACHRSP";

                /// <summary>
                /// Property for TotalVacationHoursAccrued
                /// </summary>
                public const string TotalVacationHoursAccrued = "GVACHRSA";

                /// <summary>
                /// Property for TotalSickHoursPaid
                /// </summary>
                public const string TotalSickHoursPaid = "GSICKHRSP";

                /// <summary>
                /// Property for TotalSickHoursAccrued
                /// </summary>
                public const string TotalSickHoursAccrued = "GSICKHRSA";

                /// <summary>
                /// Property for TotalCompTimeHoursPaid
                /// </summary>
                public const string TotalCompTimeHoursPaid = "GCOMPHRSP";

                /// <summary>
                /// Property for TotalCompTimeHoursAccrued
                /// </summary>
                public const string TotalCompTimeHoursAccrued = "GCOMPHRSA";

                /// <summary>
                /// Property for TotalVacationDollarsPaid
                /// </summary>
                public const string TotalVacationDollarsPaid = "GVACAMTP";

                /// <summary>
                /// Property for TotalVacationDollarsAccrued
                /// </summary>
                public const string TotalVacationDollarsAccrued = "GVACAMTA";

                /// <summary>
                /// Property for TotalSickTimeDollarsPaid
                /// </summary>
                public const string TotalSickTimeDollarsPaid = "GSICKAMTP";

                /// <summary>
                /// Property for TotalSickTimeDollarsAccrued
                /// </summary>
                public const string TotalSickTimeDollarsAccrued = "GSICKAMTA";

                /// <summary>
                /// Property for TotalCompTimeDollarsPaid
                /// </summary>
                public const string TotalCompTimeDollarsPaid = "GCOMPAMTP";

                /// <summary>
                /// Property for TotalCompTimeDollarsAccrued
                /// </summary>
                public const string TotalCompTimeDollarsAccrued = "GCOMPAMTA";

                /// <summary>
                /// Property for INTERNALUSEKeyAction
                /// </summary>
                public const string INTERNALUSEKeyAction = "KEYACTION";

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property for GDISIHRSP
                /// </summary>
                public const string GDISIHRSP = "GDISIHRSP";

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property for GDISIHRSA
                /// </summary>
                public const string GDISIHRSA = "GDISIHRSA";

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property for GDISIAMTP
                /// </summary>
                public const string GDISIAMTP = "GDISIAMTP";

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property for GDISIAMTA
                /// </summary>
                public const string GDISIAMTA = "GDISIAMTA";

                /// <summary>
                /// Property for HireDate
                /// </summary>
                public const string HireDate = "HIREDATE";

                /// <summary>
                /// Property for TerminationDate
                /// </summary>
                public const string TerminationDate = "FIREDATE";

                /// <summary>
                /// Property for PartTime
                /// </summary>
                public const string PartTime = "PARTTIME";

                /// <summary>
                /// Property for PayFrequency
                /// </summary>
                public const string PayFrequency = "PAYFREQ";

                /// <summary>
                /// Property for OvertimeSchedule
                /// </summary>
                public const string OvertimeSchedule = "OTSCHED";

                /// <summary>
                /// Property for CompTimeID
                /// </summary>
                public const string CompTimeID = "COMPTIME";

                /// <summary>
                /// Property for ShiftDifferentialSchedule
                /// </summary>
                public const string ShiftDifferentialSchedule = "SHIFTSCHED";

                /// <summary>
                /// Property for ShiftNumber
                /// </summary>
                public const string ShiftNumber = "SHIFTNUM";

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property for WORKPROV
                /// </summary>
                public const string WORKPROV = "WORKPROV";

                /// <summary>
                /// Property for EmploymentStatus
                /// </summary>
                public const string EmploymentStatus = "STATUS";

                /// <summary>
                /// Property for InactiveDate
                /// </summary>
                public const string InactiveDate = "INACTDATE";

                /// <summary>
                /// Property for ProcessCommandCode
                /// </summary>
                public const string ProcessCommandCode = "PROCESSCMD";

                /// <summary>
                /// Property for TotalOvertimeHours
                /// </summary>
                public const string TotalOvertimeHours = "GOTHOURS";

                /// <summary>
                /// Property for OvertimeCalculation
                /// </summary>
                public const string OvertimeCalculation = "OTCALCTYPE";

                /// <summary>
                /// Property for RegularHoursPerDay
                /// </summary>
                public const string RegularHoursPerDay = "HRSPERDAY";

                /// <summary>
                /// Property for WorkClassification
                /// </summary>
                public const string WorkClassification = "WORKCODE";

                /// <summary>
                /// Property for TotalJobs
                /// </summary>
                public const string TotalJobs = "TOTALJOBS";

                /// <summary>
                /// Property for SecurityFlag
                /// </summary>
                public const string SecurityFlag = "USERSEC";

                /// <summary>
                /// Property for CalcOTOnAWeeklyBasis
                /// </summary>
                public const string CalcOTOnAWeeklyBasis = "WKLYFLSA";

                /// <summary>
                /// Property for NumberOfOptionalFields
                /// </summary>
                public const string NumberOfOptionalFields = "VALUES";

                /// <summary>
                /// Property for OvertimeOverride
                /// </summary>
                public const string OvertimeOverride = "OTOVERRIDE";

                /// <summary>
                /// Property for OvertimeHours
                /// </summary>
                public const string OvertimeHours = "COTHOURS";

                /// <summary>
                /// Property for TimecardLines
                /// </summary>
                public const string TimecardLines = "TCDLINES";

                /// <summary>
                /// Property for JobRelated
                /// </summary>
                public const string JobRelated = "SWJOB";

                /// <summary>
                /// Property for SourceApplication
                /// </summary>
                public const string SourceApplication = "SRCEAPPL";

            }

            #endregion
            #region Index Properties

            /// <summary>
            /// Contains list of TimecardHeader Index Constants
            /// </summary>
            public class Index
            {
                /// <summary>
                /// Property Indexer for Employee
                /// </summary>
                public const int Employee = 1;

                /// <summary>
                /// Property Indexer for PeriodEndDate
                /// </summary>
                public const int PeriodEndDate = 2;

                /// <summary>
                /// Property Indexer for Timecard
                /// </summary>
                public const int Timecard = 3;

                /// <summary>
                /// Property Indexer for Description
                /// </summary>
                public const int Description = 4;

                /// <summary>
                /// Property Indexer for TimesLate
                /// </summary>
                public const int TimesLate = 5;

                /// <summary>
                /// Property Indexer for Reusable
                /// </summary>
                public const int Reusable = 6;

                /// <summary>
                /// Property Indexer for ActiveFlag
                /// </summary>
                public const int ActiveFlag = 7;

                /// <summary>
                /// Property Indexer for SeparateCheckFlag
                /// </summary>
                public const int SeparateCheckFlag = 8;

                /// <summary>
                /// Property Indexer for ProcessedFlag
                /// </summary>
                public const int ProcessedFlag = 9;

                /// <summary>
                /// Property Indexer for RegularHours
                /// </summary>
                public const int RegularHours = 11;

                /// <summary>
                /// Property Indexer for ShiftHours
                /// </summary>
                public const int ShiftHours = 12;

                /// <summary>
                /// Property Indexer for VacationHoursPaid
                /// </summary>
                public const int VacationHoursPaid = 13;

                /// <summary>
                /// Property Indexer for VacationHoursAccrued
                /// </summary>
                public const int VacationHoursAccrued = 14;

                /// <summary>
                /// Property Indexer for SickHoursPaid
                /// </summary>
                public const int SickHoursPaid = 15;

                /// <summary>
                /// Property Indexer for SickHoursAccrued
                /// </summary>
                public const int SickHoursAccrued = 16;

                /// <summary>
                /// Property Indexer for CompensatoryTimeHoursPaid
                /// </summary>
                public const int CompensatoryTimeHoursPaid = 17;

                /// <summary>
                /// Property Indexer for CompTimeHoursAccrued
                /// </summary>
                public const int CompTimeHoursAccrued = 18;

                /// <summary>
                /// Property Indexer for VacationDollarsPaid
                /// </summary>
                public const int VacationDollarsPaid = 19;

                /// <summary>
                /// Property Indexer for VacationDollarsAccrued
                /// </summary>
                public const int VacationDollarsAccrued = 20;

                /// <summary>
                /// Property Indexer for SickTimeDollarsPaid
                /// </summary>
                public const int SickTimeDollarsPaid = 21;

                /// <summary>
                /// Property Indexer for SickTimeDollarsAccrued
                /// </summary>
                public const int SickTimeDollarsAccrued = 22;

                /// <summary>
                /// Property Indexer for CompTimeDollarsPaid
                /// </summary>
                public const int CompTimeDollarsPaid = 23;

                /// <summary>
                /// Property Indexer for CompTimeDollarsAccrued
                /// </summary>
                public const int CompTimeDollarsAccrued = 24;

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property Indexer for CDISIHRSP
                /// </summary>
                public const int CDISIHRSP = 25;

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property Indexer for CDISIHRSA
                /// </summary>
                public const int CDISIHRSA = 26;

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property Indexer for CDISIAMTP
                /// </summary>
                public const int CDISIAMTP = 27;

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property Indexer for CDISIAMTA
                /// </summary>
                public const int CDISIAMTA = 28;

                /// <summary>
                /// Property Indexer for LastName
                /// </summary>
                public const int LastName = 29;

                /// <summary>
                /// Property Indexer for FirstName
                /// </summary>
                public const int FirstName = 30;

                /// <summary>
                /// Property Indexer for MiddleName
                /// </summary>
                public const int MiddleName = 31;

                /// <summary>
                /// Property Indexer for TotalRegularHours
                /// </summary>
                public const int TotalRegularHours = 32;

                /// <summary>
                /// Property Indexer for TotalShiftHours
                /// </summary>
                public const int TotalShiftHours = 33;

                /// <summary>
                /// Property Indexer for TotalVacationHoursPaid
                /// </summary>
                public const int TotalVacationHoursPaid = 34;

                /// <summary>
                /// Property Indexer for TotalVacationHoursAccrued
                /// </summary>
                public const int TotalVacationHoursAccrued = 35;

                /// <summary>
                /// Property Indexer for TotalSickHoursPaid
                /// </summary>
                public const int TotalSickHoursPaid = 36;

                /// <summary>
                /// Property Indexer for TotalSickHoursAccrued
                /// </summary>
                public const int TotalSickHoursAccrued = 37;

                /// <summary>
                /// Property Indexer for TotalCompTimeHoursPaid
                /// </summary>
                public const int TotalCompTimeHoursPaid = 38;

                /// <summary>
                /// Property Indexer for TotalCompTimeHoursAccrued
                /// </summary>
                public const int TotalCompTimeHoursAccrued = 39;

                /// <summary>
                /// Property Indexer for TotalVacationDollarsPaid
                /// </summary>
                public const int TotalVacationDollarsPaid = 40;

                /// <summary>
                /// Property Indexer for TotalVacationDollarsAccrued
                /// </summary>
                public const int TotalVacationDollarsAccrued = 41;

                /// <summary>
                /// Property Indexer for TotalSickTimeDollarsPaid
                /// </summary>
                public const int TotalSickTimeDollarsPaid = 42;

                /// <summary>
                /// Property Indexer for TotalSickTimeDollarsAccrued
                /// </summary>
                public const int TotalSickTimeDollarsAccrued = 43;

                /// <summary>
                /// Property Indexer for TotalCompTimeDollarsPaid
                /// </summary>
                public const int TotalCompTimeDollarsPaid = 44;

                /// <summary>
                /// Property Indexer for TotalCompTimeDollarsAccrued
                /// </summary>
                public const int TotalCompTimeDollarsAccrued = 45;

                /// <summary>
                /// Property Indexer for INTERNALUSEKeyAction
                /// </summary>
                public const int INTERNALUSEKeyAction = 46;

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property Indexer for GDISIHRSP
                /// </summary>
                public const int GDISIHRSP = 47;

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property Indexer for GDISIHRSA
                /// </summary>
                public const int GDISIHRSA = 48;

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property Indexer for GDISIAMTP
                /// </summary>
                public const int GDISIAMTP = 49;

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property Indexer for GDISIAMTA
                /// </summary>
                public const int GDISIAMTA = 50;

                /// <summary>
                /// Property Indexer for HireDate
                /// </summary>
                public const int HireDate = 51;

                /// <summary>
                /// Property Indexer for TerminationDate
                /// </summary>
                public const int TerminationDate = 52;

                /// <summary>
                /// Property Indexer for PartTime
                /// </summary>
                public const int PartTime = 53;

                /// <summary>
                /// Property Indexer for PayFrequency
                /// </summary>
                public const int PayFrequency = 54;

                /// <summary>
                /// Property Indexer for OvertimeSchedule
                /// </summary>
                public const int OvertimeSchedule = 55;

                /// <summary>
                /// Property Indexer for CompTimeID
                /// </summary>
                public const int CompTimeID = 56;

                /// <summary>
                /// Property Indexer for ShiftDifferentialSchedule
                /// </summary>
                public const int ShiftDifferentialSchedule = 57;

                /// <summary>
                /// Property Indexer for ShiftNumber
                /// </summary>
                public const int ShiftNumber = 58;

                // TODO The naming convention of this property has to be manually evaluated
                /// <summary>
                /// Property Indexer for WORKPROV
                /// </summary>
                public const int WORKPROV = 59;

                /// <summary>
                /// Property Indexer for EmploymentStatus
                /// </summary>
                public const int EmploymentStatus = 60;

                /// <summary>
                /// Property Indexer for InactiveDate
                /// </summary>
                public const int InactiveDate = 61;

                /// <summary>
                /// Property Indexer for ProcessCommandCode
                /// </summary>
                public const int ProcessCommandCode = 62;

                /// <summary>
                /// Property Indexer for TotalOvertimeHours
                /// </summary>
                public const int TotalOvertimeHours = 63;

                /// <summary>
                /// Property Indexer for OvertimeCalculation
                /// </summary>
                public const int OvertimeCalculation = 64;

                /// <summary>
                /// Property Indexer for RegularHoursPerDay
                /// </summary>
                public const int RegularHoursPerDay = 65;

                /// <summary>
                /// Property Indexer for WorkClassification
                /// </summary>
                public const int WorkClassification = 66;

                /// <summary>
                /// Property Indexer for TotalJobs
                /// </summary>
                public const int TotalJobs = 67;

                /// <summary>
                /// Property Indexer for SecurityFlag
                /// </summary>
                public const int SecurityFlag = 68;

                /// <summary>
                /// Property Indexer for CalcOTOnAWeeklyBasis
                /// </summary>
                public const int CalcOTOnAWeeklyBasis = 69;

                /// <summary>
                /// Property Indexer for NumberOfOptionalFields
                /// </summary>
                public const int NumberOfOptionalFields = 75;

                /// <summary>
                /// Property Indexer for OvertimeOverride
                /// </summary>
                public const int OvertimeOverride = 76;

                /// <summary>
                /// Property Indexer for OvertimeHours
                /// </summary>
                public const int OvertimeHours = 77;

                /// <summary>
                /// Property Indexer for TimecardLines
                /// </summary>
                public const int TimecardLines = 78;

                /// <summary>
                /// Property Indexer for JobRelated
                /// </summary>
                public const int JobRelated = 79;

                /// <summary>
                /// Property Indexer for SourceApplication
                /// </summary>
                public const int SourceApplication = 80;


            }

            #endregion

        }
    }