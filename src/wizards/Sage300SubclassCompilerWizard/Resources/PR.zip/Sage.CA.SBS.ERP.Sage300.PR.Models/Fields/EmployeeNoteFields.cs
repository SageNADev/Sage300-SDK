// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeNote Constants
    /// </summary>
    public partial class EmployeeNote
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0053";


        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeNote Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for Notes
            /// </summary>
            public const string Notes = "NOTES";

            /// <summary>
            /// Property for TemplateEmployee
            /// </summary>
            public const string TemplateEmployee = "TEMPLATE";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeNote Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for Notes
            /// </summary>
            public const int Notes = 3;

            /// <summary>
            /// Property Indexer for TemplateEmployee
            /// </summary>
            public const int TemplateEmployee = 10;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 11;


        }

        #endregion

    }
}
