// Copyright (c) 2024 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of Employee Selection List Constants
    /// </summary>
    public partial class EmployeeSelectionListDetailModel
    {
        /// <summary>
        /// Entity Name with prefix added later
        /// </summary>
        public const string EntityName = "~~0046";

        #region Fields Properties

        /// <summary>
        /// Contains list of Employee Selection List Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee Selection List
            /// </summary>
            public const string EmployeeSelectionList = "EMPLISTID";

            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of Employe Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee Selection List
            /// </summary>
            public const int EmployeeSelectionList = 1;

            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 2;


        }

        #endregion

    }
}