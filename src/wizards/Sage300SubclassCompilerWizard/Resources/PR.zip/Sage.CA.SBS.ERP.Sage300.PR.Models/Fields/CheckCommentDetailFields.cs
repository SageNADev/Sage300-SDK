// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of CheckCommentDetail Constants
    /// </summary>
    public partial class CheckCommentDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0052";

        #region Fields Properties

        /// <summary>
        /// Contains list of CheckCommentDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "PEREND";

            /// <summary>
            /// Property for EntrySequence
            /// </summary>
            public const string EntrySequence = "ENTRYSEQ";

            /// <summary>
            /// Property for Uniquifier
            /// </summary>
            public const string Uniquifier = "UNIQUE";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of CheckCommentDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 2;

            /// <summary>
            /// Property Indexer for EntrySequence
            /// </summary>
            public const int EntrySequence = 3;

            /// <summary>
            /// Property Indexer for Uniquifier
            /// </summary>
            public const int Uniquifier = 4;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 5;


        }

        #endregion

    }
}