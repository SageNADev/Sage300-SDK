// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeActivity Constants
    /// </summary>
    public partial class EmployeeActivity
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0104";

        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeActivity Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for ProcessAction
            /// </summary>
            public const string ProcessAction = "ACTION";

            /// <summary>
            /// Property for Month
            /// </summary>
            public const string Month = "MONTH";

            /// <summary>
            /// Property for DocumentType
            /// </summary>
            public const string DocumentType = "ENTRYTYPE";

            /// <summary>
            /// Property for PRPostStatus
            /// </summary>
            public const string PostingStatus = "PRPOSTSTAT";

            /// <summary>
            /// Property for FromDate
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for ToDate
            /// </summary>
            public const string ToDate = "TODATE";

            /// <summary>
            /// Property for RegularEarningsMTD
            /// </summary>
            public const string RegularEarningsMTD = "REGERNMTD";

            /// <summary>
            /// Property for RegularEarningsQTD
            /// </summary>
            public const string RegularEarningsQTD = "REGERNQTD";

            /// <summary>
            /// Property for RegularEarningsYTD
            /// </summary>
            public const string RegularEarningsYTD = "REGERNYTD";

            /// <summary>
            /// Property for OverTimeEarningsMTD
            /// </summary>
            public const string OverTimeEarningsMTD = "OTERNMTD";

            /// <summary>
            /// Property for OverTimeEarningsQTD
            /// </summary>
            public const string OverTimeEarningsQTD = "OTERNQTD";

            /// <summary>
            /// Property for OverTimeEarningsYTD
            /// </summary>
            public const string OverTimeEarningsYTD = "OTERNYTD";

            /// <summary>
            /// Property for ShiftEarningsMTD
            /// </summary>
            public const string ShiftEarningsMTD = "SHFTERNMTD";

            /// <summary>
            /// Property for ShiftEarningsQTD
            /// </summary>
            public const string ShiftEarningsQTD = "SHFTERNQTD";

            /// <summary>
            /// Property for ShiftEarningsYTD
            /// </summary>
            public const string ShiftEarningsYTD = "SHFTERNYTD";

            /// <summary>
            /// Property for AccrualsPaidMTD
            /// </summary>
            public const string AccrualsPaidMTD = "ACCPAIDMTD";

            /// <summary>
            /// Property for AccrualsEarningsQTD
            /// </summary>
            public const string AccrualsPaidQTD = "ACCPAIDQTD";

            /// <summary>
            /// Property for AccrualsEarningsYTD
            /// </summary>
            public const string AccrualsPaidYTD = "ACCPAIDYTD";

            /// <summary>
            /// Property for CashBenefitsMTD
            /// </summary>
            public const string CashBenefitsMTD = "CASHBENMTD";

            /// <summary>
            /// Property for CashBenefitsQTD
            /// </summary>
            public const string CashBenefitsQTD = "CASHBENQTD";

            /// <summary>
            /// Property for CashBenefitsMTD
            /// </summary>
            public const string CashBenefitsYTD = "CASHBENYTD";

            /// <summary>
            /// Property for TotalEarningsMTD
            /// </summary>
            public const string TotalEarningsMTD = "TOTERNMTD";

            /// <summary>
            /// Property for TotalEarningsQTD
            /// </summary>
            public const string TotalEarningsQTD = "TOTERNQTD";

            /// <summary>
            /// Property for TotalEarningsYTD
            /// </summary>
            public const string TotalEarningsYTD = "TOTERNYTD";

            /// <summary>
            /// Property for ExpenseReimbursementsMTD
            /// </summary>
            public const string ExpenseReimbursementsMTD = "EXPRIMBMTD";

            /// <summary>
            /// Property for ExpenseReimbursementsQTD
            /// </summary>
            public const string ExpenseReimbursementsQTD = "EXPRIMBQTD";

            /// <summary>
            /// Property for ExpenseReimbursementsYTD
            /// </summary>
            public const string ExpenseReimbursementsYTD = "EXPRIMBYTD";

            /// <summary>
            /// Property for CashAdvancesMTD
            /// </summary>
            public const string CashAdvancesMTD = "CASHADVMTD";

            /// <summary>
            /// Property for CashAdvancesMTD
            /// </summary>
            public const string CashAdvancesQTD = "CASHADVQTD";

            /// <summary>
            /// Property for CashAdvancesMTD
            /// </summary>
            public const string CashAdvancesYTD = "CASHADVYTD";

            /// <summary>
            /// Property for DeductionsAndTaxesMTD
            /// </summary>
            public const string DeductionsAndTaxesMTD = "DEDUCTMTD";

            /// <summary>
            /// Property for DeductionsAndTaxesQTD
            /// </summary>
            public const string DeductionsAndTaxesQTD = "DEDUCTQTD";

            /// <summary>
            /// Property for DeductionsAndTaxesYTD
            /// </summary>
            public const string DeductionsAndTaxesYTD = "DEDUCTYTD";

            /// <summary>
            /// Property for NetPayMTD
            /// </summary>
            public const string NetPayMTD = "NETPAYMTD";

            /// <summary>
            /// Property for NetPayQTD
            /// </summary>
            public const string NetPayQTD = "NETPAYQTD";

            /// <summary>
            /// Property for NetPayYTD
            /// </summary>
            public const string NetPayYTD = "NETPAYYTD";

            /// <summary>
            /// Property for NonCashIncomeMTD
            /// </summary>
            public const string NonCashIncomeMTD = "NCASHIMTD";

            /// <summary>
            /// Property for NonCashIncomeQTD
            /// </summary>
            public const string NonCashIncomeQTD = "NCASHIQTD";

            /// <summary>
            /// Property for NonCashIncomeYTD
            /// </summary>
            public const string NonCashIncomeYTD = "NCASHIYTD";

            /// <summary>
            /// Property for NonCashAdvancesMTD
            /// </summary>
            public const string NonCashAdvancesMTD = "NCASHAMTD";

            /// <summary>
            /// Property for NonCashAdvancesQTD
            /// </summary>
            public const string NonCashAdvancesQTD = "NCASHAQTD";

            /// <summary>
            /// Property for NonCashAdvancesYTD
            /// </summary>
            public const string NonCashAdvancesYTD = "NCASHAYTD";

            /// <summary>
            /// Property for AccruedAmountsMTD
            /// </summary>
            public const string AccruedAmountsMTD = "ACCAMTMTD";

            /// <summary>
            /// Property for AccruedAmountsQTD
            /// </summary>
            public const string AccruedAmountsQTD = "ACCAMTQTD";

            /// <summary>
            /// Property for AccruedAmountsYTD
            /// </summary>
            public const string AccruedAmountsYTD = "ACCAMTYTD";

            /// <summary>
            /// Property for AccruedHoursMTD
            /// </summary>
            public const string AccruedHoursMTD = "ACCHRSMTD";

            /// <summary>
            /// Property for AccruedHoursQTD
            /// </summary>
            public const string AccruedHoursQTD = "ACCHRSQTD";

            /// <summary>
            /// Property for AccruedHoursYTD
            /// </summary>
            public const string AccruedHoursYTD = "ACCHRSYTD";

            /// <summary>
            /// Property for AccruedHoursPaidMTD
            /// </summary>
            public const string AccruedHoursPaidMTD = "ACCHRSPMTD";

            /// <summary>
            /// Property for AccruedHoursPaidQTD
            /// </summary>
            public const string AccruedHoursPaidQTD = "ACCHRSPQTD";

            /// <summary>
            /// Property for AccruedHoursPaidYTD
            /// </summary>
            public const string AccruedHoursPaidYTD = "ACCHRSPYTD";

            /// <summary>
            /// Property for RegularHoursPaidMTD
            /// </summary>
            public const string RegularHoursPaidMTD = "REGHRSMTD";

            /// <summary>
            /// Property for RegularHoursPaidQTD
            /// </summary>
            public const string RegularHoursPaidQTD = "REGHRSQTD";

            /// <summary>
            /// Property for RegularHoursPaidYTD
            /// </summary>
            public const string RegularHoursPaidYTD = "REGHRSYTD";

            /// <summary>
            /// Property for Year
            /// </summary>
            public const string Year = "YEAR";

            /// <summary>
            /// Property for OvertimeHoursPaidMTD
            /// </summary>
            public const string OvertimeHoursPaidMTD = "OTHOURSMTD";

            /// <summary>
            /// Property for OvertimeHoursPaidQTD
            /// </summary>
            public const string OvertimeHoursPaidQTD = "OTHOURSQTD";

            /// <summary>
            /// Property for OvertimeHoursPaidYTD
            /// </summary>
            public const string OvertimeHoursPaidYTD = "OTHOURSYTD";

            /// <summary>
            /// Property for ShiftHoursPaidMTD
            /// </summary>
            public const string ShiftHoursPaidMTD = "SHFTHRSMTD";

            /// <summary>
            /// Property for ShiftHoursPaidQTD
            /// </summary>
            public const string ShiftHoursPaidQTD = "SHFTHRSQTD";

            /// <summary>
            /// Property for ShiftHoursPaidYTD
            /// </summary>
            public const string ShiftHoursPaidYTD = "SHFTHRSYTD";

            /// <summary>
            /// Property for TotalHoursPaidMTD
            /// </summary>
            public const string TotalHoursPaidMTD = "TOTHRSMTD";

            /// <summary>
            /// Property for TotalHoursPaidQTD
            /// </summary>
            public const string TotalHoursPaidQTD = "TOTHRSQTD";

            /// <summary>
            /// Property for TotalHoursPaidYTD
            /// </summary>
            public const string TotalHoursPaidYTD = "TOTHRSYTD";

            /// <summary>
            /// Property for TotalChecks
            /// </summary>
            public const string TotalChecks = "TOTCHEQS";

            /// <summary>
            /// Property for TotalEarnings
            /// </summary>
            public const string TotalEarnings = "TOTEARNS";

            /// <summary>
            /// Property for TotalTaxes
            /// </summary>
            public const string TotalTaxes = "TOTTAXES";

            /// <summary>
            /// Property for TotalDeductions
            /// </summary>
            public const string TotalDeductions = "TOTDEDS";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "PEREND";

            /// <summary>
            /// Property for EntrySequence
            /// </summary>
            public const string EntrySequence = "ENTRYSEQ";

            /// <summary>
            /// Property for TotalDeductions
            /// </summary>
            public const string TotalCashAdvances = "TOTCASHADV";

            /// <summary>
            /// Property for TotalAdvanceRepayments
            /// </summary>
            public const string TotalAdvanceRepayments = "TOTADVREPY";

            /// <summary>
            /// Property for AccruedVacAmountsMTD
            /// </summary>
            public const string AccruedVacAmountsMTD = "VACAMTMTD";

            /// <summary>
            /// Property for AccruedVacAmountsQTD
            /// </summary>
            public const string AccruedVacAmountsQTD = "VACAMTQTD";

            /// <summary>
            /// Property for AccruedVacAmountsYTD
            /// </summary>
            public const string AccruedVacAmountsYTD = "VACAMTYTD";

            /// <summary>
            /// Property for VacationAmtPaidMTD
            /// </summary>
            public const string VacationAmtPaidMTD = "VACPAIDMTD";

            /// <summary>
            /// Property for VacationAmtPaidQTD
            /// </summary>
            public const string VacationAmtPaidQTD = "VACPAIDQTD";

            /// <summary>
            /// Property for VacationAmtPaidYTD
            /// </summary>
            public const string VacationAmtPaidYTD = "VACPAIDYTD";

            /// <summary>
            /// Property for AccruedVacHoursMTD
            /// </summary>
            public const string AccruedVacHoursMTD = "VACHRSMTD";

            /// <summary>
            /// Property for AccruedVacHoursQTD
            /// </summary>
            public const string AccruedVacHoursQTD = "VACHRSQTD";

            /// <summary>
            /// Property for AccruedVacHoursYTD
            /// </summary>
            public const string AccruedVacHoursYTD = "VACHRSYTD";

            /// <summary>
            /// Property for AccruedVacHoursPaidMTD
            /// </summary>
            public const string AccruedVacHoursPaidMTD = "VACHRSPMTD";

            /// <summary>
            /// Property for AccruedVacHoursPaidQTD
            /// </summary>
            public const string AccruedVacHoursPaidQTD = "VACHRSPQTD";

            /// <summary>
            /// Property for AccruedVacHoursPaidYTD
            /// </summary>
            public const string AccruedVacHoursPaidYTD = "VACHRSPYTD";

            /// <summary>
            /// Property for AccruedSickAmountsMTD
            /// </summary>
            public const string AccruedSickAmountsMTD = "SICAMTMTD";

            /// <summary>
            /// Property for AccruedSickAmountsMTD
            /// </summary>
            public const string AccruedSickAmountsQTD = "SICAMTQTD ";

            /// <summary>
            /// Property for AccruedSickAmountsYTD
            /// </summary>
            public const string AccruedSickAmountsYTD = "SICAMTYTD";

            /// <summary>
            /// Property for SickAmtPaidMTD
            /// </summary>
            public const string SickAmtPaidMTD = "SICPAIDMTD";

            /// <summary>
            /// Property for SickAmtPaidQTD
            /// </summary>
            public const string SickAmtPaidQTD = "SICPAIDQTD ";

            /// <summary>
            /// Property for SickAmtPaidYTD
            /// </summary>
            public const string SickAmtPaidYTD = "SICPAIDYTD";

            /// <summary>
            /// Property for AccruedSickHoursMTD
            /// </summary>
            public const string AccruedSickHoursMTD = "SICHRSMTD";

            /// <summary>
            /// Property for AccruedSickHoursQTD
            /// </summary>
            public const string AccruedSickHoursQTD = "SICHRSQTD ";

            /// <summary>
            /// Property for AccruedSickHoursYTD
            /// </summary>
            public const string AccruedSickHoursYTD = "SICHRSYTD";

            /// <summary>
            /// Property for AccruedSickHoursPaidMTD
            /// </summary>
            public const string AccruedSickHoursPaidMTD = "SICHRSPMTD";

            /// <summary>
            /// Property for AccruedSickHoursQTD
            /// </summary>
            public const string AccruedSickHoursPaidQTD = "SICHRSPQTD ";

            /// <summary>
            /// Property for AccruedSickHoursPaidYTD
            /// </summary>
            public const string AccruedSickHoursPaidYTD = "SICHRSPYTD";

            /// <summary>
            /// Property for AccruedCompTimeAmtMTD
            /// </summary>
            public const string AccruedCompTimeAmtMTD = "BNKAMTMTD";

            /// <summary>
            /// Property for AccruedCompTimeAmtQTD
            /// </summary>
            public const string AccruedCompTimeAmtQTD = "BNKAMTQTD ";

            /// <summary>
            /// Property for AccruedCompTimeAmtYTD
            /// </summary>
            public const string AccruedCompTimeAmtYTD = "BNKAMTQTD";

            /// <summary>
            /// Property for CompTimeAmtPaidMTD
            /// </summary>
            public const string CompTimeAmtPaidMTD = "BNKPAIDMTD";

            /// <summary>
            /// Property for CompTimeAmtPaidQTD
            /// </summary>
            public const string CompTimeAmtPaidQTD = "BNKPAIDQTD ";

            /// <summary>
            /// Property for CompTimeAmtPaidYTD
            /// </summary>
            public const string CompTimeAmtPaidYTD = "BNKPAIDYTD";

            /// <summary>
            /// Property for AccruedCompHoursMTD
            /// </summary>
            public const string AccruedCompHoursMTD = "BNKHRSMTD";

            /// <summary>
            /// Property for AccruedCompHoursQTD
            /// </summary>
            public const string AccruedCompHoursQTD = "BNKHRSQTD ";

            /// <summary>
            /// Property for AccruedCompHoursYTD
            /// </summary>
            public const string AccruedCompHoursYTD = "BNKHRSYTD";

            /// <summary>
            /// Property for AccruedCompHoursPaidMTD
            /// </summary>
            public const string AccruedCompHoursPaidMTD = "BNKHRSPMTD";

            /// <summary>
            /// Property for AccruedCompHoursPaidQTD
            /// </summary>
            public const string AccruedCompHoursPaidQTD = "BNKHRSPQTD ";

            /// <summary>
            /// Property for AccruedCompHoursPaidYTD
            /// </summary>
            public const string AccruedCompHoursPaidYTD = "BNKHRSPYTD";

            /// <summary>
            /// Property for DummyField
            /// </summary>
            public const string DummyField = "DUMMY";
        }
        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeActivity Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for ProcessAction
            /// </summary>
            public const int ProcessAction = 2;

            /// <summary>
            /// Property Indexer for Month
            /// </summary>
            public const int Month = 3;

            /// <summary>
            /// Property Indexer for Year
            /// </summary>
            public const int Year = 4;

            /// <summary>
            /// Property Indexer for DocumentType
            /// </summary>
            public const int DocumentType = 5;

            /// <summary>
            /// Property Indexer for PRPostStatus
            /// </summary>
            public const int PostingStatus = 6;

            /// <summary>
            /// Property Indexer for FromDate
            /// </summary>
            public const int FromDate = 7;

            /// <summary>
            /// Property Indexer for ToDate
            /// </summary>
            public const int ToDate = 8;

            /// <summary>
            /// Property Indexer for RegularEarningsMTD
            /// </summary>
            public const int RegularEarningsMTD = 9;

            /// <summary>
            /// Property Indexer for RegularEarningsQTD
            /// </summary>
            public const int RegularEarningsQTD = 10;

            /// <summary>
            /// Property Indexer for RegularEarningsYTD
            /// </summary>
            public const int RegularEarningsYTD = 11;

            /// <summary>
            /// Property Indexer for OverTimeEarningsMTD
            /// </summary>
            public const int OverTimeEarningsMTD = 12;

            /// <summary>
            /// Property Indexer for OverTimeEarningsQTD
            /// </summary>
            public const int OverTimeEarningsQTD = 13;

            /// <summary>
            /// Property Indexer for OverTimeEarningsYTD
            /// </summary>
            public const int OverTimeEarningsYTD = 14;

            /// <summary>
            /// Property Indexer for ShiftEarningsMTD
            /// </summary>
            public const int ShiftEarningsMTD = 15;

            /// <summary>
            /// Property Indexer for ShiftEarningsQTD
            /// </summary>
            public const int ShiftEarningsQTD = 16;

            /// <summary>
            /// Property Indexer for ShiftEarningsYTD
            /// </summary>
            public const int ShiftEarningsYTD = 17;

            /// <summary>
            /// Property Indexer for AccrualsPaidMTD
            /// </summary>
            public const int AccrualsPaidMTD = 18;

            /// <summary>
            /// Property Indexer for AccrualsEarningsQTD
            /// </summary>
            public const int AccrualsPaidQTD = 19;

            /// <summary>
            /// Property Indexer for AccrualsEarningsYTD
            /// </summary>
            public const int AccrualsPaidYTD = 20;

            /// <summary>
            /// Property Indexer for CashBenefitsMTD
            /// </summary>
            public const int CashBenefitsMTD = 21;

            /// <summary>
            /// Property Indexer for CashBenefitsQTD
            /// </summary>
            public const int CashBenefitsQTD = 22;

            /// <summary>
            /// Property Indexer for CashBenefitsMTD
            /// </summary>
            public const int CashBenefitsYTD = 23;

            /// <summary>
            /// Property Indexer for TotalEarningsMTD
            /// </summary>
            public const int TotalEarningsMTD = 24;

            /// <summary>
            /// Property Indexer for TotalEarningsQTD
            /// </summary>
            public const int TotalEarningsQTD = 25;

            /// <summary>
            /// Property Indexer for TotalEarningsYTD
            /// </summary>
            public const int TotalEarningsYTD = 26;

            /// <summary>
            /// Property Indexer for ExpenseReimbursementsMTD
            /// </summary>
            public const int ExpenseReimbursementsMTD = 27;

            /// <summary>
            /// Property Indexer for ExpenseReimbursementsQTD
            /// </summary>
            public const int ExpenseReimbursementsQTD = 28;

            /// <summary>
            /// Property Indexer for ExpenseReimbursementsYTD
            /// </summary>
            public const int ExpenseReimbursementsYTD = 29;

            /// <summary>
            /// Property Indexer for CashAdvancesMTD
            /// </summary>
            public const int CashAdvancesMTD = 30;

            /// <summary>
            /// Property Indexer for CashAdvancesMTD
            /// </summary>
            public const int CashAdvancesQTD = 31;

            /// <summary>
            /// Property Indexer for CashAdvancesMTD
            /// </summary>
            public const int CashAdvancesYTD = 32;

            /// <summary>
            /// Property Indexer for DeductionsAndTaxesMTD
            /// </summary>
            public const int DeductionsAndTaxesMTD = 33;

            /// <summary>
            /// Property Indexer for DeductionsAndTaxesQTD
            /// </summary>
            public const int DeductionsAndTaxesQTD = 34;

            /// <summary>
            /// Property Indexer for DeductionsAndTaxesYTD
            /// </summary>
            public const int DeductionsAndTaxesYTD = 35;

            /// <summary>
            /// Property Indexer for NetPayMTD
            /// </summary>
            public const int NetPayMTD = 36;

            /// <summary>
            /// Property Indexer for NetPayQTD
            /// </summary>
            public const int NetPayQTD = 37;

            /// <summary>
            /// Property Indexer for NetPayYTD
            /// </summary>
            public const int NetPayYTD = 38;

            /// <summary>
            /// Property Indexer for NonCashIncomeMTD
            /// </summary>
            public const int NonCashIncomeMTD = 39;

            /// <summary>
            /// Property Indexer for NonCashIncomeQTD
            /// </summary>
            public const int NonCashIncomeQTD = 40;

            /// <summary>
            /// Property Indexer for NonCashIncomeYTD
            /// </summary>
            public const int NonCashIncomeYTD = 41;

            /// <summary>
            /// Property Indexer for NonCashAdvancesMTD
            /// </summary>
            public const int NonCashAdvancesMTD = 42;

            /// <summary>
            /// Property Indexer for NonCashAdvancesQTD
            /// </summary>
            public const int NonCashAdvancesQTD = 43;

            /// <summary>
            /// Property Indexer for NonCashAdvancesYTD
            /// </summary>
            public const int NonCashAdvancesYTD = 44;

            /// <summary>
            /// Property Indexer for AccruedAmountsMTD
            /// </summary>
            public const int AccruedAmountsMTD = 45;

            /// <summary>
            /// Property Indexer for AccruedAmountsQTD
            /// </summary>
            public const int AccruedAmountsQTD = 46;

            /// <summary>
            /// Property Indexer for AccruedAmountsYTD
            /// </summary>
            public const int AccruedAmountsYTD = 47;

            /// <summary>
            /// Property Indexer for AccruedHoursMTD
            /// </summary>
            public const int AccruedHoursMTD = 48;

            /// <summary>
            /// Property Indexer for AccruedHoursQTD
            /// </summary>
            public const int AccruedHoursQTD = 49;

            /// <summary>
            /// Property Indexer for AccruedHoursYTD
            /// </summary>
            public const int AccruedHoursYTD = 50;

            /// <summary>
            /// Property Indexer for AccruedHoursPaidMTD
            /// </summary>
            public const int AccruedHoursPaidMTD = 51;

            /// <summary>
            /// Property Indexer for AccruedHoursPaidQTD
            /// </summary>
            public const int AccruedHoursPaidQTD = 52;

            /// <summary>
            /// Property Indexer for AccruedHoursPaidYTD
            /// </summary>
            public const int AccruedHoursPaidYTD = 53;

            /// <summary>
            /// Property Indexer for RegularHoursPaidMTD
            /// </summary>
            public const int RegularHoursPaidMTD = 54;

            /// <summary>
            /// Property Indexer for RegularHoursPaidQTD
            /// </summary>
            public const int RegularHoursPaidQTD = 55;

            /// <summary>
            /// Property Indexer for RegularHoursPaidYTD
            /// </summary>
            public const int RegularHoursPaidYTD = 56;

            /// <summary>
            /// Property Indexer for OvertimeHoursPaidMTD
            /// </summary>
            public const int OvertimeHoursPaidMTD = 57;

            /// <summary>
            /// Property Indexer for OvertimeHoursPaidQTD
            /// </summary>
            public const int OvertimeHoursPaidQTD = 58;

            /// <summary>
            /// Property Indexer for OvertimeHoursPaidYTD
            /// </summary>
            public const int OvertimeHoursPaidYTD = 59;

            /// <summary>
            /// Property Indexer for ShiftHoursPaidMTD
            /// </summary>
            public const int ShiftHoursPaidMTD = 60;

            /// <summary>
            /// Property Indexer for ShiftHoursPaidQTD
            /// </summary>
            public const int ShiftHoursPaidQTD = 61;

            /// <summary>
            /// Property Indexer for ShiftHoursPaidYTD
            /// </summary>
            public const int ShiftHoursPaidYTD = 62;

            /// <summary>
            /// Property Indexer for TotalHoursPaidMTD
            /// </summary>
            public const int TotalHoursPaidMTD = 63;

            /// <summary>
            /// Property Indexer for TotalHoursPaidQTD
            /// </summary>
            public const int TotalHoursPaidQTD = 64;

            /// <summary>
            /// Property Indexer for TotalHoursPaidYTD
            /// </summary>
            public const int TotalHoursPaidYTD = 65;

            /// <summary>
            /// Property Indexer for TotalChecks
            /// </summary>
            public const int TotalChecks = 66;

            /// <summary>
            /// Property Indexer for TotalEarnings
            /// </summary>
            public const int TotalEarnings = 67;

            /// <summary>
            /// Property Indexer for TotalTaxes
            /// </summary>
            public const int TotalTaxes = 68;

            /// <summary>
            /// Property Indexer for TotalDeductions
            /// </summary>
            public const int TotalDeductions = 69;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 70;

            /// <summary>
            /// Property Indexer for EntrySequence
            /// </summary>
            public const int EntrySequence = 71;

            /// <summary>
            /// Property Indexer for TotalDeductions
            /// </summary>
            public const int TotalCashAdvances = 72;

            /// <summary>
            /// Property Indexer for TotalAdvanceRepayments
            /// </summary>
            public const int TotalAdvanceRepayments = 73;

            /// <summary>
            /// Property Indexer for AccruedVacAmountsMTD
            /// </summary>
            public const int AccruedVacAmountsMTD = 74;

            /// <summary>
            /// Property Indexer for AccruedVacAmountsQTD
            /// </summary>
            public const int AccruedVacAmountsQTD = 75;

            /// <summary>
            /// Property Indexer for AccruedVacAmountsYTD
            /// </summary>
            public const int AccruedVacAmountsYTD = 76;

            /// <summary>
            /// Property Indexer for VacationAmtPaidMTD
            /// </summary>
            public const int VacationAmtPaidMTD = 77;

            /// <summary>
            /// Property Indexer for VacationAmtPaidQTD
            /// </summary>
            public const int VacationAmtPaidQTD = 78;

            /// <summary>
            /// Property Indexer for VacationAmtPaidYTD
            /// </summary>
            public const int VacationAmtPaidYTD = 79;

            /// <summary>
            /// Property Indexer for AccruedVacHoursMTD
            /// </summary>
            public const int AccruedVacHoursMTD = 80;

            /// <summary>
            /// Property Indexer for AccruedVacHoursQTD
            /// </summary>
            public const int AccruedVacHoursQTD = 81;

            /// <summary>
            /// Property Indexer for AccruedVacHoursYTD
            /// </summary>
            public const int AccruedVacHoursYTD = 82;

            /// <summary>
            /// Property Indexer for AccruedVacHoursPaidMTD
            /// </summary>
            public const int AccruedVacHoursPaidMTD = 83;

            /// <summary>
            /// Property Indexer for AccruedVacHoursPaidQTD
            /// </summary>
            public const int AccruedVacHoursPaidQTD = 84;

            /// <summary>
            /// Property Indexer for AccruedVacHoursPaidYTD
            /// </summary>
            public const int AccruedVacHoursPaidYTD = 85;

            /// <summary>
            /// Property Indexer for AccruedSickAmountsMTD
            /// </summary>
            public const int AccruedSickAmountsMTD = 86;

            /// <summary>
            /// Property Indexer for AccruedSickAmountsMTD
            /// </summary>
            public const int AccruedSickAmountsQTD = 87;

            /// <summary>
            /// Property Indexer for AccruedSickAmountsYTD
            /// </summary>
            public const int AccruedSickAmountsYTD = 88;

            /// <summary>
            /// Property Indexer for SickAmtPaidMTD
            /// </summary>
            public const int SickAmtPaidMTD = 89;

            /// <summary>
            /// Property Indexer for SickAmtPaidQTD
            /// </summary>
            public const int SickAmtPaidQTD = 90;

            /// <summary>
            /// Property Indexer for SickAmtPaidYTD
            /// </summary>
            public const int SickAmtPaidYTD = 91;

            /// <summary>
            /// Property Indexer for AccruedSickHoursMTD
            /// </summary>
            public const int AccruedSickHoursMTD = 92;

            /// <summary>
            /// Property Indexer for AccruedSickHoursQTD
            /// </summary>
            public const int AccruedSickHoursQTD = 93;

            /// <summary>
            /// Property Indexer for AccruedSickHoursYTD
            /// </summary>
            public const int AccruedSickHoursYTD = 94;

            /// <summary>
            /// Property Indexer for AccruedSickHoursPaidMTD
            /// </summary>
            public const int AccruedSickHoursPaidMTD = 95;

            /// <summary>
            /// Property Indexer for AccruedSickHoursQTD
            /// </summary>
            public const int AccruedSickHoursPaidQTD = 96;

            /// <summary>
            /// Property Indexer for AccruedSickHoursPaidYTD
            /// </summary>
            public const int AccruedSickHoursPaidYTD = 97;

            /// <summary>
            /// Property Indexer for AccruedCompTimeAmtMTD
            /// </summary>
            public const int AccruedCompTimeAmtMTD = 98;

            /// <summary>
            /// Property Indexer for AccruedCompTimeAmtQTD
            /// </summary>
            public const int AccruedCompTimeAmtQTD = 99;

            /// <summary>
            /// Property Indexer for AccruedCompTimeAmtYTD
            /// </summary>
            public const int AccruedCompTimeAmtYTD = 100;

            /// <summary>
            /// Property Indexer for CompTimeAmtPaidMTD
            /// </summary>
            public const int CompTimeAmtPaidMTD = 101;

            /// <summary>
            /// Property Indexer for CompTimeAmtPaidQTD
            /// </summary>
            public const int CompTimeAmtPaidQTD = 102;

            /// <summary>
            /// Property Indexer for CompTimeAmtPaidYTD
            /// </summary>
            public const int CompTimeAmtPaidYTD = 103;

            /// <summary>
            /// Property Indexer for AccruedCompHoursMTD
            /// </summary>
            public const int AccruedCompHoursMTD = 104;

            /// <summary>
            /// Property Indexer for AccruedCompHoursQTD
            /// </summary>
            public const int AccruedCompHoursQTD = 105;

            /// <summary>
            /// Property Indexer for AccruedCompHoursYTD
            /// </summary>
            public const int AccruedCompHoursYTD = 106;

            /// <summary>
            /// Property Indexer for AccruedCompHoursPaidMTD
            /// </summary>
            public const int AccruedCompHoursPaidMTD = 107;

            /// <summary>
            /// Property Indexer for AccruedCompHoursPaidQTD
            /// </summary>
            public const int AccruedCompHoursPaidQTD = 108;

            /// <summary>
            /// Property Indexer for AccruedCompHoursPaidYTD
            /// </summary>
            public const int AccruedCompHoursPaidYTD = 109;
        }
        #endregion
    }
}