﻿// Copyright (c) 2023-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of PayrollChecks Constants
    /// </summary>
    public partial class PayrollChecks
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0078";

        #region Fields Properties

        /// <summary>
        /// Contains list of PayrollChecks Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Bank
            /// </summary>
            public const string Bank = "BANK";

            /// <summary>
            /// Property for Bank Name
            /// </summary>
            public const string BankName = "NAME";

            /// <summary>
            /// Property for Check Stock Form
            /// </summary>
            public const string CheckStockForm = "CHKFORM";

            /// <summary>
            /// Property for Period End Date
            /// </summary>
            public const string PeriodEndDate = "LASTPEREND";

            /// <summary>
            /// Property for Detail Level
            /// </summary>
            public const string DetailLevel = "DETLEVEL";

            /// <summary>
            /// Property for Sort Checks By
            /// </summary>
            public const string SortChecksBy = "SORTCKSBY";

            /// <summary>
            /// Property for Then By
            /// </summary>
            public const string ThenBy = "THENSORTBY";

            /// <summary>
            /// Property for Class
            /// </summary>
            public const string Class = "BYCLASS";

            /// <summary>
            /// Property for Check Message 1
            /// </summary>
            public const string CheckMessage1 = "MESSAGE1";

            /// <summary>
            /// Property for Check Message 2
            /// </summary>
            public const string CheckMessage2 = "MESSAGE2";

            /// <summary>
            /// Property for Checks Status
            /// </summary>
            public const string ChecksStatus = "CHKSSTATUS";

            /// <summary>
            /// Property for Post Manual Checks Flag
            /// </summary>
            public const string PostManualChecksFlag = "POSTMANCHK";

            /// <summary>
            /// Property for Restart
            /// </summary>
            public const string Restart = "RESTART";

            /// <summary>
            /// Property for Process State
            /// </summary>
            public const string ProcessState = "STATE";

            /// <summary>
            /// Property for BK Return Status
            /// </summary>
            public const string BKReturnStatus = "SWRTRNSTTS";

            /// <summary>
            /// Property for BK App Run Number
            /// </summary>
            public const string BKAppRunNumber = "APPRUNNUM";

            /// <summary>
            /// Property for Payroll Check Run Type
            /// </summary>
            public const string PayrollCheckRunType = "RUNTYPE";

            /// <summary>
            /// Property for Print SSN Flag
            /// </summary>
            public const string PrintSSNFlag = "PRINTSIN";

            /// <summary>
            /// Property for Calculation Sequence
            /// </summary>
            public const string CalculationSequence = "CALCSEQ";

            /// <summary>
            /// Property for First Available Seq.
            /// </summary>
            public const string FirstAvailableSeq = "MINSEQ";

            /// <summary>
            /// Property for Last Available Seq.
            /// </summary>
            public const string LastAvailableSeq = "MAXSEQ";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of PayrollChecks Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Bank
            /// </summary>
            public const int Bank = 1;

            /// <summary>
            /// Property Indexer for Bank Name
            /// </summary>
            public const int BankName = 2;

            /// <summary>
            /// Property Indexer for Check Stock Form
            /// </summary>
            public const int CheckStockForm = 3;

            /// <summary>
            /// Property Indexer for Period End Date
            /// </summary>
            public const int PeriodEndDate = 4;

            /// <summary>
            /// Property Indexer for Detail Level
            /// </summary>
            public const int DetailLevel = 5;

            /// <summary>
            /// Property Indexer for Sort Checks By
            /// </summary>
            public const int SortChecksBy = 6;

            /// <summary>
            /// Property Indexer for Then By
            /// </summary>
            public const int ThenBy = 7;

            /// <summary>
            /// Property Indexer for Class
            /// </summary>
            public const int Class = 8;

            /// <summary>
            /// Property Indexer for Check Message 1
            /// </summary>
            public const int CheckMessage1 = 9;

            /// <summary>
            /// Property Indexer for Check Message 2
            /// </summary>
            public const int CheckMessage2 = 10;

            /// <summary>
            /// Property Indexer for Checks Status
            /// </summary>
            public const int ChecksStatus = 11;

            /// <summary>
            /// Property Indexer for Post Manual Checks Flag
            /// </summary>
            public const int PostManualChecksFlag = 12;

            /// <summary>
            /// Property Indexer for Restart
            /// </summary>
            public const int Restart = 13;

            /// <summary>
            /// Property Indexer for Process State
            /// </summary>
            public const int ProcessState = 14;

            /// <summary>
            /// Property Indexer for BK Return Status
            /// </summary>
            public const int BKReturnStatus = 15;

            /// <summary>
            /// Property Indexer for BK App Run Number
            /// </summary>
            public const int BKAppRunNumber = 16;

            /// <summary>
            /// Property Indexer for Payroll Check Run Type
            /// </summary>
            public const int PayrollCheckRunType = 17;

            /// <summary>
            /// Property Indexer for Print SSN Flag
            /// </summary>
            public const int PrintSSNFlag = 18;

            /// <summary>
            /// Property Indexer for Calculation Sequence
            /// </summary>
            public const int CalculationSequence = 19;

            /// <summary>
            /// Property Indexer for First Available Seq.
            /// </summary>
            public const int FirstAvailableSeq = 20;

            /// <summary>
            /// Property Indexer for Last Available Seq.
            /// </summary>
            public const int LastAvailableSeq = 21;

        }

        #endregion
    }
}
