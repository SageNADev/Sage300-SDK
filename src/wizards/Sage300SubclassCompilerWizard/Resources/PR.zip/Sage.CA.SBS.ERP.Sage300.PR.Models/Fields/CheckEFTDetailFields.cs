// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of CheckEFTDetail Constants
    /// </summary>
    public partial class CheckEFTDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0202";

        #region Fields Properties

        /// <summary>
        /// Contains list of CheckEFTDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "PEREND";

            /// <summary>
            /// Property for EntrySequenceByEmployee
            /// </summary>
            public const string EntrySequenceByEmployee = "ENTRYSEQ";

            /// <summary>
            /// Property for CategoryCode
            /// </summary>
            public const string CategoryCode = "CATEGORY";

            /// <summary>
            /// Property for UniqueKeyField
            /// </summary>
            public const string UniqueKeyField = "LINENO";

            /// <summary>
            /// Property for BankAccountCode
            /// </summary>
            public const string BankAccountCode = "BKACCTCODE";

            /// <summary>
            /// Property for PresentationListTypePay
            /// </summary>
            public const string PresentationListTypePay = "LINETYPE";

            /// <summary>
            /// Property for BaseAmount
            /// </summary>
            public const string BaseAmount = "BASEAMT";

            /// <summary>
            /// Property for AmtPctToBeDeposited
            /// </summary>
            public const string AmtPctToBeDeposited = "AMTPCT";

            /// <summary>
            /// Property for DepositAmount
            /// </summary>
            public const string DepositAmount = "DEPOSITAMT";

            /// <summary>
            /// Property for PrintCategory
            /// </summary>
            public const string PrintCategory = "PCATEGORY";

            /// <summary>
            /// Property for PrintLineType
            /// </summary>
            public const string PrintLineType = "PLINETYPE";

            /// <summary>
            /// Property for PrintLineContents
            /// </summary>
            public const string PrintLineContents = "PCONTENTS";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of CheckEFTDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 2;

            /// <summary>
            /// Property Indexer for EntrySequenceByEmployee
            /// </summary>
            public const int EntrySequenceByEmployee = 3;

            /// <summary>
            /// Property Indexer for CategoryCode
            /// </summary>
            public const int CategoryCode = 4;

            /// <summary>
            /// Property Indexer for UniqueKeyField
            /// </summary>
            public const int UniqueKeyField = 5;

            /// <summary>
            /// Property Indexer for BankAccountCode
            /// </summary>
            public const int BankAccountCode = 6;

            /// <summary>
            /// Property Indexer for PresentationListTypePay
            /// </summary>
            public const int PresentationListTypePay = 7;

            /// <summary>
            /// Property Indexer for BaseAmount
            /// </summary>
            public const int BaseAmount = 8;

            /// <summary>
            /// Property Indexer for AmtPctToBeDeposited
            /// </summary>
            public const int AmtPctToBeDeposited = 9;

            /// <summary>
            /// Property Indexer for DepositAmount
            /// </summary>
            public const int DepositAmount = 10;

            /// <summary>
            /// Property Indexer for PrintCategory
            /// </summary>
            public const int PrintCategory = 11;

            /// <summary>
            /// Property Indexer for PrintLineType
            /// </summary>
            public const int PrintLineType = 12;

            /// <summary>
            /// Property Indexer for PrintLineContents
            /// </summary>
            public const int PrintLineContents = 13;


        }

        #endregion

    }
}