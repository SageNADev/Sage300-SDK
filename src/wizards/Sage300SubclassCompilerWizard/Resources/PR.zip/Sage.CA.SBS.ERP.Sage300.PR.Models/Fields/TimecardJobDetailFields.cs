// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of TimecardJobDetail Constants
    /// </summary>
    public partial class TimecardJobDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0042";


        #region Fields Properties

        /// <summary>
        /// Contains list of TimecardJobDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "PEREND";

            /// <summary>
            /// Property for Timecard
            /// </summary>
            public const string Timecard = "TIMECARD";

            /// <summary>
            /// Property for TimecardLineNumber
            /// </summary>
            public const string TimecardLineNumber = "LINENUM";

            /// <summary>
            /// Property for JobLineNumber
            /// </summary>
            public const string JobLineNumber = "JOBLINE";

            /// <summary>
            /// Property for ContractCode
            /// </summary>
            public const string ContractCode = "CONTRACT";

            /// <summary>
            /// Property for ProjectCode
            /// </summary>
            public const string ProjectCode = "PROJECT";

            /// <summary>
            /// Property for CategoryCode
            /// </summary>
            public const string CategoryCode = "CCATEGORY";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "IDCUST";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "CURRCODE";

            /// <summary>
            /// Property for StartTime
            /// </summary>
            public const string StartTime = "STARTTIME";

            /// <summary>
            /// Property for StopTime
            /// </summary>
            public const string StopTime = "STOPTIME";

            /// <summary>
            /// Property for Hours
            /// </summary>
            public const string Hours = "HOURS";

            /// <summary>
            /// Property for PiecesSalesAmt
            /// </summary>
            public const string PiecesSalesAmt = "CNTBASE";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEMNO";

            /// <summary>
            /// Property for ARItemUOM
            /// </summary>
            public const string ARItemUOM = "ARUNIT";

            /// <summary>
            /// Property for RegularWIPCOSAcct
            /// </summary>
            public const string RegularWIPCOSAcct = "WIPACCT";

            /// <summary>
            /// Property for OvertimeWIPCOSAcct
            /// </summary>
            public const string OvertimeWIPCOSAcct = "OTWIPACCT";

            /// <summary>
            /// Property for ShiftWIPCOSAcct
            /// </summary>
            public const string ShiftWIPCOSAcct = "STWIPACCT";

            /// <summary>
            /// Property for OvertimeHoursOverride
            /// </summary>
            public const string OvertimeHoursOverride = "OTHOURS";

            /// <summary>
            /// Property for OvertimeBillingRateOverride
            /// </summary>
            public const string OvertimeBillingRateOverride = "OTBILLRATE";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "PROJSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for UnformattedContractCode
            /// </summary>
            public const string UnformattedContractCode = "UFMTCONTNO";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "COSTCLASS";

            /// <summary>
            /// Property for CurrencyDescription
            /// </summary>
            public const string CurrencyDescription = "CURRDESC";

            /// <summary>
            /// Property for INTERNALUSEKeyAction
            /// </summary>
            public const string INTERNALUSEKeyAction = "KEYACTION";

            /// <summary>
            /// Property for AllowCostCenterOverrides
            /// </summary>
            public const string AllowCostCenterOverrides = "ALLOWGLOVR";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for ResourceDescription
            /// </summary>
            public const string ResourceDescription = "RESDESC";

        }

        #endregion
        #region Index Properties

        /// <summary>
        /// Contains list of TimecardJobDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 2;

            /// <summary>
            /// Property Indexer for Timecard
            /// </summary>
            public const int Timecard = 3;

            /// <summary>
            /// Property Indexer for TimecardLineNumber
            /// </summary>
            public const int TimecardLineNumber = 4;

            /// <summary>
            /// Property Indexer for JobLineNumber
            /// </summary>
            public const int JobLineNumber = 5;

            /// <summary>
            /// Property Indexer for ContractCode
            /// </summary>
            public const int ContractCode = 6;

            /// <summary>
            /// Property Indexer for ProjectCode
            /// </summary>
            public const int ProjectCode = 7;

            /// <summary>
            /// Property Indexer for CategoryCode
            /// </summary>
            public const int CategoryCode = 8;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 9;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 10;

            /// <summary>
            /// Property Indexer for StartTime
            /// </summary>
            public const int StartTime = 11;

            /// <summary>
            /// Property Indexer for StopTime
            /// </summary>
            public const int StopTime = 12;

            /// <summary>
            /// Property Indexer for Hours
            /// </summary>
            public const int Hours = 13;

            /// <summary>
            /// Property Indexer for PiecesSalesAmt
            /// </summary>
            public const int PiecesSalesAmt = 14;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 15;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 16;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 17;

            /// <summary>
            /// Property Indexer for ARItemUOM
            /// </summary>
            public const int ARItemUOM = 18;

            /// <summary>
            /// Property Indexer for RegularWIPCOSAcct
            /// </summary>
            public const int RegularWIPCOSAcct = 19;

            /// <summary>
            /// Property Indexer for OvertimeWIPCOSAcct
            /// </summary>
            public const int OvertimeWIPCOSAcct = 20;

            /// <summary>
            /// Property Indexer for ShiftWIPCOSAcct
            /// </summary>
            public const int ShiftWIPCOSAcct = 21;

            /// <summary>
            /// Property Indexer for OvertimeHoursOverride
            /// </summary>
            public const int OvertimeHoursOverride = 22;

            /// <summary>
            /// Property Indexer for OvertimeBillingRateOverride
            /// </summary>
            public const int OvertimeBillingRateOverride = 23;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 24;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 25;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 26;

            /// <summary>
            /// Property Indexer for UnformattedContractCode
            /// </summary>
            public const int UnformattedContractCode = 27;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 28;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 29;

            /// <summary>
            /// Property Indexer for CurrencyDescription
            /// </summary>
            public const int CurrencyDescription = 30;

            /// <summary>
            /// Property Indexer for INTERNALUSEKeyAction
            /// </summary>
            public const int INTERNALUSEKeyAction = 31;

            /// <summary>
            /// Property Indexer for AllowCostCenterOverrides
            /// </summary>
            public const int AllowCostCenterOverrides = 32;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 33;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 50;

            /// <summary>
            /// Property Indexer for ResourceDescription
            /// </summary>
            public const int ResourceDescription = 51;


        }

        #endregion

    }
}