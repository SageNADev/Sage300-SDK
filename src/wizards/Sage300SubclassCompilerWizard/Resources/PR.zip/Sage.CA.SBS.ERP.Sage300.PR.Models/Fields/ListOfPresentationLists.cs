﻿/* Copyright (c) 1994-2023 Sage Software, Inc.  All rights reserved. */

using System.Collections.Generic;
using System.Xml.Serialization;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Class to get and set Enum value for select list
    /// </summary>
    public class ListOfPresentationLists
    {
        /// <summary>
        /// Gets or sets Presentation Identifier
        /// </summary>
        /// 
        /// <returns>
        /// Presentation Identifier number
        /// </returns>
        [XmlAttribute("PresentationId")]
        public int PresentationId { get; set; }

        /// <summary>
        /// Gets or sets the PresentationList.
        /// </summary>
        /// 
        /// <returns>
        /// Presentation data strings sepparated by '|' symbol
        /// </returns>
        [XmlAttribute("PresentationData")]
        public List<CustomSelectList> PresentationData { get; set; }
    }
}