// Copyright (c) 2023-2024 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of GenerateEftFile Constants
    /// </summary>
    public partial class GenerateEFTFile

    {
        /// <summary>
        /// Entity Name 
        /// </summary>
        public const string EntityName = "~~0203";

        #region Fields Properties

        /// <summary>
        /// Contains list of GenarateEftFile Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for EFTFileType
            /// </summary>
            public const string EFTFileType = "EFTRUNTYPE";

            /// <summary>
            /// Property for RunSequence
            /// </summary>
            public const string RunSequence = "RERUNWHICH";

            /// <summary>
            /// Property for CompanyEFTBank
            /// </summary>
            public const string CompanyEFTBank = "BANKID";

            /// <summary>
            /// Property for SelectionList
            /// </summary>
            public const string SelectionList = "SELECTLIST";

            /// <summary>
            /// Property for FromEmployee
            /// </summary>
            public const string FromEmployee = "EMPFROM";

            /// <summary>
            /// Property for ToEmployee
            /// </summary>
            public const string ToEmployee = "EMPTO";

            /// <summary>
            /// Property for FromPeriodEndDate
            /// </summary>
            public const string FromPeriodEndDate = "PEDATEFROM";

            /// <summary>
            /// Property for ToPeriodEndDate
            /// </summary>
            public const string ToPeriodEndDate = "PEDATETO";

            /// <summary>
            /// Property for UseDefaultFundsAvailableDate
            /// </summary>
            public const string UseDefaultFundsAvailableDate = "USEDEFDATE";

            /// <summary>
            /// Property for DefaultFundsAvailableDate
            /// </summary>
            public const string DefaultFundsAvailableDate = "DEFDATE";

            /// <summary>
            /// Property for FileCreationDate
            /// </summary>
            public const string FileCreationDate = "CREATDATE";

            /// <summary>
            /// Property for FileCreationNumber
            /// </summary>
            public const string FileCreationNo = "FILCREATNO";

            /// <summary>
            /// Property for FileIdModifier
            /// </summary>
            public const string FileIdModifier = "FILIDMODIF";

            /// <summary>
            /// Property for EntryDescription
            /// </summary>
            public const string EntryDescription = "ENTRYDESC";

            /// <summary>
            /// Property for EFTRunSequence
            /// </summary>
            public const string EFTRunSequence = "EFTRUNSEQ";

            /// <summary>
            /// Property for ReturnSequence
            /// </summary>
            public const string ReturnSequence = "RERUNSEQ";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for EftType
            /// </summary>
            public const string EFTType = "EFTTYPE";

            /// <summary>
            /// Property for CaseState
            /// </summary>
            public const string CaseState = "CASESTATE";

            /// <summary>
            /// Property for RegenratePreviousCSEFT
            /// </summary>
            public const string RegenratePreviousCSEFT = "INCLPCSEFT";

            /// <summary>
            /// Property for TransactionsType
            /// </summary>
            public const string TransactionsType = "DDRUNTYPE";

            /// <summary>
            /// Property for RunSeq
            /// </summary>
            public const string RunSeq = "RUNSEQ";

            /// <summary>
            /// Property for ReRunSeq
            /// </summary>
            public const string ReRunSeq = "RERUNSEQ";

            /// <summary>
            /// Property for ToRunSeq
            /// </summary>
            public const string ToRunSeq = "TORUNSEQ";

            /// <summary>
            /// Property for ToReRunSeq
            /// </summary>
            public const string ToReRunSeq = "TORERUNSEQ";

            /// <summary>
            /// Property for LastReRunOnly
            /// </summary>
            public const string LastReRunOnly = "LASTRERUNONLY";

            /// <summary>
            /// Property for MaskEFTNBR
            /// </summary>
            public const string MaskEFTNBR = "MASKEFTNBR";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of GenerateEftFile Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for EFTFileType
            /// </summary>
            public const int EFTFileType = 1;

            /// <summary>
            /// Property Indexer for RunSequence
            /// </summary>
            public const int RunSequence = 2;

            /// <summary>
            /// Property Indexer for CompanyEFTBank
            /// </summary>
            public const int CompanyEFTBank = 3;

            /// <summary>
            /// Property Indexer for SelectionList
            /// </summary>
            public const int SelectionList = 4;

            /// <summary>
            /// Property Indexer for FromEmployee
            /// </summary>
            public const int FromEmployee = 5;

            /// <summary>
            /// Property Indexer for ToEmployee
            /// </summary>
            public const int ToEmployee = 6;

            /// <summary>
            /// Property Indexer for FromPeriodEndDate
            /// </summary>
            public const int FromPeriodEndDate = 7;

            /// <summary>
            /// Property Indexer for ToPeriodEndDate
            /// </summary>
            public const int ToPeriodEndDate = 8;

            /// <summary>
            /// Property Indexer for UseDefaultFundsAvailableDate
            /// </summary>
            public const int UseDefaultFundsAvailableDate = 9;

            /// <summary>
            /// Property Indexer for DefaultFundsAvailableDate
            /// </summary>
            public const int DefaultFundsAvailableDate = 10;

            /// <summary>
            /// Property Indexer for FileCreationDate
            /// </summary>
            public const int FileCreationDate = 11;

            /// <summary>
            /// Property Indexer for FileCreationNo
            /// </summary>
            public const int FileCreationNo = 12;

            /// <summary>
            /// Property Indexer for FileIdModifier
            /// </summary>
            public const int FileIdModifier = 13;

            /// <summary>
            /// Property Indexer for EntryDescription
            /// </summary>
            public const int EntryDescription = 14;

            /// <summary>
            /// Property Indexer for EFTRunSequence
            /// </summary>
            public const int EFTRunSequence = 15;

            /// <summary>
            /// Property Indexer for ReturnSequence
            /// </summary>
            public const int ReturnSequence = 16;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 17;

            /// <summary>
            /// Property Indexer for EFTType
            /// </summary>
            public const int EFTType = 18;

            /// <summary>
            /// Property Indexer for CaseState
            /// </summary>
            public const int CaseState = 19;

            /// <summary>
            /// Property Indexer for RegenratePreviousCSEFT
            /// </summary>
            public const int RegenratePreviousCSEFT = 20;

            /// <summary>
            /// Property Indexer for TransactionsType
            /// </summary>
            public const int TransactionsType = 21;
        }
        #endregion
    }
}