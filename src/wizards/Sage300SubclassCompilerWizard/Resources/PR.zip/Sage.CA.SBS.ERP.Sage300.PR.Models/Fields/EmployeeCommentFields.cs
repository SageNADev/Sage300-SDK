// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeComment Constants
    /// </summary>
    public partial class EmployeeComment
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0119";


        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeComment Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for DateEntered
            /// </summary>
            public const string DateEntered = "ENTERED";

            /// <summary>
            /// Property for Uniquifier
            /// </summary>
            public const string Uniquifier = "UNIQUIFIER";

            /// <summary>
            /// Property for ExpiryDate
            /// </summary>
            public const string ExpiryDate = "EXPIRES";

            /// <summary>
            /// Property for FollowUpDate
            /// </summary>
            public const string FollowUpDate = "FOLLOWUP";

            /// <summary>
            /// Property for UserID
            /// </summary>
            public const string UserID = "USERID";

            /// <summary>
            /// Property for CommentType
            /// </summary>
            public const string CommentType = "COMMENTTYP";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for ReservedComment0
            /// </summary>
            public const string ReservedComment0 = "COMMENT0";

            /// <summary>
            /// Property for ReservedComment1
            /// </summary>
            public const string ReservedComment1 = "COMMENT1";

            /// <summary>
            /// Property for ReservedComment2
            /// </summary>
            public const string ReservedComment2 = "COMMENT2";

            /// <summary>
            /// Property for ReservedComment3
            /// </summary>
            public const string ReservedComment3 = "COMMENT3";

            /// <summary>
            /// Property for ReservedComment4
            /// </summary>
            public const string ReservedComment4 = "COMMENT4";

            /// <summary>
            /// Property for ReservedComment5
            /// </summary>
            public const string ReservedComment5 = "COMMENT5";

            /// <summary>
            /// Property for ReservedComment6
            /// </summary>
            public const string ReservedComment6 = "COMMENT6";

            /// <summary>
            /// Property for ReservedComment7
            /// </summary>
            public const string ReservedComment7 = "COMMENT7";

            /// <summary>
            /// Property for ReservedComment8
            /// </summary>
            public const string ReservedComment8 = "COMMENT8";

            /// <summary>
            /// Property for ReservedComment9
            /// </summary>
            public const string ReservedComment9 = "COMMENT9";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeComment Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for DateEntered
            /// </summary>
            public const int DateEntered = 2;

            /// <summary>
            /// Property Indexer for Uniquifier
            /// </summary>
            public const int Uniquifier = 3;

            /// <summary>
            /// Property Indexer for ExpiryDate
            /// </summary>
            public const int ExpiryDate = 4;

            /// <summary>
            /// Property Indexer for FollowUpDate
            /// </summary>
            public const int FollowUpDate = 5;

            /// <summary>
            /// Property Indexer for UserID
            /// </summary>
            public const int UserID = 6;

            /// <summary>
            /// Property Indexer for CommentType
            /// </summary>
            public const int CommentType = 7;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 8;

            /// <summary>
            /// Property Indexer for ReservedComment0
            /// </summary>
            public const int ReservedComment0 = 15;

            /// <summary>
            /// Property Indexer for ReservedComment1
            /// </summary>
            public const int ReservedComment1 = 16;

            /// <summary>
            /// Property Indexer for ReservedComment2
            /// </summary>
            public const int ReservedComment2 = 17;

            /// <summary>
            /// Property Indexer for ReservedComment3
            /// </summary>
            public const int ReservedComment3 = 18;

            /// <summary>
            /// Property Indexer for ReservedComment4
            /// </summary>
            public const int ReservedComment4 = 19;

            /// <summary>
            /// Property Indexer for ReservedComment5
            /// </summary>
            public const int ReservedComment5 = 20;

            /// <summary>
            /// Property Indexer for ReservedComment6
            /// </summary>
            public const int ReservedComment6 = 21;

            /// <summary>
            /// Property Indexer for ReservedComment7
            /// </summary>
            public const int ReservedComment7 = 22;

            /// <summary>
            /// Property Indexer for ReservedComment8
            /// </summary>
            public const int ReservedComment8 = 23;

            /// <summary>
            /// Property Indexer for ReservedComment9
            /// </summary>
            public const int ReservedComment9 = 24;


        }

        #endregion

    }
}
