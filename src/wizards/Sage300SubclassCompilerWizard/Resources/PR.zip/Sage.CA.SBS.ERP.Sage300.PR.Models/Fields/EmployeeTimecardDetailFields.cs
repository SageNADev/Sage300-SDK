// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeTimecardDetail Constants
    /// </summary>
    public partial class EmployeeTimecardDetail
    {
        /// <summary>
        /// Entity Name with prefix added later
        /// </summary>
        public const string EntityName = "~~0103";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"PAYDATE", "PAYDATE" },
                    {"EARNDED", "EARNDED" },
                    {"STARTTIME", "STARTTIME"},
                    {"STOPTIME", "STOPTIME"},
                    {"HOURS", "HOURS"},
                    {"TIPSEXP", "TIPSEXP"},
                    {"SHIFTSCHED", "SHIFTSCHED"},
                    {"SHIFTNUM", "SHIFTNUM"},
                    {"POOLEDTIPS", "POOLEDTIPS"},
                    {"TIPSBASE", "TIPSBASE"},
                    {"JOBS", "JOBS"}
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeTimecardDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for EndDate
            /// </summary>
            public const string EndDate = "ENDDATE";

            /// <summary>
            /// Property for PayDate
            /// </summary>
            public const string PayDate = "PAYDATE";

            /// <summary>
            /// Property for EarningExpTipAccrualCode
            /// </summary>
            public const string EarningExpTipAccrualCode = "EARNDED";

            /// <summary>
            /// Property for UniqueKeyField
            /// </summary>
            public const string UniqueKeyField = "UNIQUE";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for StartTime
            /// </summary>
            public const string StartTime = "STARTTIME";

            /// <summary>
            /// Property for StopTime
            /// </summary>
            public const string StopTime = "STOPTIME";

            /// <summary>
            /// Property for HoursWorked
            /// </summary>
            public const string HoursWorked = "HOURS";

            /// <summary>
            /// Property for TipsExpensePiecesSalesAmount
            /// </summary>
            public const string TipsExpensePiecesSalesAmount = "TIPSEXP";

            /// <summary>
            /// Property for ShiftDifferentialSchedule
            /// </summary>
            public const string ShiftDifferentialSchedule = "SHIFTSCHED";

            /// <summary>
            /// Property for ShiftNumber
            /// </summary>
            public const string ShiftNumber = "SHIFTNUM";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for PooledTips
            /// </summary>
            public const string PooledTips = "POOLEDTIPS";

            /// <summary>
            /// Property for TipsBasedOn
            /// </summary>
            public const string TipsBasedOn = "TIPSBASE";

            /// <summary>
            /// Property for Jobs
            /// </summary>
            public const string Jobs = "JOBS";

            /// <summary>
            /// Property for WorkClassificationCode
            /// </summary>
            public const string WorkClassificationCode = "WORKCODE";

            /// <summary>
            /// Property for TotalJobHours
            /// </summary>
            public const string TotalJobHours = "JOBHOURS";

            /// <summary>
            /// Property for TotalJobPiecesSalesAmt
            /// </summary>
            public const string TotalJobPiecesSalesAmt = "JOBBASE";

            /// <summary>
            /// Property for DayOfTheWeek
            /// </summary>
            public const string DayOfTheWeek = "DOW";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for CalculationMethod
            /// </summary>
            public const string CalculationMethod = "CALCMETH";

            /// <summary>
            /// Property for EarnDedCategory
            /// </summary>
            public const string EarnDedCategory = "EDCATEGORY";

            /// <summary>
            /// Property for EarnDedType
            /// </summary>
            public const string EarnDedType = "EARDEDTYPE";

            /// <summary>
            /// Property for GLSegmentOne
            /// </summary>
            public const string GLSegmentOne = "GLSEG1";

            /// <summary>
            /// Property for GLSegmentTwo
            /// </summary>
            public const string GLSegmentTwo = "GLSEG2";

            /// <summary>
            /// Property for GLSegmentThree
            /// </summary>
            public const string GLSegmentThree = "GLSEG3";

            /// <summary>
            /// Property for GLSegmentNameOne
            /// </summary>
            public const string GLSegmentNameOne = "GLSEGID1";

            /// <summary>
            /// Property for GLSegmentDescriptionOne
            /// </summary>
            public const string GLSegmentDescriptionOne = "GLSEGDESC1";

            /// <summary>
            /// Property for GLSegmentNameTwo
            /// </summary>
            public const string GLSegmentNameTwo = "GLSEGID2";

            /// <summary>
            /// Property for GLSegmentDescriptionTwo
            /// </summary>
            public const string GLSegmentDescriptionTwo = "GLSEGDESC2";

            /// <summary>
            /// Property for GLSegmentNameThree
            /// </summary>
            public const string GLSegmentNameThree = "GLSEGID3";

            /// <summary>
            /// Property for GLSegmentDescriptionThree
            /// </summary>
            public const string GLSegmentDescriptionThree = "GLSEGDESC3";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeTimecardDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for EndDate
            /// </summary>
            public const int EndDate = 2;

            /// <summary>
            /// Property Indexer for PayDate
            /// </summary>
            public const int PayDate = 3;

            /// <summary>
            /// Property Indexer for EarningExpTipAccrualCode
            /// </summary>
            public const int EarningExpTipAccrualCode = 4;

            /// <summary>
            /// Property Indexer for UniqueKeyField
            /// </summary>
            public const int UniqueKeyField = 5;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 6;

            /// <summary>
            /// Property Indexer for StartTime
            /// </summary>
            public const int StartTime = 7;

            /// <summary>
            /// Property Indexer for StopTime
            /// </summary>
            public const int StopTime = 8;

            /// <summary>
            /// Property Indexer for HoursWorked
            /// </summary>
            public const int HoursWorked = 9;

            /// <summary>
            /// Property Indexer for TipsExpensePiecesSalesAmount
            /// </summary>
            public const int TipsExpensePiecesSalesAmount = 10;

            /// <summary>
            /// Property Indexer for ShiftDifferentialSchedule
            /// </summary>
            public const int ShiftDifferentialSchedule = 11;

            /// <summary>
            /// Property Indexer for ShiftNumber
            /// </summary>
            public const int ShiftNumber = 12;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 13;

            /// <summary>
            /// Property Indexer for PooledTips
            /// </summary>
            public const int PooledTips = 14;

            /// <summary>
            /// Property Indexer for TipsBasedOn
            /// </summary>
            public const int TipsBasedOn = 15;

            /// <summary>
            /// Property Indexer for Jobs
            /// </summary>
            public const int Jobs = 16;

            /// <summary>
            /// Property Indexer for WorkClassificationCode
            /// </summary>
            public const int WorkClassificationCode = 17;

            /// <summary>
            /// Property Indexer for TotalJobHours
            /// </summary>
            public const int TotalJobHours = 18;

            /// <summary>
            /// Property Indexer for TotalJobPiecesSalesAmt
            /// </summary>
            public const int TotalJobPiecesSalesAmt = 19;

            /// <summary>
            /// Property Indexer for DayOfTheWeek
            /// </summary>
            public const int DayOfTheWeek = 20;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 21;

            /// <summary>
            /// Property Indexer for CalculationMethod
            /// </summary>
            public const int CalculationMethod = 22;

            /// <summary>
            /// Property Indexer for EarnDedCategory
            /// </summary>
            public const int EarnDedCategory = 23;

            /// <summary>
            /// Property Indexer for EarnDedType
            /// </summary>
            public const int EarnDedType = 24;

            /// <summary>
            /// Property Indexer for GLSegmentOne
            /// </summary>
            public const int GLSegmentOne = 25;

            /// <summary>
            /// Property Indexer for GLSegmentTwo
            /// </summary>
            public const int GLSegmentTwo = 26;

            /// <summary>
            /// Property Indexer for GLSegmentThree
            /// </summary>
            public const int GLSegmentThree = 27;

            /// <summary>
            /// Property Indexer for GLSegmentNameOne
            /// </summary>
            public const int GLSegmentNameOne = 28;

            /// <summary>
            /// Property Indexer for GLSegmentDescriptionOne
            /// </summary>
            public const int GLSegmentDescriptionOne = 29;

            /// <summary>
            /// Property Indexer for GLSegmentNameTwo
            /// </summary>
            public const int GLSegmentNameTwo = 30;

            /// <summary>
            /// Property Indexer for GLSegmentDescriptionTwo
            /// </summary>
            public const int GLSegmentDescriptionTwo = 31;

            /// <summary>
            /// Property Indexer for GLSegmentNameThree
            /// </summary>
            public const int GLSegmentNameThree = 32;

            /// <summary>
            /// Property Indexer for GLSegmentDescriptionThree
            /// </summary>
            public const int GLSegmentDescriptionThree = 33;


        }

        #endregion

    }
}