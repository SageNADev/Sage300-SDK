// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EarningsDeduction Constants
    /// </summary>
    public partial class EarningsDeduction
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0007";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"ASOF", "InactiveAsOf"},
                    {"EARDEDTYPE", "Type"},
                    {"FREQUENCY", "Frequency"},
                    {"STARTMONTH", "StartMonth"},
                    {"STARTDAY", "StartDay"},
                    {"ECALCMETH", "EmployeeCalculationMethod"},
                    {"EW2BOX", "EmployeeW2Box"},
                    {"ERATE", "EmployeeRate"},
                    {"EANNUALMAX", "EmployeeAnnualMaximum"},
                    {"EDAILYMIN", "EmployeeDailyMinimum"},
                    {"EDAILYMAX", "EmployeeDailyMaximum"},
                    {"EWEEKLYMIN", "EmployeeWeeklyMinimum"},
                    {"EWEEKLYMAX", "EmployeeWeeklyMaximum"},
                    {"EBIWKLYMIN", "EmployeeBiweeklyMinimum"},
                    {"EBIWKLYMAX", "EmployeeBiweeklyMaximum"},
                    {"ESEMIMNMIN", "EmployeeSemimonthlyMinimum"},
                    {"ESEMIMNMAX", "EmployeeSemimonthlyMaximum"},
                    {"EMNTHLYMIN", "EmployeeMonthlyMinimum"},
                    {"EMNTHLYMAX", "EmployeeMonthlyMaximum"},
                    {"EQRTRLYMIN", "EmployeeQuarterlyMinimum"},
                    {"EQRTRLYMAX", "EmployeeQuarterlyMaximum"},
                    {"E10PPPYMIN", "EmployeeTenPeriodYearMinimum"},
                    {"E10PPPYMAX", "EmployeeTenPeriodYearMaximum"},
                    {"E13PPPYMIN", "EmployeeThirteenPeriodYearMi"},
                    {"E13PPPYMAX", "EmployeeThirteenPeriodYearMa"},
                    {"E22PPPYMIN", "E22PPPYMIN"},
                    {"E22PPPYMAX", "E22PPPYMAX"},
                    {"ELIMITBASE", "EmployeeBaseLimit"},
                    {"WGBRACK1", "WageBracket1"},
                    {"WGADDAMT1", "AddAmount1"},
                    {"WGPCTOVR1", "PercntOfExcess1"},
                    {"WGBRACK2", "WageBracket2"},
                    {"WGADDAMT2", "AddAmount2"},
                    {"WGPCTOVR2", "PercntOfExcess2"},
                    {"WGBRACK3", "WageBracket3"},
                    {"WGADDAMT3", "AddAmount3"},
                    {"WGPCTOVR3", "PercntOfExcess3"},
                    {"WGBRACK4", "WageBracket4"},
                    {"WGADDAMT4", "AddAmount4"},
                    {"WGPCTOVR4", "PercntOfExcess4"},
                    {"WGBRACK5", "WageBracket5"},
                    {"WGADDAMT5", "AddAmount5"},
                    {"WGPCTOVR5", "PercntOfExcess5"},
                    {"WGBRACK6", "WageBracket6"},
                    {"WGADDAMT6", "AddAmount6"},
                    {"WGPCTOVR6", "PercntOfExcess6"},
                    {"WGBRACK7", "WageBracket7"},
                    {"WGADDAMT7", "AddAmount7"},
                    {"WGPCTOVR7", "PercntOfExcess7"},
                    {"WGBRACK8", "WageBracket8"},
                    {"WGADDAMT8", "AddAmount8"},
                    {"WGPCTOVR8", "PercntOfExcess8"},
                    {"WGBRACK9", "WageBracket9"},
                    {"WGADDAMT9", "AddAmount9"},
                    {"WGPCTOVR9", "PercntOfExcess9"},
                    {"WGBRACK10", "WageBracket10"},
                    {"WGADDAMT10", "AddAmount10"},
                    {"WGPCTOVR10", "PercntOfExcess10"},
                    {"WGBRACK11", "WageBracket11"},
                    {"WGADDAMT11", "AddAmount11"},
                    {"WGPCTOVR11", "PercntOfExcess11"},
                    {"WGBRACK12", "WageBracket12"},
                    {"WGADDAMT12", "AddAmount12"},
                    {"WGPCTOVR12", "PercntOfExcess12"},
                    {"WGBRACK13", "WageBracket13"},
                    {"WGADDAMT13", "AddAmount13"},
                    {"WGPCTOVR13", "PercntOfExcess13"},
                    {"WGBRACK14", "WageBracket14"},
                    {"WGADDAMT14", "AddAmount14"},
                    {"WGPCTOVR14", "PercntOfExcess14"},
                    {"WGBRACK15", "WageBracket15"},
                    {"WGADDAMT15", "AddAmount15"},
                    {"WGPCTOVR15", "PercntOfExcess15"},
                    {"WGBRACK16", "WageBracket16"},
                    {"WGADDAMT16", "AddAmount16"},
                    {"WGPCTOVR16", "PercntOfExcess16"},
                    {"WGBRACK17", "WageBracket17"},
                    {"WGADDAMT17", "AddAmount17"},
                    {"WGPCTOVR17", "PercntOfExcess17"},
                    {"WGBRACK18", "WageBracket18"},
                    {"WGADDAMT18", "AddAmount18"},
                    {"WGPCTOVR18", "PercntOfExcess18"},
                    {"WGBRACK19", "WageBracket19"},
                    {"WGADDAMT19", "AddAmount19"},
                    {"WGPCTOVR19", "PercntOfExcess19"},
                    {"WGBRACK20", "WageBracket20"},
                    {"WGADDAMT20", "AddAmount20"},
                    {"WGPCTOVR20", "PercntOfExcess20"},
                    {"RCALCMETH", "EmployerCalculationMethod"},
                    {"RW2BOX", "EmployerW2Box"},
                    {"RRATE", "EmployerRate"},
                    {"RANNUALMAX", "EmployerAnnualMaximum"},
                    {"RDAILYMIN", "EmployerDailyMinimum"},
                    {"RDAILYMAX", "EmployerDailyMaximum"},
                    {"RWEEKLYMIN", "EmployerWeeklyMinimum"},
                    {"RWEEKLYMAX", "EmployerWeeklyMaximum"},
                    {"RBIWKLYMIN", "EmployerBiweeklyMinimum"},
                    {"RBIWKLYMAX", "EmployerBiweeklyMaximum"},
                    {"RSEMIMNMIN", "EmployerSemimonthlyMinimum"},
                    {"RSEMIMNMAX", "EmployerSemimonthlyMaximum"},
                    {"RMNTHLYMIN", "EmployerMonthlyMinimum"},
                    {"RMNTHLYMAX", "EmployerMonthlyMaximum"},
                    {"RQRTRLYMIN", "EmployerQuarterlyMinimum"},
                    {"RQRTRLYMAX", "EmployerQuarterlyMaximum"},
                    {"R10PPPYMIN", "EmployerTenPerYearMinimum"},
                    {"R10PPPYMAX", "EmployerTenPerYearMaximum"},
                    {"R13PPPYMIN", "EmployerThirteenPerYearMinim"},
                    {"R13PPPYMAX", "EmployerThirteenPerYearMaxim"},
                    {"R22PPPYMIN", "EmployerTwentytwoPerYearMini"},
                    {"R22PPPYMAX", "EmployerTwentytwoPerYearMaxi"},
                    {"RLIMITBASE", "EmployerBaseLimit"},
                    {"ALLOWWCC", "SubjectToWorkersCompensation"},
                    {"COMMAMT1", "CommissionAmount1"},
                    {"COMMPCT1", "CommissionPct1"},
                    {"COMMAMT2", "CommissionAmount2"},
                    {"COMMPCT2", "CommissionPct2"},
                    {"COMMAMT3", "CommissionAmount3"},
                    {"COMMPCT3", "CommissionPct3"},
                    {"COMMAMT4", "CommissionAmount4"},
                    {"COMMPCT4", "CommissionPct4"},
                    {"COMMAMT5", "CommissionAmount5"},
                    {"COMMPCT5", "CommissionPct5"},
                    {"COMMPCTX", "CommissionAmountExcess"},
                    {"PIECNUM1", "PieceCount1"},
                    {"PIECAMT1", "PieceAmount1"},
                    {"PIECNUM2", "PieceCount2"},
                    {"PIECAMT2", "PieceAmount2"},
                    {"PIECNUM3", "PieceCount3"},
                    {"PIECAMT3", "PieceAmount3"},
                    {"PIECNUM4", "PieceCount4"},
                    {"PIECAMT4", "PieceAmount4"},
                    {"PIECNUM5", "PieceCount5"},
                    {"PIECAMT5", "PieceAmount5"},
                    {"PIECAMTX", "MaxPieceRateAmount"},
                    {"TIPDISB", "TipDisbursement"},
                    {"PAYDOWNDED", "RepaymentDeduction"},
                    {"REPAYID", "AdvanceToBeRepaid"},
                    {"CARRYOVER", "Carryover"},
                    {"COVERDAY", "CarryOverDay"},
                    {"COVERMONTH", "CarryOverMonth"},
                    {"POSTLIAB", "PostLiab"},
                    {"SVCYEAR1", "ServiceYear1"},
                    {"BEGHRS1", "BeginningHours1"},
                    {"INCRHRS1", "IncrementHours1"},
                    {"MAXACCR1", "MaxAnnualAccrual1"},
                    {"MAXCARRY1", "MaxCarryOverHours1"},
                    {"SVCYEAR2", "ServiceYear2"},
                    {"BEGHRS2", "BeginningHours2"},
                    {"INCRHRS2", "IncrementHours2"},
                    {"MAXACCR2", "MaxAnnualAccrual2"},
                    {"MAXCARRY2", "MaxCarryOverHours2"},
                    {"SVCYEAR3", "ServiceYear3"},
                    {"BEGHRS3", "BeginningHours3"},
                    {"INCRHRS3", "IncrementHours3"},
                    {"MAXACCR3", "MaxAnnualAccrual3"},
                    {"MAXCARRY3", "MaxCarryOverHours3"},
                    {"SVCYEAR4", "ServiceYear4"},
                    {"BEGHRS4", "BeginningHours4"},
                    {"INCRHRS4", "IncrementHours4"},
                    {"MAXACCR4", "MaxAnnualAccrual4"},
                    {"MAXCARRY4", "MaxCarryOverHours4"},
                    {"LEVEL", "Level"},
                    {"LISTUSEBHI", "BaseHoursListUse"},
                    {"REGULARBHI", "BaseHoursRegular"},
                    {"OVRTIMEBHI", "BaseHoursOvertime"},
                    {"LISTUSEBEI", "BaseEarningsListUse"},
                    {"REGULARBEI", "BaseEarningsRegular"},
                    {"OVRTIMEBEI", "BaseEarningsOvertime"},
                    {"SHIFTBEI", "BaseEarningsShift"},
                    {"LISTUSEBDI", "BaseDeductionsListUse"},
                    {"LISTUSEBTI", "BaseTaxListUse"},
                    {"LISTUSETTW", "ListUseOfTypeOfTaxableWage"},
                    {"WHMETHTTW", "WithholdingMethodForTaxableW"},
                    {"LISTUSETDB", "TakeDeductionBeforeListUse"},
                    {"ET4BOX", "ET4BOX"},
                    {"RT4BOX", "RT4BOX"},
                    {"ER1BOX", "ER1BOX"},
                    {"RR1BOX", "RR1BOX"},
                    {"EASSOCW2SW", "EASSOCW2SW"},
                    {"EASSOCTAX", "EASSOCTAX"},
                    {"RASSOCW2SW", "RASSOCW2SW"},
                    {"RASSOCTAX", "RASSOCTAX"},
                    {"POSTBENE", "PostBenefit"},
                    {"PAYACCRUAL", "PayAccrual"},
                    {"NONPERPYMT", "NONPERPYMT"},
                    {"LINKEARN", "LinkedEarning"},
                    {"SWFLSA", "IncludeInFLSAOvertimeCalc"},
                    {"COMMINCREM", "ProgressiveCalcCommissions"},
                    {"WGANNUALIZ", "AnnualizedWageBrackets"},
                    {"WGBRINCREM", "ProgressiveCalcWageBrackets"},
                    {"PIECINCREM", "ProgressiveCalcPieceRate"},
                    {"ELIFETMMAX", "EmployeeLifetimeMaximum"},
                    {"RLIFETMMAX", "EmployerLifetimeMaximum"},
                    {"E2NDRATEIN", "EmployeeSecRateEffective"},
                    {"R2NDRATEIN", "EmployerSecRateEffective"},
                    {"E2NDRATE", "EmployeeSecondaryRate"},
                    {"R2NDRATE", "EmployerSecondaryRate"},
                    {"SVCYEAR5", "ServiceYear5"},
                    {"BEGHRS5", "BeginningHours5"},
                    {"INCRHRS5", "IncrementHours5"},
                    {"MAXACCR5", "MaxAnnualAccrual5"},
                    {"MAXCARRY5", "MaxCarryOverHours5"},
                    {"SVCYEAR6", "ServiceYear6"},
                    {"BEGHRS6", "BeginningHours6"},
                    {"INCRHRS6", "IncrementHours6"},
                    {"MAXACCR6", "MaxAnnualAccrual6"},
                    {"MAXCARRY6", "MaxCarryOverHours6"},
                    {"SVCYEAR7", "ServiceYear7"},
                    {"BEGHRS7", "BeginningHours7"},
                    {"INCRHRS7", "IncrementHours7"},
                    {"MAXACCR7", "MaxAnnualAccrual7"},
                    {"MAXCARRY7", "MaxCarryOverHours7"},
                    {"SVCYEAR8", "ServiceYear8"},
                    {"BEGHRS8", "BeginningHours8"},
                    {"INCRHRS8", "IncrementHours8"},
                    {"MAXACCR8", "MaxAnnualAccrual8"},
                    {"MAXCARRY8", "MaxCarryOverHours8"},
                    {"SVCYEAR9", "ServiceYear9"},
                    {"BEGHRS9", "BeginningHours9"},
                    {"INCRHRS9", "IncrementHours9"},
                    {"MAXACCR9", "MaxAnnualAccrual9"},
                    {"MAXCARRY9", "MaxCarryOverHours9"},
                    {"SVCYEAR10", "ServiceYear10"},
                    {"BEGHRS10", "BeginningHours10"},
                    {"INCRHRS10", "IncrementHours10"},
                    {"MAXACCR10", "MaxAnnualAccrual10"},
                    {"MAXCARRY10", "MaxCarryOverHours10"},
                    {"CCOVERRIDE", "CostCenterOverrideBasedOnCa"},
                    {"BILLPCT1", "BillingPercentage1"},
                    {"BILLPCT2", "BillingPercentage2"},
                    {"BILLPCT3", "BillingPercentage3"},
                    {"BILLPCT4", "BillingPercentage4"},
                    {"BILLPCT5", "BillingPercentage5"},
                    {"BILLPCT6", "BillingPercentage6"},
                    {"MAXONREM", "CalculationMaxCarryOverBasedOnR"},
                    {"MAXONACCR", "CapAccrualAtMaxAccrual"},
                };
            }
        }

    

        #region Fields Properties

        /// <summary>
        /// Contains list of EarningsDeduction Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for EarningDeduction
            /// </summary>
            public const string EarningDeduction = "EARNDED";

            /// <summary>
            /// Property for EarningDeductionDescription
            /// </summary>
            public const string EarningDeductionDescription = "LONGDESC";

            /// <summary>
            /// Property for EarningDeductionShortDescript
            /// </summary>
            public const string EarningDeductionShortDescript = "SHORTDESC";

            /// <summary>
            /// Property for Inactive
            /// </summary>
            public const string Inactive = "INACTIVE";

            /// <summary>
            /// Property for InactiveAsOf
            /// </summary>
            public const string InactiveAsOf = "ASOF";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "LASTMAINT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "EARDEDTYPE";

            /// <summary>
            /// Property for Frequency
            /// </summary>
            public const string Frequency = "FREQUENCY";

            /// <summary>
            /// Property for Starts
            /// </summary>
            public const string Starts = "STARTS";

            /// <summary>
            /// Property for StartMonth
            /// </summary>
            public const string StartMonth = "STARTMONTH";

            /// <summary>
            /// Property for StartDay
            /// </summary>
            public const string StartDay = "STARTDAY";

            /// <summary>
            /// Property for Ends
            /// </summary>
            public const string Ends = "ENDS";

            /// <summary>
            /// Property for PrintOnCheck
            /// </summary>
            public const string PrintOnCheck = "PRNTONCHK";

            /// <summary>
            /// Property for RESERVEDPrintIfCurrentZero
            /// </summary>
            public const string RESERVEDPrintIfCurrentZero = "PRNTIF0";

            /// <summary>
            /// Property for RESERVEDPrintYTDIfCurrentZe
            /// </summary>
            public const string RESERVEDPrintYTDIfCurrentZe = "PRNTYTDIF0";

            /// <summary>
            /// Property for EmployeeCalculationMethod
            /// </summary>
            public const string EmployeeCalculationMethod = "ECALCMETH";

            /// <summary>
            /// Property for EmployeeW2Box
            /// </summary>
            public const string EmployeeW2Box = "EW2BOX";

            /// <summary>
            /// Property for EmployeeRate
            /// </summary>
            public const string EmployeeRate = "ERATE";

            /// <summary>
            /// Property for EmployeeAnnualMaximum
            /// </summary>
            public const string EmployeeAnnualMaximum = "EANNUALMAX";

            /// <summary>
            /// Property for EmployeeDailyMinimum
            /// </summary>
            public const string EmployeeDailyMinimum = "EDAILYMIN";

            /// <summary>
            /// Property for EmployeeDailyMaximum
            /// </summary>
            public const string EmployeeDailyMaximum = "EDAILYMAX";

            /// <summary>
            /// Property for EmployeeWeeklyMinimum
            /// </summary>
            public const string EmployeeWeeklyMinimum = "EWEEKLYMIN";

            /// <summary>
            /// Property for EmployeeWeeklyMaximum
            /// </summary>
            public const string EmployeeWeeklyMaximum = "EWEEKLYMAX";

            /// <summary>
            /// Property for EmployeeBiweeklyMinimum
            /// </summary>
            public const string EmployeeBiweeklyMinimum = "EBIWKLYMIN";

            /// <summary>
            /// Property for EmployeeBiweeklyMaximum
            /// </summary>
            public const string EmployeeBiweeklyMaximum = "EBIWKLYMAX";

            /// <summary>
            /// Property for EmployeeSemimonthlyMinimum
            /// </summary>
            public const string EmployeeSemimonthlyMinimum = "ESEMIMNMIN";

            /// <summary>
            /// Property for EmployeeSemimonthlyMaximum
            /// </summary>
            public const string EmployeeSemimonthlyMaximum = "ESEMIMNMAX";

            /// <summary>
            /// Property for EmployeeMonthlyMinimum
            /// </summary>
            public const string EmployeeMonthlyMinimum = "EMNTHLYMIN";

            /// <summary>
            /// Property for EmployeeMonthlyMaximum
            /// </summary>
            public const string EmployeeMonthlyMaximum = "EMNTHLYMAX";

            /// <summary>
            /// Property for EmployeeQuarterlyMinimum
            /// </summary>
            public const string EmployeeQuarterlyMinimum = "EQRTRLYMIN";

            /// <summary>
            /// Property for EmployeeQuarterlyMaximum
            /// </summary>
            public const string EmployeeQuarterlyMaximum = "EQRTRLYMAX";

            /// <summary>
            /// Property for EmployeeTenPeriodYearMinimum
            /// </summary>
            public const string Employee10PerYearMin = "E10PPPYMIN";

            /// <summary>
            /// Property for EmployeeTenPeriodYearMaximum
            /// </summary>
            public const string Employee10PerYearMax = "E10PPPYMAX";

            /// <summary>
            /// Property for EmployeeThirteenPeriodYearMi
            /// </summary>
            public const string Employee13PerYearMin = "E13PPPYMIN";

            /// <summary>
            /// Property for EmployeeThirteenPeriodYearMa
            /// </summary>
            public const string Employee13PerYearMax = "E13PPPYMAX";

            /// <summary>
            /// Property for E22PPPYMIN
            /// </summary>
            public const string Employee22PerYearMin = "E22PPPYMIN";

            /// <summary>
            /// Property for E22PPPYMAX
            /// </summary>
            public const string Employee22PerYearMax = "E22PPPYMAX";

            /// <summary>
            /// Property for EmployeeBaseLimit
            /// </summary>
            public const string EmployeeBaseLimit = "ELIMITBASE";

            /// <summary>
            /// Property for WageBracket1
            /// </summary>
            public const string WageBracket1 = "WGBRACK1";

            /// <summary>
            /// Property for AddAmount1
            /// </summary>
            public const string AddAmount1 = "WGADDAMT1";

            /// <summary>
            /// Property for PercntOfExcess1
            /// </summary>
            public const string PercntOfExcess1 = "WGPCTOVR1";

            /// <summary>
            /// Property for WageBracket2
            /// </summary>
            public const string WageBracket2 = "WGBRACK2";

            /// <summary>
            /// Property for AddAmount2
            /// </summary>
            public const string AddAmount2 = "WGADDAMT2";

            /// <summary>
            /// Property for PercntOfExcess2
            /// </summary>
            public const string PercntOfExcess2 = "WGPCTOVR2";

            /// <summary>
            /// Property for WageBracket3
            /// </summary>
            public const string WageBracket3 = "WGBRACK3";

            /// <summary>
            /// Property for AddAmount3
            /// </summary>
            public const string AddAmount3 = "WGADDAMT3";

            /// <summary>
            /// Property for PercntOfExcess3
            /// </summary>
            public const string PercntOfExcess3 = "WGPCTOVR3";

            /// <summary>
            /// Property for WageBracket4
            /// </summary>
            public const string WageBracket4 = "WGBRACK4";

            /// <summary>
            /// Property for AddAmount4
            /// </summary>
            public const string AddAmount4 = "WGADDAMT4";

            /// <summary>
            /// Property for PercntOfExcess4
            /// </summary>
            public const string PercntOfExcess4 = "WGPCTOVR4";

            /// <summary>
            /// Property for WageBracket5
            /// </summary>
            public const string WageBracket5 = "WGBRACK5";

            /// <summary>
            /// Property for AddAmount5
            /// </summary>
            public const string AddAmount5 = "WGADDAMT5";

            /// <summary>
            /// Property for PercntOfExcess5
            /// </summary>
            public const string PercntOfExcess5 = "WGPCTOVR5";

            /// <summary>
            /// Property for WageBracket6
            /// </summary>
            public const string WageBracket6 = "WGBRACK6";

            /// <summary>
            /// Property for AddAmount6
            /// </summary>
            public const string AddAmount6 = "WGADDAMT6";

            /// <summary>
            /// Property for PercntOfExcess6
            /// </summary>
            public const string PercntOfExcess6 = "WGPCTOVR6";

            /// <summary>
            /// Property for WageBracket7
            /// </summary>
            public const string WageBracket7 = "WGBRACK7";

            /// <summary>
            /// Property for AddAmount7
            /// </summary>
            public const string AddAmount7 = "WGADDAMT7";

            /// <summary>
            /// Property for PercntOfExcess7
            /// </summary>
            public const string PercntOfExcess7 = "WGPCTOVR7";

            /// <summary>
            /// Property for WageBracket8
            /// </summary>
            public const string WageBracket8 = "WGBRACK8";

            /// <summary>
            /// Property for AddAmount8
            /// </summary>
            public const string AddAmount8 = "WGADDAMT8";

            /// <summary>
            /// Property for PercntOfExcess8
            /// </summary>
            public const string PercntOfExcess8 = "WGPCTOVR8";

            /// <summary>
            /// Property for WageBracket9
            /// </summary>
            public const string WageBracket9 = "WGBRACK9";

            /// <summary>
            /// Property for AddAmount9
            /// </summary>
            public const string AddAmount9 = "WGADDAMT9";

            /// <summary>
            /// Property for PercntOfExcess9
            /// </summary>
            public const string PercntOfExcess9 = "WGPCTOVR9";

            /// <summary>
            /// Property for WageBracket10
            /// </summary>
            public const string WageBracket10 = "WGBRACK10";

            /// <summary>
            /// Property for AddAmount10
            /// </summary>
            public const string AddAmount10 = "WGADDAMT10";

            /// <summary>
            /// Property for PercntOfExcess10
            /// </summary>
            public const string PercntOfExcess10 = "WGPCTOVR10";

            /// <summary>
            /// Property for WageBracket11
            /// </summary>
            public const string WageBracket11 = "WGBRACK11";

            /// <summary>
            /// Property for AddAmount11
            /// </summary>
            public const string AddAmount11 = "WGADDAMT11";

            /// <summary>
            /// Property for PercntOfExcess11
            /// </summary>
            public const string PercntOfExcess11 = "WGPCTOVR11";

            /// <summary>
            /// Property for WageBracket12
            /// </summary>
            public const string WageBracket12 = "WGBRACK12";

            /// <summary>
            /// Property for AddAmount12
            /// </summary>
            public const string AddAmount12 = "WGADDAMT12";

            /// <summary>
            /// Property for PercntOfExcess12
            /// </summary>
            public const string PercntOfExcess12 = "WGPCTOVR12";

            /// <summary>
            /// Property for WageBracket13
            /// </summary>
            public const string WageBracket13 = "WGBRACK13";

            /// <summary>
            /// Property for AddAmount13
            /// </summary>
            public const string AddAmount13 = "WGADDAMT13";

            /// <summary>
            /// Property for PercntOfExcess13
            /// </summary>
            public const string PercntOfExcess13 = "WGPCTOVR13";

            /// <summary>
            /// Property for WageBracket14
            /// </summary>
            public const string WageBracket14 = "WGBRACK14";

            /// <summary>
            /// Property for AddAmount14
            /// </summary>
            public const string AddAmount14 = "WGADDAMT14";

            /// <summary>
            /// Property for PercntOfExcess14
            /// </summary>
            public const string PercntOfExcess14 = "WGPCTOVR14";

            /// <summary>
            /// Property for WageBracket15
            /// </summary>
            public const string WageBracket15 = "WGBRACK15";

            /// <summary>
            /// Property for AddAmount15
            /// </summary>
            public const string AddAmount15 = "WGADDAMT15";

            /// <summary>
            /// Property for PercntOfExcess15
            /// </summary>
            public const string PercntOfExcess15 = "WGPCTOVR15";

            /// <summary>
            /// Property for WageBracket16
            /// </summary>
            public const string WageBracket16 = "WGBRACK16";

            /// <summary>
            /// Property for AddAmount16
            /// </summary>
            public const string AddAmount16 = "WGADDAMT16";

            /// <summary>
            /// Property for PercntOfExcess16
            /// </summary>
            public const string PercntOfExcess16 = "WGPCTOVR16";

            /// <summary>
            /// Property for WageBracket17
            /// </summary>
            public const string WageBracket17 = "WGBRACK17";

            /// <summary>
            /// Property for AddAmount17
            /// </summary>
            public const string AddAmount17 = "WGADDAMT17";

            /// <summary>
            /// Property for PercntOfExcess17
            /// </summary>
            public const string PercntOfExcess17 = "WGPCTOVR17";

            /// <summary>
            /// Property for WageBracket18
            /// </summary>
            public const string WageBracket18 = "WGBRACK18";

            /// <summary>
            /// Property for AddAmount18
            /// </summary>
            public const string AddAmount18 = "WGADDAMT18";

            /// <summary>
            /// Property for PercntOfExcess18
            /// </summary>
            public const string PercntOfExcess18 = "WGPCTOVR18";

            /// <summary>
            /// Property for WageBracket19
            /// </summary>
            public const string WageBracket19 = "WGBRACK19";

            /// <summary>
            /// Property for AddAmount19
            /// </summary>
            public const string AddAmount19 = "WGADDAMT19";

            /// <summary>
            /// Property for PercntOfExcess19
            /// </summary>
            public const string PercntOfExcess19 = "WGPCTOVR19";

            /// <summary>
            /// Property for WageBracket20
            /// </summary>
            public const string WageBracket20 = "WGBRACK20";

            /// <summary>
            /// Property for AddAmount20
            /// </summary>
            public const string AddAmount20 = "WGADDAMT20";

            /// <summary>
            /// Property for PercntOfExcess20
            /// </summary>
            public const string PercntOfExcess20 = "WGPCTOVR20";

            /// <summary>
            /// Property for EmployerCalculationMethod
            /// </summary>
            public const string EmployerCalculationMethod = "RCALCMETH";

            /// <summary>
            /// Property for EmployerW2Box
            /// </summary>
            public const string EmployerW2Box = "RW2BOX";

            /// <summary>
            /// Property for EmployerRate
            /// </summary>
            public const string EmployerRate = "RRATE";

            /// <summary>
            /// Property for EmployerAnnualMaximum
            /// </summary>
            public const string EmployerAnnualMaximum = "RANNUALMAX";

            /// <summary>
            /// Property for EmployerDailyMinimum
            /// </summary>
            public const string EmployerDailyMinimum = "RDAILYMIN";

            /// <summary>
            /// Property for EmployerDailyMaximum
            /// </summary>
            public const string EmployerDailyMaximum = "RDAILYMAX";

            /// <summary>
            /// Property for EmployerWeeklyMinimum
            /// </summary>
            public const string EmployerWeeklyMinimum = "RWEEKLYMIN";

            /// <summary>
            /// Property for EmployerWeeklyMaximum
            /// </summary>
            public const string EmployerWeeklyMaximum = "RWEEKLYMAX";

            /// <summary>
            /// Property for EmployerBiweeklyMinimum
            /// </summary>
            public const string EmployerBiweeklyMinimum = "RBIWKLYMIN";

            /// <summary>
            /// Property for EmployerBiweeklyMaximum
            /// </summary>
            public const string EmployerBiweeklyMaximum = "RBIWKLYMAX";

            /// <summary>
            /// Property for EmployerSemimonthlyMinimum
            /// </summary>
            public const string EmployerSemimonthlyMinimum = "RSEMIMNMIN";

            /// <summary>
            /// Property for EmployerSemimonthlyMaximum
            /// </summary>
            public const string EmployerSemimonthlyMaximum = "RSEMIMNMAX";

            /// <summary>
            /// Property for EmployerMonthlyMinimum
            /// </summary>
            public const string EmployerMonthlyMinimum = "RMNTHLYMIN";

            /// <summary>
            /// Property for EmployerMonthlyMaximum
            /// </summary>
            public const string EmployerMonthlyMaximum = "RMNTHLYMAX";

            /// <summary>
            /// Property for EmployerQuarterlyMinimum
            /// </summary>
            public const string EmployerQuarterlyMinimum = "RQRTRLYMIN";

            /// <summary>
            /// Property for EmployerQuarterlyMaximum
            /// </summary>
            public const string EmployerQuarterlyMaximum = "RQRTRLYMAX";

            /// <summary>
            /// Property for EmployerTenPerYearMinimum
            /// </summary>
            public const string Employer10PerYearMin = "R10PPPYMIN";

            /// <summary>
            /// Property for EmployerTenPerYearMaximum
            /// </summary>
            public const string Employer10PerYearMax = "R10PPPYMAX";

            /// <summary>
            /// Property for EmployerThirteenPerYearMinim
            /// </summary>
            public const string Employer13PerYearMin = "R13PPPYMIN";

            /// <summary>
            /// Property for EmployerThirteenPerYearMaxim
            /// </summary>
            public const string Employer13PerYearMax = "R13PPPYMAX";

            /// <summary>
            /// Property for EmployerTwentytwoPerYearMini
            /// </summary>
            public const string Employer22PerYearMin = "R22PPPYMIN";

            /// <summary>
            /// Property for EmployerTwentytwoPerYearMaxi
            /// </summary>
            public const string Employer22PerYearMax = "R22PPPYMAX";

            /// <summary>
            /// Property for EmployerBaseLimit
            /// </summary>
            public const string EmployerBaseLimit = "RLIMITBASE";

            /// <summary>
            /// Property for SubjectToWorkersCompensation
            /// </summary>
            public const string SubjectToWorkersCompensation = "ALLOWWCC";

            /// <summary>
            /// Property for CommissionAmount1
            /// </summary>
            public const string CommissionAmount1 = "COMMAMT1";

            /// <summary>
            /// Property for CommissionPct1
            /// </summary>
            public const string CommissionPct1 = "COMMPCT1";

            /// <summary>
            /// Property for CommissionAmount2
            /// </summary>
            public const string CommissionAmount2 = "COMMAMT2";

            /// <summary>
            /// Property for CommissionPct2
            /// </summary>
            public const string CommissionPct2 = "COMMPCT2";

            /// <summary>
            /// Property for CommissionAmount3
            /// </summary>
            public const string CommissionAmount3 = "COMMAMT3";

            /// <summary>
            /// Property for CommissionPct3
            /// </summary>
            public const string CommissionPct3 = "COMMPCT3";

            /// <summary>
            /// Property for CommissionAmount4
            /// </summary>
            public const string CommissionAmount4 = "COMMAMT4";

            /// <summary>
            /// Property for CommissionPct4
            /// </summary>
            public const string CommissionPct4 = "COMMPCT4";

            /// <summary>
            /// Property for CommissionAmount5
            /// </summary>
            public const string CommissionAmount5 = "COMMAMT5";

            /// <summary>
            /// Property for CommissionPct5
            /// </summary>
            public const string CommissionPct5 = "COMMPCT5";

            /// <summary>
            /// Property for CommissionAmountExcess
            /// </summary>
            public const string CommissionAmountExcess = "COMMPCTX";

            /// <summary>
            /// Property for PieceCount1
            /// </summary>
            public const string PieceCount1 = "PIECNUM1";

            /// <summary>
            /// Property for PieceAmount1
            /// </summary>
            public const string PieceAmount1 = "PIECAMT1";

            /// <summary>
            /// Property for PieceCount2
            /// </summary>
            public const string PieceCount2 = "PIECNUM2";

            /// <summary>
            /// Property for PieceAmount2
            /// </summary>
            public const string PieceAmount2 = "PIECAMT2";

            /// <summary>
            /// Property for PieceCount3
            /// </summary>
            public const string PieceCount3 = "PIECNUM3";

            /// <summary>
            /// Property for PieceAmount3
            /// </summary>
            public const string PieceAmount3 = "PIECAMT3";

            /// <summary>
            /// Property for PieceCount4
            /// </summary>
            public const string PieceCount4 = "PIECNUM4";

            /// <summary>
            /// Property for PieceAmount4
            /// </summary>
            public const string PieceAmount4 = "PIECAMT4";

            /// <summary>
            /// Property for PieceCount5
            /// </summary>
            public const string PieceCount5 = "PIECNUM5";

            /// <summary>
            /// Property for PieceAmount5
            /// </summary>
            public const string PieceAmount5 = "PIECAMT5";

            /// <summary>
            /// Property for MaxPieceRateAmount
            /// </summary>
            public const string MaxPieceRateAmount = "PIECAMTX";

            /// <summary>
            /// Property for TipDisbursement
            /// </summary>
            public const string TipDisbursement = "TIPDISB";

            /// <summary>
            /// Property for RepaymentDeduction
            /// </summary>
            public const string RepaymentDeduction = "PAYDOWNDED";

            /// <summary>
            /// Property for AdvanceToBeRepaid
            /// </summary>
            public const string AdvanceToBeRepaid = "REPAYID";

            /// <summary>
            /// Property for Carryover
            /// </summary>
            public const string Carryover = "CARRYOVER";

            /// <summary>
            /// Property for CarryOverDay
            /// </summary>
            public const string CarryOverDay = "COVERDAY";

            /// <summary>
            /// Property for CarryOverMonth
            /// </summary>
            public const string CarryOverMonth = "COVERMONTH";

            /// <summary>
            /// Property for PostLiab
            /// </summary>
            public const string PostLiab = "POSTLIAB";

            /// <summary>
            /// Property for ServiceYear1
            /// </summary>
            public const string ServiceYear1 = "SVCYEAR1";

            /// <summary>
            /// Property for BeginningHours1
            /// </summary>
            public const string BeginningHours1 = "BEGHRS1";

            /// <summary>
            /// Property for IncrementHours1
            /// </summary>
            public const string IncrementHours1 = "INCRHRS1";

            /// <summary>
            /// Property for MaxAnnualAccrual1
            /// </summary>
            public const string MaxAnnualAccrual1 = "MAXACCR1";

            /// <summary>
            /// Property for MaxCarryOverHours1
            /// </summary>
            public const string MaxCarryOverHours1 = "MAXCARRY1";

            /// <summary>
            /// Property for ServiceYear2
            /// </summary>
            public const string ServiceYear2 = "SVCYEAR2";

            /// <summary>
            /// Property for BeginningHours2
            /// </summary>
            public const string BeginningHours2 = "BEGHRS2";

            /// <summary>
            /// Property for IncrementHours2
            /// </summary>
            public const string IncrementHours2 = "INCRHRS2";

            /// <summary>
            /// Property for MaxAnnualAccrual2
            /// </summary>
            public const string MaxAnnualAccrual2 = "MAXACCR2";

            /// <summary>
            /// Property for MaxCarryOverHours2
            /// </summary>
            public const string MaxCarryOverHours2 = "MAXCARRY2";

            /// <summary>
            /// Property for ServiceYear3
            /// </summary>
            public const string ServiceYear3 = "SVCYEAR3";

            /// <summary>
            /// Property for BeginningHours3
            /// </summary>
            public const string BeginningHours3 = "BEGHRS3";

            /// <summary>
            /// Property for IncrementHours3
            /// </summary>
            public const string IncrementHours3 = "INCRHRS3";

            /// <summary>
            /// Property for MaxAnnualAccrual3
            /// </summary>
            public const string MaxAnnualAccrual3 = "MAXACCR3";

            /// <summary>
            /// Property for MaxCarryOverHours3
            /// </summary>
            public const string MaxCarryOverHours3 = "MAXCARRY3";

            /// <summary>
            /// Property for ServiceYear4
            /// </summary>
            public const string ServiceYear4 = "SVCYEAR4";

            /// <summary>
            /// Property for BeginningHours4
            /// </summary>
            public const string BeginningHours4 = "BEGHRS4";

            /// <summary>
            /// Property for IncrementHours4
            /// </summary>
            public const string IncrementHours4 = "INCRHRS4";

            /// <summary>
            /// Property for MaxAnnualAccrual4
            /// </summary>
            public const string MaxAnnualAccrual4 = "MAXACCR4";

            /// <summary>
            /// Property for MaxCarryOverHours4
            /// </summary>
            public const string MaxCarryOverHours4 = "MAXCARRY4";

            /// <summary>
            /// Property for Level
            /// </summary>
            public const string Level = "LEVEL";

            /// <summary>
            /// Property for BaseHoursListUse
            /// </summary>
            public const string BaseHoursListUse = "LISTUSEBHI";

            /// <summary>
            /// Property for BaseHoursRegular
            /// </summary>
            public const string BaseHoursRegular = "REGULARBHI";

            /// <summary>
            /// Property for BaseHoursOvertime
            /// </summary>
            public const string BaseHoursOvertime = "OVRTIMEBHI";

            /// <summary>
            /// Property for BaseEarningsListUse
            /// </summary>
            public const string BaseEarningsListUse = "LISTUSEBEI";

            /// <summary>
            /// Property for BaseEarningsRegular
            /// </summary>
            public const string BaseEarningsRegular = "REGULARBEI";

            /// <summary>
            /// Property for BaseEarningsOvertime
            /// </summary>
            public const string BaseEarningsOvertime = "OVRTIMEBEI";

            /// <summary>
            /// Property for BaseEarningsShift
            /// </summary>
            public const string BaseEarningsShift = "SHIFTBEI";

            /// <summary>
            /// Property for BaseDeductionsListUse
            /// </summary>
            public const string BaseDeductionsListUse = "LISTUSEBDI";

            /// <summary>
            /// Property for BaseTaxListUse
            /// </summary>
            public const string BaseTaxListUse = "LISTUSEBTI";

            /// <summary>
            /// Property for ListUseOfTypeOfTaxableWage
            /// </summary>
            public const string ListUseOfTypeOfTaxableWage = "LISTUSETTW";

            /// <summary>
            /// Property for WithholdingMethodForTaxableW
            /// </summary>
            public const string WithholdingMethodForTaxableW = "WHMETHTTW";

            /// <summary>
            /// Property for TakeDeductionBeforeListUse
            /// </summary>
            public const string TakeDeductionBeforeListUse = "LISTUSETDB";

            /// <summary>
            /// Property for ET4BOX
            /// </summary>
            public const string ET4BOX = "ET4BOX";

            /// <summary>
            /// Property for RT4BOX
            /// </summary>
            public const string RT4BOX = "RT4BOX";

            /// <summary>
            /// Property for ER1BOX
            /// </summary>
            public const string ER1BOX = "ER1BOX";

            /// <summary>
            /// Property for RR1BOX
            /// </summary>
            public const string RR1BOX = "RR1BOX";

            /// <summary>
            /// Property for EASSOCW2SW
            /// </summary>
            public const string EASSOCW2SW = "EASSOCW2SW";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EASSOCTAX
            /// </summary>
            public const string EASSOCTAX = "EASSOCTAX";

            /// <summary>
            /// Property for RASSOCW2SW
            /// </summary>
            public const string RASSOCW2SW = "RASSOCW2SW";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RASSOCTAX
            /// </summary>
            public const string RASSOCTAX = "RASSOCTAX";

            /// <summary>
            /// Property for PostBenefit
            /// </summary>
            public const string PostBenefit = "POSTBENE";

            /// <summary>
            /// Property for PayAccrual
            /// </summary>
            public const string PayAccrual = "PAYACCRUAL";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for NONPERPYMT
            /// </summary>
            public const string NONPERPYMT = "NONPERPYMT";

            /// <summary>
            /// Property for LinkedEarning
            /// </summary>
            public const string LinkedEarning = "LINKEARN";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for IncludeInFLSAOvertimeCalc
            /// </summary>
            public const string IncludeInFLSAOvertimeCalc = "SWFLSA";

            /// <summary>
            /// Property for ProgressiveCalcCommissions
            /// </summary>
            public const string ProgressiveCalcCommissions = "COMMINCREM";

            /// <summary>
            /// Property for AnnualizedWageBrackets
            /// </summary>
            public const string AnnualizedWageBrackets = "WGANNUALIZ";

            /// <summary>
            /// Property for ProgressiveCalcWageBrackets
            /// </summary>
            public const string ProgressiveCalcWageBrackets = "WGBRINCREM";

            /// <summary>
            /// Property for ProgressiveCalcPieceRate
            /// </summary>
            public const string ProgressiveCalcPieceRate = "PIECINCREM";

            /// <summary>
            /// Property for EmployeeLifetimeMaximum
            /// </summary>
            public const string EmployeeLifetimeMaximum = "ELIFETMMAX";

            /// <summary>
            /// Property for EmployerLifetimeMaximum
            /// </summary>
            public const string EmployerLifetimeMaximum = "RLIFETMMAX";

            /// <summary>
            /// Property for EmployeeSecRateEffective
            /// </summary>
            public const string EmployeeSecRateEffective = "E2NDRATEIN";

            /// <summary>
            /// Property for EmployerSecRateEffective
            /// </summary>
            public const string EmployerSecRateEffective = "R2NDRATEIN";

            /// <summary>
            /// Property for EmployeeSecondaryRate
            /// </summary>
            public const string EmployeeSecondaryRate = "E2NDRATE";

            /// <summary>
            /// Property for EmployerSecondaryRate
            /// </summary>
            public const string EmployerSecondaryRate = "R2NDRATE";

            /// <summary>
            /// Property for ServiceYear5
            /// </summary>
            public const string ServiceYear5 = "SVCYEAR5";

            /// <summary>
            /// Property for BeginningHours5
            /// </summary>
            public const string BeginningHours5 = "BEGHRS5";

            /// <summary>
            /// Property for IncrementHours5
            /// </summary>
            public const string IncrementHours5 = "INCRHRS5";

            /// <summary>
            /// Property for MaxAnnualAccrual5
            /// </summary>
            public const string MaxAnnualAccrual5 = "MAXACCR5";

            /// <summary>
            /// Property for MaxCarryOverHours5
            /// </summary>
            public const string MaxCarryOverHours5 = "MAXCARRY5";

            /// <summary>
            /// Property for ServiceYear6
            /// </summary>
            public const string ServiceYear6 = "SVCYEAR6";

            /// <summary>
            /// Property for BeginningHours6
            /// </summary>
            public const string BeginningHours6 = "BEGHRS6";

            /// <summary>
            /// Property for IncrementHours6
            /// </summary>
            public const string IncrementHours6 = "INCRHRS6";

            /// <summary>
            /// Property for MaxAnnualAccrual6
            /// </summary>
            public const string MaxAnnualAccrual6 = "MAXACCR6";

            /// <summary>
            /// Property for MaxCarryOverHours6
            /// </summary>
            public const string MaxCarryOverHours6 = "MAXCARRY6";

            /// <summary>
            /// Property for ServiceYear7
            /// </summary>
            public const string ServiceYear7 = "SVCYEAR7";

            /// <summary>
            /// Property for BeginningHours7
            /// </summary>
            public const string BeginningHours7 = "BEGHRS7";

            /// <summary>
            /// Property for IncrementHours7
            /// </summary>
            public const string IncrementHours7 = "INCRHRS7";

            /// <summary>
            /// Property for MaxAnnualAccrual7
            /// </summary>
            public const string MaxAnnualAccrual7 = "MAXACCR7";

            /// <summary>
            /// Property for MaxCarryOverHours7
            /// </summary>
            public const string MaxCarryOverHours7 = "MAXCARRY7";

            /// <summary>
            /// Property for ServiceYear8
            /// </summary>
            public const string ServiceYear8 = "SVCYEAR8";

            /// <summary>
            /// Property for BeginningHours8
            /// </summary>
            public const string BeginningHours8 = "BEGHRS8";

            /// <summary>
            /// Property for IncrementHours8
            /// </summary>
            public const string IncrementHours8 = "INCRHRS8";

            /// <summary>
            /// Property for MaxAnnualAccrual8
            /// </summary>
            public const string MaxAnnualAccrual8 = "MAXACCR8";

            /// <summary>
            /// Property for MaxCarryOverHours8
            /// </summary>
            public const string MaxCarryOverHours8 = "MAXCARRY8";

            /// <summary>
            /// Property for ServiceYear9
            /// </summary>
            public const string ServiceYear9 = "SVCYEAR9";

            /// <summary>
            /// Property for BeginningHours9
            /// </summary>
            public const string BeginningHours9 = "BEGHRS9";

            /// <summary>
            /// Property for IncrementHours9
            /// </summary>
            public const string IncrementHours9 = "INCRHRS9";

            /// <summary>
            /// Property for MaxAnnualAccrual9
            /// </summary>
            public const string MaxAnnualAccrual9 = "MAXACCR9";

            /// <summary>
            /// Property for MaxCarryOverHours9
            /// </summary>
            public const string MaxCarryOverHours9 = "MAXCARRY9";

            /// <summary>
            /// Property for ServiceYear10
            /// </summary>
            public const string ServiceYear10 = "SVCYEAR10";

            /// <summary>
            /// Property for BeginningHours10
            /// </summary>
            public const string BeginningHours10 = "BEGHRS10";

            /// <summary>
            /// Property for IncrementHours10
            /// </summary>
            public const string IncrementHours10 = "INCRHRS10";

            /// <summary>
            /// Property for MaxAnnualAccrual10
            /// </summary>
            public const string MaxAnnualAccrual10 = "MAXACCR10";

            /// <summary>
            /// Property for MaxCarryOverHours10
            /// </summary>
            public const string MaxCarryOverHours10 = "MAXCARRY10";

            /// <summary>
            /// Property for CostCenterOverrideBasedOnCa
            /// </summary>
            public const string CostCenterOverrideBasedOnCa = "CCOVERRIDE";

            /// <summary>
            /// Property for BillingRates
            /// </summary>
            public const string BillingRates = "BILLINGS";

            /// <summary>
            /// Property for BillingPercentage1
            /// </summary>
            public const string BillingPercentage1 = "BILLPCT1";

            /// <summary>
            /// Property for BillingPercentage2
            /// </summary>
            public const string BillingPercentage2 = "BILLPCT2";

            /// <summary>
            /// Property for BillingPercentage3
            /// </summary>
            public const string BillingPercentage3 = "BILLPCT3";

            /// <summary>
            /// Property for BillingPercentage4
            /// </summary>
            public const string BillingPercentage4 = "BILLPCT4";

            /// <summary>
            /// Property for BillingPercentage5
            /// </summary>
            public const string BillingPercentage5 = "BILLPCT5";

            /// <summary>
            /// Property for BillingPercentage6
            /// </summary>
            public const string BillingPercentage6 = "BILLPCT6";

            /// <summary>
            /// Property for CalculationMaxCarryOverBasedOnR
            /// </summary>
            public const string CalculationMaxCarryOverBasedOnR = "MAXONREM";

            /// <summary>
            /// Property for CapAccrualAtMaxAccrual
            /// </summary>
            public const string CapAccrualAtMaxAccrual = "MAXONACCR";

            /// <summary>
            /// Property for ReportAs
            /// </summary>
            public const string ReportAs = "COVID";

            /// <summary>
            /// Property for RESERVEDCDNOnly
            /// </summary>
            public const string RESERVEDCDNOnly = "OTHERBOX";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for Message
            /// </summary>
            public string Message { get; set; }
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EarningsDeduction Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for EarningDeduction
            /// </summary>
            public const int EarningDeduction = 1;

            /// <summary>
            /// Property Indexer for EarningDeductionDescription
            /// </summary>
            public const int EarningDeductionDescription = 2;

            /// <summary>
            /// Property Indexer for EarningDeductionShortDescript
            /// </summary>
            public const int EarningDeductionShortDescript = 3;

            /// <summary>
            /// Property Indexer for Inactive
            /// </summary>
            public const int Inactive = 4;

            /// <summary>
            /// Property Indexer for InactiveAsOf
            /// </summary>
            public const int InactiveAsOf = 5;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 6;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 7;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 8;

            /// <summary>
            /// Property Indexer for Frequency
            /// </summary>
            public const int Frequency = 9;

            /// <summary>
            /// Property Indexer for Starts
            /// </summary>
            public const int Starts = 10;

            /// <summary>
            /// Property Indexer for StartMonth
            /// </summary>
            public const int StartMonth = 11;

            /// <summary>
            /// Property Indexer for StartDay
            /// </summary>
            public const int StartDay = 12;

            /// <summary>
            /// Property Indexer for Ends
            /// </summary>
            public const int Ends = 13;

            /// <summary>
            /// Property Indexer for PrintOnCheck
            /// </summary>
            public const int PrintOnCheck = 14;

            /// <summary>
            /// Property Indexer for RESERVEDPrintIfCurrentZero
            /// </summary>
            public const int RESERVEDPrintIfCurrentZero = 15;

            /// <summary>
            /// Property Indexer for RESERVEDPrintYTDIfCurrentZe
            /// </summary>
            public const int RESERVEDPrintYTDIfCurrentZe = 16;

            /// <summary>
            /// Property Indexer for EmployeeCalculationMethod
            /// </summary>
            public const int EmployeeCalculationMethod = 17;

            /// <summary>
            /// Property Indexer for EmployeeW2Box
            /// </summary>
            public const int EmployeeW2Box = 18;

            /// <summary>
            /// Property Indexer for EmployeeRate
            /// </summary>
            public const int EmployeeRate = 19;

            /// <summary>
            /// Property Indexer for EmployeeAnnualMaximum
            /// </summary>
            public const int EmployeeAnnualMaximum = 20;

            /// <summary>
            /// Property Indexer for EmployeeDailyMinimum
            /// </summary>
            public const int EmployeeDailyMinimum = 21;

            /// <summary>
            /// Property Indexer for EmployeeDailyMaximum
            /// </summary>
            public const int EmployeeDailyMaximum = 22;

            /// <summary>
            /// Property Indexer for EmployeeWeeklyMinimum
            /// </summary>
            public const int EmployeeWeeklyMinimum = 23;

            /// <summary>
            /// Property Indexer for EmployeeWeeklyMaximum
            /// </summary>
            public const int EmployeeWeeklyMaximum = 24;

            /// <summary>
            /// Property Indexer for EmployeeBiweeklyMinimum
            /// </summary>
            public const int EmployeeBiweeklyMinimum = 25;

            /// <summary>
            /// Property Indexer for EmployeeBiweeklyMaximum
            /// </summary>
            public const int EmployeeBiweeklyMaximum = 26;

            /// <summary>
            /// Property Indexer for EmployeeSemimonthlyMinimum
            /// </summary>
            public const int EmployeeSemimonthlyMinimum = 27;

            /// <summary>
            /// Property Indexer for EmployeeSemimonthlyMaximum
            /// </summary>
            public const int EmployeeSemimonthlyMaximum = 28;

            /// <summary>
            /// Property Indexer for EmployeeMonthlyMinimum
            /// </summary>
            public const int EmployeeMonthlyMinimum = 29;

            /// <summary>
            /// Property Indexer for EmployeeMonthlyMaximum
            /// </summary>
            public const int EmployeeMonthlyMaximum = 30;

            /// <summary>
            /// Property Indexer for EmployeeQuarterlyMinimum
            /// </summary>
            public const int EmployeeQuarterlyMinimum = 31;

            /// <summary>
            /// Property Indexer for EmployeeQuarterlyMaximum
            /// </summary>
            public const int EmployeeQuarterlyMaximum = 32;

            /// <summary>
            /// Property Indexer for EmployeeTenPeriodYearMinimum
            /// </summary>
            public const int Employee10PerYearMin = 33;

            /// <summary>
            /// Property Indexer for EmployeeTenPeriodYearMaximum
            /// </summary>
            public const int Employee10PerYearMax = 34;

            /// <summary>
            /// Property Indexer for EmployeeThirteenPeriodYearMi
            /// </summary>
            public const int Employee13PerYearMin = 35;

            /// <summary>
            /// Property Indexer for EmployeeThirteenPeriodYearMa
            /// </summary>
            public const int Employee13PerYearMax = 36;

            /// <summary>
            /// Property Indexer for E22PPPYMIN
            /// </summary>
            public const int Employee22PerYearMin = 37;

            /// <summary>
            /// Property Indexer for E22PPPYMAX
            /// </summary>
            public const int Employee22PerYearMax = 38;

            /// <summary>
            /// Property Indexer for EmployeeBaseLimit
            /// </summary>
            public const int EmployeeBaseLimit = 39;

            /// <summary>
            /// Property Indexer for WageBracket1
            /// </summary>
            public const int WageBracket1 = 40;

            /// <summary>
            /// Property Indexer for AddAmount1
            /// </summary>
            public const int AddAmount1 = 41;

            /// <summary>
            /// Property Indexer for PercntOfExcess1
            /// </summary>
            public const int PercntOfExcess1 = 42;

            /// <summary>
            /// Property Indexer for WageBracket2
            /// </summary>
            public const int WageBracket2 = 43;

            /// <summary>
            /// Property Indexer for AddAmount2
            /// </summary>
            public const int AddAmount2 = 44;

            /// <summary>
            /// Property Indexer for PercntOfExcess2
            /// </summary>
            public const int PercntOfExcess2 = 45;

            /// <summary>
            /// Property Indexer for WageBracket3
            /// </summary>
            public const int WageBracket3 = 46;

            /// <summary>
            /// Property Indexer for AddAmount3
            /// </summary>
            public const int AddAmount3 = 47;

            /// <summary>
            /// Property Indexer for PercntOfExcess3
            /// </summary>
            public const int PercntOfExcess3 = 48;

            /// <summary>
            /// Property Indexer for WageBracket4
            /// </summary>
            public const int WageBracket4 = 49;

            /// <summary>
            /// Property Indexer for AddAmount4
            /// </summary>
            public const int AddAmount4 = 50;

            /// <summary>
            /// Property Indexer for PercntOfExcess4
            /// </summary>
            public const int PercntOfExcess4 = 51;

            /// <summary>
            /// Property Indexer for WageBracket5
            /// </summary>
            public const int WageBracket5 = 52;

            /// <summary>
            /// Property Indexer for AddAmount5
            /// </summary>
            public const int AddAmount5 = 53;

            /// <summary>
            /// Property Indexer for PercntOfExcess5
            /// </summary>
            public const int PercntOfExcess5 = 54;

            /// <summary>
            /// Property Indexer for WageBracket6
            /// </summary>
            public const int WageBracket6 = 55;

            /// <summary>
            /// Property Indexer for AddAmount6
            /// </summary>
            public const int AddAmount6 = 56;

            /// <summary>
            /// Property Indexer for PercntOfExcess6
            /// </summary>
            public const int PercntOfExcess6 = 57;

            /// <summary>
            /// Property Indexer for WageBracket7
            /// </summary>
            public const int WageBracket7 = 58;

            /// <summary>
            /// Property Indexer for AddAmount7
            /// </summary>
            public const int AddAmount7 = 59;

            /// <summary>
            /// Property Indexer for PercntOfExcess7
            /// </summary>
            public const int PercntOfExcess7 = 60;

            /// <summary>
            /// Property Indexer for WageBracket8
            /// </summary>
            public const int WageBracket8 = 61;

            /// <summary>
            /// Property Indexer for AddAmount8
            /// </summary>
            public const int AddAmount8 = 62;

            /// <summary>
            /// Property Indexer for PercntOfExcess8
            /// </summary>
            public const int PercntOfExcess8 = 63;

            /// <summary>
            /// Property Indexer for WageBracket9
            /// </summary>
            public const int WageBracket9 = 64;

            /// <summary>
            /// Property Indexer for AddAmount9
            /// </summary>
            public const int AddAmount9 = 65;

            /// <summary>
            /// Property Indexer for PercntOfExcess9
            /// </summary>
            public const int PercntOfExcess9 = 66;

            /// <summary>
            /// Property Indexer for WageBracket10
            /// </summary>
            public const int WageBracket10 = 67;

            /// <summary>
            /// Property Indexer for AddAmount10
            /// </summary>
            public const int AddAmount10 = 68;

            /// <summary>
            /// Property Indexer for PercntOfExcess10
            /// </summary>
            public const int PercntOfExcess10 = 69;

            /// <summary>
            /// Property Indexer for WageBracket11
            /// </summary>
            public const int WageBracket11 = 70;

            /// <summary>
            /// Property Indexer for AddAmount11
            /// </summary>
            public const int AddAmount11 = 71;

            /// <summary>
            /// Property Indexer for PercntOfExcess11
            /// </summary>
            public const int PercntOfExcess11 = 72;

            /// <summary>
            /// Property Indexer for WageBracket12
            /// </summary>
            public const int WageBracket12 = 73;

            /// <summary>
            /// Property Indexer for AddAmount12
            /// </summary>
            public const int AddAmount12 = 74;

            /// <summary>
            /// Property Indexer for PercntOfExcess12
            /// </summary>
            public const int PercntOfExcess12 = 75;

            /// <summary>
            /// Property Indexer for WageBracket13
            /// </summary>
            public const int WageBracket13 = 76;

            /// <summary>
            /// Property Indexer for AddAmount13
            /// </summary>
            public const int AddAmount13 = 77;

            /// <summary>
            /// Property Indexer for PercntOfExcess13
            /// </summary>
            public const int PercntOfExcess13 = 78;

            /// <summary>
            /// Property Indexer for WageBracket14
            /// </summary>
            public const int WageBracket14 = 79;

            /// <summary>
            /// Property Indexer for AddAmount14
            /// </summary>
            public const int AddAmount14 = 80;

            /// <summary>
            /// Property Indexer for PercntOfExcess14
            /// </summary>
            public const int PercntOfExcess14 = 81;

            /// <summary>
            /// Property Indexer for WageBracket15
            /// </summary>
            public const int WageBracket15 = 82;

            /// <summary>
            /// Property Indexer for AddAmount15
            /// </summary>
            public const int AddAmount15 = 83;

            /// <summary>
            /// Property Indexer for PercntOfExcess15
            /// </summary>
            public const int PercntOfExcess15 = 84;

            /// <summary>
            /// Property Indexer for WageBracket16
            /// </summary>
            public const int WageBracket16 = 85;

            /// <summary>
            /// Property Indexer for AddAmount16
            /// </summary>
            public const int AddAmount16 = 86;

            /// <summary>
            /// Property Indexer for PercntOfExcess16
            /// </summary>
            public const int PercntOfExcess16 = 87;

            /// <summary>
            /// Property Indexer for WageBracket17
            /// </summary>
            public const int WageBracket17 = 88;

            /// <summary>
            /// Property Indexer for AddAmount17
            /// </summary>
            public const int AddAmount17 = 89;

            /// <summary>
            /// Property Indexer for PercntOfExcess17
            /// </summary>
            public const int PercntOfExcess17 = 90;

            /// <summary>
            /// Property Indexer for WageBracket18
            /// </summary>
            public const int WageBracket18 = 91;

            /// <summary>
            /// Property Indexer for AddAmount18
            /// </summary>
            public const int AddAmount18 = 92;

            /// <summary>
            /// Property Indexer for PercntOfExcess18
            /// </summary>
            public const int PercntOfExcess18 = 93;

            /// <summary>
            /// Property Indexer for WageBracket19
            /// </summary>
            public const int WageBracket19 = 94;

            /// <summary>
            /// Property Indexer for AddAmount19
            /// </summary>
            public const int AddAmount19 = 95;

            /// <summary>
            /// Property Indexer for PercntOfExcess19
            /// </summary>
            public const int PercntOfExcess19 = 96;

            /// <summary>
            /// Property Indexer for WageBracket20
            /// </summary>
            public const int WageBracket20 = 97;

            /// <summary>
            /// Property Indexer for AddAmount20
            /// </summary>
            public const int AddAmount20 = 98;

            /// <summary>
            /// Property Indexer for PercntOfExcess20
            /// </summary>
            public const int PercntOfExcess20 = 99;

            /// <summary>
            /// Property Indexer for EmployerCalculationMethod
            /// </summary>
            public const int EmployerCalculationMethod = 100;

            /// <summary>
            /// Property Indexer for EmployerW2Box
            /// </summary>
            public const int EmployerW2Box = 101;

            /// <summary>
            /// Property Indexer for EmployerRate
            /// </summary>
            public const int EmployerRate = 102;

            /// <summary>
            /// Property Indexer for EmployerAnnualMaximum
            /// </summary>
            public const int EmployerAnnualMaximum = 103;

            /// <summary>
            /// Property Indexer for EmployerDailyMinimum
            /// </summary>
            public const int EmployerDailyMinimum = 104;

            /// <summary>
            /// Property Indexer for EmployerDailyMaximum
            /// </summary>
            public const int EmployerDailyMaximum = 105;

            /// <summary>
            /// Property Indexer for EmployerWeeklyMinimum
            /// </summary>
            public const int EmployerWeeklyMinimum = 106;

            /// <summary>
            /// Property Indexer for EmployerWeeklyMaximum
            /// </summary>
            public const int EmployerWeeklyMaximum = 107;

            /// <summary>
            /// Property Indexer for EmployerBiweeklyMinimum
            /// </summary>
            public const int EmployerBiweeklyMinimum = 108;

            /// <summary>
            /// Property Indexer for EmployerBiweeklyMaximum
            /// </summary>
            public const int EmployerBiweeklyMaximum = 109;

            /// <summary>
            /// Property Indexer for EmployerSemimonthlyMinimum
            /// </summary>
            public const int EmployerSemimonthlyMinimum = 110;

            /// <summary>
            /// Property Indexer for EmployerSemimonthlyMaximum
            /// </summary>
            public const int EmployerSemimonthlyMaximum = 111;

            /// <summary>
            /// Property Indexer for EmployerMonthlyMinimum
            /// </summary>
            public const int EmployerMonthlyMinimum = 112;

            /// <summary>
            /// Property Indexer for EmployerMonthlyMaximum
            /// </summary>
            public const int EmployerMonthlyMaximum = 113;

            /// <summary>
            /// Property Indexer for EmployerQuarterlyMinimum
            /// </summary>
            public const int EmployerQuarterlyMinimum = 114;

            /// <summary>
            /// Property Indexer for EmployerQuarterlyMaximum
            /// </summary>
            public const int EmployerQuarterlyMaximum = 115;

            /// <summary>
            /// Property Indexer for EmployerTenPerYearMinimum
            /// </summary>
            public const int Employer10PerYearMin = 116;

            /// <summary>
            /// Property Indexer for EmployerTenPerYearMaximum
            /// </summary>
            public const int Employer10PerYearMax = 117;

            /// <summary>
            /// Property Indexer for EmployerThirteenPerYearMinim
            /// </summary>
            public const int Employer13PerYearMin = 118;

            /// <summary>
            /// Property Indexer for EmployerThirteenPerYearMaxim
            /// </summary>
            public const int Employer13PerYearMax = 119;

            /// <summary>
            /// Property Indexer for EmployerTwentytwoPerYearMini
            /// </summary>
            public const int Employer22PerYearMin = 120;

            /// <summary>
            /// Property Indexer for EmployerTwentytwoPerYearMaxi
            /// </summary>
            public const int Employer22PerYearMax = 121;

            /// <summary>
            /// Property Indexer for EmployerBaseLimit
            /// </summary>
            public const int EmployerBaseLimit = 122;

            /// <summary>
            /// Property Indexer for SubjectToWorkersCompensation
            /// </summary>
            public const int SubjectToWorkersCompensation = 123;

            /// <summary>
            /// Property Indexer for CommissionAmount1
            /// </summary>
            public const int CommissionAmount1 = 124;

            /// <summary>
            /// Property Indexer for CommissionPct1
            /// </summary>
            public const int CommissionPct1 = 125;

            /// <summary>
            /// Property Indexer for CommissionAmount2
            /// </summary>
            public const int CommissionAmount2 = 126;

            /// <summary>
            /// Property Indexer for CommissionPct2
            /// </summary>
            public const int CommissionPct2 = 127;

            /// <summary>
            /// Property Indexer for CommissionAmount3
            /// </summary>
            public const int CommissionAmount3 = 128;

            /// <summary>
            /// Property Indexer for CommissionPct3
            /// </summary>
            public const int CommissionPct3 = 129;

            /// <summary>
            /// Property Indexer for CommissionAmount4
            /// </summary>
            public const int CommissionAmount4 = 130;

            /// <summary>
            /// Property Indexer for CommissionPct4
            /// </summary>
            public const int CommissionPct4 = 131;

            /// <summary>
            /// Property Indexer for CommissionAmount5
            /// </summary>
            public const int CommissionAmount5 = 132;

            /// <summary>
            /// Property Indexer for CommissionPct5
            /// </summary>
            public const int CommissionPct5 = 133;

            /// <summary>
            /// Property Indexer for CommissionAmountExcess
            /// </summary>
            public const int CommissionAmountExcess = 134;

            /// <summary>
            /// Property Indexer for PieceCount1
            /// </summary>
            public const int PieceCount1 = 135;

            /// <summary>
            /// Property Indexer for PieceAmount1
            /// </summary>
            public const int PieceAmount1 = 136;

            /// <summary>
            /// Property Indexer for PieceCount2
            /// </summary>
            public const int PieceCount2 = 137;

            /// <summary>
            /// Property Indexer for PieceAmount2
            /// </summary>
            public const int PieceAmount2 = 138;

            /// <summary>
            /// Property Indexer for PieceCount3
            /// </summary>
            public const int PieceCount3 = 139;

            /// <summary>
            /// Property Indexer for PieceAmount3
            /// </summary>
            public const int PieceAmount3 = 140;

            /// <summary>
            /// Property Indexer for PieceCount4
            /// </summary>
            public const int PieceCount4 = 141;

            /// <summary>
            /// Property Indexer for PieceAmount4
            /// </summary>
            public const int PieceAmount4 = 142;

            /// <summary>
            /// Property Indexer for PieceCount5
            /// </summary>
            public const int PieceCount5 = 143;

            /// <summary>
            /// Property Indexer for PieceAmount5
            /// </summary>
            public const int PieceAmount5 = 144;

            /// <summary>
            /// Property Indexer for MaxPieceRateAmount
            /// </summary>
            public const int MaxPieceRateAmount = 145;

            /// <summary>
            /// Property Indexer for TipDisbursement
            /// </summary>
            public const int TipDisbursement = 146;

            /// <summary>
            /// Property Indexer for RepaymentDeduction
            /// </summary>
            public const int RepaymentDeduction = 147;

            /// <summary>
            /// Property Indexer for AdvanceToBeRepaid
            /// </summary>
            public const int AdvanceToBeRepaid = 148;

            /// <summary>
            /// Property Indexer for Carryover
            /// </summary>
            public const int Carryover = 149;

            /// <summary>
            /// Property Indexer for CarryOverDay
            /// </summary>
            public const int CarryOverDay = 150;

            /// <summary>
            /// Property Indexer for CarryOverMonth
            /// </summary>
            public const int CarryOverMonth = 151;

            /// <summary>
            /// Property Indexer for PostLiab
            /// </summary>
            public const int PostLiab = 152;

            /// <summary>
            /// Property Indexer for ServiceYear1
            /// </summary>
            public const int ServiceYear1 = 153;

            /// <summary>
            /// Property Indexer for BeginningHours1
            /// </summary>
            public const int BeginningHours1 = 154;

            /// <summary>
            /// Property Indexer for IncrementHours1
            /// </summary>
            public const int IncrementHours1 = 155;

            /// <summary>
            /// Property Indexer for MaxAnnualAccrual1
            /// </summary>
            public const int MaxAnnualAccrual1 = 156;

            /// <summary>
            /// Property Indexer for MaxCarryOverHours1
            /// </summary>
            public const int MaxCarryOverHours1 = 157;

            /// <summary>
            /// Property Indexer for ServiceYear2
            /// </summary>
            public const int ServiceYear2 = 158;

            /// <summary>
            /// Property Indexer for BeginningHours2
            /// </summary>
            public const int BeginningHours2 = 159;

            /// <summary>
            /// Property Indexer for IncrementHours2
            /// </summary>
            public const int IncrementHours2 = 160;

            /// <summary>
            /// Property Indexer for MaxAnnualAccrual2
            /// </summary>
            public const int MaxAnnualAccrual2 = 161;

            /// <summary>
            /// Property Indexer for MaxCarryOverHours2
            /// </summary>
            public const int MaxCarryOverHours2 = 162;

            /// <summary>
            /// Property Indexer for ServiceYear3
            /// </summary>
            public const int ServiceYear3 = 163;

            /// <summary>
            /// Property Indexer for BeginningHours3
            /// </summary>
            public const int BeginningHours3 = 164;

            /// <summary>
            /// Property Indexer for IncrementHours3
            /// </summary>
            public const int IncrementHours3 = 165;

            /// <summary>
            /// Property Indexer for MaxAnnualAccrual3
            /// </summary>
            public const int MaxAnnualAccrual3 = 166;

            /// <summary>
            /// Property Indexer for MaxCarryOverHours3
            /// </summary>
            public const int MaxCarryOverHours3 = 167;

            /// <summary>
            /// Property Indexer for ServiceYear4
            /// </summary>
            public const int ServiceYear4 = 168;

            /// <summary>
            /// Property Indexer for BeginningHours4
            /// </summary>
            public const int BeginningHours4 = 169;

            /// <summary>
            /// Property Indexer for IncrementHours4
            /// </summary>
            public const int IncrementHours4 = 170;

            /// <summary>
            /// Property Indexer for MaxAnnualAccrual4
            /// </summary>
            public const int MaxAnnualAccrual4 = 171;

            /// <summary>
            /// Property Indexer for MaxCarryOverHours4
            /// </summary>
            public const int MaxCarryOverHours4 = 172;

            /// <summary>
            /// Property Indexer for Level
            /// </summary>
            public const int Level = 173;

            /// <summary>
            /// Property Indexer for BaseHoursListUse
            /// </summary>
            public const int BaseHoursListUse = 174;

            /// <summary>
            /// Property Indexer for BaseHoursRegular
            /// </summary>
            public const int BaseHoursRegular = 175;

            /// <summary>
            /// Property Indexer for BaseHoursOvertime
            /// </summary>
            public const int BaseHoursOvertime = 176;

            /// <summary>
            /// Property Indexer for BaseEarningsListUse
            /// </summary>
            public const int BaseEarningsListUse = 177;

            /// <summary>
            /// Property Indexer for BaseEarningsRegular
            /// </summary>
            public const int BaseEarningsRegular = 178;

            /// <summary>
            /// Property Indexer for BaseEarningsOvertime
            /// </summary>
            public const int BaseEarningsOvertime = 179;

            /// <summary>
            /// Property Indexer for BaseEarningsShift
            /// </summary>
            public const int BaseEarningsShift = 180;

            /// <summary>
            /// Property Indexer for BaseDeductionsListUse
            /// </summary>
            public const int BaseDeductionsListUse = 181;

            /// <summary>
            /// Property Indexer for BaseTaxListUse
            /// </summary>
            public const int BaseTaxListUse = 182;

            /// <summary>
            /// Property Indexer for ListUseOfTypeOfTaxableWage
            /// </summary>
            public const int ListUseOfTypeOfTaxableWage = 183;

            /// <summary>
            /// Property Indexer for WithholdingMethodForTaxableW
            /// </summary>
            public const int WithholdingMethodForTaxableW = 184;

            /// <summary>
            /// Property Indexer for TakeDeductionBeforeListUse
            /// </summary>
            public const int TakeDeductionBeforeListUse = 185;

            /// <summary>
            /// Property Indexer for ET4BOX
            /// </summary>
            public const int ET4BOX = 186;

            /// <summary>
            /// Property Indexer for RT4BOX
            /// </summary>
            public const int RT4BOX = 187;

            /// <summary>
            /// Property Indexer for ER1BOX
            /// </summary>
            public const int ER1BOX = 188;

            /// <summary>
            /// Property Indexer for RR1BOX
            /// </summary>
            public const int RR1BOX = 189;

            /// <summary>
            /// Property Indexer for EASSOCW2SW
            /// </summary>
            public const int EASSOCW2SW = 190;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EASSOCTAX
            /// </summary>
            public const int EASSOCTAX = 191;

            /// <summary>
            /// Property Indexer for RASSOCW2SW
            /// </summary>
            public const int RASSOCW2SW = 192;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RASSOCTAX
            /// </summary>
            public const int RASSOCTAX = 193;

            /// <summary>
            /// Property Indexer for PostBenefit
            /// </summary>
            public const int PostBenefit = 194;

            /// <summary>
            /// Property Indexer for PayAccrual
            /// </summary>
            public const int PayAccrual = 195;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for NONPERPYMT
            /// </summary>
            public const int NONPERPYMT = 196;

            /// <summary>
            /// Property Indexer for LinkedEarning
            /// </summary>
            public const int LinkedEarning = 197;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 198;

            /// <summary>
            /// Property Indexer for IncludeInFLSAOvertimeCalc
            /// </summary>
            public const int IncludeInFLSAOvertimeCalc = 199;

            /// <summary>
            /// Property Indexer for ProgressiveCalcCommissions
            /// </summary>
            public const int ProgressiveCalcCommissions = 200;

            /// <summary>
            /// Property Indexer for AnnualizedWageBrackets
            /// </summary>
            public const int AnnualizedWageBrackets = 201;

            /// <summary>
            /// Property Indexer for ProgressiveCalcWageBrackets
            /// </summary>
            public const int ProgressiveCalcWageBrackets = 202;

            /// <summary>
            /// Property Indexer for ProgressiveCalcPieceRate
            /// </summary>
            public const int ProgressiveCalcPieceRate = 203;

            /// <summary>
            /// Property Indexer for EmployeeLifetimeMaximum
            /// </summary>
            public const int EmployeeLifetimeMaximum = 204;

            /// <summary>
            /// Property Indexer for EmployerLifetimeMaximum
            /// </summary>
            public const int EmployerLifetimeMaximum = 205;

            /// <summary>
            /// Property Indexer for EmployeeSecRateEffective
            /// </summary>
            public const int EmployeeSecRateEffective = 206;

            /// <summary>
            /// Property Indexer for EmployerSecRateEffective
            /// </summary>
            public const int EmployerSecRateEffective = 207;

            /// <summary>
            /// Property Indexer for EmployeeSecondaryRate
            /// </summary>
            public const int EmployeeSecondaryRate = 208;

            /// <summary>
            /// Property Indexer for EmployerSecondaryRate
            /// </summary>
            public const int EmployerSecondaryRate = 209;

            /// <summary>
            /// Property Indexer for ServiceYear5
            /// </summary>
            public const int ServiceYear5 = 230;

            /// <summary>
            /// Property Indexer for BeginningHours5
            /// </summary>
            public const int BeginningHours5 = 231;

            /// <summary>
            /// Property Indexer for IncrementHours5
            /// </summary>
            public const int IncrementHours5 = 232;

            /// <summary>
            /// Property Indexer for MaxAnnualAccrual5
            /// </summary>
            public const int MaxAnnualAccrual5 = 233;

            /// <summary>
            /// Property Indexer for MaxCarryOverHours5
            /// </summary>
            public const int MaxCarryOverHours5 = 234;

            /// <summary>
            /// Property Indexer for ServiceYear6
            /// </summary>
            public const int ServiceYear6 = 235;

            /// <summary>
            /// Property Indexer for BeginningHours6
            /// </summary>
            public const int BeginningHours6 = 236;

            /// <summary>
            /// Property Indexer for IncrementHours6
            /// </summary>
            public const int IncrementHours6 = 237;

            /// <summary>
            /// Property Indexer for MaxAnnualAccrual6
            /// </summary>
            public const int MaxAnnualAccrual6 = 238;

            /// <summary>
            /// Property Indexer for MaxCarryOverHours6
            /// </summary>
            public const int MaxCarryOverHours6 = 239;

            /// <summary>
            /// Property Indexer for ServiceYear7
            /// </summary>
            public const int ServiceYear7 = 240;

            /// <summary>
            /// Property Indexer for BeginningHours7
            /// </summary>
            public const int BeginningHours7 = 241;

            /// <summary>
            /// Property Indexer for IncrementHours7
            /// </summary>
            public const int IncrementHours7 = 242;

            /// <summary>
            /// Property Indexer for MaxAnnualAccrual7
            /// </summary>
            public const int MaxAnnualAccrual7 = 243;

            /// <summary>
            /// Property Indexer for MaxCarryOverHours7
            /// </summary>
            public const int MaxCarryOverHours7 = 244;

            /// <summary>
            /// Property Indexer for ServiceYear8
            /// </summary>
            public const int ServiceYear8 = 245;

            /// <summary>
            /// Property Indexer for BeginningHours8
            /// </summary>
            public const int BeginningHours8 = 246;

            /// <summary>
            /// Property Indexer for IncrementHours8
            /// </summary>
            public const int IncrementHours8 = 247;

            /// <summary>
            /// Property Indexer for MaxAnnualAccrual8
            /// </summary>
            public const int MaxAnnualAccrual8 = 248;

            /// <summary>
            /// Property Indexer for MaxCarryOverHours8
            /// </summary>
            public const int MaxCarryOverHours8 = 249;

            /// <summary>
            /// Property Indexer for ServiceYear9
            /// </summary>
            public const int ServiceYear9 = 250;

            /// <summary>
            /// Property Indexer for BeginningHours9
            /// </summary>
            public const int BeginningHours9 = 251;

            /// <summary>
            /// Property Indexer for IncrementHours9
            /// </summary>
            public const int IncrementHours9 = 252;

            /// <summary>
            /// Property Indexer for MaxAnnualAccrual9
            /// </summary>
            public const int MaxAnnualAccrual9 = 253;

            /// <summary>
            /// Property Indexer for MaxCarryOverHours9
            /// </summary>
            public const int MaxCarryOverHours9 = 254;

            /// <summary>
            /// Property Indexer for ServiceYear10
            /// </summary>
            public const int ServiceYear10 = 255;

            /// <summary>
            /// Property Indexer for BeginningHours10
            /// </summary>
            public const int BeginningHours10 = 256;

            /// <summary>
            /// Property Indexer for IncrementHours10
            /// </summary>
            public const int IncrementHours10 = 257;

            /// <summary>
            /// Property Indexer for MaxAnnualAccrual10
            /// </summary>
            public const int MaxAnnualAccrual10 = 258;

            /// <summary>
            /// Property Indexer for MaxCarryOverHours10
            /// </summary>
            public const int MaxCarryOverHours10 = 259;

            /// <summary>
            /// Property Indexer for CostCenterOverrideBasedOnCa
            /// </summary>
            public const int CostCenterOverrideBasedOnCa = 260;

            /// <summary>
            /// Property Indexer for BillingRates
            /// </summary>
            public const int BillingRates = 261;

            /// <summary>
            /// Property Indexer for BillingPercentage1
            /// </summary>
            public const int BillingPercentage1 = 262;

            /// <summary>
            /// Property Indexer for BillingPercentage2
            /// </summary>
            public const int BillingPercentage2 = 263;

            /// <summary>
            /// Property Indexer for BillingPercentage3
            /// </summary>
            public const int BillingPercentage3 = 264;

            /// <summary>
            /// Property Indexer for BillingPercentage4
            /// </summary>
            public const int BillingPercentage4 = 265;

            /// <summary>
            /// Property Indexer for BillingPercentage5
            /// </summary>
            public const int BillingPercentage5 = 266;

            /// <summary>
            /// Property Indexer for BillingPercentage6
            /// </summary>
            public const int BillingPercentage6 = 267;

            /// <summary>
            /// Property Indexer for CalculationMaxCarryOverBasedOnR
            /// </summary>
            public const int CalculationMaxCarryOverBasedOnR = 268;

            /// <summary>
            /// Property Indexer for CapAccrualAtMaxAccrual
            /// </summary>
            public const int CapAccrualAtMaxAccrual = 269;

            /// <summary>
            /// Property Indexer for ReportAs
            /// </summary>
            public const int ReportAs = 270;

            /// <summary>
            /// Property Indexer for RESERVEDCDNOnly
            /// </summary>
            public const int RESERVEDCDNOnly = 271;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 210;


        }

        #endregion

    }
}
