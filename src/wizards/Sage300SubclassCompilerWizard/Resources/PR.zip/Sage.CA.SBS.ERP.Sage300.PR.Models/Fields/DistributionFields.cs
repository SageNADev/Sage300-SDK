// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of Distribution Constants
    /// </summary>
    public partial class Distribution
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0009";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"EXPACCT", "RegularExpenseGLAccount"},
                    {"OTACCT", "OvertimeExpenseGLAccount"},
                    {"SHIFTACCT", "ShiftDifferentialExpGLAcct"},
                    {"ELIABACCT", "EmployeeLiabilityGLAccount"},
                    {"RLIABACCT", "EmployerLiabilityGLAccount"},
                    {"ASSETACCT", "AdvancesReceivableGLAccount"},
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of Distribution Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for EarningDeduction
            /// </summary>
            public const string EarningDeduction = "EARNDED";

            /// <summary>
            /// Property for DistributionCode
            /// </summary>
            public const string DistributionCode = "DISTCODE";

            /// <summary>
            /// Property for DistributionDescription
            /// </summary>
            public const string DistributionDescription = "DISTRNAME";

            /// <summary>
            /// Property for RegularExpenseGLAccount
            /// </summary>
            public const string RegularExpenseGLAccount = "EXPACCT";

            /// <summary>
            /// Property for OvertimeExpenseGLAccount
            /// </summary>
            public const string OvertimeExpenseGLAccount = "OTACCT";

            /// <summary>
            /// Property for ShiftDifferentialExpGLAcct
            /// </summary>
            public const string ShiftDifferentialExpGLAcct = "SHIFTACCT";

            /// <summary>
            /// Property for EmployeeLiabilityGLAccount
            /// </summary>
            public const string EmployeeLiabilityGLAccount = "ELIABACCT";

            /// <summary>
            /// Property for EmployerLiabilityGLAccount
            /// </summary>
            public const string EmployerLiabilityGLAccount = "RLIABACCT";

            /// <summary>
            /// Property for AdvancesReceivableGLAccount
            /// </summary>
            public const string AdvancesReceivableGLAccount = "ASSETACCT";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of Distribution Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for EarningDeduction
            /// </summary>
            public const int EarningDeduction = 1;

            /// <summary>
            /// Property Indexer for DistributionCode
            /// </summary>
            public const int DistributionCode = 2;

            /// <summary>
            /// Property Indexer for DistributionDescription
            /// </summary>
            public const int DistributionDescription = 3;

            /// <summary>
            /// Property Indexer for RegularExpenseGLAccount
            /// </summary>
            public const int RegularExpenseGLAccount = 4;

            /// <summary>
            /// Property Indexer for OvertimeExpenseGLAccount
            /// </summary>
            public const int OvertimeExpenseGLAccount = 5;

            /// <summary>
            /// Property Indexer for ShiftDifferentialExpGLAcct
            /// </summary>
            public const int ShiftDifferentialExpGLAcct = 6;

            /// <summary>
            /// Property Indexer for EmployeeLiabilityGLAccount
            /// </summary>
            public const int EmployeeLiabilityGLAccount = 7;

            /// <summary>
            /// Property Indexer for EmployerLiabilityGLAccount
            /// </summary>
            public const int EmployerLiabilityGLAccount = 8;

            /// <summary>
            /// Property Indexer for AdvancesReceivableGLAccount
            /// </summary>
            public const int AdvancesReceivableGLAccount = 9;


        }

        #endregion

    }
}
