// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of EmployeeTimecardJobDetail Constants
    /// </summary>
    public partial class EmployeeTimecardJobDetail
    {
        /// <summary>
        /// Entity Name with prefix added later
        /// </summary>
        public const string EntityName = "~~0044";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"CONTRACT", "CONTRACT"},
                    {"PROJECT", "PROJECT"},
                    {"CCATEGORY", "CCATEGORY"},
                    {"IDCUST", "IDCUST" },
                    {"STARTTIME", "STARTTIME"},
                    {"STOPTIME", "STOPTIME"},
                    {"HOURS", "HOURS"},
                    {"STWIPACCT", "STWIPACCT" },
                    {"OTWIPACCT", "OTWIPACCT" },
                    {"WIPACCT", "WIPACCT" },
                    {"ARUNIT", "ARUNIT"},
                    {"ARITEMNO", "ARITEMNO"},
                    {"BILLRATE", "BILLRATE" },
                    {"BILLTYPE", "BILLTYPE" },
                    {"CNTBASE", "CNTBASE" },
                    {"RESOURCE", "RESOURCE" }
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of EmployeeTimecardJobDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for EndDate
            /// </summary>
            public const string EndDate = "ENDDATE";

            /// <summary>
            /// Property for PayDate
            /// </summary>
            public const string PayDate = "PAYDATE";

            /// <summary>
            /// Property for EarningExpenseTipCode
            /// </summary>
            public const string EarningExpenseTipCode = "EARNDED";

            /// <summary>
            /// Property for UniqueKeyField
            /// </summary>
            public const string UniqueKeyField = "UNIQUE";

            /// <summary>
            /// Property for JobLineNumber
            /// </summary>
            public const string JobLineNumber = "JOBLINE";

            /// <summary>
            /// Property for ContractCode
            /// </summary>
            public const string ContractCode = "CONTRACT";

            /// <summary>
            /// Property for ProjectCode
            /// </summary>
            public const string ProjectCode = "PROJECT";

            /// <summary>
            /// Property for CategoryCode
            /// </summary>
            public const string CategoryCode = "CCATEGORY";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "IDCUST";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "CURRCODE";

            /// <summary>
            /// Property for StartTime
            /// </summary>
            public const string StartTime = "STARTTIME";

            /// <summary>
            /// Property for StopTime
            /// </summary>
            public const string StopTime = "STOPTIME";

            /// <summary>
            /// Property for Hours
            /// </summary>
            public const string Hours = "HOURS";

            /// <summary>
            /// Property for PiecesSalesAmt
            /// </summary>
            public const string PiecesSalesAmt = "CNTBASE";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEMNO";

            /// <summary>
            /// Property for ARItemUOM
            /// </summary>
            public const string ARItemUOM = "ARUNIT";

            /// <summary>
            /// Property for RegularWIPCOSAcct
            /// </summary>
            public const string RegularWIPCOSAcct = "WIPACCT";

            /// <summary>
            /// Property for OvertimeWIPCOSAcct
            /// </summary>
            public const string OvertimeWIPCOSAcct = "OTWIPACCT";

            /// <summary>
            /// Property for ShiftWIPCOSAcct
            /// </summary>
            public const string ShiftWIPCOSAcct = "STWIPACCT";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "PROJSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for UnformattedContractCode
            /// </summary>
            public const string UnformattedContractCode = "UFMTCONTNO";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "COSTCLASS";

            /// <summary>
            /// Property for CurrencyDescription
            /// </summary>
            public const string CurrencyDescription = "CURRDESC";

            /// <summary>
            /// Property for AllowCostCenterOverrides
            /// </summary>
            public const string AllowCostCenterOverrides = "ALLOWGLOVR";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for ResourceDescription
            /// </summary>
            public const string ResourceDescription = "RESDESC";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of EmployeeTimecardJobDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for EndDate
            /// </summary>
            public const int EndDate = 2;

            /// <summary>
            /// Property Indexer for PayDate
            /// </summary>
            public const int PayDate = 3;

            /// <summary>
            /// Property Indexer for EarningExpenseTipCode
            /// </summary>
            public const int EarningExpenseTipCode = 4;

            /// <summary>
            /// Property Indexer for UniqueKeyField
            /// </summary>
            public const int UniqueKeyField = 5;

            /// <summary>
            /// Property Indexer for JobLineNumber
            /// </summary>
            public const int JobLineNumber = 6;

            /// <summary>
            /// Property Indexer for ContractCode
            /// </summary>
            public const int ContractCode = 7;

            /// <summary>
            /// Property Indexer for ProjectCode
            /// </summary>
            public const int ProjectCode = 8;

            /// <summary>
            /// Property Indexer for CategoryCode
            /// </summary>
            public const int CategoryCode = 9;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 10;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 11;

            /// <summary>
            /// Property Indexer for StartTime
            /// </summary>
            public const int StartTime = 12;

            /// <summary>
            /// Property Indexer for StopTime
            /// </summary>
            public const int StopTime = 13;

            /// <summary>
            /// Property Indexer for Hours
            /// </summary>
            public const int Hours = 14;

            /// <summary>
            /// Property Indexer for PiecesSalesAmt
            /// </summary>
            public const int PiecesSalesAmt = 15;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 16;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 17;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 18;

            /// <summary>
            /// Property Indexer for ARItemUOM
            /// </summary>
            public const int ARItemUOM = 19;

            /// <summary>
            /// Property Indexer for RegularWIPCOSAcct
            /// </summary>
            public const int RegularWIPCOSAcct = 20;

            /// <summary>
            /// Property Indexer for OvertimeWIPCOSAcct
            /// </summary>
            public const int OvertimeWIPCOSAcct = 21;

            /// <summary>
            /// Property Indexer for ShiftWIPCOSAcct
            /// </summary>
            public const int ShiftWIPCOSAcct = 22;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 23;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 24;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 25;

            /// <summary>
            /// Property Indexer for UnformattedContractCode
            /// </summary>
            public const int UnformattedContractCode = 26;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 27;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 28;

            /// <summary>
            /// Property Indexer for CurrencyDescription
            /// </summary>
            public const int CurrencyDescription = 30;

            /// <summary>
            /// Property Indexer for AllowCostCenterOverrides
            /// </summary>
            public const int AllowCostCenterOverrides = 31;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 32;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 50;

            /// <summary>
            /// Property Indexer for ResourceDescription
            /// </summary>
            public const int ResourceDescription = 51;


        }

        #endregion

    }
}