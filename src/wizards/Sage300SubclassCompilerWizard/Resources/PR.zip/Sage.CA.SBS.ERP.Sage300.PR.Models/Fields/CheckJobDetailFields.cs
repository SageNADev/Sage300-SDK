// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of CheckJobDetail Constants
    /// </summary>
    public partial class CheckJobDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0056";

        #region Fields Properties

        /// <summary>
        /// Contains list of CheckJobDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "PEREND";

            /// <summary>
            /// Property for EntrySequence
            /// </summary>
            public const string EntrySequence = "ENTRYSEQ";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for EarningDeduction
            /// </summary>
            public const string EarningDeduction = "EARNDED";

            /// <summary>
            /// Property for LineType
            /// </summary>
            public const string LineType = "LINETYPE";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for JobLineNumber
            /// </summary>
            public const string JobLineNumber = "JOBLINE";

            /// <summary>
            /// Property for ContractCode
            /// </summary>
            public const string ContractCode = "CONTRACT";

            /// <summary>
            /// Property for ProjectCode
            /// </summary>
            public const string ProjectCode = "PROJECT";

            /// <summary>
            /// Property for CategoryCode
            /// </summary>
            public const string CategoryCode = "CCATEGORY";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "IDCUST";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "CURRCODE";

            /// <summary>
            /// Property for StartTime
            /// </summary>
            public const string StartTime = "STARTTIME";

            /// <summary>
            /// Property for StopTime
            /// </summary>
            public const string StopTime = "STOPTIME";

            /// <summary>
            /// Property for Hours
            /// </summary>
            public const string Hours = "HOURS";

            /// <summary>
            /// Property for PiecesSalesAmt
            /// </summary>
            public const string PiecesSalesAmt = "CNTBASE";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEMNO";

            /// <summary>
            /// Property for ARItemUOM
            /// </summary>
            public const string ARItemUOM = "ARUNIT";

            /// <summary>
            /// Property for WIPCOSAcct
            /// </summary>
            public const string WIPCOSAcct = "WIPACCT";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for CurrencyDescription
            /// </summary>
            public const string CurrencyDescription = "CURRDESC";

            /// <summary>
            /// Property for UnformattedContractCode
            /// </summary>
            public const string UnformattedContractCode = "UFMTCONTNO";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "PROJSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for ExtendedBillingAmount
            /// </summary>
            public const string ExtendedBillingAmount = "BEXTEND";

            /// <summary>
            /// Property for EmployeeExtendedAmount
            /// </summary>
            public const string EmployeeExtendedAmount = "EEXTEND";

            /// <summary>
            /// Property for OverheadAccount
            /// </summary>
            public const string OverheadAccount = "GLOVERHEAD";

            /// <summary>
            /// Property for LaborBurdenAccount
            /// </summary>
            public const string LaborBurdenAccount = "GLLABOR";

            /// <summary>
            /// Property for FCOverheadAmount
            /// </summary>
            public const string FCOverheadAmount = "FCOVRHDAMT";

            /// <summary>
            /// Property for OverheadAmount
            /// </summary>
            public const string OverheadAmount = "SCOVRHDAMT";

            /// <summary>
            /// Property for FCLaborBurdenAmount
            /// </summary>
            public const string FCLaborBurdenAmount = "FCLABORAMT";

            /// <summary>
            /// Property for LaborBurdenAmount
            /// </summary>
            public const string LaborBurdenAmount = "SCLABORAMT";

            /// <summary>
            /// Property for PJCTransactionNumber
            /// </summary>
            public const string PJCTransactionNumber = "PMTRANSNUM";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "COSTCLASS";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for ResourceDescription
            /// </summary>
            public const string ResourceDescription = "RESDESC";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of CheckJobDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 2;

            /// <summary>
            /// Property Indexer for EntrySequence
            /// </summary>
            public const int EntrySequence = 3;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 4;

            /// <summary>
            /// Property Indexer for EarningDeduction
            /// </summary>
            public const int EarningDeduction = 5;

            /// <summary>
            /// Property Indexer for LineType
            /// </summary>
            public const int LineType = 6;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 7;

            /// <summary>
            /// Property Indexer for JobLineNumber
            /// </summary>
            public const int JobLineNumber = 8;

            /// <summary>
            /// Property Indexer for ContractCode
            /// </summary>
            public const int ContractCode = 9;

            /// <summary>
            /// Property Indexer for ProjectCode
            /// </summary>
            public const int ProjectCode = 10;

            /// <summary>
            /// Property Indexer for CategoryCode
            /// </summary>
            public const int CategoryCode = 11;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 12;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 13;

            /// <summary>
            /// Property Indexer for StartTime
            /// </summary>
            public const int StartTime = 14;

            /// <summary>
            /// Property Indexer for StopTime
            /// </summary>
            public const int StopTime = 15;

            /// <summary>
            /// Property Indexer for Hours
            /// </summary>
            public const int Hours = 16;

            /// <summary>
            /// Property Indexer for PiecesSalesAmt
            /// </summary>
            public const int PiecesSalesAmt = 17;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 18;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 19;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 20;

            /// <summary>
            /// Property Indexer for ARItemUOM
            /// </summary>
            public const int ARItemUOM = 21;

            /// <summary>
            /// Property Indexer for WIPCOSAcct
            /// </summary>
            public const int WIPCOSAcct = 22;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 23;

            /// <summary>
            /// Property Indexer for CurrencyDescription
            /// </summary>
            public const int CurrencyDescription = 24;

            /// <summary>
            /// Property Indexer for UnformattedContractCode
            /// </summary>
            public const int UnformattedContractCode = 25;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 26;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 27;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 28;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmount
            /// </summary>
            public const int ExtendedBillingAmount = 29;

            /// <summary>
            /// Property Indexer for EmployeeExtendedAmount
            /// </summary>
            public const int EmployeeExtendedAmount = 30;

            /// <summary>
            /// Property Indexer for OverheadAccount
            /// </summary>
            public const int OverheadAccount = 31;

            /// <summary>
            /// Property Indexer for LaborBurdenAccount
            /// </summary>
            public const int LaborBurdenAccount = 32;

            /// <summary>
            /// Property Indexer for FCOverheadAmount
            /// </summary>
            public const int FCOverheadAmount = 33;

            /// <summary>
            /// Property Indexer for OverheadAmount
            /// </summary>
            public const int OverheadAmount = 34;

            /// <summary>
            /// Property Indexer for FCLaborBurdenAmount
            /// </summary>
            public const int FCLaborBurdenAmount = 35;

            /// <summary>
            /// Property Indexer for LaborBurdenAmount
            /// </summary>
            public const int LaborBurdenAmount = 36;

            /// <summary>
            /// Property Indexer for PJCTransactionNumber
            /// </summary>
            public const int PJCTransactionNumber = 37;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 38;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 39;

            /// <summary>
            /// Property Indexer for ResourceDescription
            /// </summary>
            public const int ResourceDescription = 40;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 100;


        }

        #endregion

    }
}