// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of CheckHeader Constants
    /// </summary>
    public partial class CheckHeader
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0048";


        #region Fields Properties

        /// <summary>
        /// Contains list of CheckHeader Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "PEREND";

            /// <summary>
            /// Property for EntrySequence
            /// </summary>
            public const string EntrySequence = "ENTRYSEQ";

            /// <summary>
            /// Property for TypeOfCheck
            /// </summary>
            public const string TypeOfCheck = "ENTRYTYPE";

            /// <summary>
            /// Property for BankID
            /// </summary>
            public const string BankID = "BANK";

            /// <summary>
            /// Property for TransactionNumber
            /// </summary>
            public const string TransactionNumber = "TRANSNUM";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for PeriodStartDate
            /// </summary>
            public const string PeriodStartDate = "PERSTART";

            /// <summary>
            /// Property for TimesLateThisPeriodTimecard
            /// </summary>
            public const string TimesLateThisPeriodTimecard = "TIMESLATE";

            /// <summary>
            /// Property for CheckStatus
            /// </summary>
            public const string CheckStatus = "CHECKSTAT";

            /// <summary>
            /// Property for PRPostStatus
            /// </summary>
            public const string PRPostStatus = "PRPOSTSTAT";

            /// <summary>
            /// Property for SentToGL
            /// </summary>
            public const string SentToGL = "GLPOSTSTAT";

            /// <summary>
            /// Property for PayFrequency
            /// </summary>
            public const string PayFrequency = "PAYFREQ";

            /// <summary>
            /// Property for Class1
            /// </summary>
            public const string Class1 = "CLASS1";

            /// <summary>
            /// Property for Class2
            /// </summary>
            public const string Class2 = "CLASS2";

            /// <summary>
            /// Property for Class3
            /// </summary>
            public const string Class3 = "CLASS3";

            /// <summary>
            /// Property for Class4
            /// </summary>
            public const string Class4 = "CLASS4";

            /// <summary>
            /// Property for BankSerialNumber
            /// </summary>
            public const string BankSerialNumber = "SERIAL";

            /// <summary>
            /// Property for CalculationSequence
            /// </summary>
            public const string CalculationSequence = "CALCSEQ";

            /// <summary>
            /// Property for PostingSequence
            /// </summary>
            public const string PostingSequence = "POSTSEQ";

            /// <summary>
            /// Property for PayrollPeriod
            /// </summary>
            public const string PayrollPeriod = "PRPERIOD";

            /// <summary>
            /// Property for TransactionAmt
            /// </summary>
            public const string TransactionAmt = "TRANSAMT";

            /// <summary>
            /// Property for GLSegmentOne
            /// </summary>
            public const string GLSegmentOne = "GLSEG1";

            /// <summary>
            /// Property for GLSegmentTwo
            /// </summary>
            public const string GLSegmentTwo = "GLSEG2";

            /// <summary>
            /// Property for GLSegmentThree
            /// </summary>
            public const string GLSegmentThree = "GLSEG3";

            /// <summary>
            /// Property for BankGeneralLedgerAccount
            /// </summary>
            public const string BankGeneralLedgerAccount = "BANKACCT";

            /// <summary>
            /// Property for RESERVEDCdnOnly
            /// </summary>
            public const string RESERVEDCdnOnly = "WORKPROV";

            /// <summary>
            /// Property for EmployeeEIID
            /// </summary>
            public const string EmployeeEIID = "TAXPLAN";

            /// <summary>
            /// Property for ExchangeRate
            /// </summary>
            public const string ExchangeRate = "EXRATE";

            /// <summary>
            /// Property for RateOperator
            /// </summary>
            public const string RateOperator = "RATEOP";

            /// <summary>
            /// Property for EFTStatus
            /// </summary>
            public const string EFTStatus = "EFTSTAT";

            /// <summary>
            /// Property for EFTRunSequence
            /// </summary>
            public const string EFTRunSequence = "EFTRUNSEQ";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for GLDrilldownLink
            /// </summary>
            public const string GLDrilldownLink = "GLDRDWNLNK";

            /// <summary>
            /// Property for OvertimeOverride
            /// </summary>
            public const string OvertimeOverride = "OTOVERRIDE";

            /// <summary>
            /// Property for OvertimeCalculation
            /// </summary>
            public const string OvertimeCalculation = "OTCALCTYPE";

            /// <summary>
            /// Property for BasedOnExternalTimecards
            /// </summary>
            public const string BasedOnExternalTimecards = "SWEXTERNTC";

            /// <summary>
            /// Property for JobRelated
            /// </summary>
            public const string JobRelated = "SWJOB";

            /// <summary>
            /// Property for ExchangeRateDate
            /// </summary>
            public const string ExchangeRateDate = "EXRATEDATE";

            /// <summary>
            /// Property for OriginalType
            /// </summary>
            public const string OriginalType = "ORGTYPE";

            /// <summary>
            /// Property for ChildSupportEFTStatus
            /// </summary>
            public const string ChildSupportEFTStatus = "CSEFTSTAT";

            /// <summary>
            /// Property for GLSegmentFour
            /// </summary>
            public const string GLSegmentFour = "GLSEG4";

            /// <summary>
            /// Property for GLSegmentFive
            /// </summary>
            public const string GLSegmentFive = "GLSEG5";

            /// <summary>
            /// Property for GLSegmentSix
            /// </summary>
            public const string GLSegmentSix = "GLSEG6";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for NextLineNumber
            /// </summary>
            public const string NextLineNumber = "LINENO";

            /// <summary>
            /// Property for SecurityFlag
            /// </summary>
            public const string SecurityFlag = "USERSEC";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of CheckHeader Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 2;

            /// <summary>
            /// Property Indexer for EntrySequence
            /// </summary>
            public const int EntrySequence = 3;

            /// <summary>
            /// Property Indexer for TypeOfCheck
            /// </summary>
            public const int TypeOfCheck = 4;
    
            /// <summary>
            /// Property Indexer for BankID
            /// </summary>
            public const int BankID = 5;

            /// <summary>
            /// Property Indexer for TransactionNumber
            /// </summary>
            public const int TransactionNumber = 6;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 7;

            /// <summary>
            /// Property Indexer for PeriodStartDate
            /// </summary>
            public const int PeriodStartDate = 8;

            /// <summary>
            /// Property Indexer for TimesLateThisPeriodTimecard
            /// </summary>
            public const int TimesLateThisPeriodTimecard = 9;

            /// <summary>
            /// Property Indexer for CheckStatus
            /// </summary>
            public const int CheckStatus = 10;

            /// <summary>
            /// Property Indexer for PRPostStatus
            /// </summary>
            public const int PRPostStatus = 11;

            /// <summary>
            /// Property Indexer for SentToGL
            /// </summary>
            public const int SentToGL = 12;

            /// <summary>
            /// Property Indexer for PayFrequency
            /// </summary>
            public const int PayFrequency = 13;

            /// <summary>
            /// Property Indexer for Class1
            /// </summary>
            public const int Class1 = 14;

            /// <summary>
            /// Property Indexer for Class2
            /// </summary>
            public const int Class2 = 15;

            /// <summary>
            /// Property Indexer for Class3
            /// </summary>
            public const int Class3 = 16;

            /// <summary>
            /// Property Indexer for Class4
            /// </summary>
            public const int Class4 = 17;

            /// <summary>
            /// Property Indexer for BankSerialNumber
            /// </summary>
            public const int BankSerialNumber = 18;

            /// <summary>
            /// Property Indexer for CalculationSequence
            /// </summary>
            public const int CalculationSequence = 19;

            /// <summary>
            /// Property Indexer for PostingSequence
            /// </summary>
            public const int PostingSequence = 20;

            /// <summary>
            /// Property Indexer for PayrollPeriod
            /// </summary>
            public const int PayrollPeriod = 21;

            /// <summary>
            /// Property Indexer for TransactionAmt
            /// </summary>
            public const int TransactionAmt = 22;

            /// <summary>
            /// Property Indexer for GLSegmentOne
            /// </summary>
            public const int GLSegmentOne = 23;

            /// <summary>
            /// Property Indexer for GLSegmentTwo
            /// </summary>
            public const int GLSegmentTwo = 24;

            /// <summary>
            /// Property Indexer for GLSegmentThree
            /// </summary>
            public const int GLSegmentThree = 25;

            /// <summary>
            /// Property Indexer for BankGeneralLedgerAccount
            /// </summary>
            public const int BankGeneralLedgerAccount = 26;

            /// <summary>
            /// Property Indexer for RESERVEDCdnOnly
            /// </summary>
            public const int RESERVEDCdnOnly = 27;

            /// <summary>
            /// Property Indexer for EmployeeEIID
            /// </summary>
            public const int EmployeeEIID = 28;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 29;

            /// <summary>
            /// Property Indexer for RateOperator
            /// </summary>
            public const int RateOperator = 30;

            /// <summary>
            /// Property Indexer for EFTStatus
            /// </summary>
            public const int EFTStatus = 31;

            /// <summary>
            /// Property Indexer for EFTRunSequence
            /// </summary>
            public const int EFTRunSequence = 32;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 33;

            /// <summary>
            /// Property Indexer for GLDrilldownLink
            /// </summary>
            public const int GLDrilldownLink = 34;

            /// <summary>
            /// Property Indexer for OvertimeOverride
            /// </summary>
            public const int OvertimeOverride = 35;

            /// <summary>
            /// Property Indexer for OvertimeCalculation
            /// </summary>
            public const int OvertimeCalculation = 36;

            /// <summary>
            /// Property Indexer for BasedOnExternalTimecards
            /// </summary>
            public const int BasedOnExternalTimecards = 37;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 38;

            /// <summary>
            /// Property Indexer for ExchangeRateDate
            /// </summary>
            public const int ExchangeRateDate = 39;

            /// <summary>
            /// Property Indexer for OriginalType
            /// </summary>
            public const int OriginalType = 40;

            /// <summary>
            /// Property Indexer for ChildSupportEFTStatus
            /// </summary>
            public const int ChildSupportEFTStatus = 41;

            /// <summary>
            /// Property Indexer for GLSegmentFour
            /// </summary>
            public const int GLSegmentFour = 42;

            /// <summary>
            /// Property Indexer for GLSegmentFive
            /// </summary>
            public const int GLSegmentFive = 43;

            /// <summary>
            /// Property Indexer for GLSegmentSix
            /// </summary>
            public const int GLSegmentSix = 44;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 100;

            /// <summary>
            /// Property Indexer for NextLineNumber
            /// </summary>
            public const int NextLineNumber = 101;

            /// <summary>
            /// Property Indexer for SecurityFlag
            /// </summary>
            public const int SecurityFlag = 102;


        }

        #endregion

    }
}