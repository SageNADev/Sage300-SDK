// Copyright (c) 2025 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of GloballyModifyList Constants
    /// </summary>
    public partial class GloballyModifyList

    {
        /// <summary>
        /// Entity Name 
        /// </summary>
        public const string EntityName = "~~0051";

        #region Fields Properties

        /// <summary>
        /// Contains list of GloballyModifyList Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for FieldIndex
            /// </summary>
            public const string FieldIndex = "FIELDIDX";

            /// <summary>
            /// Property for FieldType
            /// </summary>
            public const string FieldType = "FIELDTYPE";

            /// <summary>
            /// Property for Operation
            /// </summary>
            public const string Operation = "OPERATION";

            /// <summary>
            /// Property for TestOldValue
            /// </summary>
            public const string TestOldValue = "TESTOLD";

            /// <summary>
            /// Property for OldStringValue
            /// </summary>
            public const string OldStringValue = "OLDSTRING";

            /// <summary>
            /// Property for NewStringValue
            /// </summary>
            public const string NewStringValue = "NEWSTRING";


            /// <summary>
            /// Property for OldDateValue
            /// </summary>
            public const string OldDateValue = "OLDDATE";

            /// <summary>
            /// Property for NewDateValue
            /// </summary>
            public const string NewDateValue = "NEWDATE";

            /// <summary>
            /// Property for OldIntegerValue
            /// </summary>
            public const string OldIntegerValue = "OLDINT";

            /// <summary>
            /// Property for NewIntegerValue
            /// </summary>
            public const string NewIntegerValue = "NEWINT";

            /// <summary>
            /// Property for OldAmountPercent
            /// </summary>
            public const string OldAmountPercent = "OLDAMTPCT";

            /// <summary>
            /// Property for AmountPercentChange
            /// </summary>
            public const string AmountPercentChange = "AMTPCTCHG";

            /// <summary>
            /// Property for IDToChange
            /// </summary>
            public const string IDToChange = "ID2CHANGE";

            /// <summary>
            /// Property for OldWCCGroup
            /// </summary>
            public const string OldWCCGroup = "OLDWCCGRUP";

            /// <summary>
            /// Property for NewWCCGroup
            /// </summary>
            public const string NewWCCGroup = "NEWWCCGRUP";

            /// <summary>
            /// Property for OldBillingRate
            /// </summary>
            public const string OldBillingRate = "OLDBILLRAT";

            /// <summary>
            /// Property for NewBillingRate
            /// </summary>
            public const string NewBillingRate = "NEWBILLRAT";

            /// <summary>
            /// Property for BCDType
            /// </summary>
            public const string BCDType = "BCDTYPE";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of GloballyModifyList Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for FieldIndex
            /// </summary>
            public const int FieldIndex = 1;

            /// <summary>
            /// Property Indexer for FieldType
            /// </summary>
            public const int FieldType = 3;

            /// <summary>
            /// Property Indexer for BCDType
            /// </summary>
            public const int BCDType = 7;

            /// <summary>
            /// Property Indexer for Operation
            /// </summary>
            public const int Operation = 8;

            /// <summary>
            /// Property Indexer for TestOldValue
            /// </summary>
            public const int TestOldValue = 9;

            /// <summary>
            /// Property Indexer for OldStringValue
            /// </summary>
            public const int OldStringValue = 10;

            /// <summary>
            /// Property Indexer for NewStringValue
            /// </summary>
            public const int NewStringValue = 11;

            /// <summary>
            /// Property Indexer for OldDateValue
            /// </summary>
            public const int OldDateValue = 12;

            /// <summary>
            /// Property Indexer for NewDateValue
            /// </summary>
            public const int NewDateValue = 13;

            /// <summary>
            /// Property Indexer for OldIntegerValue
            /// </summary>
            public const int OldIntegerValue = 14;

            /// <summary>
            /// Property Indexer for NewIntegerValue
            /// </summary>
            public const int NewIntegerValue = 15;

            /// <summary>
            /// Property Indexer for OldAmountPercent
            /// </summary>
            public const int OldAmountPercent = 16;

            /// <summary>
            /// Property Indexer for AmountPercentChange
            /// </summary>
            public const int AmountPercentChange = 17;

            /// <summary>
            /// Property Indexer for IDToChange
            /// </summary>
            public const int IDToChange = 19;

            /// <summary>
            /// Property Indexer for FileCreationNo
            /// </summary>
            public const int OldWCCGroup = 23;

            /// <summary>
            /// Property Indexer for NewWCCGroup
            /// </summary>
            public const int NewWCCGroup = 24;

            /// <summary>
            /// Property Indexer for OldBillingRate
            /// </summary>
            public const int OldBillingRate = 25;

            /// <summary>
            /// Property Indexer for NewBillingRate
            /// </summary>
            public const int NewBillingRate = 26;

        }
        #endregion
    }
}