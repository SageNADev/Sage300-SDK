// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of CalculatePayrollOptionalField Constants
    /// </summary>
    public partial class CalculatePayrollOptionalField
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0137";

        #region Fields Properties

        /// <summary>
        /// Contains list of CalculatePayrollOptionalField Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for DummyField
            /// </summary>
            public const string DummyField = "DUMMY";

            /// <summary>
            /// Property for OptionalField
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for Value
            /// </summary>
            public const string Value = "VALUE";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Length
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Decimals
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for AllowBlank
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";

            /// <summary>
            /// Property for Validate
            /// </summary>
            public const string Validate = "VALIDATE";

            /// <summary>
            /// Property for ValueSet
            /// </summary>
            public const string ValueSet = "SWSET";
        }

        #endregion
        #region Index Properties

        /// <summary>
        /// Contains list of CalculatePayrollOptionalField Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for DummyField
            /// </summary>
            public const int DummyField = 1;

            /// <summary>
            /// Property Indexer for OptionalField
            /// </summary>
            public const int OptionalField = 2;

            /// <summary>
            /// Property Indexer for Value
            /// </summary>
            public const int Value = 3;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 4;

            /// <summary>
            /// Property Indexer for Length
            /// </summary>
            public const int Length = 5;

            /// <summary>
            /// Property Indexer for Decimals
            /// </summary>
            public const int Decimals = 6;

            /// <summary>
            /// Property Indexer for AllowBlank
            /// </summary>
            public const int AllowBlank = 7;

            /// <summary>
            /// Property Indexer for Validate
            /// </summary>
            public const int Validate = 8;

            /// <summary>
            /// Property Indexer for ValueSet
            /// </summary>
            public const int ValueSet = 9;
        }

        #endregion

    }
}