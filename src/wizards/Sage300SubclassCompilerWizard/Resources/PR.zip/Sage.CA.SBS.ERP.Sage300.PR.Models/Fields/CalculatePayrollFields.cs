// Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of CalculatePayroll Constants
    /// </summary>
    public partial class CalculatePayroll
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "~~0083";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"EDDAILY", "DailyEDDaily"},
                    {"EDWEEKLY", "DailyEDWeekly"},
                    {"EDBIWEEKLY", "DailyEDBiweekly"},
                    {"EDSEMIMTH", "DailyEDSemimonthly"},
                    {"ED22PERIOD", "DailyED22Periods"},
                    {"ED13PERIOD", "DailyED13Periods"},
                    {"EDMONTHLY", "DailyEDMonthly"},
                    {"ED10PERIOD", "DailyED10Periods"},
                    {"EDQTRLY", "DailyEDQuarterly"},
                    {"EWWEEKLY", "WeeklyEDWeekly"},
                    {"EWBIWEEKLY", "WeeklyEDBiweekly"},
                    {"EWSEMIMTH", "WeeklyEDSemimonthly"},
                    {"EW22PERIOD", "WeeklyED22Periods"},
                    {"EW13PERIOD", "WeeklyED13Periods"},
                    {"EWMONTHLY", "WeeklyEDMonthly"},
                    {"EW10PERIOD", "WeeklyED10Periods"},
                    {"EWQTRLY", "WeeklyEDQuarterly"},
                    {"EBBIWEEKLY", "BiweeklyEDBiweekly"},
                    {"EBSEMIMTH", "BiweeklyEDSemimonthly"},
                    {"EB22PERIOD", "BiweeklyED22Periods"},
                    {"EB13PERIOD", "BiweeklyED13Periods"},
                    {"EBMONTHLY", "BiweeklyEDMonthly"},
                    {"EB10PERIOD", "BiweeklyED10Periods"},
                    {"EBQTRLY", "BiweeklyEDQuarterly"},
                    {"ESSEMIMTH", "SemimonthlyEDSemimonthly"},
                    {"ES22PERIOD", "SemimonthlyED22Periods"},
                    {"ES13PERIOD", "SemimonthlyED13Periods"},
                    {"ESMONTHLY", "SemimonthlyEDMonthly"},
                    {"ES10PERIOD", "SemimonthlyED10Periods"},
                    {"ESQTRLY", "SemimonthlyEDQuarterly"},
                    {"EC22PERIOD", "Num22PeriodsED22Periods"},
                    {"EC13PERIOD", "Num22PeriodsED13Periods"},
                    {"ECMONTHLY", "Num22PeriodsEDMonthly"},
                    {"EC10PERIOD", "Num22PeriodsED10Periods"},
                    {"ECQTRLY", "Num22PeriodsEDQuarterly"},
                    {"EX13PERIOD", "Num13PeriodsED13Periods"},
                    {"EXMONTHLY", "Num13PeriodsEDMonthly"},
                    {"EX10PERIOD", "Num13PeriodsED10Periods"},
                    {"EXQTRLY", "Num13PeriodsEDQuarterly"},
                    {"EMMONTHLY", "MonthlyPeriodsEDMonthly"},
                    {"EM10PERIOD", "MonthlyPeriodsED10Periods"},
                    {"EMQTRLY", "MonthlyPeriodsEDQuarterly"},
                    {"EA10PERIOD", "Num10PeriodsED10Periods"},
                    {"EAQTRLY", "Num10PeriodsEDQuarterly"},
                    {"EQQTRLY", "QuarterlyEDQuarterly"},
                    {"BDDAILY", "DailyPeriodStartDate"},
                    {"BDWEEKLY", "WeeklyPeriodStartDate"},
                    {"BDBIWEEKLY", "BiweeklyPeriodStartDate"},
                    {"BDSEMIMTH", "SemimonthlyPeriodStartDate"},
                    {"BD22PERIOD", "Num22PeriodsPeriodStartDate"},
                    {"BD13PERIOD", "Num13PeriodsPeriodStartDate"},
                    {"BDMONTHLY", "MonthlyPeriodStartDate"},
                    {"BD10PERIOD", "Num10PeriodsPeriodStartDate"},
                    {"BDQTRLY", "QuarterlyPeriodStartDate"},
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of CalculatePayroll Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for BeginningEmployee
            /// </summary>
            public const string BeginningEmployee = "BEGEMP";

            /// <summary>
            /// Property for EndingEmployee
            /// </summary>
            public const string EndingEmployee = "ENDEMP";

            /// <summary>
            /// Property for BeginningClass1
            /// </summary>
            public const string BeginningClass1 = "BEGCLASS1";

            /// <summary>
            /// Property for EndingClass1
            /// </summary>
            public const string EndingClass1 = "ENDCLASS1";

            /// <summary>
            /// Property for BeginningClass2
            /// </summary>
            public const string BeginningClass2 = "BEGCLASS2";

            /// <summary>
            /// Property for EndingClass2
            /// </summary>
            public const string EndingClass2 = "ENDCLASS2";

            /// <summary>
            /// Property for BeginningClass3
            /// </summary>
            public const string BeginningClass3 = "BEGCLASS3";

            /// <summary>
            /// Property for EndingClass3
            /// </summary>
            public const string EndingClass3 = "ENDCLASS3";

            /// <summary>
            /// Property for BeginningClass4
            /// </summary>
            public const string BeginningClass4 = "BEGCLASS4";

            /// <summary>
            /// Property for EndingClass4
            /// </summary>
            public const string EndingClass4 = "ENDCLASS4";

            /// <summary>
            /// Property for SelectionList
            /// </summary>
            public const string SelectionList = "SELECTLIST";

            /// <summary>
            /// Property for PayrollRunDate
            /// </summary>
            public const string PayrollRunDate = "RUNDATE";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "ENDDATE";

            /// <summary>
            /// Property for CheckDate
            /// </summary>
            public const string CheckDate = "CHECKDATE";

            /// <summary>
            /// Property for PayrollPeriod
            /// </summary>
            public const string PayrollPeriod = "PRPERIOD";

            /// <summary>
            /// Property for AdvancesOnly
            /// </summary>
            public const string AdvancesOnly = "ADVANCERUN";

            /// <summary>
            /// Property for DeleteCurrentActivity
            /// </summary>
            public const string DeleteCurrentActivity = "UNPOST";

            /// <summary>
            /// Property for EmpDaily
            /// </summary>
            public const string EmpDaily = "EDAILY";

            /// <summary>
            /// Property for EmpWeekly
            /// </summary>
            public const string EmpWeekly = "EWEEKLY";

            /// <summary>
            /// Property for EmpBiweekly
            /// </summary>
            public const string EmpBiweekly = "EBIWEEKLY";

            /// <summary>
            /// Property for EmpSemimonthly
            /// </summary>
            public const string EmpSemimonthly = "ESEMIMONTH";

            /// <summary>
            /// Property for Emp22Periods
            /// </summary>
            public const string Emp22Periods = "E22PERIODS";

            /// <summary>
            /// Property for Emp13Periods
            /// </summary>
            public const string Emp13Periods = "E13PERIODS";

            /// <summary>
            /// Property for EmpMonthly
            /// </summary>
            public const string EmpMonthly = "EMONTHLY";

            /// <summary>
            /// Property for Emp10Periods
            /// </summary>
            public const string Emp10Periods = "E10PERIODS";

            /// <summary>
            /// Property for EmpQuarterly
            /// </summary>
            public const string EmpQuarterly = "EQUARTERLY";

            /// <summary>
            /// Property for DailyEDDaily
            /// </summary>
            public const string DailyEDDaily = "EDDAILY";

            /// <summary>
            /// Property for DailyEDWeekly
            /// </summary>
            public const string DailyEDWeekly = "EDWEEKLY";

            /// <summary>
            /// Property for DailyEDBiweekly
            /// </summary>
            public const string DailyEDBiweekly = "EDBIWEEKLY";

            /// <summary>
            /// Property for DailyEDSemimonthly
            /// </summary>
            public const string DailyEDSemimonthly = "EDSEMIMTH";

            /// <summary>
            /// Property for DailyED22Periods
            /// </summary>
            public const string DailyED22Periods = "ED22PERIOD";

            /// <summary>
            /// Property for DailyED13Periods
            /// </summary>
            public const string DailyED13Periods = "ED13PERIOD";

            /// <summary>
            /// Property for DailyEDMonthly
            /// </summary>
            public const string DailyEDMonthly = "EDMONTHLY";

            /// <summary>
            /// Property for DailyED10Periods
            /// </summary>
            public const string DailyED10Periods = "ED10PERIOD";

            /// <summary>
            /// Property for DailyEDQuarterly
            /// </summary>
            public const string DailyEDQuarterly = "EDQTRLY";

            /// <summary>
            /// Property for WeeklyEDWeekly
            /// </summary>
            public const string WeeklyEDWeekly = "EWWEEKLY";

            /// <summary>
            /// Property for WeeklyEDBiweekly
            /// </summary>
            public const string WeeklyEDBiweekly = "EWBIWEEKLY";

            /// <summary>
            /// Property for WeeklyEDSemimonthly
            /// </summary>
            public const string WeeklyEDSemimonthly = "EWSEMIMTH";

            /// <summary>
            /// Property for WeeklyED22Periods
            /// </summary>
            public const string WeeklyED22Periods = "EW22PERIOD";

            /// <summary>
            /// Property for WeeklyED13Periods
            /// </summary>
            public const string WeeklyED13Periods = "EW13PERIOD";

            /// <summary>
            /// Property for WeeklyEDMonthly
            /// </summary>
            public const string WeeklyEDMonthly = "EWMONTHLY";

            /// <summary>
            /// Property for WeeklyED10Periods
            /// </summary>
            public const string WeeklyED10Periods = "EW10PERIOD";

            /// <summary>
            /// Property for WeeklyEDQuarterly
            /// </summary>
            public const string WeeklyEDQuarterly = "EWQTRLY";

            /// <summary>
            /// Property for BiweeklyEDBiweekly
            /// </summary>
            public const string BiweeklyEDBiweekly = "EBBIWEEKLY";

            /// <summary>
            /// Property for BiweeklyEDSemimonthly
            /// </summary>
            public const string BiweeklyEDSemimonthly = "EBSEMIMTH";

            /// <summary>
            /// Property for BiweeklyED22Periods
            /// </summary>
            public const string BiweeklyED22Periods = "EB22PERIOD";

            /// <summary>
            /// Property for BiweeklyED13Periods
            /// </summary>
            public const string BiweeklyED13Periods = "EB13PERIOD";

            /// <summary>
            /// Property for BiweeklyEDMonthly
            /// </summary>
            public const string BiweeklyEDMonthly = "EBMONTHLY";

            /// <summary>
            /// Property for BiweeklyED10Periods
            /// </summary>
            public const string BiweeklyED10Periods = "EB10PERIOD";

            /// <summary>
            /// Property for BiweeklyEDQuarterly
            /// </summary>
            public const string BiweeklyEDQuarterly = "EBQTRLY";

            /// <summary>
            /// Property for SemimonthlyEDSemimonthly
            /// </summary>
            public const string SemimonthlyEDSemimonthly = "ESSEMIMTH";

            /// <summary>
            /// Property for SemimonthlyED22Periods
            /// </summary>
            public const string SemimonthlyED22Periods = "ES22PERIOD";

            /// <summary>
            /// Property for SemimonthlyED13Periods
            /// </summary>
            public const string SemimonthlyED13Periods = "ES13PERIOD";

            /// <summary>
            /// Property for SemimonthlyEDMonthly
            /// </summary>
            public const string SemimonthlyEDMonthly = "ESMONTHLY";

            /// <summary>
            /// Property for SemimonthlyED10Periods
            /// </summary>
            public const string SemimonthlyED10Periods = "ES10PERIOD";

            /// <summary>
            /// Property for SemimonthlyEDQuarterly
            /// </summary>
            public const string SemimonthlyEDQuarterly = "ESQTRLY";

            /// <summary>
            /// Property for Num22PeriodsED22Periods
            /// </summary>
            public const string Num22PeriodsED22Periods = "EC22PERIOD";

            /// <summary>
            /// Property for Num22PeriodsED13Periods
            /// </summary>
            public const string Num22PeriodsED13Periods = "EC13PERIOD";

            /// <summary>
            /// Property for Num22PeriodsEDMonthly
            /// </summary>
            public const string Num22PeriodsEDMonthly = "ECMONTHLY";

            /// <summary>
            /// Property for Num22PeriodsED10Periods
            /// </summary>
            public const string Num22PeriodsED10Periods = "EC10PERIOD";

            /// <summary>
            /// Property for Num22PeriodsEDQuarterly
            /// </summary>
            public const string Num22PeriodsEDQuarterly = "ECQTRLY";

            /// <summary>
            /// Property for Num13PeriodsED13Periods
            /// </summary>
            public const string Num13PeriodsED13Periods = "EX13PERIOD";

            /// <summary>
            /// Property for Num13PeriodsEDMonthly
            /// </summary>
            public const string Num13PeriodsEDMonthly = "EXMONTHLY";

            /// <summary>
            /// Property for Num13PeriodsED10Periods
            /// </summary>
            public const string Num13PeriodsED10Periods = "EX10PERIOD";

            /// <summary>
            /// Property for Num13PeriodsEDQuarterly
            /// </summary>
            public const string Num13PeriodsEDQuarterly = "EXQTRLY";

            /// <summary>
            /// Property for MonthlyPeriodsEDMonthly
            /// </summary>
            public const string MonthlyPeriodsEDMonthly = "EMMONTHLY";

            /// <summary>
            /// Property for MonthlyPeriodsED10Periods
            /// </summary>
            public const string MonthlyPeriodsED10Periods = "EM10PERIOD";

            /// <summary>
            /// Property for MonthlyPeriodsEDQuarterly
            /// </summary>
            public const string MonthlyPeriodsEDQuarterly = "EMQTRLY";

            /// <summary>
            /// Property for Num10PeriodsED10Periods
            /// </summary>
            public const string Num10PeriodsED10Periods = "EA10PERIOD";

            /// <summary>
            /// Property for Num10PeriodsEDQuarterly
            /// </summary>
            public const string Num10PeriodsEDQuarterly = "EAQTRLY";

            /// <summary>
            /// Property for QuarterlyEDQuarterly
            /// </summary>
            public const string QuarterlyEDQuarterly = "EQQTRLY";

            /// <summary>
            /// Property for DailyPeriodStartDate
            /// </summary>
            public const string DailyPeriodStartDate = "BDDAILY";

            /// <summary>
            /// Property for WeeklyPeriodStartDate
            /// </summary>
            public const string WeeklyPeriodStartDate = "BDWEEKLY";

            /// <summary>
            /// Property for BiweeklyPeriodStartDate
            /// </summary>
            public const string BiweeklyPeriodStartDate = "BDBIWEEKLY";

            /// <summary>
            /// Property for SemimonthlyPeriodStartDate
            /// </summary>
            public const string SemimonthlyPeriodStartDate = "BDSEMIMTH";

            /// <summary>
            /// Property for Num22PeriodsPeriodStartDate
            /// </summary>
            public const string Num22PeriodsPeriodStartDate = "BD22PERIOD";

            /// <summary>
            /// Property for Num13PeriodsPeriodStartDate
            /// </summary>
            public const string Num13PeriodsPeriodStartDate = "BD13PERIOD";

            /// <summary>
            /// Property for MonthlyPeriodStartDate
            /// </summary>
            public const string MonthlyPeriodStartDate = "BDMONTHLY";

            /// <summary>
            /// Property for Num10PeriodsPeriodStartDate
            /// </summary>
            public const string Num10PeriodsPeriodStartDate = "BD10PERIOD";

            /// <summary>
            /// Property for QuarterlyPeriodStartDate
            /// </summary>
            public const string QuarterlyPeriodStartDate = "BDQTRLY";

            /// <summary>
            /// Property for DoEFTCalculation
            /// </summary>
            public const string DoEFTCalculation = "DOEFTCALC";

            /// <summary>
            /// Property for CalculationOption
            /// </summary>
            public const string CalculationOption = "CALCOPTION";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for DummyField
            /// </summary>
            public const string DummyField = "DUMMY";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for TaxVersion
            /// </summary>
            public const string TaxVersion = "TAXVERSION";

        }

        #endregion
        #region Index Properties

        /// <summary>
        /// Contains list of CalculatePayroll Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for BeginningEmployee
            /// </summary>
            public const int BeginningEmployee = 1;

            /// <summary>
            /// Property Indexer for EndingEmployee
            /// </summary>
            public const int EndingEmployee = 2;

            /// <summary>
            /// Property Indexer for BeginningClass1
            /// </summary>
            public const int BeginningClass1 = 3;

            /// <summary>
            /// Property Indexer for EndingClass1
            /// </summary>
            public const int EndingClass1 = 4;

            /// <summary>
            /// Property Indexer for BeginningClass2
            /// </summary>
            public const int BeginningClass2 = 5;

            /// <summary>
            /// Property Indexer for EndingClass2
            /// </summary>
            public const int EndingClass2 = 6;

            /// <summary>
            /// Property Indexer for BeginningClass3
            /// </summary>
            public const int BeginningClass3 = 7;

            /// <summary>
            /// Property Indexer for EndingClass3
            /// </summary>
            public const int EndingClass3 = 8;

            /// <summary>
            /// Property Indexer for BeginningClass4
            /// </summary>
            public const int BeginningClass4 = 9;

            /// <summary>
            /// Property Indexer for EndingClass4
            /// </summary>
            public const int EndingClass4 = 10;

            /// <summary>
            /// Property Indexer for SelectionList
            /// </summary>
            public const int SelectionList = 11;

            /// <summary>
            /// Property Indexer for PayrollRunDate
            /// </summary>
            public const int PayrollRunDate = 12;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 13;

            /// <summary>
            /// Property Indexer for CheckDate
            /// </summary>
            public const int CheckDate = 14;

            /// <summary>
            /// Property Indexer for PayrollPeriod
            /// </summary>
            public const int PayrollPeriod = 15;

            /// <summary>
            /// Property Indexer for AdvancesOnly
            /// </summary>
            public const int AdvancesOnly = 16;

            /// <summary>
            /// Property Indexer for DeleteCurrentActivity
            /// </summary>
            public const int DeleteCurrentActivity = 17;

            /// <summary>
            /// Property Indexer for EmpDaily
            /// </summary>
            public const int EmpDaily = 18;

            /// <summary>
            /// Property Indexer for EmpWeekly
            /// </summary>
            public const int EmpWeekly = 19;

            /// <summary>
            /// Property Indexer for EmpBiweekly
            /// </summary>
            public const int EmpBiweekly = 20;

            /// <summary>
            /// Property Indexer for EmpSemimonthly
            /// </summary>
            public const int EmpSemimonthly = 21;

            /// <summary>
            /// Property Indexer for Emp22Periods
            /// </summary>
            public const int Emp22Periods = 22;

            /// <summary>
            /// Property Indexer for Emp13Periods
            /// </summary>
            public const int Emp13Periods = 23;

            /// <summary>
            /// Property Indexer for EmpMonthly
            /// </summary>
            public const int EmpMonthly = 24;

            /// <summary>
            /// Property Indexer for Emp10Periods
            /// </summary>
            public const int Emp10Periods = 25;

            /// <summary>
            /// Property Indexer for EmpQuarterly
            /// </summary>
            public const int EmpQuarterly = 26;

            /// <summary>
            /// Property Indexer for DailyEDDaily
            /// </summary>
            public const int DailyEDDaily = 27;

            /// <summary>
            /// Property Indexer for DailyEDWeekly
            /// </summary>
            public const int DailyEDWeekly = 28;

            /// <summary>
            /// Property Indexer for DailyEDBiweekly
            /// </summary>
            public const int DailyEDBiweekly = 29;

            /// <summary>
            /// Property Indexer for DailyEDSemimonthly
            /// </summary>
            public const int DailyEDSemimonthly = 30;

            /// <summary>
            /// Property Indexer for DailyED22Periods
            /// </summary>
            public const int DailyED22Periods = 31;

            /// <summary>
            /// Property Indexer for DailyED13Periods
            /// </summary>
            public const int DailyED13Periods = 32;

            /// <summary>
            /// Property Indexer for DailyEDMonthly
            /// </summary>
            public const int DailyEDMonthly = 33;

            /// <summary>
            /// Property Indexer for DailyED10Periods
            /// </summary>
            public const int DailyED10Periods = 34;

            /// <summary>
            /// Property Indexer for DailyEDQuarterly
            /// </summary>
            public const int DailyEDQuarterly = 35;

            /// <summary>
            /// Property Indexer for WeeklyEDWeekly
            /// </summary>
            public const int WeeklyEDWeekly = 36;

            /// <summary>
            /// Property Indexer for WeeklyEDBiweekly
            /// </summary>
            public const int WeeklyEDBiweekly = 37;

            /// <summary>
            /// Property Indexer for WeeklyEDSemimonthly
            /// </summary>
            public const int WeeklyEDSemimonthly = 38;

            /// <summary>
            /// Property Indexer for WeeklyED22Periods
            /// </summary>
            public const int WeeklyED22Periods = 39;

            /// <summary>
            /// Property Indexer for WeeklyED13Periods
            /// </summary>
            public const int WeeklyED13Periods = 40;

            /// <summary>
            /// Property Indexer for WeeklyEDMonthly
            /// </summary>
            public const int WeeklyEDMonthly = 41;

            /// <summary>
            /// Property Indexer for WeeklyED10Periods
            /// </summary>
            public const int WeeklyED10Periods = 42;

            /// <summary>
            /// Property Indexer for WeeklyEDQuarterly
            /// </summary>
            public const int WeeklyEDQuarterly = 43;

            /// <summary>
            /// Property Indexer for BiweeklyEDBiweekly
            /// </summary>
            public const int BiweeklyEDBiweekly = 44;

            /// <summary>
            /// Property Indexer for BiweeklyEDSemimonthly
            /// </summary>
            public const int BiweeklyEDSemimonthly = 45;

            /// <summary>
            /// Property Indexer for BiweeklyED22Periods
            /// </summary>
            public const int BiweeklyED22Periods = 46;

            /// <summary>
            /// Property Indexer for BiweeklyED13Periods
            /// </summary>
            public const int BiweeklyED13Periods = 47;

            /// <summary>
            /// Property Indexer for BiweeklyEDMonthly
            /// </summary>
            public const int BiweeklyEDMonthly = 48;

            /// <summary>
            /// Property Indexer for BiweeklyED10Periods
            /// </summary>
            public const int BiweeklyED10Periods = 49;

            /// <summary>
            /// Property Indexer for BiweeklyEDQuarterly
            /// </summary>
            public const int BiweeklyEDQuarterly = 50;

            /// <summary>
            /// Property Indexer for SemimonthlyEDSemimonthly
            /// </summary>
            public const int SemimonthlyEDSemimonthly = 51;

            /// <summary>
            /// Property Indexer for SemimonthlyED22Periods
            /// </summary>
            public const int SemimonthlyED22Periods = 52;

            /// <summary>
            /// Property Indexer for SemimonthlyED13Periods
            /// </summary>
            public const int SemimonthlyED13Periods = 53;

            /// <summary>
            /// Property Indexer for SemimonthlyEDMonthly
            /// </summary>
            public const int SemimonthlyEDMonthly = 54;

            /// <summary>
            /// Property Indexer for SemimonthlyED10Periods
            /// </summary>
            public const int SemimonthlyED10Periods = 55;

            /// <summary>
            /// Property Indexer for SemimonthlyEDQuarterly
            /// </summary>
            public const int SemimonthlyEDQuarterly = 56;

            /// <summary>
            /// Property Indexer for Num22PeriodsED22Periods
            /// </summary>
            public const int Num22PeriodsED22Periods = 57;

            /// <summary>
            /// Property Indexer for Num22PeriodsED13Periods
            /// </summary>
            public const int Num22PeriodsED13Periods = 58;

            /// <summary>
            /// Property Indexer for Num22PeriodsEDMonthly
            /// </summary>
            public const int Num22PeriodsEDMonthly = 59;

            /// <summary>
            /// Property Indexer for Num22PeriodsED10Periods
            /// </summary>
            public const int Num22PeriodsED10Periods = 60;

            /// <summary>
            /// Property Indexer for Num22PeriodsEDQuarterly
            /// </summary>
            public const int Num22PeriodsEDQuarterly = 61;

            /// <summary>
            /// Property Indexer for Num13PeriodsED13Periods
            /// </summary>
            public const int Num13PeriodsED13Periods = 62;

            /// <summary>
            /// Property Indexer for Num13PeriodsEDMonthly
            /// </summary>
            public const int Num13PeriodsEDMonthly = 63;

            /// <summary>
            /// Property Indexer for Num13PeriodsED10Periods
            /// </summary>
            public const int Num13PeriodsED10Periods = 64;

            /// <summary>
            /// Property Indexer for Num13PeriodsEDQuarterly
            /// </summary>
            public const int Num13PeriodsEDQuarterly = 65;

            /// <summary>
            /// Property Indexer for MonthlyPeriodsEDMonthly
            /// </summary>
            public const int MonthlyPeriodsEDMonthly = 66;

            /// <summary>
            /// Property Indexer for MonthlyPeriodsED10Periods
            /// </summary>
            public const int MonthlyPeriodsED10Periods = 67;

            /// <summary>
            /// Property Indexer for MonthlyPeriodsEDQuarterly
            /// </summary>
            public const int MonthlyPeriodsEDQuarterly = 68;

            /// <summary>
            /// Property Indexer for Num10PeriodsED10Periods
            /// </summary>
            public const int Num10PeriodsED10Periods = 69;

            /// <summary>
            /// Property Indexer for Num10PeriodsEDQuarterly
            /// </summary>
            public const int Num10PeriodsEDQuarterly = 70;

            /// <summary>
            /// Property Indexer for QuarterlyEDQuarterly
            /// </summary>
            public const int QuarterlyEDQuarterly = 71;

            /// <summary>
            /// Property Indexer for DailyPeriodStartDate
            /// </summary>
            public const int DailyPeriodStartDate = 72;

            /// <summary>
            /// Property Indexer for WeeklyPeriodStartDate
            /// </summary>
            public const int WeeklyPeriodStartDate = 73;

            /// <summary>
            /// Property Indexer for BiweeklyPeriodStartDate
            /// </summary>
            public const int BiweeklyPeriodStartDate = 74;

            /// <summary>
            /// Property Indexer for SemimonthlyPeriodStartDate
            /// </summary>
            public const int SemimonthlyPeriodStartDate = 75;

            /// <summary>
            /// Property Indexer for Num22PeriodsPeriodStartDate
            /// </summary>
            public const int Num22PeriodsPeriodStartDate = 76;

            /// <summary>
            /// Property Indexer for Num13PeriodsPeriodStartDate
            /// </summary>
            public const int Num13PeriodsPeriodStartDate = 77;

            /// <summary>
            /// Property Indexer for MonthlyPeriodStartDate
            /// </summary>
            public const int MonthlyPeriodStartDate = 78;

            /// <summary>
            /// Property Indexer for Num10PeriodsPeriodStartDate
            /// </summary>
            public const int Num10PeriodsPeriodStartDate = 79;

            /// <summary>
            /// Property Indexer for QuarterlyPeriodStartDate
            /// </summary>
            public const int QuarterlyPeriodStartDate = 80;

            /// <summary>
            /// Property Indexer for DoEFTCalculation
            /// </summary>
            public const int DoEFTCalculation = 81;

            /// <summary>
            /// Property Indexer for CalculationOption
            /// </summary>
            public const int CalculationOption = 82;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 83;

            /// <summary>
            /// Property Indexer for DummyField
            /// </summary>
            public const int DummyField = 84;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 85;

            /// <summary>
            /// Property Indexer for TaxVersion
            /// </summary>
            public const int TaxVersion = 86;


        }

        #endregion

    }
}