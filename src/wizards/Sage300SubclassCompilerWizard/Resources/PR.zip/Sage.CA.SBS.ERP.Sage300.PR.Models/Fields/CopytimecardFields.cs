﻿// Copyright (c) 2025 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Contains list of Copytimecard Constants
    /// </summary>
    public partial class Copytimecard
    {
        /// <summary>
        /// Entity Name with prefix added later
        /// </summary>
        public const string EntityName = "~~0108";


        #region Fields Properties

        /// <summary>
        /// Contains list of Copytimecard Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "PEREND";

            /// <summary>
            /// Property for Timecard
            /// </summary>
            public const string Timecard = "TIMECARD";

            /// <summary>
            /// Property for AssignTimecardNumber
            /// </summary>
            public const string AssignTimecardNumber = "CTIMECARD";

            /// <summary>
            /// Property for ReuseTimecard
            /// </summary>
            public const string ReuseTimecard = "CREUSECARD"; 

            /// <summary>
            /// Property for AssignPeriodEndDate
            /// </summary>
            public const string AssignPeriodEndDate = "CPEREND";

            /// <summary>
            /// Property for AssignActiveStatus
            /// </summary>
            public const string AssignActiveStatus = "CACTIVE";

            /// <summary>
            /// Property for AssignSeparateCheckFlag
            /// </summary>
            public const string AssignSeparateCheckFlag = "CSEPCHECK";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "CTCARDDESC";

            /// <summary>
            /// Property for Chooseby
            /// </summary>
            public const string Chooseby = "CCHOICE";

            /// <summary>
            /// Property for SelectionList
            /// </summary>
            public const string SelectionList = "CEMPLISTID";

            /// <summary>
            /// Property for FromEmployee
            /// </summary>
            public const string FromEmployee = "CFEMPLOYEE";

            /// <summary>
            /// Property for ToEmployee
            /// </summary>
            public const string ToEmployee = "CTEMPLOYEE";

            /// <summary>
            /// Property for Class
            /// </summary>
            public const string CopyClass = "CCLASS";   

            /// <summary>
            /// Property for FromClassCode
            /// </summary>
            public const string FromClassCode = "CFCLASSCOD";

            /// <summary>
            /// Property for ToClassCode
            /// </summary>
            public const string ToClassCode = "CTCLASSCOD";

            /// <summary>
            /// Property for Ignoreinvaliddetails
            /// </summary>
            public const string Ignoreinvaliddetails = "CIGNOREEDT";

            /// <summary>
            /// Property for SkipEmployeesInvalidData
            /// </summary>
            public const string SkipEmployeesInvalidData = "CSKIPEMP";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";
        }
        #endregion

        /// <summary>
        /// Contains list of copy timecard Index Constants
        /// </summary>
        /// 
        #region Index Properties

        public class Index
        {
            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 1;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 2;

            /// <summary>
            /// Property Indexer for Timecard
            /// </summary>
            public const int Timecard = 3;

            /// <summary>
            /// Property Indexer for AssignTimecardNumber
            /// </summary>
            public const int AssignTimecardNumber = 4;

            /// <summary>
            /// Property Indexer for AssignReusable
            /// </summary>
            public const int ReuseTimecard = 5; 

            /// <summary>
            /// Property Indexer for AssignPeriodEndDate
            /// </summary>
            public const int AssignPeriodEndDate = 6;

            /// <summary>
            /// Property Indexer for AssignActiveStatus
            /// </summary>
            public const int AssignActiveStatus = 7;

            /// <summary>
            /// Property Indexer for AssignSeparateCheckFlag
            /// </summary>
            public const int AssignSeparateCheckFlag = 8;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 9;

            /// <summary>
            /// Property Indexer for Chooseby
            /// </summary>
            public const int Chooseby = 10;

            /// <summary>
            /// Property Indexer for SelectionList
            /// </summary>
            public const int SelectionList = 11;

            /// <summary>
            /// Property Indexer for FromEmployee
            /// </summary>
            public const int FromEmployee = 12;

            /// <summary>
            /// Property Indexer for ToEmployee
            /// </summary>
            public const int ToEmployee = 13;

            /// <summary>
            /// Property Indexer for Class
            /// </summary>
            public const int CopyClass = 14;    

            /// <summary>
            /// Property Indexer for FromClassCode
            /// </summary>
            public const int FromClassCode = 15;

            /// <summary>
            /// Property Indexer for ToClassCode
            /// </summary>
            public const int ToClassCode = 16;

            /// <summary>
            /// Property Indexer for Ignoreinvaliddetails
            /// </summary>
            public const int Ignoreinvaliddetails = 17;

            /// <summary>
            /// Property Indexer for SkipEmployeesInvalidData
            /// </summary>
            public const int SkipEmployeesInvalidData = 18;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 19;
        }
            #endregion
    }
}
