// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms; 

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for PrenoteStatus
    /// </summary>
    public enum PrenoteStatus
    {
        /// <summary>
        /// Gets or sets NotSent
        /// </summary>
        [EnumValue("NotSent", typeof(EmployeeEFTBankResx))]
        NotSent = 0,
        /// <summary>
        /// Gets or sets Pending
        /// </summary>
        [EnumValue("Pending", typeof(EmployeeEFTBankResx))]
        Pending = 1,
        /// <summary>
        /// Gets or sets Approved
        /// </summary>
        [EnumValue("Approved", typeof(EmployeeEFTBankResx))]
        Approved = 2,
        /// <summary>
        /// Gets or sets Declined
        /// </summary>
        [EnumValue("Declined", typeof(EmployeeEFTBankResx))]
        Declined = 3
    }
}