﻿
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	public enum UseDefDate 
	{
		/// <summary>
		/// Gets or sets UseEmployeeCheckDate
		/// </summary>
		[EnumValue("UseEmployeeCheckDate", typeof(GenerateEFTFileResx))]
		UseEmployeeCheckDate = 1,

		/// <summary>
		/// Gets or sets UseDeafultFundsAvailableDate
		/// </summary>
		[EnumValue("UseDefaultFundsAvailableDate", typeof(GenerateEFTFileResx))]
		UseDeafultFunfdsAvailableDate = 2,
	}
	public enum UseDefDateCP
	{
		/// <summary>
		/// Gets or sets UseEmployeeChequeDate
		/// </summary>

		[EnumValue("UseEmployeeChequeDate", typeof(GenerateEFTFileResx))]
		UseEmployeeChequeDate = 1,

		/// <summary>
		/// Gets or sets UseDeafultFundsAvailableDate
		/// </summary>

		[EnumValue("UseDefaultFundsAvailableDate", typeof(GenerateEFTFileResx))]
		UseDeafultFundsAvailableDate = 2,
    }
}
