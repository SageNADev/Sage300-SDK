// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for TypeOfCheck
    /// </summary>
    public enum TypeOfCheckDocument
    {
        /// <summary>
        /// Gets or sets All
        /// </summary>
        [EnumValue("All", typeof(PRCommonResx))]
        All = -1,
        /// <summary>
        /// Gets or sets SystemCheck
        /// </summary>
        [EnumValue("SystemCheck", typeof(PRCommonResx),1)]
        SystemCheck = 1,
        /// <summary>
        /// Gets or sets ManualCheck
        /// </summary>
        [EnumValue("ManualCheck", typeof(PRCommonResx),2)]
        ManualCheck = 2,
        /// <summary>
        /// Gets or sets HistoryEntry
        /// </summary>
        [EnumValue("HistoryEntry", typeof(PRCommonResx),3)]
        HistoryEntry = 4,
        /// <summary>
        /// Gets or sets ReversedCheck
        /// </summary>
        [EnumValue("ReversedCheck", typeof(PRCommonResx),4)]
        ReversedCheck = 5,
       
    }
}