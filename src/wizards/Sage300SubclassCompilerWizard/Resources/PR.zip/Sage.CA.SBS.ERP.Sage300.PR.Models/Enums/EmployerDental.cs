// Copyright (c) 2024 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for EmployerDental
	/// </summary>
	public enum EmployerDental
	{
		/// <summary>
		/// Gets or sets NoEmployerCoverage
		/// </summary>

		[EnumValue("NoEmployerCoverage", typeof(EmployeeResx))]
		NoEmployerCoverage = 0,

		/// <summary>
		/// Gets or sets EmployeeOnly
		/// </summary>

		[EnumValue("EmployeeOnly", typeof(EmployeeResx))]
		EmployeeOnly = 1,

		/// <summary>
		/// Gets or sets EmployeeSpouseDependants
		/// </summary>

		[EnumValue("EmployeeSpouseDependants", typeof(EmployeeResx))]
		EmployeeSpouseDependants = 2,

		/// <summary>
		/// Gets or sets EmployeeSpouseOnly
		/// </summary>

		[EnumValue("EmployeeSpouseOnly", typeof(EmployeeResx))]
		EmployeeSpouseOnly = 3,

		/// <summary>
		/// Gets or sets EmployeeDependantsOnly
		/// </summary>

		[EnumValue("EmployeeDependantsOnly", typeof(EmployeeResx))]
		EmployeeDependantsOnly = 4
	}
}
