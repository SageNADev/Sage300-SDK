// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for SentToGL
    /// </summary>
    public enum SentToGL
    {
        /// <summary>
        /// Gets or sets NotSent
        /// </summary>
        [EnumValue("NotSent", typeof(CheckHeaderResx))]
        NotSent = 1,
        /// <summary>
        /// Gets or sets Sent
        /// </summary>
        [EnumValue("Sent", typeof(CheckHeaderResx))]
        Sent = 2,
        /// <summary>
        /// Gets or sets NotToBeSent
        /// </summary>
        [EnumValue("NotToBeSent", typeof(CheckHeaderResx))]
        NotToBeSent = 3
    }
}