﻿// Copyright (c) 2023-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for TypeOfCheque
    /// </summary>
    public enum TypeOfCheckCP
    {
        /// <summary>
        /// Gets or sets All
        /// </summary>
        [EnumValue("All", typeof(CheckHeaderResx))]
        All = -1,
        /// <summary>
        /// Gets or sets SystemCheque
        /// </summary>
        [EnumValue("SystemCheque", typeof(CheckHeaderResx), 1)]
        SystemCheque = 1,
        /// <summary>
        /// Gets or sets ManualCheque
        /// </summary>
        [EnumValue("ManualCheque", typeof(CheckHeaderResx), 2)]
        ManualCheque = 2,
        /// <summary>
        /// Gets or sets HistoryCheck
        /// </summary>
        [EnumValue("HistoryCheck", typeof(CheckHeaderResx), 3)]
        HistoryEntry = 4,
        /// <summary>
        /// Gets or sets ReversedCheque
        /// </summary>
        [EnumValue("ReversedCheque", typeof(CheckHeaderResx), 4)]
        ReversedCheque = 5,

    }
}