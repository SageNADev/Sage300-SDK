// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for OriginalType
    /// </summary>
    public enum OriginalType
    {
        /// <summary>
        /// Gets or sets SystemCheck
        /// </summary>
        [EnumValue("SystemCheck", typeof(CheckHeaderResx))]
        SystemCheck = 1,
        /// <summary>
        /// Gets or sets ManualCheck
        /// </summary>
        [EnumValue("ManualCheck", typeof(CheckHeaderResx))]
        ManualCheck = 2,
        /// <summary>
        /// Gets or sets Adjustment
        /// </summary>
        [EnumValue("Adjustment", typeof(CheckHeaderResx))]
        Adjustment = 3,
        /// <summary>
        /// Gets or sets HistoryEntry
        /// </summary>
        [EnumValue("HistoryEntry", typeof(CheckHeaderResx))]
        HistoryEntry = 4,
        /// <summary>
        /// Gets or sets ReversedCheck
        /// </summary>
        [EnumValue("ReversedCheck", typeof(CheckHeaderResx))]
        ReversedCheck = 5
    }
}