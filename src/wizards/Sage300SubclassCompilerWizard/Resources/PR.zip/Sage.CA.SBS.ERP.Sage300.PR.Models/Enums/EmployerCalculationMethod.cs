// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for EmployerCalculationMethod
    /// </summary>
    public enum EmployerCalculationMethod
    {
        /// <summary>
        /// Gets or sets Flat
        /// </summary>
        [EnumValue("Flat", typeof(EarningsDeductionResx))]
        Flat = 2,
        /// <summary>
        /// Gets or sets AmountPerHour
        /// </summary>
        [EnumValue("AmountPerHour", typeof(EarningsDeductionResx))]
        AmountPerHour = 5,
        /// <summary>
        /// Gets or sets PieceRateTable
        /// </summary>
        [EnumValue("PieceRateTable", typeof(EarningsDeductionResx))]
        PieceRateTable = 6,
        /// <summary>
        /// Gets or sets PercentageOfBase
        /// </summary>
        [EnumValue("PercentageOfBase", typeof(EarningsDeductionResx))]
        PercentageOfBase = 7,
        /// <summary>
        /// Gets or sets SalesCommissionTable
        /// </summary>
        [EnumValue("SalesCommissionTable", typeof(EarningsDeductionResx))]
        SalesCommissionTable = 8,
        /// <summary>
        /// Gets or sets WageBracketTable
        /// </summary>
        [EnumValue("WageBracketTable", typeof(EarningsDeductionResx))]
        WageBracketTable = 9
    }
}
