﻿
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    public enum EmployeeSelectionType
    {
		/// <summary>
		/// Gets or sets EmployeeNumber
		/// </summary>

		[EnumValue("EmployeeNumber", typeof(AssignAuditResx))]
		EmployeeNumber = 0,

		/// <summary>
		/// Gets or sets Class
		/// </summary>

		[EnumValue("Class", typeof(AssignAuditResx))]
		Class = 1,

		/// <summary>
		/// Gets or sets SelectionList
		/// </summary>

		[EnumValue("SelectionList", typeof(AssignAuditResx))]
		SelectionList = 2,

		/// <summary>
		/// Gets or sets SetCriteria
		/// </summary>
		[EnumValue("SetCriteria", typeof(AssignAuditResx))]
		SetCriteria = 3
	}
}
