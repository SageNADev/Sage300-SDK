// Copyright (c) 1994-2023 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for CalculationOption
    /// </summary>
    public enum CalculationOption
    {
        /// <summary>
        /// Gets or sets AllChecks
        /// </summary>
        [EnumValue("AllChecks", typeof(CalculatePayrollResx))]
        AllChecks = 1,
        /// <summary>
        /// Gets or sets AdvanceOnly
        /// </summary>
        [EnumValue("AdvanceOnly", typeof(CalculatePayrollResx))]
        AdvanceOnly = 2,
        /// <summary>
        /// Gets or sets IgnoreZeroAndNegativeChecks
        /// </summary>
        [EnumValue("IgnoreZeroAndNegativeChecks", typeof(CalculatePayrollResx))]
        IgnoreZeroAndNegativeChecks = 3,
        /// <summary>
        /// Gets or sets IgnoreNegativeChecks
        /// </summary>
        [EnumValue("IgnoreNegativeChecks", typeof(CalculatePayrollResx))]
        IgnoreNegativeChecks = 4
    }
    /// <summary>
    /// Enum for CalculationOptionCP
    /// </summary>
    public enum CalculationOptionCP
    {
        /// <summary>
        /// Gets or sets AllCheques
        /// </summary>
        [EnumValue("AllCheques", typeof(CalculatePayrollResx))]
        AllChecks = 1,
        /// <summary>
        /// Gets or sets AdvanceOnly
        /// </summary>
        [EnumValue("AdvanceOnly", typeof(CalculatePayrollResx))]
        AdvanceOnly = 2,
        /// <summary>
        /// Gets or sets IgnoreZeroAndNegativeCheques
        /// </summary>
        [EnumValue("IgnoreZeroAndNegativeCheques", typeof(CalculatePayrollResx))]
        IgnoreZeroAndNegativeChecks = 3,
        /// <summary>
        /// Gets or sets IgnoreNegativeCheques
        /// </summary>
        [EnumValue("IgnoreNegativeCheques", typeof(CalculatePayrollResx))]
        IgnoreNegativeChecks = 4
    }
}