// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for WithholdingMethodForTaxableW
    /// </summary>
    public enum WithholdingMethodForTaxableW
    {
        /// <summary>
        /// Gets or sets RegularRate
        /// </summary>
        [EnumValue("RegularRate", typeof(EarningsDeductionResx))]
        RegularRate = 1,
        /// <summary>
        /// Gets or sets TaxableNoWithholding
        /// </summary>
        [EnumValue("TaxableNoWithholding", typeof(EarningsDeductionResx))]
        TaxableNoWithholding = 4,
        /// <summary>
        /// Gets or sets SupplementalWithholding
        /// </summary>
        [EnumValue("SupplementalWithholding", typeof(EarningsDeductionResx))]
        SupplementalWithholding = 6
    }
}
