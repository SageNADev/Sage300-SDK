// Copyright (c) 1994-2023 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for ProcessCommandCode
	/// </summary>
	public enum ProcessCommand
	{
		/// <summary>
		/// Gets or sets NoAction
		/// </summary>

		[EnumValue("Generated", typeof(CommonResx))]
		NoAction = 0,

		/// <summary>
		/// Gets or sets ModifyOrAssignRecords
		/// </summary>

		[EnumValue("Generated", typeof(CommonResx))]
		ModifyOrAssignRecords = 1,

		/// <summary>
		/// Gets or sets ClearAuditFiles
		/// </summary>

		[EnumValue("Generated", typeof(CommonResx))]
		ClearAuditFiles = 2,

		/// <summary>
		/// Gets or sets UpdateInfoToMatchJobs
		/// </summary>

		[EnumValue("Generated", typeof(CommonResx))]
		LockEditFunction  = 3,

		/// <summary>
		/// Gets or sets CalculatePayroll
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		LockAuditReportFunction = 4,
			
		/// <summary>
		/// Gets or sets CalculatePayroll
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		UnlockAuditReportFunction  = 5
	}
}
