// Copyright (c) 2024 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for PayerDental
	/// </summary>
	public enum PayerDental
	{
		/// <summary>
		/// Gets or sets NoPayeeCoverage
		/// </summary>

		[EnumValue("NoPayeeCoverage", typeof(EmployeeResx))]
		NoPayeeCoverage = 1,

		/// <summary>
		/// Gets or sets PayeeOnly
		/// </summary>

		[EnumValue("PayeeOnly", typeof(EmployeeResx))]
		PayeeOnly = 2,

		/// <summary>
		/// Gets or sets PayeeSpouseDependants
		/// </summary>

		[EnumValue("PayeeSpouseDependants", typeof(EmployeeResx))]
		PayeeSpouseDependants = 3,

		/// <summary>
		/// Gets or sets PayeeSpouseOnly
		/// </summary>

		[EnumValue("PayeeSpouseOnly", typeof(EmployeeResx))]
		PayeeSpouseOnly = 4,

		/// <summary>
		/// Gets or sets PayeeDependantsOnly
		/// </summary>

		[EnumValue("PayeeDependantsOnly", typeof(EmployeeResx))]
		PayeeDependantsOnly = 5
	}
}
