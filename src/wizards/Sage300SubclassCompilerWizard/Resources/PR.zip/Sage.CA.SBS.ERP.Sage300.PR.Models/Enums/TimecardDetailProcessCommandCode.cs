﻿// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommandCode
    /// </summary>
    public enum TimecardDetailProcessCommandCode
    {
        /// <summary>
        /// Gets or sets ProcessCostCenters
        /// </summary>
        [EnumValue("ProcessCostCenters", typeof(TimecardDetailResx))]
        ProcessCostCenters = 0,
        /// <summary>
        /// Gets or sets InsertOptionalFields
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(TimecardDetailResx))]
        InsertOptionalFields = 1,
        /// <summary>
        /// Gets or sets UpdateInfoToMatchJobs
        /// </summary>
        [EnumValue("UpdateInfoToMatchJobs", typeof(TimecardDetailResx))]
        UpdateInfoToMatchJobs = 2,
        /// <summary>
        /// Gets or sets ClearOTOverrideFields
        /// </summary>
        [EnumValue("ClearOTOverrideFields", typeof(TimecardDetailResx))]
        ClearOTOverrideFields = 3,
        /// <summary>
        /// Gets or sets ClearJobs
        /// </summary>
        [EnumValue("ClearJobs", typeof(TimecardDetailResx))]
        ClearJobs = 4,
    }
}
