// Copyright (c) 1994-2024 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for BankIDQualifier
    /// </summary>
    public enum BankIDQualifier
    {
        /// <summary>
        /// Gets or sets Num01NACHANationalClearingSystemNumber
        /// </summary>
        [EnumValue("Num01NACHANationalClearingSystemNumber", typeof(EmployeeResx))]
        Num01NACHANationalClearingSystemNumber = 1,
        /// <summary>
        /// Gets or sets Num02BICBankIdentificationNumber
        /// </summary>
        [EnumValue("Num02BICBankIdentificationNumber", typeof(EmployeeResx))]
        Num02BICBankIdentificationNumber = 2,
        /// <summary>
        /// Gets or sets Num03IBANInternationalBankAccountNumber
        /// </summary>
        [EnumValue("Num03IBANInternationalBankAccountNumber", typeof(EmployeeResx))]
        Num03IBANInternationalBankAccountNumber = 3
    }
}