// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ProcessAction
    /// </summary>
    public enum ProcessAction
    {
        /// <summary>
        /// Gets or sets CalculateEarningAndHours
        /// </summary>
        [EnumValue("CalculateEarningAndHours", typeof(EmployeeActivityResx))]
        CalculateEarningAndHours = 1,

        /// <summary>
        /// Gets or sets CalculatePayrollRegisterTotal
        /// </summary>
        [EnumValue("CalculatePayrollRegisterTotal", typeof(EmployeeActivityResx))]
        CalculatePayrollRegisterTotal = 2,

        /// <summary>
        /// Gets or sets CalculatePayrollRegisterTotalOneCheck
        /// </summary>
        [EnumValue("CalculatePayrollRegisterTotalOneCheck", typeof(EmployeeActivityResx))]
        CalculatePayrollRegisterTotalOneCheck = 3,
        
    }
}