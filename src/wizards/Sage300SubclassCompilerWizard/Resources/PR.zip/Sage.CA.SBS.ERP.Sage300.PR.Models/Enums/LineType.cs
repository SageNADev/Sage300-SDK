// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for LineType
    /// </summary>
    public enum LineType
    {
        /// <summary>
        /// Gets or sets Payment
        /// </summary>
        [EnumValue("Payment", typeof(CheckJobsOptionalFieldsValueResx))]
        Payment = 1,
        /// <summary>
        /// Gets or sets Accrual
        /// </summary>
        [EnumValue("Accrual", typeof(CheckJobsOptionalFieldsValueResx))]
        Accrual = 2,
        /// <summary>
        /// Gets or sets Regular
        /// </summary>
        [EnumValue("Regular", typeof(CheckJobsOptionalFieldsValueResx))]
        Regular = 3,
        /// <summary>
        /// Gets or sets Overtime
        /// </summary>
        [EnumValue("Overtime", typeof(CheckJobsOptionalFieldsValueResx))]
        Overtime = 4,
        /// <summary>
        /// Gets or sets ShiftDifferential
        /// </summary>
        [EnumValue("ShiftDifferential", typeof(CheckJobsOptionalFieldsValueResx))]
        ShiftDifferential = 5,
        /// <summary>
        /// Gets or sets na
        /// </summary>
        [EnumValue("na", typeof(CheckJobsOptionalFieldsValueResx))]
        na = 6,
        /// <summary>
        /// Gets or sets NormalWithholding
        /// </summary>
        [EnumValue("NormalWithholding", typeof(CheckJobsOptionalFieldsValueResx))]
        NormalWithholding = 7,
        /// <summary>
        /// Gets or sets BackupWithholding
        /// </summary>
        [EnumValue("BackupWithholding", typeof(CheckJobsOptionalFieldsValueResx))]
        BackupWithholding = 8,
        /// <summary>
        /// Gets or sets SupplementalWithholding
        /// </summary>
        [EnumValue("SupplementalWithholding", typeof(CheckJobsOptionalFieldsValueResx))]
        SupplementalWithholding = 9
    }
}