// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for PrintCategory
    /// </summary>
    public enum PrintCategory
    {
        /// <summary>
        /// Gets or sets CHKEEFTEntries
        /// </summary>
        [EnumValue("CHKEEFTEntries", typeof(CheckEFTDetailResx))]
        CHKEEFTEntries = 6
    }
}