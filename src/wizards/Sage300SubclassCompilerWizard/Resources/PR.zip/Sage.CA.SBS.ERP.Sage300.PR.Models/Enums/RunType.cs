﻿
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	public enum RunType
	{
		/// <summary>
		/// Gets or sets AllChecks
		/// </summary>

		[EnumValue("AllChecks", typeof(PayrollChecksResx))]
		AllChecks = 1,

		/// <summary>
		/// Gets or sets EFTChecksOnly
		/// </summary>

		[EnumValue("EFTChecksOnly", typeof(PayrollChecksResx))]
		EFTChecksOnly = 2,

		/// <summary>
		/// Gets or sets EFTChecksOnly
		/// </summary>

		[EnumValue("NonEFTChecksOnly", typeof(PayrollChecksResx))]
		NonEFTChecksOnly = 3,


	}

	public enum RunTypeCP
	{
		/// <summary>
		/// Gets or sets AllCheques
		/// </summary>

		[EnumValue("AllCheques", typeof(PayrollChecksResx))]
		AllCheques = 1,

		/// <summary>
		/// Gets or sets EFTChequesOnly
		/// </summary>

		[EnumValue("EFTChequesOnly", typeof(PayrollChecksResx))]
		EFTChequesOnly = 2,

		/// <summary>
		/// Gets or sets EFTChecksOnly
		/// </summary>

		[EnumValue("NonEFTChequessOnly", typeof(PayrollChecksResx))]
		NonEFTChequessOnly = 3,


	}
}
