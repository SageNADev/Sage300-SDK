// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for ProcessCommandCode
	/// </summary>
	public enum ProcessCommandCode
	{
		/// <summary>
		/// Gets or sets NoAction
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		NoAction = 0,

		/// <summary>
		/// Gets or sets InsertOptionalFields
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		InsertOptionalFields = 1,

		/// <summary>
		/// Gets or sets UpdateInfoToMatchJobs
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		UpdateInfoToMatchJobs = 2,
	
		/// <summary>
		/// Gets or sets CalculatePayroll
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		CalculatePayroll = 3
	}
}
