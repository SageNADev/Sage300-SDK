﻿
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	public enum EFTType
	{
		/// <summary>
		/// Gets or sets Orignal
		/// </summary>

		[EnumValue("DirectDepositEFT", typeof(GenerateEFTFileResx))]
		DirectDepositEFT = 1,

		/// <summary>
		/// Gets or sets ChildSupportEFT
		/// </summary>

		[EnumValue("ChildSupportEFT", typeof(GenerateEFTFileResx))]
		ChildSupportEFT = 2,
	}
	
}
