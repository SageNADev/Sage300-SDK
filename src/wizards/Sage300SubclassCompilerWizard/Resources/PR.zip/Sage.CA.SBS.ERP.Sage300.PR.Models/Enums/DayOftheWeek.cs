// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for DayOftheWeek
	/// </summary>
	public enum DayOftheWeek
	{
		/// <summary>
		/// Gets or sets Sunday
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		Sunday = 1,

		/// <summary>
		/// Gets or sets Monday
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		Monday = 2,

		/// <summary>
		/// Gets or sets Tuesday
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		Tuesday = 3,

		/// <summary>
		/// Gets or sets Wednesday
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		Wednesday = 4,

		/// <summary>
		/// Gets or sets Thursday
		/// </summary>

		[EnumValue("Generated", typeof(CommonResx))]
		Thursday = 5,

		/// <summary>
		/// Gets or sets Friday
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		Friday = 6,

		/// <summary>
		/// Gets or sets Saturday
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		Saturday = 7
	}
}
