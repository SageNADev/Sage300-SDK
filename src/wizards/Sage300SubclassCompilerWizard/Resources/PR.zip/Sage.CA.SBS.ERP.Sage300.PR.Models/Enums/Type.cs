// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Type
    /// </summary>
    public enum Type
    {
        /// <summary>
        /// Gets or sets Text
        /// </summary>
        [EnumValue("Text", typeof(EnumerationsResx))]
        Text = 1,
        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [EnumValue("Amount", typeof(EnumerationsResx))]
        Amount = 100,
        /// <summary>
        /// Gets or sets Number
        /// </summary>
        [EnumValue("Number", typeof(EnumerationsResx))]
        Number = 6,
        /// <summary>
        /// Gets or sets Integer
        /// </summary>
        [EnumValue("Integer", typeof(EnumerationsResx))]
        Integer = 8,
        /// <summary>
        /// Gets or sets YesNo
        /// </summary>
        [EnumValue("YesNo", typeof(EnumerationsResx))]
        YesNo = 9,
        /// <summary>
        /// Gets or sets Date
        /// </summary>
        [EnumValue("Date", typeof(EnumerationsResx))]
        Date = 3,
        /// <summary>
        /// Gets or sets Time
        /// </summary>
        [EnumValue("Time", typeof(EnumerationsResx))]
        Time = 4
    }
}