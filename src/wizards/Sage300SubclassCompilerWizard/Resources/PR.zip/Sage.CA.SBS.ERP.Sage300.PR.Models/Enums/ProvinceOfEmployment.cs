// Copyright (c) 2022-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for StateOfHire
	/// </summary>
	public enum StateOfHire
	{
		/// <summary>
		/// Gets or sets Alberta
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		Alberta = 1,

		/// <summary>
		/// Gets or sets BritishColumbia
		/// </summary>

		[EnumValue("Generated", typeof(CommonResx))]
		BritishColumbia = 2,

		/// <summary>
		/// Gets or sets Manitoba
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		Manitoba = 3,

		/// <summary>
		/// Gets or sets NewBrunswick
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		NewBrunswick = 4,

		/// <summary>
		/// Gets or sets NewfoundlandLabrador
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		NewfoundlandLabrador = 5,

		/// <summary>
		/// Gets or sets NorthwestTerritories
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		NorthwestTerritories = 6,

		/// <summary>
		/// Gets or sets NovaScotia
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		NovaScotia = 7,

		/// <summary>
		/// Gets or sets Ontario
		/// </summary>

		[EnumValue("Generated", typeof(CommonResx))]
		Ontario = 8,

		/// <summary>
		/// Gets or sets OutsideCanada
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		OutsideCanada = 9,

		/// <summary>
		/// Gets or sets PrinceEdwardIsland
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		PrinceEdwardIsland = 10,

		/// <summary>
		/// Gets or sets Quebec
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		Quebec = 11,

		/// <summary>
		/// Gets or sets Saskatchewan
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		Saskatchewan = 12,

		/// <summary>
		/// Gets or sets YukonTerritory
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		YukonTerritory = 13,

		/// <summary>
		/// Gets or sets Nunavut
		/// </summary>
	
		[EnumValue("Generated", typeof(CommonResx))]
		Nunavut = 14
	}
}
