// Copyright (c) 2022-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for StateOfHire
	/// </summary>
	public enum StateOfHire
	{
		/// <summary>
		/// Gets or sets None (blank)
		/// </summary>

		[EnumValue("None", typeof(EmployeeResx))]
		None = 0,

		/// <summary>
		/// Gets or sets Alberta
		/// </summary>
		
		[EnumValue("Alberta", typeof(EmployeeResx))]
		Alberta = 1,

		/// <summary>
		/// Gets or sets BritishColumbia
		/// </summary>

		[EnumValue("BritishColumbia", typeof(EmployeeResx))]
		BritishColumbia = 2,

		/// <summary>
		/// Gets or sets Manitoba
		/// </summary>
		
		[EnumValue("Manitoba", typeof(EmployeeResx))]
		Manitoba = 3,

		/// <summary>
		/// Gets or sets NewBrunswick
		/// </summary>
	
		[EnumValue("NewBrunswick", typeof(EmployeeResx))]
		NewBrunswick = 4,

		/// <summary>
		/// Gets or sets NewfoundlandLabrador
		/// </summary>
		
		[EnumValue("NewfoundlandLabrador", typeof(EmployeeResx))]
		NewfoundlandLabrador = 5,

		/// <summary>
		/// Gets or sets NorthwestTerritories
		/// </summary>
	
		[EnumValue("NorthwestTerritories", typeof(EmployeeResx))]
		NorthwestTerritories = 6,

		/// <summary>
		/// Gets or sets NovaScotia
		/// </summary>
		
		[EnumValue("NovaScotia", typeof(EmployeeResx))]
		NovaScotia = 7,

		/// <summary>
		/// Gets or sets Ontario
		/// </summary>

		[EnumValue("Ontario", typeof(EmployeeResx))]
		Ontario = 8,

		/// <summary>
		/// Gets or sets OutsideCanada
		/// </summary>
	
		[EnumValue("OutsideCanada", typeof(EmployeeResx))]
		OutsideCanada = 9,

		/// <summary>
		/// Gets or sets PrinceEdwardIsland
		/// </summary>
		
		[EnumValue("PrinceEdwardIsland", typeof(EmployeeResx))]
		PrinceEdwardIsland = 10,

		/// <summary>
		/// Gets or sets Quebec
		/// </summary>
	
		[EnumValue("Quebec", typeof(EmployeeResx))]
		Quebec = 11,

		/// <summary>
		/// Gets or sets Saskatchewan
		/// </summary>
		
		[EnumValue("Saskatchewan", typeof(EmployeeResx))]
		Saskatchewan = 12,

		/// <summary>
		/// Gets or sets YukonTerritory
		/// </summary>
		
		[EnumValue("YukonTerritory", typeof(EmployeeResx))]
		YukonTerritory = 13,

		/// <summary>
		/// Gets or sets Nunavut
		/// </summary>
	
		[EnumValue("Nunavut", typeof(EmployeeResx))]
		Nunavut = 14
	}
}
