﻿/* Copyright (c) 2023-2024 The Sage Group plc or its licensors.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	public enum ClassCodes
	{
		/// <summary>
		/// Gets or sets Class1
		/// </summary>

		[EnumValue("Class1", typeof(PayrollChecksResx))]
		Class1 = 1,

		/// <summary>
		/// Gets or sets Class2
		/// </summary>

		[EnumValue("Class2", typeof(PayrollChecksResx))]
		Class2 = 2,

		/// <summary>
		/// Gets or sets Class3
		/// </summary>

		[EnumValue("Class3", typeof(PayrollChecksResx))]
		Class3 = 3,

		/// <summary>
		/// Gets or sets Class4
		/// </summary>
		[EnumValue("Class4", typeof(PayrollChecksResx))]
		Class4 = 4
	}
}
