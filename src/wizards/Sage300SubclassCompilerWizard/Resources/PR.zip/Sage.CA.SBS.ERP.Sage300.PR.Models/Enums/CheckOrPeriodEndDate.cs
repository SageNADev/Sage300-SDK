// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for CheckOrPeriodEndDate
    /// </summary>
    public enum CheckOrPeriodEndDate
    {
        /// <summary>
        /// Gets or sets UseCheckDateAsJournalEntryDate
        /// </summary>
        [EnumValue("UseCheckDateAsJournalEntryDate", typeof(CompanyOptionResx))]
        UseCheckDateAsJournalEntryDate = 1,
        /// <summary>
        /// Gets or sets UsePayPeriodEndDateAsJournalEntryDate
        /// </summary>
        [EnumValue("UsePayPeriodEndDateAsJournalEntryDate", typeof(CompanyOptionResx))]
        UsePayPeriodEndDateAsJournalEntryDate = 2
    }
}