// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for GLTransAppendToBatch
    /// </summary>
    public enum GLTransAppendToBatch
    {
        /// <summary>
        /// Gets or sets AddingToAnExistingBatch
        /// </summary>
        [EnumValue("AddingToAnExistingBatch", typeof(CompanyOptionResx))]
        AddingToAnExistingBatch = 1,
        /// <summary>
        /// Gets or sets CreatingANewBatch
        /// </summary>
        [EnumValue("CreatingANewBatch", typeof(CompanyOptionResx))]
        CreatingANewBatch = 0,
        /// <summary>
        /// Gets or sets CreatingAndPostingANewBatch
        /// </summary>
        [EnumValue("CreatingAndPostingANewBatch", typeof(CompanyOptionResx))]
        CreatingAndPostingANewBatch = 2
    }
}