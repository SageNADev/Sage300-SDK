// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for RESERVEDCDNOnly
    /// </summary>
    public enum RESERVEDCDNOnly
    {
        /// <summary>
        /// Gets or sets Num028OtherIncome
        /// </summary>
        [EnumValue("Num028OtherIncome", typeof(EarningsDeductionResx))]
        Num028OtherIncome = 1,
        /// <summary>
        /// Gets or sets Num104ResearchGrants
        /// </summary>
        [EnumValue("Num104ResearchGrants", typeof(EarningsDeductionResx))]
        Num104ResearchGrants = 2,
        /// <summary>
        /// Gets or sets Num105ScholarshipsBursariesFellowships
        /// </summary>
        [EnumValue("Num105ScholarshipsBursariesFellowships", typeof(EarningsDeductionResx))]
        Num105ScholarshipsBursariesFellowships = 3,
        /// <summary>
        /// Gets or sets Num130ApprenticeshipIncentiveGrantOr
        /// </summary>
        [EnumValue("Num130ApprenticeshipIncentiveGrantOr", typeof(EarningsDeductionResx))]
        Num130ApprenticeshipIncentiveGrantOr = 4
    }
}
