// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for PrintLineType
    /// </summary>
    public enum PrintLineType
    {
        /// <summary>
        /// Gets or sets CHKEEFTEntryFixedAmount
        /// </summary>
        [EnumValue("CHKEEFTEntryFixedAmount", typeof(CheckEFTDetailResx))]
        CHKEEFTEntryFixedAmount = 91,
        /// <summary>
        /// Gets or sets CHKEEFTEntryOfGrossEarnings
        /// </summary>
        [EnumValue("CHKEEFTEntryOfGrossEarnings", typeof(CheckEFTDetailResx))]
        CHKEEFTEntryOfGrossEarnings = 92,
        /// <summary>
        /// Gets or sets CHKEEFTEntryOfNetPay
        /// </summary>
        [EnumValue("CHKEEFTEntryOfNetPay", typeof(CheckEFTDetailResx))]
        CHKEEFTEntryOfNetPay = 93
    }
}