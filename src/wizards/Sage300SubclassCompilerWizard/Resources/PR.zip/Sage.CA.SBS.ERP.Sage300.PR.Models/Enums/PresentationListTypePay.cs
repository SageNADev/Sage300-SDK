// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for PresentationListTypePay
    /// </summary>
    public enum PresentationListTypePay
    {
        /// <summary>
        /// Gets or sets na
        /// </summary>
        [EnumValue("na", typeof(CheckEFTDetailResx))]
        na = 6
    }
}