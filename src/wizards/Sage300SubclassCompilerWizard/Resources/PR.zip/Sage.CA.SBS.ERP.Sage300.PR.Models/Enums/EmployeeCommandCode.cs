// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommandCode
    /// </summary>
    public enum EmployeeCommandCode
    {
        /// <summary>
        /// Gets or sets InitializeNewRecord
        /// </summary>
        [EnumValue("InitializeNewRecord", typeof(EarningsDeductionResx))]
        InitializeNewRecord = 0,
        /// <summary>
        /// Gets or sets InsertOptionalFields
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(EarningsDeductionResx))]
        InsertOptionalFields = 1,
        /// <summary>
        /// Gets or sets CheckForTimecardAndManualChecks
        /// </summary>
        [EnumValue("CheckForTimecardAndManualChecks", typeof(EarningsDeductionResx))]
        CheckForTimecardAndManualChecks = 2,
        /// <summary>
        /// Gets or sets SetAttributes
        /// </summary>
        [EnumValue("SetAttributes", typeof(EarningsDeductionResx))]
        SetAttributes = 3
    }
}
