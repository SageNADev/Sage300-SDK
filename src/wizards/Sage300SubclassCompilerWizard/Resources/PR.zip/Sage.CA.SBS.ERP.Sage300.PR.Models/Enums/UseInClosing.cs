﻿/* Copyright (c) 1994-2024 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Use In Closing
    /// </summary>
    public enum UseInClosing
    {
        /// <summary>
        /// The no
        /// </summary>
        [EnumValue("UseInClosing_No", typeof (EmployeeSelectionListResx))] No = 0,

        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("UseInClosing_Yes", typeof (EmployeeSelectionListResx))] Yes = 1
    }
}