// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for EmployeeLimit
    /// </summary>
    public enum EmployeeLimit
    {
        /// <summary>
        /// Gets or sets NoLimit
        /// </summary>
        [EnumValue("NoLimit", typeof(CompanyPayrollTaxeResx))]
        NoLimit = 1,
        /// <summary>
        /// Gets or sets Withholding
        /// </summary>
        [EnumValue("Withholding", typeof(CompanyPayrollTaxeResx))]
        Withholding = 4,
        /// <summary>
        /// Gets or sets Base
        /// </summary>
        [EnumValue("Base", typeof(CompanyPayrollTaxeResx))]
        Base = 5
    }
}
