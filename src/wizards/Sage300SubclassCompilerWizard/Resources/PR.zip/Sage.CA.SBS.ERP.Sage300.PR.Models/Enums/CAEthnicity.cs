// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for CAEthnicity
    /// </summary>
    public enum CAEthnicity
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(EmployeeResx))]
        None = 0,
        /// <summary>
        /// Gets or sets A10HispanicLatinoMale
        /// </summary>
        [EnumValue("A10HispanicLatinoMale", typeof(EmployeeResx))]
        A10HispanicLatinoMale = 1,
        /// <summary>
        /// Gets or sets A20HispanicLatinoFemale
        /// </summary>
        [EnumValue("A20HispanicLatinoFemale", typeof(EmployeeResx))]
        A20HispanicLatinoFemale = 2,
        /// <summary>
        /// Gets or sets A30HispanicLatinoNonBinary
        /// </summary>
        [EnumValue("A30HispanicLatinoNonBinary", typeof(EmployeeResx))]
        A30HispanicLatinoNonBinary = 3,
        /// <summary>
        /// Gets or sets B10NonHispanicNonLatinoMaleWhite
        /// </summary>
        [EnumValue("B10NonHispanicNonLatinoMaleWhite", typeof(EmployeeResx))]
        B10NonHispanicNonLatinoMaleWhite = 4,
        /// <summary>
        /// Gets or sets B20NonHispanicNonLatinoMaleBlackOrAfricanAmerican
        /// </summary>
        [EnumValue("B20NonHispanicNonLatinoMaleBlackOrAfricanAmerican", typeof(EmployeeResx))]
        B20NonHispanicNonLatinoMaleBlackOrAfricanAmerican = 5,
        /// <summary>
        /// Gets or sets B30NonHispanicNonLatinoMaleNativeHawaiianOrOtherPacificIslander
        /// </summary>
        [EnumValue("B30NonHispanicNonLatinoMaleNativeHawaiianOrOtherPacificIslander", typeof(EmployeeResx))]
        B30NonHispanicNonLatinoMaleNativeHawaiianOrOtherPacificIslander = 6,
        /// <summary>
        /// Gets or sets B40NonHispanicNonLatinoMaleAsian
        /// </summary>
        [EnumValue("B40NonHispanicNonLatinoMaleAsian", typeof(EmployeeResx))]
        B40NonHispanicNonLatinoMaleAsian = 7,
        /// <summary>
        /// Gets or sets B50NonHispanicNonLatinoMaleAmericanIndianOrAlaskanNative
        /// </summary>
        [EnumValue("B50NonHispanicNonLatinoMaleAmericanIndianOrAlaskanNative", typeof(EmployeeResx))]
        B50NonHispanicNonLatinoMaleAmericanIndianOrAlaskanNative = 8,
        /// <summary>
        /// Gets or sets B60NonHispanicNonLatinoMaleTwoOrMoreRaces
        /// </summary>
        [EnumValue("B60NonHispanicNonLatinoMaleTwoOrMoreRaces", typeof(EmployeeResx))]
        B60NonHispanicNonLatinoMaleTwoOrMoreRaces = 9,
        /// <summary>
        /// Gets or sets C10NonHispanicNonLatinoFemaleWhite
        /// </summary>
        [EnumValue("C10NonHispanicNonLatinoFemaleWhite", typeof(EmployeeResx))]
        C10NonHispanicNonLatinoFemaleWhite = 10,
        /// <summary>
        /// Gets or sets C20NonHispanicNonLatinoFemaleBlackOrAfricanAmerican
        /// </summary>
        [EnumValue("C20NonHispanicNonLatinoFemaleBlackOrAfricanAmerican", typeof(EmployeeResx))]
        C20NonHispanicNonLatinoFemaleBlackOrAfricanAmerican = 11,
        /// <summary>
        /// Gets or sets C30NonHispanicNonLatinoFemaleNativeHawaiianOrOtherPacificIslander
        /// </summary>
        [EnumValue("C30NonHispanicNonLatinoFemaleNativeHawaiianOrOtherPacificIslander", typeof(EmployeeResx))]
        C30NonHispanicNonLatinoFemaleNativeHawaiianOrOtherPacificIslander = 12,
        /// <summary>
        /// Gets or sets C40NonHispanicNonLatinoFemaleAsian
        /// </summary>
        [EnumValue("C40NonHispanicNonLatinoFemaleAsian", typeof(EmployeeResx))]
        C40NonHispanicNonLatinoFemaleAsian = 13,
        /// <summary>
        /// Gets or sets C50NonHispanicNonLatinoFemaleAmericanIndianOrAlaskanNative
        /// </summary>
        [EnumValue("C50NonHispanicNonLatinoFemaleAmericanIndianOrAlaskanNative", typeof(EmployeeResx))]
        C50NonHispanicNonLatinoFemaleAmericanIndianOrAlaskanNative = 14,
        /// <summary>
        /// Gets or sets C60NonHispanicNonLatinoFemaleTwoOrMoreRaces
        /// </summary>
        [EnumValue("C60NonHispanicNonLatinoFemaleTwoOrMoreRaces", typeof(EmployeeResx))]
        C60NonHispanicNonLatinoFemaleTwoOrMoreRaces = 15,
        /// <summary>
        /// Gets or sets D10NonHispanicNonLatinoNonBinaryWhite
        /// </summary>
        [EnumValue("D10NonHispanicNonLatinoNonBinaryWhite", typeof(EmployeeResx))]
        D10NonHispanicNonLatinoNonBinaryWhite = 16,
        /// <summary>
        /// Gets or sets D20NonHispanicNonLatinoNonBinaryBlackOrAfricanAmerican
        /// </summary>
        [EnumValue("D20NonHispanicNonLatinoNonBinaryBlackOrAfricanAmerican", typeof(EmployeeResx))]
        D20NonHispanicNonLatinoNonBinaryBlackOrAfricanAmerican = 17,
        /// <summary>
        /// Gets or sets D30NonHispanicNonLatinoNonBinaryNativeHawaiianOrOtherPacificIslander
        /// </summary>
        [EnumValue("D30NonHispanicNonLatinoNonBinaryNativeHawaiianOrOtherPacificIslander", typeof(EmployeeResx))]
        D30NonHispanicNonLatinoNonBinaryNativeHawaiianOrOtherPacificIslander = 18,
        /// <summary>
        /// Gets or sets D40NonHispanicNonLatinoNonBinaryAsian
        /// </summary>
        [EnumValue("D40NonHispanicNonLatinoNonBinaryAsian", typeof(EmployeeResx))]
        D40NonHispanicNonLatinoNonBinaryAsian = 19,
        /// <summary>
        /// Gets or sets D50NonHispanicNonLatinoNonBinaryAmericanIndianOrAlaskanNative
        /// </summary>
        [EnumValue("D50NonHispanicNonLatinoNonBinaryAmericanIndianOrAlaskanNative", typeof(EmployeeResx))]
        D50NonHispanicNonLatinoNonBinaryAmericanIndianOrAlaskanNative = 20,
        /// <summary>
        /// Gets or sets D60NonHispanicNonLatinoNonBinaryTwoOrMoreRaces
        /// </summary>
        [EnumValue("D60NonHispanicNonLatinoNonBinaryTwoOrMoreRaces", typeof(EmployeeResx))]
        D60NonHispanicNonLatinoNonBinaryTwoOrMoreRaces = 21
    }
}
