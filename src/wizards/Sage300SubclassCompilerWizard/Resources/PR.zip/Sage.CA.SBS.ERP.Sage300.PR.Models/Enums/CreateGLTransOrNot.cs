// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for CreateGLTransOrNot
    /// </summary>
    public enum CreateGLTransOrNot
    {
        /// <summary>
        /// Gets or sets DuringPosting
        /// </summary>
        [EnumValue("DuringPosting", typeof(CompanyOptionResx))]
        DuringPosting = 1,
        /// <summary>
        /// Gets or sets OnRequestUsingCreateGLBatchIcon
        /// </summary>
        [EnumValue("OnRequestUsingCreateGLBatchIcon", typeof(CompanyOptionResx))]
        OnRequestUsingCreateGLBatchIcon = 2
    }
}