﻿// Copyright (c) 2024 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.Common.Models.Enums
{
    /// <summary>
    /// Enum for Class
    /// </summary>
    public enum Class
    {
        /// <summary>
        /// Gets or sets Class1
        /// </summary>
        [EnumValue("Class1", typeof(EmployeeSelectionListResx))]
        Class1 = 1,

        /// <summary>
        /// Gets or sets Class2 
        /// </summary>
        [EnumValue("Class2", typeof(EmployeeSelectionListResx))]
        Class2 = 2,

        /// <summary>
        /// Gets or sets Class3 
        /// </summary>
        [EnumValue("Class3", typeof(EmployeeSelectionListResx))]
        Class3 = 3,

        /// <summary>
        /// Gets or sets Class4 
        /// </summary>
        [EnumValue("Class4", typeof(EmployeeSelectionListResx))]
        Class4 = 4
    }
}
