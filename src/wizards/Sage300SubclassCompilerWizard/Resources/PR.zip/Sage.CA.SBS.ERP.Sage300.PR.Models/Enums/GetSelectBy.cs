﻿// Copyright (c) 2024 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.Common.Models.Enums
{
    /// <summary>
    /// Enum for GetSelectBy
    /// </summary>
    public enum GetSelectBy
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(EmployeeSelectionListResx))]
        None = 0,
        /// <summary>
        /// Gets or sets EmployeeNumber
        /// </summary>
        [EnumValue("EmployeeNumber", typeof(EmployeeSelectionListResx))]
        EmployeeNumber = 1,
        /// <summary>
        /// Gets or sets EmployeeLastName
        /// </summary>
        [EnumValue("EmployeeLastName", typeof(EmployeeSelectionListResx))]
        EmployeeLastName = 2,
        /// <summary>
        /// Gets or sets Class
        /// </summary>
        [EnumValue("Class", typeof(EmployeeSelectionListResx))]
        Class = 3,
        /// <summary>
        /// Gets or sets State
        /// </summary>
        [EnumValue("State", typeof(EmployeeSelectionListResx))]
        State = 4,
        /// <summary>
        /// Gets or sets WorkClassification
        /// </summary>
        [EnumValue("WorkClassification", typeof(EmployeeSelectionListResx))]
        WorkClassification = 6,
        /// <summary>
        /// Gets or sets ShiftDifferential
        /// </summary>
        [EnumValue("ShiftDifferential", typeof(EmployeeSelectionListResx))]
        ShiftDifferential = 7,
        /// <summary>
        /// Gets or sets OvertimeSchedule
        /// </summary>
        [EnumValue("OvertimeSchedule", typeof(EmployeeSelectionListResx))]
        OvertimeSchedule = 8,
        /// <summary>
        /// Gets or sets WCCGroup
        /// </summary>
        [EnumValue("WCCGroup", typeof(EmployeeSelectionListResx))]
        WCCGroup = 9,
        /// <summary>
        /// Gets or sets IncludeEarningOrDeduction
        /// </summary>
        [EnumValue("IncludeEarningOrDeduction", typeof(EmployeeSelectionListResx))]
        IncludeEarningOrDeduction = 10,
        /// <summary>
        /// Gets or sets ExcludeEarningOrDeduction
        /// </summary>
        [EnumValue("ExcludeEarningOrDeduction", typeof(EmployeeSelectionListResx))]
        ExcludeEarningOrDeduction = 11,
        /// <summary>
        /// Gets or sets IncludeTax
        /// </summary>
        [EnumValue("IncludeTax", typeof(EmployeeSelectionListResx))]
        IncludeTax = 12,
        /// <summary>
        /// Gets or sets ExcludeTax
        /// </summary>
        [EnumValue("ExcludeTax", typeof(EmployeeSelectionListResx))]
        ExcludeTax = 13,
    }
}
