﻿#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for TimecardType 
	/// </summary>
	public enum TimecardType
	{
		/// <summary>
		/// Gets or sets AllTimecards 
		/// </summary>
		[EnumValue("AllTimecards", typeof(TimecardHeaderResx))]
		AllTimecards = 1,
		/// <summary>
		/// Gets or sets ReusableTimecards 
		/// </summary>	
		[EnumValue("ReusableTimecards", typeof(TimecardHeaderResx))]
		ReusableTimecards = 2,
		/// <summary>
		/// Gets or sets NonReusableTimecards 
		/// </summary>	
		[EnumValue("NonReusableTimecards", typeof(TimecardHeaderResx))]
		NonReusableTimecards = 3
	}
}
