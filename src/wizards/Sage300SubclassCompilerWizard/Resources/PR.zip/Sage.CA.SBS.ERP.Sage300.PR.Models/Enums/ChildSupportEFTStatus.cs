// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ChildSupportEFTStatus
    /// </summary>
    public enum ChildSupportEFTStatus
    {
        /// <summary>
        /// Gets or sets NotEfted
        /// </summary>
        [EnumValue("NotEfted", typeof(CheckDetailResx))]
        NotEfted = 0,
        /// <summary>
        /// Gets or sets EFTed
        /// </summary>
        [EnumValue("EFTed", typeof(CheckDetailResx))]
        EFTed = 1
    }
}