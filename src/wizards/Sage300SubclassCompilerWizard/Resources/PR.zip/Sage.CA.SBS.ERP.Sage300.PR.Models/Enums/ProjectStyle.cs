// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ProjectStyle
    /// </summary>
    public enum ProjectStyle
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(TimecardJobDetailResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Standard
        /// </summary>
        [EnumValue("Standard", typeof(TimecardJobDetailResx))]
        Standard = 1,
        /// <summary>
        /// Gets or sets Basic
        /// </summary>
        [EnumValue("Basic", typeof(TimecardJobDetailResx))]
        Basic = 2
    }
}