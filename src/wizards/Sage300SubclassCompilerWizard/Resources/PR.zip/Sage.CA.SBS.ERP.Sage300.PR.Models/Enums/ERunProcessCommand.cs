﻿// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for ProcessCommandCode
	/// </summary>
	public enum ERunProcessCommand
	{
		/// <summary>
		/// Gets or sets NoAction
		/// </summary>

		[EnumValue("Generated", typeof(CommonResx))]
		GenerateFile = 0,

		/// <summary>
		/// Gets or sets InsertOptionalFields
		/// </summary>

		[EnumValue("Generated", typeof(CommonResx))]
		CheckFileExistence = 1,
	}
}
