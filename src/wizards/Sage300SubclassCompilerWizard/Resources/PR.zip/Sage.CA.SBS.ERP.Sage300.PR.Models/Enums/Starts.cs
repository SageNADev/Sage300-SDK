// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Starts
    /// </summary>
    public enum Starts
    {
        /// <summary>
        /// Gets or sets SpecificMonthDay
        /// </summary>
        [EnumValue("SpecificMonthDay", typeof(EarningsDeductionResx))]
        SpecificMonthDay = 1,
        /// <summary>
        /// Gets or sets DateOfHire
        /// </summary>
        [EnumValue("DateOfHire", typeof(EarningsDeductionResx))]
        DateOfHire = 2,
        /// <summary>
        /// Gets or sets MonthsAfterHire
        /// </summary>
        [EnumValue("MonthsAfterHire", typeof(EarningsDeductionResx))]
        MonthsAfterHire = 3,
        /// <summary>
        /// Gets or sets DaysAfterHire
        /// </summary>
        [EnumValue("DaysAfterHire", typeof(EarningsDeductionResx))]
        DaysAfterHire = 4
    }
}
