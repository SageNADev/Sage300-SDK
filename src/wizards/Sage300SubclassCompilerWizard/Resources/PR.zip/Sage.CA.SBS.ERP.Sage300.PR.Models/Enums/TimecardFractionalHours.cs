// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for TimecardFractionalHours
    /// </summary>
    public enum TimecardFractionalHours
    {
        /// <summary>
        /// Gets or sets Minutes
        /// </summary>
        [EnumValue("Minutes", typeof(CompanyOptionResx))]
        Minutes = 1,
        /// <summary>
        /// Gets or sets HundredthsOfAnHour
        /// </summary>
        [EnumValue("HundredthsOfAnHour", typeof(CompanyOptionResx))]
        HundredthsOfAnHour = 2
    }
}