// Copyright (c) 2023-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for WithholdingMethod
    /// </summary>
    public enum WithholdingMethod
    {
        /// <summary>
        /// Gets or sets StandardCalculation
        /// </summary>
        [EnumValue("StandardCalculation", typeof(EmployeeTaxInfoResx))]
        StandardCalculation = 1,
        /// <summary>
        /// Gets or sets AmountOverride
        /// </summary>
        [EnumValue("AmountOverride", typeof(EmployeeTaxInfoResx))]
        AmountOverride = 2,
        /// <summary>
        /// Gets or sets PercentOverride
        /// </summary>
        [EnumValue("PercentOverride", typeof(EmployeeTaxInfoResx))]
        PercentOverride = 3,
        /// <summary>
        /// Gets or sets TaxableNoWithholding
        /// </summary>
        [EnumValue("TaxableNoWithholding", typeof(EmployeeTaxInfoResx))]
        TaxableNoWithholding = 4,
        /// <summary>
        /// Gets or sets CalculationBaseOnly
        /// </summary>
        [EnumValue("CalculationBaseOnly", typeof(EmployeeTaxInfoResx))]
        CalculationBaseOnly = 7
    }
}
