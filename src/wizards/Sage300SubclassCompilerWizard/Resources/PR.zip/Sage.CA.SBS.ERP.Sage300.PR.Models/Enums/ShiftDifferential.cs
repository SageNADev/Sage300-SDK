﻿// Copyright (c) 2024 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.Common.Models.Enums
{
    /// <summary>
    /// Enum for ShiftDifferential
    /// </summary>
    public enum ShiftDifferential
    {
        /// <summary>
        /// Gets or sets ShiftDifferential1
        /// </summary>
        [EnumValue("ShiftDifferential1", typeof(EmployeeSelectionListResx))]
        ShiftDifferential1 = 1,

        /// <summary>
        /// Gets or sets ShiftDifferential2 
        /// </summary>
        [EnumValue("ShiftDifferential2", typeof(EmployeeSelectionListResx))]
        ShiftDifferential2 = 2,

        /// <summary>
        /// Gets or sets ShiftDifferential3 
        /// </summary>
        [EnumValue("ShiftDifferential3", typeof(EmployeeSelectionListResx))]
        ShiftDifferential3 = 3,

        /// <summary>
        /// Gets or sets ShiftDifferential4 
        /// </summary>
        [EnumValue("ShiftDifferential4", typeof(EmployeeSelectionListResx))]
        ShiftDifferential4 = 4
    }
}
