﻿/* Copyright (c) 1994-2024 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Optional Field Location
    /// </summary>
    public enum OptionalFieldLocation
    {
        /// <summary>
        /// The Optional Field Employee
        /// </summary>
        [EnumValue("OptionalFieldLocation_Employee", typeof (EnumerationsResx))] Employee = 1,
        /// <summary>
        ///The Optional Field Employee taxes
        /// </summary>
        [EnumValue("OptionalFieldLocation_EmployeeTaxes", typeof(EnumerationsResx))] EmployeeTaxes = 5,
        /// <summary>
        ///The Optional Field Employee earning or deduction
        /// </summary>
        [EnumValue("OptionalFieldLocation_EmployeeEarnOrDed", typeof(EnumerationsResx))] EmployeeEarnOrDed = 4

    }
}