﻿/* Copyright (c) 2023-2024 The Sage Group plc or its licensors.  All rights reserved. */
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	public enum DetailLevel
	{
		/// <summary>
		/// Gets or sets EarningsOrDeductionsInFullDetail
		/// </summary>

		[EnumValue("EarnOrDedInFullDetail", typeof(PayrollChecksResx))]
		EarnOrDedInFullDetail = 1,

		/// <summary>
		/// Gets or sets EmployeeName
		/// </summary>

		[EnumValue("EarnOrDedSummarizedByTypeAndRate", typeof(PayrollChecksResx))]
		EarnOrDedSummarizedByTypeAndRate = 2,


	}
}
