// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for OvertimeCalculation
	/// </summary>
	public enum OvertimeCalculation
	{
		/// <summary>
		/// Gets or sets HourlyRate
		/// </summary>
	
		[EnumValue("HourlyRate", typeof(EmployeeResx))]
		HourlyRate = 0,

		/// <summary>
		/// Gets or sets MinimumWage
		/// </summary>
	
		[EnumValue("MinimumWage", typeof(EmployeeResx))]
		MinimumWage = 1,

		/// <summary>
		/// Gets or sets ShiftRate
		/// </summary>
		
		[EnumValue("ShiftRate", typeof(EmployeeResx))]
		ShiftRate = 2,

		/// <summary>
		/// Gets or sets RegularRateHourly
		/// </summary>
	
		[EnumValue("RegularRateHourly", typeof(EmployeeResx))]
		RegularRateHourly = 3,

		/// <summary>
		/// Gets or sets RegularRateSalaryFixedHours
		/// </summary>

		[EnumValue("RegularRateSalaryFixedHours", typeof(EmployeeResx))]
		RegularRateSalaryFixedHours = 4,

		/// <summary>
		/// Gets or sets RegularRateSalaryFluctuatingHours
		/// </summary>

		[EnumValue("RegularRateSalaryFluctuatingHours", typeof(EmployeeResx))]
		RegularRateSalaryFluctuatingHours = 5
	}
}
