// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for Gender
	/// </summary>
	public enum Gender
	{
		/// <summary>
		/// Gets or sets 
		/// </summary>

		[EnumValue("Blank", typeof(EmployeeResx))]
		Blank = 1,

		/// <summary>
		/// Gets or sets Male
		/// </summary>
	
		[EnumValue("Male", typeof(EmployeeResx))]
		Male = 2,

		/// <summary>
		/// Gets or sets Female
		/// </summary>
		
		[EnumValue("Female", typeof(EmployeeResx))]
		Female = 3,

		/// <summary>
		/// Gets or sets Nonbinary
		/// </summary>

		[EnumValue("Nonbinary", typeof(EmployeeResx))]
		NonBinary = 4
	}
}
