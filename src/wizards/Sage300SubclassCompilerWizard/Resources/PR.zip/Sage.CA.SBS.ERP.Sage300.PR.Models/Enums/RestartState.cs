﻿// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for CheckStatus
    /// </summary>
    public enum RestartState
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(PayrollChecksResx))]
        None = 0,
        /// <summary>
        /// Gets or sets GenerateBankCheckRegister
        /// </summary>
        [EnumValue("GenerateBankCheckRegister", typeof(PayrollChecksResx))]
        GenerateBankCheckRegister = 1,
        /// <summary>
        /// Gets or sets PrintCheck
        /// </summary>
        [EnumValue("PrintCheck", typeof(PayrollChecksResx))]
        PrintCheck = 2,
        /// <summary>
        /// Gets or sets UpdateStatus
        /// </summary>
        [EnumValue("UpdateStatus", typeof(PayrollChecksResx))]
        UpdateStatus = 3,
        
    }
}