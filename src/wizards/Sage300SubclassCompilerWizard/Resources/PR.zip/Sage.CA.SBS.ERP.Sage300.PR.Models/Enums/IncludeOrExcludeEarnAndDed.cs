﻿// Copyright (c) 2024 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.Common.Models.Enums
{
    /// <summary>
    /// Enum for IncludeOrExcludeEarnAndDed
    /// </summary>
    public enum IncludeOrExcludeEarnAndDed
    {
        /// <summary>
        /// Gets or sets Accrual
        /// </summary>
        [EnumValue("Accrual", typeof(EmployeeSelectionListResx))]
        Accrual = 1,

        /// <summary>
        /// Gets or sets Earning
        /// </summary>
        [EnumValue("Earning", typeof(EmployeeSelectionListResx))]
        Earning = 2,

        /// <summary>
        /// Gets or sets Advance
        /// </summary>
        [EnumValue("Advance", typeof(EmployeeSelectionListResx))]
        Advance = 3,

        /// <summary>
        /// Gets or sets Deduction
        /// </summary>
        [EnumValue("Deduction", typeof(EmployeeSelectionListResx))]
        Deduction = 4,

        /// <summary>
        /// Gets or sets ExpenseReimbusement
        /// </summary>
        [EnumValue("ExpenseReimbursement", typeof(EmployeeSelectionListResx))]
        ExpenseReimbursement = 5,

        /// <summary>
        /// Gets or sets Benefit
        /// </summary>
        [EnumValue("Benefit", typeof(EmployeeSelectionListResx))]
        Benefit = 6
    }
}
