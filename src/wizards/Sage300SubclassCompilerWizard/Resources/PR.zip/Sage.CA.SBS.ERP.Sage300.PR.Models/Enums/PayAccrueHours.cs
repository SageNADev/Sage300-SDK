// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for PayAccrueHours
    /// </summary>
    public enum PayAccrueHours
    {
        /// <summary>
        /// Gets or sets Payment
        /// </summary>
        [EnumValue("Payment", typeof(TimecardDetailResx))]
        Payment = 1,
        /// <summary>
        /// Gets or sets Accrual
        /// </summary>
        [EnumValue("Accrual", typeof(TimecardDetailResx))]
        Accrual = 2,
        /// <summary>
        /// Gets or sets na
        /// </summary>
        [EnumValue("na", typeof(TimecardDetailResx))]
        na = 6
    }
}