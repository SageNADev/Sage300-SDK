// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for EmployeeBaseLimit
    /// </summary>
    public enum EmployeeBaseLimit
    {
        /// <summary>
        /// Gets or sets NoLimit
        /// </summary>
        [EnumValue("NoLimit", typeof(EarningsDeductionResx))]
        NoLimit = 1
    }
}
