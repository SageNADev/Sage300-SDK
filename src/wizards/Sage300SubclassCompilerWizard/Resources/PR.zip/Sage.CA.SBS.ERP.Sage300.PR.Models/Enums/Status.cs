// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models; 
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Status
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// Gets or sets New
        /// </summary>
        [EnumValue("New", typeof(EmployeeTimecardResx))]
        New = 0,
        /// <summary>
        /// Gets or sets ReadyForApproval
        /// </summary>
        [EnumValue("ReadyForApproval", typeof(EmployeeTimecardResx))]
        ReadyForApproval = 1,
        /// <summary>
        /// Gets or sets Reviewed
        /// </summary>
        [EnumValue("Reviewed", typeof(EmployeeTimecardResx))]
        Reviewed = 3,
        /// <summary>
        /// Gets or sets Approved
        /// </summary>
        [EnumValue("Approved", typeof(EmployeeTimecardResx))]
        Approved = 2
    }
}