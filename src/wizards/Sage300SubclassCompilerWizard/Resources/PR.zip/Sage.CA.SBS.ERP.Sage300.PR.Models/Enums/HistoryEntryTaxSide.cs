// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for HistoryEntryTaxSide
    /// </summary>
    public enum HistoryEntryTaxSide
    {
        /// <summary>
        /// Gets or sets NotApplicable
        /// </summary>
        [EnumValue("NotApplicable", typeof(CheckDetailResx))]
        NotApplicable = 0,
        /// <summary>
        /// Gets or sets EmployerTax
        /// </summary>
        [EnumValue("EmployerTax", typeof(CheckDetailResx))]
        EmployerTax = 1,
        /// <summary>
        /// Gets or sets EmployeeTax
        /// </summary>
        [EnumValue("EmployeeTax", typeof(CheckDetailResx))]
        EmployeeTax = 2,
        /// <summary>
        /// Gets or sets EmployeeAndEmployerTax
        /// </summary>
        [EnumValue("EmployeeAndEmployerTax", typeof(CheckDetailResx))]
        EmployeeAndEmployerTax = 3
    }
}