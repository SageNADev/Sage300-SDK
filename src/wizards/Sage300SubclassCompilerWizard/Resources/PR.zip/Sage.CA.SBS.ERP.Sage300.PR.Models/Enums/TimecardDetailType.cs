﻿// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Type
    /// </summary>
    public enum TimecardDetailType
    {
        /// <summary>
        /// Gets or sets SalaryAndWages
        /// </summary>
        [EnumValue("SalaryWages", typeof(TimecardDetailResx))]
        SalaryAndWages = 1,
        /// <summary>
        /// Gets or sets ReportedTips
        /// </summary>
        [EnumValue("ReportedTips", typeof(TimecardDetailResx))]
        ReportedTips = 2,
        /// <summary>
        /// Gets or sets AllocatedTips
        /// </summary>
        [EnumValue("AllocatedTips", typeof(TimecardDetailResx))]
        AllocatedTips = 3,
        /// <summary>
        /// Gets or sets Vacation
        /// </summary>
        [EnumValue("Vacation", typeof(TimecardDetailResx))]
        Vacation = 7,
        /// <summary>
        /// Gets or sets Sick
        /// </summary>
        [EnumValue("Sick", typeof(TimecardDetailResx))]
        Sick = 8,
        /// <summary>
        /// Gets or sets CompensatoryTime
        /// </summary>
        [EnumValue("CompensatoryTime", typeof(TimecardDetailResx))]
        CompensatoryTime = 9,
        /// <summary>
        /// Gets or sets Cash
        /// </summary>
        [EnumValue("Cash", typeof(TimecardDetailResx))]
        Cash = 13,
        /// <summary>
        /// Gets or sets Noncash
        /// </summary>
        [EnumValue("Noncash", typeof(TimecardDetailResx))]
        Noncash = 14,
        /// <summary>
        /// Gets or sets InsuranceTax
        /// </summary>
        [EnumValue("InsuranceTax", typeof(TimecardDetailResx))]
        InsuranceTax = 18,
        /// <summary>
        /// Gets or sets IncomeTax
        /// </summary>
        [EnumValue("IncomeTax", typeof(TimecardDetailResx))]
        IncomeTax = 19,
        /// <summary>
        /// Gets or sets UnemploymentTax
        /// </summary>
        [EnumValue("UnemploymentTax", typeof(TimecardDetailResx))]
        UnemploymentTax = 20,
        /// <summary>
        /// Gets or sets PensionPlanTax
        /// </summary>
        [EnumValue("PensionPlanTax", typeof(TimecardDetailResx))]
        PensionPlanTax = 21,
        /// <summary>
        /// Gets or sets HealthTax
        /// </summary>
        [EnumValue("HealthTax", typeof(TimecardDetailResx))]
        HealthTax = 22,
        /// <summary>
        /// Gets or sets OtherTax
        /// </summary>
        [EnumValue("OtherTax", typeof(TimecardDetailResx))]
        OtherTax = 23,
        /// <summary>
        /// Gets or sets na
        /// </summary>
        [EnumValue("na", typeof(TimecardDetailResx))]
        NA = 25,
    }
}
