// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ProjectType
    /// </summary>
    public enum ProjectType
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(TimecardJobDetailResx))]
        None = 0,
        /// <summary>
        /// Gets or sets TimeAndMaterials
        /// </summary>
        [EnumValue("TimeAndMaterials", typeof(TimecardJobDetailResx))]
        TimeAndMaterials = 1,
        /// <summary>
        /// Gets or sets FixedPrice
        /// </summary>
        [EnumValue("FixedPrice", typeof(TimecardJobDetailResx))]
        FixedPrice = 2,
        /// <summary>
        /// Gets or sets CostPlus
        /// </summary>
        [EnumValue("CostPlus", typeof(TimecardJobDetailResx))]
        CostPlus = 3
    }
}