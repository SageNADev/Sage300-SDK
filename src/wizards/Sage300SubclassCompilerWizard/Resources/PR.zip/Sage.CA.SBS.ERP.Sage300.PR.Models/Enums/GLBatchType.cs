// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for GLBatchType
    /// </summary>
    public enum GLBatchType
    {
        /// <summary>
        /// Gets or sets DoNotConsolidate
        /// </summary>
        [EnumValue("DoNotConsolidate", typeof(CompanyOptionResx))]
        DoNotConsolidate = 1,
        /// <summary>
        /// Gets or sets ConsolidateByAcctFiscalPeriod
        /// </summary>
        [EnumValue("ConsolidateByAcctFiscalPeriod", typeof(CompanyOptionResx))]
        ConsolidateByAcctFiscalPeriod = 2,
        /// <summary>
        /// Gets or sets ConsolidateByAcctFiscalPeriodAndSourceCode
        /// </summary>
        [EnumValue("ConsolidateByAcctFiscalPeriodAndSourceCode", typeof(CompanyOptionResx))]
        ConsolidateByAcctFiscalPeriodAndSourceCode = 3
    }
}