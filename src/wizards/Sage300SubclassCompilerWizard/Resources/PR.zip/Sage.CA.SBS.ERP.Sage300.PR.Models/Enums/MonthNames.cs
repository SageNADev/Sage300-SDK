// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Month
    /// </summary>
    public enum MonthNames
    {
        /// <summary>
        /// Gets or sets January
        /// </summary>
        [EnumValue("January", typeof(EmployeeActivityResx))]
        January = 1,
        /// <summary>
        /// Gets or sets January
        /// </summary>
        [EnumValue("February", typeof(EmployeeActivityResx))]
        February = 2,
        /// <summary>
        /// Gets or sets March
        /// </summary>
        [EnumValue("March", typeof(EmployeeActivityResx))]
        March = 3,
        /// <summary>
        /// Gets or sets April
        /// </summary>
        [EnumValue("April", typeof(EmployeeActivityResx))]
        April = 4,
        /// <summary>
        /// Gets or sets May
        /// </summary>
        [EnumValue("May", typeof(EmployeeActivityResx))]
        May = 5,
        /// <summary>
        /// Gets or sets June
        /// </summary>
        [EnumValue("June", typeof(EmployeeActivityResx))]
        June = 6,
        /// <summary>
        /// Gets or sets July
        /// </summary>
        [EnumValue("July", typeof(EmployeeActivityResx))]
        July = 7,
        /// <summary>
        /// Gets or sets August
        /// </summary>
        [EnumValue("August", typeof(EmployeeActivityResx))]
        August = 8,
        /// <summary>
        /// Gets or sets September
        /// </summary>
        [EnumValue("September", typeof(EmployeeActivityResx))]
        September = 9,
        /// <summary>
        /// Gets or sets October
        /// </summary>
        [EnumValue("October", typeof(EmployeeActivityResx))]
        October = 10,
        /// <summary>
        /// Gets or sets November
        /// </summary>
        [EnumValue("November", typeof(EmployeeActivityResx))]
        November = 11,
        /// <summary>
        /// Gets or sets December
        /// </summary>
        [EnumValue("December", typeof(EmployeeActivityResx))]
        December = 12,
    }
}