// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for W2BoxType
    /// </summary>
    public enum W2BoxType
    {
        /// <summary>
        /// Gets or sets NotApplicable
        /// </summary>
        [EnumValue("NotApplicable", typeof(CompanyPayrollTaxeResx))]
        NotApplicable = 1,
        /// <summary>
        /// Gets or sets OtherInformationBox
        /// </summary>
        [EnumValue("OtherInformationBox", typeof(CompanyPayrollTaxeResx))]
        OtherInformationBox = 2,
        /// <summary>
        /// Gets or sets CombineWithAnotherTax
        /// </summary>
        [EnumValue("CombineWithAnotherTax", typeof(CompanyPayrollTaxeResx))]
        CombineWithAnotherTax = 3,
        /// <summary>
        /// Gets or sets LocalTaxBox
        /// </summary>
        [EnumValue("LocalTaxBox", typeof(CompanyPayrollTaxeResx))]
        LocalTaxBox = 4,
        /// <summary>
        /// Gets or sets SuppressW2Reporting
        /// </summary>
        [EnumValue("SuppressW2Reporting", typeof(CompanyPayrollTaxeResx))]
        SuppressW2Reporting = 5
    }
}
