// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for EFTStatus
    /// </summary>
    public enum EFTStatus
    {
        /// <summary>
        /// Gets or sets Prenotification
        /// </summary>
        [EnumValue("Prenotification", typeof(EmployeeGarnishmentResx))]
        Prenotification = 0,
        /// <summary>
        /// Gets or sets Deposit
        /// </summary>
        [EnumValue("Deposit", typeof(EmployeeGarnishmentResx))]
        Deposit = 1,
        /// <summary>
        /// Gets or sets Inactive
        /// </summary>
        [EnumValue("Inactive", typeof(EmployeeGarnishmentResx))]
        Inactive = 2
    }
}