// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for WhatToGloballyModify
    /// </summary>
    public enum WhatToGloballyModify
    {
        /// <summary>
        /// Gets or sets EarningsDeductions
        /// </summary>
        [EnumValue("Generated", typeof(CommonResx))]
        EarningsDeductions = 0,
        /// <summary>
        /// Gets or sets Taxes
        /// </summary>
        [EnumValue("Generated", typeof(CommonResx))]
        Taxes = 1,
        /// <summary>
        /// Gets or sets AddEarningsDeductions
        /// </summary>
        [EnumValue("Generated", typeof(CommonResx))]
        AddEarningsDeductions = 2,
        /// <summary>
        /// Gets or sets AddTax
        /// </summary>
        [EnumValue("Generated", typeof(CommonResx))]
        AddTax = 3
    }
}