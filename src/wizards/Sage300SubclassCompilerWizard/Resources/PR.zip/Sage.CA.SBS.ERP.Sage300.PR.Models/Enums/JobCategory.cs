// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for JobCategory
    /// </summary>
    public enum JobCategory
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(EmployeeResx))]
        None = 0,
        /// <summary>
        /// Gets or sets ExecutiveSeniorLevelOfficialsAndManagers
        /// </summary>
        [EnumValue("ExecutiveSeniorLevelOfficialsAndManagers", typeof(EmployeeResx))]
        ExecutiveSeniorLevelOfficialsAndManagers = 1,
        /// <summary>
        /// Gets or sets FirstMidLevelOfficialsAndManagers
        /// </summary>
        [EnumValue("FirstMidLevelOfficialsAndManagers", typeof(EmployeeResx))]
        FirstMidLevelOfficialsAndManagers = 2,
        /// <summary>
        /// Gets or sets Professionals
        /// </summary>
        [EnumValue("Professionals", typeof(EmployeeResx))]
        Professionals = 3,
        /// <summary>
        /// Gets or sets Technicians
        /// </summary>
        [EnumValue("Technicians", typeof(EmployeeResx))]
        Technicians = 4,
        /// <summary>
        /// Gets or sets SalesWorkers
        /// </summary>
        [EnumValue("SalesWorkers", typeof(EmployeeResx))]
        SalesWorkers = 5,
        /// <summary>
        /// Gets or sets AdministrativeSupportWorkers
        /// </summary>
        [EnumValue("AdministrativeSupportWorkers", typeof(EmployeeResx))]
        AdministrativeSupportWorkers = 6,
        /// <summary>
        /// Gets or sets CraftWorkers
        /// </summary>
        [EnumValue("CraftWorkers", typeof(EmployeeResx))]
        CraftWorkers = 7,
        /// <summary>
        /// Gets or sets Operatives
        /// </summary>
        [EnumValue("Operatives", typeof(EmployeeResx))]
        Operatives = 8,
        /// <summary>
        /// Gets or sets LaborersAndHelpers
        /// </summary>
        [EnumValue("LaborersAndHelpers", typeof(EmployeeResx))]
        LaborersAndHelpers = 9,
        /// <summary>
        /// Gets or sets ServiceWorkers
        /// </summary>
        [EnumValue("ServiceWorkers", typeof(EmployeeResx))]
        ServiceWorkers = 10
    }
}
