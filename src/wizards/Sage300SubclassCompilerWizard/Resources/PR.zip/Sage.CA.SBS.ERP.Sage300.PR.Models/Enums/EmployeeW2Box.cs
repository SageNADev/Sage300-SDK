// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for EmployeeW2Box
    /// </summary>
    public enum EmployeeW2Box
    {
        /// <summary>
        /// Gets or sets NotApplicable
        /// </summary>
        [EnumValue("NotApplicable", typeof(EarningsDeductionResx))]
        NotApplicable = 1,
        /// <summary>
        /// Gets or sets OtherInformationBox
        /// </summary>
        [EnumValue("OtherInformationBox", typeof(EarningsDeductionResx))]
        OtherInformationBox = 2,
        /// <summary>
        /// Gets or sets DependentCare
        /// </summary>
        [EnumValue("DependentCare", typeof(EarningsDeductionResx))]
        DependentCare = 3,
        /// <summary>
        /// Gets or sets Employee401K
        /// </summary>
        [EnumValue("Employee401K", typeof(EarningsDeductionResx))]
        Employee401K = 4,
        /// <summary>
        /// Gets or sets Employee403B
        /// </summary>
        [EnumValue("Employee403B", typeof(EarningsDeductionResx))]
        Employee403B = 5,
        /// <summary>
        /// Gets or sets Employee408K6
        /// </summary>
        [EnumValue("Employee408K6", typeof(EarningsDeductionResx))]
        Employee408K6 = 6,
        /// <summary>
        /// Gets or sets Employee457
        /// </summary>
        [EnumValue("Employee457", typeof(EarningsDeductionResx))]
        Employee457 = 7,
        /// <summary>
        /// Gets or sets Employee501C18D
        /// </summary>
        [EnumValue("Employee501C18D", typeof(EarningsDeductionResx))]
        Employee501C18D = 8,
        /// <summary>
        /// Gets or sets SIMPLERetirementAcct
        /// </summary>
        [EnumValue("SIMPLERetirementAcct", typeof(EarningsDeductionResx))]
        SIMPLERetirementAcct = 9,
        /// <summary>
        /// Gets or sets DeferralsUnderSection409A
        /// </summary>
        [EnumValue("DeferralsUnderSection409A", typeof(EarningsDeductionResx))]
        DeferralsUnderSection409A = 10,
        /// <summary>
        /// Gets or sets RothContributionsToEmployee401K
        /// </summary>
        [EnumValue("RothContributionsToEmployee401K", typeof(EarningsDeductionResx))]
        RothContributionsToEmployee401K = 11,
        /// <summary>
        /// Gets or sets RothContributionsToEmployee403B
        /// </summary>
        [EnumValue("RothContributionsToEmployee403B", typeof(EarningsDeductionResx))]
        RothContributionsToEmployee403B = 12,
        /// <summary>
        /// Gets or sets HealthSavingsAccount
        /// </summary>
        [EnumValue("HealthSavingsAccount", typeof(EarningsDeductionResx))]
        HealthSavingsAccount = 13,
        /// <summary>
        /// Gets or sets EmployerProvidedHealthCare
        /// </summary>
        [EnumValue("EmployerProvidedHealthCare", typeof(EarningsDeductionResx))]
        EmployerProvidedHealthCare = 14,
        /// <summary>
        /// Gets or sets RothContributionsUnderGovernmental457B
        /// </summary>
        [EnumValue("RothContributionsUnderGovernmental457B", typeof(EarningsDeductionResx))]
        RothContributionsUnderGovernmental457B = 15
    }
}
