// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for Category
	/// </summary>
	public enum Category
	{
		/// <summary>
		/// Gets or sets Hours
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		Hours = 0,

		/// <summary>
		/// Gets or sets Tips
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		Tips = 1,

		/// <summary>
		/// Gets or sets Expense
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		Expense = 2,

		/// <summary>
		/// Gets or sets PieceRate
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		PieceRate = 3,

		/// <summary>
		/// Gets or sets SalesCommissions
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		SalesCommissions = 4,

		/// <summary>
		/// Gets or sets SickAccrualPayment
		/// </summary>
		
		[EnumValue("Generated", typeof(CommonResx))]
		SickAccrualPayment = 5,

		/// <summary>
		/// Gets or sets VacationAccrualPayment
		
		[EnumValue("Generated", typeof(CommonResx))]
		VacationAccrualPayment = 6
	}
}
