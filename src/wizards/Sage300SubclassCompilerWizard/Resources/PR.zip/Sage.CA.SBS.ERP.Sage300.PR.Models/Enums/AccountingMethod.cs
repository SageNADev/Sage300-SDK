// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for AccountingMethod
    /// </summary>
    public enum AccountingMethod
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(TimecardJobDetailResx))]
        None = 0,
        /// <summary>
        /// Gets or sets CompletedProject
        /// </summary>
        [EnumValue("CompletedProject", typeof(TimecardJobDetailResx))]
        CompletedProject = 1,
        /// <summary>
        /// Gets or sets TotalCostPercentageComplete
        /// </summary>
        [EnumValue("TotalCostPercentageComplete", typeof(TimecardJobDetailResx))]
        TotalCostPercentageComplete = 2,
        /// <summary>
        /// Gets or sets LaborHoursPercentageComplete
        /// </summary>
        [EnumValue("LaborHoursPercentageComplete", typeof(TimecardJobDetailResx))]
        LaborHoursPercentageComplete = 3,
        /// <summary>
        /// Gets or sets BillingsAndCosts
        /// </summary>
        [EnumValue("BillingsAndCosts", typeof(TimecardJobDetailResx))]
        BillingsAndCosts = 4,
        /// <summary>
        /// Gets or sets ProjectPercentageComplete
        /// </summary>
        [EnumValue("ProjectPercentageComplete", typeof(TimecardJobDetailResx))]
        ProjectPercentageComplete = 5,
        /// <summary>
        /// Gets or sets CategoryPercentageComplete
        /// </summary>
        [EnumValue("CategoryPercentageComplete", typeof(TimecardJobDetailResx))]
        CategoryPercentageComplete = 6,
        /// <summary>
        /// Gets or sets CompletedContract
        /// </summary>
        [EnumValue("CompletedContract", typeof(TimecardJobDetailResx))]
        CompletedContract = 7,
        /// <summary>
        /// Gets or sets AccrualBasis
        /// </summary>
        [EnumValue("AccrualBasis", typeof(TimecardJobDetailResx))]
        AccrualBasis = 8
    }
}