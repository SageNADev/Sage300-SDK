// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for CheckStatus
    /// </summary>
    public enum CheckStatus
    {
        /// <summary>
        /// Gets or sets Align
        /// </summary>
        [EnumValue("Align", typeof(CheckHeaderResx))]
        Align = 1,
        /// <summary>
        /// Gets or sets Void
        /// </summary>
        [EnumValue("Void", typeof(CheckHeaderResx))]
        Void = 2,
        /// <summary>
        /// Gets or sets Outstanding
        /// </summary>
        [EnumValue("Outstanding", typeof(CheckHeaderResx))]
        Outstanding = 3,
        /// <summary>
        /// Gets or sets Reversed
        /// </summary>
        [EnumValue("Reversed", typeof(CheckHeaderResx))]
        Reversed = 4,
        /// <summary>
        /// Gets or sets Cleared
        /// </summary>
        [EnumValue("Cleared", typeof(CheckHeaderResx))]
        Cleared = 5,
        /// <summary>
        /// Gets or sets ClearedWithError
        /// </summary>
        [EnumValue("ClearedWithError", typeof(CheckHeaderResx))]
        ClearedWithError = 6,
        /// <summary>
        /// Gets or sets Nonnegotiable
        /// </summary>
        [EnumValue("Nonnegotiable", typeof(CheckHeaderResx))]
        Nonnegotiable = 7,
        /// <summary>
        /// Gets or sets Continuation
        /// </summary>
        [EnumValue("Continuation", typeof(CheckHeaderResx))]
        Continuation = 8
    }
}