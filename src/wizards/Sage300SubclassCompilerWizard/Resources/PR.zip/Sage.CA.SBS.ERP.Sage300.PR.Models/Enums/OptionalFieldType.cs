// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for TYPE
    /// </summary>
    public enum OptionalFieldType
    {
        /// <summary>
        /// Gets or sets Text
        /// </summary>
        [EnumValue("Text", typeof(CheckJobsOptionalFieldsValueResx))]
        Text = 1,
        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [EnumValue("Amount", typeof(CheckJobsOptionalFieldsValueResx))]
        Amount = 100,
        /// <summary>
        /// Gets or sets Number
        /// </summary>
        [EnumValue("Number", typeof(CheckJobsOptionalFieldsValueResx))]
        Number = 6,
        /// <summary>
        /// Gets or sets Integer
        /// </summary>
        [EnumValue("Integer", typeof(CheckJobsOptionalFieldsValueResx))]
        Integer = 8,
        /// <summary>
        /// Gets or sets YesNo
        /// </summary>
        [EnumValue("YesNo", typeof(CheckJobsOptionalFieldsValueResx))]
        YesNo = 9,
        /// <summary>
        /// Gets or sets Date
        /// </summary>
        [EnumValue("Date", typeof(CheckJobsOptionalFieldsValueResx))]
        Date = 3,
        /// <summary>
        /// Gets or sets Time
        /// </summary>
        [EnumValue("Time", typeof(CheckJobsOptionalFieldsValueResx))]
        Time = 4
    }
}