﻿#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for CheckType 
	/// </summary>
	public enum CheckType
	{
		/// <summary>
		/// Gets or sets Check 
		/// </summary>	
		Check = 1,
		/// <summary>
		/// Gets or sets EFT 
		/// </summary>	
		EFT = 2,
	}
}
