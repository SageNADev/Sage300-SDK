// Copyright (c) 2022-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for EmployeeElectronicW2Consent
	/// </summary>
	public enum EmployeeElectronicW2Consent
	{
		/// <summary>
		/// Gets or sets No
		/// </summary>
	
		[EnumValue("No", typeof(CommonResx))]
		No = 0,

		/// <summary>
		/// Gets or sets Yes
		/// </summary>
	
		[EnumValue("Yes", typeof(CommonResx))]
		Yes = 1
	}
}
