// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms; 

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ProcessControlCode
    /// </summary>
    public enum ProcessControlCode
    {
        /// <summary>
        /// Gets or sets NoAction
        /// </summary>
        [EnumValue("NoAction", typeof(EmployeeTimecardResx))]
        NoAction = 0,
        /// <summary>
        /// Gets or sets InsertDefaultDetails
        /// </summary>
        [EnumValue("InsertDefaultDetails", typeof(EmployeeTimecardResx))]
        InsertDefaultDetails = 1,
        /// <summary>
        /// Gets or sets InsertOptionalFields
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(EmployeeTimecardResx))]
        InsertOptionalFields = 2
    }
}