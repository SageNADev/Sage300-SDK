// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for PrintLineContents
    /// </summary>
    public enum PrintLineContents
    {
        /// <summary>
        /// Gets or sets CHKDEmployeeOnly
        /// </summary>
        [EnumValue("CHKDEmployeeOnly", typeof(CheckEFTDetailResx))]
        CHKDEmployeeOnly = 1
    }
}