// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Frequency
    /// </summary>
    public enum Frequency
    {
        /// <summary>
        /// Gets or sets Float
        /// </summary>
        [EnumValue("Float", typeof(EarningsDeductionResx))]
        Float = 1,
        /// <summary>
        /// Gets or sets Daily
        /// </summary>
        [EnumValue("Daily", typeof(EarningsDeductionResx))]
        Daily = 2,
        /// <summary>
        /// Gets or sets Weekly
        /// </summary>
        [EnumValue("Weekly", typeof(EarningsDeductionResx))]
        Weekly = 3,
        /// <summary>
        /// Gets or sets Biweekly
        /// </summary>
        [EnumValue("Biweekly", typeof(EarningsDeductionResx))]
        Biweekly = 4,
        /// <summary>
        /// Gets or sets Semimonthly
        /// </summary>
        [EnumValue("Semimonthly", typeof(EarningsDeductionResx))]
        Semimonthly = 5,
        /// <summary>
        /// Gets or sets TwentyTwoPerYear
        /// </summary>
        [EnumValue("TwentyTwoPerYear", typeof(EarningsDeductionResx))]
        TwentyTwoPerYear = 10,
        /// <summary>
        /// Gets or sets ThirteenPerYear
        /// </summary>
        [EnumValue("ThirteenPerYear", typeof(EarningsDeductionResx))]
        ThirteenPerYear = 9,
        /// <summary>
        /// Gets or sets Monthly
        /// </summary>
        [EnumValue("Monthly", typeof(EarningsDeductionResx))]
        Monthly = 6,
        /// <summary>
        /// Gets or sets TenPerYear
        /// </summary>
        [EnumValue("TenPerYear", typeof(EarningsDeductionResx))]
        TenPerYear = 8,
        /// <summary>
        /// Gets or sets Quarterly
        /// </summary>
        [EnumValue("Quarterly", typeof(EarningsDeductionResx))]
        Quarterly = 7
    }
}
