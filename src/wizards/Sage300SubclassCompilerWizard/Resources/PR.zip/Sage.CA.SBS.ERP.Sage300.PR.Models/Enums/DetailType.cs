// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for DetailType
    /// </summary>
    public enum DetailType
    {
        /// <summary>
        /// Gets or sets EarningDeduction
        /// </summary>
        [EnumValue("EarningDeduction", typeof(CheckDetailResx))]
        EarningDeduction = 1,
        /// <summary>
        /// Gets or sets Tax
        /// </summary>
        [EnumValue("Tax", typeof(CheckDetailResx))]
        Tax = 2
    }
}