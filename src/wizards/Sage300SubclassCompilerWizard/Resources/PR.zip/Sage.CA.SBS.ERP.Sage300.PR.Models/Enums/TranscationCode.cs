// Copyright (c) 1994-2024 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms; 

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for TranscationCode
    /// </summary>
    public enum TranscationCode
    {
        /// <summary>
        /// Gets or sets Num22Checking
        /// </summary>
        [EnumValue("Num22Checking", typeof(EmployeeResx))]
        Num22Checking = 22,
        /// <summary>
        /// Gets or sets Num32Savings
        /// </summary>
        [EnumValue("Num32Savings", typeof(EmployeeResx))]
        Num32Savings = 32
    }
}