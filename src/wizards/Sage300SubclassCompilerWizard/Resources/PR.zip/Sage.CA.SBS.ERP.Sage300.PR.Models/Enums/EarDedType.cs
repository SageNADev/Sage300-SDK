// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for EarDedType
    /// </summary>
    public enum EarDedType
    {
        /// <summary>
        /// Gets or sets SalaryAndWages
        /// </summary>
        [EnumValue("SalaryAndWages", typeof(EmployeeResx))]
        SalaryAndWages = 1,
        /// <summary>
        /// Gets or sets ReportedTips
        /// </summary>
        [EnumValue("ReportedTips", typeof(EmployeeResx))]
        ReportedTips = 2,
        /// <summary>
        /// Gets or sets AllocatedTips
        /// </summary>
        [EnumValue("AllocatedTips", typeof(EmployeeResx))]
        AllocatedTips = 3,
        /// Gets or sets Vacation
        /// </summary>
        [EnumValue("Vacation", typeof(EmployeeResx))]
        Vacation = 7,
        /// Gets or sets Sick
        /// </summary>
        [EnumValue("Sick", typeof(EmployeeResx))]
        Sick = 8,
        /// Gets or sets CompensationTime
        /// </summary>
        [EnumValue("CompensationTime", typeof(EmployeeResx))]
        CompensationTime = 9,
        /// Gets or sets Disability
        /// </summary>
        [EnumValue("Disability", typeof(EmployeeResx))]
        Disability = 10,
        /// Gets or sets Cash
        /// </summary>
        [EnumValue("Cash", typeof(EmployeeResx))]
        Cash = 13,
        /// Gets or sets NonCash
        /// </summary>
        [EnumValue(" NonCash", typeof(EmployeeResx))]
        NonCash = 14,
        /// Gets or sets InsuranceTax
        /// </summary>
        [EnumValue("InsuranceTax", typeof(EmployeeResx))]
        InsuranceTax = 18,
        /// Gets or sets IncomeTax
        /// </summary>
        [EnumValue("IncomeTax", typeof(EmployeeResx))]
        IncomeTax = 19,
        /// Gets or sets UnemploymentTax
        /// </summary>
        [EnumValue("UnemploymentTax", typeof(EmployeeResx))]
        UnemploymentTax = 20,
        /// Gets or sets PensionPlanTax
        /// </summary>
        [EnumValue("PensionPlanTax", typeof(EmployeeResx))]
        PensionPlanTax = 21,
        /// Gets or sets HealthTax
        /// </summary>
        [EnumValue("HealthTax", typeof(EmployeeResx))]
        HealthTax = 22,
        /// Gets or sets OtherTax
        /// </summary>
        [EnumValue("OtherTax", typeof(EmployeeResx))]
        OtherTax = 23,
        /// Gets or sets NotApply
        /// </summary>
        [EnumValue("NotApply", typeof(EmployeeResx))]
        NotApply = 25
    }
}