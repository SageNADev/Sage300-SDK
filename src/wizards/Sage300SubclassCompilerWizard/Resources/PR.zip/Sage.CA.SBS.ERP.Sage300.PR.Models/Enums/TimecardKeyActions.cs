﻿// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    public enum TimecardKeyActions
    {
        /// <summary>
        /// Gets or sets Start New Timecard
        /// </summary>
        StartNewTimecard = 1,
        /// <summary>
        /// Gets or sets Start New Timecard Copy Details
        /// </summary>
        StartNewTimecardCopyDetails = 2,
        /// <summary>
        /// Gets or sets Change Current Timecard
        /// </summary>
        ChangeCurrentTimecard = 3
    }

}