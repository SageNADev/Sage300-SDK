﻿// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for CheckOrPeriodEndDate
    /// </summary>
    public enum PrintCheckStatus
    {
        /// <summary>
        /// Gets or sets NoChecksToPrintOrPost
        /// </summary>
        [EnumValue("NoChecksToPrintOrPost", typeof(PayrollChecksResx))]
        NoChecksToPrintOrPost = 1,
        /// <summary>
        /// Gets or sets ChecksToPost
        /// </summary>
        [EnumValue("ChecksToPost", typeof(PayrollChecksResx))]
        ChecksToPost = 2,
        /// <summary>
        /// Gets or sets ChecksToPrintOrPost
        /// </summary>
        [EnumValue("ChecksToPrintOrPost", typeof(PayrollChecksResx))]
        ChecksToPrintOrPost = 3
    }
}