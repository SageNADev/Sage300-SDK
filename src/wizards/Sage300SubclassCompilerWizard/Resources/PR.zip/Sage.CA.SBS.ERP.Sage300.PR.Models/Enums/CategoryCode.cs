// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for CategoryCode
    /// </summary>
    public enum CategoryCode
    {
        /// <summary>
        /// Gets or sets Accrual
        /// </summary>
        [EnumValue("Accrual", typeof(CheckDetailsOptionalFieldResx))]
        Accrual = 1,
        /// <summary>
        /// Gets or sets Earning
        /// </summary>
        [EnumValue("Earning", typeof(CheckDetailsOptionalFieldResx))]
        Earning = 2,
        /// <summary>
        /// Gets or sets Advance
        /// </summary>
        [EnumValue("Advance", typeof(CheckDetailsOptionalFieldResx))]
        Advance = 3,
        /// <summary>
        /// Gets or sets Deduction
        /// </summary>
        [EnumValue("Deduction", typeof(CheckDetailsOptionalFieldResx))]
        Deduction = 4,
        /// <summary>
        /// Gets or sets ExpenseReimbursement
        /// </summary>
        [EnumValue("ExpenseReimbursement", typeof(CheckDetailsOptionalFieldResx))]
        ExpenseReimbursement = 5,
        /// <summary>
        /// Gets or sets Benefit
        /// </summary>
        [EnumValue("Benefit", typeof(CheckDetailsOptionalFieldResx))]
        Benefit = 6,
        /// <summary>
        /// Gets or sets FederalTax
        /// </summary>
        [EnumValue("FederalTax", typeof(CheckDetailsOptionalFieldResx))]
        FederalTax = 7,
        /// <summary>
        /// Gets or sets StateTax
        /// </summary>
        [EnumValue("StateTax", typeof(CheckDetailsOptionalFieldResx))]
        StateTax = 8,
        /// <summary>
        /// Gets or sets LocalTax
        /// </summary>
        [EnumValue("LocalTax", typeof(CheckDetailsOptionalFieldResx))]
        LocalTax = 9,
        /// <summary>
        /// Gets or sets UserTax
        /// </summary>
        [EnumValue("UserTax", typeof(CheckDetailsOptionalFieldResx))]
        UserTax = 10
    }
}