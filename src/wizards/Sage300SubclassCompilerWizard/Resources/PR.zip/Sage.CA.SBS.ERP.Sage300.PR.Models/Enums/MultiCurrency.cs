﻿#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum Multicurrency
    /// </summary>
    public enum Multicurrency
    {
        /// <summary>
        /// The no
        /// </summary>
        [EnumValue("No", typeof(PayrollChecksResx))] No = 0,

        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("Yes", typeof(PayrollChecksResx))] Yes = 1
    }
}
