// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms; 

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ShiftNumber
    /// </summary>
    public enum ShiftNumber
    {
        /// <summary>
        /// Gets or sets ShiftNumber - 1
        /// </summary>
        [EnumValue("ShiftNumberOne", typeof(EmployeeTimecardResx))]
        One = 1,

        /// <summary>
        /// Gets or sets ShiftNumber - 2
        /// </summary>
        [EnumValue("ShiftNumberTwo", typeof(EmployeeTimecardResx))]
        Two = 2,

        /// <summary>
        /// Gets or sets ShiftNumber - 3
        /// </summary>
        [EnumValue("ShiftNumberThree", typeof(EmployeeTimecardResx))]
        Three = 3,

        /// <summary>
        /// Gets or sets ShiftNumber - 4
        /// </summary>
        [EnumValue("ShiftNumberFour", typeof(EmployeeTimecardResx))]
        Four = 4,

    }
}