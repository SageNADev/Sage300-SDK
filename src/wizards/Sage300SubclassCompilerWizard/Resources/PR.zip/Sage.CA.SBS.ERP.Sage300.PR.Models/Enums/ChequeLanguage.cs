// Copyright (c) 2022-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for CheckLanguage
	/// </summary>
	public enum CheckLanguage
	{
		/// <summary>
		/// Gets or sets English
		/// </summary>

		[EnumValue("English", typeof(EmployeeResx))]
		English = 5658,

		/// <summary>
		/// Gets or sets French
		/// </summary>
		
		[EnumValue("French", typeof(EmployeeResx))]
		French = 7092,

		/// <summary>
		/// Gets or sets Spanish
		/// </summary>
		
		[EnumValue("Spanish", typeof(EmployeeResx))]
		Spanish = 5845,

		/// <summary>
		/// Gets or sets Australian
		/// </summary>
		
		[EnumValue("Australian", typeof(EmployeeResx))]
		Australian = 738,

		/// <summary>
		/// Gets or sets Mexican
		/// </summary>
		
		[EnumValue("Mexican", typeof(EmployeeResx))]
		Mexican = 15719,

		/// <summary>
		/// Gets or sets ChineseSimplified
		/// </summary>
	
		[EnumValue("ChineseSimplified", typeof(EmployeeResx))]
		ChineseSimplified = 2857,

		/// <summary>
		/// Gets or sets ChineseTraditional
		/// </summary>
	
		[EnumValue("ChineseTraditional", typeof(EmployeeResx))]
		ChineseTraditional = 2863
	}
}
