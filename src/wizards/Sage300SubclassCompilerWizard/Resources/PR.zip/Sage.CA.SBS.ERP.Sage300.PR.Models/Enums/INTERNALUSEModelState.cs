// Copyright (c) 1994-2024 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for INTERNALUSEModelState
    /// </summary>
    public enum INTERNALUSEModelState
    {
        /// <summary>
        /// There IS corresponding EmployeeTaxeModel record on server
        /// </summary>
        [EnumValue("Acquired", typeof(EmployeeTaxInfoResx))]
        Acquired = 0,
        /// <summary>
        /// There is NO corresponding EmployeeTaxeModel record on server
        /// </summary>
        [EnumValue("Created", typeof(EmployeeTaxInfoResx))]
        Created = 1,
        /// <summary>
        /// Just inserted corresponding EmployeeTaxeModel record on server
        /// </summary>
        [EnumValue("Inserted", typeof(EmployeeTaxInfoResx))]
        Inserted = 2,
        /// <summary>
        /// Just updated corresponding EmployeeTaxeModel record on server
        /// </summary>
        [EnumValue("Updated", typeof(EmployeeTaxInfoResx))]
        Updated = 3
    }
}