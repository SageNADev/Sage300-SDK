// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for INTERNALUSEModelState
    /// </summary>
    public enum INTERNALUSEModelState
    {
        /// <summary>
        /// There IS corresponding EmployeeTaxeModel record on server
        /// </summary>
        [EnumValue("Accounted", typeof(EmployeeTaxeResx))]
        Accounted = 0,
        /// <summary>
        /// There is NO corresponding EmployeeTaxeModel record on server
        /// </summary>
        [EnumValue("Created", typeof(EmployeeTaxeResx))]
        Created = 1,
        /// <summary>
        /// Just inserted corresponding EmployeeTaxeModel record on server
        /// </summary>
        [EnumValue("Inserted", typeof(EmployeeTaxeResx))]
        Inserted = 2
    }
}