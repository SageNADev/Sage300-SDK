// Copyright (c) 1994-2024 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms; 

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for EFTCalculationType
    /// </summary>
    public enum EFTCalculationType
    {
        /// <summary>
        /// Gets or sets FixedAmount
        /// </summary>
        [EnumValue("FixedAmount", typeof(EmployeeResx))]
        FixedAmount = 1,
        /// <summary>
        /// Gets or sets OfGrossEarnings
        /// </summary>
        [EnumValue("OfGrossEarnings", typeof(EmployeeResx))]
        OfGrossEarnings = 2,
        /// <summary>
        /// Gets or sets OfNetPay
        /// </summary>
        [EnumValue("OfNetPay", typeof(EmployeeResx))]
        OfNetPay = 3
    }
}