﻿
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	public enum ThenChecksBy
	{
		/// <summary>
		/// Gets or sets EmployeeNumber
		/// </summary>

		[EnumValue("EmployeeNumber", typeof(PayrollChecksResx))]
		EmployeeNumber = 1,

		/// <summary>
		/// Gets or sets EmployeeName
		/// </summary>

		[EnumValue("EmployeeName", typeof(PayrollChecksResx))]
		EmployeeName = 2,

		
	}
}
