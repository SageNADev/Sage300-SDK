// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Ethnicity
    /// </summary>
    public enum Ethnicity
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(EmployeeResx))]
        None = 0,
        /// <summary>
        /// Gets or sets AHispanicOrLatinoMale
        /// </summary>
        [EnumValue("AHispanicOrLatinoMale", typeof(EmployeeResx))]
        AHispanicOrLatinoMale = 1,
        /// <summary>
        /// Gets or sets BHispanicOrLatinoFemale
        /// </summary>
        [EnumValue("BHispanicOrLatinoFemale", typeof(EmployeeResx))]
        BHispanicOrLatinoFemale = 2,
        /// <summary>
        /// Gets or sets CWhiteMale
        /// </summary>
        [EnumValue("CWhiteMale", typeof(EmployeeResx))]
        CWhiteMale = 3,
        /// <summary>
        /// Gets or sets DBlackOrAfricanAmericanMale
        /// </summary>
        [EnumValue("DBlackOrAfricanAmericanMale", typeof(EmployeeResx))]
        DBlackOrAfricanAmericanMale = 4,
        /// <summary>
        /// Gets or sets ENativeHawaiianOrPacificIslanderMale
        /// </summary>
        [EnumValue("ENativeHawaiianOrPacificIslanderMale", typeof(EmployeeResx))]
        ENativeHawaiianOrPacificIslanderMale = 5,
        /// <summary>
        /// Gets or sets FAsianMale
        /// </summary>
        [EnumValue("FAsianMale", typeof(EmployeeResx))]
        FAsianMale = 6,
        /// <summary>
        /// Gets or sets GNativeAmericanOrAlaskaNativeMale
        /// </summary>
        [EnumValue("GNativeAmericanOrAlaskaNativeMale", typeof(EmployeeResx))]
        GNativeAmericanOrAlaskaNativeMale = 7,
        /// <summary>
        /// Gets or sets HTwoOrMoreRacesMale
        /// </summary>
        [EnumValue("HTwoOrMoreRacesMale", typeof(EmployeeResx))]
        HTwoOrMoreRacesMale = 8,
        /// <summary>
        /// Gets or sets IWhiteFemale
        /// </summary>
        [EnumValue("IWhiteFemale", typeof(EmployeeResx))]
        IWhiteFemale = 9,
        /// <summary>
        /// Gets or sets JBlackOrAfricanAmericanFemale
        /// </summary>
        [EnumValue("JBlackOrAfricanAmericanFemale", typeof(EmployeeResx))]
        JBlackOrAfricanAmericanFemale = 10,
        /// <summary>
        /// Gets or sets KNativeHawaiianOrPacificIslanderFemale
        /// </summary>
        [EnumValue("KNativeHawaiianOrPacificIslanderFemale", typeof(EmployeeResx))]
        KNativeHawaiianOrPacificIslanderFemale = 11,
        /// <summary>
        /// Gets or sets LAsianFemale
        /// </summary>
        [EnumValue("LAsianFemale", typeof(EmployeeResx))]
        LAsianFemale = 12,
        /// <summary>
        /// Gets or sets MNativeAmericanOrAlaskaNativeFemale
        /// </summary>
        [EnumValue("MNativeAmericanOrAlaskaNativeFemale", typeof(EmployeeResx))]
        MNativeAmericanOrAlaskaNativeFemale = 13,
        /// <summary>
        /// Gets or sets NTwoOrMoreRacesFemale
        /// </summary>
        [EnumValue("NTwoOrMoreRacesFemale", typeof(EmployeeResx))]
        NTwoOrMoreRacesFemale = 14
    }
}
