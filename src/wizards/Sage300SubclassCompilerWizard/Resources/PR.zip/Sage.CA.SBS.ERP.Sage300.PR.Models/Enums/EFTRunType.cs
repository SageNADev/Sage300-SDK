﻿
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	public enum EFTRunType 
	{
		/// <summary>
		/// Gets or sets Orignal
		/// </summary>

		[EnumValue("Orignal", typeof(GenerateEFTFileResx))]
		Orignal = 1,

		/// <summary>
		/// Gets or sets Replacement
		/// </summary>

		[EnumValue("Replacement", typeof(GenerateEFTFileResx))]
		Replacement = 2,

		/// <summary>
		/// Gets or sets Pre-notification
		/// </summary>

		[EnumValue("PreNotification", typeof(GenerateEFTFileResx))]
		PreNotification = 3,


	}
	public enum EFTRunTypeCP
	{
	// <summary>
		// Gets or sets Orignal
		// </summary>

		[EnumValue("Orignal", typeof(GenerateEFTFileResx))]
		Orignal = 1,

		/// <summary>
		/// Gets or sets Replacement
		/// </summary>

		[EnumValue("Replacement", typeof(GenerateEFTFileResx))]
		Replacement = 2,

		/// <summary>
		/// Gets or sets Test
		/// </summary>

		[EnumValue("Test", typeof(GenerateEFTFileResx))]
		Test = 3


	}
}
