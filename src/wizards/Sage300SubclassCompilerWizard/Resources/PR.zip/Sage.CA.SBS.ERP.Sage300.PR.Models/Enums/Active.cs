﻿#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for Active 
	/// </summary>
	public enum Active
	{
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>
		[EnumValue("Yes", typeof(EnumerationsResx))]
		Yes = 1,
		/// <summary>
		/// Gets or sets No 
		/// </summary>	
		[EnumValue("No", typeof(EnumerationsResx))]
		No = 0
	}
}
