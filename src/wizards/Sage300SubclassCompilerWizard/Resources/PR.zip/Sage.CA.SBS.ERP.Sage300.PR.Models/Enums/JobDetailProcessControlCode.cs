// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Job Detail ProcessControlCode
    /// </summary>
    public enum JobDetailProcessControlCode
    {
        /// <summary>
        /// Gets or sets InsertOptionalFields
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(EmployeeTimecardResx))]
        InsertOptionalFields = 0
    }
}