// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for EmployerW2Box
    /// </summary>
    public enum EmployerW2Box
    {
        /// <summary>
        /// Gets or sets NotApplicable
        /// </summary>
        [EnumValue("NotApplicable", typeof(EarningsDeductionResx))]
        NotApplicable = 1,
        /// <summary>
        /// Gets or sets OtherInformationBox
        /// </summary>
        [EnumValue("OtherInformationBox", typeof(EarningsDeductionResx))]
        OtherInformationBox = 2,
        /// <summary>
        /// Gets or sets AllocatedTips
        /// </summary>
        [EnumValue("AllocatedTips", typeof(EarningsDeductionResx))]
        AllocatedTips = 3,
        /// <summary>
        /// Gets or sets DependentCare
        /// </summary>
        [EnumValue("DependentCare", typeof(EarningsDeductionResx))]
        DependentCare = 4,
        /// <summary>
        /// Gets or sets FringeBenefit
        /// </summary>
        [EnumValue("FringeBenefit", typeof(EarningsDeductionResx))]
        FringeBenefit = 5,
        /// <summary>
        /// Gets or sets CostOfGroupTermOver50000
        /// </summary>
        [EnumValue("CostOfGroupTermOver50000", typeof(EarningsDeductionResx))]
        CostOfGroupTermOver50000 = 6,
        /// <summary>
        /// Gets or sets UncollectedSocSecTaxOnCostOfGroupTermOver50000
        /// </summary>
        [EnumValue("UncollectedSocSecTaxOnCostOfGroupTermOver50000", typeof(EarningsDeductionResx))]
        UncollectedSocSecTaxOnCostOfGroupTermOver50000 = 7,
        /// <summary>
        /// Gets or sets UncollectedMedicareTaxOnCostOfGroupTermOver50000
        /// </summary>
        [EnumValue("UncollectedMedicareTaxOnCostOfGroupTermOver50000", typeof(EarningsDeductionResx))]
        UncollectedMedicareTaxOnCostOfGroupTermOver50000 = 8,
        /// <summary>
        /// Gets or sets SickPayNotIncludibleAsIncome3RdPartySickPay
        /// </summary>
        [EnumValue("SickPayNotIncludibleAsIncome3RdPartySickPay", typeof(EarningsDeductionResx))]
        SickPayNotIncludibleAsIncome3RdPartySickPay = 9,
        /// <summary>
        /// Gets or sets ExcessGolden
        /// </summary>
        [EnumValue("ExcessGolden", typeof(EarningsDeductionResx))]
        ExcessGolden = 10,
        /// <summary>
        /// Gets or sets AllowedPerDiem
        /// </summary>
        [EnumValue("AllowedPerDiem", typeof(EarningsDeductionResx))]
        AllowedPerDiem = 11,
        /// <summary>
        /// Gets or sets NonqualifiedPlan
        /// </summary>
        [EnumValue("NonqualifiedPlan", typeof(EarningsDeductionResx))]
        NonqualifiedPlan = 12,
        /// <summary>
        /// Gets or sets Section457
        /// </summary>
        [EnumValue("Section457", typeof(EarningsDeductionResx))]
        Section457 = 13,
        /// <summary>
        /// Gets or sets ExcludableMovingExpenseReimbursements
        /// </summary>
        [EnumValue("ExcludableMovingExpenseReimbursements", typeof(EarningsDeductionResx))]
        ExcludableMovingExpenseReimbursements = 14,
        /// <summary>
        /// Gets or sets NontaxableCombatPay
        /// </summary>
        [EnumValue("NontaxableCombatPay", typeof(EarningsDeductionResx))]
        NontaxableCombatPay = 15,
        /// <summary>
        /// Gets or sets MedicalSavingsAcct
        /// </summary>
        [EnumValue("MedicalSavingsAcct", typeof(EarningsDeductionResx))]
        MedicalSavingsAcct = 16,
        /// <summary>
        /// Gets or sets AdoptionBenefit
        /// </summary>
        [EnumValue("AdoptionBenefit", typeof(EarningsDeductionResx))]
        AdoptionBenefit = 17,
        /// <summary>
        /// Gets or sets NonStatutoryStockOptions
        /// </summary>
        [EnumValue("NonStatutoryStockOptions", typeof(EarningsDeductionResx))]
        NonStatutoryStockOptions = 18,
        /// <summary>
        /// Gets or sets HealthSavingsAccount
        /// </summary>
        [EnumValue("HealthSavingsAccount", typeof(EarningsDeductionResx))]
        HealthSavingsAccount = 19,
        /// <summary>
        /// Gets or sets IncomeUnderSection409A
        /// </summary>
        [EnumValue("IncomeUnderSection409A", typeof(EarningsDeductionResx))]
        IncomeUnderSection409A = 20,
        /// <summary>
        /// Gets or sets EmployerProvidedHealthCare
        /// </summary>
        [EnumValue("EmployerProvidedHealthCare", typeof(EarningsDeductionResx))]
        EmployerProvidedHealthCare = 21,
        /// <summary>
        /// Gets or sets PermittedBenefitsUnderAQSEHRA
        /// </summary>
        [EnumValue("PermittedBenefitsUnderAQSEHRA", typeof(EarningsDeductionResx))]
        PermittedBenefitsUnderAQSEHRA = 22
    }
}
