﻿// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommandCode
    /// </summary>
    public enum TimecardProcessCommandCode
    {
        /// <summary>
        /// Gets or sets KeyAction
        /// </summary>
        [EnumValue("KeyAction", typeof(TimecardDetailResx))]
        KeyAction = 0,
        /// <summary>
        /// Gets or sets InsertOptionalFields
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(TimecardDetailResx))]
        InsertOptionalFields = 1,
    }
}
