// Copyright (c) 1994-2024 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for INTERNALUSEOperationCode
    /// </summary>
    public enum INTERNALUSEOperationCode
    {
        /// <summary>
        /// Gets or sets CopyEmployeeTemplate
        /// </summary>
        [EnumValue("CopyEmployeeTemplate", typeof(EmployeeTaxInfoResx))]
        CopyEmployeeTemplate = 0,
        /// <summary>
        /// Gets or sets CheckParameters
        /// </summary>
        [EnumValue("CheckParameters", typeof(EmployeeTaxInfoResx))]
        CheckParameters = 1,
        /// <summary>
        /// Gets or sets InsertOptionalFields
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(EmployeeTaxInfoResx))]
        InsertOptionalFields = 2
    }
}