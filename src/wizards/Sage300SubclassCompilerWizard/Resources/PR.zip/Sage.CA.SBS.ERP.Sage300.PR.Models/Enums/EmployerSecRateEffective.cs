// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for EmployerSecRateEffective
    /// </summary>
    public enum EmployerSecRateEffective
    {
        /// <summary>
        /// Gets or sets Never
        /// </summary>
        [EnumValue("Never", typeof(EarningsDeductionResx))]
        Never = 0,
        /// <summary>
        /// Gets or sets AfterAnnualMaximumReached
        /// </summary>
        [EnumValue("AfterAnnualMaximumReached", typeof(EarningsDeductionResx))]
        AfterAnnualMaximumReached = 1
    }
}
