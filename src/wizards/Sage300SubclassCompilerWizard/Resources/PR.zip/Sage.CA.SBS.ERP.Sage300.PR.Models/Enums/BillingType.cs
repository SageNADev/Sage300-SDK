// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for BillingType
    /// </summary>
    public enum BillingType
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(TimecardJobDetailResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Nonbillable
        /// </summary>
        [EnumValue("Nonbillable", typeof(TimecardJobDetailResx))]
        Nonbillable = 1,
        /// <summary>
        /// Gets or sets Billable
        /// </summary>
        [EnumValue("Billable", typeof(TimecardJobDetailResx))]
        Billable = 2,
        /// <summary>
        /// Gets or sets NoCharge
        /// </summary>
        [EnumValue("NoCharge", typeof(TimecardJobDetailResx))]
        NoCharge = 3
    }
}