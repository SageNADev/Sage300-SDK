﻿
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	public enum SortChecksBy
	{
		/// <summary>
		/// Gets or sets EmployeeNumber
		/// </summary>

		[EnumValue("EmployeeNumber", typeof(PayrollChecksResx))]
		EmployeeNumber = 1,

		/// <summary>
		/// Gets or sets EmployeeName
		/// </summary>

		[EnumValue("EmployeeName", typeof(PayrollChecksResx))]
		EmployeeName = 2,

		/// <summary>
		/// Gets or sets PeriodEndDate
		/// </summary>

		[EnumValue("PeriodEndDate", typeof(PayrollChecksResx))]
		PeriodEndDate = 3,

		/// <summary>
		/// Gets or sets CheckDate
		/// </summary>
		[EnumValue("CheckDate", typeof(PayrollChecksResx))]
		CheckDate = 4,

		/// <summary>
		/// Gets or sets ClassCode
		/// </summary>
		[EnumValue("ClassCode", typeof(PayrollChecksResx))]
		ClassCode = 5


	}
	public enum SortChecksByCP
	{
		/// <summary>
		/// Gets or sets EmployeeNumber
		/// </summary>
		[EnumValue("EmployeeNumber", typeof(PayrollChecksResx))]
		EmployeeNumber = 1,

		/// <summary>
		/// Gets or sets EmployeeName
		/// </summary>
		[EnumValue("EmployeeName", typeof(PayrollChecksResx))]
		EmployeeName = 2,

		/// <summary>
		/// Gets or sets PeriodEndDate
		/// </summary>
		[EnumValue("PeriodEndDate", typeof(PayrollChecksResx))]
		PeriodEndDate = 3,

		/// <summary>
		/// Gets or sets ChequeDate
		/// </summary>
		[EnumValue("ChequeDate", typeof(PayrollChecksResx))]
		ChequeDate = 4,

		/// <summary>
		/// Gets or sets ClassCode
		/// </summary>
		[EnumValue("ClassCode", typeof(PayrollChecksResx))]
		ClassCode = 5
	}
}
