// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for PayFrequency
	/// </summary>
	public enum PayFrequency
	{
		/// <summary>
		/// Gets or sets Daily
		/// </summary>
		
		[EnumValue("Daily", typeof(EmployeeResx))]
		Daily = 2,

		/// <summary>
		/// Gets or sets Weekly
		/// </summary>
	
		[EnumValue("Weekly", typeof(EmployeeResx))]
		Weekly = 3,

		/// <summary>
		/// Gets or sets Biweekly
		/// </summary>
		
		[EnumValue("Biweekly", typeof(EmployeeResx))]
		Biweekly = 4,

		/// <summary>
		/// Gets or sets Semimonthly
		/// </summary>

		[EnumValue("Semimonthly", typeof(EmployeeResx))]
		Semimonthly = 5,

		/// <summary>
		/// Gets or sets TwentytwoperYear
		/// </summary>
	
		[EnumValue("TwentyTwoPerYear", typeof(EmployeeResx))]
		TwentytwoperYear = 10,

		/// <summary>
		/// Gets or sets ThirteenperYear
		/// </summary>
		
		[EnumValue("ThirteenPerYear", typeof(EmployeeResx))]
		ThirteenperYear = 9,

		/// <summary>
		/// Gets or sets Monthly
		/// </summary>

		[EnumValue("Monthly", typeof(EmployeeResx))]
		Monthly = 6,

		/// <summary>
		/// Gets or sets Monthly
		/// </summary>

		[EnumValue("Quarterly", typeof(EmployeeResx))]
		Quarterly = 7,

		/// <summary>
		/// Gets or sets TenperYear
		/// </summary>
	
		[EnumValue("TenPerYear", typeof(EmployeeResx))]
		TenperYear = 8
	}
}
