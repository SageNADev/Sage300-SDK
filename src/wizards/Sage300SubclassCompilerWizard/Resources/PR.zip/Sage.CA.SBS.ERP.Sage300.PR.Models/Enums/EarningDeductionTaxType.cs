// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for EarningDeductionTaxType
    /// </summary>
    public enum EarningDeductionTaxType
    {
        /// <summary>
        /// Gets or sets SalaryWages
        /// </summary>
        [EnumValue("SalaryWages", typeof(CheckDetailResx))]
        SalaryWages = 1,
        /// <summary>
        /// Gets or sets ReportedTips
        /// </summary>
        [EnumValue("ReportedTips", typeof(CheckDetailResx))]
        ReportedTips = 2,
        /// <summary>
        /// Gets or sets AllocatedTips
        /// </summary>
        [EnumValue("AllocatedTips", typeof(CheckDetailResx))]
        AllocatedTips = 3,
        /// <summary>
        /// Gets or sets Vacation
        /// </summary>
        [EnumValue("Vacation", typeof(CheckDetailResx))]
        Vacation = 7,
        /// <summary>
        /// Gets or sets Sick
        /// </summary>
        [EnumValue("Sick", typeof(CheckDetailResx))]
        Sick = 8,
        /// <summary>
        /// Gets or sets CompensatoryTime
        /// </summary>
        [EnumValue("CompensatoryTime", typeof(CheckDetailResx))]
        CompensatoryTime = 9,
        /// <summary>
        /// Gets or sets Cash
        /// </summary>
        [EnumValue("Cash", typeof(CheckDetailResx))]
        Cash = 13,
        /// <summary>
        /// Gets or sets Noncash
        /// </summary>
        [EnumValue("Noncash", typeof(CheckDetailResx))]
        Noncash = 14,
        /// <summary>
        /// Gets or sets InsuranceTax
        /// </summary>
        [EnumValue("InsuranceTax", typeof(CheckDetailResx))]
        InsuranceTax = 18,
        /// <summary>
        /// Gets or sets IncomeTax
        /// </summary>
        [EnumValue("IncomeTax", typeof(CheckDetailResx))]
        IncomeTax = 19,
        /// <summary>
        /// Gets or sets UnemploymentTax
        /// </summary>
        [EnumValue("UnemploymentTax", typeof(CheckDetailResx))]
        UnemploymentTax = 20,
        /// <summary>
        /// Gets or sets PensionPlanTax
        /// </summary>
        [EnumValue("PensionPlanTax", typeof(CheckDetailResx))]
        PensionPlanTax = 21,
        /// <summary>
        /// Gets or sets HealthTax
        /// </summary>
        [EnumValue("HealthTax", typeof(CheckDetailResx))]
        HealthTax = 22,
        /// <summary>
        /// Gets or sets OtherTax
        /// </summary>
        [EnumValue("OtherTax", typeof(CheckDetailResx))]
        OtherTax = 23,
        /// <summary>
        /// Gets or sets na
        /// </summary>
        [EnumValue("na", typeof(CheckDetailResx))]
        na = 25
    }
}