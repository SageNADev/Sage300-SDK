// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for CalculationMethod
    /// </summary>
    public enum CalculationMethod
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(TimecardDetailResx))]
        None = 1,
        /// <summary>
        /// Gets or sets Flat
        /// </summary>
        [EnumValue("Flat", typeof(TimecardDetailResx))]
        Flat = 2,
        /// <summary>
        /// Gets or sets Fixed
        /// </summary>
        [EnumValue("Fixed", typeof(TimecardDetailResx))]
        Fixed = 3,
        /// <summary>
        /// Gets or sets HourlyRate
        /// </summary>
        [EnumValue("HourlyRate", typeof(TimecardDetailResx))]
        HourlyRate = 4,
        /// <summary>
        /// Gets or sets AmountPerHour
        /// </summary>
        [EnumValue("AmountPerHour", typeof(TimecardDetailResx))]
        AmountPerHour = 5,
        /// <summary>
        /// Gets or sets PieceRateTable
        /// </summary>
        [EnumValue("PieceRateTable", typeof(TimecardDetailResx))]
        PieceRateTable = 6,
        /// <summary>
        /// Gets or sets PercentageOfBase
        /// </summary>
        [EnumValue("PercentageOfBase", typeof(TimecardDetailResx))]
        PercentageOfBase = 7,
        /// <summary>
        /// Gets or sets SalesCommissionTable
        /// </summary>
        [EnumValue("SalesCommissionTable", typeof(TimecardDetailResx))]
        SalesCommissionTable = 8,
        /// <summary>
        /// Gets or sets WageBracketTable
        /// </summary>
        [EnumValue("WageBracketTable", typeof(TimecardDetailResx))]
        WageBracketTable = 9,
        /// <summary>
        /// Gets or sets HoursPerHourWorked
        /// </summary>
        [EnumValue("HoursPerHourWorked", typeof(TimecardDetailResx))]
        HoursPerHourWorked = 10,
        /// <summary>
        /// Gets or sets HoursPerFrequency
        /// </summary>
        [EnumValue("HoursPerFrequency", typeof(TimecardDetailResx))]
        HoursPerFrequency = 12,
        /// <summary>
        /// Gets or sets TaxBracketTable
        /// </summary>
        [EnumValue("TaxBracketTable", typeof(TimecardDetailResx))]
        TaxBracketTable = 13,
        /// <summary>
        /// Gets or sets PercentageOfAnotherTax
        /// </summary>
        [EnumValue("PercentageOfAnotherTax", typeof(TimecardDetailResx))]
        PercentageOfAnotherTax = 14
    }
}