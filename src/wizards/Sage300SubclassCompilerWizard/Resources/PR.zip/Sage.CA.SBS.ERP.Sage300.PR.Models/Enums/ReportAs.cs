// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ReportAs
    /// </summary>
    public enum ReportAs
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(EarningsDeductionResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Form941EmergencyPaidSickLeave
        /// </summary>
        [EnumValue("Form941EmergencyPaidSickLeave", typeof(EarningsDeductionResx))]
        Form941EmergencyPaidSickLeave = 1,
        /// <summary>
        /// Gets or sets Form941EmergencyPaidSickLeaveForOthers
        /// </summary>
        [EnumValue("Form941EmergencyPaidSickLeaveForOthers", typeof(EarningsDeductionResx))]
        Form941EmergencyPaidSickLeaveForOthers = 8,
        /// <summary>
        /// Gets or sets Form941EmergencyPaidFamilyLeave
        /// </summary>
        [EnumValue("Form941EmergencyPaidFamilyLeave", typeof(EarningsDeductionResx))]
        Form941EmergencyPaidFamilyLeave = 2,
        /// <summary>
        /// Gets or sets Form941QualifiedRetentionCreditEarnings
        /// </summary>
        [EnumValue("Form941QualifiedRetentionCreditEarnings", typeof(EarningsDeductionResx))]
        Form941QualifiedRetentionCreditEarnings = 3
    }
}
