// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for ActiveSegmentReplaceOption
    /// </summary>
    public enum ActiveSegmentReplaceOption
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(CompanyOptionResx))]
        None = 1,
        /// <summary>
        /// Gets or sets ExpenseAccounts
        /// </summary>
        [EnumValue("ExpenseAccounts", typeof(CompanyOptionResx))]
        ExpenseAccounts = 2,
        /// <summary>
        /// Gets or sets ExpenseAndLiabilityAccounts
        /// </summary>
        [EnumValue("ExpenseAndLiabilityAccounts", typeof(CompanyOptionResx))]
        ExpenseAndLiabilityAccounts = 3
    }
}