﻿// Copyright (c) 2025 The Sage Group plc or its licensors.  All rights reserved.
#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	public enum Chooseby	 
	{
        /// <summary>
        /// Gets or sets EmployeeNumber
        /// </summary>
        [EnumValue("EmployeeNumber", typeof(CopytimecardResx))]
		EmployeeNumber = 0,

		/// <summary>
		/// Gets or sets ClassCode
		/// </summary>
		[EnumValue("ClassCode", typeof(CopytimecardResx))]
		ClassCode = 1,

		/// <summary>
		/// Gets or sets SelectionLists
		/// </summary>
		[EnumValue("SelectionList", typeof(CopytimecardResx))]
		SelectionList = 2
	}
}
