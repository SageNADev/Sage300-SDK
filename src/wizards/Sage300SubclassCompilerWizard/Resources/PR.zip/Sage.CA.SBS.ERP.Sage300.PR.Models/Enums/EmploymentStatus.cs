// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	/// <summary>
	/// Enum for EmploymentStatus
	/// </summary>
	public enum EmploymentStatus
	{
		/// <summary>
		/// Gets or sets Active
		/// </summary>

		[EnumValue("Active", typeof(EmployeeResx))]
		Active = 1,

		/// <summary>
		/// Gets or sets Inactive
		/// </summary>

		[EnumValue("Inactive", typeof(EmployeeResx))]
		Inactive = 2,

		/// <summary>
		/// Gets or sets Terminated
		/// </summary>
	
		[EnumValue("Terminated", typeof(EmployeeResx))]
		Terminated = 3
	}

	/// <summary>
	/// Enum for EmploymentStatus
	/// </summary>
	public enum EmploymentStatusCP
	{
		/// <summary>
		/// Gets or sets Active
		/// </summary>

		[EnumValue("Active", typeof(EmployeeResx))]
		Active = 1,

		/// <summary>
		/// Gets or sets Inactive
		/// </summary>

		[EnumValue("Inactive", typeof(EmployeeResx))]
		Inactive = 2,

		/// <summary>
		/// Gets or sets Terminated
		/// </summary>

		[EnumValue("Terminated", typeof(EmployeeResx))]
		Terminated = 3,

		/// <summary>
		/// Gets or sets InactiveROEPending
		/// </summary>

		[EnumValue("InactiveROEPending", typeof(EmployeeResx))]
		InactiveROEPending = 4,

		/// <summary>
		/// Gets or sets TerminatedROEPending
		/// </summary>

		[EnumValue("TerminatedROEPending", typeof(EmployeeResx))]
		TerminatedROEPending = 5
	}
}
