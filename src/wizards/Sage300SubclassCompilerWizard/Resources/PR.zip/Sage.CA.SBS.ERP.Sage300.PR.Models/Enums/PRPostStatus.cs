// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for PRPostStatus
    /// </summary>
    public enum PRPostStatus
    {
        /// <summary>
        /// Gets or sets NotPosted
        /// </summary>
        [EnumValue("NotPosted", typeof(CheckHeaderResx))]
        NotPosted = 1,
        /// <summary>
        /// Gets or sets Posted
        /// </summary>
        [EnumValue("Posted", typeof(CheckHeaderResx))]
        Posted = 2
    }
}