﻿// Copyright (c) 2025 The Sage Group plc or its licensors.  All rights reserved.
#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
	public enum CopyClass
	{
		/// <summary>
		/// Gets or sets Class1
		/// </summary>
		[EnumValue("Class1", typeof(CopytimecardResx))]
		Class1 = 1,

		/// <summary>
		/// Gets or sets Class2
		/// </summary>
		[EnumValue("Class2", typeof(CopytimecardResx))]
		Class2 = 2,

		/// <summary>
		/// Gets or sets Class3
		/// </summary>
		[EnumValue("Class3", typeof(CopytimecardResx))]
		Class3 = 3,

		/// <summary>
		/// Gets or sets Class4
		/// </summary>
		[EnumValue("Class4", typeof(CopytimecardResx))]
		Class4 = 4
	}
}
