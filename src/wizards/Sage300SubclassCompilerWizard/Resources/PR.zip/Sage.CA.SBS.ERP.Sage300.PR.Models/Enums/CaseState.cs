﻿
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    public enum CaseState
    {
        /// <summary>
        /// Gets or sets California 
        /// </summary>
        [EnumValue("California", typeof(GenerateEFTFileResx))]
        California = 1,

        /// <summary>
        /// Gets or sets Connecticut 
        /// </summary>	
        [EnumValue("Connecticut", typeof(GenerateEFTFileResx))]
        Connecticut = 2, 

        /// <summary>
        /// Gets or sets DelaWare 
        /// </summary>	
        [EnumValue("DelaWare", typeof(GenerateEFTFileResx))]
        DelaWare = 3,

        /// <summary>
        /// Gets or sets Florida 
        /// </summary>	
        [EnumValue("Florida", typeof(GenerateEFTFileResx))]
        Florida = 4,

        /// <summary>
        /// Gets or sets Georgia 
        /// </summary>
        [EnumValue("Georgia", typeof(GenerateEFTFileResx))]
        Georgia = 5,

        /// <summary>
        /// Gets or sets Illnois
        /// </summary>	
        [EnumValue("Illnois", typeof(GenerateEFTFileResx))]
        Illnois = 6,

        /// <summary>
        /// Gets or sets Indiana 
        /// </summary>
        [EnumValue("Indiana", typeof(GenerateEFTFileResx))]
        Indiana = 7,

        /// <summary>
        /// Gets or sets Iowa
        /// </summary>	
        [EnumValue("Iowa", typeof(GenerateEFTFileResx))]
        Iowa = 8,

        /// <summary>
        /// Gets or sets Kansas 
        /// </summary>
        [EnumValue("Kansas", typeof(GenerateEFTFileResx))]
        Kansas = 9,

        /// <summary>
        /// Gets or sets Massachusetts 
        /// </summary>
        [EnumValue("Massachusetts", typeof(GenerateEFTFileResx))]
        Massachusetts = 10,

        /// <summary>
        /// Gets or sets Mississippi
        /// </summary>	
        [EnumValue("Mississippi", typeof(GenerateEFTFileResx))]
        Mississippi = 11,

        /// <summary>
        /// Gets or sets Nebraska 
        /// </summary>
        [EnumValue("Nebraska", typeof(GenerateEFTFileResx))]
        Nebraska = 12,

        /// <summary>
        /// Gets or sets NorthCarolina 
        /// </summary>
        [EnumValue("NorthCarolina", typeof(GenerateEFTFileResx))]
        NorthCarolina = 13,
		
        /// <summary>
        /// Gets or sets NorthDakota
        /// </summary>	
        [EnumValue("NorthDakota", typeof(GenerateEFTFileResx))]
        NorthDakota = 14,
		
        /// <summary>
        /// Gets or sets NewJersey 
        /// </summary>
        [EnumValue("NewJersey", typeof(GenerateEFTFileResx))]
        NewJersey = 15,

        /// <summary>
        /// Gets or sets NewMexico
        /// <summary>
        [EnumValue("NewMexico", typeof(GenerateEFTFileResx))]
        NewMexico = 16,

        /// <summary>
        /// Gets or sets Nevada 
        /// </summary>
        [EnumValue("Nevada", typeof(GenerateEFTFileResx))]
        Nevada = 17,

        /// <summary>
        /// Gets or sets Ohio
        /// <summary>
        [EnumValue("Ohio", typeof(GenerateEFTFileResx))]
        Ohio = 18,

        /// <summary>
        /// Gets or sets Oklahoma
        /// <summary>
        [EnumValue("Oklahoma", typeof(GenerateEFTFileResx))]
        Oklahoma = 19,

        /// <summary>
        /// Gets or sets Oregon 
        /// </summary>
        [EnumValue("Oregon", typeof(GenerateEFTFileResx))]
        Oregon = 20,

        /// <summary>
        /// Gets or sets Pennsylvania
        /// <summary>
        [EnumValue("Pennsylvania", typeof(GenerateEFTFileResx))]
        Pennsylvania = 21,

        /// <summary>
        /// Gets or sets RhodeIsland
        /// <summary>
        [EnumValue("RhodeIsland", typeof(GenerateEFTFileResx))]
        RhodeIsland = 22,

        /// <summary>
        /// Gets or sets SouthDakota
        /// <summary>
        [EnumValue("SouthDakota", typeof(GenerateEFTFileResx))]
        SouthDakota = 23,

        /// <summary>
        /// Gets or sets Texas 
        /// </summary>
        [EnumValue("Texas", typeof(GenerateEFTFileResx))]
        Texas = 24,

        /// <summary>
        /// Gets or sets Virginia
        /// <summary>
        [EnumValue("Virginia", typeof(GenerateEFTFileResx))]
        Virginia = 25,

        /// <summary>
        /// Gets or sets Washington 
        /// </summary>
        [EnumValue("Washington", typeof(GenerateEFTFileResx))]
        Washington = 26,

        /// <summary>
        /// Gets or sets Wisconsin
        /// <summary>
        [EnumValue("Wisconsin", typeof(GenerateEFTFileResx))]
        Wisconsin = 27,

        /// <summary>
        /// Gets or sets WestVirginia 
        /// </summary>
        [EnumValue("WestVirginia", typeof(GenerateEFTFileResx))]
        WestVirginia = 28,

    }
    public enum CaseStateCP
	{

        /// <summary>
        /// Gets or sets California 
        /// </summary>
        [EnumValue("California", typeof(GenerateEFTFileResx))]
        California = 1,

        /// <summary>
        /// Gets or sets Connecticut 
        /// </summary>	
        [EnumValue("Connecticut", typeof(GenerateEFTFileResx))]
        Connecticut = 2,

        /// <summary>
        /// Gets or sets DelaWare 
        /// </summary>	
        [EnumValue("DelaWare", typeof(GenerateEFTFileResx))]
        DelaWare = 3,

        /// <summary>
        /// Gets or sets Florida 
        /// </summary>	
        [EnumValue("Florida", typeof(GenerateEFTFileResx))]
        Florida = 4,

        /// <summary>
        /// Gets or sets Georgia 
        /// </summary>
        [EnumValue("Georgia", typeof(GenerateEFTFileResx))]
        Georgia = 5,

        /// <summary>
        /// Gets or sets Illnois
        /// </summary>	
        [EnumValue("Illnois", typeof(GenerateEFTFileResx))]
        Illnois = 6,

        /// <summary>
        /// Gets or sets Indiana 
        /// </summary>
        [EnumValue("Indiana", typeof(GenerateEFTFileResx))]
        Indiana = 7,

        /// <summary>
        /// Gets or sets Iowa
        /// </summary>	
        [EnumValue("Iowa", typeof(GenerateEFTFileResx))]
        Iowa = 8,

        /// <summary>
        /// Gets or sets Kansas 
        /// </summary>
        [EnumValue("Kansas", typeof(GenerateEFTFileResx))]
        Kansas = 9,

        /// <summary>
        /// Gets or sets Massachusetts 
        /// </summary>
        [EnumValue("Massachusetts", typeof(GenerateEFTFileResx))]
        Massachusetts = 10,

        /// <summary>
        /// Gets or sets Mississippi
        /// </summary>	
        [EnumValue("Mississippi", typeof(GenerateEFTFileResx))]
        Mississippi = 11,

        /// <summary>
        /// Gets or sets Nebraska 
        /// </summary>
        [EnumValue("Nebraska", typeof(GenerateEFTFileResx))]
        Nebraska = 12,

        /// <summary>
        /// Gets or sets NorthCarolina 
        /// </summary>
        [EnumValue("NorthCarolina", typeof(GenerateEFTFileResx))]
        NorthCarolina = 13,

        /// <summary>
        /// Gets or sets NorthDakota
        /// </summary>	
        [EnumValue("NorthDakota", typeof(GenerateEFTFileResx))]
        NorthDakota = 14,
		
        /// <summary>
        /// Gets or sets NewJersey 
        /// </summary>
        [EnumValue("NewJersey", typeof(GenerateEFTFileResx))]
        NewJersey = 15,

        /// <summary>
        /// Gets or sets NewMexico
        /// <summary>
        [EnumValue("NewMexico", typeof(GenerateEFTFileResx))]
        NewMexico = 16,

        /// <summary>
        /// Gets or sets Nevada 
        /// </summary>
        [EnumValue("Nevada", typeof(GenerateEFTFileResx))]
        Nevada = 17,

        /// <summary>
        /// Gets or sets Ohio
        /// <summary>
        [EnumValue("Ohio", typeof(GenerateEFTFileResx))]
        Ohio = 18,

        /// <summary>
        /// Gets or sets Oklahoma
        /// <summary>
        [EnumValue("Oklahoma", typeof(GenerateEFTFileResx))]
        Oklahoma = 19,

        /// <summary>
        /// Gets or sets Oregon 
        /// </summary>
        [EnumValue("Oregon", typeof(GenerateEFTFileResx))]
        Oregon = 20,

        /// <summary>
        /// Gets or sets Pennsylvania
        /// <summary>
        [EnumValue("Pennsylvania", typeof(GenerateEFTFileResx))]
        Pennsylvania = 11,

        /// <summary>
        /// Gets or sets RhodeIsland
        /// <summary>
        [EnumValue("RhodeIsland", typeof(GenerateEFTFileResx))]
        RhodeIsland = 22,

        /// <summary>
        /// Gets or sets SouthDakota
        /// <summary>
        [EnumValue("SouthDakota", typeof(GenerateEFTFileResx))]
        SouthDakota = 23,

        /// <summary>
        /// Gets or sets Texas 
        /// </summary>
        [EnumValue("Texas", typeof(GenerateEFTFileResx))]
        Texas = 24,

        /// <summary>
        /// Gets or sets Virginia
        /// <summary>
        [EnumValue("Virginia", typeof(GenerateEFTFileResx))]
        Virginia = 25,

        /// <summary>
        /// Gets or sets Washington 
        /// </summary>
        [EnumValue("Washington", typeof(GenerateEFTFileResx))]
        Washington = 26,

        /// <summary>
        /// Gets or sets Wisconsin
        /// <summary>
        [EnumValue("Wisconsin", typeof(GenerateEFTFileResx))]
        Wisconsin = 27,

        /// <summary>
        /// Gets or sets WestVirginia 
        /// </summary>
        [EnumValue("WestVirginia", typeof(GenerateEFTFileResx))]
        WestVirginia = 28,	
    }
}
