// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

// NB: differs from 'TypeOfCheck' in that the history option
// isn't included.
#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for TypeOfCheckCurrent
    /// </summary>
    public enum TypeOfCheckCurrent
    {
        /// <summary>
        /// Gets or sets All
        /// </summary>
        [EnumValue("All", typeof(CheckHeaderResx))]
        All = -1,
        /// <summary>
        /// Gets or sets SystemCheck
        /// </summary>
        [EnumValue("SystemCheck", typeof(CheckHeaderResx),1)]
        SystemCheck = 1,
        /// <summary>
        /// Gets or sets ManualCheck
        /// </summary>
        [EnumValue("ManualCheck", typeof(CheckHeaderResx),2)]
        ManualCheck = 2,
        /// <summary>
        /// Gets or sets ReversedCheck
        /// </summary>
        [EnumValue("ReversedCheck", typeof(CheckHeaderResx),4)]
        ReversedCheck = 5,
       
    }
}