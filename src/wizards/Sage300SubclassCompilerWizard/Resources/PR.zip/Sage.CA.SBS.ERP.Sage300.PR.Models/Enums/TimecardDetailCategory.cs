﻿// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for Category
    /// </summary>
    public enum TimeCardDetailCategory
    {
        /// <summary>
        /// Gets or sets Accrual
        /// </summary>
        [EnumValue("Accrual", typeof(TimecardDetailResx))]
        Accrual = 1,
        /// <summary>
        /// Gets or sets Earning
        /// </summary>
        [EnumValue("Earning", typeof(TimecardDetailResx))]
        Earning = 2,
        /// <summary>
        /// Gets or sets Advance
        /// </summary>
        [EnumValue("Advance", typeof(TimecardDetailResx))]
        Advance = 3,
        /// <summary>
        /// Gets or sets Deduction
        /// </summary>
        [EnumValue("Deduction", typeof(TimecardDetailResx))]
        Deduction = 4,
        /// <summary>
        /// Gets or sets ExpenseReimbursement
        /// </summary>
        [EnumValue("ExpenseReimbursement", typeof(TimecardDetailResx))]
        ExpenseReimbursement = 5,
        /// <summary>
        /// Gets or sets Benefit
        /// </summary>
        [EnumValue("Benefit", typeof(TimecardDetailResx))]
        Benefit = 6,
        /// <summary>
        /// Gets or sets FederalTax
        /// </summary>
        [EnumValue("FederalTax", typeof(TimecardDetailResx))]
        FederalTax = 7,
        /// <summary>
        /// Gets or sets StateTax
        /// </summary>
        [EnumValue("StateTax", typeof(TimecardDetailResx))]
        StateTax = 8,
        /// <summary>
        /// Gets or sets LocalTax
        /// </summary>
        [EnumValue("LocalTax", typeof(TimecardDetailResx))]
        LocalTax = 9,
        /// <summary>
        /// Gets or sets UserTax
        /// </summary>
        [EnumValue("UserTax", typeof(TimecardDetailResx))]
        UserTax = 10
    }
}
