// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models.Enums
{
    /// <summary>
    /// Enum for CostClass
    /// </summary>
    public enum CostClass
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(TimecardJobDetailResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Labor
        /// </summary>
        [EnumValue("Labor", typeof(TimecardJobDetailResx))]
        Labor = 1,
        /// <summary>
        /// Gets or sets Material
        /// </summary>
        [EnumValue("Material", typeof(TimecardJobDetailResx))]
        Material = 2,
        /// <summary>
        /// Gets or sets Equipment
        /// </summary>
        [EnumValue("Equipment", typeof(TimecardJobDetailResx))]
        Equipment = 3,
        /// <summary>
        /// Gets or sets Subcontractor
        /// </summary>
        [EnumValue("Subcontractor", typeof(TimecardJobDetailResx))]
        Subcontractor = 4,
        /// <summary>
        /// Gets or sets Overhead
        /// </summary>
        [EnumValue("Overhead", typeof(TimecardJobDetailResx))]
        Overhead = 5,
        /// <summary>
        /// Gets or sets Miscellaneous
        /// </summary>
        [EnumValue("Miscellaneous", typeof(TimecardJobDetailResx))]
        Miscellaneous = 6
    }
}