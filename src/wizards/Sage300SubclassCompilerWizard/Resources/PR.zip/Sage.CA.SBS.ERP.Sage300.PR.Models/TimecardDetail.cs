// Copyright (c) 2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PR.Models
{
    /// <summary>
    /// Partial class for TimecardDetail
    /// </summary>
    public partial class TimecardDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets Timecard
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Timecard", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.Timecard, Id = Index.Timecard, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Timecard { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public short LineNumber { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Int, Size = 2)]
        public TimeCardDetailCategory Category { get; set; }

        /// <summary>
        /// Gets or sets EarningsDeduction
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningsDeduction", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.EarningsDeduction, Id = Index.EarningsDeduction, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EarningsDeduction { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public TimecardDetailType Type { get; set; }

        /// <summary>
        /// Gets or sets Date
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Date", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.Date, Id = Index.Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Date { get; set; }

        /// <summary>
        /// Gets or sets StartTime
        /// </summary>
        [Display(Name = "StartTime", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.StartTime, Id = Index.StartTime, FieldType = EntityFieldType.Int, Size = 2)]
        public short StartTime { get; set; }

        /// <summary>
        /// Gets or sets StopTime
        /// </summary>
        [Display(Name = "StopTime", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.StopTime, Id = Index.StopTime, FieldType = EntityFieldType.Int, Size = 2)]
        public short StopTime { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentOne
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentOne", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentOne, Id = Index.GLSegmentOne, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentOne { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentTwo
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentTwo", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentTwo, Id = Index.GLSegmentTwo, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentTwo { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentThree
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentThree", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentThree, Id = Index.GLSegmentThree, FieldType = EntityFieldType.Char, Size = 15)]
        public string GLSegmentThree { get; set; }

        /// <summary>
        /// Gets or sets Hours
        /// </summary>
        [Display(Name = "Hours", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.Hours, Id = Index.Hours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal Hours { get; set; }

        /// <summary>
        /// Gets or sets CalculationMethod
        /// </summary>
        [Display(Name = "CalculationMethod", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.CalculationMethod, Id = Index.CalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculationMethod CalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets BaseLimit
        /// </summary>
        [Display(Name = "BaseLimit", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.BaseLimit, Id = Index.BaseLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public short BaseLimit { get; set; }

        /// <summary>
        /// Gets or sets PiecesSalesBase
        /// </summary>
        [Display(Name = "PiecesSalesBase", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.PiecesSalesBase, Id = Index.PiecesSalesBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PiecesSalesBase { get; set; }

        /// <summary>
        /// Gets or sets EDTaxRateAmtPercent
        /// </summary>
        [Display(Name = "EDTaxRateAmtPercent", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.EDTaxRateAmtPercent, Id = Index.EDTaxRateAmtPercent, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EDTaxRateAmtPercent { get; set; }

        /// <summary>
        /// Gets or sets PayAccrueHours
        /// </summary>
        [Display(Name = "PayAccrueHours", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.PayAccrueHours, Id = Index.PayAccrueHours, FieldType = EntityFieldType.Int, Size = 2)]
        public PayAccrueHours PayAccrueHours { get; set; }

        /// <summary>
        /// Gets or sets RegularPayExpenseGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RegularPayExpenseGLAccount", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.RegularPayExpenseGLAccount, Id = Index.RegularPayExpenseGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string RegularPayExpenseGLAccount { get; set; }

        /// <summary>
        /// Gets or sets LiabilityGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LiabilityGLAccount", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.LiabilityGLAccount, Id = Index.LiabilityGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string LiabilityGLAccount { get; set; }

        /// <summary>
        /// Gets or sets OvertimeExpenseGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OvertimeExpenseGLAccount", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.OvertimeExpenseGLAccount, Id = Index.OvertimeExpenseGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string OvertimeExpenseGLAccount { get; set; }

        /// <summary>
        /// Gets or sets ShiftDifferentialGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiftDifferentialGLAccount", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.ShiftDifferentialGLAccount, Id = Index.ShiftDifferentialGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string ShiftDifferentialGLAccount { get; set; }

        /// <summary>
        /// Gets or sets AssetAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AssetAccount", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.AssetAccount, Id = Index.AssetAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string AssetAccount { get; set; }

        /// <summary>
        /// Gets or sets OvertimeSchedule
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OvertimeSchedule", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.OvertimeSchedule, Id = Index.OvertimeSchedule, FieldType = EntityFieldType.Char, Size = 6)]
        public string OvertimeSchedule { get; set; }

        /// <summary>
        /// Gets or sets ShiftDifferentialSchedule
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShiftDifferentialSchedule", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.ShiftDifferentialSchedule, Id = Index.ShiftDifferentialSchedule, FieldType = EntityFieldType.Char, Size = 6)]
        public string ShiftDifferentialSchedule { get; set; }

        /// <summary>
        /// Gets or sets ShiftNumber
        /// </summary>
        [Display(Name = "ShiftNumber", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.ShiftNumber, Id = Index.ShiftNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public ShiftNumber ShiftNumber { get; set; }

        /// <summary>
        /// Gets or sets WorkersCompensationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkersCompensationCode", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.WorkersCompensationCode, Id = Index.WorkersCompensationCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string WorkersCompensationCode { get; set; }

        /// <summary>
        /// Gets or sets WeeksWorked
        /// </summary>
        [Display(Name = "WeeksWorked", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.WeeksWorked, Id = Index.WeeksWorked, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal WeeksWorked { get; set; }

        /// <summary>
        /// Gets or sets TaxAnnualizationFactor
        /// </summary>
        [Display(Name = "TaxAnnualizationFactor", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.TaxAnnualizationFactor, Id = Index.TaxAnnualizationFactor, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TaxAnnualizationFactor { get; set; }

        /// <summary>
        /// Gets or sets EntryType
        /// </summary>
        [Display(Name = "EntryType", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public short EntryType { get; set; }

        /// <summary>
        /// Gets or sets EDTaxDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EDTaxDescription", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.EDTaxDescription, Id = Index.EDTaxDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string EDTaxDescription { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentNameOne
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentNameOne", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentNameOne, Id = Index.GLSegmentNameOne, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentNameOne { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentDescriptionOne
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentDescriptionOne", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentDescriptionOne, Id = Index.GLSegmentDescriptionOne, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLSegmentDescriptionOne { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentNameTwo
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentNameTwo", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentNameTwo, Id = Index.GLSegmentNameTwo, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentNameTwo { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentDescriptionTwo
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentDescriptionTwo", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentDescriptionTwo, Id = Index.GLSegmentDescriptionTwo, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLSegmentDescriptionTwo { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentNameThree
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentNameThree", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentNameThree, Id = Index.GLSegmentNameThree, FieldType = EntityFieldType.Char, Size = 6)]
        public string GLSegmentNameThree { get; set; }

        /// <summary>
        /// Gets or sets GLSegmentDescriptionThree
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLSegmentDescriptionThree", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.GLSegmentDescriptionThree, Id = Index.GLSegmentDescriptionThree, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLSegmentDescriptionThree { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public TimecardDetailProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets DaysWorked
        /// </summary>
        [Display(Name = "DaysWorked", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.DaysWorked, Id = Index.DaysWorked, FieldType = EntityFieldType.Int, Size = 2)]
        public short DaysWorked { get; set; }

        /// <summary>
        /// Gets or sets WorkersCompGroup
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkersCompGroup", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.WorkersCompGroup, Id = Index.WorkersCompGroup, FieldType = EntityFieldType.Char, Size = 6)]
        public string WorkersCompGroup { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }
        
        /// <summary>
        /// Gets or sets OvertimeHoursOverride
        /// </summary>
        [Display(Name = "OvertimeHoursOverride", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.OvertimeHoursOverride, Id = Index.OvertimeHoursOverride, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal OvertimeHoursOverride { get; set; }

        /// <summary>
        /// Gets or sets OvertimeRateOverride
        /// </summary>
        [Display(Name = "OvertimeRateOverride", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.OvertimeRateOverride, Id = Index.OvertimeRateOverride, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal OvertimeRateOverride { get; set; }

        /// <summary>
        /// Gets or sets IncludeInFLSAOvertimeCalc
        /// </summary>
        [Display(Name = "IncludeInFLSAOvertimeCalc", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.IncludeInFLSAOvertimeCalc, Id = Index.IncludeInFLSAOvertimeCalc, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IncludeInFLSAOvertimeCalc { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets EmployerExpenseGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployerExpenseGLAccount", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.EmployerExpenseGLAccount, Id = Index.EmployerExpenseGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string EmployerExpenseGLAccount { get; set; }

        /// <summary>
        /// Gets or sets EmployerLiabilityGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployerLiabilityGLAccount", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.EmployerLiabilityGLAccount, Id = Index.EmployerLiabilityGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string EmployerLiabilityGLAccount { get; set; }

        /// <summary>
        /// Gets or sets JobsAllocBasedOnCalcBase
        /// </summary>
        [Display(Name = "JobsAllocBasedOnCalcBase", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.JobsAllocBasedOnCalcBase, Id = Index.JobsAllocBasedOnCalcBase, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool JobsAllocBasedOnCalcBase { get; set; }

        /// <summary>
        /// Gets or sets Jobs
        /// </summary>
        [Display(Name = "Jobs", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.Jobs, Id = Index.Jobs, FieldType = EntityFieldType.Long, Size = 4)]
        public int Jobs { get; set; }

        /// <summary>
        /// Gets or sets WorkClassificationCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkClassificationCode", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.WorkClassificationCode, Id = Index.WorkClassificationCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string WorkClassificationCode { get; set; }

        /// <summary>
        /// Gets or sets TotalJobHours
        /// </summary>
        [Display(Name = "TotalJobHours", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.TotalJobHours, Id = Index.TotalJobHours, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 3)]
        public decimal TotalJobHours { get; set; }

        /// <summary>
        /// Gets or sets TotalJobPiecesSalesAmt
        /// </summary>
        [Display(Name = "TotalJobPiecesSalesAmt", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.TotalJobPiecesSalesAmt, Id = Index.TotalJobPiecesSalesAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalJobPiecesSalesAmt { get; set; }

        /// <summary>
        /// Gets or sets EmployerCalculationMethod
        /// </summary>
        [Display(Name = "EmployerCalculationMethod", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.EmployerCalculationMethod, Id = Index.EmployerCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployerCalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets EmployerBaseLimit
        /// </summary>
        [Display(Name = "EmployerBaseLimit", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.EmployerBaseLimit, Id = Index.EmployerBaseLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public short EmployerBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets OverrideEmployerRateAmtPct
        /// </summary>
        [Display(Name = "OverrideEmployerRateAmtPct", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.OverrideEmployerRateAmtPct, Id = Index.OverrideEmployerRateAmtPct, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OverrideEmployerRateAmtPct { get; set; }

        /// <summary>
        /// Gets or sets EmployerRateAmtPct
        /// </summary>
        [Display(Name = "EmployerRateAmtPct", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.EmployerRateAmtPct, Id = Index.EmployerRateAmtPct, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal EmployerRateAmtPct { get; set; }

        /// <summary>
        /// Gets or sets DefaultEmployerRateAmtPct
        /// </summary>
        [Display(Name = "DefaultEmployerRateAmtPct", ResourceType = typeof (TimecardDetailResx))]
        [ViewField(Name = Fields.DefaultEmployerRateAmtPct, Id = Index.DefaultEmployerRateAmtPct, FieldType = EntityFieldType.Decimal, Size = 9, Precision = 5)]
        public decimal DefaultEmployerRateAmtPct { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Category string value
        /// </summary>
        public string CategoryString => EnumUtility.GetStringValue(Category);

        /// <summary>
        /// Gets Type string value
        /// </summary>
        public string TypeString => EnumUtility.GetStringValue(Type);

        /// <summary>
        /// Gets CalculationMethod string value
        /// </summary>
        public string CalculationMethodString => EnumUtility.GetStringValue(CalculationMethod);

        /// <summary>
        /// Gets PayAccrueHours string value
        /// </summary>
        public string PayAccrueHoursString => EnumUtility.GetStringValue(PayAccrueHours);

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

        #endregion
    }
}
