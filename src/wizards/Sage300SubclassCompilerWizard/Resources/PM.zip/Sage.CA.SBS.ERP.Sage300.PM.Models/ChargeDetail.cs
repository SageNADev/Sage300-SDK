// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for ChargeDetail
    /// </summary>
    public partial class ChargeDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (ChargeDetailResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets MyContract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MyContract", ResourceType = typeof(ChargeDetailResx))]
        [ViewField(Name = Fields.MyContract, Id = Index.MyContract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string MyContract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (ChargeDetailResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (ChargeDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (ChargeDetailResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets ChargeCode
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ChargeCode", ResourceType = typeof(ChargeDetailResx))]
        [ViewField(Name = Fields.ChargeCode, Id = Index.ChargeCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ChargeCode { get; set; }

        /// <summary>
        /// Gets or sets DESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DESC", ResourceType = typeof(ChargeDetailResx))]
        [ViewField(Name = Fields.DESC, Id = Index.DESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string DESC { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingType", ResourceType = typeof(ChargeDetailResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public string BillingType { get; set; }

        /// <summary>
        /// Gets or sets BillingAmount
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingAmount", ResourceType = typeof(ChargeDetailResx))]
        [ViewField(Name = Fields.BillingAmount, Id = Index.BillingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public string BillingAmount { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof(ChargeDetailResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof(ChargeDetailResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ChargeDetailResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(ChargeDetailResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        // Is this same as Charge Code description?
        /// <summary>
        /// Gets or sets ITEMDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ITEMDESC, Id = Index.ITEMDESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string ITEMDESC { get; set; }

        /// <summary>
        /// Gets or sets contract description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CONTDESC, Id = Index.CONTDESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string CONTDESC { get; set; }

        /// <summary>
        /// Gets or sets project description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PROJDESC, Id = Index.PROJDESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string PROJDESC { get; set; }

        /// <summary>
        /// Gets or sets category description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CATDESC, Id = Index.CATDESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string CATDESC { get; set; }

        /// <summary>
        /// Gets or sets resource description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RESDESC, Id = Index.RESDESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string RESDESC { get; set; }

        #region UI Strings

        #endregion
    }
}
