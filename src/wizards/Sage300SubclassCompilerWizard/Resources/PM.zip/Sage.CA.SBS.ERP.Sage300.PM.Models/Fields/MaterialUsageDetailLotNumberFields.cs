// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of MaterialUsageDetailLotNumber Constants
    /// </summary>
    public partial class MaterialUsageDetailLotNumber
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0484";


        #region Properties

        /// <summary>
        /// Contains list of MaterialUsageDetailLotNumber Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for FormattedLotNumber
            /// </summary>
            public const string FormattedLotNumber = "LOTNUMF";

            /// <summary>
            /// Property for ExpiryDate
            /// </summary>
            public const string ExpiryDate = "EXPIRYDATE";

            /// <summary>
            /// Property for TransactionQuantity
            /// </summary>
            public const string TransactionQuantity = "QTY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for QTYSQ
            /// </summary>
            public const string QTYSQ = "QTYSQ";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of MaterialUsageDetailLotNumber Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for FormattedLotNumber
            /// </summary>
            public const int FormattedLotNumber = 3;

            /// <summary>
            /// Property Indexer for ExpiryDate
            /// </summary>
            public const int ExpiryDate = 4;

            /// <summary>
            /// Property Indexer for TransactionQuantity
            /// </summary>
            public const int TransactionQuantity = 5;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for QTYSQ
            /// </summary>
            public const int QTYSQ = 6;


        }

        #endregion

    }
}