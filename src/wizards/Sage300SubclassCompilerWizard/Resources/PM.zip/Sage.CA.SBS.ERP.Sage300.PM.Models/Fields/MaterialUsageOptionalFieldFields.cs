// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of MaterialUsageOptionalField Constants
    /// </summary>
    public partial class MaterialUsageOptionalField
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0538";


        #region Properties

        /// <summary>
        /// Contains list of MaterialUsageOptionalField Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for OptionalField
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALUE
            /// </summary>
            public const string VALUE = "VALUE";

            /// <summary>
            /// Property for DataType
            /// </summary>
            public const string DataType = "TYPE";

            /// <summary>
            /// Property for Length
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Decimals
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for AllowBlank
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";

            /// <summary>
            /// Property for Validate
            /// </summary>
            public const string Validate = "VALIDATE";

            /// <summary>
            /// Property for ValueSet
            /// </summary>
            public const string ValueSet = "SWSET";

            /// <summary>
            /// Property for ValueIndex
            /// </summary>
            public const string ValueIndex = "VALINDEX";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALIFTEXT
            /// </summary>
            public const string VALIFTEXT = "VALIFTEXT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALIFMONEY
            /// </summary>
            public const string VALIFMONEY = "VALIFMONEY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALIFNUM
            /// </summary>
            public const string VALIFNUM = "VALIFNUM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALIFLONG
            /// </summary>
            public const string VALIFLONG = "VALIFLONG";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALIFBOOL
            /// </summary>
            public const string VALIFBOOL = "VALIFBOOL";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALIFDATE
            /// </summary>
            public const string VALIFDATE = "VALIFDATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALIFTIME
            /// </summary>
            public const string VALIFTIME = "VALIFTIME";

            /// <summary>
            /// Property for OptionalFieldDescription
            /// </summary>
            public const string OptionalFieldDescription = "FDESC";

            /// <summary>
            /// Property for ValueDescription
            /// </summary>
            public const string ValueDescription = "VDESC";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of MaterialUsageOptionalField Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for OptionalField
            /// </summary>
            public const int OptionalField = 2;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALUE
            /// </summary>
            public const int VALUE = 3;

            /// <summary>
            /// Property Indexer for DataType
            /// </summary>
            public const int DataType = 4;

            /// <summary>
            /// Property Indexer for Length
            /// </summary>
            public const int Length = 5;

            /// <summary>
            /// Property Indexer for Decimals
            /// </summary>
            public const int Decimals = 6;

            /// <summary>
            /// Property Indexer for AllowBlank
            /// </summary>
            public const int AllowBlank = 7;

            /// <summary>
            /// Property Indexer for Validate
            /// </summary>
            public const int Validate = 8;

            /// <summary>
            /// Property Indexer for ValueSet
            /// </summary>
            public const int ValueSet = 9;

            /// <summary>
            /// Property Indexer for ValueIndex
            /// </summary>
            public const int ValueIndex = 20;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALIFTEXT
            /// </summary>
            public const int VALIFTEXT = 21;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALIFMONEY
            /// </summary>
            public const int VALIFMONEY = 22;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALIFNUM
            /// </summary>
            public const int VALIFNUM = 23;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALIFLONG
            /// </summary>
            public const int VALIFLONG = 24;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALIFBOOL
            /// </summary>
            public const int VALIFBOOL = 25;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALIFDATE
            /// </summary>
            public const int VALIFDATE = 26;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALIFTIME
            /// </summary>
            public const int VALIFTIME = 27;

            /// <summary>
            /// Property Indexer for OptionalFieldDescription
            /// </summary>
            public const int OptionalFieldDescription = 28;

            /// <summary>
            /// Property Indexer for ValueDescription
            /// </summary>
            public const int ValueDescription = 29;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 30;


        }

        #endregion

    }
}