// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Reports
{
    /// <summary>
    /// Contains list of TransactionListing Constants
    /// </summary>
    public partial class TransactionListing
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "DFF31E2A-F98A-4303-98C2-55D844470219";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of TransactionListing Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Path
            /// </summary>
            public const string Path = "PATH";

            /// <summary>
            /// Property for Ext
            /// </summary>
            public const string Ext = "EXT";

            /// <summary>
            /// Property for Swoptlic
            /// </summary>
            public const string Swoptlic = "SWOPTLIC";

            /// <summary>
            /// Property for Swicactive
            /// </summary>
            public const string Swicactive = "SWICACTIVE";

            /// <summary>
            /// Property for Swpay
            /// </summary>
            public const string Swpay = "SWPAY";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of TransactionListing Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Path
            /// </summary>
            public const int Path = 2;

            /// <summary>
            /// Property Indexer for Ext
            /// </summary>
            public const int Ext = 3;

            /// <summary>
            /// Property Indexer for Swoptlic
            /// </summary>
            public const int Swoptlic = 4;

            /// <summary>
            /// Property Indexer for Swicactive
            /// </summary>
            public const int Swicactive = 5;

            /// <summary>
            /// Property Indexer for Swpay
            /// </summary>
            public const int Swpay = 6;


        }

        #endregion

    }
}