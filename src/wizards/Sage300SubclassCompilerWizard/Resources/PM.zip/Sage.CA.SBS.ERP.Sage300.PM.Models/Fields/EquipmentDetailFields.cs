﻿// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of UpdateRetainageDetail Constants
    /// </summary>
    public partial class EquipmentDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0031";

        #region Properties

        /// <summary>
        /// Contains list of UpdateRetainageDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for EquipmentNumber
            /// </summary>
            public const string EquipmentNumber = "EQUIPNO";

            /// <summary>
            /// Property for FormattedContractNumber
            /// </summary>
            public const string FormattedContractNumber = "FMTCONTNO";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for EquipmentCode (Resource)
            /// </summary>
            public const string EquipmentCode = "RESOURCE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QUANTITY";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEM";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UOM";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            /// <summary>
            /// Property for ExtendedCostSR
            /// </summary>
            public const string ExtendedCostSR = "EXTCOSTSR";

            /// <summary>
            /// Property for ExtendedCostHM
            /// </summary>
            public const string ExtendedCostHM = "EXTCOSTHM";

            /// <summary>
            /// Property for OverheadType
            /// </summary>
            public const string OverheadType = "OVERHD";

            /// <summary>
            /// Property for OverheadRate
            /// </summary>
            public const string OverheadRate = "OHEADRATE";

            /// <summary>
            /// Property for OverheadPercentage
            /// </summary>
            public const string OverheadPercentage = "HEADPER";

            /// <summary>
            /// Property for OverheadAmountSR
            /// </summary>
            public const string OverheadAmountSR = "OHSR";

            /// <summary>
            /// Property for OverheadAmountHM
            /// </summary>
            public const string OverheadAmountHM = "OHHM";

            /// <summary>
            /// Property for TotalCostSR
            /// </summary>
            public const string TotalCostSR = "TOTCOSTSR";

            /// <summary>
            /// Property for TotalCostHM
            /// </summary>
            public const string TotalCostHM = "TOTCOSTHM";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for OverheadAccount
            /// </summary>
            public const string OverheadAccount = "OHACCT";

            /// <summary>
            /// Property for EquipmentAccount
            /// </summary>
            public const string EquipmentAccount = "EQUIPACCT";

            /// <summary>
            /// Property for WorkInProgressAccount
            /// </summary>
            public const string WorkInProgressAccount = "WIPACCT";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillAmountBasedOn
            /// </summary>
            public const string BillAmountBasedOn = "FIXEDBILL";

            /// <summary>
            /// Property for RevenueAndCostCurrency
            /// </summary>
            public const string RevenueAndCostCurrency = "ESTBILLCCY";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for ExtendedBillingAmountSR
            /// </summary>
            public const string ExtendedBillingAmountSR = "EXTBILLSR";

            /// <summary>
            /// Property for ExtendedBillingAmountHM (Reserved)
            /// </summary>
            public const string ExtendedBillingAmountHM = "EXTBILLHM";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCCY";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TCLASS5";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TINCLUDED1";

            /// <summary>
            /// Property for TaxIncluded2
            /// </summary>
            public const string TaxIncluded2 = "TINCLUDED2";

            /// <summary>
            /// Property for TaxIncluded3
            /// </summary>
            public const string TaxIncluded3 = "TINCLUDED3";

            /// <summary>
            /// Property for TaxIncluded4
            /// </summary>
            public const string TaxIncluded4 = "TINCLUDED4";

            /// <summary>
            /// Property for TaxIncluded5
            /// </summary>
            public const string TaxIncluded5 = "TINCLUDED5";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string ContractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVTYPE";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for GLDetailDescription
            /// </summary>
            public const string GLDetailDescription = "GLDDESC";

            /// <summary>
            /// Property for GLDetailReference
            /// </summary>
            public const string GLDetailReference = "GLDREF";

            /// <summary>
            /// Property for GLDetailComment
            /// </summary>
            public const string GLDetailComment = "GLCOMMENT";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for EADescription
            /// </summary>
            public const string EADescription = "EADESC";

            /// <summary>
            /// Property for WIPDescription
            /// </summary>
            public const string WIPDescription = "WIPDESC";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for ContractDescription
            /// </summary>
            public const string ContractDescription = "CONTDESC";

            /// <summary>
            /// Property for ProjectDescription
            /// </summary>
            public const string ProjectDescription = "PROJDESC";

            /// <summary>
            /// Property for CategoryDescription
            /// </summary>
            public const string CategoryDescription = "CATDESC";

            /// <summary>
            /// Property for HasOptionalFields
            /// </summary>
            public const string HasOptionalFields = "HASOPT";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of UpdateRetainageDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for EquipmentNumber
            /// </summary>
            public const int EquipmentNumber = 3;

            /// <summary>
            /// Property Indexer for FormattedContractNumber
            /// </summary>
            public const int FormattedContractNumber = 4;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 5;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 6;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 7;

            /// <summary>
            /// Property Indexer for EquipmentCode (Resource)
            /// </summary>
            public const int EquipmentCode = 8;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 9;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 10;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 11;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 12;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 13;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 14;

            /// <summary>
            /// Property Indexer for ExtendedCostSR
            /// </summary>
            public const int ExtendedCostSR = 15;

            /// <summary>
            /// Property Indexer for ExtendedCostHM
            /// </summary>
            public const int ExtendedCostHM = 16;

            /// <summary>
            /// Property Indexer for OverheadType
            /// </summary>
            public const int OverheadType = 17;

            /// <summary>
            /// Property Indexer for OverheadRate
            /// </summary>
            public const int OverheadRate = 18;

            /// <summary>
            /// Property Indexer for OverheadPercentage
            /// </summary>
            public const int OverheadPercentage = 19;

            /// <summary>
            /// Property Indexer for OverheadAmountSR
            /// </summary>
            public const int OverheadAmountSR = 20;

            /// <summary>
            /// Property Indexer for OverheadAmountHM
            /// </summary>
            public const int OverheadAmountHM = 21;

            /// <summary>
            /// Property Indexer for TotalCostSR
            /// </summary>
            public const int TotalCostSR = 22;

            /// <summary>
            /// Property Indexer for TotalCostHM
            /// </summary>
            public const int TotalCostHM = 23;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 24;

            /// <summary>
            /// Property Indexer for OverheadAccount
            /// </summary>
            public const int OverheadAccount = 25;

            // TODO - Set correct index numbers below

            /// <summary>
            /// Property Indexer for EquipmentAccount
            /// </summary>
            public const int EquipmentAccount = 26;

            /// <summary>
            /// Property Indexer for WorkInProgressAccount
            /// </summary>
            public const int WorkInProgressAccount = 27;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 28;

            /// <summary>
            /// Property Indexer for BillAmountBasedOn
            /// </summary>
            public const int BillAmountBasedOn = 29;

            /// <summary>
            /// Property Indexer for RevenueAndCostCurrency
            /// </summary>
            public const int RevenueAndCostCurrency = 30;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 31;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmountSR
            /// </summary>
            public const int ExtendedBillingAmountSR = 32;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmountHM
            /// </summary>
            public const int ExtendedBillingAmountHM = 33;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 34;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 35;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 36;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 37;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 38;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 39;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 40;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 41;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 42;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 43;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 44;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 45;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 46;

            /// <summary>
            /// Property Indexer for TaxIncluded2
            /// </summary>
            public const int TaxIncluded2 = 47;

            /// <summary>
            /// Property Indexer for TaxIncluded3
            /// </summary>
            public const int TaxIncluded3 = 48;

            /// <summary>
            /// Property Indexer for TaxIncluded4
            /// </summary>
            public const int TaxIncluded4 = 49;

            /// <summary>
            /// Property Indexer for TaxIncluded5
            /// </summary>
            public const int TaxIncluded5 = 50;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int ContractStyle = 51;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 52;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 53;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 54;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 55;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 56;

            /// <summary>
            /// Property Indexer for GLDetailDescription
            /// </summary>
            public const int GLDetailDescription = 57;

            /// <summary>
            /// Property Indexer for GLDetailReference
            /// </summary>
            public const int GLDetailReference = 58;

            /// <summary>
            /// Property Indexer for GLDetailComment
            /// </summary>
            public const int GLDetailComment = 59;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1001;

            /// <summary>
            /// Property Indexer for EADescription
            /// </summary>
            public const int EADescription = 1003;

            /// <summary>
            /// Property Indexer for WIPDescription
            /// </summary>
            public const int WIPDescription = 1004;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 1005;

            /// <summary>
            /// Property Indexer for ContractDescription
            /// </summary>
            public const int ContractDescription = 1009;

            /// <summary>
            /// Property Indexer for ProjectDescription
            /// </summary>
            public const int ProjectDescription = 1010;

            /// <summary>
            /// Property Indexer for CategoryDescription
            /// </summary>
            public const int CategoryDescription = 1011;

            /// <summary>
            /// Property Indexer for HasOptionalFields
            /// </summary>
            public const int HasOptionalFields = 1012;
        }

        #endregion

    }
}