// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespaces
using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of MaterialAllocationDetail Constants
    /// </summary>
    public partial class MaterialAllocationDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0461";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"LOCATION",    "Location"},
                    {"COSTMETHOD",  "CostMethod"},
                    {"STOCKITEM",   "StockItem"},
                    {"UOM",         "UnitOfMeasure"},
                    {"UNFMTITEM",   "UnformattedItemNumber"},
                    {"QUANTITY",    "AllocatedQuantity"},
                    {"UNITCOST",    "UnitCost"},
                    {"BILLRATE",    "BillingRate"},
                    {"BILLTYPE",    "BillingType"},
                    {"EXTBILLSR",   "ExtendedBillingAmount"},
                    {"EXTBILLHR",   "FunctionalBillingAmount"},
                    {"APERCENT",    "PercentageAllocated"},
                    {"EXTCOSTSR",   "ExtendedCost"},
                    {"EXTCOSTHM",   "ExtendedAllocatedCost"},
                    {"TOTCOSTSR",   "TotalCostSource"},
                    {"TOTCOSTHM",   "TotalCostFunctional"},
                    {"OHHM",        "OverheadAllocated"},
                    {"COMMENTS",    "Comments"},
                    {"CONTSTYLE",   "Style"},
                    {"PROJTYPE",    "ProjectType"},
                    {"CUSTOMER",    "Customer"},
                    {"REVREC",      "AccountingMethod"},
                    {"INVTYPE",     "InvoiceType"},
                    {"VALUES",      "OptionalFields"},
                    {"TRANSDATE",   "TransactionDate"},
                    {"FISCALYEAR",  "FiscalYear"},
                    {"FISCALPER",   "FiscalPeriod"},
                    {"CONVERSION",  "Conversion"},
                    {"STRDCONVER",  "StoredConversionFactor"},
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of MaterialAllocationDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for MaterialAllocationNumber
            /// </summary>
            public const string MaterialAllocationNumber = "MALLOCNO";

            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FormattedContractNumber = "FMTCONTNO";

            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "RESOURCE";

            /// <summary>
            /// Property for DESC
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for CostMethod
            /// </summary>
            public const string CostMethod = "COSTMETHOD";

            /// <summary>
            /// Property for StockItem
            /// </summary>
            public const string StockItem = "STOCKITEM";

            /// <summary>
            /// Property for UOM
            /// </summary>
            public const string UnitOfMeasure = "UOM";

            /// <summary>
            /// Property for UnformattedItemNumber
            /// </summary>
            public const string UnformattedItemNumber = "UNFMTITEM";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for AllocatedQuantity
            /// </summary>
            public const string AllocatedQuantity = "QUANTITY";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for ExtendedBillingAmount
            /// </summary>
            public const string ExtendedBillingAmount = "EXTBILLSR";

            /// <summary>
            /// Property for BillingAmountFunc
            /// </summary>
            public const string FunctionalBillingAmount = "EXTBILLHR";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCCY";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            /// <summary>
            /// Property for PercentageAllocated
            /// </summary>
            public const string PercentageAllocated = "APERCENT";

            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "EXTCOSTSR";

            /// <summary>
            /// Property for ExtendedAllocatedCost
            /// </summary>
            public const string ExtendedAllocatedCost = "EXTCOSTHM";

            /// <summary>
            /// Property for TotalCostSource
            /// </summary>
            public const string TotalCostSource = "TOTCOSTSR";

            /// <summary>
            /// Property for TotalCostFunctional
            /// </summary>
            public const string TotalCostFunctional = "TOTCOSTHM";

            /// <summary>
            /// Property for StoredOverhead
            /// </summary>
            public const string StoredOverhead = "OHSR";

            /// <summary>
            /// Property for OverheadAllocated
            /// </summary>
            public const string OverheadAllocated = "OHHM";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for Style
            /// </summary>
            public const string Style = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVTYPE";

            /// <summary>
            /// Property for VALUES
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for StoredQuantity
            /// </summary>
            public const string StoredQuantity = "STRDQTY";

            /// <summary>
            /// Property for ExtendedStoredCost
            /// </summary>
            public const string ExtendedStoredCost = "STRDCOSTHM";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCALPER";

            /// <summary>
            /// Property for Conversion
            /// </summary>
            public const string Conversion = "CONVERSION";

            /// <summary>
            /// Property for STRDUOM
            /// </summary>
            public const string StoredUnitOfMeasure = "STRDUOM";

            /// <summary>
            /// Property for StoredConversionFactor
            /// </summary>
            public const string StoredConversionFactor = "STRDCONVER";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for LOCDESC
            /// </summary>
            public const string LocationDescription = "LOCDESC";

            /// <summary>
            /// Property for HASOPT
            /// </summary>
            public const string HasOptionalFields = "HASOPT";

            /// <summary>
            /// Property for CONTDESC
            /// </summary>
            public const string ContractDescription = "CONTDESC";

            /// <summary>
            /// Property for PROJDESC
            /// </summary>
            public const string ProjectDescription = "PROJDESC";

            /// <summary>
            /// Property for CATDESC
            /// </summary>
            public const string CategoryDescription = "CATDESC";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of MaterialAllocationDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for MaterialAllocationNumber
            /// </summary>
            public const int MaterialAllocationNumber = 3;

            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FormattedContractNumber = 4;

            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int Contract = 5;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 6;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 7;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 8;

            /// <summary>
            /// Property Indexer for DESC
            /// </summary>
            public const int Description = 9;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 10;

            /// <summary>
            /// Property Indexer for CostMethod
            /// </summary>
            public const int CostMethod = 11;

            /// <summary>
            /// Property Indexer for StockItem
            /// </summary>
            public const int StockItem = 12;

            /// <summary>
            /// Property Indexer for UOM
            /// </summary>
            public const int UnitOfMeasure = 13;

            /// <summary>
            /// Property Indexer for UnformattedItemNumber
            /// </summary>
            public const int UnformattedItemNumber = 14;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 15;

            /// <summary>
            /// Property Indexer for AllocatedQuantity
            /// </summary>
            public const int AllocatedQuantity = 16;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 17;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 18;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 19;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmount
            /// </summary>
            public const int ExtendedBillingAmount = 20;

            /// <summary>
            /// Property Indexer for BillingAmountFunc
            /// </summary>
            public const int FunctionalBillingAmount = 21;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 22;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 23;

            /// <summary>
            /// Property Indexer for PercentageAllocated
            /// </summary>
            public const int PercentageAllocated = 24;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 25;

            /// <summary>
            /// Property Indexer for ExtendedAllocatedCost
            /// </summary>
            public const int ExtendedAllocatedCost = 26;

            /// <summary>
            /// Property Indexer for TotalCostSource
            /// </summary>
            public const int TotalCostSource = 27;

            /// <summary>
            /// Property Indexer for TotalCostFunctional
            /// </summary>
            public const int TotalCostFunctional = 28;

            /// <summary>
            /// Property Indexer for StoredOverhead
            /// </summary>
            public const int StoredOverhead = 32;

            /// <summary>
            /// Property Indexer for OverheadAllocated
            /// </summary>
            public const int OverheadAllocated = 33;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 34;

            /// <summary>
            /// Property Indexer for Style
            /// </summary>
            public const int Style = 35;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 36;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 37;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 38;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 39;

            /// <summary>
            /// Property Indexer for VALUES
            /// </summary>
            public const int OptionalFields = 40;

            /// <summary>
            /// Property Indexer for StoredQuantity
            /// </summary>
            public const int StoredQuantity = 41;

            /// <summary>
            /// Property Indexer for ExtendedStoredCost
            /// </summary>
            public const int ExtendedStoredCost = 42;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 43;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 44;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 45;

            /// <summary>
            /// Property Indexer for Conversion
            /// </summary>
            public const int Conversion = 46;

            /// <summary>
            /// Property Indexer for STRDUOM
            /// </summary>
            public const int StoredUnitOfMeasure = 47;

            /// <summary>
            /// Property Indexer for StoredConversionFactor
            /// </summary>
            public const int StoredConversionFactor = 48;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1001;

            /// <summary>
            /// Property Indexer for LOCDESC
            /// </summary>
            public const int LocationDescription = 1002;

            /// <summary>
            /// Property Indexer for CONTDESC
            /// </summary>
            public const int ContractDescription = 1003;

            /// <summary>
            /// Property Indexer for PROJDESC
            /// </summary>
            public const int ProjectDescription = 1004;

            /// <summary>
            /// Property Indexer for CATDESC
            /// </summary>
            public const int CategoryDescription = 1005;

            /// <summary>
            /// Property Indexer for HASOPT
            /// </summary>
            public const int HasOptionalFields = 1006;
        }

        #endregion

    }
}