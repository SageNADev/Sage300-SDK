/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary> Account Set Constants </summary>
	public partial class AccountSet 
	{
	    /// <summary> View Name </summary>
	    public const string EntityName = "PM0017";

        #region Fields Constants
        /// <summary> Account Set Field Constants </summary>
        public class Fields
        {
            /// <summary> Property for AccountSetCode </summary>
            public const string AccountSetCode = "IDACCTSET";

            /// <summary> Property for Description </summary>
            public const string Description = "TEXTDESC";

            /// <summary> Property for Status </summary>
            public const string Status = "INACTIVE";

            /// <summary> Property for LastMaintained </summary>
            public const string LastMaintained = "DATELASTMN";

            /// <summary> Property for DateInactive </summary>
            public const string DateInactive = "DATEINACTV";

            /// <summary> Property for WorkInProgress </summary>
            public const string WorkInProgress = "WIPACCT";

            /// <summary> Property for CostOfSales </summary>
            public const string CostOfSales = "COSTACCT";

            /// <summary> Property for Billings </summary>
            public const string Billings = "BILLACCT";

            /// <summary> Property for DeferredRevenue </summary>
            public const string DeferredRevenue = "DEFRACCT";

            /// <summary> Property for Revenue </summary>
            public const string Revenue = "REVACCT";

            /// <summary> Property for PayrollExpense </summary>
            public const string PayrollExpense = "PAYACCT";

            /// <summary> Property for Overhead </summary>
            public const string Overhead = "OHACCT";

            /// <summary> Property for Labor </summary>
            public const string Labor = "LABACCT";

            /// <summary> Property for Equipment </summary>
            public const string Equipment = "EQUIPACCT";

            /// <summary> Property for EmployeeExpense </summary>
            public const string EmployeeExpense = "EXPACCT";

            /// <summary> Property for Profit </summary>
            public const string Profit = "PROACCT";

            /// <summary> Property for Loss </summary>
            public const string Loss = "LOSSACCT";

            /// <summary> Property for CurrencyCode </summary>
            public const string CurrencyCode = "CURNCODE";

            /// <summary> Property for Cost </summary>
            public const string Cost = "CEACCT";
	    }
        #endregion
        #region Index Constants
        /// <summary> Account Set Index Constants </summary>
        public class Index
        {
            /// <summary> Property Indexer for AccountSetCode </summary>
            public const int AccountSetCode = 1;

            /// <summary> Property Indexer for Description </summary>
            public const int Description = 2;

            /// <summary> Property Indexer for Status </summary>
            public const int Status = 3;

            /// <summary> Property Indexer for LastMaintained </summary>
            public const int LastMaintained = 4;

            /// <summary> Property Indexer for DateInactive </summary>
            public const int DateInactive = 5;

            /// <summary> Property Indexer for WorkInProgress </summary>
            public const int WorkInProgress = 6;

            /// <summary> Property Indexer for CostOfSales </summary>
            public const int CostOfSales = 7;

            /// <summary> Property Indexer for Billings </summary>
            public const int Billings = 8;

            /// <summary> Property Indexer for DeferredRevenue </summary>
            public const int DeferredRevenue = 9;

            /// <summary> Property Indexer for Revenue </summary>
            public const int Revenue = 10;

            /// <summary> Property Indexer for PayrollExpense </summary>
            public const int PayrollExpense = 11;

            /// <summary> Property Indexer for Overhead </summary>
            public const int Overhead = 12;

            /// <summary> Property Indexer for Labor </summary>
            public const int Labor = 13;

            /// <summary> Property Indexer for Equipment </summary>
            public const int Equipment = 14;

            /// <summary> Property Indexer for EmployeeExpense </summary>
            public const int EmployeeExpense = 15;

            /// <summary> Property Indexer for Profit </summary>
            public const int Profit = 16;

            /// <summary> Property Indexer for Loss </summary>
            public const int Loss = 17;

            /// <summary> Property Indexer for CurrencyCode </summary>
            public const int CurrencyCode = 18;

            /// <summary> Property Indexer for Cost </summary>
            public const int Cost = 19;
	    }
        #endregion
    }
}
	