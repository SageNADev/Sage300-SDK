// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of MaterialReturnDetail Constants
    /// </summary>
    public partial class MaterialReturnDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0047";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"LINENO", "LineNumber"},
                    {"FMTCONTNO", "FormattedContractNumber"},
                    //{"CONTRACT", "CONTRACT"},
                    {"CONTDESC", "ContractDescription"},
                    {"PROJECT", "Project"},
                    {"PROJDESC", "ProjectDescription"},
                    {"CATEGORY", "Category"},
                    {"CATDESC", "CategoryDescription"},
                    {"RESOURCE", "Resource"},
                    {"DESC", "Description"},
                    {"UOM", "ItemUnitOfMeasure"},
                    {"LOCATION", "Location"},
                    {"LOCDESC", "LocationDescription"},
                    {"BILLTYPE", "BillingType"},
                    {"PRICELIST", "PriceList"},
                    {"ARITEM", "ARItemNumber"},
                    {"ARDESC", "ARItemDescription"},
                    {"ARUOM", "ARUnitOfMeasure"},
                    {"QUANTITY", "Quantity"},
                    {"UNITCOST", "UnitCost"},
                    //{"EXTCOSTHM", "ExtendedCostHome"},
                    {"EXTCOSTSR", "ExtendedCost"},
                    {"BILLRATE", "BillingRate"},
                    {"EXTBILLSR", "ExtendedBillingAmount"},
                    {"ICACCT", "ICAccount"},
                    {"ICDESC", "ICAccountDescription"},
                    {"WIPACCT", "WorkInProgressAccount"},
                    {"WIPDESC", "WorkInProgressAccountDescription"},
                    {"COMMENTS", "Comments"},
                    {"TCLASS1", "TaxClass1"},
                    {"TCLASS2", "TaxClass2"},
                    {"TCLASS3", "TaxClass3"},
                    {"TCLASS4", "TaxClass4"},
                    {"TCLASS5", "TaxClass5"},
                    {"TINCLUDED1", "TaxIncluded1"},
                    {"TINCLUDED2", "TaxIncluded2"},
                    {"TINCLUDED3", "TaxIncluded3"},
                    {"TINCLUDED4", "TaxIncluded4"},
                    {"TINCLUDED5", "TaxIncluded5"}
                    //{"UNFMTITEM", "UNFMTITEM"},
                    //{"OHACCT", "OverheadAccount"},
                    //{"OVERHD", "OverheadType"},
                    //{"OHEADRATE", "OverheadRate"},
                    //{"HEADPER", "OverheadPercentage"},
                    //{"OHSR", "OHSR"},
                    //{"OHHM", "OHHM"},
                    //{"PROJTYPE", "ProjectType"},
                    //{"CONTSTYLE", "ContractStyle"},
                    //{"CUSTOMER", "Customer"},
                    //{"REVREC", "AccountingMethod"},
                    //{"INVTYPE", "InvoiceType"},
                    //{"VALUES", "VALUES"},
                    //{"CLOSESN", "CloseSN"},
                    //{"PROID", "SNInterCommunicationID"},
                    //{"POPUPSN", "PopupSN"},
                    //{"POPUPLT", "PopupLT"},
                    //{"CLOSELT", "CloseLT"},
                    //{"LTSETID", "LTInterCommunicationID"},
                    //{"FORCEPOPSN", "ForcePopupSN"},
                    //{"FORCEPOPLT", "ForcePopupLT"},
                    //{"GENICSEQ", "GenerateICSequence"},
                    //{"CUSTCCY", "CustomerCurrency"},
                    //{"SERIALQTY", "NumberOfSerials"},
                    //{"LOTQTY", "NumberOfLots"},
                    //{"PROCESSCMD", "ProcessCommand"},
                    //{"XGENALCQTY", "SerialLotQuantityToProcess"},
                    //{"XLOTMAKQTY", "NumberOfLotsToGenerate"},
                    //{"XPERLOTQTY", "QuantityPerLot"},
                    //{"SALLOCFROM", "AllocateSerialFrom"},
                    //{"LALLOCFROM", "AllocateLotFrom"},
                    //{"METERHWND", "MeterHandle"},
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of MaterialReturnDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for MaterialReturnNumber
            /// </summary>
            public const string MaterialReturnNumber = "MATERIALNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FormattedContractNumber
            /// </summary>
            public const string FormattedContractNumber = "FMTCONTNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string CONTRACT = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QUANTITY";

            /// <summary>
            /// Property for ItemUnitOfMeasure
            /// </summary>
            public const string ItemUnitOfMeasure = "UOM";

            /// <summary>
            /// Property for Conversion
            /// </summary>
            public const string Conversion = "CONVERSION";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ADJUNITCST
            /// </summary>
            public const string ADJUNITCST = "ADJUNITCST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ADJCOST
            /// </summary>
            public const string ADJCOST = "ADJCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for COSTSEQNUM
            /// </summary>
            public const string COSTSEQNUM = "COSTSEQNUM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for COSTDATE
            /// </summary>
            public const string COSTDATE = "COSTDATE";

            /// <summary>
            /// Property for AdditionalCost
            /// </summary>
            public const string AdditionalCost = "ADDCOST";

            /// <summary>
            /// Property for StockItem
            /// </summary>
            public const string StockItem = "STOCKITEM";

            /// <summary>
            /// Property for CostMethod
            /// </summary>
            public const string CostMethod = "COSTMETHOD";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for UNFMTITEM
            /// </summary>
            public const string UNFMTITEM = "UNFMTITEM";

            /// <summary>
            /// Property for CheckBelowZero
            /// </summary>
            public const string CheckBelowZero = "CHKBDLZERO";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "EXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ExtendedCostHome
            /// </summary>
            public const string ExtendedCostHome = "EXTCOSTHM";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for ICAccount
            /// </summary>
            public const string ICAccount = "ICACCT";

            /// <summary>
            /// Property for WorkInProgressAccount
            /// </summary>
            public const string WorkInProgressAccount = "WIPACCT";

            /// <summary>
            /// Property for OverheadAccount
            /// </summary>
            public const string OverheadAccount = "OHACCT";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillAmountBasedOn
            /// </summary>
            public const string BillAmountBasedOn = "FIXEDBILL";

            /// <summary>
            /// Property for RevenueAndCostCurrency
            /// </summary>
            public const string RevenueAndCostCurrency = "ESTBILLCCY";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for ExtendedBillingAmount
            /// </summary>
            public const string ExtendedBillingAmount = "EXTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTCOSTSR
            /// </summary>
            public const string TOTCOSTSR = "TOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTCOSTHM
            /// </summary>
            public const string TOTCOSTHM = "TOTCOSTHM";

            /// <summary>
            /// Property for OverheadType
            /// </summary>
            public const string OverheadType = "OVERHD";

            /// <summary>
            /// Property for OverheadRate
            /// </summary>
            public const string OverheadRate = "OHEADRATE";

            /// <summary>
            /// Property for OverheadPercentage
            /// </summary>
            public const string OverheadPercentage = "HEADPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OHSR
            /// </summary>
            public const string OHSR = "OHSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OHHM
            /// </summary>
            public const string OHHM = "OHHM";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCCY";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEM";

            /// <summary>
            /// Property for ARUnitOfMeasure
            /// </summary>
            public const string ARUnitOfMeasure = "ARUOM";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TCLASS5";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TINCLUDED1";

            /// <summary>
            /// Property for TaxIncluded2
            /// </summary>
            public const string TaxIncluded2 = "TINCLUDED2";

            /// <summary>
            /// Property for TaxIncluded3
            /// </summary>
            public const string TaxIncluded3 = "TINCLUDED3";

            /// <summary>
            /// Property for TaxIncluded4
            /// </summary>
            public const string TaxIncluded4 = "TINCLUDED4";

            /// <summary>
            /// Property for TaxIncluded5
            /// </summary>
            public const string TaxIncluded5 = "TINCLUDED5";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string ContractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALUES
            /// </summary>
            public const string VALUES = "VALUES";

            /// <summary>
            /// Property for CloseSN
            /// </summary>
            public const string CloseSN = "CLOSESN";

            /// <summary>
            /// Property for SNInterCommunicationID
            /// </summary>
            public const string SNInterCommunicationID = "PROID";

            /// <summary>
            /// Property for PopupSN
            /// </summary>
            public const string PopupSN = "POPUPSN";

            /// <summary>
            /// Property for PopupLT
            /// </summary>
            public const string PopupLT = "POPUPLT";

            /// <summary>
            /// Property for CloseLT
            /// </summary>
            public const string CloseLT = "CLOSELT";

            /// <summary>
            /// Property for LTInterCommunicationID
            /// </summary>
            public const string LTInterCommunicationID = "LTSETID";

            /// <summary>
            /// Property for ForcePopupSN
            /// </summary>
            public const string ForcePopupSN = "FORCEPOPSN";

            /// <summary>
            /// Property for ForcePopupLT
            /// </summary>
            public const string ForcePopupLT = "FORCEPOPLT";

            /// <summary>
            /// Property for GenerateICSequence
            /// </summary>
            public const string GenerateICSequence = "GENICSEQ";

            /// <summary>
            /// Property for PriceList
            /// </summary>
            public const string PriceList = "PRICELIST";

            /// <summary>
            /// Property for CustomerCurrency
            /// </summary>
            public const string CustomerCurrency = "CUSTCCY";

            /// <summary>
            /// Property for NumberOfSerials
            /// </summary>
            public const string NumberOfSerials = "SERIALQTY";

            /// <summary>
            /// Property for NumberOfLots
            /// </summary>
            public const string NumberOfLots = "LOTQTY";

            /// <summary>
            /// Property for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Property for SerialLotQuantityToProcess
            /// </summary>
            public const string SerialLotQuantityToProcess = "XGENALCQTY";

            /// <summary>
            /// Property for NumberOfLotsToGenerate
            /// </summary>
            public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

            /// <summary>
            /// Property for QuantityPerLot
            /// </summary>
            public const string QuantityPerLot = "XPERLOTQTY";

            /// <summary>
            /// Property for AllocateSerialFrom
            /// </summary>
            public const string AllocateSerialFrom = "SALLOCFROM";

            /// <summary>
            /// Property for AllocateLotFrom
            /// </summary>
            public const string AllocateLotFrom = "LALLOCFROM";

            /// <summary>
            /// Property for MeterHandle
            /// </summary>
            public const string MeterHandle = "METERHWND";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ICAccountDescription
            /// </summary>
            public const string ICAccountDescription = "ICDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for WorkInProgressAccountDescription
            /// </summary>
            public const string WorkInProgressAccountDescription = "WIPDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for LocationDescription
            /// </summary>
            public const string LocationDescription = "LOCDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ARItemDescription
            /// </summary>
            public const string ARItemDescription = "ARDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OHDESC
            /// </summary>
            public const string OHDESC = "OHDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for HasOptionalFields
            /// </summary>
            public const string HasOptionalFields = "HASOPT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ContractDescription
            /// </summary>
            public const string ContractDescription = "CONTDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ProjectDescription
            /// </summary>
            public const string ProjectDescription = "PROJDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CategoryDescription
            /// </summary>
            public const string CategoryDescription = "CATDESC";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of MaterialReturnDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for MaterialReturnNumber
            /// </summary>
            public const int MaterialReturnNumber = 3;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FormattedContractNumber
            /// </summary>
            public const int FormattedContractNumber = 4;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int CONTRACT = 5;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 6;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 7;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 8;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 9;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 10;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 11;

            /// <summary>
            /// Property Indexer for ItemUnitOfMeasure
            /// </summary>
            public const int ItemUnitOfMeasure = 12;

            /// <summary>
            /// Property Indexer for Conversion
            /// </summary>
            public const int Conversion = 13;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 14;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ADJUNITCST
            /// </summary>
            public const int ADJUNITCST = 15;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ADJCOST
            /// </summary>
            public const int ADJCOST = 16;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for COSTSEQNUM
            /// </summary>
            public const int COSTSEQNUM = 17;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for COSTDATE
            /// </summary>
            public const int COSTDATE = 18;

            /// <summary>
            /// Property Indexer for AdditionalCost
            /// </summary>
            public const int AdditionalCost = 19;

            /// <summary>
            /// Property Indexer for StockItem
            /// </summary>
            public const int StockItem = 20;

            /// <summary>
            /// Property Indexer for CostMethod
            /// </summary>
            public const int CostMethod = 21;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for UNFMTITEM
            /// </summary>
            public const int UNFMTITEM = 22;

            /// <summary>
            /// Property Indexer for CheckBelowZero
            /// </summary>
            public const int CheckBelowZero = 23;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 24;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 25;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ExtendedCostHome
            /// </summary>
            public const int ExtendedCostHome = 26;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 27;

            /// <summary>
            /// Property Indexer for ICAccount
            /// </summary>
            public const int ICAccount = 28;

            /// <summary>
            /// Property Indexer for WorkInProgressAccount
            /// </summary>
            public const int WorkInProgressAccount = 29;

            /// <summary>
            /// Property Indexer for OverheadAccount
            /// </summary>
            public const int OverheadAccount = 30;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 31;

            /// <summary>
            /// Property Indexer for BillAmountBasedOn
            /// </summary>
            public const int BillAmountBasedOn = 32;

            /// <summary>
            /// Property Indexer for RevenueAndCostCurrency
            /// </summary>
            public const int RevenueAndCostCurrency = 33;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 34;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmount
            /// </summary>
            public const int ExtendedBillingAmount = 35;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTCOSTSR
            /// </summary>
            public const int TOTCOSTSR = 37;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTCOSTHM
            /// </summary>
            public const int TOTCOSTHM = 38;

            /// <summary>
            /// Property Indexer for OverheadType
            /// </summary>
            public const int OverheadType = 39;

            /// <summary>
            /// Property Indexer for OverheadRate
            /// </summary>
            public const int OverheadRate = 40;

            /// <summary>
            /// Property Indexer for OverheadPercentage
            /// </summary>
            public const int OverheadPercentage = 41;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OHSR
            /// </summary>
            public const int OHSR = 42;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OHHM
            /// </summary>
            public const int OHHM = 43;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 44;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 45;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 46;

            /// <summary>
            /// Property Indexer for ARUnitOfMeasure
            /// </summary>
            public const int ARUnitOfMeasure = 47;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 48;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 49;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 50;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 51;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 52;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 53;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 54;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 55;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 56;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 57;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 58;

            /// <summary>
            /// Property Indexer for TaxIncluded2
            /// </summary>
            public const int TaxIncluded2 = 59;

            /// <summary>
            /// Property Indexer for TaxIncluded3
            /// </summary>
            public const int TaxIncluded3 = 60;

            /// <summary>
            /// Property Indexer for TaxIncluded4
            /// </summary>
            public const int TaxIncluded4 = 61;

            /// <summary>
            /// Property Indexer for TaxIncluded5
            /// </summary>
            public const int TaxIncluded5 = 62;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 63;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int ContractStyle = 64;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 65;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 66;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 67;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALUES
            /// </summary>
            public const int VALUES = 68;

            /// <summary>
            /// Property Indexer for CloseSN
            /// </summary>
            public const int CloseSN = 69;

            /// <summary>
            /// Property Indexer for SNInterCommunicationID
            /// </summary>
            public const int SNInterCommunicationID = 70;

            /// <summary>
            /// Property Indexer for PopupSN
            /// </summary>
            public const int PopupSN = 71;

            /// <summary>
            /// Property Indexer for PopupLT
            /// </summary>
            public const int PopupLT = 72;

            /// <summary>
            /// Property Indexer for CloseLT
            /// </summary>
            public const int CloseLT = 73;

            /// <summary>
            /// Property Indexer for LTInterCommunicationID
            /// </summary>
            public const int LTInterCommunicationID = 74;

            /// <summary>
            /// Property Indexer for ForcePopupSN
            /// </summary>
            public const int ForcePopupSN = 75;

            /// <summary>
            /// Property Indexer for ForcePopupLT
            /// </summary>
            public const int ForcePopupLT = 76;

            /// <summary>
            /// Property Indexer for GenerateICSequence
            /// </summary>
            public const int GenerateICSequence = 77;

            /// <summary>
            /// Property Indexer for PriceList
            /// </summary>
            public const int PriceList = 78;

            /// <summary>
            /// Property Indexer for CustomerCurrency
            /// </summary>
            public const int CustomerCurrency = 79;

            /// <summary>
            /// Property Indexer for NumberOfSerials
            /// </summary>
            public const int NumberOfSerials = 80;

            /// <summary>
            /// Property Indexer for NumberOfLots
            /// </summary>
            public const int NumberOfLots = 81;

            /// <summary>
            /// Property Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 1012;

            /// <summary>
            /// Property Indexer for SerialLotQuantityToProcess
            /// </summary>
            public const int SerialLotQuantityToProcess = 1013;

            /// <summary>
            /// Property Indexer for NumberOfLotsToGenerate
            /// </summary>
            public const int NumberOfLotsToGenerate = 1014;

            /// <summary>
            /// Property Indexer for QuantityPerLot
            /// </summary>
            public const int QuantityPerLot = 1015;

            /// <summary>
            /// Property Indexer for AllocateSerialFrom
            /// </summary>
            public const int AllocateSerialFrom = 1016;

            /// <summary>
            /// Property Indexer for AllocateLotFrom
            /// </summary>
            public const int AllocateLotFrom = 1017;

            /// <summary>
            /// Property Indexer for MeterHandle
            /// </summary>
            public const int MeterHandle = 1018;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1001;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ICAccountDescription
            /// </summary>
            public const int ICAccountDescription = 1003;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for WorkInProgressAccountDescription
            /// </summary>
            public const int WorkInProgressAccountDescription = 1004;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for LocationDescription
            /// </summary>
            public const int LocationDescription = 1006;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ARItemDescription
            /// </summary>
            public const int ARItemDescription = 1005;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OHDESC
            /// </summary>
            public const int OHDESC = 1007;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for HasOptionalFields
            /// </summary>
            public const int HasOptionalFields = 1011;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ContractDescription
            /// </summary>
            public const int ContractDescription = 1008;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ProjectDescription
            /// </summary>
            public const int ProjectDescription = 1009;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CategoryDescription
            /// </summary>
            public const int CategoryDescription = 1010;


        }

        #endregion

    }
}