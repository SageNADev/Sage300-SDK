// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of TimecardExpenseDetail Constants
    /// </summary>
    public partial class TimecardExpenseDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0113";


        #region Properties

        /// <summary>
        /// Contains list of TimecardExpenseDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for TimecardNumber
            /// </summary>
            public const string TimecardNumber = "TIMECARDNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FMTCONTNO = "FMTCONTNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string CONTRACT = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for ExpenseCode
            /// </summary>
            public const string ExpenseCode = "EXPENSE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for DESC
            /// </summary>
            public const string DESC = "DESC";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TDATE";

            /// <summary>
            /// Property for ExpenseType
            /// </summary>
            public const string ExpenseType = "EXPTYPE";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QUANTITY";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEM";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UOM";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCCY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for UNITCOST
            /// </summary>
            public const string UNITCOST = "UNITCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EXTCOSTSR
            /// </summary>
            public const string EXTCOSTSR = "EXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EXTCOSTHM
            /// </summary>
            public const string EXTCOSTHM = "EXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EXTBILLSR
            /// </summary>
            public const string EXTBILLSR = "EXTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for BILLRATE
            /// </summary>
            public const string BILLRATE = "BILLRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTCOSTSR
            /// </summary>
            public const string TOTCOSTSR = "TOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTCOSTHM
            /// </summary>
            public const string TOTCOSTHM = "TOTCOSTHM";

            /// <summary>
            /// Property for TotalBillableAmount
            /// </summary>
            public const string TotalBillableAmount = "TOTBILLSR";

            /// <summary>
            /// Property for EmployeeExpenseAccount
            /// </summary>
            public const string EmployeeExpenseAccount = "EXPACCT";

            /// <summary>
            /// Property for WorkInProgressAccount
            /// </summary>
            public const string WorkInProgressAccount = "WIPACCT";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for BillAmountBasedOn
            /// </summary>
            public const string BillAmountBasedOn = "FIXEDBILL";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TCLASS5";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TINCLUDED1";

            /// <summary>
            /// Property for TaxIncluded2
            /// </summary>
            public const string TaxIncluded2 = "TINCLUDED2";

            /// <summary>
            /// Property for TaxIncluded3
            /// </summary>
            public const string TaxIncluded3 = "TINCLUDED3";

            /// <summary>
            /// Property for TaxIncluded4
            /// </summary>
            public const string TaxIncluded4 = "TINCLUDED4";

            /// <summary>
            /// Property for TaxIncluded5
            /// </summary>
            public const string TaxIncluded5 = "TINCLUDED5";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string ContractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALUES
            /// </summary>
            public const string VALUES = "VALUES";

            /// <summary>
            /// Property for GLDetailDescription
            /// </summary>
            public const string GLDetailDescription = "GLDDESC";

            /// <summary>
            /// Property for GLDetailReference
            /// </summary>
            public const string GLDetailReference = "GLDREF";

            /// <summary>
            /// Property for GLDetailComment
            /// </summary>
            public const string GLDetailComment = "GLCOMMENT";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "TYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RESDESC
            /// </summary>
            public const string RESDESC = "RESDESC";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EXPDESC
            /// </summary>
            public const string EXPDESC = "EXPDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for WIPDESC
            /// </summary>
            public const string WIPDESC = "WIPDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ITEMDESC
            /// </summary>
            public const string ITEMDESC = "ITEMDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTDESC
            /// </summary>
            public const string CONTDESC = "CONTDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PROJDESC
            /// </summary>
            public const string PROJDESC = "PROJDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CATDESC
            /// </summary>
            public const string CATDESC = "CATDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for HASOPT
            /// </summary>
            public const string HASOPT = "HASOPT";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of TimecardExpenseDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for TimecardNumber
            /// </summary>
            public const int TimecardNumber = 3;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FMTCONTNO = 4;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int CONTRACT = 5;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 6;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 7;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 8;

            /// <summary>
            /// Property Indexer for ExpenseCode
            /// </summary>
            public const int ExpenseCode = 9;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for DESC
            /// </summary>
            public const int DESC = 10;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 11;

            /// <summary>
            /// Property Indexer for ExpenseType
            /// </summary>
            public const int ExpenseType = 12;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 13;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 14;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 15;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 16;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 17;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 18;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for UNITCOST
            /// </summary>
            public const int UNITCOST = 19;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EXTCOSTSR
            /// </summary>
            public const int EXTCOSTSR = 20;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EXTCOSTHM
            /// </summary>
            public const int EXTCOSTHM = 21;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EXTBILLSR
            /// </summary>
            public const int EXTBILLSR = 22;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for BILLRATE
            /// </summary>
            public const int BILLRATE = 34;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTCOSTSR
            /// </summary>
            public const int TOTCOSTSR = 35;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTCOSTHM
            /// </summary>
            public const int TOTCOSTHM = 36;

            /// <summary>
            /// Property Indexer for TotalBillableAmount
            /// </summary>
            public const int TotalBillableAmount = 37;

            /// <summary>
            /// Property Indexer for EmployeeExpenseAccount
            /// </summary>
            public const int EmployeeExpenseAccount = 39;

            /// <summary>
            /// Property Indexer for WorkInProgressAccount
            /// </summary>
            public const int WorkInProgressAccount = 40;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 43;

            /// <summary>
            /// Property Indexer for BillAmountBasedOn
            /// </summary>
            public const int BillAmountBasedOn = 44;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 45;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 46;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 47;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 48;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 49;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 50;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 51;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 52;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 53;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 54;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 55;

            /// <summary>
            /// Property Indexer for TaxIncluded2
            /// </summary>
            public const int TaxIncluded2 = 56;

            /// <summary>
            /// Property Indexer for TaxIncluded3
            /// </summary>
            public const int TaxIncluded3 = 57;

            /// <summary>
            /// Property Indexer for TaxIncluded4
            /// </summary>
            public const int TaxIncluded4 = 58;

            /// <summary>
            /// Property Indexer for TaxIncluded5
            /// </summary>
            public const int TaxIncluded5 = 59;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 60;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int ContractStyle = 61;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 62;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 63;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 64;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALUES
            /// </summary>
            public const int VALUES = 65;

            /// <summary>
            /// Property Indexer for GLDetailDescription
            /// </summary>
            public const int GLDetailDescription = 66;

            /// <summary>
            /// Property Indexer for GLDetailReference
            /// </summary>
            public const int GLDetailReference = 67;

            /// <summary>
            /// Property Indexer for GLDetailComment
            /// </summary>
            public const int GLDetailComment = 68;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 69;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 70;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RESDESC
            /// </summary>
            public const int RESDESC = 71;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1001;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EXPDESC
            /// </summary>
            public const int EXPDESC = 1002;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for WIPDESC
            /// </summary>
            public const int WIPDESC = 1003;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ITEMDESC
            /// </summary>
            public const int ITEMDESC = 1004;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTDESC
            /// </summary>
            public const int CONTDESC = 1009;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PROJDESC
            /// </summary>
            public const int PROJDESC = 1010;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CATDESC
            /// </summary>
            public const int CATDESC = 1011;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for HASOPT
            /// </summary>
            public const int HASOPT = 1012;


        }

        #endregion

    }
}