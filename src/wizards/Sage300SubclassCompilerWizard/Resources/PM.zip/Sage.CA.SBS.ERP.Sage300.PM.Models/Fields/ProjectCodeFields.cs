// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of ProjectCode Constants
    /// </summary>
    public partial class ProjectCode
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0006";


        #region Properties

        /// <summary>
        /// Contains list of ProjectCode Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "INACTIVE";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for DateInactive
            /// </summary>
            public const string DateInactive = "DATEINACTV";

            /// <summary>
            /// Property for Project123Type
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for CostPlusPercentage
            /// </summary>
            public const string CostPlusPercentage = "COSTPLUSP";

            /// <summary>
            /// Property for ClosedForBillings
            /// </summary>
            public const string ClosedForBillings = "CLOSEBILL";

            /// <summary>
            /// Property for ClosedForCost
            /// </summary>
            public const string ClosedForCost = "CLOSECOST";

            /// <summary>
            /// Property for RevenueType
            /// </summary>
            public const string RevenueType = "USEDEFREV";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for ARRetainagePercentage
            /// </summary>
            public const string ARRetainagePercentage = "RETAR";

            /// <summary>
            /// Property for ARRetentionPeriod
            /// </summary>
            public const string ARRetentionPeriod = "RETDAYSAR";

            /// <summary>
            /// Property for OverrideGLAccountSegments
            /// </summary>
            public const string OverrideGLAccountSegments = "SEGOVERRD";

            /// <summary>
            /// Property for Segment1
            /// </summary>
            public const string Segment1 = "SEGNUM1";

            /// <summary>
            /// Property for SegmentCode1
            /// </summary>
            public const string SegmentCode1 = "SEGVAL1";

            /// <summary>
            /// Property for Segment2
            /// </summary>
            public const string Segment2 = "SEGNUM2";

            /// <summary>
            /// Property for SegmentCode2
            /// </summary>
            public const string SegmentCode2 = "SEGVAL2";

            /// <summary>
            /// Property for Segment3
            /// </summary>
            public const string Segment3 = "SEGNUM3";

            /// <summary>
            /// Property for SegmentCode3
            /// </summary>
            public const string SegmentCode3 = "SEGVAL3";

            /// <summary>
            /// Property for Segment4
            /// </summary>
            public const string Segment4 = "SEGNUM4";

            /// <summary>
            /// Property for SegmentCode4
            /// </summary>
            public const string SegmentCode4 = "SEGVAL4";

            /// <summary>
            /// Property for Segment5
            /// </summary>
            public const string Segment5 = "SEGNUM5";

            /// <summary>
            /// Property for SegmentCode5
            /// </summary>
            public const string SegmentCode5 = "SEGVAL5";

            /// <summary>
            /// Property for Segment6
            /// </summary>
            public const string Segment6 = "SEGNUM6";

            /// <summary>
            /// Property for SegmentCode6
            /// </summary>
            public const string SegmentCode6 = "SEGVAL6";

            /// <summary>
            /// Property for Segment7
            /// </summary>
            public const string Segment7 = "SEGNUM7";

            /// <summary>
            /// Property for SegmentCode7
            /// </summary>
            public const string SegmentCode7 = "SEGVAL7";

            /// <summary>
            /// Property for Segment8
            /// </summary>
            public const string Segment8 = "SEGNUM8";

            /// <summary>
            /// Property for SegmentCode8
            /// </summary>
            public const string SegmentCode8 = "SEGVAL8";

            /// <summary>
            /// Property for Segment9
            /// </summary>
            public const string Segment9 = "SEGNUM9";

            /// <summary>
            /// Property for SegmentCode9
            /// </summary>
            public const string SegmentCode9 = "SEGVAL9";

            /// <summary>
            /// Property for FormCode
            /// </summary>
            public const string FormCode = "FORMCODE";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of ProjectCode Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Project123
            /// </summary>
            public const int Project = 1;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 3;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 4;

            /// <summary>
            /// Property Indexer for DateInactive
            /// </summary>
            public const int DateInactive = 5;

            /// <summary>
            /// Property Indexer for Project123Type
            /// </summary>
            public const int ProjectType = 6;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 7;

            /// <summary>
            /// Property Indexer for CostPlusPercentage
            /// </summary>
            public const int CostPlusPercentage = 8;

            /// <summary>
            /// Property Indexer for ClosedForBillings
            /// </summary>
            public const int ClosedForBillings = 9;

            /// <summary>
            /// Property Indexer for ClosedForCost
            /// </summary>
            public const int ClosedForCost = 10;

            /// <summary>
            /// Property Indexer for RevenueType
            /// </summary>
            public const int RevenueType = 11;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 12;

            /// <summary>
            /// Property Indexer for ARRetainagePercentage
            /// </summary>
            public const int ARRetainagePercentage = 13;

            /// <summary>
            /// Property Indexer for ARRetentionPeriod
            /// </summary>
            public const int ARRetentionPeriod = 14;

            /// <summary>
            /// Property Indexer for OverrideGLAccountSegments
            /// </summary>
            public const int OverrideGLAccountSegments = 15;

            /// <summary>
            /// Property Indexer for Segment1
            /// </summary>
            public const int Segment1 = 16;

            /// <summary>
            /// Property Indexer for SegmentCode1
            /// </summary>
            public const int SegmentCode1 = 17;

            /// <summary>
            /// Property Indexer for Segment2
            /// </summary>
            public const int Segment2 = 18;

            /// <summary>
            /// Property Indexer for SegmentCode2
            /// </summary>
            public const int SegmentCode2 = 19;

            /// <summary>
            /// Property Indexer for Segment3
            /// </summary>
            public const int Segment3 = 20;

            /// <summary>
            /// Property Indexer for SegmentCode3
            /// </summary>
            public const int SegmentCode3 = 21;

            /// <summary>
            /// Property Indexer for Segment4
            /// </summary>
            public const int Segment4 = 22;

            /// <summary>
            /// Property Indexer for SegmentCode4
            /// </summary>
            public const int SegmentCode4 = 23;

            /// <summary>
            /// Property Indexer for Segment5
            /// </summary>
            public const int Segment5 = 24;

            /// <summary>
            /// Property Indexer for SegmentCode5
            /// </summary>
            public const int SegmentCode5 = 25;

            /// <summary>
            /// Property Indexer for Segment6
            /// </summary>
            public const int Segment6 = 26;

            /// <summary>
            /// Property Indexer for SegmentCode6
            /// </summary>
            public const int SegmentCode6 = 27;

            /// <summary>
            /// Property Indexer for Segment7
            /// </summary>
            public const int Segment7 = 28;

            /// <summary>
            /// Property Indexer for SegmentCode7
            /// </summary>
            public const int SegmentCode7 = 29;

            /// <summary>
            /// Property Indexer for Segment8
            /// </summary>
            public const int Segment8 = 30;

            /// <summary>
            /// Property Indexer for SegmentCode8
            /// </summary>
            public const int SegmentCode8 = 31;

            /// <summary>
            /// Property Indexer for Segment9
            /// </summary>
            public const int Segment9 = 32;

            /// <summary>
            /// Property Indexer for SegmentCode9
            /// </summary>
            public const int SegmentCode9 = 33;

            /// <summary>
            /// Property Indexer for FormCode
            /// </summary>
            public const int FormCode = 34;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 36;


        }

        #endregion

    }
}