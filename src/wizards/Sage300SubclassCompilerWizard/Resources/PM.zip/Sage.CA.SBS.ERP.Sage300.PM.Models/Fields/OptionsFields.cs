// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of Options Constants
    /// </summary>
    public partial class Options
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0003";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of Options Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Dummy
            /// </summary>
            public const string Dummy = "IDOPT01";

            /// <summary>
            /// Property for ContactName
            /// </summary>
            public const string ContactName = "CONTACT";

            /// <summary>
            /// Property for Telephone
            /// </summary>
            public const string Telephone = "PHONE";

            /// <summary>
            /// Property for FaxNumber
            /// </summary>
            public const string FaxNumber = "FAX";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for Multicurrency
            /// </summary>
            public const string Multicurrency = "MULTICURR";

            /// <summary>
            /// Property for HomeCurrency
            /// </summary>
            public const string HomeCurrency = "HOMECURR";

            /// <summary>
            /// Property for DefaultOverheadType
            /// </summary>
            public const string DefaultOverheadType = "DEFOVERHD";

            /// <summary>
            /// Property for OverheadRate
            /// </summary>
            public const string OverheadRate = "OHEADRATE";

            /// <summary>
            /// Property for OverheadPercentage
            /// </summary>
            public const string OverheadPercentage = "HEADPER";

            /// <summary>
            /// Property for DefaultLaborType
            /// </summary>
            public const string DefaultLaborType = "DEFLABOR";

            /// <summary>
            /// Property for LaborRate
            /// </summary>
            public const string LaborRate = "LABORRATE";

            /// <summary>
            /// Property for LaborPercentage
            /// </summary>
            public const string LaborPercentage = "LABORPER";

            /// <summary>
            /// Property for EditImportedBatches
            /// </summary>
            public const string EditImportedBatches = "SWEDITIMPT";

            /// <summary>
            /// Property for ForceListingOfTransactions
            /// </summary>
            public const string ForceListingOfTransactions = "SWFRCLST";

            /// <summary>
            /// Property for DefaultAccountingMethod
            /// </summary>
            public const string DefaultAccountingMethod = "DEFREVREC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PAYROLL
            /// </summary>
            public const string PAYROLL = "PAYROLL";

            /// <summary>
            /// Property for CreateGLTransactions
            /// </summary>
            public const string CreateGLTransactions = "DEFERGLPST";

            /// <summary>
            /// Property for AppendGLBatch
            /// </summary>
            public const string AppendGLBatch = "APPENDGL";

            /// <summary>
            /// Property for ConsolidateGLBatches
            /// </summary>
            public const string ConsolidateGLBatches = "CONSOLGL";

            /// <summary>
            /// Property for GLReferenceFieldNotUsed
            /// </summary>
            public const string GLReferenceFieldNotUsed = "CODEGLREF";

            /// <summary>
            /// Property for GLDescriptionFieldNotUsed
            /// </summary>
            public const string GLDescriptionFieldNotUsed = "CODEGLDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for NXTCHRGSEQ
            /// </summary>
            public const string NXTCHRGSEQ = "NXTCHRGSEQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for NXTEQIPSEQ
            /// </summary>
            public const string NXTEQIPSEQ = "NXTEQIPSEQ";

            /// <summary>
            /// Property for ReviseEstimates
            /// </summary>
            public const string ReviseEstimates = "NXTCHNGSEQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for NXTCARDSEQ
            /// </summary>
            public const string NXTCARDSEQ = "NXTCARDSEQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for NXTRRSEQ
            /// </summary>
            public const string NXTRRSEQ = "NXTRRSEQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for NXTADJSEQ
            /// </summary>
            public const string NXTADJSEQ = "NXTADJSEQ";

            /// <summary>
            /// Property for Cost
            /// </summary>
            public const string Cost = "COSTBTCH";

            /// <summary>
            /// Property for Invoice
            /// </summary>
            public const string Invoice = "INVBTCH";

            /// <summary>
            /// Property for Timecard
            /// </summary>
            public const string Timecard = "TCARDBTCH";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for STKABTCH
            /// </summary>
            public const string STKABTCH = "STKABTCH";

            /// <summary>
            /// Property for MaterialReturn
            /// </summary>
            public const string MaterialReturn = "STKRBTCH";

            /// <summary>
            /// Property for ProjectAndJobCosting
            /// </summary>
            public const string ProjectAndJobCosting = "PMSC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for STKALLSC
            /// </summary>
            public const string STKALLSC = "STKALLSC";

            /// <summary>
            /// Property for MaterialReturns
            /// </summary>
            public const string MaterialReturns = "STKRETSC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TIMECARDSC
            /// </summary>
            public const string TIMECARDSC = "TIMECARDSC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RRSC
            /// </summary>
            public const string RRSC = "RRSC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EQUIPSC
            /// </summary>
            public const string EQUIPSC = "EQUIPSC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CHRGSC
            /// </summary>
            public const string CHRGSC = "CHRGSC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ADJSC
            /// </summary>
            public const string ADJSC = "ADJSC";

            /// <summary>
            /// Property for DefaultARRetainagePercentage
            /// </summary>
            public const string DefaultARRetainagePercentage = "RETAR";

            /// <summary>
            /// Property for DefaultARRetainageNoOfDays
            /// </summary>
            public const string DefaultARRetainageNoOfDays = "RETDAYSAR";

            /// <summary>
            /// Property for DefaultAPRetainagePercentage
            /// </summary>
            public const string DefaultAPRetainagePercentage = "RETAP";

            /// <summary>
            /// Property for DefaultAPRetainageNoOfDays
            /// </summary>
            public const string DefaultAPRetainageNoOfDays = "RETDAYSAP";

            /// <summary>
            /// Property for DateLastRevenueRecognition
            /// </summary>
            public const string DateLastRevenueRecognition = "DATELASTRR";

            /// <summary>
            /// Property for TimeLastRevenueRecognition
            /// </summary>
            public const string TimeLastRevenueRecognition = "TIMELASTRR";

            /// <summary>
            /// Property for DateLastBillingWorksheet
            /// </summary>
            public const string DateLastBillingWorksheet = "DATELASTBB";

            /// <summary>
            /// Property for DateLastMaterialUsage
            /// </summary>
            public const string DateLastMaterialUsage = "DATELASTAL";

            /// <summary>
            /// Property for DateLastMaterialReturn
            /// </summary>
            public const string DateLastMaterialReturn = "DATELASTRE";

            /// <summary>
            /// Property for DateLastTimecard
            /// </summary>
            public const string DateLastTimecard = "DATELASTTC";

            /// <summary>
            /// Property for DateLastCostBatchPosted
            /// </summary>
            public const string DateLastCostBatchPosted = "DATELASTCS";

            /// <summary>
            /// Property for DateLastInvoiceBatchPosted
            /// </summary>
            public const string DateLastInvoiceBatchPosted = "DATELASTIN";

            /// <summary>
            /// Property for DateLastChargesPosted
            /// </summary>
            public const string DateLastChargesPosted = "DATELASTCH";

            /// <summary>
            /// Property for DateLastEquipmentUsage
            /// </summary>
            public const string DateLastEquipmentUsage = "DATELASTEU";

            /// <summary>
            /// Property for DateLastRevisedEstimatesPost
            /// </summary>
            public const string DateLastRevisedEstimatesPost = "DATELASTES";

            /// <summary>
            /// Property for AllowEditOfGLCodesInAR
            /// </summary>
            public const string AllowEditOfGLCodesInAR = "ARGLEDIT";

            /// <summary>
            /// Property for AllowEditOfGLCodesInAP
            /// </summary>
            public const string AllowEditOfGLCodesInAP = "APGLEDIT";

            /// <summary>
            /// Property for AgingPeriod1
            /// </summary>
            public const string AgingPeriod1 = "AGINPERD1";

            /// <summary>
            /// Property for AgingPeriod2
            /// </summary>
            public const string AgingPeriod2 = "AGINPERD2";

            /// <summary>
            /// Property for AgingPeriod3
            /// </summary>
            public const string AgingPeriod3 = "AGINPERD3";

            /// <summary>
            /// Property for Level1Name
            /// </summary>
            public const string Level1Name = "LEVEL1NAME";

            /// <summary>
            /// Property for Level2Name
            /// </summary>
            public const string Level2Name = "LEVEL2NAME";

            /// <summary>
            /// Property for Level3Name
            /// </summary>
            public const string Level3Name = "LEVEL3NAME";

            /// <summary>
            /// Property for DefaultContractStructure
            /// </summary>
            public const string DefaultContractStructure = "DEFSTRUCT";

            /// <summary>
            /// Property for UseHypen
            /// </summary>
            public const string UseHypen = "HYPEN";

            /// <summary>
            /// Property for UseForwardSlash
            /// </summary>
            public const string UseForwardSlash = "FWDSLASH";

            /// <summary>
            /// Property for UseBackSlash
            /// </summary>
            public const string UseBackSlash = "BCKSLASH";

            /// <summary>
            /// Property for UseAsterisk
            /// </summary>
            public const string UseAsterisk = "ASTERISK";

            /// <summary>
            /// Property for UsePeriod
            /// </summary>
            public const string UsePeriod = "PERIOD";

            /// <summary>
            /// Property for UseLeftParenthesis
            /// </summary>
            public const string UseLeftParenthesis = "LFTPARENS";

            /// <summary>
            /// Property for UseRightParenthesis
            /// </summary>
            public const string UseRightParenthesis = "RGTPARENS";

            /// <summary>
            /// Property for UsePoundSign
            /// </summary>
            public const string UsePoundSign = "POUNDSGN";

            /// <summary>
            /// Property for TimeCardPrefix
            /// </summary>
            public const string TimeCardPrefix = "TEXTTCPF";

            /// <summary>
            /// Property for TimecardNumberLength
            /// </summary>
            public const string TimecardNumberLength = "CNTTCPFLEN";

            /// <summary>
            /// Property for NextTimecardNumber
            /// </summary>
            public const string NextTimecardNumber = "CNTTCSEQ";

            /// <summary>
            /// Property for MaterialUsagePrefix
            /// </summary>
            public const string MaterialUsagePrefix = "TEXTSAPF";

            /// <summary>
            /// Property for MaterialUsageNumberLength
            /// </summary>
            public const string MaterialUsageNumberLength = "CNTSAPFLEN";

            /// <summary>
            /// Property for NextMaterialUsageNumber
            /// </summary>
            public const string NextMaterialUsageNumber = "CNTSASEQ";

            /// <summary>
            /// Property for MaterialReturnPrefix
            /// </summary>
            public const string MaterialReturnPrefix = "TEXTSRPF";

            /// <summary>
            /// Property for MaterialReturnNumberLength
            /// </summary>
            public const string MaterialReturnNumberLength = "CNTSRPFLEN";

            /// <summary>
            /// Property for NextMaterialReturnsNumber
            /// </summary>
            public const string NextMaterialReturnsNumber = "CNTSRSEQ";

            /// <summary>
            /// Property for EquipmentUsagePrefix
            /// </summary>
            public const string EquipmentUsagePrefix = "TEXTEQPF";

            /// <summary>
            /// Property for EquipmentUsageNumberLength
            /// </summary>
            public const string EquipmentUsageNumberLength = "CNTEQPFLEN";

            /// <summary>
            /// Property for NextEquipmentUsageNumber
            /// </summary>
            public const string NextEquipmentUsageNumber = "CNTEQSEQ";

            /// <summary>
            /// Property for RevisedEstimatePrefix
            /// </summary>
            public const string RevisedEstimatePrefix = "TEXTCOPF";

            /// <summary>
            /// Property for RevisedEstimateNumberLength
            /// </summary>
            public const string RevisedEstimateNumberLength = "CNTCOPFLEN";

            /// <summary>
            /// Property for NextRevisedEstimateNumber
            /// </summary>
            public const string NextRevisedEstimateNumber = "CNTCOSEQ";

            /// <summary>
            /// Property for ChargePrefix
            /// </summary>
            public const string ChargePrefix = "TEXTCHRGPF";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TEXTADJPF
            /// </summary>
            public const string TEXTADJPF = "TEXTADJPF";

            /// <summary>
            /// Property for AdjustmentNumberLength
            /// </summary>
            public const string AdjustmentNumberLength = "CNTADJLEN";

            /// <summary>
            /// Property for NextAdjustmentNumber
            /// </summary>
            public const string NextAdjustmentNumber = "CNTADJSEQ";

            /// <summary>
            /// Property for ChargeNumberLength
            /// </summary>
            public const string ChargeNumberLength = "CNTCHRGLEN";

            /// <summary>
            /// Property for NextChargeNumber
            /// </summary>
            public const string NextChargeNumber = "CNTCHRGSEQ";

            /// <summary>
            /// Property for NextContractUnique
            /// </summary>
            public const string NextContractUnique = "NEXTCTUNIQ";

            /// <summary>
            /// Property for ARBilling
            /// </summary>
            public const string ARBilling = "CNTBBSEQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CNTRRSEQ
            /// </summary>
            public const string CNTRRSEQ = "CNTRRSEQ";

            /// <summary>
            /// Property for ARBillingPrefix
            /// </summary>
            public const string ARBillingPrefix = "TEXTBBPF";

            /// <summary>
            /// Property for RevenueRecognitionPrefix
            /// </summary>
            public const string RevenueRecognitionPrefix = "TEXTRRPF";

            /// <summary>
            /// Property for ARBillingLength
            /// </summary>
            public const string ARBillingLength = "CNTBBLEN";

            /// <summary>
            /// Property for RevenueRecognitionLength
            /// </summary>
            public const string RevenueRecognitionLength = "CNTRRLEN";

            /// <summary>
            /// Property for AllowEditOfProjectType
            /// </summary>
            public const string AllowEditOfProjectType = "PROJTYPE";

            /// <summary>
            /// Property for DefaultARItemNumber
            /// </summary>
            public const string DefaultARItemNumber = "ARITEM";

            /// <summary>
            /// Property for DefaultARUnitOfMeasure
            /// </summary>
            public const string DefaultARUnitOfMeasure = "ARUOM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PAYROLLTC
            /// </summary>
            public const string PAYROLLTC = "PAYROLLTC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for GLEQIPSEQ
            /// </summary>
            public const string GLEQIPSEQ = "GLEQIPSEQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for GLCARDSEQ
            /// </summary>
            public const string GLCARDSEQ = "GLCARDSEQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for GLRRSEQ
            /// </summary>
            public const string GLRRSEQ = "GLRRSEQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for GLADJSEQ
            /// </summary>
            public const string GLADJSEQ = "GLADJSEQ";

            /// <summary>
            /// Property for Level1NamePlural
            /// </summary>
            public const string Level1NamePlural = "LEVEL4NAME";

            /// <summary>
            /// Property for Level2NamePlural
            /// </summary>
            public const string Level2NamePlural = "LEVEL5NAME";

            /// <summary>
            /// Property for Level3NamePlural
            /// </summary>
            public const string Level3NamePlural = "LEVEL6NAME";

            /// <summary>
            /// Property for Costs
            /// </summary>
            public const string Costs = "CESC";

            /// <summary>
            /// Property for ReopenProjects
            /// </summary>
            public const string ReopenProjects = "ROSC";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DRIVERID";

            /// <summary>
            /// Property for DecimalsForMaterialQuantity
            /// </summary>
            public const string DecimalsForMaterialQuantity = "FRACTQTY";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Options Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Dummy
            /// </summary>
            public const int Dummy = 1;

            /// <summary>
            /// Property Indexer for ContactName
            /// </summary>
            public const int ContactName = 2;

            /// <summary>
            /// Property Indexer for Telephone
            /// </summary>
            public const int Telephone = 3;

            /// <summary>
            /// Property Indexer for FaxNumber
            /// </summary>
            public const int FaxNumber = 4;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 5;

            /// <summary>
            /// Property Indexer for Multicurrency
            /// </summary>
            public const int Multicurrency = 6;

            /// <summary>
            /// Property Indexer for HomeCurrency
            /// </summary>
            public const int HomeCurrency = 7;

            /// <summary>
            /// Property Indexer for DefaultOverheadType
            /// </summary>
            public const int DefaultOverheadType = 8;

            /// <summary>
            /// Property Indexer for OverheadRate
            /// </summary>
            public const int OverheadRate = 9;

            /// <summary>
            /// Property Indexer for OverheadPercentage
            /// </summary>
            public const int OverheadPercentage = 10;

            /// <summary>
            /// Property Indexer for DefaultLaborType
            /// </summary>
            public const int DefaultLaborType = 11;

            /// <summary>
            /// Property Indexer for LaborRate
            /// </summary>
            public const int LaborRate = 12;

            /// <summary>
            /// Property Indexer for LaborPercentage
            /// </summary>
            public const int LaborPercentage = 13;

            /// <summary>
            /// Property Indexer for EditImportedBatches
            /// </summary>
            public const int EditImportedBatches = 14;

            /// <summary>
            /// Property Indexer for ForceListingOfTransactions
            /// </summary>
            public const int ForceListingOfTransactions = 15;

            /// <summary>
            /// Property Indexer for DefaultAccountingMethod
            /// </summary>
            public const int DefaultAccountingMethod = 16;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PAYROLL
            /// </summary>
            public const int PAYROLL = 17;

            /// <summary>
            /// Property Indexer for CreateGLTransactions
            /// </summary>
            public const int CreateGLTransactions = 18;

            /// <summary>
            /// Property Indexer for AppendGLBatch
            /// </summary>
            public const int AppendGLBatch = 19;

            /// <summary>
            /// Property Indexer for ConsolidateGLBatches
            /// </summary>
            public const int ConsolidateGLBatches = 20;

            /// <summary>
            /// Property Indexer for GLReferenceFieldNotUsed
            /// </summary>
            public const int GLReferenceFieldNotUsed = 21;

            /// <summary>
            /// Property Indexer for GLDescriptionFieldNotUsed
            /// </summary>
            public const int GLDescriptionFieldNotUsed = 22;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for NXTCHRGSEQ
            /// </summary>
            public const int NXTCHRGSEQ = 23;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for NXTEQIPSEQ
            /// </summary>
            public const int NXTEQIPSEQ = 24;

            /// <summary>
            /// Property Indexer for ReviseEstimates
            /// </summary>
            public const int ReviseEstimates = 25;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for NXTCARDSEQ
            /// </summary>
            public const int NXTCARDSEQ = 26;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for NXTRRSEQ
            /// </summary>
            public const int NXTRRSEQ = 29;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for NXTADJSEQ
            /// </summary>
            public const int NXTADJSEQ = 30;

            /// <summary>
            /// Property Indexer for Cost
            /// </summary>
            public const int Cost = 31;

            /// <summary>
            /// Property Indexer for Invoice
            /// </summary>
            public const int Invoice = 32;

            /// <summary>
            /// Property Indexer for Timecard
            /// </summary>
            public const int Timecard = 33;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for STKABTCH
            /// </summary>
            public const int STKABTCH = 34;

            /// <summary>
            /// Property Indexer for MaterialReturn
            /// </summary>
            public const int MaterialReturn = 35;

            /// <summary>
            /// Property Indexer for ProjectAndJobCosting
            /// </summary>
            public const int ProjectAndJobCosting = 36;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for STKALLSC
            /// </summary>
            public const int STKALLSC = 37;

            /// <summary>
            /// Property Indexer for MaterialReturns
            /// </summary>
            public const int MaterialReturns = 38;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TIMECARDSC
            /// </summary>
            public const int TIMECARDSC = 39;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RRSC
            /// </summary>
            public const int RRSC = 40;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EQUIPSC
            /// </summary>
            public const int EQUIPSC = 41;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CHRGSC
            /// </summary>
            public const int CHRGSC = 42;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ADJSC
            /// </summary>
            public const int ADJSC = 43;

            /// <summary>
            /// Property Indexer for DefaultARRetainagePercentage
            /// </summary>
            public const int DefaultARRetainagePercentage = 44;

            /// <summary>
            /// Property Indexer for DefaultARRetainageNoOfDays
            /// </summary>
            public const int DefaultARRetainageNoOfDays = 45;

            /// <summary>
            /// Property Indexer for DefaultAPRetainagePercentage
            /// </summary>
            public const int DefaultAPRetainagePercentage = 46;

            /// <summary>
            /// Property Indexer for DefaultAPRetainageNoOfDays
            /// </summary>
            public const int DefaultAPRetainageNoOfDays = 47;

            /// <summary>
            /// Property Indexer for DateLastRevenueRecognition
            /// </summary>
            public const int DateLastRevenueRecognition = 48;

            /// <summary>
            /// Property Indexer for TimeLastRevenueRecognition
            /// </summary>
            public const int TimeLastRevenueRecognition = 49;

            /// <summary>
            /// Property Indexer for DateLastBillingWorksheet
            /// </summary>
            public const int DateLastBillingWorksheet = 50;

            /// <summary>
            /// Property Indexer for DateLastMaterialUsage
            /// </summary>
            public const int DateLastMaterialUsage = 51;

            /// <summary>
            /// Property Indexer for DateLastMaterialReturn
            /// </summary>
            public const int DateLastMaterialReturn = 52;

            /// <summary>
            /// Property Indexer for DateLastTimecard
            /// </summary>
            public const int DateLastTimecard = 53;

            /// <summary>
            /// Property Indexer for DateLastCostBatchPosted
            /// </summary>
            public const int DateLastCostBatchPosted = 54;

            /// <summary>
            /// Property Indexer for DateLastInvoiceBatchPosted
            /// </summary>
            public const int DateLastInvoiceBatchPosted = 55;

            /// <summary>
            /// Property Indexer for DateLastChargesPosted
            /// </summary>
            public const int DateLastChargesPosted = 56;

            /// <summary>
            /// Property Indexer for DateLastEquipmentUsage
            /// </summary>
            public const int DateLastEquipmentUsage = 57;

            /// <summary>
            /// Property Indexer for DateLastRevisedEstimatesPost
            /// </summary>
            public const int DateLastRevisedEstimatesPost = 58;

            /// <summary>
            /// Property Indexer for AllowEditOfGLCodesInAR
            /// </summary>
            public const int AllowEditOfGLCodesInAR = 59;

            /// <summary>
            /// Property Indexer for AllowEditOfGLCodesInAP
            /// </summary>
            public const int AllowEditOfGLCodesInAP = 60;

            /// <summary>
            /// Property Indexer for AgingPeriod1
            /// </summary>
            public const int AgingPeriod1 = 61;

            /// <summary>
            /// Property Indexer for AgingPeriod2
            /// </summary>
            public const int AgingPeriod2 = 62;

            /// <summary>
            /// Property Indexer for AgingPeriod3
            /// </summary>
            public const int AgingPeriod3 = 63;

            /// <summary>
            /// Property Indexer for Level1Name
            /// </summary>
            public const int Level1Name = 64;

            /// <summary>
            /// Property Indexer for Level2Name
            /// </summary>
            public const int Level2Name = 65;

            /// <summary>
            /// Property Indexer for Level3Name
            /// </summary>
            public const int Level3Name = 66;

            /// <summary>
            /// Property Indexer for DefaultContractStructure
            /// </summary>
            public const int DefaultContractStructure = 67;

            /// <summary>
            /// Property Indexer for UseHypen
            /// </summary>
            public const int UseHypen = 68;

            /// <summary>
            /// Property Indexer for UseForwardSlash
            /// </summary>
            public const int UseForwardSlash = 69;

            /// <summary>
            /// Property Indexer for UseBackSlash
            /// </summary>
            public const int UseBackSlash = 70;

            /// <summary>
            /// Property Indexer for UseAsterisk
            /// </summary>
            public const int UseAsterisk = 71;

            /// <summary>
            /// Property Indexer for UsePeriod
            /// </summary>
            public const int UsePeriod = 72;

            /// <summary>
            /// Property Indexer for UseLeftParenthesis
            /// </summary>
            public const int UseLeftParenthesis = 73;

            /// <summary>
            /// Property Indexer for UseRightParenthesis
            /// </summary>
            public const int UseRightParenthesis = 74;

            /// <summary>
            /// Property Indexer for UsePoundSign
            /// </summary>
            public const int UsePoundSign = 75;

            /// <summary>
            /// Property Indexer for TimeCardPrefix
            /// </summary>
            public const int TimeCardPrefix = 76;

            /// <summary>
            /// Property Indexer for TimecardNumberLength
            /// </summary>
            public const int TimecardNumberLength = 77;

            /// <summary>
            /// Property Indexer for NextTimecardNumber
            /// </summary>
            public const int NextTimecardNumber = 78;

            /// <summary>
            /// Property Indexer for MaterialUsagePrefix
            /// </summary>
            public const int MaterialUsagePrefix = 79;

            /// <summary>
            /// Property Indexer for MaterialUsageNumberLength
            /// </summary>
            public const int MaterialUsageNumberLength = 80;

            /// <summary>
            /// Property Indexer for NextMaterialUsageNumber
            /// </summary>
            public const int NextMaterialUsageNumber = 81;

            /// <summary>
            /// Property Indexer for MaterialReturnPrefix
            /// </summary>
            public const int MaterialReturnPrefix = 82;

            /// <summary>
            /// Property Indexer for MaterialReturnNumberLength
            /// </summary>
            public const int MaterialReturnNumberLength = 83;

            /// <summary>
            /// Property Indexer for NextMaterialReturnsNumber
            /// </summary>
            public const int NextMaterialReturnsNumber = 84;

            /// <summary>
            /// Property Indexer for EquipmentUsagePrefix
            /// </summary>
            public const int EquipmentUsagePrefix = 85;

            /// <summary>
            /// Property Indexer for EquipmentUsageNumberLength
            /// </summary>
            public const int EquipmentUsageNumberLength = 86;

            /// <summary>
            /// Property Indexer for NextEquipmentUsageNumber
            /// </summary>
            public const int NextEquipmentUsageNumber = 87;

            /// <summary>
            /// Property Indexer for RevisedEstimatePrefix
            /// </summary>
            public const int RevisedEstimatePrefix = 88;

            /// <summary>
            /// Property Indexer for RevisedEstimateNumberLength
            /// </summary>
            public const int RevisedEstimateNumberLength = 89;

            /// <summary>
            /// Property Indexer for NextRevisedEstimateNumber
            /// </summary>
            public const int NextRevisedEstimateNumber = 90;

            /// <summary>
            /// Property Indexer for ChargePrefix
            /// </summary>
            public const int ChargePrefix = 91;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TEXTADJPF
            /// </summary>
            public const int TEXTADJPF = 92;

            /// <summary>
            /// Property Indexer for AdjustmentNumberLength
            /// </summary>
            public const int AdjustmentNumberLength = 93;

            /// <summary>
            /// Property Indexer for NextAdjustmentNumber
            /// </summary>
            public const int NextAdjustmentNumber = 94;

            /// <summary>
            /// Property Indexer for ChargeNumberLength
            /// </summary>
            public const int ChargeNumberLength = 95;

            /// <summary>
            /// Property Indexer for NextChargeNumber
            /// </summary>
            public const int NextChargeNumber = 96;

            /// <summary>
            /// Property Indexer for NextContractUnique
            /// </summary>
            public const int NextContractUnique = 97;

            /// <summary>
            /// Property Indexer for ARBilling
            /// </summary>
            public const int ARBilling = 98;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CNTRRSEQ
            /// </summary>
            public const int CNTRRSEQ = 99;

            /// <summary>
            /// Property Indexer for ARBillingPrefix
            /// </summary>
            public const int ARBillingPrefix = 100;

            /// <summary>
            /// Property Indexer for RevenueRecognitionPrefix
            /// </summary>
            public const int RevenueRecognitionPrefix = 101;

            /// <summary>
            /// Property Indexer for ARBillingLength
            /// </summary>
            public const int ARBillingLength = 102;

            /// <summary>
            /// Property Indexer for RevenueRecognitionLength
            /// </summary>
            public const int RevenueRecognitionLength = 103;

            /// <summary>
            /// Property Indexer for AllowEditOfProjectType
            /// </summary>
            public const int AllowEditOfProjectType = 104;

            /// <summary>
            /// Property Indexer for DefaultARItemNumber
            /// </summary>
            public const int DefaultARItemNumber = 105;

            /// <summary>
            /// Property Indexer for DefaultARUnitOfMeasure
            /// </summary>
            public const int DefaultARUnitOfMeasure = 106;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PAYROLLTC
            /// </summary>
            public const int PAYROLLTC = 107;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for GLEQIPSEQ
            /// </summary>
            public const int GLEQIPSEQ = 109;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for GLCARDSEQ
            /// </summary>
            public const int GLCARDSEQ = 111;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for GLRRSEQ
            /// </summary>
            public const int GLRRSEQ = 114;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for GLADJSEQ
            /// </summary>
            public const int GLADJSEQ = 115;

            /// <summary>
            /// Property Indexer for Level1NamePlural
            /// </summary>
            public const int Level1NamePlural = 116;

            /// <summary>
            /// Property Indexer for Level2NamePlural
            /// </summary>
            public const int Level2NamePlural = 117;

            /// <summary>
            /// Property Indexer for Level3NamePlural
            /// </summary>
            public const int Level3NamePlural = 118;

            /// <summary>
            /// Property Indexer for Costs
            /// </summary>
            public const int Costs = 119;

            /// <summary>
            /// Property Indexer for ReopenProjects
            /// </summary>
            public const int ReopenProjects = 120;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 1000;

            /// <summary>
            /// Property Indexer for DecimalsForMaterialQuantity
            /// </summary>
            public const int DecimalsForMaterialQuantity = 1001;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1002;


        }

        #endregion

    }
}