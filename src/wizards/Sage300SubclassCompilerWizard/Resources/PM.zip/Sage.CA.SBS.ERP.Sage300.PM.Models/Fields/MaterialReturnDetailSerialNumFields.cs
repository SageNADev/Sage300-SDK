// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of MaterialReturnDetailSerialNum Constants
    /// </summary>
    public partial class MaterialReturnDetailSerialNum
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0485";


        #region Properties

        /// <summary>
        /// Contains list of MaterialReturnDetailSerialNum Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for FormattedSerialNumber
            /// </summary>
            public const string FormattedSerialNumber = "SERIALNUMF";

            /// <summary>
            /// Property for SerialQuantity
            /// </summary>
            public const string SerialQuantity = "SCOUNT";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of MaterialReturnDetailSerialNum Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for FormattedSerialNumber
            /// </summary>
            public const int FormattedSerialNumber = 3;

            /// <summary>
            /// Property Indexer for SerialQuantity
            /// </summary>
            public const int SerialQuantity = 50;


        }

        #endregion

    }
}