// Copyright (c) 2019 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of OpeningBalancesDetail Constants
    /// </summary>
    public partial class OpeningBalancesDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0402";


        #region Properties

        /// <summary>
        /// Contains list of OpeningBalancesDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "DOCNUM";

            /// <summary>
            /// Property for OpeningType
            /// </summary>
            public const string OpeningType = "OPENTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FMTCONTNO = "FMTCONTNO";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "Contract";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for ActualType
            /// </summary>
            public const string ActualType = "COSTREV";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for CostType
            /// </summary>
            public const string CostType = "COSTTYPE";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for CustomerCurrency
            /// </summary>
            public const string CustomerCurrency = "BILLCCY";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for RateOperation
            /// </summary>
            public const string RateOperation = "RATEOP";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for Rate
            /// </summary>
            public const string Rate = "RATE";

            /// <summary>
            /// Property for RateSpread
            /// </summary>
            public const string RateSpread = "RATESPREAD";

            /// <summary>
            /// Property for OriginalQuantity
            /// </summary>
            public const string OriginalQuantity = "OQTY";

            /// <summary>
            /// Property for ActualQuantity
            /// </summary>
            public const string ActualQuantity = "AQTY";

            /// <summary>
            /// Property for OriginalARItemNumber
            /// </summary>
            public const string OriginalARItemNumber = "OARITEM";

            /// <summary>
            /// Property for OriginalARUnitOfMeasure
            /// </summary>
            public const string OriginalARUnitOfMeasure = "OARUOM";

            /// <summary>
            /// Property for OriginalUnitCost
            /// </summary>
            public const string OriginalUnitCost = "OUNITCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OEXTCOSTSR
            /// </summary>
            public const string OEXTCOSTSR = "OEXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OEXTCOSTHM
            /// </summary>
            public const string OEXTCOSTHM = "OEXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for AEXTCOSTSR
            /// </summary>
            public const string AEXTCOSTSR = "AEXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for AEXTCOSTHM
            /// </summary>
            public const string AEXTCOSTHM = "AEXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OOHTYPE
            /// </summary>
            public const string OOHTYPE = "OOHTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OOHRATE
            /// </summary>
            public const string OOHRATE = "OOHRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OOHPER
            /// </summary>
            public const string OOHPER = "OOHPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OOHSR
            /// </summary>
            public const string OOHSR = "OOHSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OOHHM
            /// </summary>
            public const string OOHHM = "OOHHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for AOHSR
            /// </summary>
            public const string AOHSR = "AOHSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for AOHHM
            /// </summary>
            public const string AOHHM = "AOHHM";

            /// <summary>
            /// Property for LaborType
            /// </summary>
            public const string LaborType = "OLABORTYPE";

            /// <summary>
            /// Property for LaborRate
            /// </summary>
            public const string LaborRate = "OLABORRATE";

            /// <summary>
            /// Property for LaborPercentage
            /// </summary>
            public const string LaborPercentage = "OLABORPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OLABORSR
            /// </summary>
            public const string OLABORSR = "OLABORSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OLABORHM
            /// </summary>
            public const string OLABORHM = "OLABORHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ALABORSR
            /// </summary>
            public const string ALABORSR = "ALABORSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ALABORHM
            /// </summary>
            public const string ALABORHM = "ALABORHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OTOTCOSTSR
            /// </summary>
            public const string OTOTCOSTSR = "OTOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OTOTCOSTHM
            /// </summary>
            public const string OTOTCOSTHM = "OTOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ATOTCOSTSR
            /// </summary>
            public const string ATOTCOSTSR = "ATOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ATOTCOSTHM
            /// </summary>
            public const string ATOTCOSTHM = "ATOTCOSTHM";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "OBILLTYPE";

            /// <summary>
            /// Property for OriginalBillingRate
            /// </summary>
            public const string OriginalBillingRate = "OBILLRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OBILLSR
            /// </summary>
            public const string OBILLSR = "OBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OBILLHM
            /// </summary>
            public const string OBILLHM = "OBILLHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ABILLSR
            /// </summary>
            public const string ABILLSR = "ABILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ABILLHM
            /// </summary>
            public const string ABILLHM = "ABILLHM";

            /// <summary>
            /// Property for RemainingToBeBilled
            /// </summary>
            public const string RemainingToBeBilled = "RBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OPROFITSR
            /// </summary>
            public const string OPROFITSR = "OPROFITSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OPROFITHM
            /// </summary>
            public const string OPROFITHM = "OPROFITHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for APROFITSR
            /// </summary>
            public const string APROFITSR = "APROFITSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for APROFITHM
            /// </summary>
            public const string APROFITHM = "APROFITHM";

            /// <summary>
            /// Property for TotalARCustomerReceipts
            /// </summary>
            public const string TotalARCustomerReceipts = "TARRECTSSR";

            /// <summary>
            /// Property for LastARReceiptPostingDate
            /// </summary>
            public const string LastARReceiptPostingDate = "ARRECDATE";

            /// <summary>
            /// Property for TotalAPVendorPayments
            /// </summary>
            public const string TotalAPVendorPayments = "TAPPAYMTS";

            /// <summary>
            /// Property for LastAPPaymentPostingDate
            /// </summary>
            public const string LastAPPaymentPostingDate = "APPAYDATE";

            /// <summary>
            /// Property for LastCostPostingDate
            /// </summary>
            public const string LastCostPostingDate = "COSTDATE";

            /// <summary>
            /// Property for LastBillingsPostingDate
            /// </summary>
            public const string LastBillingsPostingDate = "BILLDATE";

            /// <summary>
            /// Property for LastRevRecognitionPostingDate
            /// </summary>
            public const string LastRevRecognitionPostingDate = "REVRECDATE";

            /// <summary>
            /// Property for LastRevisedPostingDate
            /// </summary>
            public const string LastRevisedPostingDate = "REVESTDATE";

            /// <summary>
            /// Property for LastBillingsPercentComplete
            /// </summary>
            public const string LastBillingsPercentComplete = "LSTBILLPER";

            /// <summary>
            /// Property for LastPurchaseOrderDate
            /// </summary>
            public const string LastPurchaseOrderDate = "PODATE";

            /// <summary>
            /// Property for LastPOReceiptDate
            /// </summary>
            public const string LastPOReceiptDate = "PORECDATE";

            /// <summary>
            /// Property for LastPOReturnDate
            /// </summary>
            public const string LastPOReturnDate = "PORETDATE";

            /// <summary>
            /// Property for LastCanadianPayrollPostingDate
            /// </summary>
            public const string LastCanadianPayrollPostingDate = "PLSTPDATCP";

            /// <summary>
            /// Property for LastUSPayrollPostingDate
            /// </summary>
            public const string LastUSPayrollPostingDate = "PLSTPDATUP";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVTYPE";

            /// <summary>
            /// Property for Reversed
            /// </summary>
            public const string Reversed = "REVERSED";

            /// <summary>
            /// Property for StoredQuantity
            /// </summary>
            public const string StoredQuantity = "STRDQTY";

            /// <summary>
            /// Property for StoredCost
            /// </summary>
            public const string StoredCost = "STRDCOSTHM";

            /// <summary>
            /// Property for StoredBillableAmount
            /// </summary>
            public const string StoredBillableAmount = "STRDBILLSR";

            /// <summary>
            /// Property for PreviousCompletedWork
            /// </summary>
            public const string PreviousCompletedWork = "PRECOLEDSR";

            /// <summary>
            /// Property for OverheadAmount
            /// </summary>
            public const string OverheadAmount = "STRDOHHM";

            /// <summary>
            /// Property for TotalStoredCost
            /// </summary>
            public const string TotalStoredCost = "STRDTCSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for COHTYPE
            /// </summary>
            public const string COHTYPE = "COHTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for COHRATE
            /// </summary>
            public const string COHRATE = "COHRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for COHPER
            /// </summary>
            public const string COHPER = "COHPER";

            /// <summary>
            /// Property for UseAIAReport
            /// </summary>
            public const string UseAIAReport = "USEAIA";

            /// <summary>
            /// Property for PreviousCertificatesForPaymen
            /// </summary>
            public const string PreviousCertificatesForPaymen = "PREAIAPAY";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCALPER";

            /// <summary>
            /// Property for G703ColumnFFromLastAIARepo
            /// </summary>
            public const string G703ColumnFFromLastAIARepo = "PRESTORED";

            /// <summary>
            /// Property for G703ColumnIFromLastAIARepo
            /// </summary>
            public const string G703ColumnIFromLastAIARepo = "PRERETAIN";

            /// <summary>
            /// Property for LastOEShipmentDate
            /// </summary>
            public const string LastOEShipmentDate = "OESHPDATE";

            /// <summary>
            /// Property for LastOEInvoiceDate
            /// </summary>
            public const string LastOEInvoiceDate = "OEINVDATE";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTDESC
            /// </summary>
            public const string CONTDESC = "CONTDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PROJDESC
            /// </summary>
            public const string PROJDESC = "PROJDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CATDESC
            /// </summary>
            public const string CATDESC = "CATDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RESDESC
            /// </summary>
            public const string RESDESC = "RESDESC";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of OpeningBalancesDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 3;

            /// <summary>
            /// Property Indexer for OpeningType
            /// </summary>
            public const int OpeningType = 4;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FMTCONTNO = 5;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 6;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 7;

            /// <summary>
            /// Property Indexer for ActualType
            /// </summary>
            public const int ActualType = 8;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 9;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 10;

            /// <summary>
            /// Property Indexer for CostType
            /// </summary>
            public const int CostType = 11;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 12;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 13;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 14;

            /// <summary>
            /// Property Indexer for CustomerCurrency
            /// </summary>
            public const int CustomerCurrency = 15;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 16;

            /// <summary>
            /// Property Indexer for RateOperation
            /// </summary>
            public const int RateOperation = 17;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 18;

            /// <summary>
            /// Property Indexer for Rate
            /// </summary>
            public const int Rate = 19;

            /// <summary>
            /// Property Indexer for RateSpread
            /// </summary>
            public const int RateSpread = 20;

            /// <summary>
            /// Property Indexer for OriginalQuantity
            /// </summary>
            public const int OriginalQuantity = 21;

            /// <summary>
            /// Property Indexer for ActualQuantity
            /// </summary>
            public const int ActualQuantity = 22;

            /// <summary>
            /// Property Indexer for OriginalARItemNumber
            /// </summary>
            public const int OriginalARItemNumber = 23;

            /// <summary>
            /// Property Indexer for OriginalARUnitOfMeasure
            /// </summary>
            public const int OriginalARUnitOfMeasure = 24;

            /// <summary>
            /// Property Indexer for OriginalUnitCost
            /// </summary>
            public const int OriginalUnitCost = 25;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OEXTCOSTSR
            /// </summary>
            public const int OEXTCOSTSR = 26;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OEXTCOSTHM
            /// </summary>
            public const int OEXTCOSTHM = 27;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for AEXTCOSTSR
            /// </summary>
            public const int AEXTCOSTSR = 28;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for AEXTCOSTHM
            /// </summary>
            public const int AEXTCOSTHM = 29;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OOHTYPE
            /// </summary>
            public const int OOHTYPE = 30;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OOHRATE
            /// </summary>
            public const int OOHRATE = 31;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OOHPER
            /// </summary>
            public const int OOHPER = 32;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OOHSR
            /// </summary>
            public const int OOHSR = 33;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OOHHM
            /// </summary>
            public const int OOHHM = 34;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for AOHSR
            /// </summary>
            public const int AOHSR = 35;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for AOHHM
            /// </summary>
            public const int AOHHM = 36;

            /// <summary>
            /// Property Indexer for LaborType
            /// </summary>
            public const int LaborType = 37;

            /// <summary>
            /// Property Indexer for LaborRate
            /// </summary>
            public const int LaborRate = 38;

            /// <summary>
            /// Property Indexer for LaborPercentage
            /// </summary>
            public const int LaborPercentage = 39;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OLABORSR
            /// </summary>
            public const int OLABORSR = 40;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OLABORHM
            /// </summary>
            public const int OLABORHM = 41;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ALABORSR
            /// </summary>
            public const int ALABORSR = 42;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ALABORHM
            /// </summary>
            public const int ALABORHM = 43;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OTOTCOSTSR
            /// </summary>
            public const int OTOTCOSTSR = 44;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OTOTCOSTHM
            /// </summary>
            public const int OTOTCOSTHM = 45;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ATOTCOSTSR
            /// </summary>
            public const int ATOTCOSTSR = 46;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ATOTCOSTHM
            /// </summary>
            public const int ATOTCOSTHM = 47;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 48;

            /// <summary>
            /// Property Indexer for OriginalBillingRate
            /// </summary>
            public const int OriginalBillingRate = 49;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OBILLSR
            /// </summary>
            public const int OBILLSR = 50;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OBILLHM
            /// </summary>
            public const int OBILLHM = 51;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ABILLSR
            /// </summary>
            public const int ABILLSR = 52;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ABILLHM
            /// </summary>
            public const int ABILLHM = 53;

            /// <summary>
            /// Property Indexer for RemainingToBeBilled
            /// </summary>
            public const int RemainingToBeBilled = 54;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OPROFITSR
            /// </summary>
            public const int OPROFITSR = 55;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OPROFITHM
            /// </summary>
            public const int OPROFITHM = 56;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for APROFITSR
            /// </summary>
            public const int APROFITSR = 57;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for APROFITHM
            /// </summary>
            public const int APROFITHM = 58;

            /// <summary>
            /// Property Indexer for TotalARCustomerReceipts
            /// </summary>
            public const int TotalARCustomerReceipts = 300;

            /// <summary>
            /// Property Indexer for LastARReceiptPostingDate
            /// </summary>
            public const int LastARReceiptPostingDate = 301;

            /// <summary>
            /// Property Indexer for TotalAPVendorPayments
            /// </summary>
            public const int TotalAPVendorPayments = 302;

            /// <summary>
            /// Property Indexer for LastAPPaymentPostingDate
            /// </summary>
            public const int LastAPPaymentPostingDate = 303;

            /// <summary>
            /// Property Indexer for LastCostPostingDate
            /// </summary>
            public const int LastCostPostingDate = 304;

            /// <summary>
            /// Property Indexer for LastBillingsPostingDate
            /// </summary>
            public const int LastBillingsPostingDate = 305;

            /// <summary>
            /// Property Indexer for LastRevRecognitionPostingDate
            /// </summary>
            public const int LastRevRecognitionPostingDate = 306;

            /// <summary>
            /// Property Indexer for LastRevisedPostingDate
            /// </summary>
            public const int LastRevisedPostingDate = 307;

            /// <summary>
            /// Property Indexer for LastBillingsPercentComplete
            /// </summary>
            public const int LastBillingsPercentComplete = 308;

            /// <summary>
            /// Property Indexer for LastPurchaseOrderDate
            /// </summary>
            public const int LastPurchaseOrderDate = 309;

            /// <summary>
            /// Property Indexer for LastPOReceiptDate
            /// </summary>
            public const int LastPOReceiptDate = 310;

            /// <summary>
            /// Property Indexer for LastPOReturnDate
            /// </summary>
            public const int LastPOReturnDate = 311;

            /// <summary>
            /// Property Indexer for LastCanadianPayrollPostingDate
            /// </summary>
            public const int LastCanadianPayrollPostingDate = 312;

            /// <summary>
            /// Property Indexer for LastUSPayrollPostingDate
            /// </summary>
            public const int LastUSPayrollPostingDate = 313;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 500;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 501;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 502;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 503;

            /// <summary>
            /// Property Indexer for Reversed
            /// </summary>
            public const int Reversed = 504;

            /// <summary>
            /// Property Indexer for StoredQuantity
            /// </summary>
            public const int StoredQuantity = 600;

            /// <summary>
            /// Property Indexer for StoredCost
            /// </summary>
            public const int StoredCost = 601;

            /// <summary>
            /// Property Indexer for StoredBillableAmount
            /// </summary>
            public const int StoredBillableAmount = 602;

            /// <summary>
            /// Property Indexer for PreviousCompletedWork
            /// </summary>
            public const int PreviousCompletedWork = 603;

            /// <summary>
            /// Property Indexer for OverheadAmount
            /// </summary>
            public const int OverheadAmount = 604;

            /// <summary>
            /// Property Indexer for TotalStoredCost
            /// </summary>
            public const int TotalStoredCost = 605;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for COHTYPE
            /// </summary>
            public const int COHTYPE = 606;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for COHRATE
            /// </summary>
            public const int COHRATE = 607;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for COHPER
            /// </summary>
            public const int COHPER = 608;

            /// <summary>
            /// Property Indexer for UseAIAReport
            /// </summary>
            public const int UseAIAReport = 609;

            /// <summary>
            /// Property Indexer for PreviousCertificatesForPayment
            /// </summary>
            public const int PreviousCertificatesForPayment = 610;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 611;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 612;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 613;

            /// <summary>
            /// Property Indexer for G703ColumnFFromLastAIARepo
            /// </summary>
            public const int G703ColumnFFromLastAIARepo = 614;

            /// <summary>
            /// Property Indexer for G703ColumnIFromLastAIARepo
            /// </summary>
            public const int G703ColumnIFromLastAIARepo = 615;

            /// <summary>
            /// Property Indexer for LastOEShipmentDate
            /// </summary>
            public const int LastOEShipmentDate = 616;

            /// <summary>
            /// Property Indexer for LastOEInvoiceDate
            /// </summary>
            public const int LastOEInvoiceDate = 617;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1000;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTDESC
            /// </summary>
            public const int CONTDESC = 1009;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PROJDESC
            /// </summary>
            public const int PROJDESC = 1010;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CATDESC
            /// </summary>
            public const int CATDESC = 1011;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RESDESC
            /// </summary>
            public const int RESDESC = 1012;


        }

        #endregion

    }
}