// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of EquipmentsDetailView Constants
    /// </summary>
    public partial class EquipmentCodeDetailView
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0476";


        #region Properties

        /// <summary>
        /// Contains list of EquipmentsDetailView Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Equipment
            /// </summary>
            public const string Equipment = "EQUIPMENT";

            /// <summary>
            /// Property for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CCY";

            /// <summary>
            /// Property for ARItem
            /// </summary>
            public const string ARItem = "ARITEM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ARUOM
            /// </summary>
            public const string ARUOM = "UOM";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for CurrencyDescription
            /// </summary>
            public const string CurrencyDescription = "DESC";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of EquipmentsDetailView Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Equipment
            /// </summary>
            public const int Equipment = 1;

            /// <summary>
            /// Property Indexer for CurrencyCode
            /// </summary>
            public const int CurrencyCode = 2;

            /// <summary>
            /// Property Indexer for ARItem
            /// </summary>
            public const int ARItem = 3;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ARUOM
            /// </summary>
            public const int ARUOM = 4;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 5;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 6;

            /// <summary>
            /// Property Indexer for CurrencyDescription
            /// </summary>
            public const int CurrencyDescription = 7;


        }

        #endregion

    }
}