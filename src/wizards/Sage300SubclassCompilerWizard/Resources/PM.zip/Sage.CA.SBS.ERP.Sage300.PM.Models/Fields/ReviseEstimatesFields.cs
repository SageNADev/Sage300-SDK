// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of CostEntriesHeaders Constants
    /// </summary>
    public partial class ReviseEstimates
    {
        /// <summary>
        /// Roto Id
        /// </summary>
        public const string EntityName = "PM0058";

        #region Properties

        /// <summary>
        /// Contains list of CostEntriesHeaders Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "DOCNUM";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCALPER";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "EXTCOSTSR";

            /// <summary>
            /// Property for TotalCost
            /// </summary>
            public const string TotalCost = "EXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Overhead Amount Source Currency
            /// </summary>
            public const string OverheadAmountSourceCurrency = "OHSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Overhead Amount Home Currency
            /// </summary>
            public const string OverheadAmountHomeCurrency = "OHHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Labor Amount Source Currency
            /// </summary>
            public const string LaborAmountSourceCurrency = "LABORSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Labor Amount Home Currency
            /// </summary>
            public const string LaborAmountHomeCurrency = "LABORHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Total Cost Amount Source Currency
            /// </summary>
            public const string TotalCostAmountSourceCurrency = "TOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Total Cost Amount Home Currency
            /// </summary>
            public const string TotalCostAmountHomeCurrency = "TOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Total Billable Amount Source Currency
            /// </summary>
            public const string TotalBillableAmountSourceCurrency = "TOTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for Total Billable Amount Home Currency
            /// </summary>
            public const string TotalBillableAmountHomeCurrency = "TOTBILLHM";

            /// <summary>
            /// Property for TotalQuantity
            /// </summary>
            public const string TotalQuantity = "TOTQTY";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "COMPLETE";

            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "PRINTSTAT";

            /// <summary>
            /// Property for TransactionStatus
            /// </summary>
            public const string TransactionStatus = "TRANSTAT";

            /// <summary>
            /// Property for NextDetailNumber
            /// </summary>
            public const string NextDetailNumber = "NEXTDTLNUM";

            /// <summary>
            /// Property for NumberOfDetails
            /// </summary>
            public const string NumberOfDetails = "NUMDTL";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for ICStat
            /// </summary>
            public const string ICStat = "ICSTAT";

            /// <summary>
            /// Property for NumberOfMiscellaneousCosts
            /// </summary>
            public const string NumberOfMiscellaneousCosts = "NUMMC";

            /// <summary>
            /// Property for NumberOfTimecards
            /// </summary>
            public const string NumberOfTimecards = "NUMTC";

            /// <summary>
            /// Property for NumberOfTimeExpenses
            /// </summary>
            public const string NumberOfTimeExpenses = "NUMTE";

            /// <summary>
            /// Property for NumberOfEquipmentUsages
            /// </summary>
            public const string NumberOfEquipmentUsages = "NUMEQ";

            /// <summary>
            /// Property for NumberOfMaterialUsages
            /// </summary>
            public const string NumberOfMaterialUsages = "NUMMU";

            /// <summary>
            /// Property for NumberOfMaterialReturns
            /// </summary>
            public const string NumberOfMaterialReturns = "NUMMR";

            /// <summary>
            /// Property for NumberOfCharges
            /// </summary>
            public const string NumberOfCharges = "NUMCH";

            /// <summary>
            /// Property for CreatedBy
            /// </summary>
            public const string CreatedBy = "CREATEBY";

            /// <summary>
            /// Property for CreatedOn
            /// </summary>
            public const string CreatedOn = "CREATEDT";

            /// <summary>
            /// Property for CreatedAt
            /// </summary>
            public const string CreatedAt = "CREATETM";

            /// <summary>
            /// Property for ApprovedBy
            /// </summary>
            public const string ApprovedBy = "APPROVEBY";

            /// <summary>
            /// Property for ApprovedOn
            /// </summary>
            public const string ApprovedOn = "APPROVEDT";

            /// <summary>
            /// Property for ApprovedAt
            /// </summary>
            public const string ApprovedAt = "APPROVETM";

            /// <summary>
            /// Property for PostedBy
            /// </summary>
            public const string PostedBy = "POSTEDBY";

            /// <summary>
            /// Property for PostedOn
            /// </summary>
            public const string PostedOn = "POSTEDDT";

            /// <summary>
            /// Property for PostedAt
            /// </summary>
            public const string PostedAt = "POSTEDTM";

            /// <summary>
            /// Property for GLEntryDescription
            /// </summary>
            public const string GLEntryDescription = "GLHDESC";

            /// <summary>
            /// Property for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for ShowProgressBarDuringPosting
            /// </summary>
            public const string ShowProgressBarDuringPosting = "BMETER";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of CostEntriesHeaders Index Constants
        /// </summary>
        public partial class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 2;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 3;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 4;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 5;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 6;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 7;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 8;

            /// <summary>
            /// Property Indexer for TotalCost
            /// </summary>
            public const int TotalCost = 9;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Overhead Amount Source Currency
            /// </summary>
            public const int OverheadAmountSourceCurrency = 10;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Overhead Amount Home Currency
            /// </summary>
            public const int OverheadAmountHomeCurrency = 11;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Labor Amount Source Currency
            /// </summary>
            public const int LaborAmountSourceCurrency = 12;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Labor Amount Home Currency
            /// </summary>
            public const int LaborAmountHomeCurrency = 13;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Total Cost Amount Source Currency
            /// </summary>
            public const int TotalCostAmountSourceCurrency = 14;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Total Cost Amount Home Currency
            /// </summary>
            public const int TotalCostAmountHomeCurrency = 15;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Total Billable Amount Source Currency
            /// </summary>
            public const int TotalBillableAmountSourceCurrency = 16;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for Total Billable Amount Home Currency
            /// </summary>
            public const int TotalBillableAmountHomeCurrency = 17;

            /// <summary>
            /// Property Indexer for TotalQuantity
            /// </summary>
            public const int TotalQuantity = 18;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 19;

            /// <summary>
            /// Property Indexer for Printed
            /// </summary>
            public const int Printed = 20;

            /// <summary>
            /// Property Indexer for TransactionStatus
            /// </summary>
            public const int TransactionStatus = 21;

            /// <summary>
            /// Property Indexer for NextDetailNumber
            /// </summary>
            public const int NextDetailNumber = 22;

            /// <summary>
            /// Property Indexer for NumberOfDetails
            /// </summary>
            public const int NumberOfDetails = 23;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 24;

            /// <summary>
            /// Property Indexer for ICStat
            /// </summary>
            public const int ICStat = 25;

            /// <summary>
            /// Property Indexer for NumberOfMiscellaneousCosts
            /// </summary>
            public const int NumberOfMiscellaneousCosts = 26;

            /// <summary>
            /// Property Indexer for NumberOfTimecards
            /// </summary>
            public const int NumberOfTimecards = 27;

            /// <summary>
            /// Property Indexer for NumberOfTimeExpenses
            /// </summary>
            public const int NumberOfTimeExpenses = 28;

            /// <summary>
            /// Property Indexer for NumberOfEquipmentUsages
            /// </summary>
            public const int NumberOfEquipmentUsages = 29;

            /// <summary>
            /// Property Indexer for NumberOfMaterialUsages
            /// </summary>
            public const int NumberOfMaterialUsages = 30;

            /// <summary>
            /// Property Indexer for NumberOfMaterialReturns
            /// </summary>
            public const int NumberOfMaterialReturns = 31;

            /// <summary>
            /// Property Indexer for NumberOfCharges
            /// </summary>
            public const int NumberOfCharges = 32;

            /// <summary>
            /// Property Indexer for CreatedBy
            /// </summary>
            public const int CreatedBy = 33;

            /// <summary>
            /// Property Indexer for CreatedOn
            /// </summary>
            public const int CreatedOn = 34;

            /// <summary>
            /// Property Indexer for CreatedAt
            /// </summary>
            public const int CreatedAt = 35;

            /// <summary>
            /// Property Indexer for ApprovedBy
            /// </summary>
            public const int ApprovedBy = 36;

            /// <summary>
            /// Property Indexer for ApprovedOn
            /// </summary>
            public const int ApprovedOn = 37;

            /// <summary>
            /// Property Indexer for ApprovedAt
            /// </summary>
            public const int ApprovedAt = 38;

            /// <summary>
            /// Property Indexer for PostedBy
            /// </summary>
            public const int PostedBy = 39;

            /// <summary>
            /// Property Indexer for PostedOn
            /// </summary>
            public const int PostedOn = 40;

            /// <summary>
            /// Property Indexer for PostedAt
            /// </summary>
            public const int PostedAt = 41;

            /// <summary>
            /// Property Indexer for GLEntryDescription
            /// </summary>
            public const int GLEntryDescription = 42;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 43;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 44;

            /// <summary>
            /// Property Indexer for ShowProgressBarDuringPosting
            /// </summary>
            public const int ShowProgressBarDuringPosting = 1000;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1001;


        }

        #endregion

    }
}