// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of UpdateRetainageDetail Constants
    /// </summary>
    public partial class UpdateRetainageDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0410";


        #region Properties

        /// <summary>
        /// Contains list of UpdateRetainageDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for RetainageNumber
            /// </summary>
            public const string RetainageNumber = "DOCNUM";

            /// <summary>
            /// Property for RetainageType
            /// </summary>
            public const string RetainageType = "RETTYPE";

            /// <summary>
            /// Property for FormattedContractNumber
            /// </summary>
            public const string FormattedContractNumber = "FMTCONTNO";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string ContractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for OriginalDocumentNumber
            /// </summary>
            public const string OriginalDocumentNumber = "ODOCNUM";

            /// <summary>
            /// Property for RetainageAmount
            /// </summary>
            public const string RetainageAmount = "AMOUNT";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CUSTCCY";

            /// <summary>
            /// Property for ContractDescription
            /// </summary>
            public const string ContractDescription = "CONTDESC";

            /// <summary>
            /// Property for ProjectDescription
            /// </summary>
            public const string ProjectDescription = "PROJDESC";

            /// <summary>
            /// Property for CategoryDescription
            /// </summary>
            public const string CategoryDescription = "CATDESC";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of UpdateRetainageDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for RetainageNumber
            /// </summary>
            public const int RetainageNumber = 3;

            /// <summary>
            /// Property Indexer for RetainageType
            /// </summary>
            public const int RetainageType = 4;

            /// <summary>
            /// Property Indexer for FormattedContractNumber
            /// </summary>
            public const int FormattedContractNumber = 5;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 6;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 7;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 8;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 9;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int ContractStyle = 10;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 11;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 12;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 13;

            /// <summary>
            /// Property Indexer for OriginalDocumentNumber
            /// </summary>
            public const int OriginalDocumentNumber = 14;

            /// <summary>
            /// Property Indexer for RetainageAmount
            /// </summary>
            public const int RetainageAmount = 15;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 16;

            /// <summary>
            /// Property Indexer for ContractDescription
            /// </summary>
            public const int ContractDescription = 1001;

            /// <summary>
            /// Property Indexer for ProjectDescription
            /// </summary>
            public const int ProjectDescription = 1002;

            /// <summary>
            /// Property Indexer for CategoryDescription
            /// </summary>
            public const int CategoryDescription = 1003;
        }

        #endregion

    }
}