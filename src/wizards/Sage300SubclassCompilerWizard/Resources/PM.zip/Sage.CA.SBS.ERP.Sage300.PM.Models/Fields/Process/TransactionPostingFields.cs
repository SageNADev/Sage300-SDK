// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Process
{
    /// <summary>
    /// Contains list of TransactionPosting Constants
    /// </summary>
    public partial class TransactionPosting
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0900";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of TransactionPosting Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for DocumentType
            /// </summary>
            public const string DocumentType = "DOCTYPE";

            /// <summary>
            /// Property for IncludeDocumentsWithAStatus - Note that this field is NOT used!!!
            /// </summary>
            public const string IncludeDocumentsWithAStatus = "STATUS";

            /// <summary>
            /// Property for FromDocument
            /// </summary>
            public const string FromDocument = "DOCNUMFR";

            /// <summary>
            /// Property for ToDocument
            /// </summary>
            public const string ToDocument = "DOCNUMTO";

            /// <summary>
            /// Property for Entered
            /// </summary>
            public const string Entered = "INCENT";

            /// <summary>
            /// Property for Approved
            /// </summary>
            public const string Approved = "INCAPP";

            /// <summary>
            /// Property for ReadyForApproval
            /// </summary>
            public const string ReadyForApproval = "INCRFA";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of TransactionPosting Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for DocumentType
            /// </summary>
            public const int DocumentType = 1;

            /// <summary>
            /// Property Indexer for IncludeDocumentsWithAStatus - this field is NOT used!!
            /// </summary>
            public const int IncludeDocumentsWithAStatus = 2;

            /// <summary>
            /// Property Indexer for FromDocument
            /// </summary>
            public const int FromDocument = 3;

            /// <summary>
            /// Property Indexer for ToDocument
            /// </summary>
            public const int ToDocument = 4;

            /// <summary>
            /// Property Indexer for Entered
            /// </summary>
            public const int Entered = 5;

            /// <summary>
            /// Property Indexer for Approved
            /// </summary>
            public const int Approved = 6;

            /// <summary>
            /// Property Indexer for ReadyForApproval
            /// </summary>
            public const int ReadyForApproval = 7;


        }

        #endregion

    }
}