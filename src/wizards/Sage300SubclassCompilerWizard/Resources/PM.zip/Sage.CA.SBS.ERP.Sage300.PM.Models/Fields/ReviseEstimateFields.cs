// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of ReviseEstimate Constants
    /// </summary>
    public partial class ReviseEstimate
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0058";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"TRANSDATE", "TransactionDate"},
                    {"REFERENCE", "Reference"},
                    {"DESC", "Description"},
                    {"COMPLETE", "Status"},
                    {"DATEBUS", "PostingDate"},
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of ReviseEstimate Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for ReviseEstimateNumber
            /// </summary>
            public const string ReviseEstimateNumber = "CHNGORDNO";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCALPER";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CTOTQTY
            /// </summary>
            public const string CTOTQTY = "CTOTQTY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RTOTQTY
            /// </summary>
            public const string RTOTQTY = "RTOTQTY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CEXTCOSTSR
            /// </summary>
            public const string CEXTCOSTSR = "CEXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for REXTCOSTSR
            /// </summary>
            public const string REXTCOSTSR = "REXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CEXTCOSTHM
            /// </summary>
            public const string CEXTCOSTHM = "CEXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for REXTCOSTHM
            /// </summary>
            public const string REXTCOSTHM = "REXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CTOTCOSTSR
            /// </summary>
            public const string CTOTCOSTSR = "CTOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RTOTCOSTSR
            /// </summary>
            public const string RTOTCOSTSR = "RTOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CTOTCOSTHM
            /// </summary>
            public const string CTOTCOSTHM = "CTOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RTOTCOSTHM
            /// </summary>
            public const string RTOTCOSTHM = "RTOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CTOTBILLSR
            /// </summary>
            public const string CTOTBILLSR = "CTOTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RTOTBILLSR
            /// </summary>
            public const string RTOTBILLSR = "RTOTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CTOTBILLHM
            /// </summary>
            public const string CTOTBILLHM = "CTOTBILLHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RTOTBILLHM
            /// </summary>
            public const string RTOTBILLHM = "RTOTBILLHM";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "COMPLETE";

            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "PRINTSTAT";

            /// <summary>
            /// Property for TransactionStatus
            /// </summary>
            public const string TransactionStatus = "TRANSTAT";

            /// <summary>
            /// Property for NextDetailNumber
            /// </summary>
            public const string NextDetailNumber = "NEXTDTLNUM";

            /// <summary>
            /// Property for NumberOfDetails
            /// </summary>
            public const string NumberOfDetails = "NUMDTL";

            /// <summary>
            /// Property for CreatedBy
            /// </summary>
            public const string CreatedBy = "CREATEBY";

            /// <summary>
            /// Property for CreatedOn
            /// </summary>
            public const string CreatedOn = "CREATEDT";

            /// <summary>
            /// Property for CreatedAt
            /// </summary>
            public const string CreatedAt = "CREATETM";

            /// <summary>
            /// Property for ApprovedBy
            /// </summary>
            public const string ApprovedBy = "APPROVEBY";

            /// <summary>
            /// Property for ApprovedOn
            /// </summary>
            public const string ApprovedOn = "APPROVEDT";

            /// <summary>
            /// Property for ApprovedAt
            /// </summary>
            public const string ApprovedAt = "APPROVETM";

            /// <summary>
            /// Property for PostedBy
            /// </summary>
            public const string PostedBy = "POSTEDBY";

            /// <summary>
            /// Property for PostedOn
            /// </summary>
            public const string PostedOn = "POSTEDDT";

            /// <summary>
            /// Property for PostedAt
            /// </summary>
            public const string PostedAt = "POSTEDTM";

            /// <summary>
            /// Property for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for ShowProgressBarDuringPosting
            /// </summary>
            public const string ShowProgressBarDuringPosting = "BMETER";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of ReviseEstimate Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for ReviseEstimateNumber
            /// </summary>
            public const int ReviseEstimateNumber = 2;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 3;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 4;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 5;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 6;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 7;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CTOTQTY
            /// </summary>
            public const int CTOTQTY = 8;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RTOTQTY
            /// </summary>
            public const int RTOTQTY = 9;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CEXTCOSTSR
            /// </summary>
            public const int CEXTCOSTSR = 10;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for REXTCOSTSR
            /// </summary>
            public const int REXTCOSTSR = 11;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CEXTCOSTHM
            /// </summary>
            public const int CEXTCOSTHM = 12;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for REXTCOSTHM
            /// </summary>
            public const int REXTCOSTHM = 13;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CTOTCOSTSR
            /// </summary>
            public const int CTOTCOSTSR = 14;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RTOTCOSTSR
            /// </summary>
            public const int RTOTCOSTSR = 15;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CTOTCOSTHM
            /// </summary>
            public const int CTOTCOSTHM = 16;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RTOTCOSTHM
            /// </summary>
            public const int RTOTCOSTHM = 17;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CTOTBILLSR
            /// </summary>
            public const int CTOTBILLSR = 18;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RTOTBILLSR
            /// </summary>
            public const int RTOTBILLSR = 19;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CTOTBILLHM
            /// </summary>
            public const int CTOTBILLHM = 20;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RTOTBILLHM
            /// </summary>
            public const int RTOTBILLHM = 21;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 22;

            /// <summary>
            /// Property Indexer for Printed
            /// </summary>
            public const int Printed = 23;

            /// <summary>
            /// Property Indexer for TransactionStatus
            /// </summary>
            public const int TransactionStatus = 24;

            /// <summary>
            /// Property Indexer for NextDetailNumber
            /// </summary>
            public const int NextDetailNumber = 25;

            /// <summary>
            /// Property Indexer for NumberOfDetails
            /// </summary>
            public const int NumberOfDetails = 26;

            /// <summary>
            /// Property Indexer for CreatedBy
            /// </summary>
            public const int CreatedBy = 27;

            /// <summary>
            /// Property Indexer for CreatedOn
            /// </summary>
            public const int CreatedOn = 28;

            /// <summary>
            /// Property Indexer for CreatedAt
            /// </summary>
            public const int CreatedAt = 29;

            /// <summary>
            /// Property Indexer for ApprovedBy
            /// </summary>
            public const int ApprovedBy = 30;

            /// <summary>
            /// Property Indexer for ApprovedOn
            /// </summary>
            public const int ApprovedOn = 31;

            /// <summary>
            /// Property Indexer for ApprovedAt
            /// </summary>
            public const int ApprovedAt = 32;

            /// <summary>
            /// Property Indexer for PostedBy
            /// </summary>
            public const int PostedBy = 33;

            /// <summary>
            /// Property Indexer for PostedOn
            /// </summary>
            public const int PostedOn = 34;

            /// <summary>
            /// Property Indexer for PostedAt
            /// </summary>
            public const int PostedAt = 35;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 36;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 37;

            /// <summary>
            /// Property Indexer for ShowProgressBarDuringPosting
            /// </summary>
            public const int ShowProgressBarDuringPosting = 1000;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1001;


        }

        #endregion

    }
}