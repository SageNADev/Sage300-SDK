// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of TimecardTimeDetail Constants
    /// </summary>
    public partial class TimecardTimeDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0041";


        #region Properties

        /// <summary>
        /// Contains list of TimecardTimeDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for TimecardNumber
            /// </summary>
            public const string TimecardNumber = "TIMECARDNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FMTCONTNO = "FMTCONTNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string CONTRACT = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for EarningsCode
            /// </summary>
            public const string EarningsCode = "EARNINGS";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for DESC
            /// </summary>
            public const string DESC = "DESC";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TDATE";

            /// <summary>
            /// Property for TimeType
            /// </summary>
            public const string TimeType = "TIMETYPE";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for StartTime
            /// </summary>
            public const string StartTime = "STARTTIME";

            /// <summary>
            /// Property for EndTime
            /// </summary>
            public const string EndTime = "ENDTIME";

            /// <summary>
            /// Property for Hours
            /// </summary>
            public const string Hours = "QUANTITY";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEM";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UOM";

            /// <summary>
            /// Property for RevenueAndCostCurrency
            /// </summary>
            public const string RevenueAndCostCurrency = "ESTBILLCCY";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCCY";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EXTCOSTSR
            /// </summary>
            public const string EXTCOSTSR = "EXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EXTCOSTHM
            /// </summary>
            public const string EXTCOSTHM = "EXTCOSTHM";

            /// <summary>
            /// Property for ExtendedBillingAmount
            /// </summary>
            public const string ExtendedBillingAmount = "EXTBILLSR";

            /// <summary>
            /// Property for LaborType
            /// </summary>
            public const string LaborType = "LABOR";

            /// <summary>
            /// Property for LaborRate
            /// </summary>
            public const string LaborRate = "LABORRATE";

            /// <summary>
            /// Property for LaborPercentage
            /// </summary>
            public const string LaborPercentage = "LABORPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for LABORSR
            /// </summary>
            public const string LABORSR = "LABORSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for LABORHM
            /// </summary>
            public const string LABORHM = "LABORHM";

            /// <summary>
            /// Property for OverheadType
            /// </summary>
            public const string OverheadType = "OVERHD";

            /// <summary>
            /// Property for OverheadRate
            /// </summary>
            public const string OverheadRate = "OHEADRATE";

            /// <summary>
            /// Property for OverheadPercentage
            /// </summary>
            public const string OverheadPercentage = "HEADPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OHSR
            /// </summary>
            public const string OHSR = "OHSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OHHM
            /// </summary>
            public const string OHHM = "OHHM";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTCOSTSR
            /// </summary>
            public const string TOTCOSTSR = "TOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTCOSTHM
            /// </summary>
            public const string TOTCOSTHM = "TOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTBILLSR
            /// </summary>
            public const string TOTBILLSR = "TOTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTBILLHM
            /// </summary>
            public const string TOTBILLHM = "TOTBILLHM";

            /// <summary>
            /// Property for PayrollAccount
            /// </summary>
            public const string PayrollAccount = "PAYRACCT";

            /// <summary>
            /// Property for WorkInProgressAccount
            /// </summary>
            public const string WorkInProgressAccount = "WIPACCT";

            /// <summary>
            /// Property for OverheadAccount
            /// </summary>
            public const string OverheadAccount = "OHACCT";

            /// <summary>
            /// Property for LaborAccount
            /// </summary>
            public const string LaborAccount = "LABORACCT";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for BillAmountBasedOn
            /// </summary>
            public const string BillAmountBasedOn = "FIXEDBILL";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TCLASS5";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TINCLUDED1";

            /// <summary>
            /// Property for TaxIncluded2
            /// </summary>
            public const string TaxIncluded2 = "TINCLUDED2";

            /// <summary>
            /// Property for TaxIncluded3
            /// </summary>
            public const string TaxIncluded3 = "TINCLUDED3";

            /// <summary>
            /// Property for TaxIncluded4
            /// </summary>
            public const string TaxIncluded4 = "TINCLUDED4";

            /// <summary>
            /// Property for TaxIncluded5
            /// </summary>
            public const string TaxIncluded5 = "TINCLUDED5";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string ContractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALUES
            /// </summary>
            public const string VALUES = "VALUES";

            /// <summary>
            /// Property for GLDetailDescription
            /// </summary>
            public const string GLDetailDescription = "GLDDESC";

            /// <summary>
            /// Property for GLDetailReference
            /// </summary>
            public const string GLDetailReference = "GLDREF";

            /// <summary>
            /// Property for GLDetailComment
            /// </summary>
            public const string GLDetailComment = "GLCOMMENT";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PAYRDESC
            /// </summary>
            public const string PAYRDESC = "PAYRDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for WIPDESC
            /// </summary>
            public const string WIPDESC = "WIPDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ITEMDESC
            /// </summary>
            public const string ITEMDESC = "ITEMDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OHDESC
            /// </summary>
            public const string OHDESC = "OHDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for LABORDESC
            /// </summary>
            public const string LABORDESC = "LABORDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for WARN
            /// </summary>
            public const string WARN = "WARN";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTDESC
            /// </summary>
            public const string CONTDESC = "CONTDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PROJDESC
            /// </summary>
            public const string PROJDESC = "PROJDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CATDESC
            /// </summary>
            public const string CATDESC = "CATDESC";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for HASOPT
            /// </summary>
            public const string HASOPT = "HASOPT";

            /// <summary>
            /// Property for CalledByPMTIMET
            /// </summary>
            public const string CalledByPMTIMET = "TIMET";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of TimecardTimeDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for TimecardNumber
            /// </summary>
            public const int TimecardNumber = 3;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FMTCONTNO = 4;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int CONTRACT = 5;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 6;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 7;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 8;

            /// <summary>
            /// Property Indexer for EarningsCode
            /// </summary>
            public const int EarningsCode = 9;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for DESC
            /// </summary>
            public const int DESC = 10;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 11;

            /// <summary>
            /// Property Indexer for TimeType
            /// </summary>
            public const int TimeType = 12;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 13;

            /// <summary>
            /// Property Indexer for StartTime
            /// </summary>
            public const int StartTime = 14;

            /// <summary>
            /// Property Indexer for EndTime
            /// </summary>
            public const int EndTime = 15;

            /// <summary>
            /// Property Indexer for Hours
            /// </summary>
            public const int Hours = 16;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 17;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 18;

            /// <summary>
            /// Property Indexer for RevenueAndCostCurrency
            /// </summary>
            public const int RevenueAndCostCurrency = 19;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 20;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 21;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 22;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EXTCOSTSR
            /// </summary>
            public const int EXTCOSTSR = 23;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EXTCOSTHM
            /// </summary>
            public const int EXTCOSTHM = 24;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmount
            /// </summary>
            public const int ExtendedBillingAmount = 25;

            /// <summary>
            /// Property Indexer for LaborType
            /// </summary>
            public const int LaborType = 27;

            /// <summary>
            /// Property Indexer for LaborRate
            /// </summary>
            public const int LaborRate = 28;

            /// <summary>
            /// Property Indexer for LaborPercentage
            /// </summary>
            public const int LaborPercentage = 29;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for LABORSR
            /// </summary>
            public const int LABORSR = 30;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for LABORHM
            /// </summary>
            public const int LABORHM = 31;

            /// <summary>
            /// Property Indexer for OverheadType
            /// </summary>
            public const int OverheadType = 32;

            /// <summary>
            /// Property Indexer for OverheadRate
            /// </summary>
            public const int OverheadRate = 33;

            /// <summary>
            /// Property Indexer for OverheadPercentage
            /// </summary>
            public const int OverheadPercentage = 34;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OHSR
            /// </summary>
            public const int OHSR = 35;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OHHM
            /// </summary>
            public const int OHHM = 36;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 37;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTCOSTSR
            /// </summary>
            public const int TOTCOSTSR = 38;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTCOSTHM
            /// </summary>
            public const int TOTCOSTHM = 39;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTBILLSR
            /// </summary>
            public const int TOTBILLSR = 40;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTBILLHM
            /// </summary>
            public const int TOTBILLHM = 41;

            /// <summary>
            /// Property Indexer for PayrollAccount
            /// </summary>
            public const int PayrollAccount = 42;

            /// <summary>
            /// Property Indexer for WorkInProgressAccount
            /// </summary>
            public const int WorkInProgressAccount = 43;

            /// <summary>
            /// Property Indexer for OverheadAccount
            /// </summary>
            public const int OverheadAccount = 44;

            /// <summary>
            /// Property Indexer for LaborAccount
            /// </summary>
            public const int LaborAccount = 45;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 46;

            /// <summary>
            /// Property Indexer for BillAmountBasedOn
            /// </summary>
            public const int BillAmountBasedOn = 47;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 48;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 49;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 50;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 51;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 52;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 53;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 54;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 55;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 56;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 57;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 58;

            /// <summary>
            /// Property Indexer for TaxIncluded2
            /// </summary>
            public const int TaxIncluded2 = 59;

            /// <summary>
            /// Property Indexer for TaxIncluded3
            /// </summary>
            public const int TaxIncluded3 = 60;

            /// <summary>
            /// Property Indexer for TaxIncluded4
            /// </summary>
            public const int TaxIncluded4 = 61;

            /// <summary>
            /// Property Indexer for TaxIncluded5
            /// </summary>
            public const int TaxIncluded5 = 62;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 63;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int ContractStyle = 64;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 65;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 66;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 67;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALUES
            /// </summary>
            public const int VALUES = 68;

            /// <summary>
            /// Property Indexer for GLDetailDescription
            /// </summary>
            public const int GLDetailDescription = 69;

            /// <summary>
            /// Property Indexer for GLDetailReference
            /// </summary>
            public const int GLDetailReference = 70;

            /// <summary>
            /// Property Indexer for GLDetailComment
            /// </summary>
            public const int GLDetailComment = 71;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 72;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PAYRDESC
            /// </summary>
            public const int PAYRDESC = 1003;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for WIPDESC
            /// </summary>
            public const int WIPDESC = 1004;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ITEMDESC
            /// </summary>
            public const int ITEMDESC = 1005;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OHDESC
            /// </summary>
            public const int OHDESC = 1006;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for LABORDESC
            /// </summary>
            public const int LABORDESC = 1007;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for WARN
            /// </summary>
            public const int WARN = 1008;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTDESC
            /// </summary>
            public const int CONTDESC = 1009;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PROJDESC
            /// </summary>
            public const int PROJDESC = 1010;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CATDESC
            /// </summary>
            public const int CATDESC = 1011;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1012;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for HASOPT
            /// </summary>
            public const int HASOPT = 1013;

            /// <summary>
            /// Property Indexer for CalledByPMTIMET
            /// </summary>
            public const int CalledByPMTIMET = 1014;


        }

        #endregion

    }
}