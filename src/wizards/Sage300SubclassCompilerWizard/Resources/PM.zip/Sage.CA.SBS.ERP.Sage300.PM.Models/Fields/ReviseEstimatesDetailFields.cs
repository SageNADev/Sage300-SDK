// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of ReviseEstimatesDetail Constants
    /// </summary>
    public partial class ReviseEstimatesDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0059";


        #region Properties

        /// <summary>
        /// Contains list of ReviseEstimatesDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for ReviseEstimateNumber
            /// </summary>
            public const string ReviseEstimateNumber = "CHNGORDNO";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FMTCONTNO = "FMTCONTNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string CONTRACT = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for CostType
            /// </summary>
            public const string CostType = "COSTTYPE";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Action
            /// </summary>
            public const string Action = "ACTION";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CBILLTYPE
            /// </summary>
            public const string CBILLTYPE = "CBILLTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RBILLTYPE
            /// </summary>
            public const string RBILLTYPE = "RBILLTYPE";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCCY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CDESC
            /// </summary>
            public const string CDESC = "CDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RDESC
            /// </summary>
            public const string RDESC = "RDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CARITEM
            /// </summary>
            public const string CARITEM = "CARITEM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RARITEM
            /// </summary>
            public const string RARITEM = "RARITEM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CARUOM
            /// </summary>
            public const string CARUOM = "CARUOM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RARUOM
            /// </summary>
            public const string RARUOM = "RARUOM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CICUOM
            /// </summary>
            public const string CICUOM = "CICUOM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RICUOM
            /// </summary>
            public const string RICUOM = "RICUOM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CCONV
            /// </summary>
            public const string CCONV = "CCONV";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RCONV
            /// </summary>
            public const string RCONV = "RCONV";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CQUANTITY
            /// </summary>
            public const string CQUANTITY = "CQUANTITY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RQUANTITY
            /// </summary>
            public const string RQUANTITY = "RQUANTITY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CUNITCOST
            /// </summary>
            public const string CUNITCOST = "CUNITCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RUNITCOST
            /// </summary>
            public const string RUNITCOST = "RUNITCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CEXTCOSTSR
            /// </summary>
            public const string CEXTCOSTSR = "CEXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for REXTCOSTSR
            /// </summary>
            public const string REXTCOSTSR = "REXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CEXTCOSTHM
            /// </summary>
            public const string CEXTCOSTHM = "CEXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for REXTCOSTHM
            /// </summary>
            public const string REXTCOSTHM = "REXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CLABORTYPE
            /// </summary>
            public const string CLABORTYPE = "CLABORTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RLABORTYPE
            /// </summary>
            public const string RLABORTYPE = "RLABORTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CLABORRATE
            /// </summary>
            public const string CLABORRATE = "CLABORRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RLABORRATE
            /// </summary>
            public const string RLABORRATE = "RLABORRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CLABORPER
            /// </summary>
            public const string CLABORPER = "CLABORPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RLABORPER
            /// </summary>
            public const string RLABORPER = "RLABORPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CLABORAMT
            /// </summary>
            public const string CLABORAMT = "CLABORAMT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RLABORAMT
            /// </summary>
            public const string RLABORAMT = "RLABORAMT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for COHTYPE
            /// </summary>
            public const string COHTYPE = "COHTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ROHTYPE
            /// </summary>
            public const string ROHTYPE = "ROHTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for COHRATE
            /// </summary>
            public const string COHRATE = "COHRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ROHRATE
            /// </summary>
            public const string ROHRATE = "ROHRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for COHPER
            /// </summary>
            public const string COHPER = "COHPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ROHPER
            /// </summary>
            public const string ROHPER = "ROHPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for COHAMT
            /// </summary>
            public const string COHAMT = "COHAMT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ROHAMT
            /// </summary>
            public const string ROHAMT = "ROHAMT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CTOTCOSTSR
            /// </summary>
            public const string CTOTCOSTSR = "CTOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RTOTCOSTSR
            /// </summary>
            public const string RTOTCOSTSR = "RTOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CTOTCOSTHM
            /// </summary>
            public const string CTOTCOSTHM = "CTOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RTOTCOSTHM
            /// </summary>
            public const string RTOTCOSTHM = "RTOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CCOSTPLUSP
            /// </summary>
            public const string CCOSTPLUSP = "CCOSTPLUSP";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RCOSTPLUSP
            /// </summary>
            public const string RCOSTPLUSP = "RCOSTPLUSP";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CBILLRATE
            /// </summary>
            public const string CBILLRATE = "CBILLRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RBILLRATE
            /// </summary>
            public const string RBILLRATE = "RBILLRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CEXTBILLSR
            /// </summary>
            public const string CEXTBILLSR = "CEXTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for REXTBILLSR
            /// </summary>
            public const string REXTBILLSR = "REXTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CEXTBILLHM
            /// </summary>
            public const string CEXTBILLHM = "CEXTBILLHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for REXTBILLHM
            /// </summary>
            public const string REXTBILLHM = "REXTBILLHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CFPAMTSR
            /// </summary>
            public const string CFPAMTSR = "CFPAMTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RFPAMTSR
            /// </summary>
            public const string RFPAMTSR = "RFPAMTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CFPAMTHM
            /// </summary>
            public const string CFPAMTHM = "CFPAMTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RFPAMTHM
            /// </summary>
            public const string RFPAMTHM = "RFPAMTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CPROFITSR
            /// </summary>
            public const string CPROFITSR = "CPROFITSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RPROFITSR
            /// </summary>
            public const string RPROFITSR = "RPROFITSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CPROFITHM
            /// </summary>
            public const string CPROFITHM = "CPROFITHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RPROFITHM
            /// </summary>
            public const string RPROFITHM = "RPROFITHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CRATETYPE
            /// </summary>
            public const string CRATETYPE = "CRATETYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CRATEDATE
            /// </summary>
            public const string CRATEDATE = "CRATEDATE";

            /// <summary>
            /// Property for RateOp
            /// </summary>
            public const string RateOp = "CRATEOP";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CRATE
            /// </summary>
            public const string CRATE = "CRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RATETYPE
            /// </summary>
            public const string RATETYPE = "RATETYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RATEDATE
            /// </summary>
            public const string RATEDATE = "RATEDATE";

            /// <summary>
            /// Property for RateOperation
            /// </summary>
            public const string RateOperation = "RATEOP";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RATE
            /// </summary>
            public const string RATE = "RATE";

            /// <summary>
            /// Property for RateSpread
            /// </summary>
            public const string RateSpread = "RATESPREAD";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENTS";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string ContractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALUES
            /// </summary>
            public const string VALUES = "VALUES";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RATEERR
            /// </summary>
            public const string RATEERR = "RATEERR";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTDESC
            /// </summary>
            public const string CONTDESC = "CONTDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PROJDESC
            /// </summary>
            public const string PROJDESC = "PROJDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CATDESC
            /// </summary>
            public const string CATDESC = "CATDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RESDESC
            /// </summary>
            public const string RESDESC = "RESDESC";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "HASOPT";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of ReviseEstimatesDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for ReviseEstimateNumber
            /// </summary>
            public const int ReviseEstimateNumber = 3;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 4;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FMTCONTNO = 5;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int CONTRACT = 6;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 7;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 8;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 9;

            /// <summary>
            /// Property Indexer for CostType
            /// </summary>
            public const int CostType = 10;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 11;

            /// <summary>
            /// Property Indexer for Action
            /// </summary>
            public const int Action = 12;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CBILLTYPE
            /// </summary>
            public const int CBILLTYPE = 13;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RBILLTYPE
            /// </summary>
            public const int RBILLTYPE = 14;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 15;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 16;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CDESC
            /// </summary>
            public const int CDESC = 17;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RDESC
            /// </summary>
            public const int RDESC = 18;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CARITEM
            /// </summary>
            public const int CARITEM = 19;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RARITEM
            /// </summary>
            public const int RARITEM = 20;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CARUOM
            /// </summary>
            public const int CARUOM = 21;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RARUOM
            /// </summary>
            public const int RARUOM = 22;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CICUOM
            /// </summary>
            public const int CICUOM = 23;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RICUOM
            /// </summary>
            public const int RICUOM = 24;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CCONV
            /// </summary>
            public const int CCONV = 25;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RCONV
            /// </summary>
            public const int RCONV = 26;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CQUANTITY
            /// </summary>
            public const int CQUANTITY = 27;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RQUANTITY
            /// </summary>
            public const int RQUANTITY = 28;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CUNITCOST
            /// </summary>
            public const int CUNITCOST = 29;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RUNITCOST
            /// </summary>
            public const int RUNITCOST = 30;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CEXTCOSTSR
            /// </summary>
            public const int CEXTCOSTSR = 31;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for REXTCOSTSR
            /// </summary>
            public const int REXTCOSTSR = 32;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CEXTCOSTHM
            /// </summary>
            public const int CEXTCOSTHM = 33;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for REXTCOSTHM
            /// </summary>
            public const int REXTCOSTHM = 34;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CLABORTYPE
            /// </summary>
            public const int CLABORTYPE = 35;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RLABORTYPE
            /// </summary>
            public const int RLABORTYPE = 36;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CLABORRATE
            /// </summary>
            public const int CLABORRATE = 37;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RLABORRATE
            /// </summary>
            public const int RLABORRATE = 38;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CLABORPER
            /// </summary>
            public const int CLABORPER = 39;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RLABORPER
            /// </summary>
            public const int RLABORPER = 40;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CLABORAMT
            /// </summary>
            public const int CLABORAMT = 41;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RLABORAMT
            /// </summary>
            public const int RLABORAMT = 42;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for COHTYPE
            /// </summary>
            public const int COHTYPE = 43;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ROHTYPE
            /// </summary>
            public const int ROHTYPE = 44;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for COHRATE
            /// </summary>
            public const int COHRATE = 45;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ROHRATE
            /// </summary>
            public const int ROHRATE = 46;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for COHPER
            /// </summary>
            public const int COHPER = 47;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ROHPER
            /// </summary>
            public const int ROHPER = 48;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for COHAMT
            /// </summary>
            public const int COHAMT = 49;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ROHAMT
            /// </summary>
            public const int ROHAMT = 50;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CTOTCOSTSR
            /// </summary>
            public const int CTOTCOSTSR = 51;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RTOTCOSTSR
            /// </summary>
            public const int RTOTCOSTSR = 52;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CTOTCOSTHM
            /// </summary>
            public const int CTOTCOSTHM = 53;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RTOTCOSTHM
            /// </summary>
            public const int RTOTCOSTHM = 54;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CCOSTPLUSP
            /// </summary>
            public const int CCOSTPLUSP = 55;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RCOSTPLUSP
            /// </summary>
            public const int RCOSTPLUSP = 56;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CBILLRATE
            /// </summary>
            public const int CBILLRATE = 57;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RBILLRATE
            /// </summary>
            public const int RBILLRATE = 58;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CEXTBILLSR
            /// </summary>
            public const int CEXTBILLSR = 59;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for REXTBILLSR
            /// </summary>
            public const int REXTBILLSR = 60;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CEXTBILLHM
            /// </summary>
            public const int CEXTBILLHM = 61;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for REXTBILLHM
            /// </summary>
            public const int REXTBILLHM = 62;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CFPAMTSR
            /// </summary>
            public const int CFPAMTSR = 63;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RFPAMTSR
            /// </summary>
            public const int RFPAMTSR = 64;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CFPAMTHM
            /// </summary>
            public const int CFPAMTHM = 65;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RFPAMTHM
            /// </summary>
            public const int RFPAMTHM = 66;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CPROFITSR
            /// </summary>
            public const int CPROFITSR = 67;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RPROFITSR
            /// </summary>
            public const int RPROFITSR = 68;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CPROFITHM
            /// </summary>
            public const int CPROFITHM = 69;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RPROFITHM
            /// </summary>
            public const int RPROFITHM = 70;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CRATETYPE
            /// </summary>
            public const int CRATETYPE = 71;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CRATEDATE
            /// </summary>
            public const int CRATEDATE = 72;

            /// <summary>
            /// Property Indexer for RateOp
            /// </summary>
            public const int RateOp = 73;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CRATE
            /// </summary>
            public const int CRATE = 74;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RATETYPE
            /// </summary>
            public const int RATETYPE = 75;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RATEDATE
            /// </summary>
            public const int RATEDATE = 76;

            /// <summary>
            /// Property Indexer for RateOperation
            /// </summary>
            public const int RateOperation = 77;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RATE
            /// </summary>
            public const int RATE = 78;

            /// <summary>
            /// Property Indexer for RateSpread
            /// </summary>
            public const int RateSpread = 79;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 80;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int ContractStyle = 81;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 82;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 83;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 84;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 85;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALUES
            /// </summary>
            public const int VALUES = 86;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RATEERR
            /// </summary>
            public const int RATEERR = 1001;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1002;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTDESC
            /// </summary>
            public const int CONTDESC = 1009;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PROJDESC
            /// </summary>
            public const int PROJDESC = 1010;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CATDESC
            /// </summary>
            public const int CATDESC = 1011;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RESDESC
            /// </summary>
            public const int RESDESC = 1012;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 1013;


        }

        #endregion

    }
}