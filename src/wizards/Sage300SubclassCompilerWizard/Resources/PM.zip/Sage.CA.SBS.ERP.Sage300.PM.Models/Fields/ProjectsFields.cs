// Copyright (c) 2018 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of Projects Constants
    /// </summary>
    public partial class Projects
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0022";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"STARTDATE", "ProjectedStartDate"},
                    {"ORJENDDATE", "ProjectedEndDate"},
                    {"CURENDDATE", "CurrentEndDate"},
                    {"PROJTYPE", "ProjectType"},
                    {"REVREC", "AccountingMethod"},
                    {"COSTPLUSP", "CostPlusPercentage"},
                    {"CLOSEBILL", "ClosedToBillings"},
                    {"PROJSTAT", "ProjectStatus"},
                    {"BILLTYPE", "BillingType"},
                    {"BILLACCT", "Billings"},
                    {"REVACCT", "Revenue"},
                    {"WIPACCT", "WorkInProgress"},
                    {"COGSACCT", "CostOfSales"},
                    {"INVTYPE", "ARInvoiceType"},
                    {"CUSTOMER", "Customer"},
                    {"FPAMOUNTSR", "FPAMOUNTSR"},
                    {"TAUTH1", "TaxAuthority1"},
                    {"TAUTH2", "TaxAuthority2"},
                    {"TAUTH3", "TaxAuthority3"},
                    {"TAUTH4", "TaxAuthority4"},
                    {"TAUTH5", "TaxAuthority5"},
                    {"TCLASS1", "TaxClass1"},
                    {"TCLASS2", "TaxClass2"},
                    {"TCLASS3", "TaxClass3"},
                    {"TCLASS4", "TaxClass4"},
                    {"TCLASS5", "TaxClass5"},
                    {"TINCLUDED1", "TaxIncluded1"},
                    {"TINCLUDED2", "TaxIncluded2"},
                    {"TINCLUDED3", "TaxIncluded3"},
                    {"TINCLUDED4", "TaxIncluded4"},
                    {"TINCLUDED5", "TaxIncluded5"},
                    {"CDATEFROM", "CurrentStartDate"},
                    {"PROJSTYLE", "ProjectStyle"},
                    {"MULTICUST", "InvoiceToMultipleCustomers"},
                    {"PRICEOPT", "DefaultBillingRate"},
                    {"PRICELIST", "PriceList"},
                    {"OEMCHGOPT", "OEMiscellaneousCharges"},
                    {"ARACCTSET", "ARAccountSet"},
                    {"SNAPOFROM", "SNAPOFROM"},
                    {"SNAPOTO", "SNAPOTO"},
                    {"SNAPCFROM", "SNAPCFROM"},
                    {"SNAPCTO", "SNAPCTO"},
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of Projects Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ContractUniq
            /// </summary>
            public const string ContractUniq = "CTUNIQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "PLINENUM";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for ProjectedStartDate
            /// </summary>
            public const string ProjectedStartDate = "STARTDATE";

            /// <summary>
            /// Property for ProjectedEndDate
            /// </summary>
            public const string ProjectedEndDate = "ORJENDDATE";

            /// <summary>
            /// Property for CurrentEndDate
            /// </summary>
            public const string CurrentEndDate = "CURENDDATE";

            /// <summary>
            /// Property for DateClosed
            /// </summary>
            public const string DateClosed = "CLOSEDDATE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for CostPlusPercentage
            /// </summary>
            public const string CostPlusPercentage = "COSTPLUSP";

            /// <summary>
            /// Property for ClosedToBillings
            /// </summary>
            public const string ClosedToBillings = "CLOSEBILL";

            /// <summary>
            /// Property for ClosedToCosts
            /// </summary>
            public const string ClosedToCosts = "CLOSECOST";

            /// <summary>
            /// Property for ProjectStatus
            /// </summary>
            public const string ProjectStatus = "PROJSTAT";

            /// <summary>
            /// Property for RevenueType
            /// </summary>
            public const string RevenueType = "USEDEFREV";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for ARRetainagePercentage
            /// </summary>
            public const string ARRetainagePercentage = "PERRETREC";

            /// <summary>
            /// Property for ARRetentionPeriod
            /// </summary>
            public const string ARRetentionPeriod = "RETRECD";

            /// <summary>
            /// Property for Billings
            /// </summary>
            public const string Billings = "BILLACCT";

            /// <summary>
            /// Property for DeferredRevenue
            /// </summary>
            public const string DeferredRevenue = "DEFRACCT";

            /// <summary>
            /// Property for Revenue
            /// </summary>
            public const string Revenue = "REVACCT";

            /// <summary>
            /// Property for Profit
            /// </summary>
            public const string Profit = "PROFITACCT";

            /// <summary>
            /// Property for Loss
            /// </summary>
            public const string Loss = "LOSSACCT";

            /// <summary>
            /// Property for Gain
            /// </summary>
            public const string Gain = "GAINACCT";

            /// <summary>
            /// Property for WorkInProgress
            /// </summary>
            public const string WorkInProgress = "WIPACCT";

            /// <summary>
            /// Property for CostOfSales
            /// </summary>
            public const string CostOfSales = "COGSACCT";

            /// <summary>
            /// Property for PONumber
            /// </summary>
            public const string PONumber = "PONUMBER";

            /// <summary>
            /// Property for FormCode
            /// </summary>
            public const string FormCode = "FORMCODE";

            /// <summary>
            /// Property for ARInvoiceType
            /// </summary>
            public const string ARInvoiceType = "INVTYPE";

            /// <summary>
            /// Property for OriginalExchangeRate
            /// </summary>
            public const string OriginalExchangeRate = "ORATE";

            /// <summary>
            /// Property for OriginalRateType
            /// </summary>
            public const string OriginalRateType = "ORATETYPE";

            /// <summary>
            /// Property for OriginalRateDate
            /// </summary>
            public const string OriginalRateDate = "ORATEDATE";

            /// <summary>
            /// Property for ExchangeRate
            /// </summary>
            public const string ExchangeRate = "RATE";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "RATETYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RATEOP
            /// </summary>
            public const string RateOperator = "RATEOP";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateSpread
            /// </summary>
            public const string RateSpread = "RATESPREAD";

            /// <summary>
            /// Property for RevenueAndCostCurrency
            /// </summary>
            public const string RevenueAndCostCurrency = "ESTBILLCCY";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            /// <summary>
            /// Property for RevenueCurrency
            /// </summary>
            public const string RevenueCurrency = "REVCCY";

            /// <summary>
            /// Property for InvoiceStatus
            /// </summary>
            public const string InvoiceStatus = "INVSTATE";

            /// <summary>
            /// Property for NumberOfCategories
            /// </summary>
            public const string NumberOfCategories = "NUMCATS";

            /// <summary>
            /// Property for OriginalLaborCostEst
            /// </summary>
            public const string OriginalLaborCostEst = "ORJTIMECHM";

            /// <summary>
            /// Property for CurrencyLaborCostEst
            /// </summary>
            public const string CurrencyLaborCostEst = "CURTIMECHM";

            /// <summary>
            /// Property for ActualLaborCosts
            /// </summary>
            public const string ActualLaborCosts = "ACTTIMECHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJTIMEBSR
            /// </summary>
            public const string ORJTIMEBSR = "ORJTIMEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJTIMEBHM
            /// </summary>
            public const string ORJTIMEBHM = "ORJTIMEBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURTIMEBSR
            /// </summary>
            public const string CURTIMEBSR = "CURTIMEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURTIMEBHM
            /// </summary>
            public const string CURTIMEBHM = "CURTIMEBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTTIMEBSR
            /// </summary>
            public const string ACTTIMEBSR = "ACTTIMEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTTIMEBHM
            /// </summary>
            public const string ACTTIMEBHM = "ACTTIMEBHM";

            /// <summary>
            /// Property for OriginalLaborQtyEst
            /// </summary>
            public const string OriginalLaborQtyEst = "ORJTIMEQTY";

            /// <summary>
            /// Property for CurrencyLaborQtyEst
            /// </summary>
            public const string CurrencyLaborQtyEst = "CURTIMEQTY";

            /// <summary>
            /// Property for ActualLaborQty
            /// </summary>
            public const string ActualLaborQty = "ACTTIMEQTY";

            /// <summary>
            /// Property for LaborPercentageComplete
            /// </summary>
            public const string LaborPercentageComplete = "PERTIMEQTY";

            /// <summary>
            /// Property for OriginalMaterialEstimatedCost
            /// </summary>
            public const string OriginalMaterialEstimatedCost = "ORJMATECHM";

            /// <summary>
            /// Property for CurrentMaterialEstimatedCost
            /// </summary>
            public const string CurrentMaterialEstimatedCost = "CURMATECHM";

            /// <summary>
            /// Property for ActualMaterialCost
            /// </summary>
            public const string ActualMaterialCost = "ACTMATECHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJMATEBSR
            /// </summary>
            public const string ORJMATEBSR = "ORJMATEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJMATEBHM
            /// </summary>
            public const string ORJMATEBHM = "ORJMATEBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURMATEBSR
            /// </summary>
            public const string CURMATEBSR = "CURMATEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURMATEBHM
            /// </summary>
            public const string CURMATEBHM = "CURMATEBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTMATEBSR
            /// </summary>
            public const string ACTMATEBSR = "ACTMATEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTMATEBHM
            /// </summary>
            public const string ACTMATEBHM = "ACTMATEBHM";

            /// <summary>
            /// Property for OriginalMaterialQtyEst
            /// </summary>
            public const string OriginalMaterialQtyEst = "ORJMATEQTY";

            /// <summary>
            /// Property for CurrencyMaterialEst
            /// </summary>
            public const string CurrencyMaterialEst = "CURMATEQTY";

            /// <summary>
            /// Property for ActualMaterialQty
            /// </summary>
            public const string ActualMaterialQty = "ACTMATEQTY";

            /// <summary>
            /// Property for OriginalEstimatedEquipmentCost
            /// </summary>
            public const string OriginalEstimatedEquipmentCost = "ORJEQUICHM";

            /// <summary>
            /// Property for CurrencyEstimatedEquipmentCost
            /// </summary>
            public const string CurrencyEstimatedEquipmentCost = "CUREQUICHM";

            /// <summary>
            /// Property for ActualEquipmentCost
            /// </summary>
            public const string ActualEquipmentCost = "ACTEQUICHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJEQUIBSR
            /// </summary>
            public const string ORJEQUIBSR = "ORJEQUIBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJEQUIBHM
            /// </summary>
            public const string ORJEQUIBHM = "ORJEQUIBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CUREQUIBSR
            /// </summary>
            public const string CUREQUIBSR = "CUREQUIBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CUREQUIBHM
            /// </summary>
            public const string CUREQUIBHM = "CUREQUIBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTEQUIBSR
            /// </summary>
            public const string ACTEQUIBSR = "ACTEQUIBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTEQUIBHM
            /// </summary>
            public const string ACTEQUIBHM = "ACTEQUIBHM";

            /// <summary>
            /// Property for OriginalEquipmentQtyEst
            /// </summary>
            public const string OriginalEquipmentQtyEst = "ORJEQUIQTY";

            /// <summary>
            /// Property for CurrencyEquipmentEst
            /// </summary>
            public const string CurrencyEquipmentEst = "CUREQUIQTY";

            /// <summary>
            /// Property for ActualEquipmentQty
            /// </summary>
            public const string ActualEquipmentQty = "ACTEQUIQTY";

            /// <summary>
            /// Property for OriginalSubcontractorEstCost
            /// </summary>
            public const string OriginalSubcontractorEstCost = "ORJSUBCCHM";

            /// <summary>
            /// Property for CurrencySubcontractorEstCost
            /// </summary>
            public const string CurrencySubcontractorEstCost = "CURSUBCCHM";

            /// <summary>
            /// Property for ActualSubcontractorCost
            /// </summary>
            public const string ActualSubcontractorCost = "ACTSUBCCHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJSUBCBSR
            /// </summary>
            public const string ORJSUBCBSR = "ORJSUBCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJSUBCBHM
            /// </summary>
            public const string ORJSUBCBHM = "ORJSUBCBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURSUBCBSR
            /// </summary>
            public const string CURSUBCBSR = "CURSUBCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURSUBCBHM
            /// </summary>
            public const string CURSUBCBHM = "CURSUBCBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTSUBCBSR
            /// </summary>
            public const string ACTSUBCBSR = "ACTSUBCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTSUBCBHM
            /// </summary>
            public const string ACTSUBCBHM = "ACTSUBCBHM";

            /// <summary>
            /// Property for OriginalSubcontractorQtyEst
            /// </summary>
            public const string OriginalSubcontractorQtyEst = "ORJSUBCQTY";

            /// <summary>
            /// Property for CurrencySubcontractorEst
            /// </summary>
            public const string CurrencySubcontractorEst = "CURSUBCQTY";

            /// <summary>
            /// Property for ActualSubcontractorQty
            /// </summary>
            public const string ActualSubcontractorQty = "ACTSUBCQTY";

            /// <summary>
            /// Property for OriginalEstOverheadExpenseCost
            /// </summary>
            public const string OriginalEstOverheadExpenseCost = "ORJOHEXCHM";

            /// <summary>
            /// Property for CurrencyEstOverheadExpenseCost
            /// </summary>
            public const string CurrencyEstOverheadExpenseCost = "CUROHEXCHM";

            /// <summary>
            /// Property for ActualOverheadExpenseCost
            /// </summary>
            public const string ActualOverheadExpenseCost = "ACTOHEXCHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJOHEXBSR
            /// </summary>
            public const string ORJOHEXBSR = "ORJOHEXBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJOHEXBHM
            /// </summary>
            public const string ORJOHEXBHM = "ORJOHEXBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CUROHEXBSR
            /// </summary>
            public const string CUROHEXBSR = "CUROHEXBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CUROHEXBHM
            /// </summary>
            public const string CUROHEXBHM = "CUROHEXBHM";

            /// <summary>
            /// Property for ActualOverheadAmountBilled
            /// </summary>
            public const string ActualOverheadAmountBilled = "ACTOHEXBSR";

            /// <summary>
            /// Property for ActualOverheadBillingEst
            /// </summary>
            public const string ActualOverheadBillingEst = "ACTOHEXBHM";

            /// <summary>
            /// Property for OriginalOverheadQtyEst
            /// </summary>
            public const string OriginalOverheadQtyEst = "ORJOHEXQTY";

            /// <summary>
            /// Property for CurrencyOverheadEst
            /// </summary>
            public const string CurrencyOverheadEst = "CUROHEXQTY";

            /// <summary>
            /// Property for ActualOverheadQty
            /// </summary>
            public const string ActualOverheadQty = "ACTOHEXQTY";

            /// <summary>
            /// Property for OriginalEstMiscellaneousCost
            /// </summary>
            public const string OriginalEstMiscellaneousCost = "ORJMISCCHM";

            /// <summary>
            /// Property for CurrencyEstMiscellaneousCost
            /// </summary>
            public const string CurrencyEstMiscellaneousCost = "CURMISCCHM";

            /// <summary>
            /// Property for ActualMiscellaneousCost
            /// </summary>
            public const string ActualMiscellaneousCost = "ACTMISCCHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJMISCBSR
            /// </summary>
            public const string ORJMISCBSR = "ORJMISCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJMISCBHM
            /// </summary>
            public const string ORJMISCBHM = "ORJMISCBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURMISCBSR
            /// </summary>
            public const string CURMISCBSR = "CURMISCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURMISCBHM
            /// </summary>
            public const string CURMISCBHM = "CURMISCBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTMISCBSR
            /// </summary>
            public const string ACTMISCBSR = "ACTMISCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTMISCBHM
            /// </summary>
            public const string ACTMISCBHM = "ACTMISCBHM";

            /// <summary>
            /// Property for OriginalMiscellaneousQtyEst
            /// </summary>
            public const string OriginalMiscellaneousQtyEst = "ORJMISCQTY";

            /// <summary>
            /// Property for CurrencyMiscellaneousQtyEst
            /// </summary>
            public const string CurrencyMiscellaneousQtyEst = "CURMISCQTY";

            /// <summary>
            /// Property for ActualMiscellaneousQty
            /// </summary>
            public const string ActualMiscellaneousQty = "ACTMISCQTY";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for OriginalOverheadEstimate
            /// </summary>
            public const string OriginalOverheadEstimate = "ORJOHEADHM";

            /// <summary>
            /// Property for CurrentOverheadEstimate
            /// </summary>
            public const string CurrentOverheadEstimate = "CUROHEADHM";

            /// <summary>
            /// Property for ActualOverhead
            /// </summary>
            public const string ActualOverhead = "ACTOHEADHM";

            /// <summary>
            /// Property for OriginalLaborAmountEstimate
            /// </summary>
            public const string OriginalLaborAmountEstimate = "ORJLABHM";

            /// <summary>
            /// Property for CurrentLaborAmountEstimate
            /// </summary>
            public const string CurrentLaborAmountEstimate = "CURLABHM";

            /// <summary>
            /// Property for ActualLaborAmount
            /// </summary>
            public const string ActualLaborAmount = "ACTLABHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTCHRGSR
            /// </summary>
            public const string ACTCHRGSR = "ACTCHRGSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTCHRGHM
            /// </summary>
            public const string ACTCHRGHM = "ACTCHRGHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTCHRGDSR
            /// </summary>
            public const string ACTCHRGDSR = "ACTCHRGDSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTCHRGDHM
            /// </summary>
            public const string ACTCHRGDHM = "ACTCHRGDHM";

            /// <summary>
            /// Property for ActCostStockRetToInventory
            /// </summary>
            public const string ActCostStockRetToInventory = "ACTSTKREHM";

            /// <summary>
            /// Property for ActQtyStockRetToInventory
            /// </summary>
            public const string ActQtyStockRetToInventory = "ACTSTKRQTY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TARRECTSSR
            /// </summary>
            public const string TARRECTSSR = "TARRECTSSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TARRECTSHM
            /// </summary>
            public const string TARRECTSHM = "TARRECTSHM";

            /// <summary>
            /// Property for TotalAPVendorPayments
            /// </summary>
            public const string TotalAPVendorPayments = "TAPPAYMTS";

            /// <summary>
            /// Property for TotalOriginalCostEst
            /// </summary>
            public const string TotalOriginalCostEst = "TORJCOSTHM";

            /// <summary>
            /// Property for TotalCurrencyCostEst
            /// </summary>
            public const string TotalCurrencyCostEst = "TCURCOSTHM";

            /// <summary>
            /// Property for TotalActualCost
            /// </summary>
            public const string TotalActualCost = "TACTCOSTHM";

            /// <summary>
            /// Property for TotalCostRecognized
            /// </summary>
            public const string TotalCostRecognized = "TRECCOSTHM";

            /// <summary>
            /// Property for PercentTotalCost
            /// </summary>
            public const string PercentTotalCost = "PERTCOST";

            /// <summary>
            /// Property for PercentTotalRevenue
            /// </summary>
            public const string PercentTotalRevenue = "PERTREV";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TORJREVSR
            /// </summary>
            public const string TORJREVSR = "TORJREVSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TORJREVHM
            /// </summary>
            public const string TORJREVHM = "TORJREVHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TCURREVSR
            /// </summary>
            public const string TCURREVSR = "TCURREVSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TCURREVHM
            /// </summary>
            public const string TCURREVHM = "TCURREVHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TACTREVSR
            /// </summary>
            public const string TACTREVSR = "TACTREVSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TACTREVHM
            /// </summary>
            public const string TACTREVHM = "TACTREVHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TRECREVSR
            /// </summary>
            public const string TRECREVSR = "TRECREVSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TRECREVHM
            /// </summary>
            public const string TRECREVHM = "TRECREVHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RETARAMTSR
            /// </summary>
            public const string RETARAMTSR = "RETARAMTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RETARAMTHM
            /// </summary>
            public const string RETARAMTHM = "RETARAMTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RETARRECSR
            /// </summary>
            public const string RETARRECSR = "RETARRECSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RETARRECHM
            /// </summary>
            public const string RETARRECHM = "RETARRECHM";

            /// <summary>
            /// Property for RetainagePayable
            /// </summary>
            public const string RetainagePayable = "RETAPAMT";

            /// <summary>
            /// Property for RetainageAmountPaidInAP
            /// </summary>
            public const string RetainageAmountPaidInAP = "RETAPPAID";

            /// <summary>
            /// Property for CommittedPOQuantity
            /// </summary>
            public const string CommittedPOQuantity = "POQTY";

            /// <summary>
            /// Property for RecognizedLoss
            /// </summary>
            public const string RecognizedLoss = "OEAMOUNTHM";

            /// <summary>
            /// Property for BillingsPercentComplete
            /// </summary>
            public const string BillingsPercentComplete = "PCOMPLETEB";

            /// <summary>
            /// Property for RRPercentComplete
            /// </summary>
            public const string RRPercentComplete = "PCOMPLETER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FPAMOUNTSR
            /// </summary>
            public const string FPAMOUNTSR = "FPAMOUNTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FPAMOUNTHM
            /// </summary>
            public const string FPAMOUNTHM = "FPAMOUNTHM";

            /// <summary>
            /// Property for LastBillingsPercentComplete
            /// </summary>
            public const string LastBillingsPercentComplete = "LSTBILLPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for BILLAMTRSR
            /// </summary>
            public const string BILLAMTRSR = "BILLAMTRSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for BILLAMTRHM
            /// </summary>
            public const string BILLAMTRHM = "BILLAMTRHM";

            /// <summary>
            /// Property for LastCostPostingDate
            /// </summary>
            public const string LastCostPostingDate = "COSTDATE";

            /// <summary>
            /// Property for LastBillingsPostingDate
            /// </summary>
            public const string LastBillingsPostingDate = "BILLDATE";

            /// <summary>
            /// Property for LastOverheadPostingDate
            /// </summary>
            public const string LastOverheadPostingDate = "OHDATE";

            /// <summary>
            /// Property for LastChargePostingDate
            /// </summary>
            public const string LastChargePostingDate = "CHARGEDATE";

            /// <summary>
            /// Property for LastRevenueRecPostingDate
            /// </summary>
            public const string LastRevenueRecPostingDate = "REVRECDATE";

            /// <summary>
            /// Property for LastARReceiptPostingDate
            /// </summary>
            public const string LastARReceiptPostingDate = "ARRECDATE";

            /// <summary>
            /// Property for LastAPPaymentPostingDate
            /// </summary>
            public const string LastAPPaymentPostingDate = "APPAYDATE";

            /// <summary>
            /// Property for LastTimecardPostingDate
            /// </summary>
            public const string LastTimecardPostingDate = "TIMEDATE";

            /// <summary>
            /// Property for LastMaterialUsagePostingDate
            /// </summary>
            public const string LastMaterialUsagePostingDate = "STKTRDATE";

            /// <summary>
            /// Property for LastMaterialReturnPostingDat
            /// </summary>
            public const string LastMaterialReturnPostingDat = "STKRETDATE";

            /// <summary>
            /// Property for LastEquipmentPostingDate
            /// </summary>
            public const string LastEquipmentPostingDate = "EQUIPDATE";

            /// <summary>
            /// Property for LastPurchaseOrderDate
            /// </summary>
            public const string LastPurchaseOrderDate = "PODATE";

            /// <summary>
            /// Property for LastPOReceiptDate
            /// </summary>
            public const string LastPOReceiptDate = "PORECDATE";

            /// <summary>
            /// Property for LastPOReturnDate
            /// </summary>
            public const string LastPOReturnDate = "PORETDATE";

            /// <summary>
            /// Property for LastOEInvoiceDate
            /// </summary>
            public const string LastOEInvoiceDate = "OEINVDATE";

            /// <summary>
            /// Property for ProjectTaxTotal
            /// </summary>
            public const string ProjectTaxTotal = "PTAXTOTAL";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TCLASS5";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TINCLUDED1";

            /// <summary>
            /// Property for TaxIncluded2
            /// </summary>
            public const string TaxIncluded2 = "TINCLUDED2";

            /// <summary>
            /// Property for TaxIncluded3
            /// </summary>
            public const string TaxIncluded3 = "TINCLUDED3";

            /// <summary>
            /// Property for TaxIncluded4
            /// </summary>
            public const string TaxIncluded4 = "TINCLUDED4";

            /// <summary>
            /// Property for TaxIncluded5
            /// </summary>
            public const string TaxIncluded5 = "TINCLUDED5";

            /// <summary>
            /// Property for TAXBASES1
            /// </summary>
            public const string TAXBASES1 = "TAXBASES1";

            /// <summary>
            /// Property for TAXBASES2
            /// </summary>
            public const string TAXBASES2 = "TAXBASES2";

            /// <summary>
            /// Property for TAXBASES3
            /// </summary>
            public const string TAXBASES3 = "TAXBASES3";

            /// <summary>
            /// Property for TAXBASES4
            /// </summary>
            public const string TAXBASES4 = "TAXBASES4";

            /// <summary>
            /// Property for TAXBASES5
            /// </summary>
            public const string TAXBASES5 = "TAXBASES5";

            /// <summary>
            /// Property for TAXBASEH1
            /// </summary>
            public const string TAXBASEH1 = "TAXBASEH1";

            /// <summary>
            /// Property for TAXBASEH2
            /// </summary>
            public const string TAXBASEH2 = "TAXBASEH2";

            /// <summary>
            /// Property for TAXBASEH3
            /// </summary>
            public const string TAXBASEH3 = "TAXBASEH3";

            /// <summary>
            /// Property for TAXBASEH4
            /// </summary>
            public const string TAXBASEH4 = "TAXBASEH4";

            /// <summary>
            /// Property for TAXBASEH5
            /// </summary>
            public const string TAXBASEH5 = "TAXBASEH5";

            /// <summary>
            /// Property for TAXAMTS1
            /// </summary>
            public const string TAXAMTS1 = "TAXAMTS1";

            /// <summary>
            /// Property for TAXAMTS2
            /// </summary>
            public const string TAXAMTS2 = "TAXAMTS2";

            /// <summary>
            /// Property for TAXAMTS3
            /// </summary>
            public const string TAXAMTS3 = "TAXAMTS3";

            /// <summary>
            /// Property for TAXAMTS4
            /// </summary>
            public const string TAXAMTS4 = "TAXAMTS4";

            /// <summary>
            /// Property for TAXAMTS5
            /// </summary>
            public const string TAXAMTS5 = "TAXAMTS5";

            /// <summary>
            /// Property for TAXAMTH1
            /// </summary>
            public const string TAXAMTH1 = "TAXAMTH1";

            /// <summary>
            /// Property for TAXAMTH2
            /// </summary>
            public const string TAXAMTH2 = "TAXAMTH2";

            /// <summary>
            /// Property for TAXAMTH3
            /// </summary>
            public const string TAXAMTH3 = "TAXAMTH3";

            /// <summary>
            /// Property for TAXAMTH4
            /// </summary>
            public const string TAXAMTH4 = "TAXAMTH4";

            /// <summary>
            /// Property for TAXAMTH5
            /// </summary>
            public const string TAXAMTH5 = "TAXAMTH5";

            /// <summary>
            /// Property for OnBillingWorksheet
            /// </summary>
            public const string OnBillingWorksheet = "ONBW";

            /// <summary>
            /// Property for ProjectHasBeenOpened
            /// </summary>
            public const string ProjectHasBeenOpened = "OPENED";

            /// <summary>
            /// Property for ExpectedBillings
            /// </summary>
            public const string ExpectedBillings = "BILLAMT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORATEOP
            /// </summary>
            public const string ORateOperator = "ORATEOP";

            /// <summary>
            /// Property for LastRevRecognitionPercentage
            /// </summary>
            public const string LastRevRecognitionPercentage = "LSTRRPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PRFTLOSSSR
            /// </summary>
            public const string PRFTLOSSSR = "PRFTLOSSSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PRFTLOSSHM
            /// </summary>
            public const string PRFTLOSSHM = "PRFTLOSSHM";

            /// <summary>
            /// Property for LastRevisedPostingDate
            /// </summary>
            public const string LastRevisedPostingDate = "REVESTDATE";

            /// <summary>
            /// Property for OnRRWorksheet
            /// </summary>
            public const string OnRRWorksheet = "ONRW";

            /// <summary>
            /// Property for OriginalEmployeeLabor
            /// </summary>
            public const string OriginalEmployeeLabor = "OLABEMHM";

            /// <summary>
            /// Property for CurrentEmployeeLabor
            /// </summary>
            public const string CurrentEmployeeLabor = "CLABEMHM";

            /// <summary>
            /// Property for ActualEmployeeLabor
            /// </summary>
            public const string ActualEmployeeLabor = "ALABEMHM";

            /// <summary>
            /// Property for OriginalEmployeeOverhead
            /// </summary>
            public const string OriginalEmployeeOverhead = "OOHEMHM";

            /// <summary>
            /// Property for CurrentEmployeeOverhead
            /// </summary>
            public const string CurrentEmployeeOverhead = "COHEMHM";

            /// <summary>
            /// Property for ActualEmployeeOverhead
            /// </summary>
            public const string ActualEmployeeOverhead = "AOHEMHM";

            /// <summary>
            /// Property for OriginalEquipmentOverhead
            /// </summary>
            public const string OriginalEquipmentOverhead = "OOHEQHM";

            /// <summary>
            /// Property for CurrentEquipmentOverhead
            /// </summary>
            public const string CurrentEquipmentOverhead = "COHEQHM";

            /// <summary>
            /// Property for ActualEquipmentOverhead
            /// </summary>
            public const string ActualEquipmentOverhead = "AOHEQHM";

            /// <summary>
            /// Property for OriginalSubcontractorOverhead
            /// </summary>
            public const string OriginalSubcontractorOverhead = "OOHSUHM";

            /// <summary>
            /// Property for CurrentSubcontractorOverhead
            /// </summary>
            public const string CurrentSubcontractorOverhead = "COHSUHM";

            /// <summary>
            /// Property for ActualSubcontractorOverhead
            /// </summary>
            public const string ActualSubcontractorOverhead = "AOHSUHM";

            /// <summary>
            /// Property for OriginalOverheadOverhead
            /// </summary>
            public const string OriginalOverheadOverhead = "OOHOHHM";

            /// <summary>
            /// Property for CurrentOverheadOverhead
            /// </summary>
            public const string CurrentOverheadOverhead = "COHOHHM";

            /// <summary>
            /// Property for ActualOverheadOverhead
            /// </summary>
            public const string ActualOverheadOverhead = "AOHOHHM";

            /// <summary>
            /// Property for OriginalMiscellaneousOverhead
            /// </summary>
            public const string OriginalMiscellaneousOverhead = "OOHMIHM";

            /// <summary>
            /// Property for CurrentMiscellaneousOverhead
            /// </summary>
            public const string CurrentMiscellaneousOverhead = "COHMIHM";

            /// <summary>
            /// Property for ActualMiscellaneousOverhead
            /// </summary>
            public const string ActualMiscellaneousOverhead = "AOHMIHM";

            /// <summary>
            /// Property for OriginalMaterialOverhead
            /// </summary>
            public const string OriginalMaterialOverhead = "OOHMAHM";

            /// <summary>
            /// Property for CurrentMaterialOverhead
            /// </summary>
            public const string CurrentMaterialOverhead = "COHMAHM";

            /// <summary>
            /// Property for ActualMaterialOverhead
            /// </summary>
            public const string ActualMaterialOverhead = "AOHMAHM";

            /// <summary>
            /// Property for CurrentStartDate
            /// </summary>
            public const string CurrentStartDate = "CDATEFROM";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "PROJSTYLE";

            /// <summary>
            /// Property for CurrentBillingsARAndOnBW
            /// </summary>
            public const string CurrentBillingsARAndOnBW = "BILLAMTC";

            /// <summary>
            /// Property for CommittedPOCost
            /// </summary>
            public const string CommittedPOCost = "POCOSTHM";

            /// <summary>
            /// Property for CommittedPOOverhead
            /// </summary>
            public const string CommittedPOOverhead = "POOHHM";

            /// <summary>
            /// Property for CommittedPOLabor
            /// </summary>
            public const string CommittedPOLabor = "POLABORHM";

            /// <summary>
            /// Property for CommittedPOTotalCost
            /// </summary>
            public const string CommittedPOTotalCost = "POTCOSTHM";

            /// <summary>
            /// Property for POEmployeeQuantity
            /// </summary>
            public const string POEmployeeQuantity = "POEMQTY";

            /// <summary>
            /// Property for POEmployeeOverhead
            /// </summary>
            public const string POEmployeeOverhead = "POEMOHHM";

            /// <summary>
            /// Property for POEmployeeLabor
            /// </summary>
            public const string POEmployeeLabor = "POEMLABHM";

            /// <summary>
            /// Property for POEmployeeTotalCost
            /// </summary>
            public const string POEmployeeTotalCost = "POEMTCOSTH";

            /// <summary>
            /// Property for POEquipmentQuantity
            /// </summary>
            public const string POEquipmentQuantity = "POEQQTY";

            /// <summary>
            /// Property for POEquipmentOverhead
            /// </summary>
            public const string POEquipmentOverhead = "POEQOHHM";

            /// <summary>
            /// Property for POEquipmentTotalCost
            /// </summary>
            public const string POEquipmentTotalCost = "POEQTCOSTH";

            /// <summary>
            /// Property for POSubcontractorQuantity
            /// </summary>
            public const string POSubcontractorQuantity = "POSUQTY";

            /// <summary>
            /// Property for POSubcontractorOverhead
            /// </summary>
            public const string POSubcontractorOverhead = "POSUOHHM";

            /// <summary>
            /// Property for POSubcontractorTotalCost
            /// </summary>
            public const string POSubcontractorTotalCost = "POSUTCOSTH";

            /// <summary>
            /// Property for POOverheadQuantity
            /// </summary>
            public const string POOverheadQuantity = "POOHQTY";

            /// <summary>
            /// Property for POOverheadOverhead
            /// </summary>
            public const string POOverheadOverhead = "POOHOHHM";

            /// <summary>
            /// Property for POOverheadTotalCost
            /// </summary>
            public const string POOverheadTotalCost = "POOHTCOSTH";

            /// <summary>
            /// Property for POMiscellaneousQuantity
            /// </summary>
            public const string POMiscellaneousQuantity = "POMIQTY";

            /// <summary>
            /// Property for POMiscellaneousOverhead
            /// </summary>
            public const string POMiscellaneousOverhead = "POMIOHHM";

            /// <summary>
            /// Property for POMiscellaneousTotalCost
            /// </summary>
            public const string POMiscellaneousTotalCost = "POMITCOSTH";

            /// <summary>
            /// Property for POMaterialQuantity
            /// </summary>
            public const string POMaterialQuantity = "POMAQTY";

            /// <summary>
            /// Property for POMaterialOverhead
            /// </summary>
            public const string POMaterialOverhead = "POMAOHHM";

            /// <summary>
            /// Property for POMaterialTotalCost
            /// </summary>
            public const string POMaterialTotalCost = "POMATCOSTH";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALUES
            /// </summary>
            public const string VALUES = "VALUES";

            /// <summary>
            /// Property for TransactionsHaveBeenCleared
            /// </summary>
            public const string TransactionsHaveBeenCleared = "CLEARED";

            /// <summary>
            /// Property for TaxGroup
            /// </summary>
            public const string TaxGroup = "CODETAXGRP";

            /// <summary>
            /// Property for CustomerTaxClass1
            /// </summary>
            public const string CustomerTaxClass1 = "CTCLASS1";

            /// <summary>
            /// Property for CustomerTaxClass2
            /// </summary>
            public const string CustomerTaxClass2 = "CTCLASS2";

            /// <summary>
            /// Property for CustomerTaxClass3
            /// </summary>
            public const string CustomerTaxClass3 = "CTCLASS3";

            /// <summary>
            /// Property for CustomerTaxClass4
            /// </summary>
            public const string CustomerTaxClass4 = "CTCLASS4";

            /// <summary>
            /// Property for CustomerTaxClass5
            /// </summary>
            public const string CustomerTaxClass5 = "CTCLASS5";

            /// <summary>
            /// Property for CustomerTaxAuthority1
            /// </summary>
            public const string CustomerTaxAuthority1 = "CTAUTH1";

            /// <summary>
            /// Property for CustomerTaxAuthority2
            /// </summary>
            public const string CustomerTaxAuthority2 = "CTAUTH2";

            /// <summary>
            /// Property for CustomerTaxAuthority3
            /// </summary>
            public const string CustomerTaxAuthority3 = "CTAUTH3";

            /// <summary>
            /// Property for CustomerTaxAuthority4
            /// </summary>
            public const string CustomerTaxAuthority4 = "CTAUTH4";

            /// <summary>
            /// Property for CustomerTaxAuthority5
            /// </summary>
            public const string CustomerTaxAuthority5 = "CTAUTH5";

            /// <summary>
            /// Property for LastUSPayrollPostingDate
            /// </summary>
            public const string LastUSPayrollPostingDate = "LUPDATE";

            /// <summary>
            /// Property for LastCanadianPayrollPostingDa
            /// </summary>
            public const string LastCanadianPayrollPostingDa = "LCPDATE";

            /// <summary>
            /// Property for StoredCost
            /// </summary>
            public const string StoredCost = "STRDCOSTHM";

            /// <summary>
            /// Property for StoredBillableAmount
            /// </summary>
            public const string StoredBillableAmount = "STRDBILLSR";

            /// <summary>
            /// Property for PreviousD+E
            /// </summary>
            public const string PreviousDAndE = "PRECOLEDSR";

            /// <summary>
            /// Property for OverheadAmount
            /// </summary>
            public const string OverheadAmount = "STRDOHHM";

            /// <summary>
            /// Property for TotalStoredCost
            /// </summary>
            public const string TotalStoredCost = "STRDTCSTHM";

            /// <summary>
            /// Property for TaxExpCommittedFunc
            /// </summary>
            public const string TaxExpCommittedFunc = "TXEXPCOMHM";

            /// <summary>
            /// Property for TaxAllCommittedFunc
            /// </summary>
            public const string TaxAllCommittedFunc = "TXALLCOMHM";

            /// <summary>
            /// Property for StoredQuantity
            /// </summary>
            public const string StoredQuantity = "STRDQTY";

            /// <summary>
            /// Property for PreviousCertificatesForPaymen
            /// </summary>
            public const string PreviousCertificatesForPaymen = "PREAIAPAY";

            /// <summary>
            /// Property for G703ColumnFFromLastAIARepo
            /// </summary>
            public const string G703ColumnFFromLastAIARepo = "PRESTORED";

            /// <summary>
            /// Property for G703ColumnIFromLastAIARepo
            /// </summary>
            public const string G703ColumnIFromLastAIARepo = "PRERETAIN";

            /// <summary>
            /// Property for AccountSet
            /// </summary>
            public const string AccountSet = "IDACCTSET";

            /// <summary>
            /// Property for CustomerCurrency
            /// </summary>
            public const string CustomerCurrency = "CUSTCCY";

            /// <summary>
            /// Property for Contact
            /// </summary>
            public const string Contact = "CUSCONTACT";

            /// <summary>
            /// Property for Position
            /// </summary>
            public const string Position = "CTACTITTLE";

            /// <summary>
            /// Property for Phone
            /// </summary>
            public const string Phone = "CTACPHONE";

            /// <summary>
            /// Property for OtherPhone
            /// </summary>
            public const string OtherPhone = "OTHERPHONE";

            /// <summary>
            /// Property for Fax
            /// </summary>
            public const string Fax = "CTACFAX";

            /// <summary>
            /// Property for Email
            /// </summary>
            public const string Email = "CTACEMAIL";

            /// <summary>
            /// Property for InvoiceToMultipleCustomers
            /// </summary>
            public const string InvoiceToMultipleCustomers = "MULTICUST";

            /// <summary>
            /// Property for HasThisProjectBeenBilled
            /// </summary>
            public const string HasThisProjectBeenBilled = "BILLED";

            /// <summary>
            /// Property for LastOEShipmentDate
            /// </summary>
            public const string LastOEShipmentDate = "OESHPDATE";

            /// <summary>
            /// Property for DefaultBillingRate
            /// </summary>
            public const string DefaultBillingRate = "PRICEOPT";

            /// <summary>
            /// Property for PriceList
            /// </summary>
            public const string PriceList = "PRICELIST";

            /// <summary>
            /// Property for OEMiscellaneousCharges
            /// </summary>
            public const string OEMiscellaneousCharges = "OEMCHGOPT";

            /// <summary>
            /// Property for ARAccountSet
            /// </summary>
            public const string ARAccountSet = "ARACCTSET";

            /// <summary>
            /// Property for UpdateCategoryCostPlus
            /// </summary>
            public const string UpdateCategoryCostPlus = "UPCP";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for RateErrorCode
            /// </summary>
            public const string RateErrorCode = "RATEERR";

            /// <summary>
            /// Property for BillingAccountDescription
            /// </summary>
            public const string BillingAccountDescription = "BILLDESC";

            /// <summary>
            /// Property for RevenueAccountDescription
            /// </summary>
            public const string RevenueAccountDescription = "REVDESC";

            /// <summary>
            /// Property for WIPAccountDescription
            /// </summary>
            public const string WIPAccountDescription = "WIPDESC";

            /// <summary>
            /// Property for COGSAccountDescription
            /// </summary>
            public const string COGSAccountDescription = "COGSDESC";

            /// <summary>
            /// Property for CostPlusAtRead
            /// </summary>
            public const string CostPlusAtRead = "RCOSTPLUSP";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "ORJQTY";

            /// <summary>
            /// Property for CurrentQuantityEstimate
            /// </summary>
            public const string CurrentQuantityEstimate = "CURQTY";

            /// <summary>
            /// Property for ActualQuantity
            /// </summary>
            public const string ActualQuantity = "ACTQTY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJCOSTHM
            /// </summary>
            public const string ORJCOSTHM = "ORJCOSTHM";

            /// <summary>
            /// Property for CurrentCostEstimate
            /// </summary>
            public const string CurrentCostEstimate = "CURCOSTHM";

            /// <summary>
            /// Property for ActualCost
            /// </summary>
            public const string ActualCost = "ACTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SNAPCALC
            /// </summary>
            public const string SNAPCALC = "SNAPCALC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SNAPOFROM
            /// </summary>
            public const string SNAPOFROM = "SNAPOFROM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SNAPOTO
            /// </summary>
            public const string SNAPOTO = "SNAPOTO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SNAPCFROM
            /// </summary>
            public const string SNAPCFROM = "SNAPCFROM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SNAPCTO
            /// </summary>
            public const string SNAPCTO = "SNAPCTO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for HASOPT
            /// </summary>
            public const string HASOPT = "HASOPT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OPENING
            /// </summary>
            public const string Opening = "OPENING";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for UPDATE
            /// </summary>
            public const string UPDATE = "UPDATE";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "CUSTNAME";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Projects Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ContractUniq
            /// </summary>
            public const int ContractUniq = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 3;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 4;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 5;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 6;

            /// <summary>
            /// Property Indexer for ProjectedStartDate
            /// </summary>
            public const int ProjectedStartDate = 7;

            /// <summary>
            /// Property Indexer for ProjectedEndDate
            /// </summary>
            public const int ProjectedEndDate = 8;

            /// <summary>
            /// Property Indexer for CurrentEndDate
            /// </summary>
            public const int CurrentEndDate = 9;

            /// <summary>
            /// Property Indexer for DateClosed
            /// </summary>
            public const int DateClosed = 10;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 11;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 12;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 13;

            /// <summary>
            /// Property Indexer for CostPlusPercentage
            /// </summary>
            public const int CostPlusPercentage = 14;

            /// <summary>
            /// Property Indexer for ClosedToBillings
            /// </summary>
            public const int ClosedToBillings = 15;

            /// <summary>
            /// Property Indexer for ClosedToCosts
            /// </summary>
            public const int ClosedToCosts = 16;

            /// <summary>
            /// Property Indexer for ProjectStatus
            /// </summary>
            public const int ProjectStatus = 17;

            /// <summary>
            /// Property Indexer for RevenueType
            /// </summary>
            public const int RevenueType = 18;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 19;

            /// <summary>
            /// Property Indexer for ARRetainagePercentage
            /// </summary>
            public const int ARRetainagePercentage = 20;

            /// <summary>
            /// Property Indexer for ARRetentionPeriod
            /// </summary>
            public const int ARRetentionPeriod = 21;

            /// <summary>
            /// Property Indexer for Billings
            /// </summary>
            public const int Billings = 22;

            /// <summary>
            /// Property Indexer for DeferredRevenue
            /// </summary>
            public const int DeferredRevenue = 23;

            /// <summary>
            /// Property Indexer for Revenue
            /// </summary>
            public const int Revenue = 24;

            /// <summary>
            /// Property Indexer for Profit
            /// </summary>
            public const int Profit = 25;

            /// <summary>
            /// Property Indexer for Loss
            /// </summary>
            public const int Loss = 26;

            /// <summary>
            /// Property Indexer for Gain
            /// </summary>
            public const int Gain = 27;

            /// <summary>
            /// Property Indexer for WorkInProgress
            /// </summary>
            public const int WorkInProgress = 28;

            /// <summary>
            /// Property Indexer for CostOfSales
            /// </summary>
            public const int CostOfSales = 29;

            /// <summary>
            /// Property Indexer for PONumber
            /// </summary>
            public const int PONumber = 30;

            /// <summary>
            /// Property Indexer for FormCode
            /// </summary>
            public const int FormCode = 31;

            /// <summary>
            /// Property Indexer for ARInvoiceType
            /// </summary>
            public const int ARInvoiceType = 32;

            /// <summary>
            /// Property Indexer for OriginalExchangeRate
            /// </summary>
            public const int OriginalExchangeRate = 33;

            /// <summary>
            /// Property Indexer for OriginalRateType
            /// </summary>
            public const int OriginalRateType = 34;

            /// <summary>
            /// Property Indexer for OriginalRateDate
            /// </summary>
            public const int OriginalRateDate = 35;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 36;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 37;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RATEOP
            /// </summary>
            public const int RateOperator = 38;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 39;

            /// <summary>
            /// Property Indexer for RateSpread
            /// </summary>
            public const int RateSpread = 40;

            /// <summary>
            /// Property Indexer for RevenueAndCostCurrency
            /// </summary>
            public const int RevenueAndCostCurrency = 41;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 42;

            /// <summary>
            /// Property Indexer for RevenueCurrency
            /// </summary>
            public const int RevenueCurrency = 43;

            /// <summary>
            /// Property Indexer for InvoiceStatus
            /// </summary>
            public const int InvoiceStatus = 44;

            /// <summary>
            /// Property Indexer for NumberOfCategories
            /// </summary>
            public const int NumberOfCategories = 45;

            /// <summary>
            /// Property Indexer for OriginalLaborCostEst
            /// </summary>
            public const int OriginalLaborCostEst = 47;

            /// <summary>
            /// Property Indexer for CurrencyLaborCostEst
            /// </summary>
            public const int CurrencyLaborCostEst = 49;

            /// <summary>
            /// Property Indexer for ActualLaborCosts
            /// </summary>
            public const int ActualLaborCosts = 51;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJTIMEBSR
            /// </summary>
            public const int ORJTIMEBSR = 56;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJTIMEBHM
            /// </summary>
            public const int ORJTIMEBHM = 57;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURTIMEBSR
            /// </summary>
            public const int CURTIMEBSR = 58;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURTIMEBHM
            /// </summary>
            public const int CURTIMEBHM = 59;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTTIMEBSR
            /// </summary>
            public const int ACTTIMEBSR = 60;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTTIMEBHM
            /// </summary>
            public const int ACTTIMEBHM = 61;

            /// <summary>
            /// Property Indexer for OriginalLaborQtyEst
            /// </summary>
            public const int OriginalLaborQtyEst = 66;

            /// <summary>
            /// Property Indexer for CurrencyLaborQtyEst
            /// </summary>
            public const int CurrencyLaborQtyEst = 67;

            /// <summary>
            /// Property Indexer for ActualLaborQty
            /// </summary>
            public const int ActualLaborQty = 68;

            /// <summary>
            /// Property Indexer for LaborPercentageComplete
            /// </summary>
            public const int LaborPercentageComplete = 69;

            /// <summary>
            /// Property Indexer for OriginalMaterialEstimatedCost
            /// </summary>
            public const int OriginalMaterialEstimatedCost = 71;

            /// <summary>
            /// Property Indexer for CurrentMaterialEstimatedCost
            /// </summary>
            public const int CurrentMaterialEstimatedCost = 73;

            /// <summary>
            /// Property Indexer for ActualMaterialCost
            /// </summary>
            public const int ActualMaterialCost = 75;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJMATEBSR
            /// </summary>
            public const int ORJMATEBSR = 80;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJMATEBHM
            /// </summary>
            public const int ORJMATEBHM = 81;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURMATEBSR
            /// </summary>
            public const int CURMATEBSR = 82;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURMATEBHM
            /// </summary>
            public const int CURMATEBHM = 83;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTMATEBSR
            /// </summary>
            public const int ACTMATEBSR = 84;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTMATEBHM
            /// </summary>
            public const int ACTMATEBHM = 85;

            /// <summary>
            /// Property Indexer for OriginalMaterialQtyEst
            /// </summary>
            public const int OriginalMaterialQtyEst = 90;

            /// <summary>
            /// Property Indexer for CurrencyMaterialEst
            /// </summary>
            public const int CurrencyMaterialEst = 91;

            /// <summary>
            /// Property Indexer for ActualMaterialQty
            /// </summary>
            public const int ActualMaterialQty = 92;

            /// <summary>
            /// Property Indexer for OriginalEstimatedEquipmentCost
            /// </summary>
            public const int OriginalEstimatedEquipmentCost = 95;

            /// <summary>
            /// Property Indexer for CurrencyEstimatedEquipmentCost
            /// </summary>
            public const int CurrencyEstimatedEquipmentCost = 97;

            /// <summary>
            /// Property Indexer for ActualEquipmentCost
            /// </summary>
            public const int ActualEquipmentCost = 99;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJEQUIBSR
            /// </summary>
            public const int ORJEQUIBSR = 104;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJEQUIBHM
            /// </summary>
            public const int ORJEQUIBHM = 105;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CUREQUIBSR
            /// </summary>
            public const int CUREQUIBSR = 106;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CUREQUIBHM
            /// </summary>
            public const int CUREQUIBHM = 107;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTEQUIBSR
            /// </summary>
            public const int ACTEQUIBSR = 108;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTEQUIBHM
            /// </summary>
            public const int ACTEQUIBHM = 109;

            /// <summary>
            /// Property Indexer for OriginalEquipmentQtyEst
            /// </summary>
            public const int OriginalEquipmentQtyEst = 114;

            /// <summary>
            /// Property Indexer for CurrencyEquipmentEst
            /// </summary>
            public const int CurrencyEquipmentEst = 115;

            /// <summary>
            /// Property Indexer for ActualEquipmentQty
            /// </summary>
            public const int ActualEquipmentQty = 116;

            /// <summary>
            /// Property Indexer for OriginalSubcontractorEstCost
            /// </summary>
            public const int OriginalSubcontractorEstCost = 119;

            /// <summary>
            /// Property Indexer for CurrencySubcontractorEstCost
            /// </summary>
            public const int CurrencySubcontractorEstCost = 121;

            /// <summary>
            /// Property Indexer for ActualSubcontractorCost
            /// </summary>
            public const int ActualSubcontractorCost = 123;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJSUBCBSR
            /// </summary>
            public const int ORJSUBCBSR = 128;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJSUBCBHM
            /// </summary>
            public const int ORJSUBCBHM = 129;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURSUBCBSR
            /// </summary>
            public const int CURSUBCBSR = 130;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURSUBCBHM
            /// </summary>
            public const int CURSUBCBHM = 131;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTSUBCBSR
            /// </summary>
            public const int ACTSUBCBSR = 132;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTSUBCBHM
            /// </summary>
            public const int ACTSUBCBHM = 133;

            /// <summary>
            /// Property Indexer for OriginalSubcontractorQtyEst
            /// </summary>
            public const int OriginalSubcontractorQtyEst = 138;

            /// <summary>
            /// Property Indexer for CurrencySubcontractorEst
            /// </summary>
            public const int CurrencySubcontractorEst = 139;

            /// <summary>
            /// Property Indexer for ActualSubcontractorQty
            /// </summary>
            public const int ActualSubcontractorQty = 140;

            /// <summary>
            /// Property Indexer for OriginalEstOverheadExpenseCost
            /// </summary>
            public const int OriginalEstOverheadExpenseCost = 143;

            /// <summary>
            /// Property Indexer for CurrencyEstOverheadExpenseCost
            /// </summary>
            public const int CurrencyEstOverheadExpenseCost = 145;

            /// <summary>
            /// Property Indexer for ActualOverheadExpenseCost
            /// </summary>
            public const int ActualOverheadExpenseCost = 147;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJOHEXBSR
            /// </summary>
            public const int ORJOHEXBSR = 152;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJOHEXBHM
            /// </summary>
            public const int ORJOHEXBHM = 153;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CUROHEXBSR
            /// </summary>
            public const int CUROHEXBSR = 154;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CUROHEXBHM
            /// </summary>
            public const int CUROHEXBHM = 155;

            /// <summary>
            /// Property Indexer for ActualOverheadAmountBilled
            /// </summary>
            public const int ActualOverheadAmountBilled = 156;

            /// <summary>
            /// Property Indexer for ActualOverheadBillingEst
            /// </summary>
            public const int ActualOverheadBillingEst = 157;

            /// <summary>
            /// Property Indexer for OriginalOverheadQtyEst
            /// </summary>
            public const int OriginalOverheadQtyEst = 162;

            /// <summary>
            /// Property Indexer for CurrencyOverheadEst
            /// </summary>
            public const int CurrencyOverheadEst = 163;

            /// <summary>
            /// Property Indexer for ActualOverheadQty
            /// </summary>
            public const int ActualOverheadQty = 164;

            /// <summary>
            /// Property Indexer for OriginalEstMiscellaneousCost
            /// </summary>
            public const int OriginalEstMiscellaneousCost = 167;

            /// <summary>
            /// Property Indexer for CurrencyEstMiscellaneousCost
            /// </summary>
            public const int CurrencyEstMiscellaneousCost = 169;

            /// <summary>
            /// Property Indexer for ActualMiscellaneousCost
            /// </summary>
            public const int ActualMiscellaneousCost = 171;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJMISCBSR
            /// </summary>
            public const int ORJMISCBSR = 176;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJMISCBHM
            /// </summary>
            public const int ORJMISCBHM = 177;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURMISCBSR
            /// </summary>
            public const int CURMISCBSR = 178;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURMISCBHM
            /// </summary>
            public const int CURMISCBHM = 179;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTMISCBSR
            /// </summary>
            public const int ACTMISCBSR = 180;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTMISCBHM
            /// </summary>
            public const int ACTMISCBHM = 181;

            /// <summary>
            /// Property Indexer for OriginalMiscellaneousQtyEst
            /// </summary>
            public const int OriginalMiscellaneousQtyEst = 186;

            /// <summary>
            /// Property Indexer for CurrencyMiscellaneousQtyEst
            /// </summary>
            public const int CurrencyMiscellaneousQtyEst = 187;

            /// <summary>
            /// Property Indexer for ActualMiscellaneousQty
            /// </summary>
            public const int ActualMiscellaneousQty = 188;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 416;

            /// <summary>
            /// Property Indexer for OriginalOverheadEstimate
            /// </summary>
            public const int OriginalOverheadEstimate = 191;

            /// <summary>
            /// Property Indexer for CurrentOverheadEstimate
            /// </summary>
            public const int CurrentOverheadEstimate = 193;

            /// <summary>
            /// Property Indexer for ActualOverhead
            /// </summary>
            public const int ActualOverhead = 195;

            /// <summary>
            /// Property Indexer for OriginalLaborAmountEstimate
            /// </summary>
            public const int OriginalLaborAmountEstimate = 200;

            /// <summary>
            /// Property Indexer for CurrentLaborAmountEstimate
            /// </summary>
            public const int CurrentLaborAmountEstimate = 202;

            /// <summary>
            /// Property Indexer for ActualLaborAmount
            /// </summary>
            public const int ActualLaborAmount = 204;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTCHRGSR
            /// </summary>
            public const int ACTCHRGSR = 212;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTCHRGHM
            /// </summary>
            public const int ACTCHRGHM = 213;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTCHRGDSR
            /// </summary>
            public const int ACTCHRGDSR = 214;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTCHRGDHM
            /// </summary>
            public const int ACTCHRGDHM = 215;

            /// <summary>
            /// Property Indexer for ActCostStockRetToInventory
            /// </summary>
            public const int ActCostStockRetToInventory = 221;

            /// <summary>
            /// Property Indexer for ActQtyStockRetToInventory
            /// </summary>
            public const int ActQtyStockRetToInventory = 222;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TARRECTSSR
            /// </summary>
            public const int TARRECTSSR = 223;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TARRECTSHM
            /// </summary>
            public const int TARRECTSHM = 224;

            /// <summary>
            /// Property Indexer for TotalAPVendorPayments
            /// </summary>
            public const int TotalAPVendorPayments = 225;

            /// <summary>
            /// Property Indexer for TotalOriginalCostEst
            /// </summary>
            public const int TotalOriginalCostEst = 227;

            /// <summary>
            /// Property Indexer for TotalCurrencyCostEst
            /// </summary>
            public const int TotalCurrencyCostEst = 229;

            /// <summary>
            /// Property Indexer for TotalActualCost
            /// </summary>
            public const int TotalActualCost = 231;

            /// <summary>
            /// Property Indexer for TotalCostRecognized
            /// </summary>
            public const int TotalCostRecognized = 233;

            /// <summary>
            /// Property Indexer for PercentTotalCost
            /// </summary>
            public const int PercentTotalCost = 234;

            /// <summary>
            /// Property Indexer for PercentTotalRevenue
            /// </summary>
            public const int PercentTotalRevenue = 235;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TORJREVSR
            /// </summary>
            public const int TORJREVSR = 236;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TORJREVHM
            /// </summary>
            public const int TORJREVHM = 237;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TCURREVSR
            /// </summary>
            public const int TCURREVSR = 238;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TCURREVHM
            /// </summary>
            public const int TCURREVHM = 239;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TACTREVSR
            /// </summary>
            public const int TACTREVSR = 240;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TACTREVHM
            /// </summary>
            public const int TACTREVHM = 241;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TRECREVSR
            /// </summary>
            public const int TRECREVSR = 242;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TRECREVHM
            /// </summary>
            public const int TRECREVHM = 243;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RETARAMTSR
            /// </summary>
            public const int RETARAMTSR = 246;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RETARAMTHM
            /// </summary>
            public const int RETARAMTHM = 247;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RETARRECSR
            /// </summary>
            public const int RETARRECSR = 248;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RETARRECHM
            /// </summary>
            public const int RETARRECHM = 249;

            /// <summary>
            /// Property Indexer for RetainagePayable
            /// </summary>
            public const int RetainagePayable = 250;

            /// <summary>
            /// Property Indexer for RetainageAmountPaidInAP
            /// </summary>
            public const int RetainageAmountPaidInAP = 251;

            /// <summary>
            /// Property Indexer for CommittedPOQuantity
            /// </summary>
            public const int CommittedPOQuantity = 254;

            /// <summary>
            /// Property Indexer for RecognizedLoss
            /// </summary>
            public const int RecognizedLoss = 256;

            /// <summary>
            /// Property Indexer for BillingsPercentComplete
            /// </summary>
            public const int BillingsPercentComplete = 260;

            /// <summary>
            /// Property Indexer for RRPercentComplete
            /// </summary>
            public const int RRPercentComplete = 262;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FPAMOUNTSR
            /// </summary>
            public const int FPAMOUNTSR = 263;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FPAMOUNTHM
            /// </summary>
            public const int FPAMOUNTHM = 264;

            /// <summary>
            /// Property Indexer for LastBillingsPercentComplete
            /// </summary>
            public const int LastBillingsPercentComplete = 265;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for BILLAMTRSR
            /// </summary>
            public const int BILLAMTRSR = 266;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for BILLAMTRHM
            /// </summary>
            public const int BILLAMTRHM = 267;

            /// <summary>
            /// Property Indexer for LastCostPostingDate
            /// </summary>
            public const int LastCostPostingDate = 268;

            /// <summary>
            /// Property Indexer for LastBillingsPostingDate
            /// </summary>
            public const int LastBillingsPostingDate = 269;

            /// <summary>
            /// Property Indexer for LastOverheadPostingDate
            /// </summary>
            public const int LastOverheadPostingDate = 270;

            /// <summary>
            /// Property Indexer for LastChargePostingDate
            /// </summary>
            public const int LastChargePostingDate = 271;

            /// <summary>
            /// Property Indexer for LastRevenueRecPostingDate
            /// </summary>
            public const int LastRevenueRecPostingDate = 272;

            /// <summary>
            /// Property Indexer for LastARReceiptPostingDate
            /// </summary>
            public const int LastARReceiptPostingDate = 273;

            /// <summary>
            /// Property Indexer for LastAPPaymentPostingDate
            /// </summary>
            public const int LastAPPaymentPostingDate = 274;

            /// <summary>
            /// Property Indexer for LastTimecardPostingDate
            /// </summary>
            public const int LastTimecardPostingDate = 275;

            /// <summary>
            /// Property Indexer for LastMaterialUsagePostingDate
            /// </summary>
            public const int LastMaterialUsagePostingDate = 276;

            /// <summary>
            /// Property Indexer for LastMaterialReturnPostingDat
            /// </summary>
            public const int LastMaterialReturnPostingDat = 277;

            /// <summary>
            /// Property Indexer for LastEquipmentPostingDate
            /// </summary>
            public const int LastEquipmentPostingDate = 278;

            /// <summary>
            /// Property Indexer for LastPurchaseOrderDate
            /// </summary>
            public const int LastPurchaseOrderDate = 279;

            /// <summary>
            /// Property Indexer for LastPOReceiptDate
            /// </summary>
            public const int LastPOReceiptDate = 280;

            /// <summary>
            /// Property Indexer for LastPOReturnDate
            /// </summary>
            public const int LastPOReturnDate = 281;

            /// <summary>
            /// Property Indexer for LastOEInvoiceDate
            /// </summary>
            public const int LastOEInvoiceDate = 283;

            /// <summary>
            /// Property Indexer for ProjectTaxTotal
            /// </summary>
            public const int ProjectTaxTotal = 284;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 285;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 286;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 287;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 288;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 289;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 290;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 291;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 292;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 293;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 294;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 295;

            /// <summary>
            /// Property Indexer for TaxIncluded2
            /// </summary>
            public const int TaxIncluded2 = 296;

            /// <summary>
            /// Property Indexer for TaxIncluded3
            /// </summary>
            public const int TaxIncluded3 = 297;

            /// <summary>
            /// Property Indexer for TaxIncluded4
            /// </summary>
            public const int TaxIncluded4 = 298;

            /// <summary>
            /// Property Indexer for TaxIncluded5
            /// </summary>
            public const int TaxIncluded5 = 299;

            /// <summary>
            /// Property Indexer for TAXBASES1
            /// </summary>
            public const int TAXBASES1 = 300;

            /// <summary>
            /// Property Indexer for TAXBASES2
            /// </summary>
            public const int TAXBASES2 = 301;

            /// <summary>
            /// Property Indexer for TAXBASES3
            /// </summary>
            public const int TAXBASES3 = 302;

            /// <summary>
            /// Property Indexer for TAXBASES4
            /// </summary>
            public const int TAXBASES4 = 303;

            /// <summary>
            /// Property Indexer for TAXBASES5
            /// </summary>
            public const int TAXBASES5 = 304;

            /// <summary>
            /// Property Indexer for TAXBASEH1
            /// </summary>
            public const int TAXBASEH1 = 305;

            /// <summary>
            /// Property Indexer for TAXBASEH2
            /// </summary>
            public const int TAXBASEH2 = 306;

            /// <summary>
            /// Property Indexer for TAXBASEH3
            /// </summary>
            public const int TAXBASEH3 = 307;

            /// <summary>
            /// Property Indexer for TAXBASEH4
            /// </summary>
            public const int TAXBASEH4 = 308;

            /// <summary>
            /// Property Indexer for TAXBASEH5
            /// </summary>
            public const int TAXBASEH5 = 309;

            /// <summary>
            /// Property Indexer for TAXAMTS1
            /// </summary>
            public const int TAXAMTS1 = 310;

            /// <summary>
            /// Property Indexer for TAXAMTS2
            /// </summary>
            public const int TAXAMTS2 = 311;

            /// <summary>
            /// Property Indexer for TAXAMTS3
            /// </summary>
            public const int TAXAMTS3 = 312;

            /// <summary>
            /// Property Indexer for TAXAMTS4
            /// </summary>
            public const int TAXAMTS4 = 313;

            /// <summary>
            /// Property Indexer for TAXAMTS5
            /// </summary>
            public const int TAXAMTS5 = 314;

            /// <summary>
            /// Property Indexer for TAXAMTH1
            /// </summary>
            public const int TAXAMTH1 = 315;

            /// <summary>
            /// Property Indexer for TAXAMTH2
            /// </summary>
            public const int TAXAMTH2 = 316;

            /// <summary>
            /// Property Indexer for TAXAMTH3
            /// </summary>
            public const int TAXAMTH3 = 317;

            /// <summary>
            /// Property Indexer for TAXAMTH4
            /// </summary>
            public const int TAXAMTH4 = 318;

            /// <summary>
            /// Property Indexer for TAXAMTH5
            /// </summary>
            public const int TAXAMTH5 = 319;

            /// <summary>
            /// Property Indexer for OnBillingWorksheet
            /// </summary>
            public const int OnBillingWorksheet = 320;

            /// <summary>
            /// Property Indexer for ProjectHasBeenOpened
            /// </summary>
            public const int ProjectHasBeenOpened = 321;

            /// <summary>
            /// Property Indexer for ExpectedBillings
            /// </summary>
            public const int ExpectedBillings = 322;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORATEOP
            /// </summary>
            public const int ORateOperator = 323;

            /// <summary>
            /// Property Indexer for LastRevRecognitionPercentage
            /// </summary>
            public const int LastRevRecognitionPercentage = 324;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PRFTLOSSSR
            /// </summary>
            public const int PRFTLOSSSR = 325;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PRFTLOSSHM
            /// </summary>
            public const int PRFTLOSSHM = 326;

            /// <summary>
            /// Property Indexer for LastRevisedPostingDate
            /// </summary>
            public const int LastRevisedPostingDate = 327;

            /// <summary>
            /// Property Indexer for OnRRWorksheet
            /// </summary>
            public const int OnRRWorksheet = 328;

            /// <summary>
            /// Property Indexer for OriginalEmployeeLabor
            /// </summary>
            public const int OriginalEmployeeLabor = 329;

            /// <summary>
            /// Property Indexer for CurrentEmployeeLabor
            /// </summary>
            public const int CurrentEmployeeLabor = 330;

            /// <summary>
            /// Property Indexer for ActualEmployeeLabor
            /// </summary>
            public const int ActualEmployeeLabor = 331;

            /// <summary>
            /// Property Indexer for OriginalEmployeeOverhead
            /// </summary>
            public const int OriginalEmployeeOverhead = 332;

            /// <summary>
            /// Property Indexer for CurrentEmployeeOverhead
            /// </summary>
            public const int CurrentEmployeeOverhead = 333;

            /// <summary>
            /// Property Indexer for ActualEmployeeOverhead
            /// </summary>
            public const int ActualEmployeeOverhead = 334;

            /// <summary>
            /// Property Indexer for OriginalEquipmentOverhead
            /// </summary>
            public const int OriginalEquipmentOverhead = 335;

            /// <summary>
            /// Property Indexer for CurrentEquipmentOverhead
            /// </summary>
            public const int CurrentEquipmentOverhead = 336;

            /// <summary>
            /// Property Indexer for ActualEquipmentOverhead
            /// </summary>
            public const int ActualEquipmentOverhead = 337;

            /// <summary>
            /// Property Indexer for OriginalSubcontractorOverhead
            /// </summary>
            public const int OriginalSubcontractorOverhead = 338;

            /// <summary>
            /// Property Indexer for CurrentSubcontractorOverhead
            /// </summary>
            public const int CurrentSubcontractorOverhead = 339;

            /// <summary>
            /// Property Indexer for ActualSubcontractorOverhead
            /// </summary>
            public const int ActualSubcontractorOverhead = 340;

            /// <summary>
            /// Property Indexer for OriginalOverheadOverhead
            /// </summary>
            public const int OriginalOverheadOverhead = 341;

            /// <summary>
            /// Property Indexer for CurrentOverheadOverhead
            /// </summary>
            public const int CurrentOverheadOverhead = 342;

            /// <summary>
            /// Property Indexer for ActualOverheadOverhead
            /// </summary>
            public const int ActualOverheadOverhead = 343;

            /// <summary>
            /// Property Indexer for OriginalMiscellaneousOverhead
            /// </summary>
            public const int OriginalMiscellaneousOverhead = 344;

            /// <summary>
            /// Property Indexer for CurrentMiscellaneousOverhead
            /// </summary>
            public const int CurrentMiscellaneousOverhead = 345;

            /// <summary>
            /// Property Indexer for ActualMiscellaneousOverhead
            /// </summary>
            public const int ActualMiscellaneousOverhead = 346;

            /// <summary>
            /// Property Indexer for OriginalMaterialOverhead
            /// </summary>
            public const int OriginalMaterialOverhead = 347;

            /// <summary>
            /// Property Indexer for CurrentMaterialOverhead
            /// </summary>
            public const int CurrentMaterialOverhead = 348;

            /// <summary>
            /// Property Indexer for ActualMaterialOverhead
            /// </summary>
            public const int ActualMaterialOverhead = 349;

            /// <summary>
            /// Property Indexer for CurrentStartDate
            /// </summary>
            public const int CurrentStartDate = 350;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 351;

            /// <summary>
            /// Property Indexer for CurrentBillingsARAndOnBW
            /// </summary>
            public const int CurrentBillingsARAndOnBW = 366;

            /// <summary>
            /// Property Indexer for CommittedPOCost
            /// </summary>
            public const int CommittedPOCost = 367;

            /// <summary>
            /// Property Indexer for CommittedPOOverhead
            /// </summary>
            public const int CommittedPOOverhead = 368;

            /// <summary>
            /// Property Indexer for CommittedPOLabor
            /// </summary>
            public const int CommittedPOLabor = 369;

            /// <summary>
            /// Property Indexer for CommittedPOTotalCost
            /// </summary>
            public const int CommittedPOTotalCost = 370;

            /// <summary>
            /// Property Indexer for POEmployeeQuantity
            /// </summary>
            public const int POEmployeeQuantity = 371;

            /// <summary>
            /// Property Indexer for POEmployeeOverhead
            /// </summary>
            public const int POEmployeeOverhead = 372;

            /// <summary>
            /// Property Indexer for POEmployeeLabor
            /// </summary>
            public const int POEmployeeLabor = 373;

            /// <summary>
            /// Property Indexer for POEmployeeTotalCost
            /// </summary>
            public const int POEmployeeTotalCost = 374;

            /// <summary>
            /// Property Indexer for POEquipmentQuantity
            /// </summary>
            public const int POEquipmentQuantity = 375;

            /// <summary>
            /// Property Indexer for POEquipmentOverhead
            /// </summary>
            public const int POEquipmentOverhead = 376;

            /// <summary>
            /// Property Indexer for POEquipmentTotalCost
            /// </summary>
            public const int POEquipmentTotalCost = 377;

            /// <summary>
            /// Property Indexer for POSubcontractorQuantity
            /// </summary>
            public const int POSubcontractorQuantity = 378;

            /// <summary>
            /// Property Indexer for POSubcontractorOverhead
            /// </summary>
            public const int POSubcontractorOverhead = 379;

            /// <summary>
            /// Property Indexer for POSubcontractorTotalCost
            /// </summary>
            public const int POSubcontractorTotalCost = 380;

            /// <summary>
            /// Property Indexer for POOverheadQuantity
            /// </summary>
            public const int POOverheadQuantity = 381;

            /// <summary>
            /// Property Indexer for POOverheadOverhead
            /// </summary>
            public const int POOverheadOverhead = 382;

            /// <summary>
            /// Property Indexer for POOverheadTotalCost
            /// </summary>
            public const int POOverheadTotalCost = 383;

            /// <summary>
            /// Property Indexer for POMiscellaneousQuantity
            /// </summary>
            public const int POMiscellaneousQuantity = 384;

            /// <summary>
            /// Property Indexer for POMiscellaneousOverhead
            /// </summary>
            public const int POMiscellaneousOverhead = 385;

            /// <summary>
            /// Property Indexer for POMiscellaneousTotalCost
            /// </summary>
            public const int POMiscellaneousTotalCost = 386;

            /// <summary>
            /// Property Indexer for POMaterialQuantity
            /// </summary>
            public const int POMaterialQuantity = 387;

            /// <summary>
            /// Property Indexer for POMaterialOverhead
            /// </summary>
            public const int POMaterialOverhead = 388;

            /// <summary>
            /// Property Indexer for POMaterialTotalCost
            /// </summary>
            public const int POMaterialTotalCost = 389;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALUES
            /// </summary>
            public const int VALUES = 390;

            /// <summary>
            /// Property Indexer for TransactionsHaveBeenCleared
            /// </summary>
            public const int TransactionsHaveBeenCleared = 391;

            /// <summary>
            /// Property Indexer for TaxGroup
            /// </summary>
            public const int TaxGroup = 392;

            /// <summary>
            /// Property Indexer for CustomerTaxClass1
            /// </summary>
            public const int CustomerTaxClass1 = 393;

            /// <summary>
            /// Property Indexer for CustomerTaxClass2
            /// </summary>
            public const int CustomerTaxClass2 = 394;

            /// <summary>
            /// Property Indexer for CustomerTaxClass3
            /// </summary>
            public const int CustomerTaxClass3 = 395;

            /// <summary>
            /// Property Indexer for CustomerTaxClass4
            /// </summary>
            public const int CustomerTaxClass4 = 396;

            /// <summary>
            /// Property Indexer for CustomerTaxClass5
            /// </summary>
            public const int CustomerTaxClass5 = 397;

            /// <summary>
            /// Property Indexer for CustomerTaxAuthority1
            /// </summary>
            public const int CustomerTaxAuthority1 = 398;

            /// <summary>
            /// Property Indexer for CustomerTaxAuthority2
            /// </summary>
            public const int CustomerTaxAuthority2 = 399;

            /// <summary>
            /// Property Indexer for CustomerTaxAuthority3
            /// </summary>
            public const int CustomerTaxAuthority3 = 400;

            /// <summary>
            /// Property Indexer for CustomerTaxAuthority4
            /// </summary>
            public const int CustomerTaxAuthority4 = 401;

            /// <summary>
            /// Property Indexer for CustomerTaxAuthority5
            /// </summary>
            public const int CustomerTaxAuthority5 = 402;

            /// <summary>
            /// Property Indexer for LastUSPayrollPostingDate
            /// </summary>
            public const int LastUSPayrollPostingDate = 403;

            /// <summary>
            /// Property Indexer for LastCanadianPayrollPostingDa
            /// </summary>
            public const int LastCanadianPayrollPostingDa = 404;

            /// <summary>
            /// Property Indexer for StoredCost
            /// </summary>
            public const int StoredCost = 405;

            /// <summary>
            /// Property Indexer for StoredBillableAmount
            /// </summary>
            public const int StoredBillableAmount = 406;

            /// <summary>
            /// Property Indexer for PreviousD+E
            /// </summary>
            public const int PreviousDAndE = 407;

            /// <summary>
            /// Property Indexer for OverheadAmount
            /// </summary>
            public const int OverheadAmount = 408;

            /// <summary>
            /// Property Indexer for TotalStoredCost
            /// </summary>
            public const int TotalStoredCost = 409;

            /// <summary>
            /// Property Indexer for TaxExpCommittedFunc
            /// </summary>
            public const int TaxExpCommittedFunc = 410;

            /// <summary>
            /// Property Indexer for TaxAllCommittedFunc
            /// </summary>
            public const int TaxAllCommittedFunc = 411;

            /// <summary>
            /// Property Indexer for StoredQuantity
            /// </summary>
            public const int StoredQuantity = 412;

            /// <summary>
            /// Property Indexer for PreviousCertificatesForPaymen
            /// </summary>
            public const int PreviousCertificatesForPaymen = 413;

            /// <summary>
            /// Property Indexer for G703ColumnFFromLastAIARepo
            /// </summary>
            public const int G703ColumnFFromLastAIARepo = 414;

            /// <summary>
            /// Property Indexer for G703ColumnIFromLastAIARepo
            /// </summary>
            public const int G703ColumnIFromLastAIARepo = 415;

            /// <summary>
            /// Property Indexer for AccountSet
            /// </summary>
            public const int AccountSet = 417;

            /// <summary>
            /// Property Indexer for CustomerCurrency
            /// </summary>
            public const int CustomerCurrency = 418;

            /// <summary>
            /// Property Indexer for Contact
            /// </summary>
            public const int Contact = 419;

            /// <summary>
            /// Property Indexer for Position
            /// </summary>
            public const int Position = 420;

            /// <summary>
            /// Property Indexer for Phone
            /// </summary>
            public const int Phone = 421;

            /// <summary>
            /// Property Indexer for OtherPhone
            /// </summary>
            public const int OtherPhone = 422;

            /// <summary>
            /// Property Indexer for Fax
            /// </summary>
            public const int Fax = 423;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 424;

            /// <summary>
            /// Property Indexer for InvoiceToMultipleCustomers
            /// </summary>
            public const int InvoiceToMultipleCustomers = 425;

            /// <summary>
            /// Property Indexer for HasThisProjectBeenBilled
            /// </summary>
            public const int HasThisProjectBeenBilled = 426;

            /// <summary>
            /// Property Indexer for LastOEShipmentDate
            /// </summary>
            public const int LastOEShipmentDate = 427;

            /// <summary>
            /// Property Indexer for DefaultBillingRate
            /// </summary>
            public const int DefaultBillingRate = 428;

            /// <summary>
            /// Property Indexer for PriceList
            /// </summary>
            public const int PriceList = 429;

            /// <summary>
            /// Property Indexer for OEMiscellaneousCharges
            /// </summary>
            public const int OEMiscellaneousCharges = 430;

            /// <summary>
            /// Property Indexer for ARAccountSet
            /// </summary>
            public const int ARAccountSet = 431;

            /// <summary>
            /// Property Indexer for UpdateCategoryCostPlus
            /// </summary>
            public const int UpdateCategoryCostPlus = 1001;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1002;

            /// <summary>
            /// Property Indexer for RateErrorCode
            /// </summary>
            public const int RateErrorCode = 1003;

            /// <summary>
            /// Property Indexer for BillingAccountDescription
            /// </summary>
            public const int BillingAccountDescription = 1004;

            /// <summary>
            /// Property Indexer for RevenueAccountDescription
            /// </summary>
            public const int RevenueAccountDescription = 1005;

            /// <summary>
            /// Property Indexer for WIPAccountDescription
            /// </summary>
            public const int WIPAccountDescription = 1006;

            /// <summary>
            /// Property Indexer for COGSAccountDescription
            /// </summary>
            public const int COGSAccountDescription = 1007;

            /// <summary>
            /// Property Indexer for CostPlusAtRead
            /// </summary>
            public const int CostPlusAtRead = 1008;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 1010;

            /// <summary>
            /// Property Indexer for CurrentQuantityEstimate
            /// </summary>
            public const int CurrentQuantityEstimate = 1011;

            /// <summary>
            /// Property Indexer for ActualQuantity
            /// </summary>
            public const int ActualQuantity = 1012;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJCOSTHM
            /// </summary>
            public const int ORJCOSTHM = 1013;

            /// <summary>
            /// Property Indexer for CurrentCostEstimate
            /// </summary>
            public const int CurrentCostEstimate = 1014;

            /// <summary>
            /// Property Indexer for ActualCost
            /// </summary>
            public const int ActualCost = 1015;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SNAPCALC
            /// </summary>
            public const int SNAPCALC = 1016;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SNAPOFROM
            /// </summary>
            public const int SNAPOFROM = 1017;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SNAPOTO
            /// </summary>
            public const int SNAPOTO = 1018;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SNAPCFROM
            /// </summary>
            public const int SNAPCFROM = 1019;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SNAPCTO
            /// </summary>
            public const int SNAPCTO = 1020;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for HASOPT
            /// </summary>
            public const int HASOPT = 1021;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OPENING
            /// </summary>
            public const int Opening = 1022;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for UPDATE
            /// </summary>
            public const int UPDATE = 1023;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 1024;


        }

        #endregion

    }
}