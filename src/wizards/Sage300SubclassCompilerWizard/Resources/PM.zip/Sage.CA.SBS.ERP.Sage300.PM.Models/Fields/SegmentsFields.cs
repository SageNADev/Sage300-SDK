// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of Segments Constants
    /// </summary>
    public partial class Segments
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0013";


        #region Properties

        /// <summary>
        /// Contains list of Segments Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for SegmentNumber
            /// </summary>
            public const string SegmentNumber = "SEGMENT";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Length
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Validate
            /// </summary>
            public const string Validate = "VALIDATE";


        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Segments Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for SegmentNumber
            /// </summary>
            public const int SegmentNumber = 1;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Length
            /// </summary>
            public const int Length = 3;

            /// <summary>
            /// Property Indexer for Validate
            /// </summary>
            public const int Validate = 4;


        }

        #endregion

    }
}