// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of Timecard Constants
    /// </summary>
    public partial class Timecard
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0040";


        #region Properties

        /// <summary>
        /// Contains list of Timecard Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for TimecardNumber
            /// </summary>
            public const string TimecardNumber = "TIMECARDNO";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCALPER";

            /// <summary>
            /// Property for EmployeeNumber
            /// </summary>
            public const string EmployeeNumber = "STAFFCODE";

            /// <summary>
            /// Property for Name
            /// </summary>
            public const string EmployeeName = "NAME";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for StartDate
            /// </summary>
            public const string StartDate = "BEGINDATE";

            /// <summary>
            /// Property for EndDate
            /// </summary>
            public const string EndDate = "ENDDATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EXTCOSTSR
            /// </summary>
            public const string EXTCOSTSR = "EXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EXTCOSTHM
            /// </summary>
            public const string EXTCOSTHM = "EXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OHSR
            /// </summary>
            public const string OHSR = "OHSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OHHM
            /// </summary>
            public const string OHHM = "OHHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for LABORSR
            /// </summary>
            public const string LABORSR = "LABORSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for LABORHM
            /// </summary>
            public const string LABORHM = "LABORHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTCOSTSR
            /// </summary>
            public const string TOTCOSTSR = "TOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTCOSTHM
            /// </summary>
            public const string TOTCOSTHM = "TOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTBILLSR
            /// </summary>
            public const string TOTBILLSR = "TOTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTBILLHM
            /// </summary>
            public const string TOTBILLHM = "TOTBILLHM";

            /// <summary>
            /// Property for TotalHours
            /// </summary>
            public const string TotalHours = "TOTQTY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ETOTCOSTSR
            /// </summary>
            public const string ETOTCOSTSR = "ETOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ETOTCOSTHM
            /// </summary>
            public const string ETOTCOSTHM = "ETOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ETOTBILLSR
            /// </summary>
            public const string ETOTBILLSR = "ETOTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ETOTBILLHM
            /// </summary>
            public const string ETOTBILLHM = "ETOTBILLHM";

            /// <summary>
            /// Property for TotalExpenseQuantity
            /// </summary>
            public const string TotalExpenseQuantity = "ETOTQTY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for GTOTCOSTSR
            /// </summary>
            public const string GTOTCOSTSR = "GTOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for GTOTCOSTHM
            /// </summary>
            public const string GTOTCOSTHM = "GTOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for GTOTBILLSR
            /// </summary>
            public const string GTOTBILLSR = "GTOTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for GTOTBILLHM
            /// </summary>
            public const string GTOTBILLHM = "GTOTBILLHM";

            /// <summary>
            /// Property for StaffCurrency
            /// </summary>
            public const string StaffCurrency = "CCY";

            /// <summary>
            /// Property for ExchangeRate
            /// </summary>
            public const string ExchangeRate = "RATE";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateOperator
            /// </summary>
            public const string RateOperator = "RATEOP";

            /// <summary>
            /// Property for RateSpread
            /// </summary>
            public const string RateSpread = "RATESPREAD";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "COMPLETE";

            /// <summary>
            /// Property for PrintStatus
            /// </summary>
            public const string PrintStatus = "PRINTSTAT";

            /// <summary>
            /// Property for TransactionStatus
            /// </summary>
            public const string TransactionStatus = "TRANSTAT";

            /// <summary>
            /// Property for NextDetailNumber
            /// </summary>
            public const string NextDetailNumber = "NEXTDTLNUM";

            /// <summary>
            /// Property for PayrollType
            /// </summary>
            public const string PayrollType = "PAYTYPE";

            /// <summary>
            /// Property for NumberOfDetails
            /// </summary>
            public const string NumberOfDetails = "NUMDTL";

            /// <summary>
            /// Property for MondayHours
            /// </summary>
            public const string MondayHours = "HMON";

            /// <summary>
            /// Property for TuesdayHours
            /// </summary>
            public const string TuesdayHours = "HTUE";

            /// <summary>
            /// Property for WednesdayHours
            /// </summary>
            public const string WednesdayHours = "HWED";

            /// <summary>
            /// Property for ThursdayHours
            /// </summary>
            public const string ThursdayHours = "HTHU";

            /// <summary>
            /// Property for FridayHours
            /// </summary>
            public const string FridayHours = "HFRI";

            /// <summary>
            /// Property for SaturdayHours
            /// </summary>
            public const string SaturdayHours = "HSAT";

            /// <summary>
            /// Property for SundayHours
            /// </summary>
            public const string SundayHours = "HSUN";

            /// <summary>
            /// Property for WeeklyHours
            /// </summary>
            public const string WeeklyHours = "HWEEK";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for CreatedBy
            /// </summary>
            public const string CreatedBy = "CREATEBY";

            /// <summary>
            /// Property for CreatedOn
            /// </summary>
            public const string CreatedOn = "CREATEDT";

            /// <summary>
            /// Property for CreatedAt
            /// </summary>
            public const string CreatedAt = "CREATETM";

            /// <summary>
            /// Property for ApprovedBy
            /// </summary>
            public const string ApprovedBy = "APPROVEBY";

            /// <summary>
            /// Property for ApprovedOn
            /// </summary>
            public const string ApprovedOn = "APPROVEDT";

            /// <summary>
            /// Property for ApprovedAt
            /// </summary>
            public const string ApprovedAt = "APPROVETM";

            /// <summary>
            /// Property for PostedBy
            /// </summary>
            public const string PostedBy = "POSTEDBY";

            /// <summary>
            /// Property for PostedOn
            /// </summary>
            public const string PostedOn = "POSTEDDT";

            /// <summary>
            /// Property for PostedAt
            /// </summary>
            public const string PostedAt = "POSTEDTM";

            /// <summary>
            /// Property for GLEntryDescription
            /// </summary>
            public const string GLEntryDescription = "GLHDESC";

            /// <summary>
            /// Property for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for ShowProgressBarDuringPosting
            /// </summary>
            public const string ShowProgressBarDuringPosting = "BMETER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for USERID
            /// </summary>
            public const string USERID = "USERID";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for LSTAFF
            /// </summary>
            public const string LSTAFF = "LSTAFF";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for SignonUserCanSeeThisTimecar
            /// </summary>
            public const string SignonUserCanSeeThisTimecar = "BCANSEE";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Timecard Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for TimecardNumber
            /// </summary>
            public const int TimecardNumber = 2;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 3;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 4;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 5;

            /// <summary>
            /// Property Indexer for EmployeeNumber
            /// </summary>
            public const int EmployeeNumber = 6;

            /// <summary>
            /// Property Indexer for EmployeeName
            /// </summary>
            public const int EmployeeName = 7;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 8;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 9;

            /// <summary>
            /// Property Indexer for StartDate
            /// </summary>
            public const int StartDate = 10;

            /// <summary>
            /// Property Indexer for EndDate
            /// </summary>
            public const int EndDate = 11;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EXTCOSTSR
            /// </summary>
            public const int EXTCOSTSR = 12;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EXTCOSTHM
            /// </summary>
            public const int EXTCOSTHM = 13;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OHSR
            /// </summary>
            public const int OHSR = 14;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OHHM
            /// </summary>
            public const int OHHM = 15;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for LABORSR
            /// </summary>
            public const int LABORSR = 16;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for LABORHM
            /// </summary>
            public const int LABORHM = 17;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTCOSTSR
            /// </summary>
            public const int TOTCOSTSR = 18;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTCOSTHM
            /// </summary>
            public const int TOTCOSTHM = 19;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTBILLSR
            /// </summary>
            public const int TOTBILLSR = 20;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTBILLHM
            /// </summary>
            public const int TOTBILLHM = 21;

            /// <summary>
            /// Property Indexer for TotalHours
            /// </summary>
            public const int TotalHours = 22;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ETOTCOSTSR
            /// </summary>
            public const int ETOTCOSTSR = 23;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ETOTCOSTHM
            /// </summary>
            public const int ETOTCOSTHM = 24;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ETOTBILLSR
            /// </summary>
            public const int ETOTBILLSR = 25;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ETOTBILLHM
            /// </summary>
            public const int ETOTBILLHM = 26;

            /// <summary>
            /// Property Indexer for TotalExpenseQuantity
            /// </summary>
            public const int TotalExpenseQuantity = 27;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for GTOTCOSTSR
            /// </summary>
            public const int GTOTCOSTSR = 28;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for GTOTCOSTHM
            /// </summary>
            public const int GTOTCOSTHM = 29;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for GTOTBILLSR
            /// </summary>
            public const int GTOTBILLSR = 30;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for GTOTBILLHM
            /// </summary>
            public const int GTOTBILLHM = 31;

            /// <summary>
            /// Property Indexer for StaffCurrency
            /// </summary>
            public const int StaffCurrency = 32;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 33;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 34;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 35;

            /// <summary>
            /// Property Indexer for RateOperator
            /// </summary>
            public const int RateOperator = 36;

            /// <summary>
            /// Property Indexer for RateSpread
            /// </summary>
            public const int RateSpread = 37;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 38;

            /// <summary>
            /// Property Indexer for PrintStatus
            /// </summary>
            public const int PrintStatus = 39;

            /// <summary>
            /// Property Indexer for TransactionStatus
            /// </summary>
            public const int TransactionStatus = 40;

            /// <summary>
            /// Property Indexer for NextDetailNumber
            /// </summary>
            public const int NextDetailNumber = 41;

            /// <summary>
            /// Property Indexer for PayrollType
            /// </summary>
            public const int PayrollType = 42;

            /// <summary>
            /// Property Indexer for NumberOfDetails
            /// </summary>
            public const int NumberOfDetails = 43;

            /// <summary>
            /// Property Indexer for MondayHours
            /// </summary>
            public const int MondayHours = 44;

            /// <summary>
            /// Property Indexer for TuesdayHours
            /// </summary>
            public const int TuesdayHours = 45;

            /// <summary>
            /// Property Indexer for WednesdayHours
            /// </summary>
            public const int WednesdayHours = 46;

            /// <summary>
            /// Property Indexer for ThursdayHours
            /// </summary>
            public const int ThursdayHours = 47;

            /// <summary>
            /// Property Indexer for FridayHours
            /// </summary>
            public const int FridayHours = 48;

            /// <summary>
            /// Property Indexer for SaturdayHours
            /// </summary>
            public const int SaturdayHours = 49;

            /// <summary>
            /// Property Indexer for SundayHours
            /// </summary>
            public const int SundayHours = 50;

            /// <summary>
            /// Property Indexer for WeeklyHours
            /// </summary>
            public const int WeeklyHours = 51;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 52;

            /// <summary>
            /// Property Indexer for CreatedBy
            /// </summary>
            public const int CreatedBy = 53;

            /// <summary>
            /// Property Indexer for CreatedOn
            /// </summary>
            public const int CreatedOn = 54;

            /// <summary>
            /// Property Indexer for CreatedAt
            /// </summary>
            public const int CreatedAt = 55;

            /// <summary>
            /// Property Indexer for ApprovedBy
            /// </summary>
            public const int ApprovedBy = 56;

            /// <summary>
            /// Property Indexer for ApprovedOn
            /// </summary>
            public const int ApprovedOn = 57;

            /// <summary>
            /// Property Indexer for ApprovedAt
            /// </summary>
            public const int ApprovedAt = 58;

            /// <summary>
            /// Property Indexer for PostedBy
            /// </summary>
            public const int PostedBy = 59;

            /// <summary>
            /// Property Indexer for PostedOn
            /// </summary>
            public const int PostedOn = 60;

            /// <summary>
            /// Property Indexer for PostedAt
            /// </summary>
            public const int PostedAt = 61;

            /// <summary>
            /// Property Indexer for GLEntryDescription
            /// </summary>
            public const int GLEntryDescription = 62;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 63;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 64;

            /// <summary>
            /// Property Indexer for ShowProgressBarDuringPosting
            /// </summary>
            public const int ShowProgressBarDuringPosting = 1000;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for USERID
            /// </summary>
            public const int USERID = 1001;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for LSTAFF
            /// </summary>
            public const int LSTAFF = 1002;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1003;

            /// <summary>
            /// Property Indexer for SignonUserCanSeeThisTimecar
            /// </summary>
            public const int SignonUserCanSeeThisTimecar = 1004;


        }

        #endregion

    }
}