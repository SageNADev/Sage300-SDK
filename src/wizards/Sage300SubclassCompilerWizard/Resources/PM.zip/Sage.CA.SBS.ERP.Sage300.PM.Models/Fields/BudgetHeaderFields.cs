// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of BudgetHeader Constants
    /// </summary>
    public partial class BudgetHeader
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0123";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of BudgetHeader Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for ContractUniq
            /// </summary>
            public const string ContractUniq = "CTUNIQ";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for BudgetSet
            /// </summary>
            public const string BudgetSet = "BUDGET";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string CONTRACT = "CONTRACT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FMTCONTNO = "FMTCONTNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for BUDUNIQ
            /// </summary>
            public const string BUDUNIQ = "BUDUNIQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FROMPMBUDS
            /// </summary>
            public const string FROMPMBUDS = "FROMPMBUDS";

            /// <summary>
            /// Property for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FROMPMBUDS
            /// </summary>
            public const string RecalculateHomeRevenue = "RecalculateHomeRevenue";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FROMPMBUDS
            /// </summary>
            public const string RecalculateSourceRevenue = "RecalculateSourceRevenue";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FROMPMBUDS
            /// </summary>
            public const string NoRecalculation = "NoRecalculation";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of BudgetHeader Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for ContractUniq
            /// </summary>
            public const int ContractUniq = 2;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 3;

            /// <summary>
            /// Property Indexer for BudgetSet
            /// </summary>
            public const int BudgetSet = 4;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int CONTRACT = 5;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FMTCONTNO = 6;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for BUDUNIQ
            /// </summary>
            public const int BUDUNIQ = 7;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FROMPMBUDS
            /// </summary>
            public const int FROMPMBUDS = 8;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 9;


            /// <summary>
            /// Property Indexer for RevenueCAD
            /// </summary>
            public const int RevenueCAD = 15;

            /// <summary>
            /// Property Indexer for RevenueUSD
            /// </summary>
            public const int RevenueUSD = 16;
        }

        #endregion

    }
}