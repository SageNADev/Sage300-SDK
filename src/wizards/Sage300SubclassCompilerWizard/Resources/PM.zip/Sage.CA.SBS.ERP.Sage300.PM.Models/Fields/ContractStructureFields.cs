// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of ContractStructure Constants
    /// </summary>
    public partial class ContractStructure
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0011";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of ContractStructure Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for StructureCode
            /// </summary>
            public const string StructureCode = "JOBBRKID";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Prefix
            /// </summary>
            public const string Prefix = "DELIM0";

            /// <summary>
            /// Property for Segment1
            /// </summary>
            public const string Segment1 = "SEGMENT1";

            /// <summary>
            /// Property for Segment1Offset
            /// </summary>
            public const string Segment1Offset = "OFFSET1";

            /// <summary>
            /// Property for Segment1Length
            /// </summary>
            public const string Segment1Length = "LENGTH1";

            /// <summary>
            /// Property for ValidateSegment1
            /// </summary>
            public const string ValidateSegment1 = "VALIDATE1";

            /// <summary>
            /// Property for SegmentSeparator1
            /// </summary>
            public const string SegmentSeparator1 = "DELIM1";

            /// <summary>
            /// Property for Segment2
            /// </summary>
            public const string Segment2 = "SEGMENT2";

            /// <summary>
            /// Property for Segment2Offset
            /// </summary>
            public const string Segment2Offset = "OFFSET2";

            /// <summary>
            /// Property for Segment2Length
            /// </summary>
            public const string Segment2Length = "LENGTH2";

            /// <summary>
            /// Property for ValidateSegment2
            /// </summary>
            public const string ValidateSegment2 = "VALIDATE2";

            /// <summary>
            /// Property for SegmentSeparator2
            /// </summary>
            public const string SegmentSeparator2 = "DELIM2";

            /// <summary>
            /// Property for Segment3
            /// </summary>
            public const string Segment3 = "SEGMENT3";

            /// <summary>
            /// Property for Segment3Offset
            /// </summary>
            public const string Segment3Offset = "OFFSET3";

            /// <summary>
            /// Property for Segment3Length
            /// </summary>
            public const string Segment3Length = "LENGTH3";

            /// <summary>
            /// Property for ValidateSegment3
            /// </summary>
            public const string ValidateSegment3 = "VALIDATE3";

            /// <summary>
            /// Property for SegmentSeparator3
            /// </summary>
            public const string SegmentSeparator3 = "DELIM3";

            /// <summary>
            /// Property for Segment4
            /// </summary>
            public const string Segment4 = "SEGMENT4";

            /// <summary>
            /// Property for Segment4Offset
            /// </summary>
            public const string Segment4Offset = "OFFSET4";

            /// <summary>
            /// Property for Segment4Length
            /// </summary>
            public const string Segment4Length = "LENGTH4";

            /// <summary>
            /// Property for ValidateSegment4
            /// </summary>
            public const string ValidateSegment4 = "VALIDATE4";

            /// <summary>
            /// Property for SegmentSeparator4
            /// </summary>
            public const string SegmentSeparator4 = "DELIM4";

            /// <summary>
            /// Property for Segment5
            /// </summary>
            public const string Segment5 = "SEGMENT5";

            /// <summary>
            /// Property for Segment5Offset
            /// </summary>
            public const string Segment5Offset = "OFFSET5";

            /// <summary>
            /// Property for Segment5Length
            /// </summary>
            public const string Segment5Length = "LENGTH5";

            /// <summary>
            /// Property for ValidateSegment5
            /// </summary>
            public const string ValidateSegment5 = "VALIDATE5";

            /// <summary>
            /// Property for SegmentSeparator5
            /// </summary>
            public const string SegmentSeparator5 = "DELIM5";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of ContractStructure Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for StructureCode
            /// </summary>
            public const int StructureCode = 1;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Prefix
            /// </summary>
            public const int Prefix = 3;

            /// <summary>
            /// Property Indexer for Segment1
            /// </summary>
            public const int Segment1 = 4;

            /// <summary>
            /// Property Indexer for Segment1Offset
            /// </summary>
            public const int Segment1Offset = 5;

            /// <summary>
            /// Property Indexer for Segment1Length
            /// </summary>
            public const int Segment1Length = 6;

            /// <summary>
            /// Property Indexer for ValidateSegment1
            /// </summary>
            public const int ValidateSegment1 = 7;

            /// <summary>
            /// Property Indexer for SegmentSeparator1
            /// </summary>
            public const int SegmentSeparator1 = 8;

            /// <summary>
            /// Property Indexer for Segment2
            /// </summary>
            public const int Segment2 = 9;

            /// <summary>
            /// Property Indexer for Segment2Offset
            /// </summary>
            public const int Segment2Offset = 10;

            /// <summary>
            /// Property Indexer for Segment2Length
            /// </summary>
            public const int Segment2Length = 11;

            /// <summary>
            /// Property Indexer for ValidateSegment2
            /// </summary>
            public const int ValidateSegment2 = 12;

            /// <summary>
            /// Property Indexer for SegmentSeparator2
            /// </summary>
            public const int SegmentSeparator2 = 13;

            /// <summary>
            /// Property Indexer for Segment3
            /// </summary>
            public const int Segment3 = 14;

            /// <summary>
            /// Property Indexer for Segment3Offset
            /// </summary>
            public const int Segment3Offset = 15;

            /// <summary>
            /// Property Indexer for Segment3Length
            /// </summary>
            public const int Segment3Length = 16;

            /// <summary>
            /// Property Indexer for ValidateSegment3
            /// </summary>
            public const int ValidateSegment3 = 17;

            /// <summary>
            /// Property Indexer for SegmentSeparator3
            /// </summary>
            public const int SegmentSeparator3 = 18;

            /// <summary>
            /// Property Indexer for Segment4
            /// </summary>
            public const int Segment4 = 19;

            /// <summary>
            /// Property Indexer for Segment4Offset
            /// </summary>
            public const int Segment4Offset = 20;

            /// <summary>
            /// Property Indexer for Segment4Length
            /// </summary>
            public const int Segment4Length = 21;

            /// <summary>
            /// Property Indexer for ValidateSegment4
            /// </summary>
            public const int ValidateSegment4 = 22;

            /// <summary>
            /// Property Indexer for SegmentSeparator4
            /// </summary>
            public const int SegmentSeparator4 = 23;

            /// <summary>
            /// Property Indexer for Segment5
            /// </summary>
            public const int Segment5 = 24;

            /// <summary>
            /// Property Indexer for Segment5Offset
            /// </summary>
            public const int Segment5Offset = 25;

            /// <summary>
            /// Property Indexer for Segment5Length
            /// </summary>
            public const int Segment5Length = 26;

            /// <summary>
            /// Property Indexer for ValidateSegment5
            /// </summary>
            public const int ValidateSegment5 = 27;

            /// <summary>
            /// Property Indexer for SegmentSeparator5
            /// </summary>
            public const int SegmentSeparator5 = 28;


        }

        #endregion

    }
}