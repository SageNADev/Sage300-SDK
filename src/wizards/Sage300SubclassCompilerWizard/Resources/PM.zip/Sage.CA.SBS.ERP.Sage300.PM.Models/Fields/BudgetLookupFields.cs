// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of BudgetLookup Constants
    /// </summary>
    public partial class BudgetLookup
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0124";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of BudgetLookup Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ContractUniq
            /// </summary>
            public const string ContractUniq = "CTUNIQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for LINENUM
            /// </summary>
            public const string LINENUM = "LINENUM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string CONTRACT = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for BudgetSet
            /// </summary>
            public const string BudgetSet = "BUDGET";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for RevenueCurrency
            /// </summary>
            public const string RevenueCurrency = "REVCCY";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            /// <summary>
            /// Property for CurrencyType
            /// </summary>
            public const string CurrencyType = "CCYTYPE";

            /// <summary>
            /// Property for CopyMethod
            /// </summary>
            public const string CopyMethod = "METHOD";

            /// <summary>
            /// Property for FixedSpreadBaseAmount
            /// </summary>
            public const string FixedSpreadBaseAmount = "AMOUNT";

            /// <summary>
            /// Property for PercentIncrease
            /// </summary>
            public const string PercentIncrease = "PERCENT";

            /// <summary>
            /// Property for AmountIncrease
            /// </summary>
            public const string AmountIncrease = "INCAMT";

            /// <summary>
            /// Property for CopyQuantity
            /// </summary>
            public const string CopyQuantity = "COPYQ";

            /// <summary>
            /// Property for CopyCostSource
            /// </summary>
            public const string CopyCostSource = "COPYCS";

            /// <summary>
            /// Property for CopyCostFunctional
            /// </summary>
            public const string CopyCostFunctional = "COPYCH";

            /// <summary>
            /// Property for CopyRevenueSource
            /// </summary>
            public const string CopyRevenueSource = "COPYRS";

            /// <summary>
            /// Property for CopyRevenueFunctional
            /// </summary>
            public const string CopyRevenueFunctional = "COPYRH";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for INQ1
            /// </summary>
            public const string INQ1 = "INQ1";

            /// <summary>
            /// Property for INQ2
            /// </summary>
            public const string INQ2 = "INQ2";

            /// <summary>
            /// Property for INQ3
            /// </summary>
            public const string INQ3 = "INQ3";

            /// <summary>
            /// Property for INQ4
            /// </summary>
            public const string INQ4 = "INQ4";

            /// <summary>
            /// Property for INQ5
            /// </summary>
            public const string INQ5 = "INQ5";

            /// <summary>
            /// Property for INQ6
            /// </summary>
            public const string INQ6 = "INQ6";

            /// <summary>
            /// Property for INQ7
            /// </summary>
            public const string INQ7 = "INQ7";

            /// <summary>
            /// Property for INQ8
            /// </summary>
            public const string INQ8 = "INQ8";

            /// <summary>
            /// Property for INQ9
            /// </summary>
            public const string INQ9 = "INQ9";

            /// <summary>
            /// Property for INQ10
            /// </summary>
            public const string INQ10 = "INQ10";

            /// <summary>
            /// Property for INQ11
            /// </summary>
            public const string INQ11 = "INQ11";

            /// <summary>
            /// Property for INQ12
            /// </summary>
            public const string INQ12 = "INQ12";

            /// <summary>
            /// Property for INQ13
            /// </summary>
            public const string INQ13 = "INQ13";

            /// <summary>
            /// Property for INQ14
            /// </summary>
            public const string INQ14 = "INQ14";

            /// <summary>
            /// Property for INQ15
            /// </summary>
            public const string INQ15 = "INQ15";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for INQTOTAL
            /// </summary>
            public const string INQTOTAL = "INQTOTAL";

            /// <summary>
            /// Property for INCS1
            /// </summary>
            public const string INCS1 = "INCS1";

            /// <summary>
            /// Property for INCS2
            /// </summary>
            public const string INCS2 = "INCS2";

            /// <summary>
            /// Property for INCS3
            /// </summary>
            public const string INCS3 = "INCS3";

            /// <summary>
            /// Property for INCS4
            /// </summary>
            public const string INCS4 = "INCS4";

            /// <summary>
            /// Property for INCS5
            /// </summary>
            public const string INCS5 = "INCS5";

            /// <summary>
            /// Property for INCS6
            /// </summary>
            public const string INCS6 = "INCS6";

            /// <summary>
            /// Property for INCS7
            /// </summary>
            public const string INCS7 = "INCS7";

            /// <summary>
            /// Property for INCS8
            /// </summary>
            public const string INCS8 = "INCS8";

            /// <summary>
            /// Property for INCS9
            /// </summary>
            public const string INCS9 = "INCS9";

            /// <summary>
            /// Property for INCS10
            /// </summary>
            public const string INCS10 = "INCS10";

            /// <summary>
            /// Property for INCS11
            /// </summary>
            public const string INCS11 = "INCS11";

            /// <summary>
            /// Property for INCS12
            /// </summary>
            public const string INCS12 = "INCS12";

            /// <summary>
            /// Property for INCS13
            /// </summary>
            public const string INCS13 = "INCS13";

            /// <summary>
            /// Property for INCS14
            /// </summary>
            public const string INCS14 = "INCS14";

            /// <summary>
            /// Property for INCS15
            /// </summary>
            public const string INCS15 = "INCS15";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for INCSTOTAL
            /// </summary>
            public const string INCSTOTAL = "INCSTOTAL";

            /// <summary>
            /// Property for INCH1
            /// </summary>
            public const string INCH1 = "INCH1";

            /// <summary>
            /// Property for INCH2
            /// </summary>
            public const string INCH2 = "INCH2";

            /// <summary>
            /// Property for INCH3
            /// </summary>
            public const string INCH3 = "INCH3";

            /// <summary>
            /// Property for INCH4
            /// </summary>
            public const string INCH4 = "INCH4";

            /// <summary>
            /// Property for INCH5
            /// </summary>
            public const string INCH5 = "INCH5";

            /// <summary>
            /// Property for INCH6
            /// </summary>
            public const string INCH6 = "INCH6";

            /// <summary>
            /// Property for INCH7
            /// </summary>
            public const string INCH7 = "INCH7";

            /// <summary>
            /// Property for INCH8
            /// </summary>
            public const string INCH8 = "INCH8";

            /// <summary>
            /// Property for INCH9
            /// </summary>
            public const string INCH9 = "INCH9";

            /// <summary>
            /// Property for INCH10
            /// </summary>
            public const string INCH10 = "INCH10";

            /// <summary>
            /// Property for INCH11
            /// </summary>
            public const string INCH11 = "INCH11";

            /// <summary>
            /// Property for INCH12
            /// </summary>
            public const string INCH12 = "INCH12";

            /// <summary>
            /// Property for INCH13
            /// </summary>
            public const string INCH13 = "INCH13";

            /// <summary>
            /// Property for INCH14
            /// </summary>
            public const string INCH14 = "INCH14";

            /// <summary>
            /// Property for INCH15
            /// </summary>
            public const string INCH15 = "INCH15";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for INCHTOTAL
            /// </summary>
            public const string INCHTOTAL = "INCHTOTAL";

            /// <summary>
            /// Property for INRS1
            /// </summary>
            public const string INRS1 = "INRS1";

            /// <summary>
            /// Property for INRS2
            /// </summary>
            public const string INRS2 = "INRS2";

            /// <summary>
            /// Property for INRS3
            /// </summary>
            public const string INRS3 = "INRS3";

            /// <summary>
            /// Property for INRS4
            /// </summary>
            public const string INRS4 = "INRS4";

            /// <summary>
            /// Property for INRS5
            /// </summary>
            public const string INRS5 = "INRS5";

            /// <summary>
            /// Property for INRS6
            /// </summary>
            public const string INRS6 = "INRS6";

            /// <summary>
            /// Property for INRS7
            /// </summary>
            public const string INRS7 = "INRS7";

            /// <summary>
            /// Property for INRS8
            /// </summary>
            public const string INRS8 = "INRS8";

            /// <summary>
            /// Property for INRS9
            /// </summary>
            public const string INRS9 = "INRS9";

            /// <summary>
            /// Property for INRS10
            /// </summary>
            public const string INRS10 = "INRS10";

            /// <summary>
            /// Property for INRS11
            /// </summary>
            public const string INRS11 = "INRS11";

            /// <summary>
            /// Property for INRS12
            /// </summary>
            public const string INRS12 = "INRS12";

            /// <summary>
            /// Property for INRS13
            /// </summary>
            public const string INRS13 = "INRS13";

            /// <summary>
            /// Property for INRS14
            /// </summary>
            public const string INRS14 = "INRS14";

            /// <summary>
            /// Property for INRS15
            /// </summary>
            public const string INRS15 = "INRS15";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for INRSTOTAL
            /// </summary>
            public const string INRSTOTAL = "INRSTOTAL";

            /// <summary>
            /// Property for INRH1
            /// </summary>
            public const string INRH1 = "INRH1";

            /// <summary>
            /// Property for INRH2
            /// </summary>
            public const string INRH2 = "INRH2";

            /// <summary>
            /// Property for INRH3
            /// </summary>
            public const string INRH3 = "INRH3";

            /// <summary>
            /// Property for INRH4
            /// </summary>
            public const string INRH4 = "INRH4";

            /// <summary>
            /// Property for INRH5
            /// </summary>
            public const string INRH5 = "INRH5";

            /// <summary>
            /// Property for INRH6
            /// </summary>
            public const string INRH6 = "INRH6";

            /// <summary>
            /// Property for INRH7
            /// </summary>
            public const string INRH7 = "INRH7";

            /// <summary>
            /// Property for INRH8
            /// </summary>
            public const string INRH8 = "INRH8";

            /// <summary>
            /// Property for INRH9
            /// </summary>
            public const string INRH9 = "INRH9";

            /// <summary>
            /// Property for INRH10
            /// </summary>
            public const string INRH10 = "INRH10";

            /// <summary>
            /// Property for INRH11
            /// </summary>
            public const string INRH11 = "INRH11";

            /// <summary>
            /// Property for INRH12
            /// </summary>
            public const string INRH12 = "INRH12";

            /// <summary>
            /// Property for INRH13
            /// </summary>
            public const string INRH13 = "INRH13";

            /// <summary>
            /// Property for INRH14
            /// </summary>
            public const string INRH14 = "INRH14";

            /// <summary>
            /// Property for INRH15
            /// </summary>
            public const string INRH15 = "INRH15";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for INRHTOTAL
            /// </summary>
            public const string INRHTOTAL = "INRHTOTAL";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FMTCONTNO = "FMTCONTNO";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of BudgetLookup Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ContractUniq
            /// </summary>
            public const int ContractUniq = 1;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for LINENUM
            /// </summary>
            public const int LINENUM = 2;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int CONTRACT = 3;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 4;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 5;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 6;

            /// <summary>
            /// Property Indexer for BudgetSet
            /// </summary>
            public const int BudgetSet = 7;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 8;

            /// <summary>
            /// Property Indexer for RevenueCurrency
            /// </summary>
            public const int RevenueCurrency = 9;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 10;

            /// <summary>
            /// Property Indexer for CurrencyType
            /// </summary>
            public const int CurrencyType = 11;

            /// <summary>
            /// Property Indexer for CopyMethod
            /// </summary>
            public const int CopyMethod = 12;

            /// <summary>
            /// Property Indexer for FixedSpreadBaseAmount
            /// </summary>
            public const int FixedSpreadBaseAmount = 13;

            /// <summary>
            /// Property Indexer for PercentIncrease
            /// </summary>
            public const int PercentIncrease = 14;

            /// <summary>
            /// Property Indexer for AmountIncrease
            /// </summary>
            public const int AmountIncrease = 15;

            /// <summary>
            /// Property Indexer for CopyQuantity
            /// </summary>
            public const int CopyQuantity = 16;

            /// <summary>
            /// Property Indexer for CopyCostSource
            /// </summary>
            public const int CopyCostSource = 17;

            /// <summary>
            /// Property Indexer for CopyCostFunctional
            /// </summary>
            public const int CopyCostFunctional = 18;

            /// <summary>
            /// Property Indexer for CopyRevenueSource
            /// </summary>
            public const int CopyRevenueSource = 19;

            /// <summary>
            /// Property Indexer for CopyRevenueFunctional
            /// </summary>
            public const int CopyRevenueFunctional = 20;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 21;

            /// <summary>
            /// Property Indexer for INQ1
            /// </summary>
            public const int INQ1 = 22;

            /// <summary>
            /// Property Indexer for INQ2
            /// </summary>
            public const int INQ2 = 23;

            /// <summary>
            /// Property Indexer for INQ3
            /// </summary>
            public const int INQ3 = 24;

            /// <summary>
            /// Property Indexer for INQ4
            /// </summary>
            public const int INQ4 = 25;

            /// <summary>
            /// Property Indexer for INQ5
            /// </summary>
            public const int INQ5 = 26;

            /// <summary>
            /// Property Indexer for INQ6
            /// </summary>
            public const int INQ6 = 27;

            /// <summary>
            /// Property Indexer for INQ7
            /// </summary>
            public const int INQ7 = 28;

            /// <summary>
            /// Property Indexer for INQ8
            /// </summary>
            public const int INQ8 = 29;

            /// <summary>
            /// Property Indexer for INQ9
            /// </summary>
            public const int INQ9 = 30;

            /// <summary>
            /// Property Indexer for INQ10
            /// </summary>
            public const int INQ10 = 31;

            /// <summary>
            /// Property Indexer for INQ11
            /// </summary>
            public const int INQ11 = 32;

            /// <summary>
            /// Property Indexer for INQ12
            /// </summary>
            public const int INQ12 = 33;

            /// <summary>
            /// Property Indexer for INQ13
            /// </summary>
            public const int INQ13 = 34;

            /// <summary>
            /// Property Indexer for INQ14
            /// </summary>
            public const int INQ14 = 35;

            /// <summary>
            /// Property Indexer for INQ15
            /// </summary>
            public const int INQ15 = 36;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for INQTOTAL
            /// </summary>
            public const int INQTOTAL = 37;

            /// <summary>
            /// Property Indexer for INCS1
            /// </summary>
            public const int INCS1 = 38;

            /// <summary>
            /// Property Indexer for INCS2
            /// </summary>
            public const int INCS2 = 39;

            /// <summary>
            /// Property Indexer for INCS3
            /// </summary>
            public const int INCS3 = 40;

            /// <summary>
            /// Property Indexer for INCS4
            /// </summary>
            public const int INCS4 = 41;

            /// <summary>
            /// Property Indexer for INCS5
            /// </summary>
            public const int INCS5 = 42;

            /// <summary>
            /// Property Indexer for INCS6
            /// </summary>
            public const int INCS6 = 43;

            /// <summary>
            /// Property Indexer for INCS7
            /// </summary>
            public const int INCS7 = 44;

            /// <summary>
            /// Property Indexer for INCS8
            /// </summary>
            public const int INCS8 = 45;

            /// <summary>
            /// Property Indexer for INCS9
            /// </summary>
            public const int INCS9 = 46;

            /// <summary>
            /// Property Indexer for INCS10
            /// </summary>
            public const int INCS10 = 47;

            /// <summary>
            /// Property Indexer for INCS11
            /// </summary>
            public const int INCS11 = 48;

            /// <summary>
            /// Property Indexer for INCS12
            /// </summary>
            public const int INCS12 = 49;

            /// <summary>
            /// Property Indexer for INCS13
            /// </summary>
            public const int INCS13 = 50;

            /// <summary>
            /// Property Indexer for INCS14
            /// </summary>
            public const int INCS14 = 51;

            /// <summary>
            /// Property Indexer for INCS15
            /// </summary>
            public const int INCS15 = 52;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for INCSTOTAL
            /// </summary>
            public const int INCSTOTAL = 53;

            /// <summary>
            /// Property Indexer for INCH1
            /// </summary>
            public const int INCH1 = 54;

            /// <summary>
            /// Property Indexer for INCH2
            /// </summary>
            public const int INCH2 = 55;

            /// <summary>
            /// Property Indexer for INCH3
            /// </summary>
            public const int INCH3 = 56;

            /// <summary>
            /// Property Indexer for INCH4
            /// </summary>
            public const int INCH4 = 57;

            /// <summary>
            /// Property Indexer for INCH5
            /// </summary>
            public const int INCH5 = 58;

            /// <summary>
            /// Property Indexer for INCH6
            /// </summary>
            public const int INCH6 = 59;

            /// <summary>
            /// Property Indexer for INCH7
            /// </summary>
            public const int INCH7 = 60;

            /// <summary>
            /// Property Indexer for INCH8
            /// </summary>
            public const int INCH8 = 61;

            /// <summary>
            /// Property Indexer for INCH9
            /// </summary>
            public const int INCH9 = 62;

            /// <summary>
            /// Property Indexer for INCH10
            /// </summary>
            public const int INCH10 = 63;

            /// <summary>
            /// Property Indexer for INCH11
            /// </summary>
            public const int INCH11 = 64;

            /// <summary>
            /// Property Indexer for INCH12
            /// </summary>
            public const int INCH12 = 65;

            /// <summary>
            /// Property Indexer for INCH13
            /// </summary>
            public const int INCH13 = 66;

            /// <summary>
            /// Property Indexer for INCH14
            /// </summary>
            public const int INCH14 = 67;

            /// <summary>
            /// Property Indexer for INCH15
            /// </summary>
            public const int INCH15 = 68;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for INCHTOTAL
            /// </summary>
            public const int INCHTOTAL = 69;

            /// <summary>
            /// Property Indexer for INRS1
            /// </summary>
            public const int INRS1 = 70;

            /// <summary>
            /// Property Indexer for INRS2
            /// </summary>
            public const int INRS2 = 71;

            /// <summary>
            /// Property Indexer for INRS3
            /// </summary>
            public const int INRS3 = 72;

            /// <summary>
            /// Property Indexer for INRS4
            /// </summary>
            public const int INRS4 = 73;

            /// <summary>
            /// Property Indexer for INRS5
            /// </summary>
            public const int INRS5 = 74;

            /// <summary>
            /// Property Indexer for INRS6
            /// </summary>
            public const int INRS6 = 75;

            /// <summary>
            /// Property Indexer for INRS7
            /// </summary>
            public const int INRS7 = 76;

            /// <summary>
            /// Property Indexer for INRS8
            /// </summary>
            public const int INRS8 = 77;

            /// <summary>
            /// Property Indexer for INRS9
            /// </summary>
            public const int INRS9 = 78;

            /// <summary>
            /// Property Indexer for INRS10
            /// </summary>
            public const int INRS10 = 79;

            /// <summary>
            /// Property Indexer for INRS11
            /// </summary>
            public const int INRS11 = 80;

            /// <summary>
            /// Property Indexer for INRS12
            /// </summary>
            public const int INRS12 = 81;

            /// <summary>
            /// Property Indexer for INRS13
            /// </summary>
            public const int INRS13 = 82;

            /// <summary>
            /// Property Indexer for INRS14
            /// </summary>
            public const int INRS14 = 83;

            /// <summary>
            /// Property Indexer for INRS15
            /// </summary>
            public const int INRS15 = 84;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for INRSTOTAL
            /// </summary>
            public const int INRSTOTAL = 85;

            /// <summary>
            /// Property Indexer for INRH1
            /// </summary>
            public const int INRH1 = 86;

            /// <summary>
            /// Property Indexer for INRH2
            /// </summary>
            public const int INRH2 = 87;

            /// <summary>
            /// Property Indexer for INRH3
            /// </summary>
            public const int INRH3 = 88;

            /// <summary>
            /// Property Indexer for INRH4
            /// </summary>
            public const int INRH4 = 89;

            /// <summary>
            /// Property Indexer for INRH5
            /// </summary>
            public const int INRH5 = 90;

            /// <summary>
            /// Property Indexer for INRH6
            /// </summary>
            public const int INRH6 = 91;

            /// <summary>
            /// Property Indexer for INRH7
            /// </summary>
            public const int INRH7 = 92;

            /// <summary>
            /// Property Indexer for INRH8
            /// </summary>
            public const int INRH8 = 93;

            /// <summary>
            /// Property Indexer for INRH9
            /// </summary>
            public const int INRH9 = 94;

            /// <summary>
            /// Property Indexer for INRH10
            /// </summary>
            public const int INRH10 = 95;

            /// <summary>
            /// Property Indexer for INRH11
            /// </summary>
            public const int INRH11 = 96;

            /// <summary>
            /// Property Indexer for INRH12
            /// </summary>
            public const int INRH12 = 97;

            /// <summary>
            /// Property Indexer for INRH13
            /// </summary>
            public const int INRH13 = 98;

            /// <summary>
            /// Property Indexer for INRH14
            /// </summary>
            public const int INRH14 = 99;

            /// <summary>
            /// Property Indexer for INRH15
            /// </summary>
            public const int INRH15 = 100;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for INRHTOTAL
            /// </summary>
            public const int INRHTOTAL = 101;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FMTCONTNO = 102;


        }

        #endregion

    }
}