// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of Equipment Constants
    /// </summary>
    public partial class Equipment
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0030";

        #region Fields

        /// <summary>
        /// Contains list of Equipment Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for EquipmentNumber
            /// </summary>
            public const string EquipmentNumber = "EQUIPNO";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCALPER";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ExtendedCost (EXTCOSTSR)
            /// </summary>
            public const string ExtendedCost = "EXTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ExtendedCostHome (EXTCOSTHM)
            /// </summary>
            public const string ExtendedCostHome = "EXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OHSR
            /// </summary>
            public const string OHSR = "OHSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OHHM
            /// </summary>
            public const string OHHM = "OHHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTCOSTSR
            /// </summary>
            public const string TOTCOSTSR = "TOTCOSTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTCOSTHM
            /// </summary>
            public const string TOTCOSTHM = "TOTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTBILLSR
            /// </summary>
            public const string TOTBILLSR = "TOTBILLSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TOTBILLHM
            /// </summary>
            public const string TOTBILLHM = "TOTBILLHM";

            /// <summary>
            /// Property for TotalQuantity
            /// </summary>
            public const string TotalQuantity = "TOTQTY";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "COMPLETE";

            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "PRINTSTAT";

            /// <summary>
            /// Property for TransactionStatus
            /// </summary>
            public const string TransactionStatus = "TRANSTAT";

            /// <summary>
            /// Property for NextDetailNumber
            /// </summary>
            public const string NextDetailNumber = "NEXTDTLNUM";

            /// <summary>
            /// Property for NumberOfDetails
            /// </summary>
            public const string NumberOfDetails = "NUMDTL";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for CreatedBy
            /// </summary>
            public const string CreatedBy = "CREATEBY";

            /// <summary>
            /// Property for CreatedOn
            /// </summary>
            public const string CreatedOn = "CREATEDT";

            /// <summary>
            /// Property for CreatedAt
            /// </summary>
            public const string CreatedAt = "CREATETM";

            /// <summary>
            /// Property for ApprovedBy
            /// </summary>
            public const string ApprovedBy = "APPROVEBY";

            /// <summary>
            /// Property for ApprovedOn
            /// </summary>
            public const string ApprovedOn = "APPROVEDT";

            /// <summary>
            /// Property for ApprovedAt
            /// </summary>
            public const string ApprovedAt = "APPROVETM";

            /// <summary>
            /// Property for PostedBy
            /// </summary>
            public const string PostedBy = "POSTEDBY";

            /// <summary>
            /// Property for PostedOn
            /// </summary>
            public const string PostedOn = "POSTEDDT";

            /// <summary>
            /// Property for PostedAt
            /// </summary>
            public const string PostedAt = "POSTEDTM";

            /// <summary>
            /// Property for GLEntryDescription
            /// </summary>
            public const string GLEntryDescription = "GLHDESC";

            /// <summary>
            /// Property for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for ShowProgressBarDuringPosting
            /// </summary>
            public const string ShowProgressBarDuringPosting = "BMETER";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of Equipment Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for EquipmentNumber
            /// </summary>
            public const int EquipmentNumber = 2;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 3;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 4;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 5;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 6;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 7;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ExtendedCost (EXTCOSTSR)
            /// </summary>
            public const int ExtendedCost = 8;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ExtendedCostHome (EXTCOSTHM)
            /// </summary>
            public const int ExtendedCostHome = 9;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OHSR
            /// </summary>
            public const int OHSR = 10;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OHHM
            /// </summary>
            public const int OHHM = 11;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTCOSTSR
            /// </summary>
            public const int TOTCOSTSR = 12;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTCOSTHM
            /// </summary>
            public const int TOTCOSTHM = 13;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTBILLSR
            /// </summary>
            public const int TOTBILLSR = 14;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TOTBILLHM
            /// </summary>
            public const int TOTBILLHM = 15;

            /// <summary>
            /// Property Indexer for TotalQuantity
            /// </summary>
            public const int TotalQuantity = 16;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 17;

            /// <summary>
            /// Property Indexer for Printed
            /// </summary>
            public const int Printed = 18;

            /// <summary>
            /// Property Indexer for TransactionStatus
            /// </summary>
            public const int TransactionStatus = 19;

            /// <summary>
            /// Property Indexer for NextDetailNumber
            /// </summary>
            public const int NextDetailNumber = 20;

            /// <summary>
            /// Property Indexer for NumberOfDetails
            /// </summary>
            public const int NumberOfDetails = 21;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 22;

            /// <summary>
            /// Property Indexer for CreatedBy
            /// </summary>
            public const int CreatedBy = 23;

            /// <summary>
            /// Property Indexer for CreatedOn
            /// </summary>
            public const int CreatedOn = 24;

            /// <summary>
            /// Property Indexer for CreatedAt
            /// </summary>
            public const int CreatedAt = 25;

            /// <summary>
            /// Property Indexer for ApprovedBy
            /// </summary>
            public const int ApprovedBy = 26;

            /// <summary>
            /// Property Indexer for ApprovedOn
            /// </summary>
            public const int ApprovedOn = 27;

            /// <summary>
            /// Property Indexer for ApprovedAt
            /// </summary>
            public const int ApprovedAt = 28;

            /// <summary>
            /// Property Indexer for PostedBy
            /// </summary>
            public const int PostedBy = 29;

            /// <summary>
            /// Property Indexer for PostedOn
            /// </summary>
            public const int PostedOn = 30;

            /// <summary>
            /// Property Indexer for PostedAt
            /// </summary>
            public const int PostedAt = 31;

            /// <summary>
            /// Property Indexer for GLEntryDescription
            /// </summary>
            public const int GLEntryDescription = 32;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 33;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 34;

            /// <summary>
            /// Property Indexer for ShowProgressBarDuringPosting
            /// </summary>
            public const int ShowProgressBarDuringPosting = 1000;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1001;
        }

        #endregion
    }
}
