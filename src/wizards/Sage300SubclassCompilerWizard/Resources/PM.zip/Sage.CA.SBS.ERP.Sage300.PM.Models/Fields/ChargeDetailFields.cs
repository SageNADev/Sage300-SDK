// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of ChargesDetail Constants
    /// </summary>
    public partial class ChargeDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0055";


        #region Properties

        /// <summary>
        /// Contains list of ChargesDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for ChargeNumber
            /// </summary>
            public const string ChargeNumber = "CHRGNO";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string MyContract = "FMTCONTNO";

            /// <summary>
            /// Property for UnformattedContract
            /// </summary>
            public const string UnformattedMycontract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for ChargeCode
            /// </summary>
            public const string ChargeCode = "CHARGECODE";

            // TODO The naming convention of this property has to be manually evaluated
            // WHICH description is this?
            /// <summary>
            /// Property for DESC
            /// </summary>
            public const string DESC = "DESC";

            //Which field is this?
            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "TYPE";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QUANTITY";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEM";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UOM";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillingAmount
            /// </summary>
            public const string BillingAmount = "BILLRATE";

            /// <summary>
            /// Property for ExtendedBillingAmount
            /// </summary>
            public const string ExtendedBillingAmount = "EXTBILLSR";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCCY";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TCLASS5";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TINCLUDED1";

            /// <summary>
            /// Property for TaxIncluded2
            /// </summary>
            public const string TaxIncluded2 = "TINCLUDED2";

            /// <summary>
            /// Property for TaxIncluded3
            /// </summary>
            public const string TaxIncluded3 = "TINCLUDED3";

            /// <summary>
            /// Property for TaxIncluded4
            /// </summary>
            public const string TaxIncluded4 = "TINCLUDED4";

            /// <summary>
            /// Property for TaxIncluded5
            /// </summary>
            public const string TaxIncluded5 = "TINCLUDED5";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string MycontractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALUES
            /// </summary>
            public const string VALUES = "VALUES";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ITEMDESC
            /// </summary>
            public const string ITEMDESC = "ITEMDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RESDESC
            /// </summary>
            public const string RESDESC = "RESDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for HASOPT
            /// </summary>
            public const string HASOPT = "HASOPT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTDESC
            /// </summary>
            public const string CONTDESC = "CONTDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PROJDESC
            /// </summary>
            public const string PROJDESC = "PROJDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CATDESC
            /// </summary>
            public const string CATDESC = "CATDESC";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of ChargesDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for ChargeNumber
            /// </summary>
            public const int ChargeNumber = 3;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int MyContract = 4;

            /// <summary>
            /// Property Indexer for UnformattedContract
            /// </summary>
            public const int UnformattedMycontract = 5;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 6;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 7;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 8;

            /// <summary>
            /// Property Indexer for ChargeCode
            /// </summary>
            public const int ChargeCode = 9;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for DESC
            /// </summary>
            public const int DESC = 10;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 11;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 12;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 13;

            /// <summary>
            /// Property Indexer for ARUnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 14;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 15;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 16;

            /// <summary>
            /// Property Indexer for BillingAmount
            /// </summary>
            public const int BillingAmount = 17;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmount
            /// </summary>
            public const int ExtendedBillingAmount = 18;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 20;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 21;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 22;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 23;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 24;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 25;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 26;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 27;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 28;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 29;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 30;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 31;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 32;

            /// <summary>
            /// Property Indexer for TaxIncluded2
            /// </summary>
            public const int TaxIncluded2 = 33;

            /// <summary>
            /// Property Indexer for TaxIncluded3
            /// </summary>
            public const int TaxIncluded3 = 34;

            /// <summary>
            /// Property Indexer for TaxIncluded4
            /// </summary>
            public const int TaxIncluded4 = 35;

            /// <summary>
            /// Property Indexer for TaxIncluded5
            /// </summary>
            public const int TaxIncluded5 = 36;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int MycontractStyle = 37;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 38;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 39;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 40;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 41;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALUES
            /// </summary>
            public const int VALUES = 42;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1001;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ITEMDESC
            /// </summary>
            public const int ITEMDESC = 1005;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RESDESC
            /// </summary>
            public const int RESDESC = 1006;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for HASOPT
            /// </summary>
            public const int HASOPT = 1014;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTDESC
            /// </summary>
            public const int CONTDESC = 1009;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PROJDESC
            /// </summary>
            public const int PROJDESC = 1010;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CATDESC
            /// </summary>
            public const int CATDESC = 1011;


        }

        #endregion

    }
}