// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of AdjustmentsDetail Constants
    /// </summary>
    public partial class AdjustmentsDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0063";


        #region Properties

        /// <summary>
        /// Contains list of AdjustmentsDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for AdjustmentNumber
            /// </summary>
            public const string AdjustmentNumber = "ADJUSTNO";

            /// <summary>
            /// Property for AdjustmentType
            /// </summary>
            public const string AdjustmentType = "ADJTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FMTCONTNO = "FMTCONTNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string CONTRACT = "CONTRACT";

            /// <summary>
            /// Property for OriginalProject
            /// </summary>
            public const string OriginalProject = "PROJECT";

            /// <summary>
            /// Property for OriginalCategory
            /// </summary>
            public const string OriginalCategory = "CATEGORY";

            /// <summary>
            /// Property for OriginalResource
            /// </summary>
            public const string OriginalResource = "RESOURCE";

            /// <summary>
            /// Property for FromUnformattedItemNumber
            /// </summary>
            public const string FromUnformattedItemNumber = "ITEMNO";

            /// <summary>
            /// Property for CostOrRevenue
            /// </summary>
            public const string CostOrRevenue = "COSTREV";

            /// <summary>
            /// Property for CostNumber
            /// </summary>
            public const string CostNumber = "COSTNUM";

            /// <summary>
            /// Property for RevenueNumber
            /// </summary>
            public const string RevenueNumber = "REVNUM";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "DOCNUM";

            /// <summary>
            /// Property for OriginalBillingType
            /// </summary>
            public const string OriginalBillingType = "OBILLTYPE";

            /// <summary>
            /// Property for OriginalARItemNumber
            /// </summary>
            public const string OriginalARItemNumber = "OARITEM";

            /// <summary>
            /// Property for OriginalARUnitOfMeasure
            /// </summary>
            public const string OriginalARUnitOfMeasure = "OARUOM";

            /// <summary>
            /// Property for OriginalICUnitOfMeasure
            /// </summary>
            public const string OriginalICUnitOfMeasure = "OICUOM";

            /// <summary>
            /// Property for OriginalQuantity
            /// </summary>
            public const string OriginalQuantity = "OQUANTITY";

            /// <summary>
            /// Property for OriginalUnitCost
            /// </summary>
            public const string OriginalUnitCost = "OUNITCOST";

            /// <summary>
            /// Property for OriginalBillingRate
            /// </summary>
            public const string OriginalBillingRate = "OBILLRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OEXTCOSTHM
            /// </summary>
            public const string OEXTCOSTHM = "OEXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for OEXTCOSTSR
            /// </summary>
            public const string OEXTCOSTSR = "OEXTCOSTSR";

            /// <summary>
            /// Property for OriginalExtendedBillingAmount
            /// </summary>
            public const string OriginalExtendedBillingAmount = "OEXTBILLSR";

            /// <summary>
            /// Property for OriginalLaborType
            /// </summary>
            public const string OriginalLaborType = "OLABOR";

            /// <summary>
            /// Property for OriginalLaborRate
            /// </summary>
            public const string OriginalLaborRate = "OLABORRATE";

            /// <summary>
            /// Property for OriginalLaborPercentage
            /// </summary>
            public const string OriginalLaborPercentage = "OLABORPER";

            /// <summary>
            /// Property for OriginalLaborAmount
            /// </summary>
            public const string OriginalLaborAmount = "OLABORAMT";

            /// <summary>
            /// Property for OriginalOverheadType
            /// </summary>
            public const string OriginalOverheadType = "OOVERHD";

            /// <summary>
            /// Property for OriginalOverheadRate
            /// </summary>
            public const string OriginalOverheadRate = "OOHEADRATE";

            /// <summary>
            /// Property for OriginalOverheadPercentage
            /// </summary>
            public const string OriginalOverheadPercentage = "OHEADPER";

            /// <summary>
            /// Property for OriginalOverheadAmount
            /// </summary>
            public const string OriginalOverheadAmount = "OOHAMT";

            /// <summary>
            /// Property for OriginalTotalAmount
            /// </summary>
            public const string OriginalTotalAmount = "OTOTAMTHM";

            /// <summary>
            /// Property for OriginalBillingCurrency
            /// </summary>
            public const string OriginalBillingCurrency = "OBILLCCY";

            /// <summary>
            /// Property for OriginalProjectStyle
            /// </summary>
            public const string OriginalProjectStyle = "OCONTSTYLE";

            /// <summary>
            /// Property for OriginalProjectType
            /// </summary>
            public const string OriginalProjectType = "OPROJTYPE";

            /// <summary>
            /// Property for OriginalCustomerNumber
            /// </summary>
            public const string OriginalCustomerNumber = "OCUSTOMER";

            /// <summary>
            /// Property for OriginalAccountingMethod
            /// </summary>
            public const string OriginalAccountingMethod = "OREVREC";

            /// <summary>
            /// Property for OriginalInvoiceType
            /// </summary>
            public const string OriginalInvoiceType = "OINVTYPE";

            /// <summary>
            /// Property for FromWIPAccount
            /// </summary>
            public const string FromWIPAccount = "OWIPACCT";

            /// <summary>
            /// Property for FromTransactionAccount
            /// </summary>
            public const string FromTransactionAccount = "OTRANACCT";

            /// <summary>
            /// Property for FromRevenueAccount
            /// </summary>
            public const string FromRevenueAccount = "OREVACCT";

            /// <summary>
            /// Property for FromOverheadAccount
            /// </summary>
            public const string FromOverheadAccount = "OOHACCT";

            /// <summary>
            /// Property for FromLaborAccount
            /// </summary>
            public const string FromLaborAccount = "OLABACCT";

            /// <summary>
            /// Property for FromCostVarianceAccount
            /// </summary>
            public const string FromCostVarianceAccount = "OCVACCT";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCALPER";

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VENDORID";

            /// <summary>
            /// Property for Module
            /// </summary>
            public const string Module = "MODULE";

            /// <summary>
            /// Property for DocumentType
            /// </summary>
            public const string DocumentType = "DOCTYPE";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            /// <summary>
            /// Property for UserID
            /// </summary>
            public const string UserID = "USERID";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for TimeType
            /// </summary>
            public const string TimeType = "TIMETYPE";

            /// <summary>
            /// Property for ToWIPAccount
            /// </summary>
            public const string ToWIPAccount = "DWIPACCT";

            /// <summary>
            /// Property for ToTransactionAccount
            /// </summary>
            public const string ToTransactionAccount = "DTRANACCT";

            /// <summary>
            /// Property for ToRevenueAccount
            /// </summary>
            public const string ToRevenueAccount = "DREVACCT";

            /// <summary>
            /// Property for ToOverheadAccount
            /// </summary>
            public const string ToOverheadAccount = "DOHACCT";

            /// <summary>
            /// Property for ToLaborAccount
            /// </summary>
            public const string ToLaborAccount = "DLABACCT";

            /// <summary>
            /// Property for ToCostVarianceAccount
            /// </summary>
            public const string ToCostVarianceAccount = "DCVACCT";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for DFMTCONTNO
            /// </summary>
            public const string DFMTCONTNO = "DFMTCONTNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for DCONTRACT
            /// </summary>
            public const string DCONTRACT = "DCONTRACT";

            /// <summary>
            /// Property for RevisedProject
            /// </summary>
            public const string RevisedProject = "DPROJECT";

            /// <summary>
            /// Property for RevisedCategory
            /// </summary>
            public const string RevisedCategory = "DCATEGORY";

            /// <summary>
            /// Property for CostType
            /// </summary>
            public const string CostType = "DCOSTTYPE";

            /// <summary>
            /// Property for RevisedResource
            /// </summary>
            public const string RevisedResource = "DRESOURCE";

            /// <summary>
            /// Property for ToUnformattedItemNumber
            /// </summary>
            public const string ToUnformattedItemNumber = "DITEMNO";

            /// <summary>
            /// Property for ICBucketType
            /// </summary>
            public const string ICBucketType = "DICBTYPE";

            /// <summary>
            /// Property for ICDocumentNumber
            /// </summary>
            public const string ICDocumentNumber = "DICDOCNUM";

            /// <summary>
            /// Property for ICCostingMethod
            /// </summary>
            public const string ICCostingMethod = "DICCMETHOD";

            /// <summary>
            /// Property for ICTransactionDate
            /// </summary>
            public const string ICTransactionDate = "DICDATE";

            /// <summary>
            /// Property for ICLocation
            /// </summary>
            public const string ICLocation = "DICLOCAT";

            /// <summary>
            /// Property for RevisedBillingType
            /// </summary>
            public const string RevisedBillingType = "DBILLTYPE";

            /// <summary>
            /// Property for RevisedARItemNumber
            /// </summary>
            public const string RevisedARItemNumber = "DARITEM";

            /// <summary>
            /// Property for RevisedARUnitOfMeasure
            /// </summary>
            public const string RevisedARUnitOfMeasure = "DARUOM";

            /// <summary>
            /// Property for RevisedICUnitOfMeasure
            /// </summary>
            public const string RevisedICUnitOfMeasure = "DICUOM";

            /// <summary>
            /// Property for RevisedQuantity
            /// </summary>
            public const string RevisedQuantity = "DQUANTITY";

            /// <summary>
            /// Property for RevisedUnitCost
            /// </summary>
            public const string RevisedUnitCost = "DUNITCOST";

            /// <summary>
            /// Property for RevisedBillingRate
            /// </summary>
            public const string RevisedBillingRate = "DBILLRATE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for DEXTCOSTHM
            /// </summary>
            public const string DEXTCOSTHM = "DEXTCOSTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for DEXTCOSTSR
            /// </summary>
            public const string DEXTCOSTSR = "DEXTCOSTSR";

            /// <summary>
            /// Property for RevisedExtendedBillingAmount
            /// </summary>
            public const string RevisedExtendedBillingAmount = "DEXTBILLSR";

            /// <summary>
            /// Property for RevisedLaborType
            /// </summary>
            public const string RevisedLaborType = "DLABOR";

            /// <summary>
            /// Property for RevisedLaborRate
            /// </summary>
            public const string RevisedLaborRate = "DLABORRATE";

            /// <summary>
            /// Property for RevisedLaborPercentage
            /// </summary>
            public const string RevisedLaborPercentage = "DLABORPER";

            /// <summary>
            /// Property for RevisedLaborAmount
            /// </summary>
            public const string RevisedLaborAmount = "DLABORAMT";

            /// <summary>
            /// Property for RevisedOverheadAmount
            /// </summary>
            public const string RevisedOverheadAmount = "DOHAMT";

            /// <summary>
            /// Property for RevisedOverheadType
            /// </summary>
            public const string RevisedOverheadType = "DOVERHD";

            /// <summary>
            /// Property for RevisedOverheadRate
            /// </summary>
            public const string RevisedOverheadRate = "DOHEADRATE";

            /// <summary>
            /// Property for RevisedOverheadPercentage
            /// </summary>
            public const string RevisedOverheadPercentage = "DHEADPER";

            /// <summary>
            /// Property for RevisedTotalAmount
            /// </summary>
            public const string RevisedTotalAmount = "DTOTAMTHM";

            /// <summary>
            /// Property for RevisedBillingCurrency
            /// </summary>
            public const string RevisedBillingCurrency = "DBILLCCY";

            /// <summary>
            /// Property for RevisedProjectStyle
            /// </summary>
            public const string RevisedProjectStyle = "DCONTSTYLE";

            /// <summary>
            /// Property for RevisedProjectType
            /// </summary>
            public const string RevisedProjectType = "DPROJTYPE";

            /// <summary>
            /// Property for RevisedCustomerNumber
            /// </summary>
            public const string RevisedCustomerNumber = "DCUSTOMER";

            /// <summary>
            /// Property for RevisedAccountingMethod
            /// </summary>
            public const string RevisedAccountingMethod = "DREVREC";

            /// <summary>
            /// Property for RevisedInvoiceType
            /// </summary>
            public const string RevisedInvoiceType = "DINVTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for MANITEM
            /// </summary>
            public const string MANITEM = "MANITEM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALUES
            /// </summary>
            public const string VALUES = "VALUES";

            /// <summary>
            /// Property for OriginalEarningsCode
            /// </summary>
            public const string OriginalEarningsCode = "OEARNINGS";

            /// <summary>
            /// Property for RevisedEarningsCode
            /// </summary>
            public const string RevisedEarningsCode = "DEARNINGS";

            /// <summary>
            /// Property for OriginalPayType
            /// </summary>
            public const string OriginalPayType = "OPAYTYPE";

            /// <summary>
            /// Property for RevisedPayType
            /// </summary>
            public const string RevisedPayType = "DPAYTYPE";

            /// <summary>
            /// Property for GLDetailDescription
            /// </summary>
            public const string GLDetailDescription = "GLDDESC";

            /// <summary>
            /// Property for GLDetailReference
            /// </summary>
            public const string GLDetailReference = "GLDREF";

            /// <summary>
            /// Property for GLDetailComment
            /// </summary>
            public const string GLDetailComment = "GLCOMMENT";

            /// <summary>
            /// Property for CloseSN
            /// </summary>
            public const string CloseSN = "CLOSESN";

            /// <summary>
            /// Property for SNInterCommunicationID
            /// </summary>
            public const string SNInterCommunicationID = "PROID";

            /// <summary>
            /// Property for PopupSN
            /// </summary>
            public const string PopupSN = "POPUPSN";

            /// <summary>
            /// Property for PopupLT
            /// </summary>
            public const string PopupLT = "POPUPLT";

            /// <summary>
            /// Property for CloseLT
            /// </summary>
            public const string CloseLT = "CLOSELT";

            /// <summary>
            /// Property for LTInterCommunicationID
            /// </summary>
            public const string LTInterCommunicationID = "LTSETID";

            /// <summary>
            /// Property for ForcePopupSN
            /// </summary>
            public const string ForcePopupSN = "FORCEPOPSN";

            /// <summary>
            /// Property for ForcePopupLT
            /// </summary>
            public const string ForcePopupLT = "FORCEPOPLT";

            /// <summary>
            /// Property for GenerateICSequence
            /// </summary>
            public const string GenerateICSequence = "GENICSEQ";

            /// <summary>
            /// Property for OriginalEmployeeNumber
            /// </summary>
            public const string OriginalEmployeeNumber = "OSTAFFCODE";

            /// <summary>
            /// Property for RevisedEmployeeNumber
            /// </summary>
            public const string RevisedEmployeeNumber = "DSTAFFCODE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for HASOPT
            /// </summary>
            public const string HASOPT = "HASOPT";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of AdjustmentsDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for AdjustmentNumber
            /// </summary>
            public const int AdjustmentNumber = 3;

            /// <summary>
            /// Property Indexer for AdjustmentType
            /// </summary>
            public const int AdjustmentType = 4;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FMTCONTNO = 5;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int CONTRACT = 6;

            /// <summary>
            /// Property Indexer for OriginalProject
            /// </summary>
            public const int OriginalProject = 7;

            /// <summary>
            /// Property Indexer for OriginalCategory
            /// </summary>
            public const int OriginalCategory = 8;

            /// <summary>
            /// Property Indexer for OriginalResource
            /// </summary>
            public const int OriginalResource = 9;

            /// <summary>
            /// Property Indexer for FromUnformattedItemNumber
            /// </summary>
            public const int FromUnformattedItemNumber = 10;

            /// <summary>
            /// Property Indexer for CostOrRevenue
            /// </summary>
            public const int CostOrRevenue = 11;

            /// <summary>
            /// Property Indexer for CostNumber
            /// </summary>
            public const int CostNumber = 12;

            /// <summary>
            /// Property Indexer for RevenueNumber
            /// </summary>
            public const int RevenueNumber = 13;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 14;

            /// <summary>
            /// Property Indexer for OriginalBillingType
            /// </summary>
            public const int OriginalBillingType = 15;

            /// <summary>
            /// Property Indexer for OriginalARItemNumber
            /// </summary>
            public const int OriginalARItemNumber = 16;

            /// <summary>
            /// Property Indexer for OriginalARUnitOfMeasure
            /// </summary>
            public const int OriginalARUnitOfMeasure = 17;

            /// <summary>
            /// Property Indexer for OriginalICUnitOfMeasure
            /// </summary>
            public const int OriginalICUnitOfMeasure = 18;

            /// <summary>
            /// Property Indexer for OriginalQuantity
            /// </summary>
            public const int OriginalQuantity = 19;

            /// <summary>
            /// Property Indexer for OriginalUnitCost
            /// </summary>
            public const int OriginalUnitCost = 20;

            /// <summary>
            /// Property Indexer for OriginalBillingRate
            /// </summary>
            public const int OriginalBillingRate = 21;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OEXTCOSTHM
            /// </summary>
            public const int OEXTCOSTHM = 22;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for OEXTCOSTSR
            /// </summary>
            public const int OEXTCOSTSR = 23;

            /// <summary>
            /// Property Indexer for OriginalExtendedBillingAmount
            /// </summary>
            public const int OriginalExtendedBillingAmount = 24;

            /// <summary>
            /// Property Indexer for OriginalLaborType
            /// </summary>
            public const int OriginalLaborType = 25;

            /// <summary>
            /// Property Indexer for OriginalLaborRate
            /// </summary>
            public const int OriginalLaborRate = 26;

            /// <summary>
            /// Property Indexer for OriginalLaborPercentage
            /// </summary>
            public const int OriginalLaborPercentage = 27;

            /// <summary>
            /// Property Indexer for OriginalLaborAmount
            /// </summary>
            public const int OriginalLaborAmount = 28;

            /// <summary>
            /// Property Indexer for OriginalOverheadType
            /// </summary>
            public const int OriginalOverheadType = 29;

            /// <summary>
            /// Property Indexer for OriginalOverheadRate
            /// </summary>
            public const int OriginalOverheadRate = 30;

            /// <summary>
            /// Property Indexer for OriginalOverheadPercentage
            /// </summary>
            public const int OriginalOverheadPercentage = 31;

            /// <summary>
            /// Property Indexer for OriginalOverheadAmount
            /// </summary>
            public const int OriginalOverheadAmount = 32;

            /// <summary>
            /// Property Indexer for OriginalTotalAmount
            /// </summary>
            public const int OriginalTotalAmount = 33;

            /// <summary>
            /// Property Indexer for OriginalBillingCurrency
            /// </summary>
            public const int OriginalBillingCurrency = 34;

            /// <summary>
            /// Property Indexer for OriginalProjectStyle
            /// </summary>
            public const int OriginalProjectStyle = 35;

            /// <summary>
            /// Property Indexer for OriginalProjectType
            /// </summary>
            public const int OriginalProjectType = 36;

            /// <summary>
            /// Property Indexer for OriginalCustomerNumber
            /// </summary>
            public const int OriginalCustomerNumber = 37;

            /// <summary>
            /// Property Indexer for OriginalAccountingMethod
            /// </summary>
            public const int OriginalAccountingMethod = 38;

            /// <summary>
            /// Property Indexer for OriginalInvoiceType
            /// </summary>
            public const int OriginalInvoiceType = 39;

            /// <summary>
            /// Property Indexer for FromWIPAccount
            /// </summary>
            public const int FromWIPAccount = 40;

            /// <summary>
            /// Property Indexer for FromTransactionAccount
            /// </summary>
            public const int FromTransactionAccount = 41;

            /// <summary>
            /// Property Indexer for FromRevenueAccount
            /// </summary>
            public const int FromRevenueAccount = 42;

            /// <summary>
            /// Property Indexer for FromOverheadAccount
            /// </summary>
            public const int FromOverheadAccount = 43;

            /// <summary>
            /// Property Indexer for FromLaborAccount
            /// </summary>
            public const int FromLaborAccount = 44;

            /// <summary>
            /// Property Indexer for FromCostVarianceAccount
            /// </summary>
            public const int FromCostVarianceAccount = 45;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 46;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 47;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 48;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 49;

            /// <summary>
            /// Property Indexer for Module
            /// </summary>
            public const int Module = 50;

            /// <summary>
            /// Property Indexer for DocumentType
            /// </summary>
            public const int DocumentType = 51;

            /// <summary>
            /// Property Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 52;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 53;

            /// <summary>
            /// Property Indexer for UserID
            /// </summary>
            public const int UserID = 54;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 55;

            /// <summary>
            /// Property Indexer for TimeType
            /// </summary>
            public const int TimeType = 56;

            /// <summary>
            /// Property Indexer for ToWIPAccount
            /// </summary>
            public const int ToWIPAccount = 57;

            /// <summary>
            /// Property Indexer for ToTransactionAccount
            /// </summary>
            public const int ToTransactionAccount = 58;

            /// <summary>
            /// Property Indexer for ToRevenueAccount
            /// </summary>
            public const int ToRevenueAccount = 59;

            /// <summary>
            /// Property Indexer for ToOverheadAccount
            /// </summary>
            public const int ToOverheadAccount = 60;

            /// <summary>
            /// Property Indexer for ToLaborAccount
            /// </summary>
            public const int ToLaborAccount = 61;

            /// <summary>
            /// Property Indexer for ToCostVarianceAccount
            /// </summary>
            public const int ToCostVarianceAccount = 62;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for DFMTCONTNO
            /// </summary>
            public const int DFMTCONTNO = 63;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for DCONTRACT
            /// </summary>
            public const int DCONTRACT = 64;

            /// <summary>
            /// Property Indexer for RevisedProject
            /// </summary>
            public const int RevisedProject = 65;

            /// <summary>
            /// Property Indexer for RevisedCategory
            /// </summary>
            public const int RevisedCategory = 66;

            /// <summary>
            /// Property Indexer for CostType
            /// </summary>
            public const int CostType = 67;

            /// <summary>
            /// Property Indexer for RevisedResource
            /// </summary>
            public const int RevisedResource = 68;

            /// <summary>
            /// Property Indexer for ToUnformattedItemNumber
            /// </summary>
            public const int ToUnformattedItemNumber = 69;

            /// <summary>
            /// Property Indexer for ICBucketType
            /// </summary>
            public const int ICBucketType = 70;

            /// <summary>
            /// Property Indexer for ICDocumentNumber
            /// </summary>
            public const int ICDocumentNumber = 71;

            /// <summary>
            /// Property Indexer for ICCostingMethod
            /// </summary>
            public const int ICCostingMethod = 72;

            /// <summary>
            /// Property Indexer for ICTransactionDate
            /// </summary>
            public const int ICTransactionDate = 73;

            /// <summary>
            /// Property Indexer for ICLocation
            /// </summary>
            public const int ICLocation = 74;

            /// <summary>
            /// Property Indexer for RevisedBillingType
            /// </summary>
            public const int RevisedBillingType = 75;

            /// <summary>
            /// Property Indexer for RevisedARItemNumber
            /// </summary>
            public const int RevisedARItemNumber = 76;

            /// <summary>
            /// Property Indexer for RevisedARUnitOfMeasure
            /// </summary>
            public const int RevisedARUnitOfMeasure = 77;

            /// <summary>
            /// Property Indexer for RevisedICUnitOfMeasure
            /// </summary>
            public const int RevisedICUnitOfMeasure = 78;

            /// <summary>
            /// Property Indexer for RevisedQuantity
            /// </summary>
            public const int RevisedQuantity = 79;

            /// <summary>
            /// Property Indexer for RevisedUnitCost
            /// </summary>
            public const int RevisedUnitCost = 80;

            /// <summary>
            /// Property Indexer for RevisedBillingRate
            /// </summary>
            public const int RevisedBillingRate = 81;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for DEXTCOSTHM
            /// </summary>
            public const int DEXTCOSTHM = 82;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for DEXTCOSTSR
            /// </summary>
            public const int DEXTCOSTSR = 83;

            /// <summary>
            /// Property Indexer for RevisedExtendedBillingAmount
            /// </summary>
            public const int RevisedExtendedBillingAmount = 84;

            /// <summary>
            /// Property Indexer for RevisedLaborType
            /// </summary>
            public const int RevisedLaborType = 85;

            /// <summary>
            /// Property Indexer for RevisedLaborRate
            /// </summary>
            public const int RevisedLaborRate = 86;

            /// <summary>
            /// Property Indexer for RevisedLaborPercentage
            /// </summary>
            public const int RevisedLaborPercentage = 87;

            /// <summary>
            /// Property Indexer for RevisedLaborAmount
            /// </summary>
            public const int RevisedLaborAmount = 88;

            /// <summary>
            /// Property Indexer for RevisedOverheadAmount
            /// </summary>
            public const int RevisedOverheadAmount = 89;

            /// <summary>
            /// Property Indexer for RevisedOverheadType
            /// </summary>
            public const int RevisedOverheadType = 90;

            /// <summary>
            /// Property Indexer for RevisedOverheadRate
            /// </summary>
            public const int RevisedOverheadRate = 91;

            /// <summary>
            /// Property Indexer for RevisedOverheadPercentage
            /// </summary>
            public const int RevisedOverheadPercentage = 92;

            /// <summary>
            /// Property Indexer for RevisedTotalAmount
            /// </summary>
            public const int RevisedTotalAmount = 93;

            /// <summary>
            /// Property Indexer for RevisedBillingCurrency
            /// </summary>
            public const int RevisedBillingCurrency = 94;

            /// <summary>
            /// Property Indexer for RevisedProjectStyle
            /// </summary>
            public const int RevisedProjectStyle = 95;

            /// <summary>
            /// Property Indexer for RevisedProjectType
            /// </summary>
            public const int RevisedProjectType = 96;

            /// <summary>
            /// Property Indexer for RevisedCustomerNumber
            /// </summary>
            public const int RevisedCustomerNumber = 97;

            /// <summary>
            /// Property Indexer for RevisedAccountingMethod
            /// </summary>
            public const int RevisedAccountingMethod = 98;

            /// <summary>
            /// Property Indexer for RevisedInvoiceType
            /// </summary>
            public const int RevisedInvoiceType = 99;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for MANITEM
            /// </summary>
            public const int MANITEM = 100;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALUES
            /// </summary>
            public const int VALUES = 101;

            /// <summary>
            /// Property Indexer for OriginalEarningsCode
            /// </summary>
            public const int OriginalEarningsCode = 102;

            /// <summary>
            /// Property Indexer for RevisedEarningsCode
            /// </summary>
            public const int RevisedEarningsCode = 103;

            /// <summary>
            /// Property Indexer for OriginalPayType
            /// </summary>
            public const int OriginalPayType = 104;

            /// <summary>
            /// Property Indexer for RevisedPayType
            /// </summary>
            public const int RevisedPayType = 105;

            /// <summary>
            /// Property Indexer for GLDetailDescription
            /// </summary>
            public const int GLDetailDescription = 106;

            /// <summary>
            /// Property Indexer for GLDetailReference
            /// </summary>
            public const int GLDetailReference = 107;

            /// <summary>
            /// Property Indexer for GLDetailComment
            /// </summary>
            public const int GLDetailComment = 108;

            /// <summary>
            /// Property Indexer for CloseSN
            /// </summary>
            public const int CloseSN = 109;

            /// <summary>
            /// Property Indexer for SNInterCommunicationID
            /// </summary>
            public const int SNInterCommunicationID = 110;

            /// <summary>
            /// Property Indexer for PopupSN
            /// </summary>
            public const int PopupSN = 111;

            /// <summary>
            /// Property Indexer for PopupLT
            /// </summary>
            public const int PopupLT = 112;

            /// <summary>
            /// Property Indexer for CloseLT
            /// </summary>
            public const int CloseLT = 113;

            /// <summary>
            /// Property Indexer for LTInterCommunicationID
            /// </summary>
            public const int LTInterCommunicationID = 114;

            /// <summary>
            /// Property Indexer for ForcePopupSN
            /// </summary>
            public const int ForcePopupSN = 115;

            /// <summary>
            /// Property Indexer for ForcePopupLT
            /// </summary>
            public const int ForcePopupLT = 116;

            /// <summary>
            /// Property Indexer for GenerateICSequence
            /// </summary>
            public const int GenerateICSequence = 117;

            /// <summary>
            /// Property Indexer for OriginalEmployeeNumber
            /// </summary>
            public const int OriginalEmployeeNumber = 118;

            /// <summary>
            /// Property Indexer for RevisedEmployeeNumber
            /// </summary>
            public const int RevisedEmployeeNumber = 119;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for HASOPT
            /// </summary>
            public const int HASOPT = 1001;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1002;


        }

        #endregion

    }
}