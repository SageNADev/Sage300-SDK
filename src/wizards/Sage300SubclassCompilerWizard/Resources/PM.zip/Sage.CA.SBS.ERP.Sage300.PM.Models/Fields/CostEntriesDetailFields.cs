// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of CostEntriesDetail Constants
    /// </summary>
    public partial class CostEntriesDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0422";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"LINENO", "LineNumber"},
                    {"FMTCONTNO", "FormattedContractNumber"},
                    {"CONTDESC", "ContractDescription"},
                    {"CONTRACT", "Contract"},
                    {"PROJECT", "Project"},
                    {"PROJDESC", "ProjectDescription"},
                    {"CATEGORY", "Category"},
                    {"CATDESC", "CategoryDescription"},
                    {"RESOURCE", "Resource"},
                    {"DESC", "Description"},
                    {"QUANTITY", "Quantity"},
                    {"ARITEM", "ARItemNumber"},
                    {"ITEMDESC", "ARItemDescription"},
                    {"ARUOM", "ARUnitOfMeasure"},
                    {"UNITCOST", "UnitCost"},
                    {"EXTCOSTSR", "ExtendedCost"},
                    {"COMMENTS", "Comments"},
                    {"TRANACCT", "CostAccount"},
                    {"TRANDESC", "CostAccountDescription"},
                    {"WIPACCT", "WorkInProgressAccount"},
                    {"WIPDESC", "WorkInProgressAccountDescription"},
                    {"BILLTYPE", "BillingType"},
                    {"BILLRATE", "BillingRate"},
                    {"EXTBILLSR", "BillingAmount"},
                    //TODO udpate taxes information later
                    //{"TCLASS1", "TaxClass1"},
                    //{"TCLASS2", "TaxClass2"},
                    //{"TCLASS3", "TaxClass3"},
                    //{"TCLASS4", "TaxClass4"},
                    //{"TCLASS5", "TaxClass5"},
                    //{"TINCLUDED1", "TaxIncluded1"},
                    //{"TINCLUDED2", "TaxIncluded2"},
                    //{"TINCLUDED3", "TaxIncluded3"},
                    //{"TINCLUDED4", "TaxIncluded4"},
                    //{"TINCLUDED5", "TaxIncluded5"},
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of CostEntriesDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "DOCNUM";

            /// <summary>
            /// Property for LineType
            /// </summary>
            public const string LineType = "LINETYPE";

            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FormattedContractNumber = "FMTCONTNO";

            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for PROJECT
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for CATEGORY
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "TYPE";

            /// <summary>
            /// Property for ChargeCode
            /// </summary>
            public const string ChargeCode = "CHARGECODE";

            /// <summary>
            /// Property for DESC
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QUANTITY";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEM";

            /// <summary>
            /// Property for ARUnitOfMeasure
            /// </summary>
            public const string ARUnitOfMeasure = "ARUOM";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "EXTCOSTSR";

            /// <summary>
            /// Property for ExtendedCostHM
            /// </summary>
            public const string ExtendedCostHome = "EXTCOSTHM";

            /// <summary>
            /// Property for OverheadType
            /// </summary>
            public const string OverheadType = "OVERHD";

            /// <summary>
            /// Property for OverheadRate
            /// </summary>
            public const string OverheadRate = "OHEADRATE";

            /// <summary>
            /// Property for OverheadPercentage
            /// </summary>
            public const string OverheadPercentage = "HEADPER";

            /// <summary>
            /// Property for OverheadAmount
            /// </summary>
            public const string OverheadAmount = "OHSR";

            /// <summary>
            /// Property for OverheadAmountHM
            /// </summary>
            public const string OverheadAmountHome = "OHHM";

            /// <summary>
            /// Property for LaborType
            /// </summary>
            public const string LaborType = "LABOR";

            /// <summary>
            /// Property for LaborRate
            /// </summary>
            public const string LaborRate = "LABORRATE";

            /// <summary>
            /// Property for LaborPercentage
            /// </summary>
            public const string LaborPercentage = "LABORPER";

            /// <summary>
            /// Property for TransactionLaborAmountSource
            /// </summary>
            public const string TransactionLaborAmountSource = "LABORSR";

            /// <summary>
            /// Property for TransactionLaborAmountFuncti
            /// </summary>
            public const string TransactionLaborAmountFuncti = "LABORHM";

            /// <summary>
            /// Property for TotalCost
            /// </summary>
            public const string TotalCost = "TOTCOSTSR";

            /// <summary>
            /// Property for TotalCostHM
            /// </summary>
            public const string TotalCostAmountHome = "TOTCOSTHM";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for CostAccount
            /// </summary>
            public const string CostAccount = "TRANACCT";

            /// <summary>
            /// Property for OverheadAccount
            /// </summary>
            public const string OverheadAccount = "OHACCT";

            /// <summary>
            /// Property for LaborAccount
            /// </summary>
            public const string LaborAccount = "LABORACCT";

            /// <summary>
            /// Property for WorkInProgressAccount
            /// </summary>
            public const string WorkInProgressAccount = "WIPACCT";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for BillingAmount
            /// </summary>
            public const string BillingAmount = "EXTBILLSR";

            /// <summary>
            /// Property for BillingAmountHM
            /// </summary>
            public const string BillingAmountHome = "EXTBILLHM";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCCY";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TCLASS5";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TINCLUDED1";

            /// <summary>
            /// Property for TaxIncluded2
            /// </summary>
            public const string TaxIncluded2 = "TINCLUDED2";

            /// <summary>
            /// Property for TaxIncluded3
            /// </summary>
            public const string TaxIncluded3 = "TINCLUDED3";

            /// <summary>
            /// Property for TaxIncluded4
            /// </summary>
            public const string TaxIncluded4 = "TINCLUDED4";

            /// <summary>
            /// Property for TaxIncluded5
            /// </summary>
            public const string TaxIncluded5 = "TINCLUDED5";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string ContractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for RevenueRecType
            /// </summary>
            public const string RevenueRecType = "REVREC";

            /// <summary>
            /// Property for InventoryType
            /// </summary>
            public const string InventoryType = "INVTYPE";

            /// <summary>
            /// Property for VALUES
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for PayType
            /// </summary>
            public const string PayType = "PAYTYPE";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for Expense
            /// </summary>
            public const string Expense = "EXPENSE";

            /// <summary>
            /// Property for ExpenseType
            /// </summary>
            public const string ExpenseType = "EXPTYPE";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for ICUnitOfMeasure
            /// </summary>
            public const string ICUnitOfMeasure = "ICUOM";

            /// <summary>
            /// Property for CONVERSION
            /// </summary>
            public const string Conversion = "CONVERSION";

            /// <summary>
            /// Property for StockItem
            /// </summary>
            public const string StockItem = "STOCKITEM";

            /// <summary>
            /// Property for CostMethod
            /// </summary>
            public const string CostMethod = "COSTMETHOD";

            /// <summary>
            /// Property for UnformattedItemNumber
            /// </summary>
            public const string UnformattedItemNumber = "UNFMTITEM";

            /// <summary>
            /// Property for GLDetailDescription
            /// </summary>
            public const string GLDetailDescription = "GLDDESC";

            /// <summary>
            /// Property for GLDetailReference
            /// </summary>
            public const string GLDetailReference = "GLDREF";

            /// <summary>
            /// Property for GLDetailComment
            /// </summary>
            public const string GLDetailComment = "GLCOMMENT";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for TRANDESC
            /// </summary>
            public const string CostAccountDescription = "TRANDESC";

            /// <summary>
            /// Property for WIPDESC
            /// </summary>
            public const string WorkInProgressAccountDescription = "WIPDESC";

            /// <summary>
            /// Property for ITEMDESC
            /// </summary>
            public const string ARItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for CONTDESC
            /// </summary>
            public const string ContractDescription = "CONTDESC";

            /// <summary>
            /// Property for PROJDESC
            /// </summary>
            public const string ProjectDescription = "PROJDESC";

            /// <summary>
            /// Property for CATDESC
            /// </summary>
            public const string CategoryDescription = "CATDESC";

            /// <summary>
            /// Property for HASOPT
            /// </summary>
            public const string HasOptionalField = "HASOPT";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of CostEntriesDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 3;

            /// <summary>
            /// Property Indexer for LineType
            /// </summary>
            public const int LineType = 4;

            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FormattedContractNumber = 5;

            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int Contract = 6;

            /// <summary>
            /// Property Indexer for PROJECT
            /// </summary>
            public const int Project = 7;

            /// <summary>
            /// Property Indexer for CATEGORY
            /// </summary>
            public const int Category = 8;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 9;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 10;

            /// <summary>
            /// Property Indexer for ChargeCode
            /// </summary>
            public const int ChargeCode = 11;

            /// <summary>
            /// Property Indexer for DESC
            /// </summary>
            public const int Description = 12;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 13;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 14;

            /// <summary>
            /// Property Indexer for ARUnitOfMeasure
            /// </summary>
            public const int ARUnitOfMeasure = 15;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 16;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 17;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 18;

            /// <summary>
            /// Property Indexer for ExtendedCostHM
            /// </summary>
            public const int ExtendedCostHome = 19;

            /// <summary>
            /// Property Indexer for OverheadType
            /// </summary>
            public const int OverheadType = 20;

            /// <summary>
            /// Property Indexer for OverheadRate
            /// </summary>
            public const int OverheadRate = 21;

            /// <summary>
            /// Property Indexer for OverheadPercentage
            /// </summary>
            public const int OverheadPercentage = 22;

            /// <summary>
            /// Property Indexer for OverheadAmount
            /// </summary>
            public const int OverheadAmount = 23;

            /// <summary>
            /// Property Indexer for OverheadAmountHM
            /// </summary>
            public const int OverheadAmountHome = 24;

            /// <summary>
            /// Property Indexer for LaborType
            /// </summary>
            public const int LaborType = 25;

            /// <summary>
            /// Property Indexer for LaborRate
            /// </summary>
            public const int LaborRate = 26;

            /// <summary>
            /// Property Indexer for LaborPercentage
            /// </summary>
            public const int LaborPercentage = 27;

            /// <summary>
            /// Property Indexer for TransactionLaborAmountSource
            /// </summary>
            public const int TransactionLaborAmountSource = 28;

            /// <summary>
            /// Property Indexer for TransactionLaborAmountFuncti
            /// </summary>
            public const int TransactionLaborAmountFuncti = 29;

            /// <summary>
            /// Property Indexer for TotalCost
            /// </summary>
            public const int TotalCost = 30;

            /// <summary>
            /// Property Indexer for TotalCostHM
            /// </summary>
            public const int TotalCostAmountHome = 31;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 32;

            /// <summary>
            /// Property Indexer for CostAccount
            /// </summary>
            public const int CostAccount = 33;

            /// <summary>
            /// Property Indexer for OverheadAccount
            /// </summary>
            public const int OverheadAccount = 34;

            /// <summary>
            /// Property Indexer for LaborAccount
            /// </summary>
            public const int LaborAccount = 35;

            /// <summary>
            /// Property Indexer for WorkInProgressAccount
            /// </summary>
            public const int WorkInProgressAccount = 36;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 37;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 38;

            /// <summary>
            /// Property Indexer for BillingAmount
            /// </summary>
            public const int BillingAmount = 39;

            /// <summary>
            /// Property Indexer for BillingAmountHM
            /// </summary>
            public const int BillingAmountHome = 40;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 41;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 42;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 43;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 44;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 45;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 46;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 47;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 48;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 49;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 50;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 51;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 52;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 53;

            /// <summary>
            /// Property Indexer for TaxIncluded2
            /// </summary>
            public const int TaxIncluded2 = 54;

            /// <summary>
            /// Property Indexer for TaxIncluded3
            /// </summary>
            public const int TaxIncluded3 = 55;

            /// <summary>
            /// Property Indexer for TaxIncluded4
            /// </summary>
            public const int TaxIncluded4 = 56;

            /// <summary>
            /// Property Indexer for TaxIncluded5
            /// </summary>
            public const int TaxIncluded5 = 57;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int ContractStyle = 58;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 59;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 60;

            /// <summary>
            /// Property Indexer for RevenueRecType
            /// </summary>
            public const int RevenueRecType = 61;

            /// <summary>
            /// Property Indexer for InventoryType
            /// </summary>
            public const int InventoryType = 62;

            /// <summary>
            /// Property Indexer for VALUES
            /// </summary>
            public const int NumberOfOptionalFields = 63;

            /// <summary>
            /// Property Indexer for PayType
            /// </summary>
            public const int PayType = 64;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 65;

            /// <summary>
            /// Property Indexer for Expense
            /// </summary>
            public const int Expense = 66;

            /// <summary>
            /// Property Indexer for ExpenseType
            /// </summary>
            public const int ExpenseType = 67;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 68;

            /// <summary>
            /// Property Indexer for ICUnitOfMeasure
            /// </summary>
            public const int ICUnitOfMeasure = 69;

            /// <summary>
            /// Property Indexer for CONVERSION
            /// </summary>
            public const int Conversion = 70;

            /// <summary>
            /// Property Indexer for StockItem
            /// </summary>
            public const int StockItem = 71;

            /// <summary>
            /// Property Indexer for CostMethod
            /// </summary>
            public const int CostMethod = 72;

            /// <summary>
            /// Property Indexer for UnformattedItemNumber
            /// </summary>
            public const int UnformattedItemNumber = 73;

            /// <summary>
            /// Property Indexer for GLDetailDescription
            /// </summary>
            public const int GLDetailDescription = 74;

            /// <summary>
            /// Property Indexer for GLDetailReference
            /// </summary>
            public const int GLDetailReference = 75;

            /// <summary>
            /// Property Indexer for GLDetailComment
            /// </summary>
            public const int GLDetailComment = 76;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1001;

            /// <summary>
            /// Property Indexer for TRANDESC
            /// </summary>
            public const int CostAccountDescription = 1003;

            /// <summary>
            /// Property Indexer for WIPDESC
            /// </summary>
            public const int WorkInProgressAccountDescription = 1004;

            /// <summary>
            /// Property Indexer for ITEMDESC
            /// </summary>
            public const int ARItemDescription = 1005;

            /// <summary>
            /// Property Indexer for CONTDESC
            /// </summary>
            public const int ContractDescription = 1009;

            /// <summary>
            /// Property Indexer for PROJDESC
            /// </summary>
            public const int ProjectDescription = 1010;

            /// <summary>
            /// Property Indexer for CATDESC
            /// </summary>
            public const int CategoryDescription = 1011;

            /// <summary>
            /// Property Indexer for HASOPT
            /// </summary>
            public const int HasOptionalField = 1012;


        }

        #endregion

    }
}